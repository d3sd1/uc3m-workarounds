package utils;

public class ApiKeys {
    public static String API_KEY = "churrodetexto";
}
