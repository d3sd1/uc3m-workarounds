package utils;

public class Constants {
    
    /* SESSION AND LOGIN AND REGISTER */
    public static final String SESSION_USUARIO = "usuario";
    public static final String SESSION_ADMIN = "isUsuarioAdmin";
    public static final String SESSION_CARRITO = "carrito";
    
}
