package utils;

public class AdminUser {
    public static final String NOMBRE = "admin";
    public static final String CONTRASENA = "admin";
}
