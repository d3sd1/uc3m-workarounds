package exceptions;

public class ClienteSinFondosException extends Exception {

    public ClienteSinFondosException()
    {
    }

}
