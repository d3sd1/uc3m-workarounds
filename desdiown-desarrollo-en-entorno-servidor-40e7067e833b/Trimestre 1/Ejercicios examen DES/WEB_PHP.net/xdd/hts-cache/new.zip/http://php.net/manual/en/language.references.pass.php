<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Passing by Reference - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.references.pass.php">
 <link rel="shorturl" href="http://php.net/references.pass">
 <link rel="alternate" href="http://php.net/references.pass" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.references.php">
 <link rel="prev" href="http://php.net/manual/en/language.references.arent.php">
 <link rel="next" href="http://php.net/manual/en/language.references.return.php">

 <link rel="alternate" href="http://php.net/manual/en/language.references.pass.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.references.pass.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.references.pass.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.references.pass.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.references.pass.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.references.pass.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.references.pass.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.references.pass.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.references.pass.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.references.pass.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.references.pass.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.references.return.php">
          Returning References &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.references.arent.php">
          &laquo; What References Are Not        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.references.php'>References Explained</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.references.pass.php' selected="selected">English</option>
            <option value='pt_BR/language.references.pass.php'>Brazilian Portuguese</option>
            <option value='zh/language.references.pass.php'>Chinese (Simplified)</option>
            <option value='fr/language.references.pass.php'>French</option>
            <option value='de/language.references.pass.php'>German</option>
            <option value='ja/language.references.pass.php'>Japanese</option>
            <option value='ro/language.references.pass.php'>Romanian</option>
            <option value='ru/language.references.pass.php'>Russian</option>
            <option value='es/language.references.pass.php'>Spanish</option>
            <option value='tr/language.references.pass.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.references.pass.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.references.pass">Report a Bug</a>
    </div>
  </div><div id="language.references.pass" class="sect1">
   <h2 class="title">Passing by Reference</h2>
   <p class="para">
   You can pass a variable by reference to a function so the function
   can modify the variable. The syntax is as follows:
    <div class="informalexample">
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">foo</span><span style="color: #007700">(&amp;</span><span style="color: #0000BB">$var</span><span style="color: #007700">)<br />{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$var</span><span style="color: #007700">++;<br />}<br /><br /></span><span style="color: #0000BB">$a</span><span style="color: #007700">=</span><span style="color: #0000BB">5</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">foo</span><span style="color: #007700">(</span><span style="color: #0000BB">$a</span><span style="color: #007700">);<br /></span><span style="color: #FF8000">//&nbsp;$a&nbsp;is&nbsp;6&nbsp;here<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
    <blockquote class="note"><p><strong class="note">Note</strong>: 
     <span class="simpara">
      There is no reference sign on a function call - only on
      function definitions. Function definitions alone are enough to
      correctly pass the argument by reference.  As of PHP 5.3.0,
      you will get a warning saying that &quot;call-time pass-by-reference&quot; is
      deprecated when you use &amp; in <em>foo(&amp;$a);</em>. 
      And as of PHP 5.4.0, call-time pass-by-reference was removed, so
      using it will raise a fatal error.
     </span>
    </p></blockquote>
  </p>
  <p class="para">
  The following things can be passed by reference:
   <ul class="itemizedlist">
    <li class="listitem">
     <span class="simpara">
      Variables, i.e. <em>foo($a)</em>
     </span>
    </li>
    <li class="listitem">
     <span class="simpara">
      New statements, i.e. <em>foo(new foobar())</em>
     </span>
    </li>
    <li class="listitem">
     <p class="para">
      References returned from functions, i.e.:
    <div class="informalexample">
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">foo</span><span style="color: #007700">(&amp;</span><span style="color: #0000BB">$var</span><span style="color: #007700">)<br />{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$var</span><span style="color: #007700">++;<br />}<br />function&nbsp;&amp;</span><span style="color: #0000BB">bar</span><span style="color: #007700">()<br />{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">5</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">$a</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">foo</span><span style="color: #007700">(</span><span style="color: #0000BB">bar</span><span style="color: #007700">());<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
    See more about <a href="language.references.return.php" class="link">returning by reference</a>. 
     </p>
    </li>
  </ul>
  </p>
  <p class="para">
  No other expressions should be passed by reference, as the
  result is undefined. For example, the following examples of passing
  by reference are invalid:
    <div class="informalexample">
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">foo</span><span style="color: #007700">(&amp;</span><span style="color: #0000BB">$var</span><span style="color: #007700">)<br />{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$var</span><span style="color: #007700">++;<br />}<br />function&nbsp;</span><span style="color: #0000BB">bar</span><span style="color: #007700">()&nbsp;</span><span style="color: #FF8000">//&nbsp;Note&nbsp;the&nbsp;missing&nbsp;&amp;<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">5</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">$a</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">foo</span><span style="color: #007700">(</span><span style="color: #0000BB">bar</span><span style="color: #007700">());&nbsp;</span><span style="color: #FF8000">//&nbsp;Produces&nbsp;fatal&nbsp;error&nbsp;as&nbsp;of&nbsp;PHP&nbsp;5.0.5,&nbsp;strict&nbsp;standards&nbsp;notice<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;as&nbsp;of&nbsp;PHP&nbsp;5.1.1,&nbsp;and&nbsp;notice&nbsp;as&nbsp;of&nbsp;PHP&nbsp;7.0.0<br /><br /></span><span style="color: #0000BB">foo</span><span style="color: #007700">(</span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">5</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;Expression,&nbsp;not&nbsp;variable<br /></span><span style="color: #0000BB">foo</span><span style="color: #007700">(</span><span style="color: #0000BB">5</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;Produces&nbsp;fatal&nbsp;error<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>
  </div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.references.pass&amp;redirect=http://php.net/manual/en/language.references.pass.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">12 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="115919">  <div class="votes">
    <div id="Vu115919">
    <a href="/manual/vote-note.php?id=115919&amp;page=language.references.pass&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115919">
    <a href="/manual/vote-note.php?id=115919&amp;page=language.references.pass&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115919" title="82% like this...">
    212
    </div>
  </div>
  <a href="#115919" class="name">
  <strong class="user"><em>tnestved at yahoo dot com</em></strong></a><a class="genanchor" href="#115919"> &para;</a><div class="date" title="2014-10-14 01:54"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115919">
<div class="phpcode"><code><span class="html">
By removing the ability to include the reference sign on function calls where pass-by-reference is incurred (I.e., function definition uses &amp;), the readability of the code suffers, as one has to look at the function definition to know if the variable being passed is by-ref or not (I.e., potential to be modified).&nbsp; If both function calls and function definitions require the reference sign (I.e., &amp;), readability is improved, and it also lessens the potential of an inadvertent error in the code itself.&nbsp; Going full on fatal error in 5.4.0 now forces everyone to have less readable code.&nbsp; That is, does a function merely use the variable, or potentially modify it...now we have to find the function definition and physically look at it to know, whereas before we would know the intent immediately.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117305">  <div class="votes">
    <div id="Vu117305">
    <a href="/manual/vote-note.php?id=117305&amp;page=language.references.pass&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117305">
    <a href="/manual/vote-note.php?id=117305&amp;page=language.references.pass&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117305" title="67% like this...">
    22
    </div>
  </div>
  <a href="#117305" class="name">
  <strong class="user"><em>mike at eastghost dot com</em></strong></a><a class="genanchor" href="#117305"> &para;</a><div class="date" title="2015-05-19 07:06"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117305">
<div class="phpcode"><code><span class="html">
beware unset()&nbsp; destroys references<br /><br />$x = 'x';<br />change( $x );<br />echo $x; // outputs "x" not "q23"&nbsp; ---- remove the unset() and output is "q23" not "x"<br /><br />function change( &amp; $x )<br />{<br />&nbsp; &nbsp; unset( $x );<br />&nbsp; &nbsp; $x = 'q23';<br />&nbsp; &nbsp; return true;<br />}</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121535">  <div class="votes">
    <div id="Vu121535">
    <a href="/manual/vote-note.php?id=121535&amp;page=language.references.pass&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121535">
    <a href="/manual/vote-note.php?id=121535&amp;page=language.references.pass&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121535" title="66% like this...">
    1
    </div>
  </div>
  <a href="#121535" class="name">
  <strong class="user"><em>fladnag at zerezo dot com</em></strong></a><a class="genanchor" href="#121535"> &para;</a><div class="date" title="2017-08-18 09:29"><strong>3 months ago</strong></div>
  <div class="text" id="Hcom121535">
<div class="phpcode"><code><span class="html">
Beware of using references with anonymous function and "use" keyword :<br /><br />If you have a PHP version between 5.3 and &lt; 5.3.10, "use" keyword break the reference :<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">withRef</span><span class="keyword">(&amp;</span><span class="default">$arg</span><span class="keyword">) {<br />&nbsp; echo </span><span class="string">'withRef - BEGIN - '</span><span class="keyword">.</span><span class="default">$arg</span><span class="keyword">.</span><span class="string">"\n"</span><span class="keyword">; </span><span class="comment">// 1<br />&nbsp; </span><span class="default">$func </span><span class="keyword">= function() use(</span><span class="default">$arg</span><span class="keyword">) { </span><span class="comment">/* do nothing, just declare using $arg */ </span><span class="keyword">};<br />&nbsp; </span><span class="default">$arg </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">;<br />&nbsp; echo </span><span class="string">'withRef - END - '</span><span class="keyword">.</span><span class="default">$arg</span><span class="keyword">.</span><span class="string">"\n"</span><span class="keyword">; </span><span class="comment">// 2<br /></span><span class="keyword">}<br /><br /></span><span class="default">$arg </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />echo </span><span class="string">'withRef - BEFORE - '</span><span class="keyword">.</span><span class="default">$arg</span><span class="keyword">.</span><span class="string">"\n"</span><span class="keyword">; </span><span class="comment">// 1<br /></span><span class="default">withRef</span><span class="keyword">(</span><span class="default">$arg</span><span class="keyword">);<br /></span><span class="comment">// in PHP 5.3 &lt; 5.3.10 : display 1<br />// in PHP 5.3 &gt;= 5.3.10 : display 2<br /></span><span class="keyword">echo </span><span class="string">'withRef - AFTER - '</span><span class="keyword">.</span><span class="default">$arg</span><span class="keyword">.</span><span class="string">"\n"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />A workaround is to use a copy of the reference variable in "use" keyword :<br /><span class="default">&lt;?php<br />&nbsp; </span><span class="keyword">...<br />&nbsp; </span><span class="default">$arg2 </span><span class="keyword">= </span><span class="default">$arg</span><span class="keyword">;<br />&nbsp; </span><span class="default">$func </span><span class="keyword">= function() use(</span><span class="default">$arg2</span><span class="keyword">) { </span><span class="comment">/* do nothing, just declare using $arg2 */ </span><span class="keyword">};</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121134">  <div class="votes">
    <div id="Vu121134">
    <a href="/manual/vote-note.php?id=121134&amp;page=language.references.pass&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121134">
    <a href="/manual/vote-note.php?id=121134&amp;page=language.references.pass&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121134" title="66% like this...">
    1
    </div>
  </div>
  <a href="#121134" class="name">
  <strong class="user"><em>nickshanks at nickshanks dot com</em></strong></a><a class="genanchor" href="#121134"> &para;</a><div class="date" title="2017-05-26 12:49"><strong>6 months ago</strong></div>
  <div class="text" id="Hcom121134">
<div class="phpcode"><code><span class="html">
For anyone wondering, the copy-on-write behaviour just does the Right Thing™ when an array is passed to a function not by-ref which then passes it through to another function by-ref without writing to it. For example:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">do_sort</span><span class="keyword">(array </span><span class="default">$array</span><span class="keyword">) : array {<br />&nbsp; &nbsp; </span><span class="default">usort</span><span class="keyword">(</span><span class="default">$array</span><span class="keyword">, function (</span><span class="default">$a</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">strnatcasecmp</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">[</span><span class="string">'name'</span><span class="keyword">], </span><span class="default">$b</span><span class="keyword">[</span><span class="string">'name'</span><span class="keyword">]);<br />&nbsp; &nbsp; });<br /><br />&nbsp; &nbsp; return </span><span class="default">$array</span><span class="keyword">;<br />}<br /><br /></span><span class="default">$data </span><span class="keyword">= [<br />&nbsp; &nbsp; [<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'name' </span><span class="keyword">=&gt; </span><span class="string">'one'</span><span class="keyword">,<br />&nbsp; &nbsp; ], [<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'name' </span><span class="keyword">=&gt; </span><span class="string">'two'</span><span class="keyword">,<br />&nbsp; &nbsp; ], [<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'name' </span><span class="keyword">=&gt; </span><span class="string">'three'</span><span class="keyword">,<br />&nbsp; &nbsp; ], [<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'name' </span><span class="keyword">=&gt; </span><span class="string">'four'</span><span class="keyword">,<br />&nbsp; &nbsp; ],<br />];<br /><br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$data</span><span class="keyword">);<br /></span><span class="default">do_sort</span><span class="keyword">(</span><span class="default">$data</span><span class="keyword">); </span><span class="comment">// does not affect value of $data<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$data</span><span class="keyword">);<br /></span><span class="default">$data </span><span class="keyword">= </span><span class="default">do_sort</span><span class="keyword">(</span><span class="default">$data</span><span class="keyword">);<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$data</span><span class="keyword">);</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="109550">  <div class="votes">
    <div id="Vu109550">
    <a href="/manual/vote-note.php?id=109550&amp;page=language.references.pass&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd109550">
    <a href="/manual/vote-note.php?id=109550&amp;page=language.references.pass&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V109550" title="51% like this...">
    1
    </div>
  </div>
  <a href="#109550" class="name">
  <strong class="user"><em>diabolos @t gmail dot com</em></strong></a><a class="genanchor" href="#109550"> &para;</a><div class="date" title="2012-07-27 02:46"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom109550">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br /><br /></span><span class="comment">/*<br /><br />&nbsp; This function internally swaps the contents between <br />&nbsp; two simple variables using 'passing by reference'.<br /><br />&nbsp; Some programming languages have such a swap function <br />&nbsp; built in, but PHP seems to lack such a function.&nbsp; So, <br />&nbsp; one was created to fill the need.&nbsp; It only handles <br />&nbsp; simple, single variables, not arrays, but it is<br />&nbsp; still a very handy tool to have.<br /><br />&nbsp; No value is actually returned by this function, but <br />&nbsp; the contents of the indicated variables will be <br />&nbsp; exchanged (swapped) after the call.<br />*/<br /><br />// ------------------------------------------<br />// Demo call of the swap(...) function below.<br /><br /> </span><span class="default">$a </span><span class="keyword">= </span><span class="default">123.456</span><span class="keyword">;<br /> </span><span class="default">$b </span><span class="keyword">= </span><span class="string">'abcDEF'</span><span class="keyword">;<br />&nbsp; <br /> print </span><span class="string">"&lt;pre&gt;Define:\na = </span><span class="default">$a</span><span class="string">\nb = '</span><span class="default">$b</span><span class="string">'&lt;/pre&gt;"</span><span class="keyword">;<br /> </span><span class="default">swap</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">,</span><span class="default">$b</span><span class="keyword">);<br /> print </span><span class="string">"&lt;pre&gt;After swap(a,b):\na = '</span><span class="default">$a</span><span class="string">'\nb = </span><span class="default">$b</span><span class="string">&lt;/pre&gt;"</span><span class="keyword">;<br /><br /></span><span class="comment">// -------------------------------<br /><br />&nbsp;&nbsp; </span><span class="keyword">function </span><span class="default">swap </span><span class="keyword">(&amp;</span><span class="default">$arg1</span><span class="keyword">, &amp;</span><span class="default">$arg2</span><span class="keyword">)<br />{<br /><br /></span><span class="comment">// Swap contents of indicated variables.<br />&nbsp;&nbsp; </span><span class="default">$w</span><span class="keyword">=</span><span class="default">$arg1</span><span class="keyword">;&nbsp;&nbsp; </span><span class="default">$arg1</span><span class="keyword">=</span><span class="default">$arg2</span><span class="keyword">;&nbsp;&nbsp; </span><span class="default">$arg2</span><span class="keyword">=</span><span class="default">$w</span><span class="keyword">;<br />}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114705">  <div class="votes">
    <div id="Vu114705">
    <a href="/manual/vote-note.php?id=114705&amp;page=language.references.pass&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114705">
    <a href="/manual/vote-note.php?id=114705&amp;page=language.references.pass&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114705" title="50% like this...">
    0
    </div>
  </div>
  <a href="#114705" class="name">
  <strong class="user"><em>phpnet at holodyn dot com</em></strong></a><a class="genanchor" href="#114705"> &para;</a><div class="date" title="2014-03-26 06:38"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114705">
<div class="phpcode"><code><span class="html">
The notes indicate that a function variable reference will receive a deprecated warning in the 5.3 series, however when calling the function via call_user_func the operation aborts without fatal error.<br /><br />This is not a "bug" since it is not likely worth resolving, however should be noted in this documentation.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="68835">  <div class="votes">
    <div id="Vu68835">
    <a href="/manual/vote-note.php?id=68835&amp;page=language.references.pass&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd68835">
    <a href="/manual/vote-note.php?id=68835&amp;page=language.references.pass&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V68835" title="50% like this...">
    0
    </div>
  </div>
  <a href="#68835" class="name">
  <strong class="user"><em>fdelizy at unfreeze dot net</em></strong></a><a class="genanchor" href="#68835"> &para;</a><div class="date" title="2006-08-12 09:32"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom68835">
<div class="phpcode"><code><span class="html">
Some have noticed that reference parameters can not be assigned a default value. It's actually wrong, they can be assigned a value as the other variables, but can't have a "default reference value", for instance this code won't compile :<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">use_reference</span><span class="keyword">( </span><span class="default">$someParam</span><span class="keyword">, &amp;</span><span class="default">$param </span><span class="keyword">=&amp; </span><span class="default">$POST </span><span class="keyword">)<br />{<br /> ...<br />} <br /></span><span class="default">?&gt;<br /></span><br />But this one will work :<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">use_reference</span><span class="keyword">( </span><span class="default">$someParam</span><span class="keyword">, &amp;</span><span class="default">$param </span><span class="keyword">= </span><span class="default">null </span><span class="keyword">)<br /></span><span class="default">?&gt;<br /></span><br />So here is a workaround to have a default value for reference parameters :<br /><br /><span class="default">&lt;?php<br />$array1 </span><span class="keyword">= array ( </span><span class="string">'test'</span><span class="keyword">, </span><span class="string">'test2' </span><span class="keyword">);<br /><br />function </span><span class="default">AddTo</span><span class="keyword">( </span><span class="default">$key</span><span class="keyword">, </span><span class="default">$val</span><span class="keyword">, &amp;</span><span class="default">$array </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; if ( </span><span class="default">$array </span><span class="keyword">== </span><span class="default">null </span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$array </span><span class="keyword">=&amp; </span><span class="default">$_POST</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="default">$array</span><span class="keyword">[ </span><span class="default">$key </span><span class="keyword">] = </span><span class="default">$val </span><span class="keyword">;<br />}<br /><br /></span><span class="default">AddTo</span><span class="keyword">( </span><span class="string">"indirect test"</span><span class="keyword">, </span><span class="string">"test"</span><span class="keyword">, </span><span class="default">$array1 </span><span class="keyword">);<br /></span><span class="default">AddTo</span><span class="keyword">( </span><span class="string">"indirect POST test"</span><span class="keyword">, </span><span class="string">"test" </span><span class="keyword">);<br /><br />echo </span><span class="string">"Array 1 " </span><span class="keyword">;<br /></span><span class="default">print_r </span><span class="keyword">( </span><span class="default">$array1</span><span class="keyword">);<br /><br />echo </span><span class="string">"_POST "</span><span class="keyword">;<br /></span><span class="default">print_r</span><span class="keyword">( </span><span class="default">$_POST </span><span class="keyword">);<br /><br /></span><span class="default">?&gt;<br /></span><br />And this scripts output is :<br /><br />Array 1 Array<br />(<br />&nbsp; &nbsp; [0] =&gt; test<br />&nbsp; &nbsp; [1] =&gt; test2<br />&nbsp; &nbsp; [indirect test] =&gt; test<br />)<br />_POST Array<br />(<br />&nbsp; &nbsp; [indirect POST test] =&gt; test<br />)<br /><br />Of course that means you can only assign default reference to globals or super globals variables. <br /><br />Have fun</span>
</code></div>
  </div>
 </div>
  <div class="note" id="45554">  <div class="votes">
    <div id="Vu45554">
    <a href="/manual/vote-note.php?id=45554&amp;page=language.references.pass&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd45554">
    <a href="/manual/vote-note.php?id=45554&amp;page=language.references.pass&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V45554" title="50% like this...">
    0
    </div>
  </div>
  <a href="#45554" class="name">
  <strong class="user"><em>Sergio Santana: ssantana at tlaloc dot imta dot mx</em></strong></a><a class="genanchor" href="#45554"> &para;</a><div class="date" title="2004-09-10 08:25"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom45554">
<div class="phpcode"><code><span class="html">
Sometimes we need functions for building or modifying arrays whose elements are to be references to other variables (arrays or objects for instance). In this example, I wrote two functions 'tst' and 'tst1' that perform this task. Note how the functions are written, and how they are used.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">tst</span><span class="keyword">(&amp;</span><span class="default">$arr</span><span class="keyword">, </span><span class="default">$r</span><span class="keyword">) {<br />&nbsp; </span><span class="comment">// The argument '$arr' is declared to be passed by reference, <br />&nbsp; // but '$r' is not;<br />&nbsp; // however, in the function's body, we use a reference to <br />&nbsp; // the '$r' argument<br />&nbsp; <br />&nbsp; </span><span class="default">array_push</span><span class="keyword">(</span><span class="default">$arr</span><span class="keyword">, &amp;</span><span class="default">$r</span><span class="keyword">); <br />&nbsp; </span><span class="comment">// Alternatively, this also could be $arr[] = &amp;$r (in this case)<br /></span><span class="keyword">}<br />&nbsp; <br /></span><span class="default">$arr0 </span><span class="keyword">= array();&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// an empty array<br /></span><span class="default">$arr1 </span><span class="keyword">= array(</span><span class="default">1</span><span class="keyword">,</span><span class="default">2</span><span class="keyword">,</span><span class="default">3</span><span class="keyword">);&nbsp;&nbsp; </span><span class="comment">// the array to be referenced in $arr0<br /><br />// Note how we call the function:<br /></span><span class="default">tst</span><span class="keyword">(</span><span class="default">$arr0</span><span class="keyword">, &amp;</span><span class="default">$arr1</span><span class="keyword">); </span><span class="comment">// We are passing a reference to '$arr1' in the call !<br /><br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$arr0</span><span class="keyword">); </span><span class="comment">// Contains just the reference to $arr1<br /><br /></span><span class="default">array_push</span><span class="keyword">(</span><span class="default">$arr0</span><span class="keyword">, </span><span class="default">5</span><span class="keyword">); </span><span class="comment">// we add another element to $arr0<br /></span><span class="default">array_push</span><span class="keyword">(</span><span class="default">$arr1</span><span class="keyword">, </span><span class="default">18</span><span class="keyword">); </span><span class="comment">// we add another element to $arr1 as well<br /><br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$arr1</span><span class="keyword">);&nbsp; <br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$arr0</span><span class="keyword">); </span><span class="comment">// Changes in $arr1 are reflected in $arr0<br /><br />// -----------------------------------------<br />// A simpler way to do this:<br /><br /></span><span class="keyword">function </span><span class="default">tst1</span><span class="keyword">(&amp;</span><span class="default">$arr</span><span class="keyword">, &amp;</span><span class="default">$r</span><span class="keyword">) {<br />&nbsp; </span><span class="comment">// Both arguments '$arr' and '$r" are declared to be passed by<br />&nbsp; // reference, <br />&nbsp; // again, in the function's body, we use a reference to <br />&nbsp; // the '$r' argument<br />&nbsp; <br />&nbsp; </span><span class="default">array_push</span><span class="keyword">(</span><span class="default">$arr</span><span class="keyword">, &amp;</span><span class="default">$r</span><span class="keyword">); <br />&nbsp; </span><span class="comment">// Alternatively, this also could be $arr[] = &amp;$r (in this case)<br /></span><span class="keyword">}<br /><br />&nbsp; <br /></span><span class="default">$arr0 </span><span class="keyword">= array();&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// an empty array<br /></span><span class="default">$arr1 </span><span class="keyword">= array(</span><span class="default">1</span><span class="keyword">,</span><span class="default">2</span><span class="keyword">,</span><span class="default">3</span><span class="keyword">);&nbsp;&nbsp; </span><span class="comment">// the array to be referenced in $arr0<br /><br />// Note how we call the function:<br /></span><span class="default">tst1</span><span class="keyword">(</span><span class="default">$arr0</span><span class="keyword">, </span><span class="default">$arr1</span><span class="keyword">); </span><span class="comment">// 'tst1' understands '$r' is a reference to '$arr1'<br /><br /></span><span class="keyword">echo </span><span class="string">"-------- 2nd. alternative ------------ &lt;br&gt;\n"</span><span class="keyword">;<br /><br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$arr0</span><span class="keyword">); </span><span class="comment">// Contains just the reference to $arr1<br /><br /></span><span class="default">array_push</span><span class="keyword">(</span><span class="default">$arr0</span><span class="keyword">, </span><span class="default">5</span><span class="keyword">); </span><span class="comment">// we add another element to $arr0<br /></span><span class="default">array_push</span><span class="keyword">(</span><span class="default">$arr1</span><span class="keyword">, </span><span class="default">18</span><span class="keyword">);<br /><br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$arr1</span><span class="keyword">);&nbsp; <br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$arr0</span><span class="keyword">); </span><span class="comment">// Changes in $arr1 are reflected in $arr0<br /><br />// This outputs:<br />// X-Powered-By: PHP/4.1.2<br />// Content-type: text/html<br />// <br />// Array<br />// (<br />//&nbsp; &nbsp;&nbsp; [0] =&gt; Array<br />//&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; (<br />//&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; [0] =&gt; 1<br />//&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; [1] =&gt; 2<br />//&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; [2] =&gt; 3<br />//&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; )<br />// <br />// )<br />// Array<br />// (<br />//&nbsp; &nbsp;&nbsp; [0] =&gt; 1<br />//&nbsp; &nbsp;&nbsp; [1] =&gt; 2<br />//&nbsp; &nbsp;&nbsp; [2] =&gt; 3<br />//&nbsp; &nbsp;&nbsp; [3] =&gt; 18<br />// )<br />// Array<br />// (<br />//&nbsp; &nbsp;&nbsp; [0] =&gt; Array<br />//&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; (<br />//&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; [0] =&gt; 1<br />//&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; [1] =&gt; 2<br />//&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; [2] =&gt; 3<br />//&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; [3] =&gt; 18<br />//&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; )<br />// <br />//&nbsp; &nbsp;&nbsp; [1] =&gt; 5<br />// )<br />// -------- 2nd. alternative ------------ <br />// Array<br />// (<br />//&nbsp; &nbsp;&nbsp; [0] =&gt; Array<br />//&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; (<br />//&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; [0] =&gt; 1<br />//&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; [1] =&gt; 2<br />//&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; [2] =&gt; 3<br />//&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; )<br />// <br />// )<br />// Array<br />// (<br />//&nbsp; &nbsp;&nbsp; [0] =&gt; 1<br />//&nbsp; &nbsp;&nbsp; [1] =&gt; 2<br />//&nbsp; &nbsp;&nbsp; [2] =&gt; 3<br />//&nbsp; &nbsp;&nbsp; [3] =&gt; 18<br />// )<br />// Array<br />// (<br />//&nbsp; &nbsp;&nbsp; [0] =&gt; Array<br />//&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; (<br />//&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; [0] =&gt; 1<br />//&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; [1] =&gt; 2<br />//&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; [2] =&gt; 3<br />//&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; [3] =&gt; 18<br />//&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; )<br />// <br />//&nbsp; &nbsp;&nbsp; [1] =&gt; 5<br />// )<br /></span><span class="default">?&gt;<br /></span><br />In both cases we get the same result.<br /><br />I hope this is somehow useful<br /><br />Sergio.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117220">  <div class="votes">
    <div id="Vu117220">
    <a href="/manual/vote-note.php?id=117220&amp;page=language.references.pass&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117220">
    <a href="/manual/vote-note.php?id=117220&amp;page=language.references.pass&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117220" title="35% like this...">
    -4
    </div>
  </div>
  <a href="#117220" class="name">
  <strong class="user"><em>no at spam dot please</em></strong></a><a class="genanchor" href="#117220"> &para;</a><div class="date" title="2015-05-05 08:36"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117220">
<div class="phpcode"><code><span class="html">
agreed : this change produces less readable code.<br /><br />additionally, it breaks many existing perfectly working codes which are not portable anymore and in some cases will require complex modifications<br /><br />another issue regards the fatal error that is produced : how the hell am i supposed to do if i want to allow the user to use a value that is not even in a variable, or the return or a function call, or use call_user_func... this produces many occasions for a code to even break at run time</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120351">  <div class="votes">
    <div id="Vu120351">
    <a href="/manual/vote-note.php?id=120351&amp;page=language.references.pass&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120351">
    <a href="/manual/vote-note.php?id=120351&amp;page=language.references.pass&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120351" title="28% like this...">
    -6
    </div>
  </div>
  <a href="#120351" class="name">
  <strong class="user"><em>pallsopp at gmail dot com</em></strong></a><a class="genanchor" href="#120351"> &para;</a><div class="date" title="2016-12-19 08:32"><strong>11 months ago</strong></div>
  <div class="text" id="Hcom120351">
<div class="phpcode"><code><span class="html">
The comment by tnestved at yahoo dot com is incorrect as it is based purely on perception and not architecture. The method passing the object should not care whether it is by ref or by val, and nor should the reader.<br /><br />If we are talking about readability and perception, then the receiving method needs to show that the object coming in is a reference, not an object instance, otherwise the reader is perplexed why the object is not returned.<br /><br />Good functional headers alleviate all issues in this case.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="49950">  <div class="votes">
    <div id="Vu49950">
    <a href="/manual/vote-note.php?id=49950&amp;page=language.references.pass&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd49950">
    <a href="/manual/vote-note.php?id=49950&amp;page=language.references.pass&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V49950" title="30% like this...">
    -16
    </div>
  </div>
  <a href="#49950" class="name">
  <strong class="user"><em>pillepop2003 at yahoo dot de</em></strong></a><a class="genanchor" href="#49950"> &para;</a><div class="date" title="2005-02-13 08:08"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom49950">
<div class="phpcode"><code><span class="html">
PHP has a strange behavior when passing a part of an array by reference, that does not yet exist.<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">function </span><span class="default">func</span><span class="keyword">(&amp;</span><span class="default">$a</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// void();<br />&nbsp; &nbsp; </span><span class="keyword">}<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="default">$a</span><span class="keyword">[</span><span class="string">'one'</span><span class="keyword">] =</span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">func</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">[</span><span class="string">'two'</span><span class="keyword">]);<br /></span><span class="default">?&gt;</span>&nbsp; &nbsp; <br /><br />var_dump($a) returns<br /><br />&nbsp; &nbsp; array(2) {<br />&nbsp; &nbsp; &nbsp; &nbsp; ["one"]=&gt;<br />&nbsp; &nbsp; &nbsp; &nbsp; int(1)<br />&nbsp; &nbsp; &nbsp; &nbsp; ["two"]=&gt;<br />&nbsp; &nbsp; &nbsp; &nbsp; NULL<br />&nbsp; &nbsp; }<br /><br />...which seems to be not intentional!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="48484">  <div class="votes">
    <div id="Vu48484">
    <a href="/manual/vote-note.php?id=48484&amp;page=language.references.pass&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd48484">
    <a href="/manual/vote-note.php?id=48484&amp;page=language.references.pass&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V48484" title="27% like this...">
    -13
    </div>
  </div>
  <a href="#48484" class="name">
  <strong class="user"><em>obscvresovl at NOSPAM dot hotmail dot com</em></strong></a><a class="genanchor" href="#48484"> &para;</a><div class="date" title="2004-12-25 10:51"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom48484">
<div class="phpcode"><code><span class="html">
Just a simple note...<br /><br /><span class="default">&lt;?php<br /><br />$num </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br /><br />function </span><span class="default">blah</span><span class="keyword">(&amp;</span><span class="default">$var</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="default">$var</span><span class="keyword">++;<br />}<br /><br /></span><span class="default">blah</span><span class="keyword">(</span><span class="default">$num</span><span class="keyword">);<br /><br />echo </span><span class="default">$num</span><span class="keyword">; </span><span class="comment">#2<br /><br /></span><span class="default">?&gt;<br /></span><br /><span class="default">&lt;?php<br /><br />$num </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br /><br />function </span><span class="default">blah</span><span class="keyword">()<br />{<br />&nbsp; &nbsp; </span><span class="default">$var </span><span class="keyword">=&amp; </span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">"num"</span><span class="keyword">];<br />&nbsp; &nbsp; </span><span class="default">$var</span><span class="keyword">++;<br />}<br /><br /></span><span class="default">blah</span><span class="keyword">();<br /><br />echo </span><span class="default">$num</span><span class="keyword">; </span><span class="comment">#2<br /><br /></span><span class="default">?&gt;<br /></span><br />Both codes do the same thing! The second code "explains" how passage of parameters by reference works.</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.references.pass&amp;redirect=http://php.net/manual/en/language.references.pass.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.references.php">References Explained</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.references.whatare.php" title="What References Are">What References Are</a>
                        </li>
                          
                        <li class="">
                            <a href="language.references.whatdo.php" title="What References Do">What References Do</a>
                        </li>
                          
                        <li class="">
                            <a href="language.references.arent.php" title="What References Are Not">What References Are Not</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.references.pass.php" title="Passing by Reference">Passing by Reference</a>
                        </li>
                          
                        <li class="">
                            <a href="language.references.return.php" title="Returning References">Returning References</a>
                        </li>
                          
                        <li class="">
                            <a href="language.references.unset.php" title="Unsetting References">Unsetting References</a>
                        </li>
                          
                        <li class="">
                            <a href="language.references.spot.php" title="Spotting References">Spotting References</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

