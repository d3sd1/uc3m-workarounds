<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Bitwise Operators - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.operators.bitwise.php">
 <link rel="shorturl" href="http://php.net/operators.bitwise">
 <link rel="alternate" href="http://php.net/operators.bitwise" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.operators.php">
 <link rel="prev" href="http://php.net/manual/en/language.operators.assignment.php">
 <link rel="next" href="http://php.net/manual/en/language.operators.comparison.php">

 <link rel="alternate" href="http://php.net/manual/en/language.operators.bitwise.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.operators.bitwise.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.operators.bitwise.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.operators.bitwise.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.operators.bitwise.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.operators.bitwise.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.operators.bitwise.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.operators.bitwise.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.operators.bitwise.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.operators.bitwise.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.operators.bitwise.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.operators.comparison.php">
          Comparison Operators &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.operators.assignment.php">
          &laquo; Assignment Operators        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.operators.php'>Operators</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.operators.bitwise.php' selected="selected">English</option>
            <option value='pt_BR/language.operators.bitwise.php'>Brazilian Portuguese</option>
            <option value='zh/language.operators.bitwise.php'>Chinese (Simplified)</option>
            <option value='fr/language.operators.bitwise.php'>French</option>
            <option value='de/language.operators.bitwise.php'>German</option>
            <option value='ja/language.operators.bitwise.php'>Japanese</option>
            <option value='ro/language.operators.bitwise.php'>Romanian</option>
            <option value='ru/language.operators.bitwise.php'>Russian</option>
            <option value='es/language.operators.bitwise.php'>Spanish</option>
            <option value='tr/language.operators.bitwise.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.operators.bitwise.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.operators.bitwise">Report a Bug</a>
    </div>
  </div><div id="language.operators.bitwise" class="sect1">
   <h2 class="title">Bitwise Operators</h2>
   <p class="simpara">
    Bitwise operators allow evaluation and manipulation of specific
    bits within an integer.
   </p>
   <table class="doctable table">
    <caption><strong>Bitwise Operators</strong></caption>
    
     <thead>
      <tr>
       <th>Example</th>
       <th>Name</th>
       <th>Result</th>
      </tr>

     </thead>

     <tbody class="tbody">
      <tr>
       <td><strong class="userinput"><code>$a &amp; $b</code></strong></td>
       <td>And</td>
       <td>Bits that are set in both <var class="varname"><var class="varname">$a</var></var> and <var class="varname"><var class="varname">$b</var></var> are set.</td>
      </tr>

      <tr>
       <td><strong class="userinput"><code>$a | $b</code></strong></td>
       <td>Or (inclusive or)</td>
       <td>Bits that are set in either <var class="varname"><var class="varname">$a</var></var> or <var class="varname"><var class="varname">$b</var></var> are set.</td>
      </tr>

      <tr>
       <td><strong class="userinput"><code>$a ^ $b</code></strong></td>
       <td>Xor (exclusive or)</td>
       <td>
        Bits that are set in <var class="varname"><var class="varname">$a</var></var> or <var class="varname"><var class="varname">$b</var></var> but not both are set.
       </td>
      </tr>

      <tr>
       <td><strong class="userinput"><code>~ $a</code></strong></td>
       <td>Not</td>
       <td>
        Bits that are set in <var class="varname"><var class="varname">$a</var></var> are not set, and vice versa.
       </td>
      </tr>

      <tr>
       <td><strong class="userinput"><code>$a &lt;&lt; $b</code></strong></td>
       <td>Shift left</td>
       <td>
        Shift the bits of <var class="varname"><var class="varname">$a</var></var> <var class="varname"><var class="varname">$b</var></var> steps to the left (each step means
        &quot;multiply by two&quot;)
       </td>
      </tr>

      <tr>
       <td><strong class="userinput"><code>$a &gt;&gt; $b</code></strong></td>
       <td>Shift right</td>
       <td>
        Shift the bits of <var class="varname"><var class="varname">$a</var></var> <var class="varname"><var class="varname">$b</var></var> steps to the right (each step means
        &quot;divide by two&quot;)
       </td>
      </tr>

     </tbody>
    
   </table>

   <p class="para">
    Bit shifting in PHP is arithmetic.
    Bits shifted off either end are discarded.
    Left shifts have zeros shifted in on the right while the sign
    bit is shifted out on the left, meaning the sign of an operand
    is not preserved.
    Right shifts have copies of the sign bit shifted in on the left,
    meaning the sign of an operand is preserved.
   </p>
   <p class="para">
    Use parentheses to ensure the desired
    <a href="language.operators.precedence.php" class="link">precedence</a>.
    For example, <em>$a &amp; $b == true</em> evaluates
    the equivalency then the bitwise and; while
    <em>($a &amp; $b) == true</em> evaluates the bitwise and
    then the equivalency.
   </p>
   <p class="para">
    If both operands for the <em>&amp;</em>, <em>|</em> and
    <em>^</em> operators are strings, then the operation will be
    performed on the ASCII values of the characters that make up the strings and
    the result will be a string. In all other cases, both operands will be
    <a href="language.types.integer.php#language.types.integer.casting" class="link">converted to integers</a>
    and the result will be an integer.
   </p>
   <p class="para">
    If the operand for the <em>~</em> operator is a string, the
    operation will be performed on the ASCII values of the characters that make
    up the string and the result will be a string, otherwise the operand and the
    result will be treated as integers.
   </p>
   <p class="para">
    Both operands and the result for the <em>&lt;&lt;</em> and
    <em>&gt;&gt;</em> operators are always treated as integers.
   </p>
   <p class="para">
    <div class="informalexample">
     <p class="para">
      <pre class="literallayout">
PHP&#039;s error_reporting ini setting uses bitwise values,
providing a real-world demonstration of turning
bits off. To show all errors, except for notices,
the php.ini file instructions say to use:
<strong class="userinput"><code>E_ALL &amp; ~E_NOTICE</code></strong>
      </pre>
     </p>
     <p class="para">
      <pre class="literallayout">
This works by starting with E_ALL:
<span class="computeroutput">00000000000000000111011111111111</span>
Then taking the value of E_NOTICE...
<span class="computeroutput">00000000000000000000000000001000</span>
... and inverting it via <em>~</em>:
<span class="computeroutput">11111111111111111111111111110111</span>
Finally, it uses AND (&amp;) to find the bits turned
on in both values:
<span class="computeroutput">00000000000000000111011111110111</span>
      </pre>
     </p>
     <p class="para">
      <pre class="literallayout">
Another way to accomplish that is using XOR (<em>^</em>)
to find bits that are on in only one value or the other:
<strong class="userinput"><code>E_ALL ^ E_NOTICE</code></strong>
      </pre>
     </p>
    </div>
   </p>
   <p class="para">
    <div class="informalexample">
     <p class="para">
      <pre class="literallayout">
error_reporting can also be used to demonstrate turning bits on.
The way to show just errors and recoverable errors is:
<strong class="userinput"><code>E_ERROR | E_RECOVERABLE_ERROR</code></strong>
      </pre>
     </p>
     <p class="para">
      <pre class="literallayout">
This process combines E_ERROR
<span class="computeroutput">00000000000000000000000000000001</span>
and
<span class="computeroutput">00000000000000000001000000000000</span>
using the OR (<em>|</em>) operator
to get the bits turned on in either value:
<span class="computeroutput">00000000000000000001000000000001</span>
      </pre>
     </p>
    </div>
   </p>
   <p class="para">
    <div class="example" id="example-98">
     <p><strong>Example #1 Bitwise AND, OR and XOR operations on integers</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #FF8000">/*<br />&nbsp;*&nbsp;Ignore&nbsp;the&nbsp;top&nbsp;section,<br />&nbsp;*&nbsp;it&nbsp;is&nbsp;just&nbsp;formatting&nbsp;to&nbsp;make&nbsp;output&nbsp;clearer.<br />&nbsp;*/<br /><br /></span><span style="color: #0000BB">$format&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'(%1$2d&nbsp;=&nbsp;%1$04b)&nbsp;=&nbsp;(%2$2d&nbsp;=&nbsp;%2$04b)'<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">'&nbsp;%3$s&nbsp;(%4$2d&nbsp;=&nbsp;%4$04b)'&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br /><br />echo&nbsp;&lt;&lt;&lt;EOH<br /></span><span style="color: #DD0000">&nbsp;---------&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;---------&nbsp;&nbsp;--&nbsp;---------<br />&nbsp;result&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;value&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;op&nbsp;test<br />&nbsp;---------&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;---------&nbsp;&nbsp;--&nbsp;---------<br /></span><span style="color: #007700">EOH;<br /><br /><br /></span><span style="color: #FF8000">/*<br />&nbsp;*&nbsp;Here&nbsp;are&nbsp;the&nbsp;examples.<br />&nbsp;*/<br /><br /></span><span style="color: #0000BB">$values&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #0000BB">0</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">4</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">8</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">$test&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1&nbsp;</span><span style="color: #007700">+&nbsp;</span><span style="color: #0000BB">4</span><span style="color: #007700">;<br /><br />echo&nbsp;</span><span style="color: #DD0000">"\n&nbsp;Bitwise&nbsp;AND&nbsp;\n"</span><span style="color: #007700">;<br />foreach&nbsp;(</span><span style="color: #0000BB">$values&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">$value</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$result&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$value&nbsp;</span><span style="color: #007700">&amp;&nbsp;</span><span style="color: #0000BB">$test</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">printf</span><span style="color: #007700">(</span><span style="color: #0000BB">$format</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$result</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$value</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'&amp;'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$test</span><span style="color: #007700">);<br />}<br /><br />echo&nbsp;</span><span style="color: #DD0000">"\n&nbsp;Bitwise&nbsp;Inclusive&nbsp;OR&nbsp;\n"</span><span style="color: #007700">;<br />foreach&nbsp;(</span><span style="color: #0000BB">$values&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">$value</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$result&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$value&nbsp;</span><span style="color: #007700">|&nbsp;</span><span style="color: #0000BB">$test</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">printf</span><span style="color: #007700">(</span><span style="color: #0000BB">$format</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$result</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$value</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'|'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$test</span><span style="color: #007700">);<br />}<br /><br />echo&nbsp;</span><span style="color: #DD0000">"\n&nbsp;Bitwise&nbsp;Exclusive&nbsp;OR&nbsp;(XOR)&nbsp;\n"</span><span style="color: #007700">;<br />foreach&nbsp;(</span><span style="color: #0000BB">$values&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">$value</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$result&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$value&nbsp;</span><span style="color: #007700">^&nbsp;</span><span style="color: #0000BB">$test</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">printf</span><span style="color: #007700">(</span><span style="color: #0000BB">$format</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$result</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$value</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'^'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$test</span><span style="color: #007700">);<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

     <div class="example-contents"><p>The above example will output:</p></div>
     <div class="example-contents screen">
<div class="cdata"><pre>
 ---------     ---------  -- ---------
 result        value      op test
 ---------     ---------  -- ---------
 Bitwise AND
( 0 = 0000) = ( 0 = 0000) &amp; ( 5 = 0101)
( 1 = 0001) = ( 1 = 0001) &amp; ( 5 = 0101)
( 0 = 0000) = ( 2 = 0010) &amp; ( 5 = 0101)
( 4 = 0100) = ( 4 = 0100) &amp; ( 5 = 0101)
( 0 = 0000) = ( 8 = 1000) &amp; ( 5 = 0101)

 Bitwise Inclusive OR
( 5 = 0101) = ( 0 = 0000) | ( 5 = 0101)
( 5 = 0101) = ( 1 = 0001) | ( 5 = 0101)
( 7 = 0111) = ( 2 = 0010) | ( 5 = 0101)
( 5 = 0101) = ( 4 = 0100) | ( 5 = 0101)
(13 = 1101) = ( 8 = 1000) | ( 5 = 0101)

 Bitwise Exclusive OR (XOR)
( 5 = 0101) = ( 0 = 0000) ^ ( 5 = 0101)
( 4 = 0100) = ( 1 = 0001) ^ ( 5 = 0101)
( 7 = 0111) = ( 2 = 0010) ^ ( 5 = 0101)
( 1 = 0001) = ( 4 = 0100) ^ ( 5 = 0101)
(13 = 1101) = ( 8 = 1000) ^ ( 5 = 0101)
</pre></div>
     </div>
    </div>
   </p>
   <p class="para">
    <div class="example" id="example-99">
     <p><strong>Example #2 Bitwise XOR operations on strings</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #0000BB">12&nbsp;</span><span style="color: #007700">^&nbsp;</span><span style="color: #0000BB">9</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;Outputs&nbsp;'5'<br /><br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"12"&nbsp;</span><span style="color: #007700">^&nbsp;</span><span style="color: #DD0000">"9"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;Outputs&nbsp;the&nbsp;Backspace&nbsp;character&nbsp;(ascii&nbsp;8)<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;('1'&nbsp;(ascii&nbsp;49))&nbsp;^&nbsp;('9'&nbsp;(ascii&nbsp;57))&nbsp;=&nbsp;#8<br /><br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"hallo"&nbsp;</span><span style="color: #007700">^&nbsp;</span><span style="color: #DD0000">"hello"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;Outputs&nbsp;the&nbsp;ascii&nbsp;values&nbsp;#0&nbsp;#4&nbsp;#0&nbsp;#0&nbsp;#0<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;'a'&nbsp;^&nbsp;'e'&nbsp;=&nbsp;#4<br /><br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #0000BB">2&nbsp;</span><span style="color: #007700">^&nbsp;</span><span style="color: #DD0000">"3"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;Outputs&nbsp;1<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;2&nbsp;^&nbsp;((int)"3")&nbsp;==&nbsp;1<br /><br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"2"&nbsp;</span><span style="color: #007700">^&nbsp;</span><span style="color: #0000BB">3</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;Outputs&nbsp;1<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;((int)"2")&nbsp;^&nbsp;3&nbsp;==&nbsp;1<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>
   <p class="para">
    <div class="example" id="example-100">
     <p><strong>Example #3 Bit shifting on integers</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #FF8000">/*<br />&nbsp;*&nbsp;Here&nbsp;are&nbsp;the&nbsp;examples.<br />&nbsp;*/<br /><br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"\n---&nbsp;BIT&nbsp;SHIFT&nbsp;RIGHT&nbsp;ON&nbsp;POSITIVE&nbsp;INTEGERS&nbsp;---\n"</span><span style="color: #007700">;<br /><br /></span><span style="color: #0000BB">$val&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">4</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$places&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$res&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$val&nbsp;</span><span style="color: #007700">&gt;&gt;&nbsp;</span><span style="color: #0000BB">$places</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">p</span><span style="color: #007700">(</span><span style="color: #0000BB">$res</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$val</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'&gt;&gt;'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$places</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'copy&nbsp;of&nbsp;sign&nbsp;bit&nbsp;shifted&nbsp;into&nbsp;left&nbsp;side'</span><span style="color: #007700">);<br /><br /></span><span style="color: #0000BB">$val&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">4</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$places&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$res&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$val&nbsp;</span><span style="color: #007700">&gt;&gt;&nbsp;</span><span style="color: #0000BB">$places</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">p</span><span style="color: #007700">(</span><span style="color: #0000BB">$res</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$val</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'&gt;&gt;'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$places</span><span style="color: #007700">);<br /><br /></span><span style="color: #0000BB">$val&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">4</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$places&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">3</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$res&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$val&nbsp;</span><span style="color: #007700">&gt;&gt;&nbsp;</span><span style="color: #0000BB">$places</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">p</span><span style="color: #007700">(</span><span style="color: #0000BB">$res</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$val</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'&gt;&gt;'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$places</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'bits&nbsp;shift&nbsp;out&nbsp;right&nbsp;side'</span><span style="color: #007700">);<br /><br /></span><span style="color: #0000BB">$val&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">4</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$places&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">4</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$res&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$val&nbsp;</span><span style="color: #007700">&gt;&gt;&nbsp;</span><span style="color: #0000BB">$places</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">p</span><span style="color: #007700">(</span><span style="color: #0000BB">$res</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$val</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'&gt;&gt;'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$places</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'same&nbsp;result&nbsp;as&nbsp;above;&nbsp;can&nbsp;not&nbsp;shift&nbsp;beyond&nbsp;0'</span><span style="color: #007700">);<br /><br /><br />echo&nbsp;</span><span style="color: #DD0000">"\n---&nbsp;BIT&nbsp;SHIFT&nbsp;RIGHT&nbsp;ON&nbsp;NEGATIVE&nbsp;INTEGERS&nbsp;---\n"</span><span style="color: #007700">;<br /><br /></span><span style="color: #0000BB">$val&nbsp;</span><span style="color: #007700">=&nbsp;-</span><span style="color: #0000BB">4</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$places&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$res&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$val&nbsp;</span><span style="color: #007700">&gt;&gt;&nbsp;</span><span style="color: #0000BB">$places</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">p</span><span style="color: #007700">(</span><span style="color: #0000BB">$res</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$val</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'&gt;&gt;'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$places</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'copy&nbsp;of&nbsp;sign&nbsp;bit&nbsp;shifted&nbsp;into&nbsp;left&nbsp;side'</span><span style="color: #007700">);<br /><br /></span><span style="color: #0000BB">$val&nbsp;</span><span style="color: #007700">=&nbsp;-</span><span style="color: #0000BB">4</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$places&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$res&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$val&nbsp;</span><span style="color: #007700">&gt;&gt;&nbsp;</span><span style="color: #0000BB">$places</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">p</span><span style="color: #007700">(</span><span style="color: #0000BB">$res</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$val</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'&gt;&gt;'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$places</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'bits&nbsp;shift&nbsp;out&nbsp;right&nbsp;side'</span><span style="color: #007700">);<br /><br /></span><span style="color: #0000BB">$val&nbsp;</span><span style="color: #007700">=&nbsp;-</span><span style="color: #0000BB">4</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$places&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">3</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$res&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$val&nbsp;</span><span style="color: #007700">&gt;&gt;&nbsp;</span><span style="color: #0000BB">$places</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">p</span><span style="color: #007700">(</span><span style="color: #0000BB">$res</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$val</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'&gt;&gt;'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$places</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'same&nbsp;result&nbsp;as&nbsp;above;&nbsp;can&nbsp;not&nbsp;shift&nbsp;beyond&nbsp;-1'</span><span style="color: #007700">);<br /><br /><br />echo&nbsp;</span><span style="color: #DD0000">"\n---&nbsp;BIT&nbsp;SHIFT&nbsp;LEFT&nbsp;ON&nbsp;POSITIVE&nbsp;INTEGERS&nbsp;---\n"</span><span style="color: #007700">;<br /><br /></span><span style="color: #0000BB">$val&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">4</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$places&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$res&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$val&nbsp;</span><span style="color: #007700">&lt;&lt;&nbsp;</span><span style="color: #0000BB">$places</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">p</span><span style="color: #007700">(</span><span style="color: #0000BB">$res</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$val</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'&lt;&lt;'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$places</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'zeros&nbsp;fill&nbsp;in&nbsp;right&nbsp;side'</span><span style="color: #007700">);<br /><br /></span><span style="color: #0000BB">$val&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">4</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$places&nbsp;</span><span style="color: #007700">=&nbsp;(</span><span style="color: #0000BB">PHP_INT_SIZE&nbsp;</span><span style="color: #007700">*&nbsp;</span><span style="color: #0000BB">8</span><span style="color: #007700">)&nbsp;-&nbsp;</span><span style="color: #0000BB">4</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$res&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$val&nbsp;</span><span style="color: #007700">&lt;&lt;&nbsp;</span><span style="color: #0000BB">$places</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">p</span><span style="color: #007700">(</span><span style="color: #0000BB">$res</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$val</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'&lt;&lt;'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$places</span><span style="color: #007700">);<br /><br /></span><span style="color: #0000BB">$val&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">4</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$places&nbsp;</span><span style="color: #007700">=&nbsp;(</span><span style="color: #0000BB">PHP_INT_SIZE&nbsp;</span><span style="color: #007700">*&nbsp;</span><span style="color: #0000BB">8</span><span style="color: #007700">)&nbsp;-&nbsp;</span><span style="color: #0000BB">3</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$res&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$val&nbsp;</span><span style="color: #007700">&lt;&lt;&nbsp;</span><span style="color: #0000BB">$places</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">p</span><span style="color: #007700">(</span><span style="color: #0000BB">$res</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$val</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'&lt;&lt;'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$places</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'sign&nbsp;bits&nbsp;get&nbsp;shifted&nbsp;out'</span><span style="color: #007700">);<br /><br /></span><span style="color: #0000BB">$val&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">4</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$places&nbsp;</span><span style="color: #007700">=&nbsp;(</span><span style="color: #0000BB">PHP_INT_SIZE&nbsp;</span><span style="color: #007700">*&nbsp;</span><span style="color: #0000BB">8</span><span style="color: #007700">)&nbsp;-&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$res&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$val&nbsp;</span><span style="color: #007700">&lt;&lt;&nbsp;</span><span style="color: #0000BB">$places</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">p</span><span style="color: #007700">(</span><span style="color: #0000BB">$res</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$val</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'&lt;&lt;'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$places</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'bits&nbsp;shift&nbsp;out&nbsp;left&nbsp;side'</span><span style="color: #007700">);<br /><br /><br />echo&nbsp;</span><span style="color: #DD0000">"\n---&nbsp;BIT&nbsp;SHIFT&nbsp;LEFT&nbsp;ON&nbsp;NEGATIVE&nbsp;INTEGERS&nbsp;---\n"</span><span style="color: #007700">;<br /><br /></span><span style="color: #0000BB">$val&nbsp;</span><span style="color: #007700">=&nbsp;-</span><span style="color: #0000BB">4</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$places&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$res&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$val&nbsp;</span><span style="color: #007700">&lt;&lt;&nbsp;</span><span style="color: #0000BB">$places</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">p</span><span style="color: #007700">(</span><span style="color: #0000BB">$res</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$val</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'&lt;&lt;'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$places</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'zeros&nbsp;fill&nbsp;in&nbsp;right&nbsp;side'</span><span style="color: #007700">);<br /><br /></span><span style="color: #0000BB">$val&nbsp;</span><span style="color: #007700">=&nbsp;-</span><span style="color: #0000BB">4</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$places&nbsp;</span><span style="color: #007700">=&nbsp;(</span><span style="color: #0000BB">PHP_INT_SIZE&nbsp;</span><span style="color: #007700">*&nbsp;</span><span style="color: #0000BB">8</span><span style="color: #007700">)&nbsp;-&nbsp;</span><span style="color: #0000BB">3</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$res&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$val&nbsp;</span><span style="color: #007700">&lt;&lt;&nbsp;</span><span style="color: #0000BB">$places</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">p</span><span style="color: #007700">(</span><span style="color: #0000BB">$res</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$val</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'&lt;&lt;'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$places</span><span style="color: #007700">);<br /><br /></span><span style="color: #0000BB">$val&nbsp;</span><span style="color: #007700">=&nbsp;-</span><span style="color: #0000BB">4</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$places&nbsp;</span><span style="color: #007700">=&nbsp;(</span><span style="color: #0000BB">PHP_INT_SIZE&nbsp;</span><span style="color: #007700">*&nbsp;</span><span style="color: #0000BB">8</span><span style="color: #007700">)&nbsp;-&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$res&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$val&nbsp;</span><span style="color: #007700">&lt;&lt;&nbsp;</span><span style="color: #0000BB">$places</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">p</span><span style="color: #007700">(</span><span style="color: #0000BB">$res</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$val</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'&lt;&lt;'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$places</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'bits&nbsp;shift&nbsp;out&nbsp;left&nbsp;side,&nbsp;including&nbsp;sign&nbsp;bit'</span><span style="color: #007700">);<br /><br /><br /></span><span style="color: #FF8000">/*<br />&nbsp;*&nbsp;Ignore&nbsp;this&nbsp;bottom&nbsp;section,<br />&nbsp;*&nbsp;it&nbsp;is&nbsp;just&nbsp;formatting&nbsp;to&nbsp;make&nbsp;output&nbsp;clearer.<br />&nbsp;*/<br /><br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">p</span><span style="color: #007700">(</span><span style="color: #0000BB">$res</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$val</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$op</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$places</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$note&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">''</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$format&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'%0'&nbsp;</span><span style="color: #007700">.&nbsp;(</span><span style="color: #0000BB">PHP_INT_SIZE&nbsp;</span><span style="color: #007700">*&nbsp;</span><span style="color: #0000BB">8</span><span style="color: #007700">)&nbsp;.&nbsp;</span><span style="color: #DD0000">"b\n"</span><span style="color: #007700">;<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">printf</span><span style="color: #007700">(</span><span style="color: #DD0000">"Expression:&nbsp;%d&nbsp;=&nbsp;%d&nbsp;%s&nbsp;%d\n"</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$res</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$val</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$op</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$places</span><span style="color: #007700">);<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"&nbsp;Decimal:\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">printf</span><span style="color: #007700">(</span><span style="color: #DD0000">"&nbsp;&nbsp;val=%d\n"</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$val</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">printf</span><span style="color: #007700">(</span><span style="color: #DD0000">"&nbsp;&nbsp;res=%d\n"</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$res</span><span style="color: #007700">);<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"&nbsp;Binary:\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">printf</span><span style="color: #007700">(</span><span style="color: #DD0000">'&nbsp;&nbsp;val='&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">$format</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$val</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">printf</span><span style="color: #007700">(</span><span style="color: #DD0000">'&nbsp;&nbsp;res='&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">$format</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$res</span><span style="color: #007700">);<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(</span><span style="color: #0000BB">$note</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"&nbsp;NOTE:&nbsp;</span><span style="color: #0000BB">$note</span><span style="color: #DD0000">\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

     <div class="example-contents"><p>Output of the above example on 32 bit machines:</p></div>
     <div class="example-contents screen">
<div class="cdata"><pre>

--- BIT SHIFT RIGHT ON POSITIVE INTEGERS ---
Expression: 2 = 4 &gt;&gt; 1
 Decimal:
  val=4
  res=2
 Binary:
  val=00000000000000000000000000000100
  res=00000000000000000000000000000010
 NOTE: copy of sign bit shifted into left side

Expression: 1 = 4 &gt;&gt; 2
 Decimal:
  val=4
  res=1
 Binary:
  val=00000000000000000000000000000100
  res=00000000000000000000000000000001

Expression: 0 = 4 &gt;&gt; 3
 Decimal:
  val=4
  res=0
 Binary:
  val=00000000000000000000000000000100
  res=00000000000000000000000000000000
 NOTE: bits shift out right side

Expression: 0 = 4 &gt;&gt; 4
 Decimal:
  val=4
  res=0
 Binary:
  val=00000000000000000000000000000100
  res=00000000000000000000000000000000
 NOTE: same result as above; can not shift beyond 0


--- BIT SHIFT RIGHT ON NEGATIVE INTEGERS ---
Expression: -2 = -4 &gt;&gt; 1
 Decimal:
  val=-4
  res=-2
 Binary:
  val=11111111111111111111111111111100
  res=11111111111111111111111111111110
 NOTE: copy of sign bit shifted into left side

Expression: -1 = -4 &gt;&gt; 2
 Decimal:
  val=-4
  res=-1
 Binary:
  val=11111111111111111111111111111100
  res=11111111111111111111111111111111
 NOTE: bits shift out right side

Expression: -1 = -4 &gt;&gt; 3
 Decimal:
  val=-4
  res=-1
 Binary:
  val=11111111111111111111111111111100
  res=11111111111111111111111111111111
 NOTE: same result as above; can not shift beyond -1


--- BIT SHIFT LEFT ON POSITIVE INTEGERS ---
Expression: 8 = 4 &lt;&lt; 1
 Decimal:
  val=4
  res=8
 Binary:
  val=00000000000000000000000000000100
  res=00000000000000000000000000001000
 NOTE: zeros fill in right side

Expression: 1073741824 = 4 &lt;&lt; 28
 Decimal:
  val=4
  res=1073741824
 Binary:
  val=00000000000000000000000000000100
  res=01000000000000000000000000000000

Expression: -2147483648 = 4 &lt;&lt; 29
 Decimal:
  val=4
  res=-2147483648
 Binary:
  val=00000000000000000000000000000100
  res=10000000000000000000000000000000
 NOTE: sign bits get shifted out

Expression: 0 = 4 &lt;&lt; 30
 Decimal:
  val=4
  res=0
 Binary:
  val=00000000000000000000000000000100
  res=00000000000000000000000000000000
 NOTE: bits shift out left side


--- BIT SHIFT LEFT ON NEGATIVE INTEGERS ---
Expression: -8 = -4 &lt;&lt; 1
 Decimal:
  val=-4
  res=-8
 Binary:
  val=11111111111111111111111111111100
  res=11111111111111111111111111111000
 NOTE: zeros fill in right side

Expression: -2147483648 = -4 &lt;&lt; 29
 Decimal:
  val=-4
  res=-2147483648
 Binary:
  val=11111111111111111111111111111100
  res=10000000000000000000000000000000

Expression: 0 = -4 &lt;&lt; 30
 Decimal:
  val=-4
  res=0
 Binary:
  val=11111111111111111111111111111100
  res=00000000000000000000000000000000
 NOTE: bits shift out left side, including sign bit
</pre></div>
     </div>
     <div class="example-contents"><p>Output of the above example on 64 bit machines:</p></div>
     <div class="example-contents screen">
<div class="cdata"><pre>

--- BIT SHIFT RIGHT ON POSITIVE INTEGERS ---
Expression: 2 = 4 &gt;&gt; 1
 Decimal:
  val=4
  res=2
 Binary:
  val=0000000000000000000000000000000000000000000000000000000000000100
  res=0000000000000000000000000000000000000000000000000000000000000010
 NOTE: copy of sign bit shifted into left side

Expression: 1 = 4 &gt;&gt; 2
 Decimal:
  val=4
  res=1
 Binary:
  val=0000000000000000000000000000000000000000000000000000000000000100
  res=0000000000000000000000000000000000000000000000000000000000000001

Expression: 0 = 4 &gt;&gt; 3
 Decimal:
  val=4
  res=0
 Binary:
  val=0000000000000000000000000000000000000000000000000000000000000100
  res=0000000000000000000000000000000000000000000000000000000000000000
 NOTE: bits shift out right side

Expression: 0 = 4 &gt;&gt; 4
 Decimal:
  val=4
  res=0
 Binary:
  val=0000000000000000000000000000000000000000000000000000000000000100
  res=0000000000000000000000000000000000000000000000000000000000000000
 NOTE: same result as above; can not shift beyond 0


--- BIT SHIFT RIGHT ON NEGATIVE INTEGERS ---
Expression: -2 = -4 &gt;&gt; 1
 Decimal:
  val=-4
  res=-2
 Binary:
  val=1111111111111111111111111111111111111111111111111111111111111100
  res=1111111111111111111111111111111111111111111111111111111111111110
 NOTE: copy of sign bit shifted into left side

Expression: -1 = -4 &gt;&gt; 2
 Decimal:
  val=-4
  res=-1
 Binary:
  val=1111111111111111111111111111111111111111111111111111111111111100
  res=1111111111111111111111111111111111111111111111111111111111111111
 NOTE: bits shift out right side

Expression: -1 = -4 &gt;&gt; 3
 Decimal:
  val=-4
  res=-1
 Binary:
  val=1111111111111111111111111111111111111111111111111111111111111100
  res=1111111111111111111111111111111111111111111111111111111111111111
 NOTE: same result as above; can not shift beyond -1


--- BIT SHIFT LEFT ON POSITIVE INTEGERS ---
Expression: 8 = 4 &lt;&lt; 1
 Decimal:
  val=4
  res=8
 Binary:
  val=0000000000000000000000000000000000000000000000000000000000000100
  res=0000000000000000000000000000000000000000000000000000000000001000
 NOTE: zeros fill in right side

Expression: 4611686018427387904 = 4 &lt;&lt; 60
 Decimal:
  val=4
  res=4611686018427387904
 Binary:
  val=0000000000000000000000000000000000000000000000000000000000000100
  res=0100000000000000000000000000000000000000000000000000000000000000

Expression: -9223372036854775808 = 4 &lt;&lt; 61
 Decimal:
  val=4
  res=-9223372036854775808
 Binary:
  val=0000000000000000000000000000000000000000000000000000000000000100
  res=1000000000000000000000000000000000000000000000000000000000000000
 NOTE: sign bits get shifted out

Expression: 0 = 4 &lt;&lt; 62
 Decimal:
  val=4
  res=0
 Binary:
  val=0000000000000000000000000000000000000000000000000000000000000100
  res=0000000000000000000000000000000000000000000000000000000000000000
 NOTE: bits shift out left side


--- BIT SHIFT LEFT ON NEGATIVE INTEGERS ---
Expression: -8 = -4 &lt;&lt; 1
 Decimal:
  val=-4
  res=-8
 Binary:
  val=1111111111111111111111111111111111111111111111111111111111111100
  res=1111111111111111111111111111111111111111111111111111111111111000
 NOTE: zeros fill in right side

Expression: -9223372036854775808 = -4 &lt;&lt; 61
 Decimal:
  val=-4
  res=-9223372036854775808
 Binary:
  val=1111111111111111111111111111111111111111111111111111111111111100
  res=1000000000000000000000000000000000000000000000000000000000000000

Expression: 0 = -4 &lt;&lt; 62
 Decimal:
  val=-4
  res=0
 Binary:
  val=1111111111111111111111111111111111111111111111111111111111111100
  res=0000000000000000000000000000000000000000000000000000000000000000
 NOTE: bits shift out left side, including sign bit
</pre></div>
     </div>
    </div>
   </p>
   <div class="warning"><strong class="warning">Warning</strong>
    <p class="para">
     Prior to PHP 7.0, shifting integers by values greater than or equal to the
     system long integer width, or by negative numbers, results in undefined
     behavior. In other words, if you&#039;re using PHP 5.x, don&#039;t shift more than 31
     bits on a 32-bit system, and don&#039;t shift more than 63 bits on 64-bit
     system. 
    </p>
    <p class="para">
     Use functions from the <a href="book.gmp.php" class="link">gmp</a> extension for
     bitwise manipulation on numbers beyond <em>PHP_INT_MAX</em>.
    </p>
   </div>
   <p class="para">
    See also
    <span class="function"><a href="function.pack.php" class="function">pack()</a></span>,
    <span class="function"><a href="function.unpack.php" class="function">unpack()</a></span>,
    <span class="function"><a href="function.gmp-and.php" class="function">gmp_and()</a></span>,
    <span class="function"><a href="function.gmp-or.php" class="function">gmp_or()</a></span>,
    <span class="function"><a href="function.gmp-xor.php" class="function">gmp_xor()</a></span>,
    <span class="function"><a href="function.gmp-testbit.php" class="function">gmp_testbit()</a></span>,
    <span class="function"><a href="function.gmp-clrbit.php" class="function">gmp_clrbit()</a></span>
   </p>
  </div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.operators.bitwise&amp;redirect=http://php.net/manual/en/language.operators.bitwise.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">45 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="108679">  <div class="votes">
    <div id="Vu108679">
    <a href="/manual/vote-note.php?id=108679&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd108679">
    <a href="/manual/vote-note.php?id=108679&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V108679" title="89% like this...">
    88
    </div>
  </div>
  <a href="#108679" class="name">
  <strong class="user"><em>wbcarts at juno dot com</em></strong></a><a class="genanchor" href="#108679"> &para;</a><div class="date" title="2012-05-17 03:52"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom108679">
<div class="phpcode"><code><span class="html">
BITWISE FLAGS for Custom PHP Objects<br /><br />Sometimes I need a custom PHP Object that holds several boolean TRUE or FALSE values. I could easily include a variable for each of them, but as always, code has a way to get unweildy pretty fast. A more intelligent approach always seems to be the answer, even if it seems to be overkill at first.<br /><br />I start with an abstract base class which will hold a single integer variable called $flags. This simple integer can hold 32 TRUE or FALSE boolean values. Another thing to consider is to just set certain BIT values without disturbing any of the other BITS -- so included in the class definition is the setFlag($flag, $value) function, which will set only the chosen bit. Here's the abstract base class definition: <br /><br /><span class="default">&lt;?php<br /><br /></span><span class="comment"># BitwiseFlag.php<br /><br /></span><span class="keyword">abstract class </span><span class="default">BitwiseFlag<br /></span><span class="keyword">{<br />&nbsp; protected </span><span class="default">$flags</span><span class="keyword">;<br /><br />&nbsp; </span><span class="comment">/*<br />&nbsp;&nbsp; * Note: these functions are protected to prevent outside code<br />&nbsp;&nbsp; * from falsely setting BITS. See how the extending class 'User'<br />&nbsp;&nbsp; * handles this.<br />&nbsp;&nbsp; *<br />&nbsp;&nbsp; */<br />&nbsp; </span><span class="keyword">protected function </span><span class="default">isFlagSet</span><span class="keyword">(</span><span class="default">$flag</span><span class="keyword">)<br />&nbsp; {<br />&nbsp; &nbsp; return ((</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">flags </span><span class="keyword">&amp; </span><span class="default">$flag</span><span class="keyword">) == </span><span class="default">$flag</span><span class="keyword">);<br />&nbsp; }<br /><br />&nbsp; protected function </span><span class="default">setFlag</span><span class="keyword">(</span><span class="default">$flag</span><span class="keyword">, </span><span class="default">$value</span><span class="keyword">)<br />&nbsp; {<br />&nbsp; &nbsp; if(</span><span class="default">$value</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">flags </span><span class="keyword">|= </span><span class="default">$flag</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; else<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">flags </span><span class="keyword">&amp;= ~</span><span class="default">$flag</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; }<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />The class above is abstract and cannot be instantiated, so an extension is required. Below is a simple extension called User -- which is severely truncated for clarity. Notice I am defining const variables AND methods to use them.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="comment"># User.php<br /><br /></span><span class="keyword">require(</span><span class="string">'BitwiseFlag.php'</span><span class="keyword">);<br /><br />class </span><span class="default">User </span><span class="keyword">extends </span><span class="default">BitwiseFlag<br /></span><span class="keyword">{<br />&nbsp; const </span><span class="default">FLAG_REGISTERED </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">; </span><span class="comment">// BIT #1 of $flags has the value 1<br />&nbsp; </span><span class="keyword">const </span><span class="default">FLAG_ACTIVE </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">;&nbsp; &nbsp;&nbsp; </span><span class="comment">// BIT #2 of $flags has the value 2<br />&nbsp; </span><span class="keyword">const </span><span class="default">FLAG_MEMBER </span><span class="keyword">= </span><span class="default">4</span><span class="keyword">;&nbsp; &nbsp;&nbsp; </span><span class="comment">// BIT #3 of $flags has the value 4<br />&nbsp; </span><span class="keyword">const </span><span class="default">FLAG_ADMIN </span><span class="keyword">= </span><span class="default">8</span><span class="keyword">;&nbsp; &nbsp; &nbsp; </span><span class="comment">// BIT #4 of $flags has the value 8<br /><br />&nbsp; </span><span class="keyword">public function </span><span class="default">isRegistered</span><span class="keyword">(){<br />&nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">isFlagSet</span><span class="keyword">(</span><span class="default">self</span><span class="keyword">::</span><span class="default">FLAG_REGISTERED</span><span class="keyword">);<br />&nbsp; }<br /><br />&nbsp; public function </span><span class="default">isActive</span><span class="keyword">(){<br />&nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">isFlagSet</span><span class="keyword">(</span><span class="default">self</span><span class="keyword">::</span><span class="default">FLAG_ACTIVE</span><span class="keyword">);<br />&nbsp; }<br /><br />&nbsp; public function </span><span class="default">isMember</span><span class="keyword">(){<br />&nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">isFlagSet</span><span class="keyword">(</span><span class="default">self</span><span class="keyword">::</span><span class="default">FLAG_MEMBER</span><span class="keyword">);<br />&nbsp; }<br /><br />&nbsp; public function </span><span class="default">isAdmin</span><span class="keyword">(){<br />&nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">isFlagSet</span><span class="keyword">(</span><span class="default">self</span><span class="keyword">::</span><span class="default">FLAG_ADMIN</span><span class="keyword">);<br />&nbsp; }<br /><br />&nbsp; public function </span><span class="default">setRegistered</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">){<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">setFlag</span><span class="keyword">(</span><span class="default">self</span><span class="keyword">::</span><span class="default">FLAG_REGISTERED</span><span class="keyword">, </span><span class="default">$value</span><span class="keyword">);<br />&nbsp; }<br /><br />&nbsp; public function </span><span class="default">setActive</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">){<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">setFlag</span><span class="keyword">(</span><span class="default">self</span><span class="keyword">::</span><span class="default">FLAG_ACTIVE</span><span class="keyword">, </span><span class="default">$value</span><span class="keyword">);<br />&nbsp; }<br /><br />&nbsp; public function </span><span class="default">setMember</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">){<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">setFlag</span><span class="keyword">(</span><span class="default">self</span><span class="keyword">::</span><span class="default">FLAG_MEMBER</span><span class="keyword">, </span><span class="default">$value</span><span class="keyword">);<br />&nbsp; }<br /><br />&nbsp; public function </span><span class="default">setAdmin</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">){<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">setFlag</span><span class="keyword">(</span><span class="default">self</span><span class="keyword">::</span><span class="default">FLAG_ADMIN</span><span class="keyword">, </span><span class="default">$value</span><span class="keyword">);<br />&nbsp; }<br /><br />&nbsp; public function </span><span class="default">__toString</span><span class="keyword">(){<br />&nbsp; &nbsp; return </span><span class="string">'User [' </span><span class="keyword">.<br />&nbsp; &nbsp; &nbsp; (</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">isRegistered</span><span class="keyword">() ? </span><span class="string">'REGISTERED' </span><span class="keyword">: </span><span class="string">''</span><span class="keyword">) .<br />&nbsp; &nbsp; &nbsp; (</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">isActive</span><span class="keyword">() ? </span><span class="string">' ACTIVE' </span><span class="keyword">: </span><span class="string">''</span><span class="keyword">) .<br />&nbsp; &nbsp; &nbsp; (</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">isMember</span><span class="keyword">() ? </span><span class="string">' MEMBER' </span><span class="keyword">: </span><span class="string">''</span><span class="keyword">) .<br />&nbsp; &nbsp; &nbsp; (</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">isAdmin</span><span class="keyword">() ? </span><span class="string">' ADMIN' </span><span class="keyword">: </span><span class="string">''</span><span class="keyword">) .<br />&nbsp; &nbsp; </span><span class="string">']'</span><span class="keyword">;<br />&nbsp; }<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />This seems like a lot of work, but we have addressed many issues, for example, using and maintaining the code is easy, and the getting and setting of flag values make sense. With the User class, you can now see how easy and intuitive bitwise flag operations become.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">require(</span><span class="string">'User.php'</span><span class="keyword">)<br /><br /></span><span class="default">$user </span><span class="keyword">= new </span><span class="default">User</span><span class="keyword">();<br /></span><span class="default">$user</span><span class="keyword">-&gt;</span><span class="default">setRegistered</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">);<br /></span><span class="default">$user</span><span class="keyword">-&gt;</span><span class="default">setActive</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">);<br /></span><span class="default">$user</span><span class="keyword">-&gt;</span><span class="default">setMember</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">);<br /></span><span class="default">$user</span><span class="keyword">-&gt;</span><span class="default">setAdmin</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">);<br /><br />echo </span><span class="default">$user</span><span class="keyword">;&nbsp; </span><span class="comment">// outputs: User [REGISTERED ACTIVE MEMBER ADMIN]<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="84954">  <div class="votes">
    <div id="Vu84954">
    <a href="/manual/vote-note.php?id=84954&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd84954">
    <a href="/manual/vote-note.php?id=84954&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V84954" title="100% like this...">
    4
    </div>
  </div>
  <a href="#84954" class="name">
  <strong class="user"><em>m0sh at hotmail dot com</em></strong></a><a class="genanchor" href="#84954"> &para;</a><div class="date" title="2008-08-07 12:03"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom84954">
<div class="phpcode"><code><span class="html">
@greenone - nice function, thanks. I've adapted it for key usage:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">bitxor</span><span class="keyword">(</span><span class="default">$str</span><span class="keyword">, </span><span class="default">$key</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$xorWidth </span><span class="keyword">= </span><span class="default">PHP_INT_SIZE</span><span class="keyword">*</span><span class="default">8</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="comment">// split<br />&nbsp; &nbsp; </span><span class="default">$o1 </span><span class="keyword">= </span><span class="default">str_split</span><span class="keyword">(</span><span class="default">$str</span><span class="keyword">, </span><span class="default">$xorWidth</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$o2 </span><span class="keyword">= </span><span class="default">str_split</span><span class="keyword">(</span><span class="default">str_pad</span><span class="keyword">(</span><span class="string">''</span><span class="keyword">, </span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$str</span><span class="keyword">), </span><span class="default">$key</span><span class="keyword">), </span><span class="default">$xorWidth</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$res </span><span class="keyword">= </span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$runs </span><span class="keyword">= </span><span class="default">count</span><span class="keyword">(</span><span class="default">$o1</span><span class="keyword">);<br />&nbsp; &nbsp; for(</span><span class="default">$i</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">;</span><span class="default">$i</span><span class="keyword">&lt;</span><span class="default">$runs</span><span class="keyword">;</span><span class="default">$i</span><span class="keyword">++)<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$res </span><span class="keyword">.= </span><span class="default">decbin</span><span class="keyword">(</span><span class="default">bindec</span><span class="keyword">(</span><span class="default">$o1</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">]) ^ </span><span class="default">bindec</span><span class="keyword">(</span><span class="default">$o2</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">]));&nbsp; &nbsp; &nbsp;&nbsp; <br />&nbsp; &nbsp; return </span><span class="default">$res</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="91291">  <div class="votes">
    <div id="Vu91291">
    <a href="/manual/vote-note.php?id=91291&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd91291">
    <a href="/manual/vote-note.php?id=91291&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V91291" title="84% like this...">
    17
    </div>
  </div>
  <a href="#91291" class="name">
  <strong class="user"><em>grayda dot NOSPAM at DONTSPAM dot solidinc dot org</em></strong></a><a class="genanchor" href="#91291"> &para;</a><div class="date" title="2009-06-03 08:48"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom91291">
<div class="phpcode"><code><span class="html">
Initially, I found bitmasking to be a confusing concept and found no use for it. So I've whipped up this code snippet in case anyone else is confused:<br /><br /><span class="default">&lt;?php<br /><br />&nbsp; &nbsp; </span><span class="comment">// The various details a vehicle can have<br />&nbsp; &nbsp; </span><span class="default">$hasFourWheels </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$hasTwoWheels&nbsp; </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$hasDoors&nbsp; &nbsp; &nbsp; </span><span class="keyword">= </span><span class="default">4</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$hasRedColour&nbsp; </span><span class="keyword">= </span><span class="default">8</span><span class="keyword">;<br /><br />&nbsp; &nbsp; </span><span class="default">$bike&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">= </span><span class="default">$hasTwoWheels</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$golfBuggy&nbsp; &nbsp;&nbsp; </span><span class="keyword">= </span><span class="default">$hasFourWheels</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$ford&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">= </span><span class="default">$hasFourWheels </span><span class="keyword">| </span><span class="default">$hasDoors</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$ferrari&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="keyword">= </span><span class="default">$hasFourWheels </span><span class="keyword">| </span><span class="default">$hasDoors </span><span class="keyword">| </span><span class="default">$hasRedColour</span><span class="keyword">;<br /><br />&nbsp; &nbsp; </span><span class="default">$isBike&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">= </span><span class="default">$hasFourWheels </span><span class="keyword">&amp; </span><span class="default">$bike</span><span class="keyword">; </span><span class="comment"># False, because $bike doens't have four wheels<br />&nbsp; &nbsp; </span><span class="default">$isGolfBuggy&nbsp;&nbsp; </span><span class="keyword">= </span><span class="default">$hasFourWheels </span><span class="keyword">&amp; </span><span class="default">$golfBuggy</span><span class="keyword">; </span><span class="comment"># True, because $golfBuggy has four wheels<br />&nbsp; &nbsp; </span><span class="default">$isFord&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">= </span><span class="default">$hasFourWheels </span><span class="keyword">&amp; </span><span class="default">$ford</span><span class="keyword">; </span><span class="comment"># True, because $ford $hasFourWheels<br /><br /></span><span class="default">?&gt;<br /></span><br />And you can apply this to a lot of things, for example, security:<br /><br /><span class="default">&lt;?php<br /><br />&nbsp; &nbsp; </span><span class="comment">// Security permissions:<br />&nbsp; &nbsp; </span><span class="default">$writePost </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$readPost </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$deletePost </span><span class="keyword">= </span><span class="default">4</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$addUser </span><span class="keyword">= </span><span class="default">8</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$deleteUser </span><span class="keyword">= </span><span class="default">16</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">// User groups:<br />&nbsp; &nbsp; </span><span class="default">$administrator </span><span class="keyword">= </span><span class="default">$writePost </span><span class="keyword">| </span><span class="default">$readPosts </span><span class="keyword">| </span><span class="default">$deletePosts </span><span class="keyword">| </span><span class="default">$addUser </span><span class="keyword">| </span><span class="default">$deleteUser</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$moderator </span><span class="keyword">= </span><span class="default">$readPost </span><span class="keyword">| </span><span class="default">$deletePost </span><span class="keyword">| </span><span class="default">$deleteUser</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$writer </span><span class="keyword">= </span><span class="default">$writePost </span><span class="keyword">| </span><span class="default">$readPost</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$guest </span><span class="keyword">= </span><span class="default">$readPost</span><span class="keyword">;<br /><br />&nbsp; &nbsp; </span><span class="comment">// function to check for permission<br />&nbsp; &nbsp; </span><span class="keyword">function </span><span class="default">checkPermission</span><span class="keyword">(</span><span class="default">$user</span><span class="keyword">, </span><span class="default">$permission</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">$user </span><span class="keyword">&amp; </span><span class="default">$permission</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">true</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">// Now we apply all of this!<br />&nbsp; &nbsp; </span><span class="keyword">if(</span><span class="default">checkPermission</span><span class="keyword">(</span><span class="default">$administrator</span><span class="keyword">, </span><span class="default">$deleteUser</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">deleteUser</span><span class="keyword">(</span><span class="string">"Some User"</span><span class="keyword">); </span><span class="comment"># This is executed because $administrator can $deleteUser<br />&nbsp; &nbsp; </span><span class="keyword">}<br /><br /></span><span class="default">?&gt;<br /></span><br />Once you get your head around it, it's VERY useful! Just remember to raise each value by the power of two to avoid problems</span>
</code></div>
  </div>
 </div>
  <div class="note" id="50299">  <div class="votes">
    <div id="Vu50299">
    <a href="/manual/vote-note.php?id=50299&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd50299">
    <a href="/manual/vote-note.php?id=50299&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V50299" title="85% like this...">
    5
    </div>
  </div>
  <a href="#50299" class="name">
  <strong class="user"><em>icy at digitalitcc dot com</em></strong></a><a class="genanchor" href="#50299"> &para;</a><div class="date" title="2005-02-23 11:24"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom50299">
<div class="phpcode"><code><span class="html">
Say... you really want to have say... more than 31 bits available to you in your happy bitmask. And you don't want to use floats. So, one solution would to have an array of bitmasks, that are accessed through some kind of interface.<br /><br />Here is my solution for this: A class to store an array of integers being the bitmasks. It can hold up to 66571993087 bits, and frees up unused bitmasks when there are no bits being stored in them.<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">/*<br />&nbsp; &nbsp; Infinite* bits and bit handling in general.<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; *Not infinite, sorry.<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; Perceivably, the only limit to the bitmask class in storing bits would be<br />&nbsp; &nbsp; the maximum limit of the index number, on 32 bit integer systems 2^31 - 1,<br />&nbsp; &nbsp; so 2^31 * 31 - 1 = 66571993087 bits, assuming floats are 64 bit or something.<br />&nbsp; &nbsp; I'm sure that's enough enough bits for anything.. I hope :D.<br />*/<br /><br /></span><span class="default">DEFINE</span><span class="keyword">(</span><span class="string">'INTEGER_LENGTH'</span><span class="keyword">,</span><span class="default">31</span><span class="keyword">); </span><span class="comment">// Stupid signed bit.<br /><br /></span><span class="keyword">class </span><span class="default">bitmask<br /></span><span class="keyword">{<br />&nbsp; &nbsp; protected </span><span class="default">$bitmask </span><span class="keyword">= array();<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">set</span><span class="keyword">( </span><span class="default">$bit </span><span class="keyword">) </span><span class="comment">// Set some bit<br />&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$key </span><span class="keyword">= (int) (</span><span class="default">$bit </span><span class="keyword">/ </span><span class="default">INTEGER_LENGTH</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$bit </span><span class="keyword">= (int) </span><span class="default">fmod</span><span class="keyword">(</span><span class="default">$bit</span><span class="keyword">,</span><span class="default">INTEGER_LENGTH</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">bitmask</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">] |= </span><span class="default">1 </span><span class="keyword">&lt;&lt; </span><span class="default">$bit</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">remove</span><span class="keyword">( </span><span class="default">$bit </span><span class="keyword">) </span><span class="comment">// Remove some bit<br />&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$key </span><span class="keyword">= (int) (</span><span class="default">$bit </span><span class="keyword">/ </span><span class="default">INTEGER_LENGTH</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$bit </span><span class="keyword">= (int) </span><span class="default">fmod</span><span class="keyword">(</span><span class="default">$bit</span><span class="keyword">,</span><span class="default">INTEGER_LENGTH</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">bitmask</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">] &amp;= ~ (</span><span class="default">1 </span><span class="keyword">&lt;&lt; </span><span class="default">$bit</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; if(!</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">bitmask</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">])<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; unset(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">bitmask</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">]);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">toggle</span><span class="keyword">( </span><span class="default">$bit </span><span class="keyword">) </span><span class="comment">// Toggle some bit<br />&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$key </span><span class="keyword">= (int) (</span><span class="default">$bit </span><span class="keyword">/ </span><span class="default">INTEGER_LENGTH</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$bit </span><span class="keyword">= (int) </span><span class="default">fmod</span><span class="keyword">(</span><span class="default">$bit</span><span class="keyword">,</span><span class="default">INTEGER_LENGTH</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">bitmask</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">] ^= </span><span class="default">1 </span><span class="keyword">&lt;&lt; </span><span class="default">$bit</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; if(!</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">bitmask</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">])<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; unset(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">bitmask</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">]);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">read</span><span class="keyword">( </span><span class="default">$bit </span><span class="keyword">) </span><span class="comment">// Read some bit<br />&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$key </span><span class="keyword">= (int) (</span><span class="default">$bit </span><span class="keyword">/ </span><span class="default">INTEGER_LENGTH</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$bit </span><span class="keyword">= (int) </span><span class="default">fmod</span><span class="keyword">(</span><span class="default">$bit</span><span class="keyword">,</span><span class="default">INTEGER_LENGTH</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">bitmask</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">] &amp; (</span><span class="default">1 </span><span class="keyword">&lt;&lt; </span><span class="default">$bit</span><span class="keyword">);<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">stringin</span><span class="keyword">(</span><span class="default">$string</span><span class="keyword">) </span><span class="comment">// Read a string of bits that can be up to the maximum amount of bits long.<br />&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">bitmask </span><span class="keyword">= array();<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$array </span><span class="keyword">= </span><span class="default">str_split</span><span class="keyword">( </span><span class="default">strrev</span><span class="keyword">(</span><span class="default">$string</span><span class="keyword">), </span><span class="default">INTEGER_LENGTH </span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach( </span><span class="default">$array </span><span class="keyword">as </span><span class="default">$key </span><span class="keyword">=&gt; </span><span class="default">$value </span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">$value </span><span class="keyword">= </span><span class="default">bindec</span><span class="keyword">(</span><span class="default">strrev</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">)))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">bitmask</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">] = </span><span class="default">$value</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">stringout</span><span class="keyword">() </span><span class="comment">// Print out a string of your nice little bits<br />&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$string </span><span class="keyword">= </span><span class="string">""</span><span class="keyword">;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$keys </span><span class="keyword">= </span><span class="default">array_keys</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">bitmask</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">sort</span><span class="keyword">(</span><span class="default">$keys</span><span class="keyword">, </span><span class="default">SORT_NUMERIC</span><span class="keyword">);<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; for(</span><span class="default">$i </span><span class="keyword">= </span><span class="default">array_pop</span><span class="keyword">(</span><span class="default">$keys</span><span class="keyword">);</span><span class="default">$i </span><span class="keyword">&gt;= </span><span class="default">0</span><span class="keyword">;</span><span class="default">$i</span><span class="keyword">--)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">bitmask</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">])<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$string </span><span class="keyword">.= </span><span class="default">sprintf</span><span class="keyword">(</span><span class="string">"%0" </span><span class="keyword">. </span><span class="default">INTEGER_LENGTH </span><span class="keyword">. </span><span class="string">"b"</span><span class="keyword">,</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">bitmask</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$string</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">clear</span><span class="keyword">() </span><span class="comment">// Purge!<br />&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">bitmask </span><span class="keyword">= array();<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">debug</span><span class="keyword">() </span><span class="comment">// See what's going on in your bitmask array<br />&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">bitmask</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />It treats a positive integer input as a bit, so you don't have to deal with the powers of 2 yourself.<br /><br /><span class="default">&lt;?php<br />$bitmask </span><span class="keyword">= new </span><span class="default">bitmask</span><span class="keyword">();<br /><br /></span><span class="default">$bitmask</span><span class="keyword">-&gt;</span><span class="default">set</span><span class="keyword">(</span><span class="default">8979879</span><span class="keyword">); </span><span class="comment">// Whatever<br /><br /></span><span class="default">$bitmask</span><span class="keyword">-&gt;</span><span class="default">set</span><span class="keyword">(</span><span class="default">888</span><span class="keyword">);<br /><br />if(</span><span class="default">$bitmask</span><span class="keyword">-&gt;</span><span class="default">read</span><span class="keyword">(</span><span class="default">888</span><span class="keyword">))<br />&nbsp; &nbsp; print </span><span class="string">'Happy!\n'</span><span class="keyword">;<br /><br /></span><span class="default">$bitmask</span><span class="keyword">-&gt;</span><span class="default">toggle</span><span class="keyword">(</span><span class="default">39393</span><span class="keyword">); </span><span class="comment">// Yadda yadda<br /><br /></span><span class="default">$bitmask</span><span class="keyword">-&gt;</span><span class="default">remove</span><span class="keyword">(</span><span class="default">888</span><span class="keyword">);<br /><br /></span><span class="default">$bitmask</span><span class="keyword">-&gt;</span><span class="default">debug</span><span class="keyword">();<br /><br /></span><span class="default">$bitmask</span><span class="keyword">-&gt;</span><span class="default">stringin</span><span class="keyword">(</span><span class="string">"100101000101001000101010010101010<br />00000001000001"</span><span class="keyword">);<br /><br />print </span><span class="default">$bitmask</span><span class="keyword">-&gt;</span><span class="default">stringout</span><span class="keyword">() . </span><span class="string">"\n"</span><span class="keyword">;<br /><br /></span><span class="default">$bitmask</span><span class="keyword">-&gt;</span><span class="default">debug</span><span class="keyword">();<br /><br /></span><span class="default">$bitmask</span><span class="keyword">-&gt;</span><span class="default">clear</span><span class="keyword">();<br /><br /></span><span class="default">$bitmask</span><span class="keyword">-&gt;</span><span class="default">debug</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span><br />Would produce:<br /><br />Happy!<br /><br />array(2) {<br />&nbsp; [289673]=&gt;<br />&nbsp; int(65536)<br />&nbsp; [1270]=&gt;<br />&nbsp; int(8388608)<br />}<br /><br />0000000000000001001010001010010001010100101010100<br />0000001000001<br /><br />array(2) {<br />&nbsp; [0]=&gt;<br />&nbsp; int(355106881)<br />&nbsp; [1]=&gt;<br />&nbsp; int(37970)<br />}<br /><br />array(0) {<br />}</span>
</code></div>
  </div>
 </div>
  <div class="note" id="111683">  <div class="votes">
    <div id="Vu111683">
    <a href="/manual/vote-note.php?id=111683&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd111683">
    <a href="/manual/vote-note.php?id=111683&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V111683" title="81% like this...">
    7
    </div>
  </div>
  <a href="#111683" class="name">
  <strong class="user"><em>vivekanand dot pathak25 at gmail dot com</em></strong></a><a class="genanchor" href="#111683"> &para;</a><div class="date" title="2013-03-16 07:59"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom111683">
<div class="phpcode"><code><span class="html">
$a =&nbsp; &nbsp;&nbsp; 9;<br />$b =&nbsp; &nbsp;&nbsp; 10;<br />echo $a &amp; $b;<br /><br />place value&nbsp;&nbsp; 128&nbsp; 64&nbsp; 32&nbsp; 16&nbsp;&nbsp; 8&nbsp; 4&nbsp;&nbsp; 2&nbsp;&nbsp; 1<br />$a&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; 0&nbsp; &nbsp; &nbsp; 0&nbsp; &nbsp; 0&nbsp; &nbsp;&nbsp; 0&nbsp; &nbsp; 1&nbsp; 0&nbsp;&nbsp; 0&nbsp;&nbsp; 1&nbsp;&nbsp; =9<br />$b&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; 0&nbsp; &nbsp; &nbsp; 0&nbsp; &nbsp; 0&nbsp; &nbsp;&nbsp; 0&nbsp; &nbsp; 1&nbsp;&nbsp; 0&nbsp; 1&nbsp;&nbsp; 0&nbsp;&nbsp; =10<br /><br />result&nbsp;&nbsp; 8&nbsp; <br /><br /> only bit they share together is the 8 bit. So 8 gets returned.<br /><br />&nbsp; $a =&nbsp; &nbsp;&nbsp; 36;<br />$b =&nbsp; &nbsp;&nbsp; 103;<br />echo $a &amp; $b;<br /><br />place value&nbsp;&nbsp; 128&nbsp; 64&nbsp; 32&nbsp; 16&nbsp;&nbsp; 8&nbsp; &nbsp; 4&nbsp;&nbsp; 2&nbsp;&nbsp; 1<br />$a&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; 0&nbsp; &nbsp; &nbsp; 0&nbsp; &nbsp; 1&nbsp; &nbsp;&nbsp; 0&nbsp; &nbsp; 0&nbsp; &nbsp; 1&nbsp;&nbsp; 0&nbsp;&nbsp; 0&nbsp;&nbsp; =36<br />$b&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; 0&nbsp; &nbsp; &nbsp; 1&nbsp; &nbsp; 1&nbsp; &nbsp;&nbsp; 0&nbsp; &nbsp; 0&nbsp; &nbsp; 1&nbsp;&nbsp; 1&nbsp;&nbsp; 1&nbsp;&nbsp; =103<br /><br />result&nbsp; 32+4 = 36<br />the only bits these two share together are the bits 32 and 4 which when added together return 36.<br /><br />$a =&nbsp; &nbsp;&nbsp; 9;<br />$b =&nbsp; &nbsp;&nbsp; 10;<br />echo $a | $b;<br /><br />place value&nbsp;&nbsp; 128&nbsp; 64&nbsp; 32&nbsp; 16&nbsp;&nbsp; 8&nbsp; 4&nbsp;&nbsp; 2&nbsp;&nbsp; 1<br />$a&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; 0&nbsp; &nbsp; &nbsp; 0&nbsp; &nbsp; 0&nbsp; &nbsp;&nbsp; 0&nbsp; &nbsp; 1&nbsp; 0&nbsp;&nbsp; 0&nbsp;&nbsp; 1&nbsp;&nbsp; =9<br />$b&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; 0&nbsp; &nbsp; &nbsp; 0&nbsp; &nbsp; 0&nbsp; &nbsp;&nbsp; 0&nbsp; &nbsp; 1&nbsp;&nbsp; 0&nbsp; 1&nbsp;&nbsp; 0&nbsp;&nbsp; =10<br /><br />result 8+2+1 = 11<br /> 3 bits set, in the 8, 2, and 1 column.add those up 8+2+1 and you get 11<br /><br />$a =&nbsp; &nbsp;&nbsp; 9;<br />$b =&nbsp; &nbsp;&nbsp; 10;<br />echo $a ^ $b;<br /><br />place value&nbsp;&nbsp; 128&nbsp; 64&nbsp; 32&nbsp; 16&nbsp;&nbsp; 8&nbsp; 4&nbsp;&nbsp; 2&nbsp;&nbsp; 1<br />$a&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; 0&nbsp; &nbsp; &nbsp; 0&nbsp; &nbsp; 0&nbsp; &nbsp;&nbsp; 0&nbsp; &nbsp; 1&nbsp; 0&nbsp;&nbsp; 0&nbsp;&nbsp; 1&nbsp;&nbsp; =9<br />$b&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; 0&nbsp; &nbsp; &nbsp; 0&nbsp; &nbsp; 0&nbsp; &nbsp;&nbsp; 0&nbsp; &nbsp; 1&nbsp;&nbsp; 0&nbsp; 1&nbsp;&nbsp; 0&nbsp;&nbsp; =10<br /><br />result&nbsp; 2+1 = 3<br />the 2 bit and the 1 bit that they each have set but don't share. Soooo 2+1 = 3</span>
</code></div>
  </div>
 </div>
  <div class="note" id="50622">  <div class="votes">
    <div id="Vu50622">
    <a href="/manual/vote-note.php?id=50622&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd50622">
    <a href="/manual/vote-note.php?id=50622&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V50622" title="78% like this...">
    11
    </div>
  </div>
  <a href="#50622" class="name">
  <strong class="user"><em></em></strong></a><a class="genanchor" href="#50622"> &para;</a><div class="date" title="2005-03-04 03:13"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom50622">
<div class="phpcode"><code><span class="html">
A bitwise operators practical case :<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="comment">// We want to know the red, green and blue values of this color :<br />&nbsp; &nbsp; </span><span class="default">$color </span><span class="keyword">= </span><span class="default">0xFEA946 </span><span class="keyword">;<br /><br />&nbsp; &nbsp; </span><span class="default">$red </span><span class="keyword">= </span><span class="default">$color </span><span class="keyword">&gt;&gt; </span><span class="default">16 </span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$green </span><span class="keyword">= (</span><span class="default">$color </span><span class="keyword">&amp; </span><span class="default">0x00FF00</span><span class="keyword">) &gt;&gt; </span><span class="default">8 </span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$blue </span><span class="keyword">= </span><span class="default">$color </span><span class="keyword">&amp; </span><span class="default">0x0000FF </span><span class="keyword">;<br /><br />&nbsp; &nbsp; </span><span class="default">printf</span><span class="keyword">(</span><span class="string">'Red : %X (%d), Green : %X (%d), Blue : %X (%d)'</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$red</span><span class="keyword">, </span><span class="default">$red</span><span class="keyword">, </span><span class="default">$green</span><span class="keyword">, </span><span class="default">$green</span><span class="keyword">, </span><span class="default">$blue</span><span class="keyword">, </span><span class="default">$blue</span><span class="keyword">) ;<br /><br />&nbsp; &nbsp; </span><span class="comment">// Will display...<br />&nbsp; &nbsp; // Red : FE (254), Green : A9 (169), Blue : 46 (70)<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="90850">  <div class="votes">
    <div id="Vu90850">
    <a href="/manual/vote-note.php?id=90850&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd90850">
    <a href="/manual/vote-note.php?id=90850&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V90850" title="80% like this...">
    6
    </div>
  </div>
  <a href="#90850" class="name">
  <strong class="user"><em>Silver</em></strong></a><a class="genanchor" href="#90850"> &para;</a><div class="date" title="2009-05-12 04:36"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom90850">
<div class="phpcode"><code><span class="html">
Regarding what Bob said about flags, I'd like to point out there's a 100% safe way of defining flags, which is using hexadecimal notation for integers:<br /><br /><span class="default">&lt;?php<br />define</span><span class="keyword">(</span><span class="string">"f0"</span><span class="keyword">, </span><span class="default">0x1</span><span class="keyword">); </span><span class="comment">// 2^0<br /></span><span class="default">define</span><span class="keyword">(</span><span class="string">"f1"</span><span class="keyword">, </span><span class="default">0x2</span><span class="keyword">); </span><span class="comment">// 2^1<br /></span><span class="default">define</span><span class="keyword">(</span><span class="string">"f2"</span><span class="keyword">, </span><span class="default">0x4</span><span class="keyword">); </span><span class="comment">// 2^2<br /></span><span class="default">define</span><span class="keyword">(</span><span class="string">"f3"</span><span class="keyword">, </span><span class="default">0x8</span><span class="keyword">); </span><span class="comment">// 2^3<br /></span><span class="default">define</span><span class="keyword">(</span><span class="string">"f4"</span><span class="keyword">, </span><span class="default">0x10</span><span class="keyword">); </span><span class="comment">// 2^4<br /></span><span class="default">define</span><span class="keyword">(</span><span class="string">"f5"</span><span class="keyword">, </span><span class="default">0x20</span><span class="keyword">); </span><span class="comment">// 2^5<br />// ...<br /></span><span class="default">define</span><span class="keyword">(</span><span class="string">"f20"</span><span class="keyword">, </span><span class="default">0x1000000</span><span class="keyword">); </span><span class="comment">// 2^20<br /></span><span class="default">define</span><span class="keyword">(</span><span class="string">"f21"</span><span class="keyword">, </span><span class="default">0x2000000</span><span class="keyword">); </span><span class="comment">// 2^21<br /></span><span class="default">define</span><span class="keyword">(</span><span class="string">"f22"</span><span class="keyword">, </span><span class="default">0x4000000</span><span class="keyword">); </span><span class="comment">// 2^22<br /></span><span class="default">define</span><span class="keyword">(</span><span class="string">"f23"</span><span class="keyword">, </span><span class="default">0x8000000</span><span class="keyword">); </span><span class="comment">// 2^23<br /></span><span class="default">define</span><span class="keyword">(</span><span class="string">"f24"</span><span class="keyword">, </span><span class="default">0x10000000</span><span class="keyword">); </span><span class="comment">// 2^24<br />// ... up to 2^31<br /></span><span class="default">?&gt;<br /></span><br />I always avoid using decimal notation when I have a large amount of different flags, because it's very easy to misspell numbers like 2^20 (1048576).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="58190">  <div class="votes">
    <div id="Vu58190">
    <a href="/manual/vote-note.php?id=58190&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd58190">
    <a href="/manual/vote-note.php?id=58190&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V58190" title="80% like this...">
    6
    </div>
  </div>
  <a href="#58190" class="name">
  <strong class="user"><em>zlel grxnslxves13 at hotmail dot com~=s/x/ee/g</em></strong></a><a class="genanchor" href="#58190"> &para;</a><div class="date" title="2005-10-26 07:30"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom58190">
<div class="phpcode"><code><span class="html">
I refer to Eric Swanson's post on Perl VS PHP's implementation of xor. <br /><br />Actually, this is not an issue with the implementation of XOR,&nbsp; but a lot more to do with the lose-typing policy that PHP adopts. <br /><br />Freely switching between int and float is good for most cases, but problems happen when your value is near the word size of your machine. Which is to say, 32-bit machines will encounter problems with values that hover around 0x80000000 - primarily because PHP does not support unsigned integers.<br /><br />using bindec/decbin would address this issue as a work-around to do unsigned-int xor, but here's the real picture (i'm not claiming that this code will perform better, but this would be a better pedagogical code):<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">unsigned_xor32 </span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">) <br />{<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$a1 </span><span class="keyword">= </span><span class="default">$a </span><span class="keyword">&amp; </span><span class="default">0x7FFF0000</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$a2 </span><span class="keyword">= </span><span class="default">$a </span><span class="keyword">&amp; </span><span class="default">0x0000FFFF</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$a3 </span><span class="keyword">= </span><span class="default">$a </span><span class="keyword">&amp; </span><span class="default">0x80000000</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$b1 </span><span class="keyword">= </span><span class="default">$b </span><span class="keyword">&amp; </span><span class="default">0x7FFF0000</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$b2 </span><span class="keyword">= </span><span class="default">$b </span><span class="keyword">&amp; </span><span class="default">0x0000FFFF</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$b3 </span><span class="keyword">= </span><span class="default">$b </span><span class="keyword">&amp; </span><span class="default">0x80000000</span><span class="keyword">;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$c </span><span class="keyword">= (</span><span class="default">$a3 </span><span class="keyword">!= </span><span class="default">$b3</span><span class="keyword">) ? </span><span class="default">0x80000000 </span><span class="keyword">: </span><span class="default">0</span><span class="keyword">;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; return ((</span><span class="default">$a1 </span><span class="keyword">^ </span><span class="default">$b1</span><span class="keyword">) |(</span><span class="default">$a2 </span><span class="keyword">^ </span><span class="default">$b2</span><span class="keyword">)) + </span><span class="default">$c</span><span class="keyword">;<br />}<br /><br /></span><span class="default">$x </span><span class="keyword">= </span><span class="default">3851235679</span><span class="keyword">;<br /></span><span class="default">$y </span><span class="keyword">= </span><span class="default">43814</span><span class="keyword">;<br />echo </span><span class="string">"&lt;br&gt;This is the value we want"</span><span class="keyword">;<br />echo </span><span class="string">"&lt;br&gt;3851262585"</span><span class="keyword">;<br /><br />echo </span><span class="string">"&lt;br&gt;The result of a native xor operation on integer values is treated as a signed integer"</span><span class="keyword">;<br />echo </span><span class="string">"&lt;br&gt;"</span><span class="keyword">.(</span><span class="default">$x </span><span class="keyword">^ </span><span class="default">$y</span><span class="keyword">);<br /><br />echo </span><span class="string">"&lt;br&gt;We therefore perform the MSB separately"</span><span class="keyword">;<br />echo </span><span class="string">"&lt;br&gt;"</span><span class="keyword">.</span><span class="default">unsigned_xor32</span><span class="keyword">(</span><span class="default">$x</span><span class="keyword">, </span><span class="default">$y</span><span class="keyword">);<br /><br /></span><span class="default">?&gt;<br /></span><br />This is really foundation stuff, but for those of you who missed this in college, there seems to be something on 2's complement here: <br /><br /><a href="http://www.evergreen.edu/biophysics/technotes/program/2s_comp.htm" rel="nofollow" target="_blank">http://www.evergreen.edu/biophysics/technotes/program/2s_comp.htm</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="102403">  <div class="votes">
    <div id="Vu102403">
    <a href="/manual/vote-note.php?id=102403&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd102403">
    <a href="/manual/vote-note.php?id=102403&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V102403" title="75% like this...">
    4
    </div>
  </div>
  <a href="#102403" class="name">
  <strong class="user"><em>josh at joshstrike dot com</em></strong></a><a class="genanchor" href="#102403"> &para;</a><div class="date" title="2011-02-11 07:54"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom102403">
<div class="phpcode"><code><span class="html">
More referencing this for myself than anything... if you need to iterate through every possible binary combination where $n number of flags are set to 1 in a mask of $bits length:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">echo </span><span class="default">masksOf</span><span class="keyword">(</span><span class="default">3</span><span class="keyword">,</span><span class="default">10</span><span class="keyword">);<br /><br />function </span><span class="default">masksOf</span><span class="keyword">(</span><span class="default">$n</span><span class="keyword">,</span><span class="default">$bits</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$u </span><span class="keyword">= </span><span class="default">pow</span><span class="keyword">(</span><span class="default">2</span><span class="keyword">,</span><span class="default">$bits</span><span class="keyword">)-</span><span class="default">1</span><span class="keyword">; </span><span class="comment">//start value, full flags on.<br />&nbsp; &nbsp; </span><span class="default">$masks </span><span class="keyword">= array();<br />&nbsp; &nbsp; while (</span><span class="default">$u</span><span class="keyword">&gt;</span><span class="default">0</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$z </span><span class="keyword">= </span><span class="default">numflags</span><span class="keyword">(</span><span class="default">$u</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$z</span><span class="keyword">==</span><span class="default">$n</span><span class="keyword">) </span><span class="default">array_push</span><span class="keyword">(</span><span class="default">$masks</span><span class="keyword">,</span><span class="default">$u</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$u</span><span class="keyword">--;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; return (</span><span class="default">$masks</span><span class="keyword">);&nbsp; &nbsp; <br />}<br /><br />function </span><span class="default">numflags</span><span class="keyword">(</span><span class="default">$n</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$k </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />&nbsp; &nbsp; while (</span><span class="default">$n</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$k </span><span class="keyword">+= </span><span class="default">$n </span><span class="keyword">&amp; </span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$n </span><span class="keyword">= </span><span class="default">$n </span><span class="keyword">&gt;&gt; </span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; return (</span><span class="default">$k</span><span class="keyword">);<br /><br /></span><span class="comment">//&nbsp; &nbsp; alternately: <br />//&nbsp; &nbsp; $u = 0;<br />//&nbsp; &nbsp; for ($k=1;$k&lt;=$n;$k*=2) {<br />//&nbsp; &nbsp; &nbsp; &nbsp; $u+=($n&amp;$k?1:0);<br />//&nbsp; &nbsp; }<br />//&nbsp; &nbsp; return ($u);<br /></span><span class="keyword">}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="94144">  <div class="votes">
    <div id="Vu94144">
    <a href="/manual/vote-note.php?id=94144&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd94144">
    <a href="/manual/vote-note.php?id=94144&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V94144" title="75% like this...">
    4
    </div>
  </div>
  <a href="#94144" class="name">
  <strong class="user"><em>zooly at globmi dot com</em></strong></a><a class="genanchor" href="#94144"> &para;</a><div class="date" title="2009-10-19 07:52"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom94144">
<div class="phpcode"><code><span class="html">
Here is an example for bitwise leftrotate and rightrotate.<br /><br />Note that this function works only with decimal numbers - other types can be converted with pack().<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">rotate </span><span class="keyword">( </span><span class="default">$decimal</span><span class="keyword">, </span><span class="default">$bits</span><span class="keyword">) {<br /><br />&nbsp; </span><span class="default">$binary </span><span class="keyword">= </span><span class="default">decbin</span><span class="keyword">(</span><span class="default">$decimal</span><span class="keyword">);<br /><br />&nbsp; return (<br />&nbsp; &nbsp; </span><span class="default">bindec</span><span class="keyword">(</span><span class="default">substr</span><span class="keyword">(</span><span class="default">$binary</span><span class="keyword">, </span><span class="default">$bits</span><span class="keyword">).</span><span class="default">substr</span><span class="keyword">(</span><span class="default">$binary</span><span class="keyword">, </span><span class="default">0</span><span class="keyword">, </span><span class="default">$bits</span><span class="keyword">))<br />&nbsp; );<br /><br />}<br /><br /></span><span class="comment">// Rotate 124 (1111100) to the left with 1 bits<br /><br /></span><span class="keyword">echo </span><span class="default">rotate</span><span class="keyword">(</span><span class="default">124</span><span class="keyword">, </span><span class="default">1</span><span class="keyword">);<br /><br /></span><span class="comment">// = 121 (1111001)<br /><br />// Rotate 124 (1111100) to the right with 3 bits<br /><br /></span><span class="keyword">echo </span><span class="default">rotate</span><span class="keyword">(</span><span class="default">124</span><span class="keyword">, -</span><span class="default">3</span><span class="keyword">);<br /><br /></span><span class="comment">// = 79 (1001111)<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="95614">  <div class="votes">
    <div id="Vu95614">
    <a href="/manual/vote-note.php?id=95614&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd95614">
    <a href="/manual/vote-note.php?id=95614&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V95614" title="75% like this...">
    2
    </div>
  </div>
  <a href="#95614" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#95614"> &para;</a><div class="date" title="2010-01-12 10:18"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom95614">
<div class="phpcode"><code><span class="html">
Beware that PHP's &lt;&lt; and &gt;&gt; operators, unlike the other bitwise operators do not work on ASCII values; &lt;&lt; and &gt;&gt; cast their operands to integer (when possible) before shifting and will always return an integer result.<br /><br />For example:<br /><br /><span class="default">&lt;?php<br />$foo </span><span class="keyword">= </span><span class="string">"1"</span><span class="keyword">; </span><span class="comment">// chr(49)<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$foo </span><span class="keyword">&lt;&lt; </span><span class="default">1</span><span class="keyword">); </span><span class="comment">// Output is int(2)<br /><br /></span><span class="default">$foo </span><span class="keyword">= </span><span class="string">"!"</span><span class="keyword">; </span><span class="comment">// chr(33)<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$foo </span><span class="keyword">&lt;&lt; </span><span class="default">1</span><span class="keyword">); </span><span class="comment">// Output is int(0)<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="104291">  <div class="votes">
    <div id="Vu104291">
    <a href="/manual/vote-note.php?id=104291&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd104291">
    <a href="/manual/vote-note.php?id=104291&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V104291" title="72% like this...">
    5
    </div>
  </div>
  <a href="#104291" class="name">
  <strong class="user"><em>ivoras at gmail dot com</em></strong></a><a class="genanchor" href="#104291"> &para;</a><div class="date" title="2011-06-06 04:44"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom104291">
<div class="phpcode"><code><span class="html">
As an additional curiosity, for some reason the result of the operation ("18" &amp; "32") is "10". In other words, try avoiding using the binary operators on strings :)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="56382">  <div class="votes">
    <div id="Vu56382">
    <a href="/manual/vote-note.php?id=56382&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd56382">
    <a href="/manual/vote-note.php?id=56382&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V56382" title="75% like this...">
    2
    </div>
  </div>
  <a href="#56382" class="name">
  <strong class="user"><em>Eric Swanson</em></strong></a><a class="genanchor" href="#56382"> &para;</a><div class="date" title="2005-08-31 05:19"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom56382">
<div class="phpcode"><code><span class="html">
Perl vs. PHP implementation of the ^ operator:<br /><br />After attempting to translate a Perl module into PHP, I realized that Perl's implementation of the ^ operator is different than the PHP implementation.&nbsp; By default, Perl treats the variables as floats and PHP as integers.&nbsp; I was able to verify the PHP use of the operator by stating "use integer;" within the Perl module, which output the exact same result as PHP was using.<br /><br />The logical decision would be to cast every variable as (float) when using the ^ operator in PHP.&nbsp; However, this will not yield the same results.&nbsp; After about a half hour of banging my head against the wall, I discovered a gem and wrote a function using the binary-decimal conversions in PHP.<br /><br />/*<br />not having much experience with bitwise operations, I cannot tell you that this is the BEST solution, but it certainly is a solution that finally works and always returns the EXACT same result Perl provides.<br />*/<br />function binxor($a, $b) {<br />&nbsp; &nbsp; return bindec(decbin((float)$a ^ (float)$b));<br />}<br /><br />//normal PHP code will not yeild the same result as Perl<br />$result = 3851235679 ^ 43814; //= -443704711<br /><br />//to get the same result as Perl<br />$result = binxor(3851235679, 43814); //= 3851262585<br />//YIPPEE!!!<br /><br />//to see the differences, try the following<br />$a = 3851235679 XOR 43814;<br />$b = 3851235679 ^ 43814; //integer result<br />$c = (float)3851235679 ^ (float)43814; //same as $b<br />$d = binxor(3851235679, 43814); //same as Perl!!<br /><br />echo("A: $a&lt;br /&gt;");<br />echo("B: $b&lt;br /&gt;");<br />echo("C: $c&lt;br /&gt;");<br />echo("D: $d&lt;br /&gt;");</span>
</code></div>
  </div>
 </div>
  <div class="note" id="72300">  <div class="votes">
    <div id="Vu72300">
    <a href="/manual/vote-note.php?id=72300&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd72300">
    <a href="/manual/vote-note.php?id=72300&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V72300" title="72% like this...">
    5
    </div>
  </div>
  <a href="#72300" class="name">
  <strong class="user"><em>zewt at hotmail dot com</em></strong></a><a class="genanchor" href="#72300"> &para;</a><div class="date" title="2007-01-11 11:28"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom72300">
<div class="phpcode"><code><span class="html">
if you use bitwise you MUST make sure your variables are integers, otherwise you can get incorrect results.<br /><br />I recommend ALWAYS<br /><br />(int)$var &amp; (int)$var2<br /><br />This will save you many headaches when troubleshooting a completely illogical result.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="90310">  <div class="votes">
    <div id="Vu90310">
    <a href="/manual/vote-note.php?id=90310&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd90310">
    <a href="/manual/vote-note.php?id=90310&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V90310" title="71% like this...">
    3
    </div>
  </div>
  <a href="#90310" class="name">
  <strong class="user"><em>cw3theophilus at gmail dot com</em></strong></a><a class="genanchor" href="#90310"> &para;</a><div class="date" title="2009-04-15 02:22"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom90310">
<div class="phpcode"><code><span class="html">
For those who are looking for a circular bit shift function in PHP (especially useful for cryptographic functions) that works with negtive values, here is a little function I wrote:<br /><br />(Note: It took me almost a whole day to get this to work with negative $num values (I couldn't figure out why it sometimes worked and other times didn't), because PHP only has an arithmatic and not a logical bitwise right shift like I am used to. I.e. 0x80000001&gt;&gt;16 will ouputs (in binary) "1111 1111 1111 1111 1000 0000 0000 0000" instead of "0000 0000 0000 0000 1000 0000 0000 0000" like you would expect. To fix this you have to apply the mask (by bitwise &amp;) equal to 0x7FFFFFFF right shifted one less than the offset you are shifting by.)<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">circular_shift</span><span class="keyword">(</span><span class="default">$num</span><span class="keyword">,</span><span class="default">$offset</span><span class="keyword">) { </span><span class="comment">//Do a nondestructive circular bitwise shift, if offset positive shift left, if negative shift right<br />&nbsp; &nbsp; </span><span class="default">$num</span><span class="keyword">=(int)</span><span class="default">$num</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$mask</span><span class="keyword">=</span><span class="default">0x7fffffff</span><span class="keyword">; </span><span class="comment">//Mask to cater for the fact that PHP only does arithmatic right shifts and not logical i.e. PHP doesn't give expected output when right shifting negative values<br />&nbsp; &nbsp; </span><span class="keyword">if (</span><span class="default">$offset</span><span class="keyword">&gt;</span><span class="default">0</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$num</span><span class="keyword">=(</span><span class="default">$num</span><span class="keyword">&lt;&lt;</span><span class="default">$offset</span><span class="keyword">%</span><span class="default">32</span><span class="keyword">) | ((</span><span class="default">$num</span><span class="keyword">&gt;&gt;(</span><span class="default">32</span><span class="keyword">-</span><span class="default">$offset</span><span class="keyword">%</span><span class="default">32</span><span class="keyword">)) &amp; (</span><span class="default">$mask</span><span class="keyword">&gt;&gt;(</span><span class="default">31</span><span class="keyword">-</span><span class="default">$offset</span><span class="keyword">%</span><span class="default">32</span><span class="keyword">)));<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; elseif (</span><span class="default">$offset</span><span class="keyword">&lt;</span><span class="default">0</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$offset</span><span class="keyword">=</span><span class="default">abs</span><span class="keyword">(</span><span class="default">$offset</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$num</span><span class="keyword">=((</span><span class="default">$num</span><span class="keyword">&gt;&gt;</span><span class="default">$offset</span><span class="keyword">%</span><span class="default">32</span><span class="keyword">) &amp; (</span><span class="default">$mask</span><span class="keyword">&gt;&gt;(-</span><span class="default">1</span><span class="keyword">+</span><span class="default">$offset</span><span class="keyword">%</span><span class="default">32</span><span class="keyword">))) | (</span><span class="default">$num</span><span class="keyword">&lt;&lt;(</span><span class="default">32</span><span class="keyword">-</span><span class="default">$offset</span><span class="keyword">%</span><span class="default">32</span><span class="keyword">));<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; return </span><span class="default">$num</span><span class="keyword">; <br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="109792">  <div class="votes">
    <div id="Vu109792">
    <a href="/manual/vote-note.php?id=109792&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd109792">
    <a href="/manual/vote-note.php?id=109792&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V109792" title="66% like this...">
    5
    </div>
  </div>
  <a href="#109792" class="name">
  <strong class="user"><em>frankemeks77 at yahoo dot com</em></strong></a><a class="genanchor" href="#109792"> &para;</a><div class="date" title="2012-08-21 01:24"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom109792">
<div class="phpcode"><code><span class="html">
Just learning Bitwise Shift Operators.<br /><br />The easiest way to resolve a bitwise&nbsp; shift operators is my multiply or dividing each step by two for left shift or right shift respectively<br /><br />Example:<br /><br />LEFT SHIFT<br /><span class="default">&lt;?php </span><span class="keyword">echo </span><span class="default">8 </span><span class="keyword">&lt;&lt; </span><span class="default">3</span><span class="keyword">; </span><span class="comment">//64 </span><span class="default">?&gt;<br /></span><br />//same as<br /><span class="default">&lt;?php </span><span class="keyword">echo </span><span class="default">8 </span><span class="keyword">* </span><span class="default">2 </span><span class="keyword">* </span><span class="default">2 </span><span class="keyword">* </span><span class="default">2</span><span class="keyword">; </span><span class="default">?&gt;<br /></span><br />RIGHT SHIFT<br /><span class="default">&lt;?php </span><span class="keyword">echo </span><span class="default">8 </span><span class="keyword">&gt;&gt; </span><span class="default">3</span><span class="keyword">; </span><span class="comment">//1 </span><span class="default">?&gt;<br /></span><br />//same as<br /><span class="default">&lt;?php </span><span class="keyword">echo ((</span><span class="default">8</span><span class="keyword">/</span><span class="default">2</span><span class="keyword">)/</span><span class="default">2</span><span class="keyword">)/</span><span class="default">2</span><span class="keyword">; </span><span class="comment">//1 </span><span class="default">?&gt;<br /></span><br />//Solving on a paper 8/2 = 4/2 = 2/2 = 1</span>
</code></div>
  </div>
 </div>
  <div class="note" id="105370">  <div class="votes">
    <div id="Vu105370">
    <a href="/manual/vote-note.php?id=105370&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd105370">
    <a href="/manual/vote-note.php?id=105370&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V105370" title="66% like this...">
    4
    </div>
  </div>
  <a href="#105370" class="name">
  <strong class="user"><em>aba at example dot com</em></strong></a><a class="genanchor" href="#105370"> &para;</a><div class="date" title="2011-08-12 05:07"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom105370">
<div class="phpcode"><code><span class="html">
It is true that if both the left-hand and right-hand parameters are strings, the bitwise operator will operate on the characters' ASCII values. However, a complement is necessary to complete this sentence.<br />It is not irrelevant to point out that the decimal character's ASCII value have different binary values.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">if ((</span><span class="string">'18' </span><span class="keyword">&amp; </span><span class="string">'32'</span><span class="keyword">) == </span><span class="string">'10'</span><span class="keyword">) {<br />&nbsp; &nbsp; echo </span><span class="default">ord</span><span class="keyword">(</span><span class="string">'18'</span><span class="keyword">); </span><span class="comment">//return decimal value 49, which have binary value 110001<br />&nbsp; &nbsp; </span><span class="keyword">echo </span><span class="default">ord</span><span class="keyword">(</span><span class="string">'32'</span><span class="keyword">); </span><span class="comment">//return decimal value 51, which have binary value 110011<br />&nbsp; &nbsp; </span><span class="keyword">echo </span><span class="default">ord</span><span class="keyword">(</span><span class="string">'10'</span><span class="keyword">); </span><span class="comment">//return decimal value 49, which have binary value 110001<br />&nbsp; &nbsp; //Therefore 110001 &amp; 110011 = 110001<br /></span><span class="keyword">}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="110846">  <div class="votes">
    <div id="Vu110846">
    <a href="/manual/vote-note.php?id=110846&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd110846">
    <a href="/manual/vote-note.php?id=110846&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V110846" title="66% like this...">
    2
    </div>
  </div>
  <a href="#110846" class="name">
  <strong class="user"><em>erich at seachawaii dot com</em></strong></a><a class="genanchor" href="#110846"> &para;</a><div class="date" title="2012-12-14 03:15"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom110846">
<div class="phpcode"><code><span class="html">
Just a note regarding negative shift values, as the documentation states each shift is an integer multiply or divide (left or right respectively) by 2.&nbsp; That means a negative shift value (the right hand operand) effects the sign of the shift and NOT the direction of the shift as I would have expected.&nbsp; <br />FE. 0xff &gt;&gt; -2 results in 0x0 <br />and 0xff &lt;&lt; -2 result in 0xFFFFFFFFC0000000 (dependant on PHP_INT_MAX)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="115365">  <div class="votes">
    <div id="Vu115365">
    <a href="/manual/vote-note.php?id=115365&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115365">
    <a href="/manual/vote-note.php?id=115365&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115365" title="66% like this...">
    1
    </div>
  </div>
  <a href="#115365" class="name">
  <strong class="user"><em>J. Ketting</em></strong></a><a class="genanchor" href="#115365"> &para;</a><div class="date" title="2014-07-12 09:39"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115365">
<div class="phpcode"><code><span class="html">
@zooly<br /><br />Don't forget the leading zeros.<br />It's very important if you want to write a function similar to the assembly instructions 'ror' and 'rol' (Rotate on Right and Rotate on Left), because of dword value; rotating the binary always takes 32 positions and includes the leading zeros!<br />So this is the right way:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">rotate </span><span class="keyword">(</span><span class="default">$decimal</span><span class="keyword">, </span><span class="default">$bits</span><span class="keyword">) {<br /><br />&nbsp; </span><span class="default">$binary </span><span class="keyword">= </span><span class="default">decbin</span><span class="keyword">(</span><span class="default">$decimal</span><span class="keyword">);<br />&nbsp; </span><span class="default">$binary </span><span class="keyword">= </span><span class="default">str_pad</span><span class="keyword">(</span><span class="default">$binary</span><span class="keyword">, </span><span class="default">32</span><span class="keyword">, </span><span class="string">'0'</span><span class="keyword">, </span><span class="default">STR_PAD_LEFT</span><span class="keyword">);<br />&nbsp; return (<br />&nbsp; &nbsp; </span><span class="default">bindec</span><span class="keyword">(</span><span class="default">substr</span><span class="keyword">(</span><span class="default">$binary</span><span class="keyword">, </span><span class="default">$bits</span><span class="keyword">).</span><span class="default">substr</span><span class="keyword">(</span><span class="default">$binary</span><span class="keyword">, </span><span class="default">0</span><span class="keyword">, </span><span class="default">$bits</span><span class="keyword">))<br />&nbsp; );<br /><br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />Look at this assembly code:<br /><br />mov edx, 1bf5616c<br />ror edx, 8<br /><br />After this operation: edx = 0x6c1bf561 (binary: 1101100000110111111010101100001)<br />But your code returns 0x0d9bf561 (binary: 1101100110111111010101100001)<br />In order to get the right value you have to add the leading zeros by adding that line with strpad() (see above). Very important!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="105821">  <div class="votes">
    <div id="Vu105821">
    <a href="/manual/vote-note.php?id=105821&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd105821">
    <a href="/manual/vote-note.php?id=105821&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V105821" title="64% like this...">
    4
    </div>
  </div>
  <a href="#105821" class="name">
  <strong class="user"><em>spencer-p-moy at example dot com</em></strong></a><a class="genanchor" href="#105821"> &para;</a><div class="date" title="2011-09-17 06:21"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom105821">
<div class="phpcode"><code><span class="html">
The NOT or complement operator ( ~ ) and negative binary numbers can be confusing.<br /><br />~2 = -3&nbsp; because you use the formula&nbsp; ~x = -x - 1&nbsp; The bitwise complement of a decimal number is the negation of the number minus 1.<br /><br />NOTE: just using 4 bits here for the examples below but in reality PHP uses 32 bits.<br /><br />Converting a negative decimal number (ie: -3) into binary takes 3 steps:<br />1) convert the positive version of the decimal number into binary (ie: 3 = 0011)<br />2) flips the bits (ie: 0011 becomes 1100)<br />3) add 1 (ie: 1100&nbsp; + 0001 = 1101)<br /><br />You might be wondering how does 1101 = -3. Well PHP uses the method "2's complement" to render negative binary numbers. If the left most bit is a 1 then the binary number is negative and you flip the bits and add 1. If it is 0 then it is positive and you don't have to do anything. So 0010 would be a positive 2. If it is 1101, it is negative and you flip the bits to get 0010. Add 1 and you get 0011 which equals -3.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="112699">  <div class="votes">
    <div id="Vu112699">
    <a href="/manual/vote-note.php?id=112699&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd112699">
    <a href="/manual/vote-note.php?id=112699&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V112699" title="62% like this...">
    2
    </div>
  </div>
  <a href="#112699" class="name">
  <strong class="user"><em>sag at ich dot net</em></strong></a><a class="genanchor" href="#112699"> &para;</a><div class="date" title="2013-07-14 06:52"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom112699">
<div class="phpcode"><code><span class="html">
me reimplement for bitwise NOT (~)<br /><br />&nbsp; &nbsp; protected function flipBin($number) {<br />&nbsp; &nbsp; &nbsp; &nbsp; $bin = str_pad(base_convert($number, 10, 2), 32, 0, STR_PAD_LEFT);<br />&nbsp; &nbsp; &nbsp; &nbsp; for ($i = 0; $i &lt; 32; $i++) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; switch ($bin{$i}) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case '0' :<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $bin{$i} = '1';<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case '1' :<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $bin{$i} = '0';<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; return bindec($bin);<br />&nbsp; &nbsp; }<br /><br />the benefit is, it works with numbers greater MAX_INT</span>
</code></div>
  </div>
 </div>
  <div class="note" id="57281">  <div class="votes">
    <div id="Vu57281">
    <a href="/manual/vote-note.php?id=57281&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd57281">
    <a href="/manual/vote-note.php?id=57281&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V57281" title="62% like this...">
    2
    </div>
  </div>
  <a href="#57281" class="name">
  <strong class="user"><em>Tbrendstrup</em></strong></a><a class="genanchor" href="#57281"> &para;</a><div class="date" title="2005-09-29 05:23"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom57281">
<div class="phpcode"><code><span class="html">
note that the shift operators are arithmetic, not logic like in C. You may get unexpected results with negative numbers, see <a href="http://en.wikipedia.org/wiki/Bitwise_operation" rel="nofollow" target="_blank">http://en.wikipedia.org/wiki/Bitwise_operation</a><br /><br />here's a function to do logic right shifts.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">lshiftright</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">,</span><span class="default">$amt</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="default">$mask </span><span class="keyword">= </span><span class="default">0x40000000</span><span class="keyword">;<br />&nbsp; &nbsp; if(</span><span class="default">$var </span><span class="keyword">&lt; </span><span class="default">0</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$var </span><span class="keyword">&amp;= </span><span class="default">0x7FFFFFFF</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$mask </span><span class="keyword">= </span><span class="default">$mask </span><span class="keyword">&gt;&gt; (</span><span class="default">$amt</span><span class="keyword">-</span><span class="default">1</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; return (</span><span class="default">$var </span><span class="keyword">&gt;&gt; </span><span class="default">$amt</span><span class="keyword">) | </span><span class="default">$mask</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; return </span><span class="default">$var </span><span class="keyword">&gt;&gt; </span><span class="default">$amt</span><span class="keyword">;<br />}<br /><br /></span><span class="default">$val </span><span class="keyword">= -</span><span class="default">10</span><span class="keyword">;<br /><br /></span><span class="default">printf</span><span class="keyword">(</span><span class="string">"arithmetic shift on a negative integer&lt;br&gt;%1\$032b&lt;br&gt;%2\$032b&lt;br&gt;%1\$0d&lt;br&gt;%2\$0d&lt;br&gt;"</span><span class="keyword">,</span><span class="default">$val</span><span class="keyword">, </span><span class="default">$val </span><span class="keyword">&gt;&gt; </span><span class="default">1 </span><span class="keyword">);<br /><br /></span><span class="default">printf</span><span class="keyword">(</span><span class="string">"logic shift on a negative integer&lt;br&gt;%1\$032b&lt;br&gt;%2\$032b&lt;br&gt;%1\$0d&lt;br&gt;%2\$0d&lt;br&gt;"</span><span class="keyword">,</span><span class="default">$val</span><span class="keyword">, </span><span class="default">lshiftright</span><span class="keyword">(</span><span class="default">$val</span><span class="keyword">, </span><span class="default">1</span><span class="keyword">));<br /><br /></span><span class="default">printf</span><span class="keyword">(</span><span class="string">"logic shift on a positive integer&lt;br&gt;%1\$032b&lt;br&gt;%2\$032b&lt;br&gt;%1\$0d&lt;br&gt;%2\$0d&lt;br&gt;"</span><span class="keyword">,-</span><span class="default">$val</span><span class="keyword">, </span><span class="default">lshiftright</span><span class="keyword">(-</span><span class="default">$val</span><span class="keyword">, </span><span class="default">1</span><span class="keyword">));<br /></span><span class="default">?&gt;<br /></span><br />gives the output:<br /><br />arithmetic shift on a negative integer<br />11111111111111111111111111110110<br />11111111111111111111111111111011<br />-10<br />-5<br /><br />logic shift on a negative integer<br />11111111111111111111111111110110<br />01111111111111111111111111111011<br />-10<br />2147483643<br /><br />logic shift on a positive integer<br />00000000000000000000000000001010<br />00000000000000000000000000000101<br />10<br />5</span>
</code></div>
  </div>
 </div>
  <div class="note" id="99335">  <div class="votes">
    <div id="Vu99335">
    <a href="/manual/vote-note.php?id=99335&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd99335">
    <a href="/manual/vote-note.php?id=99335&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V99335" title="57% like this...">
    1
    </div>
  </div>
  <a href="#99335" class="name">
  <strong class="user"><em>Core Xii</em></strong></a><a class="genanchor" href="#99335"> &para;</a><div class="date" title="2010-08-11 10:24"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom99335">
<div class="phpcode"><code><span class="html">
Be very careful when XOR-ing strings! If one of the values is empty (0, '', null) the result will also be empty!<br /><br /><span class="default">&lt;?php<br />var_dump</span><span class="keyword">(</span><span class="default">1234 </span><span class="keyword">^ </span><span class="default">0</span><span class="keyword">); </span><span class="comment">// int(1234)<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">1234 </span><span class="keyword">^ </span><span class="string">''</span><span class="keyword">); </span><span class="comment">// int(1234)<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">1234 </span><span class="keyword">^ </span><span class="default">null</span><span class="keyword">); </span><span class="comment">// int(1234)<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="string">'hello world' </span><span class="keyword">^ </span><span class="default">0</span><span class="keyword">); </span><span class="comment">// int(0)<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="string">'hello world' </span><span class="keyword">^ </span><span class="string">''</span><span class="keyword">); </span><span class="comment">// string(0) ""<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="string">'hello world' </span><span class="keyword">^ </span><span class="default">null</span><span class="keyword">); </span><span class="comment">// int(0)<br /></span><span class="default">?&gt;<br /></span><br />This seems rather inconsistent behavior. An integer XOR'd with zero results the original integer. But a string XOR'd with an empty value results an empty value!<br /><br />My password hashing function was always returning the same hash... Because I was XOR-ing it with a salt that was sometimes empty!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="97917">  <div class="votes">
    <div id="Vu97917">
    <a href="/manual/vote-note.php?id=97917&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd97917">
    <a href="/manual/vote-note.php?id=97917&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V97917" title="55% like this...">
    1
    </div>
  </div>
  <a href="#97917" class="name">
  <strong class="user"><em>Adam</em></strong></a><a class="genanchor" href="#97917"> &para;</a><div class="date" title="2010-05-15 01:25"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom97917">
<div class="phpcode"><code><span class="html">
Be careful of order of operations.<br /><br />for example, you may want to check if the second bit is set:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">if (</span><span class="default">$x </span><span class="keyword">&amp; </span><span class="default">2 </span><span class="keyword">== </span><span class="default">2</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="comment">/* code */<br /></span><span class="keyword">}<br /></span><span class="default">?&gt;<br /></span><br />is different than<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">if ((</span><span class="default">$x </span><span class="keyword">&amp; </span><span class="default">2</span><span class="keyword">) == </span><span class="default">2</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="comment">/* code */<br /></span><span class="keyword">}<br /></span><span class="default">?&gt;<br /></span><br />and the latter of the two should be used.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="106123">  <div class="votes">
    <div id="Vu106123">
    <a href="/manual/vote-note.php?id=106123&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd106123">
    <a href="/manual/vote-note.php?id=106123&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V106123" title="54% like this...">
    1
    </div>
  </div>
  <a href="#106123" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#106123"> &para;</a><div class="date" title="2011-10-12 07:56"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom106123">
<div class="phpcode"><code><span class="html">
To make very clear why ("18" &amp; "32") is "10".<br />1) they they are both strings ,<br />2) "&amp;" operator works on strings by taking each !Character! from each string and make a bit wise &amp; between them and add this value to the resulting string<br /><br />So:<br />"18" is made up of two characters: 0x31, 0x38<br />"32" is made up of two characters: 0x33, 0x32<br />----RESULT-----<br />0x31 &amp; 0x33 = 0x31 =&gt; "1"<br />0x38 &amp; 0x32 = 0x30 =&gt; "0"<br /><br />and the result is "10" which is 100% correct.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118164">  <div class="votes">
    <div id="Vu118164">
    <a href="/manual/vote-note.php?id=118164&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118164">
    <a href="/manual/vote-note.php?id=118164&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118164" title="50% like this...">
    0
    </div>
  </div>
  <a href="#118164" class="name">
  <strong class="user"><em>luis at rosety dot com</em></strong></a><a class="genanchor" href="#118164"> &para;</a><div class="date" title="2015-10-18 02:05"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom118164">
<div class="phpcode"><code><span class="html">
Example of function using bitwise operations for converting hexadecimal color (usually given as 6 hexadecimal digit string, into separated RGB integers)<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">hex2rgb</span><span class="keyword">(</span><span class="default">$hex</span><span class="keyword">){<br /><br />&nbsp; &nbsp; </span><span class="default">$dec </span><span class="keyword">= </span><span class="default">hexdec</span><span class="keyword">(</span><span class="default">$hexcolor</span><span class="keyword">);&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="comment">// $hex string to decimal value<br />&nbsp; &nbsp; </span><span class="default">$r </span><span class="keyword">= </span><span class="default">$dec </span><span class="keyword">&amp; </span><span class="default">hexdec</span><span class="keyword">(</span><span class="string">'FF0000'</span><span class="keyword">);&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//Mask for red<br />&nbsp; &nbsp; </span><span class="default">$g </span><span class="keyword">= </span><span class="default">$dec </span><span class="keyword">&amp; </span><span class="default">hexdec</span><span class="keyword">(</span><span class="string">'00FF00'</span><span class="keyword">);&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="comment">//Mask for green<br />&nbsp; &nbsp; </span><span class="default">$b </span><span class="keyword">= </span><span class="default">$dec </span><span class="keyword">&amp; </span><span class="default">hexdec</span><span class="keyword">(</span><span class="string">'0000FF'</span><span class="keyword">);&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="comment">//Mask for blue<br /><br />&nbsp; &nbsp; </span><span class="keyword">return array(</span><span class="default">$r</span><span class="keyword">&gt;&gt;</span><span class="default">16</span><span class="keyword">, </span><span class="default">$g</span><span class="keyword">&gt;&gt;</span><span class="default">8</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">);&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="comment">// Shift full right each color from its original position <br /></span><span class="keyword">}<br /></span><span class="default">?&gt;<br /></span><br />Example of use<br /><br /><span class="default">&lt;?php<br />$rgb </span><span class="keyword">= </span><span class="default">hex2rgb</span><span class="keyword">(</span><span class="string">'112233'</span><span class="keyword">);<br />echo </span><span class="string">"red: "</span><span class="keyword">.</span><span class="default">$rgb</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">].</span><span class="string">"\n"</span><span class="keyword">;<br />echo </span><span class="string">"green: "</span><span class="keyword">.</span><span class="default">$rgb</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">].</span><span class="string">"\n"</span><span class="keyword">;<br />echo </span><span class="string">"blue: "</span><span class="keyword">.</span><span class="default">$rgb</span><span class="keyword">[</span><span class="default">2</span><span class="keyword">].</span><span class="string">"\n"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />Would produce:<br /><br />red: 17&nbsp; &nbsp; &nbsp; &nbsp; <br />green: 34<br />blue: 51<br /><br />Since:<br />dechex(17) = '#11'<br />dechex(34) = '#22'<br />dechex(51) = '#33'</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118674">  <div class="votes">
    <div id="Vu118674">
    <a href="/manual/vote-note.php?id=118674&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118674">
    <a href="/manual/vote-note.php?id=118674&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118674" title="0% like this...">
    -1
    </div>
  </div>
  <a href="#118674" class="name">
  <strong class="user"><em>joey</em></strong></a><a class="genanchor" href="#118674"> &para;</a><div class="date" title="2016-01-18 09:05"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom118674">
<div class="phpcode"><code><span class="html">
If you want a quick one liner for reversing binary and performance/sanity isn't an issue:<br /><br />&nbsp; &nbsp; function reverse_bits($n) {<br />&nbsp; &nbsp; &nbsp; &nbsp; return (int)base_convert(strrev(str_pad(base_convert($n, 10, 2), PHP_INT_SIZE * 8, 0, STR_PAD_LEFT)), 2, 10);<br />&nbsp; &nbsp; }<br /><br />Expect it to behave strangely for the signed bit. Best to use for &lt; PHP_INT_SIZE * 8 to avoid peculiarity. You can also skip the cast if you don't mind keeping your number as a string. base convert appears to work for large precision or perhaps arbitrary but be prepared for strangeness (double, mixed types, precision loss, etc) if you need to work on the revolting number.<br /><br />Use at your own peril.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="99589">  <div class="votes">
    <div id="Vu99589">
    <a href="/manual/vote-note.php?id=99589&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd99589">
    <a href="/manual/vote-note.php?id=99589&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V99589" title="50% like this...">
    0
    </div>
  </div>
  <a href="#99589" class="name">
  <strong class="user"><em>amckenzie4 at gmail dot com</em></strong></a><a class="genanchor" href="#99589"> &para;</a><div class="date" title="2010-08-25 08:19"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom99589">
<div class="phpcode"><code><span class="html">
If, like me, you've never thought about how PHP deals with binary, the output of the bitwise NOT may confuse you.&nbsp; For instance, this:<br /><br />$bin = 2;<br />$notbin = ~$bin;<br /><br />echo "Bin: " . decbin($bin) . "&nbsp; !bin:&nbsp; " . decbin($notbin) . "\n";<br /><br />returns this:<br /><br />Bin: 10&nbsp; !bin:&nbsp; 1111111111111111111111111111111111111111111111111111111111111101<br /><br />The reason is that all binary numbers are treated as 32 bits, even if you've manually entered less.&nbsp; In order to get the result I expected (01), it was necessary to AND the result with the number of bits I wanted:&nbsp; in this case, 2 (the number 3, in decimal).&nbsp; Be aware that all return values will have zeros removed from the left until they reach a bit that is set to 1.&nbsp; Continuing the above example, the following:<br /><br />$notbin_2 = ~$bin &amp; '3';<br />echo "!bin &amp; 3:&nbsp; " . decbin($notbin_2) . "\n";<br /><br />returns this:<br /><br />!bin &amp; 3:&nbsp; 1<br /><br />Note that the actual value was a string of 31 zeros followed by a 1, but the zeros were not shown.&nbsp; This is probably a good thing.<br /><br />Furthermore, the NOT operator uses two's complement, which means the number you get may be even stranger than you expect:&nbsp; using two's complement means that ~2 == -3.&nbsp; There are plenty of good explanations of two's complement online, so I won't go into that question here.<br /><br />If what you want is just to reverse a string of bits without any interpretation, you can use a function like this:<br /><br />function bitnot($bin)<br /> {<br />&nbsp;&nbsp; $not = "";<br />&nbsp;&nbsp; for ($i = 0; $i &lt; strlen($bin); $i++)<br />&nbsp;&nbsp; {<br />&nbsp; &nbsp; &nbsp; if($bin[$i] == 0) { $not .= '1'; }<br />&nbsp; &nbsp; &nbsp; if($bin[$i] == 1) { $not .= '0'; }<br />&nbsp;&nbsp; }<br />&nbsp;&nbsp; return $not;<br /> }<br /><br />It takes a binary string of any length, reverses the bits, and returns the new string.&nbsp; You can then treat it as a binary number, use bindec() to turn it into a decimal, or whatever you want.<br /><br />I hope this helps someone as much as it would have helped me a week ago!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="82344">  <div class="votes">
    <div id="Vu82344">
    <a href="/manual/vote-note.php?id=82344&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd82344">
    <a href="/manual/vote-note.php?id=82344&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V82344" title="50% like this...">
    0
    </div>
  </div>
  <a href="#82344" class="name">
  <strong class="user"><em>bartbons at debster.nl</em></strong></a><a class="genanchor" href="#82344"> &para;</a><div class="date" title="2008-04-07 02:27"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom82344">
<div class="phpcode"><code><span class="html">
@kendsnyder at gmail dot com<br /><br />Thanx for your great function. But your function is not 100% correct. It should be:<br /><br />function safeBitCheck($number,$comparison) {<br />&nbsp; &nbsp; if( $number &lt; 2147483647 ) {<br />&nbsp; &nbsp; &nbsp; &nbsp; return ($number &amp; $comparison)==$comparison;&nbsp;&nbsp; <br />&nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; $binNumber = strrev(base_convert($number,10,2));<br />&nbsp; &nbsp; &nbsp; &nbsp; $binComparison = strrev(base_convert($comparison,10,2));<br />&nbsp; &nbsp; &nbsp; &nbsp; for( $i=0; $i&lt;strlen($binComparison); $i++ ) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if( strlen($binNumber) - 1 &lt;$i || ($binComparison{$i}==="1" &amp;&amp; $binNumber{$i}==="0") ) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return false;&nbsp;&nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; return true;<br />&nbsp; &nbsp; }<br />}<br /><br />Mind the 'minus 1' on "if( strlen($binNumber) - 1 &lt;$i".<br /><br />cheers, Bart</span>
</code></div>
  </div>
 </div>
  <div class="note" id="79662">  <div class="votes">
    <div id="Vu79662">
    <a href="/manual/vote-note.php?id=79662&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd79662">
    <a href="/manual/vote-note.php?id=79662&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V79662" title="50% like this...">
    0
    </div>
  </div>
  <a href="#79662" class="name">
  <strong class="user"><em>forlamp at msn dot com</em></strong></a><a class="genanchor" href="#79662"> &para;</a><div class="date" title="2007-12-06 06:35"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom79662">
<div class="phpcode"><code><span class="html">
two's complement logical operation for 32-bit.<br /><br />$x must be (int) when passing it to this function to work properly.<br /><br />function comp2($x)&nbsp; &nbsp; &nbsp; // 32bit bitwise complement<br />{<br />&nbsp; &nbsp; $mask = 0x80000000;<br /><br />&nbsp; &nbsp; if ($x &lt; 0)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; $x &amp;= 0x7FFFFFFF;<br />&nbsp; &nbsp; &nbsp; &nbsp; $x = ~$x;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; return $x ^ $mask;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; else<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; $x = $x ^ 0x7FFFFFFF;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; return $x | $mask;<br />&nbsp; &nbsp; }<br />}</span>
</code></div>
  </div>
 </div>
  <div class="note" id="73088">  <div class="votes">
    <div id="Vu73088">
    <a href="/manual/vote-note.php?id=73088&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd73088">
    <a href="/manual/vote-note.php?id=73088&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V73088" title="50% like this...">
    0
    </div>
  </div>
  <a href="#73088" class="name">
  <strong class="user"><em>bryanagee at gmail dot com</em></strong></a><a class="genanchor" href="#73088"> &para;</a><div class="date" title="2007-02-08 11:19"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom73088">
<div class="phpcode"><code><span class="html">
I found the 31-bit limitation on the bitwise ands to be a bit frustrating in large scale permission control applications. I have a situation involving page-level access with more than 50 pages. I was able to workaround the limitation by adding a loop that dropped 31 bits off of the right until the resource identifier bit is within the first 31. <br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; &nbsp; &nbsp; $userlevel </span><span class="keyword">= </span><span class="default">$session</span><span class="keyword">-&gt;</span><span class="default">userlevel </span><span class="keyword">- </span><span class="default">0</span><span class="keyword">;&nbsp; </span><span class="comment"># the subtraction ensures int type <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$pg_code </span><span class="keyword">= </span><span class="default">pow</span><span class="keyword">(</span><span class="default">2</span><span class="keyword">,(</span><span class="default">$pg_id</span><span class="keyword">-</span><span class="default">1</span><span class="keyword">)); <br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; while (</span><span class="default">$pg_code </span><span class="keyword">&gt;= </span><span class="default">2147483648</span><span class="keyword">)&nbsp; { <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$pg_code </span><span class="keyword">=&nbsp; </span><span class="default">$pg_code</span><span class="keyword">/</span><span class="default">pow</span><span class="keyword">(</span><span class="default">2</span><span class="keyword">,</span><span class="default">31</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$userlevel </span><span class="keyword">= </span><span class="default">$session</span><span class="keyword">-&gt;</span><span class="default">userlevel</span><span class="keyword">/</span><span class="default">pow</span><span class="keyword">(</span><span class="default">2</span><span class="keyword">,</span><span class="default">31</span><span class="keyword">) ;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; if (!(</span><span class="default">$userlevel </span><span class="keyword">- </span><span class="default">0 </span><span class="keyword">&amp; </span><span class="default">$pg_code</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">#if not authorized, show the unauthorized page<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">'Location: Unauthorized.php'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; exit;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="61478">  <div class="votes">
    <div id="Vu61478">
    <a href="/manual/vote-note.php?id=61478&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd61478">
    <a href="/manual/vote-note.php?id=61478&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V61478" title="50% like this...">
    0
    </div>
  </div>
  <a href="#61478" class="name">
  <strong class="user"><em>Xavier Daull</em></strong></a><a class="genanchor" href="#61478"> &para;</a><div class="date" title="2006-02-04 01:34"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom61478">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br /><br /></span><span class="comment">// Extract part of a binary data - due to windows system limitations (and this code), bit extracted length($firstbit to $lastbit included) is limited to 31 bits<br /></span><span class="keyword">function </span><span class="default">sub_bindata</span><span class="keyword">(</span><span class="default">$mybindata</span><span class="keyword">, </span><span class="default">$firstbit </span><span class="keyword">= </span><span class="default">7</span><span class="keyword">, </span><span class="default">$lastbit </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">, </span><span class="default">$highestbitfirst </span><span class="keyword">= </span><span class="default">true</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="comment">// 1. Create a bit mask of the right size by triming left and right<br />&nbsp; &nbsp; // 2. select bits by an AND on $mybindata<br />&nbsp; &nbsp; // 3. shift right to get only length needed<br />&nbsp; &nbsp; </span><span class="keyword">if(</span><span class="default">$highestbitfirst</span><span class="keyword">) return (((</span><span class="default">0x7FFFFFFF </span><span class="keyword">&gt;&gt; (</span><span class="default">30</span><span class="keyword">+</span><span class="default">$lastbit</span><span class="keyword">-</span><span class="default">$firstbit</span><span class="keyword">))&lt;&lt;(</span><span class="default">$lastbit</span><span class="keyword">)) &amp; </span><span class="default">$mybindata</span><span class="keyword">) &gt;&gt; (</span><span class="default">$lastbit</span><span class="keyword">);<br />&nbsp; &nbsp; else return (((</span><span class="default">0x7FFFFFFF </span><span class="keyword">&gt;&gt; (</span><span class="default">30</span><span class="keyword">-</span><span class="default">$lastbit</span><span class="keyword">+</span><span class="default">$firstbit</span><span class="keyword">))&lt;&lt;(</span><span class="default">30</span><span class="keyword">-</span><span class="default">$lastbit</span><span class="keyword">)) &amp; </span><span class="default">$mybindata</span><span class="keyword">) &gt;&gt; (</span><span class="default">30</span><span class="keyword">-</span><span class="default">$lastbit</span><span class="keyword">);<br />}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="58272">  <div class="votes">
    <div id="Vu58272">
    <a href="/manual/vote-note.php?id=58272&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd58272">
    <a href="/manual/vote-note.php?id=58272&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V58272" title="50% like this...">
    0
    </div>
  </div>
  <a href="#58272" class="name">
  <strong class="user"><em>Nina Cording</em></strong></a><a class="genanchor" href="#58272"> &para;</a><div class="date" title="2005-10-29 09:50"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom58272">
<div class="phpcode"><code><span class="html">
For those who were searching for a way to actually rotate the bits of a number, here are some little functions I wrote:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">bitRotate32</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">,</span><span class="default">$amount</span><span class="keyword">) {<br />&nbsp; &nbsp; if (</span><span class="default">$amount</span><span class="keyword">&gt;</span><span class="default">0</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$amount </span><span class="keyword">%= </span><span class="default">32</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$value </span><span class="keyword">= (</span><span class="default">$value</span><span class="keyword">&lt;&lt;</span><span class="default">$amount</span><span class="keyword">) | (</span><span class="default">$value</span><span class="keyword">&gt;&gt;(</span><span class="default">32</span><span class="keyword">-</span><span class="default">$amount</span><span class="keyword">));<br />&nbsp; &nbsp; } elseif (</span><span class="default">$amount</span><span class="keyword">&lt;</span><span class="default">0</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$amount </span><span class="keyword">= -</span><span class="default">$amount</span><span class="keyword">%</span><span class="default">32</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$value </span><span class="keyword">= (</span><span class="default">$value</span><span class="keyword">&gt;&gt;</span><span class="default">$amount</span><span class="keyword">) | (</span><span class="default">$value</span><span class="keyword">&lt;&lt;(</span><span class="default">32</span><span class="keyword">-</span><span class="default">$amount</span><span class="keyword">));<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; return </span><span class="default">$value</span><span class="keyword">;<br />}<br /><br />function </span><span class="default">bitRotate</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">,</span><span class="default">$amount</span><span class="keyword">,</span><span class="default">$bits</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$mask </span><span class="keyword">= (</span><span class="default">$bits</span><span class="keyword">&lt;</span><span class="default">32</span><span class="keyword">) ? </span><span class="default">0x7fffffff </span><span class="keyword">&gt;&gt; (</span><span class="default">31</span><span class="keyword">-</span><span class="default">$bits</span><span class="keyword">) : </span><span class="default">0xffffffff</span><span class="keyword">;<br />&nbsp; &nbsp; if (</span><span class="default">$amount</span><span class="keyword">&gt;</span><span class="default">0</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$amount </span><span class="keyword">%= </span><span class="default">$bits</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$value </span><span class="keyword">= (</span><span class="default">$value</span><span class="keyword">&lt;&lt;</span><span class="default">$amount</span><span class="keyword">) | (</span><span class="default">$value</span><span class="keyword">&gt;&gt;(</span><span class="default">$bits</span><span class="keyword">-</span><span class="default">$amount</span><span class="keyword">));<br />&nbsp; &nbsp; } elseif (</span><span class="default">$amount</span><span class="keyword">&lt;</span><span class="default">0</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$amount </span><span class="keyword">= -</span><span class="default">$amount</span><span class="keyword">%</span><span class="default">$bits</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$value </span><span class="keyword">= (</span><span class="default">$value</span><span class="keyword">&gt;&gt;</span><span class="default">$amount</span><span class="keyword">) | (</span><span class="default">$value</span><span class="keyword">&lt;&lt;(</span><span class="default">$bits</span><span class="keyword">-</span><span class="default">$amount</span><span class="keyword">));<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; return </span><span class="default">$value </span><span class="keyword">&amp; </span><span class="default">$mask</span><span class="keyword">;<br />}<br /><br /></span><span class="comment">// test the rotation:<br /><br /></span><span class="default">$test </span><span class="keyword">= </span><span class="default">4123</span><span class="keyword">;<br />for (</span><span class="default">$i</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">&lt;</span><span class="default">64</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">++) {<br />&nbsp; &nbsp; </span><span class="default">$value </span><span class="keyword">= </span><span class="default">bitRotate</span><span class="keyword">(</span><span class="default">$test</span><span class="keyword">,-</span><span class="default">$i</span><span class="keyword">,</span><span class="default">8</span><span class="keyword">); </span><span class="comment">// rotates 8 bits to the left (-$amount)<br />&nbsp; &nbsp; </span><span class="keyword">echo </span><span class="default">sprintf</span><span class="keyword">(</span><span class="string">"%032b&lt;br/&gt;"</span><span class="keyword">,</span><span class="default">$value</span><span class="keyword">);<br />}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="58186">  <div class="votes">
    <div id="Vu58186">
    <a href="/manual/vote-note.php?id=58186&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd58186">
    <a href="/manual/vote-note.php?id=58186&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V58186" title="50% like this...">
    0
    </div>
  </div>
  <a href="#58186" class="name">
  <strong class="user"><em>zlel</em></strong></a><a class="genanchor" href="#58186"> &para;</a><div class="date" title="2005-10-26 05:22"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom58186">
<div class="phpcode"><code><span class="html">
Here're my 32-bit carry-discarding operations for those of you porting encryption algorithms from C.<br /><br />Be warned that some of these are not very efficient compared to the native operations, especially when called by heavy-duty encryption algorithms - but not discarding the carry bit may not land you the same results you get in C, simply because PHP's bitwise operations were not designed to work on fixed-sized registers.<br /><br />(If your ported encryption algo still doen't give you the same results, remember to check your Endian-ness!)<br /><br />function _BF_SHR32 ($x, $bits)<br />{<br />&nbsp; &nbsp; if ($bits==0) return $x;<br />&nbsp; &nbsp; if ($bits==32) return 0;<br />&nbsp; &nbsp; $y = ($x &amp; 0x7FFFFFFF) &gt;&gt; $bits;<br />&nbsp; &nbsp; if (0x80000000 &amp; $x) {<br />&nbsp; &nbsp; &nbsp; &nbsp; $y |= (1&lt;&lt;(31-$bits));&nbsp; &nbsp; <br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; return $y;<br />}<br /><br />function _BF_SHL32 ($x, $bits)<br />{<br />&nbsp; &nbsp; if ($bits==0) return $x;<br />&nbsp; &nbsp; if ($bits==32) return 0;<br />&nbsp; &nbsp; $mask = (1&lt;&lt;(32-$bits)) - 1;<br />&nbsp; &nbsp; return (($x &amp; $mask) &lt;&lt; $bits) &amp; 0xFFFFFFFF;<br />}<br /><br />function _BF_GETBYTE ($x, $y) <br />{<br />&nbsp; &nbsp; return _BF_SHR32 ($x, 8 * $y) &amp; 0xFF;<br />}<br /><br />function _BF_OR32 ($x, $y)<br />{<br />&nbsp; &nbsp; return ($x | $y) &amp; 0xFFFFFFFF;<br />}<br /><br />function _BF_ADD32 ($x, $y)<br />{<br /><br />&nbsp; &nbsp; $x = $x &amp; 0xFFFFFFFF;<br />&nbsp; &nbsp; $y = $y &amp; 0xFFFFFFFF;<br /><br />&nbsp; &nbsp; $total = 0;<br />&nbsp; &nbsp; $carry = 0;<br />&nbsp; &nbsp; for ($i=0; $i&lt;4; $i++) {<br />&nbsp; &nbsp; &nbsp; &nbsp; $byte_x = _BF_GETBYTE($x, $i);<br />&nbsp; &nbsp; &nbsp; &nbsp; $byte_y = _BF_GETBYTE($y, $i);<br />&nbsp; &nbsp; &nbsp; &nbsp; $sum = $byte_x + $byte_y;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; $result = $sum &amp; 0xFF;<br />&nbsp; &nbsp; &nbsp; &nbsp; $carryforward = _BF_SHR32($sum, 8); <br /><br />&nbsp; &nbsp; &nbsp; &nbsp; $sum = $result + $carry;<br />&nbsp; &nbsp; &nbsp; &nbsp; $result = $sum &amp; 0xFF;<br />&nbsp; &nbsp; &nbsp; &nbsp; $carry = $carryforward + _BF_SHR32($sum, 8); <br /><br />&nbsp; &nbsp; &nbsp; &nbsp; $total = _BF_OR32(_BF_SHL32($result, $i*8), $total); <br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; return $total;<br />}</span>
</code></div>
  </div>
 </div>
  <div class="note" id="49231">  <div class="votes">
    <div id="Vu49231">
    <a href="/manual/vote-note.php?id=49231&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd49231">
    <a href="/manual/vote-note.php?id=49231&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V49231" title="50% like this...">
    0
    </div>
  </div>
  <a href="#49231" class="name">
  <strong class="user"><em>louis /at/ mulliemedia.com</em></strong></a><a class="genanchor" href="#49231"> &para;</a><div class="date" title="2005-01-20 02:12"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom49231">
<div class="phpcode"><code><span class="html">
Note that the ^ operator, unlike in some other languages, is *not* the same as the pow() function.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="40107">  <div class="votes">
    <div id="Vu40107">
    <a href="/manual/vote-note.php?id=40107&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd40107">
    <a href="/manual/vote-note.php?id=40107&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V40107" title="50% like this...">
    0
    </div>
  </div>
  <a href="#40107" class="name">
  <strong class="user"><em>richard-slater.co.uk</em></strong></a><a class="genanchor" href="#40107"> &para;</a><div class="date" title="2004-02-22 01:07"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom40107">
<div class="phpcode"><code><span class="html">
For those (like me) who are trying to do bit masking with very large numbers, here is a useful function to do the work for you.<br /><br /><span class="default">&lt;?php<br />&nbsp; </span><span class="keyword">function </span><span class="default">isBitSet</span><span class="keyword">(</span><span class="default">$bitMask</span><span class="keyword">, </span><span class="default">$bitMap</span><span class="keyword">)<br />&nbsp; {<br />&nbsp; &nbsp; return (bool) </span><span class="default">gmp_intval</span><span class="keyword">(</span><span class="default">gmp_div</span><span class="keyword">(</span><span class="default">gmp_and</span><span class="keyword">(</span><span class="default">$bitMask</span><span class="keyword">, </span><span class="default">$bitMap</span><span class="keyword">),</span><span class="default">$bitMask</span><span class="keyword">));<br />&nbsp; }<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="71145">  <div class="votes">
    <div id="Vu71145">
    <a href="/manual/vote-note.php?id=71145&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd71145">
    <a href="/manual/vote-note.php?id=71145&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V71145" title="0% like this...">
    -2
    </div>
  </div>
  <a href="#71145" class="name">
  <strong class="user"><em>rizal dot almashoor at gmail dot com</em></strong></a><a class="genanchor" href="#71145"> &para;</a><div class="date" title="2006-11-13 04:12"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom71145">
<div class="phpcode"><code><span class="html">
The following function will perform a 32-bit left shift on a 64-bit machine:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">leftshift32</span><span class="keyword">(</span><span class="default">$number</span><span class="keyword">, </span><span class="default">$steps</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="default">$binary </span><span class="keyword">= </span><span class="default">decbin</span><span class="keyword">(</span><span class="default">$number</span><span class="keyword">).</span><span class="default">str_repeat</span><span class="keyword">(</span><span class="string">"0"</span><span class="keyword">, </span><span class="default">$steps</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$binary </span><span class="keyword">= </span><span class="default">str_pad</span><span class="keyword">(</span><span class="default">$binary</span><span class="keyword">, </span><span class="default">32</span><span class="keyword">, </span><span class="string">"0"</span><span class="keyword">, </span><span class="default">STR_PAD_LEFT</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$binary </span><span class="keyword">= </span><span class="default">substr</span><span class="keyword">(</span><span class="default">$binary</span><span class="keyword">, </span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$binary</span><span class="keyword">) - </span><span class="default">32</span><span class="keyword">);<br />&nbsp; &nbsp; return </span><span class="default">$binary</span><span class="keyword">{</span><span class="default">0</span><span class="keyword">} == </span><span class="string">"1" </span><span class="keyword">? -(</span><span class="default">pow</span><span class="keyword">(</span><span class="default">2</span><span class="keyword">, </span><span class="default">31</span><span class="keyword">) - </span><span class="default">bindec</span><span class="keyword">(</span><span class="default">substr</span><span class="keyword">(</span><span class="default">$binary</span><span class="keyword">, </span><span class="default">1</span><span class="keyword">))) : </span><span class="default">bindec</span><span class="keyword">(</span><span class="default">$binary</span><span class="keyword">);<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="52032">  <div class="votes">
    <div id="Vu52032">
    <a href="/manual/vote-note.php?id=52032&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd52032">
    <a href="/manual/vote-note.php?id=52032&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V52032" title="45% like this...">
    -1
    </div>
  </div>
  <a href="#52032" class="name">
  <strong class="user"><em></em></strong></a><a class="genanchor" href="#52032"> &para;</a><div class="date" title="2005-04-19 07:28"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom52032">
<div class="phpcode"><code><span class="html">
Another practical case...<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; header</span><span class="keyword">(</span><span class="string">'Content-Type: text/plain'</span><span class="keyword">) ;<br /><br />&nbsp; &nbsp; </span><span class="comment">// We want to know the power-2 based numbers of $x<br />&nbsp; &nbsp; </span><span class="default">$x </span><span class="keyword">= </span><span class="default">9124 </span><span class="keyword">;<br /><br />&nbsp; &nbsp; </span><span class="default">$n </span><span class="keyword">= </span><span class="default">1 </span><span class="keyword">;<br />&nbsp; &nbsp; while ( </span><span class="default">$x </span><span class="keyword">&gt; </span><span class="default">0 </span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if ( </span><span class="default">$x </span><span class="keyword">&amp; </span><span class="default">1 </span><span class="keyword">== </span><span class="default">1 </span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">$n</span><span class="keyword">, </span><span class="string">"\n" </span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$n </span><span class="keyword">*= </span><span class="default">2 </span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$x </span><span class="keyword">&gt;&gt;= </span><span class="default">1 </span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">// Will output...<br />&nbsp; &nbsp; // 4<br />&nbsp; &nbsp; // 32<br />&nbsp; &nbsp; // 128<br />&nbsp; &nbsp; // 256<br />&nbsp; &nbsp; // 512<br />&nbsp; &nbsp; // 8192<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="90514">  <div class="votes">
    <div id="Vu90514">
    <a href="/manual/vote-note.php?id=90514&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd90514">
    <a href="/manual/vote-note.php?id=90514&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V90514" title="33% like this...">
    -1
    </div>
  </div>
  <a href="#90514" class="name">
  <strong class="user"><em>Bob</em></strong></a><a class="genanchor" href="#90514"> &para;</a><div class="date" title="2009-04-26 12:19"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom90514">
<div class="phpcode"><code><span class="html">
Here is an easy way to use bitwise operation for 'flag' functionality.<br />By this I mean managing a set of options which can either be ON or OFF, where zero or more of these options may be set and each option may only be set once. (If you are familiar with MySQL, think 'set' datatype).<br />Note: to older programmers, this will be obvious.<br /><br />Here is the code:<br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">set_bitflag</span><span class="keyword">(</span><span class="comment">/*variable-length args*/</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="default">$val </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />&nbsp; &nbsp; foreach(</span><span class="default">func_get_args</span><span class="keyword">() as </span><span class="default">$flag</span><span class="keyword">) </span><span class="default">$val </span><span class="keyword">= </span><span class="default">$val </span><span class="keyword">| </span><span class="default">$flag</span><span class="keyword">;<br />&nbsp; &nbsp; return </span><span class="default">$val</span><span class="keyword">;<br />}<br />function </span><span class="default">is_bitflag_set</span><span class="keyword">(</span><span class="default">$val</span><span class="keyword">, </span><span class="default">$flag</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; return ((</span><span class="default">$val </span><span class="keyword">&amp; </span><span class="default">$flag</span><span class="keyword">) === </span><span class="default">$flag</span><span class="keyword">);<br />}<br /></span><span class="comment">// Define your flags<br /></span><span class="default">define</span><span class="keyword">(</span><span class="string">'MYFLAGONE'</span><span class="keyword">, </span><span class="default">1</span><span class="keyword">); </span><span class="comment">// 0001<br /></span><span class="default">define</span><span class="keyword">(</span><span class="string">'MYFLAGTWO'</span><span class="keyword">, </span><span class="default">2</span><span class="keyword">); </span><span class="comment">// 0010<br /></span><span class="default">define</span><span class="keyword">(</span><span class="string">'MYFLAGTHREE'</span><span class="keyword">, </span><span class="default">4</span><span class="keyword">); </span><span class="comment">// 0100<br /></span><span class="default">define</span><span class="keyword">(</span><span class="string">'MYFLAGFOUR'</span><span class="keyword">, </span><span class="default">8</span><span class="keyword">); </span><span class="comment">// 1000<br /></span><span class="default">?&gt;<br /></span><br />I should point out: your flags are stored in a single integer. You can store loads of flags in a single integer.<br /><br />To use my functions, say you wanted to set MYFLAGONE and MYFLAGTHREE, you would use:<br /><span class="default">&lt;?php<br />$myflags </span><span class="keyword">= </span><span class="default">set_bitflags</span><span class="keyword">(</span><span class="default">MYFLAGONE</span><span class="keyword">, </span><span class="default">MYFLAGTHREE</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span>Note: you can pass set_bitflags() as many flags to set as you want.<br /><br />When you want to test later if a certain flag is set, use e.g.:<br /><span class="default">&lt;?php<br /></span><span class="keyword">if(</span><span class="default">is_bitflag_set</span><span class="keyword">(</span><span class="default">$myflags</span><span class="keyword">, </span><span class="default">MYFLAGTWO</span><span class="keyword">))<br />{<br />&nbsp; &nbsp; echo </span><span class="string">"MYFLAGTWO is set!"</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />The only tricky part is defining your flags. Here is the process:<br />1.&nbsp; Write a list of your flags<br />2.&nbsp; Count them<br />3.&nbsp; Define the last flag in your list as 1 times 2 to the power of &lt;count&gt; minus one. ( I.E. 1*2^(&lt;count&gt;-1) )<br />3. Working backwards through your list, from the last to the first, define each one as half of the previous one. You should reach 1 when you get to the first<br /><br />If you want to understand binary numbers, bits and bitwise operation better, the wikipedia page explains it well - <a href="http://en.wikipedia.org/wiki/Bitwise_operation." rel="nofollow" target="_blank">http://en.wikipedia.org/wiki/Bitwise_operation.</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="38019">  <div class="votes">
    <div id="Vu38019">
    <a href="/manual/vote-note.php?id=38019&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd38019">
    <a href="/manual/vote-note.php?id=38019&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V38019" title="33% like this...">
    -1
    </div>
  </div>
  <a href="#38019" class="name">
  <strong class="user"><em>krang at krang dot org dot uk</em></strong></a><a class="genanchor" href="#38019"> &para;</a><div class="date" title="2003-12-04 02:30"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom38019">
<div class="phpcode"><code><span class="html">
Hopefully this may help someone understand the fun of Bitwise Operators....<br /><br />The purpose of this function is to return a value from the GPC (Get, Post and Cookie) and do some basic formatting to it depending on the $VALIDATION value:<br /><br /><span class="default">&lt;?PHP<br /><br />&nbsp; </span><span class="keyword">function </span><span class="default">RETURN_SUBMITTED_VALUE </span><span class="keyword">(</span><span class="default">$VARIABLE</span><span class="keyword">, </span><span class="default">$METHOD</span><span class="keyword">, </span><span class="default">$VALIDATION</span><span class="keyword">) {<br /><br />&nbsp;&nbsp; </span><span class="comment">//-------------------------------<br />&nbsp;&nbsp; // Get the value from the<br />&nbsp;&nbsp; // relevant submit method...<br /><br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="keyword">if (</span><span class="default">$METHOD </span><span class="keyword">== </span><span class="string">'POST'</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; if (!isset(</span><span class="default">$_POST</span><span class="keyword">[</span><span class="default">$VARIABLE</span><span class="keyword">])) </span><span class="default">$_POST</span><span class="keyword">[</span><span class="default">$VARIABLE</span><span class="keyword">] = </span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$VALUE </span><span class="keyword">= </span><span class="default">$_POST</span><span class="keyword">[</span><span class="default">$VARIABLE</span><span class="keyword">];<br /><br />&nbsp; &nbsp; &nbsp;&nbsp; } elseif (</span><span class="default">$METHOD </span><span class="keyword">== </span><span class="string">'COOKIE'</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; if (!isset(</span><span class="default">$_COOKIE</span><span class="keyword">[</span><span class="default">$VARIABLE</span><span class="keyword">])) </span><span class="default">$_COOKIE</span><span class="keyword">[</span><span class="default">$VARIABLE</span><span class="keyword">] = </span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$VALUE </span><span class="keyword">= </span><span class="default">$_COOKIE</span><span class="keyword">[</span><span class="default">$VARIABLE</span><span class="keyword">];<br /><br />&nbsp; &nbsp; &nbsp;&nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; if (!isset(</span><span class="default">$_GET</span><span class="keyword">[</span><span class="default">$VARIABLE</span><span class="keyword">])) </span><span class="default">$_GET</span><span class="keyword">[</span><span class="default">$VARIABLE</span><span class="keyword">] = </span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$VALUE </span><span class="keyword">= </span><span class="default">$_GET</span><span class="keyword">[</span><span class="default">$VARIABLE</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp;&nbsp; }<br /><br />&nbsp;&nbsp; </span><span class="comment">//-------------------------------<br />&nbsp;&nbsp; // If necessary strip the slashes.<br />&nbsp;&nbsp; // the "GPC" means - GET, POST<br />&nbsp;&nbsp; // COOKIE.<br /><br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="keyword">if (</span><span class="default">ini_get </span><span class="keyword">(</span><span class="string">'magic_quotes_gpc'</span><span class="keyword">) == </span><span class="default">true</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$VALUE </span><span class="keyword">= </span><span class="default">stripslashes</span><span class="keyword">(</span><span class="default">$VALUE</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp;&nbsp; }<br /><br />&nbsp;&nbsp; </span><span class="comment">//-------------------------------<br />&nbsp;&nbsp; // Now for the different types<br />&nbsp;&nbsp; // of VALIDATION's<br /><br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="keyword">if ((</span><span class="default">$VALIDATION </span><span class="keyword">&amp; </span><span class="default">8</span><span class="keyword">) == </span><span class="default">8</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$VALUE </span><span class="keyword">= (int)</span><span class="default">$VALUE</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp;&nbsp; }<br /><br />&nbsp; &nbsp; &nbsp;&nbsp; if ((</span><span class="default">$VALIDATION </span><span class="keyword">&amp; </span><span class="default">4</span><span class="keyword">) == </span><span class="default">4</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$VALUE </span><span class="keyword">= </span><span class="default">strtolower</span><span class="keyword">(</span><span class="default">$VALUE</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp;&nbsp; }<br /><br />&nbsp; &nbsp; &nbsp;&nbsp; if ((</span><span class="default">$VALIDATION </span><span class="keyword">&amp; </span><span class="default">2</span><span class="keyword">) == </span><span class="default">2</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$VALUE </span><span class="keyword">= </span><span class="default">strip_tags</span><span class="keyword">(</span><span class="default">$VALUE</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp;&nbsp; }<br /><br />&nbsp; &nbsp; &nbsp;&nbsp; if ((</span><span class="default">$VALIDATION </span><span class="keyword">&amp; </span><span class="default">1</span><span class="keyword">) == </span><span class="default">1</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$VALUE </span><span class="keyword">= </span><span class="default">trim</span><span class="keyword">(</span><span class="default">$VALUE</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp;&nbsp; }<br /><br />&nbsp;&nbsp; </span><span class="comment">//-------------------------------<br />&nbsp;&nbsp; // Finally return the value<br /><br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="keyword">return </span><span class="default">$VALUE</span><span class="keyword">;<br /><br />&nbsp; }<br /><br />&nbsp; echo </span><span class="default">RETURN_SUBMITTED_VALUE </span><span class="keyword">(</span><span class="string">'ID'</span><span class="keyword">, </span><span class="string">'GET'</span><span class="keyword">, </span><span class="default">8</span><span class="keyword">) . </span><span class="string">'&lt;br /&gt;'</span><span class="keyword">;<br />&nbsp;&nbsp; </span><span class="comment">// Convert to an Integer<br /><br />&nbsp; </span><span class="keyword">echo </span><span class="default">RETURN_SUBMITTED_VALUE </span><span class="keyword">(</span><span class="string">'NAME'</span><span class="keyword">, </span><span class="string">'GET'</span><span class="keyword">, </span><span class="default">3</span><span class="keyword">) . </span><span class="string">'&lt;br /&gt;'</span><span class="keyword">;<br />&nbsp;&nbsp; </span><span class="comment">// Trim Whitespace and Strip HTML tags<br /><br />&nbsp; </span><span class="keyword">echo </span><span class="default">RETURN_SUBMITTED_VALUE </span><span class="keyword">(</span><span class="string">'GENDER'</span><span class="keyword">, </span><span class="string">'GET'</span><span class="keyword">, </span><span class="default">6</span><span class="keyword">) . </span><span class="string">'&lt;br /&gt;'</span><span class="keyword">;<br />&nbsp;&nbsp; </span><span class="comment">// Strip HTML tags and convert to lower case<br /><br />&nbsp; //-----------------------------------------------<br />&nbsp; // If this script was loaded under the URL<br />&nbsp; // index.php?ID=19a&amp;NAME=Krang&amp;GENDER=MalE<br />&nbsp; // it would print<br />&nbsp; //<br />&nbsp; // 19<br />&nbsp; // Krang<br />&nbsp; // male<br />&nbsp; //-----------------------------------------------<br /><br /></span><span class="default">?&gt;<br /></span><br />For those that don�t understand binary, the numbers you see are not random, they double each time (1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024...) which allows you to mix and match the different function, eg...<br /><br />1 + 2 = 3 (Trim Whitespace + Strip HTML)<br />2 + 4 = 6 (Strip HTML + Convert to lower case)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113284">  <div class="votes">
    <div id="Vu113284">
    <a href="/manual/vote-note.php?id=113284&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113284">
    <a href="/manual/vote-note.php?id=113284&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113284" title="25% like this...">
    -2
    </div>
  </div>
  <a href="#113284" class="name">
  <strong class="user"><em>melnikvictorl at gmail dot com</em></strong></a><a class="genanchor" href="#113284"> &para;</a><div class="date" title="2013-09-20 03:08"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113284">
<div class="phpcode"><code><span class="html">
Nice example of bitwise operation with strings:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">echo </span><span class="string">'php' </span><span class="keyword">&amp; </span><span class="string">'^_^'</span><span class="keyword">;<br /><br /></span><span class="comment">// will output string PHP</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="94552">  <div class="votes">
    <div id="Vu94552">
    <a href="/manual/vote-note.php?id=94552&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd94552">
    <a href="/manual/vote-note.php?id=94552&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V94552" title="22% like this...">
    -5
    </div>
  </div>
  <a href="#94552" class="name">
  <strong class="user"><em>Alex</em></strong></a><a class="genanchor" href="#94552"> &para;</a><div class="date" title="2009-11-11 10:10"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom94552">
<div class="phpcode"><code><span class="html">
Okay, I'm twelve, and I am new to PHP, but I created the following -simple- functions:<br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">Isdec</span><span class="keyword">(</span><span class="default">$num</span><span class="keyword">) {<br />if(</span><span class="default">round</span><span class="keyword">(</span><span class="default">$num</span><span class="keyword">)==</span><span class="default">$num</span><span class="keyword">) {<br />return </span><span class="default">false</span><span class="keyword">;<br />}<br />else {<br />return </span><span class="default">true</span><span class="keyword">;<br />}<br />}<br /><br />function </span><span class="default">decshiftl</span><span class="keyword">(</span><span class="default">$number</span><span class="keyword">, </span><span class="default">$amount</span><span class="keyword">){<br />if(</span><span class="default">Isdec</span><span class="keyword">(</span><span class="default">$number</span><span class="keyword">)) {<br /></span><span class="default">$decimal </span><span class="keyword">= </span><span class="default">substr</span><span class="keyword">(</span><span class="default">$number</span><span class="keyword">, (</span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$number</span><span class="keyword">) - </span><span class="default">round</span><span class="keyword">(</span><span class="default">$number</span><span class="keyword">) + </span><span class="default">1</span><span class="keyword">));<br /></span><span class="default">$decimal</span><span class="keyword">*=</span><span class="default">pow</span><span class="keyword">(</span><span class="default">10</span><span class="keyword">,</span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$decimal</span><span class="keyword">) - </span><span class="default">1</span><span class="keyword">);<br /></span><span class="default">$Shiftl </span><span class="keyword">= (</span><span class="default">$number </span><span class="keyword">&lt;&lt; </span><span class="default">$amount</span><span class="keyword">) + ((</span><span class="default">$decimal </span><span class="keyword">&lt;&lt; </span><span class="default">$amount</span><span class="keyword">) / </span><span class="default">pow</span><span class="keyword">(</span><span class="default">10</span><span class="keyword">,</span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$decimal</span><span class="keyword">)));<br />}<br />else {<br /></span><span class="default">$Shiftl </span><span class="keyword">= </span><span class="default">$number </span><span class="keyword">&lt;&lt; </span><span class="default">$amount</span><span class="keyword">;<br />}<br />return </span><span class="default">$Shiftl</span><span class="keyword">;<br />}<br /><br />function </span><span class="default">decshiftr</span><span class="keyword">(</span><span class="default">$number</span><span class="keyword">, </span><span class="default">$amount</span><span class="keyword">){<br />if(</span><span class="default">Isdec</span><span class="keyword">(</span><span class="default">$number</span><span class="keyword">)) {<br /></span><span class="default">$decimal </span><span class="keyword">= </span><span class="default">substr</span><span class="keyword">(</span><span class="default">$number</span><span class="keyword">, (</span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$number</span><span class="keyword">) - </span><span class="default">round</span><span class="keyword">(</span><span class="default">$number</span><span class="keyword">) + </span><span class="default">1</span><span class="keyword">));<br /></span><span class="default">$decimal</span><span class="keyword">*=</span><span class="default">pow</span><span class="keyword">(</span><span class="default">10</span><span class="keyword">,</span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$decimal</span><span class="keyword">) - </span><span class="default">1</span><span class="keyword">);<br /></span><span class="default">$Shiftr </span><span class="keyword">= (</span><span class="default">$number </span><span class="keyword">&gt;&gt; </span><span class="default">$amount</span><span class="keyword">) + ((</span><span class="default">$decimal </span><span class="keyword">&gt;&gt; </span><span class="default">$amount</span><span class="keyword">) / </span><span class="default">pow</span><span class="keyword">(</span><span class="default">10</span><span class="keyword">,</span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$decimal</span><span class="keyword">)));<br />}<br />else {<br /></span><span class="default">$Shiftr </span><span class="keyword">= </span><span class="default">$number </span><span class="keyword">&gt;&gt; </span><span class="default">$amount</span><span class="keyword">;<br />}<br />return </span><span class="default">$Shiftr</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span>Anyway, it's just shoving parameters in to an equation, but sometimes reinventing the wheel and putting rockets on it is a good thing.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="73578">  <div class="votes">
    <div id="Vu73578">
    <a href="/manual/vote-note.php?id=73578&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd73578">
    <a href="/manual/vote-note.php?id=73578&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V73578" title="16% like this...">
    -4
    </div>
  </div>
  <a href="#73578" class="name">
  <strong class="user"><em>gcG</em></strong></a><a class="genanchor" href="#73578"> &para;</a><div class="date" title="2007-03-01 04:23"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom73578">
<div class="phpcode"><code><span class="html">
function xnor($a, $b) {<br />&nbsp; &nbsp; return ~($a ^ $b);<br />}<br />XNOR is very usefull ;D</span>
</code></div>
  </div>
 </div>
  <div class="note" id="115785">  <div class="votes">
    <div id="Vu115785">
    <a href="/manual/vote-note.php?id=115785&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115785">
    <a href="/manual/vote-note.php?id=115785&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115785" title="0% like this...">
    -7
    </div>
  </div>
  <a href="#115785" class="name">
  <strong class="user"><em>yesman at mail dot com</em></strong></a><a class="genanchor" href="#115785"> &para;</a><div class="date" title="2014-09-23 03:33"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115785">
<div class="phpcode"><code><span class="html">
There is this useful bitwise calculator online for us to make quick calculations: <a href="http://www.bitwiseoperatorcalculator.com" rel="nofollow" target="_blank">http://www.bitwiseoperatorcalculator.com</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="61415">  <div class="votes">
    <div id="Vu61415">
    <a href="/manual/vote-note.php?id=61415&amp;page=language.operators.bitwise&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd61415">
    <a href="/manual/vote-note.php?id=61415&amp;page=language.operators.bitwise&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V61415" title="0% like this...">
    -4
    </div>
  </div>
  <a href="#61415" class="name">
  <strong class="user"><em>John L</em></strong></a><a class="genanchor" href="#61415"> &para;</a><div class="date" title="2006-02-02 02:11"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom61415">
<div class="phpcode"><code><span class="html">
Bitwise operators are swell, but (a &amp; b &amp; c &amp; d) == a<br />is not a way to test for four-way equality. If a is zero, it'll always be true, and in general it will be true any time a has no bits not also in the other three values.</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.operators.bitwise&amp;redirect=http://php.net/manual/en/language.operators.bitwise.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.operators.php">Operators</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.operators.precedence.php" title="Operator Precedence">Operator Precedence</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.arithmetic.php" title="Arithmetic Operators">Arithmetic Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.assignment.php" title="Assignment Operators">Assignment Operators</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.operators.bitwise.php" title="Bitwise Operators">Bitwise Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.comparison.php" title="Comparison Operators">Comparison Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.errorcontrol.php" title="Error Control Operators">Error Control Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.execution.php" title="Execution Operators">Execution Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.increment.php" title="Incrementing/Decrementing Operators">Incrementing/Decrementing Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.logical.php" title="Logical Operators">Logical Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.string.php" title="String Operators">String Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.array.php" title="Array Operators">Array Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.type.php" title="Type Operators">Type Operators</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

