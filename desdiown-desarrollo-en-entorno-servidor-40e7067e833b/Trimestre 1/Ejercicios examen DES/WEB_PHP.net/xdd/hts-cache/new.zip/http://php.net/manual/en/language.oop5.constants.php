<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Class Constants - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.oop5.constants.php">
 <link rel="shorturl" href="http://php.net/oop5.constants">
 <link rel="alternate" href="http://php.net/oop5.constants" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.oop5.php">
 <link rel="prev" href="http://php.net/manual/en/language.oop5.properties.php">
 <link rel="next" href="http://php.net/manual/en/language.oop5.autoload.php">

 <link rel="alternate" href="http://php.net/manual/en/language.oop5.constants.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.oop5.constants.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.oop5.constants.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.oop5.constants.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.oop5.constants.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.oop5.constants.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.oop5.constants.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.oop5.constants.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.oop5.constants.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.oop5.constants.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.oop5.constants.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.oop5.autoload.php">
          Autoloading Classes &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.oop5.properties.php">
          &laquo; Properties        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.oop5.php'>Classes and Objects</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.oop5.constants.php' selected="selected">English</option>
            <option value='pt_BR/language.oop5.constants.php'>Brazilian Portuguese</option>
            <option value='zh/language.oop5.constants.php'>Chinese (Simplified)</option>
            <option value='fr/language.oop5.constants.php'>French</option>
            <option value='de/language.oop5.constants.php'>German</option>
            <option value='ja/language.oop5.constants.php'>Japanese</option>
            <option value='ro/language.oop5.constants.php'>Romanian</option>
            <option value='ru/language.oop5.constants.php'>Russian</option>
            <option value='es/language.oop5.constants.php'>Spanish</option>
            <option value='tr/language.oop5.constants.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.oop5.constants.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.oop5.constants">Report a Bug</a>
    </div>
  </div><div id="language.oop5.constants" class="sect1">
 <h2 class="title">Class Constants</h2>
 <p class="para">
  It is possible to define constant values on a per-class basis remaining the
  same and unchangeable. Constants differ from normal variables in that you
  don&#039;t use the <var class="varname"><var class="varname">$</var></var> symbol to declare or use them. 
  The default visibility of class constants is <em>public</em>.
 </p>
 <p class="para">
  The value must be a constant expression, not (for example) a variable, a
  property, or a function call.
 </p>
 <p class="para">
  It&#039;s also possible for interfaces to have <em>constants</em>. Look at 
  the <a href="language.oop5.interfaces.php" class="link">interface documentation</a> for 
  examples.
 </p>
 <p class="para">
  As of PHP 5.3.0, it&#039;s possible to reference the class using a variable.
  The variable&#039;s value can not be a keyword (e.g. <em>self</em>,
  <em>parent</em> and <em>static</em>).
 </p>
 <p class="para">
  Note that class constants are allocated once per class, and not for each
  class instance.
 </p>
 <div class="example" id="example-182">
  <p><strong>Example #1 Defining and using a constant</strong></p>
  <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">MyClass<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;const&nbsp;</span><span style="color: #0000BB">CONSTANT&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'constant&nbsp;value'</span><span style="color: #007700">;<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;function&nbsp;</span><span style="color: #0000BB">showConstant</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;&nbsp;</span><span style="color: #0000BB">self</span><span style="color: #007700">::</span><span style="color: #0000BB">CONSTANT&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br />echo&nbsp;</span><span style="color: #0000BB">MyClass</span><span style="color: #007700">::</span><span style="color: #0000BB">CONSTANT&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br /><br /></span><span style="color: #0000BB">$classname&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">"MyClass"</span><span style="color: #007700">;<br />echo&nbsp;</span><span style="color: #0000BB">$classname</span><span style="color: #007700">::</span><span style="color: #0000BB">CONSTANT&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;As&nbsp;of&nbsp;PHP&nbsp;5.3.0<br /><br /></span><span style="color: #0000BB">$class&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">MyClass</span><span style="color: #007700">();<br /></span><span style="color: #0000BB">$class</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">showConstant</span><span style="color: #007700">();<br /><br />echo&nbsp;</span><span style="color: #0000BB">$class</span><span style="color: #007700">::</span><span style="color: #0000BB">CONSTANT</span><span style="color: #007700">.</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;As&nbsp;of&nbsp;PHP&nbsp;5.3.0<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
  </div>

 </div>
 <div class="example" id="example-183">
  <p><strong>Example #2 Static data example</strong></p>
  <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">foo&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;As&nbsp;of&nbsp;PHP&nbsp;5.3.0<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">const&nbsp;</span><span style="color: #0000BB">BAR&nbsp;</span><span style="color: #007700">=&nbsp;&lt;&lt;&lt;'EOT'<br /></span><span style="color: #DD0000">bar<br /></span><span style="color: #007700">EOT;<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;As&nbsp;of&nbsp;PHP&nbsp;5.3.0<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">const&nbsp;</span><span style="color: #0000BB">BAZ&nbsp;</span><span style="color: #007700">=&nbsp;&lt;&lt;&lt;EOT<br /></span><span style="color: #DD0000">baz<br /></span><span style="color: #007700">EOT;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
  </div>

 </div>
 <blockquote class="note"><p><strong class="note">Note</strong>: 
  <p class="para">
   Support for initializing constants with Heredoc and Nowdoc syntax was added in PHP 5.3.0.
  </p>
 </p></blockquote>
 <p class="para">
  The special <strong><code>::class</code></strong> constant are available as of PHP 5.5.0, and allows 
  for fully qualified class name resolution at compile, this is useful for namespaced classes:
 </p>
 <div class="example" id="example-184">
  <p><strong>Example #3 Namespaced ::class example</strong></p>
  <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">namespace&nbsp;</span><span style="color: #0000BB">foo&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;class&nbsp;</span><span style="color: #0000BB">bar&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #0000BB">bar</span><span style="color: #007700">::class;&nbsp;</span><span style="color: #FF8000">//&nbsp;foo\bar<br /></span><span style="color: #007700">}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
  </div>

 </div>
 <div class="example" id="example-185">
  <p><strong>Example #4 Constant expression example</strong></p>
  <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">const&nbsp;</span><span style="color: #0000BB">ONE&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">;<br /><br />class&nbsp;</span><span style="color: #0000BB">foo&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;As&nbsp;of&nbsp;PHP&nbsp;5.6.0<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">const&nbsp;</span><span style="color: #0000BB">TWO&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">ONE&nbsp;</span><span style="color: #007700">*&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;const&nbsp;</span><span style="color: #0000BB">THREE&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">ONE&nbsp;</span><span style="color: #007700">+&nbsp;</span><span style="color: #0000BB">self</span><span style="color: #007700">::</span><span style="color: #0000BB">TWO</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;const&nbsp;</span><span style="color: #0000BB">SENTENCE&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'The&nbsp;value&nbsp;of&nbsp;THREE&nbsp;is&nbsp;'</span><span style="color: #007700">.</span><span style="color: #0000BB">self</span><span style="color: #007700">::</span><span style="color: #0000BB">THREE</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
  </div>

  <div class="example-contents"><p>
   It is possible to provide a scalar expression involving numeric and string literals and/or constants in context of a class constant.
  </p></div>
 </div>
 <blockquote class="note"><p><strong class="note">Note</strong>: 
  <p class="para">
   Constant expression support was added in PHP 5.6.0.
  </p>
 </p></blockquote>

 <div class="example" id="language.oop5.basic.class.this">
  <p><strong>Example #5 Class constant visibility modifiers</strong></p>
  <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">Foo&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;As&nbsp;of&nbsp;PHP&nbsp;7.1.0<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">public&nbsp;const&nbsp;</span><span style="color: #0000BB">BAR&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'bar'</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;private&nbsp;const&nbsp;</span><span style="color: #0000BB">BAZ&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'baz'</span><span style="color: #007700">;<br />}<br />echo&nbsp;</span><span style="color: #0000BB">Foo</span><span style="color: #007700">::</span><span style="color: #0000BB">BAR</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">PHP_EOL</span><span style="color: #007700">;<br />echo&nbsp;</span><span style="color: #0000BB">Foo</span><span style="color: #007700">::</span><span style="color: #0000BB">BAZ</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">PHP_EOL</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
  </div>

   <div class="example-contents"><p>Output of the above example in PHP 7.1:</p></div>
   <div class="example-contents screen">
<div class="cdata"><pre>
bar

Fatal error: Uncaught Error: Cannot access private const Foo::BAZ in …
</pre></div>
   </div>
 </div>
 <blockquote class="note"><p><strong class="note">Note</strong>: 
  <p class="para">
   As of PHP 7.1.0 visibility modifiers are allowed for class constants.
  </p>
 </p></blockquote>
</div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.oop5.constants&amp;redirect=http://php.net/manual/en/language.oop5.constants.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">18 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="116109">  <div class="votes">
    <div id="Vu116109">
    <a href="/manual/vote-note.php?id=116109&amp;page=language.oop5.constants&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116109">
    <a href="/manual/vote-note.php?id=116109&amp;page=language.oop5.constants&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116109" title="77% like this...">
    101
    </div>
  </div>
  <a href="#116109" class="name">
  <strong class="user"><em>kuzawinski dot marcin at gmail dot com</em></strong></a><a class="genanchor" href="#116109"> &para;</a><div class="date" title="2014-11-11 01:27"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom116109">
<div class="phpcode"><code><span class="html">
As of PHP 5.6 you can finally define constant using math expressions, like this one:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">MyTimer </span><span class="keyword">{<br />&nbsp; &nbsp; const </span><span class="default">SEC_PER_DAY </span><span class="keyword">= </span><span class="default">60 </span><span class="keyword">* </span><span class="default">60 </span><span class="keyword">* </span><span class="default">24</span><span class="keyword">;<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />Me happy :)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="104260">  <div class="votes">
    <div id="Vu104260">
    <a href="/manual/vote-note.php?id=104260&amp;page=language.oop5.constants&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd104260">
    <a href="/manual/vote-note.php?id=104260&amp;page=language.oop5.constants&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V104260" title="72% like this...">
    119
    </div>
  </div>
  <a href="#104260" class="name">
  <strong class="user"><em>tmp dot 4 dot longoria at gmail dot com</em></strong></a><a class="genanchor" href="#104260"> &para;</a><div class="date" title="2011-06-04 01:52"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom104260">
<div class="phpcode"><code><span class="html">
it's possible to declare constant in base class, and override it in child, and access to correct value of the const from the static method is possible by 'get_called_class' method:<br /><span class="default">&lt;?php<br /></span><span class="keyword">abstract class </span><span class="default">dbObject<br /></span><span class="keyword">{&nbsp; &nbsp; <br />&nbsp; &nbsp; const </span><span class="default">TABLE_NAME</span><span class="keyword">=</span><span class="string">'undefined'</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public static function </span><span class="default">GetAll</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$c </span><span class="keyword">= </span><span class="default">get_called_class</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">"SELECT * FROM `"</span><span class="keyword">.</span><span class="default">$c</span><span class="keyword">::</span><span class="default">TABLE_NAME</span><span class="keyword">.</span><span class="string">"`"</span><span class="keyword">;<br />&nbsp; &nbsp; }&nbsp; &nbsp; <br />}<br /><br />class </span><span class="default">dbPerson </span><span class="keyword">extends </span><span class="default">dbObject<br /></span><span class="keyword">{<br />&nbsp; &nbsp; const </span><span class="default">TABLE_NAME</span><span class="keyword">=</span><span class="string">'persons'</span><span class="keyword">;<br />}<br /><br />class </span><span class="default">dbAdmin </span><span class="keyword">extends </span><span class="default">dbPerson<br /></span><span class="keyword">{<br />&nbsp; &nbsp; const </span><span class="default">TABLE_NAME</span><span class="keyword">=</span><span class="string">'admins'</span><span class="keyword">;<br />}<br /><br />echo </span><span class="default">dbPerson</span><span class="keyword">::</span><span class="default">GetAll</span><span class="keyword">().</span><span class="string">"&lt;br&gt;"</span><span class="keyword">;</span><span class="comment">//output: "SELECT * FROM `persons`"<br /></span><span class="keyword">echo </span><span class="default">dbAdmin</span><span class="keyword">::</span><span class="default">GetAll</span><span class="keyword">().</span><span class="string">"&lt;br&gt;"</span><span class="keyword">;</span><span class="comment">//output: "SELECT * FROM `admins`"<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="100142">  <div class="votes">
    <div id="Vu100142">
    <a href="/manual/vote-note.php?id=100142&amp;page=language.oop5.constants&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd100142">
    <a href="/manual/vote-note.php?id=100142&amp;page=language.oop5.constants&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V100142" title="74% like this...">
    90
    </div>
  </div>
  <a href="#100142" class="name">
  <strong class="user"><em>anonymous</em></strong></a><a class="genanchor" href="#100142"> &para;</a><div class="date" title="2010-09-27 06:32"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom100142">
<div class="phpcode"><code><span class="html">
Most people miss the point in declaring constants and confuse then things by trying to declare things like functions or arrays as constants. What happens next is to try things that are more complicated then necessary and sometimes lead to bad coding practices. Let me explain...<br /><br />A constant is a name for a value (but it's NOT a variable), that usually will be replaced in the code while it gets COMPILED and NOT at runtime. <br /><br />So returned values from functions can't be used, because they will return a value only at runtime. <br /><br />Arrays can't be used, because they are data structures that exist at runtime. <br /><br />One main purpose of declaring a constant is usually using a value in your code, that you can replace easily in one place without looking for all the occurences. Another is, to avoid mistakes. <br /><br />Think about some examples written by some before me: <br /><br />1. const MY_ARR = "return array(\"A\", \"B\", \"C\", \"D\");";<br />It was said, this would declare an array that can be used with eval. WRONG! This is just a string as constant, NOT an array. Does it make sense if it would be possible to declare an array as constant? Probably not. Instead declare the values of the array as constants and make an array variable. <br /><br />2. const magic_quotes = (bool)get_magic_quotes_gpc();<br />This can't work, of course. And it doesn't make sense either. The function already returns the value, there is no purpose in declaring a constant for the same thing. <br /><br />3. Someone spoke about "dynamic" assignments to constants. What? There are no dynamic assignments to constants, runtime assignments work _only_ with variables. Let's take the proposed example: <br /><br /><span class="default">&lt;?php<br /></span><span class="comment">/**<br /> * Constants that deal only with the database<br /> */<br /></span><span class="keyword">class </span><span class="default">DbConstant </span><span class="keyword">extends </span><span class="default">aClassConstant </span><span class="keyword">{<br />&nbsp; &nbsp; protected </span><span class="default">$host </span><span class="keyword">= </span><span class="string">'localhost'</span><span class="keyword">;<br />&nbsp; &nbsp; protected </span><span class="default">$user </span><span class="keyword">= </span><span class="string">'user'</span><span class="keyword">;<br />&nbsp; &nbsp; protected </span><span class="default">$password </span><span class="keyword">= </span><span class="string">'pass'</span><span class="keyword">;<br />&nbsp; &nbsp; protected </span><span class="default">$database </span><span class="keyword">= </span><span class="string">'db'</span><span class="keyword">;<br />&nbsp; &nbsp; protected </span><span class="default">$time</span><span class="keyword">;<br />&nbsp; &nbsp; function </span><span class="default">__construct</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">time </span><span class="keyword">= </span><span class="default">time</span><span class="keyword">() + </span><span class="default">1</span><span class="keyword">; </span><span class="comment">// dynamic assignment<br />&nbsp; &nbsp; </span><span class="keyword">}<br />}<br /></span><span class="default">?&gt;<br /></span><br />Those aren't constants, those are properties of the class. Something like "this-&gt;time = time()" would even totally defy the purpose of a constant. Constants are supposed to be just that, constant values, on every execution. They are not supposed to change every time a script runs or a class is instantiated. <br /><br />Conclusion: Don't try to reinvent constants as variables. If constants don't work, just use variables. Then you don't need to reinvent methods to achieve things for what is already there.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114599">  <div class="votes">
    <div id="Vu114599">
    <a href="/manual/vote-note.php?id=114599&amp;page=language.oop5.constants&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114599">
    <a href="/manual/vote-note.php?id=114599&amp;page=language.oop5.constants&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114599" title="76% like this...">
    67
    </div>
  </div>
  <a href="#114599" class="name">
  <strong class="user"><em>Xiong Chiamiov</em></strong></a><a class="genanchor" href="#114599"> &para;</a><div class="date" title="2014-03-10 11:36"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114599">
<div class="phpcode"><code><span class="html">
const can also be used directly in namespaces, a feature never explicitly stated in the documentation.<br /><br /><span class="default">&lt;?php<br /></span><span class="comment"># foo.php<br /></span><span class="keyword">namespace </span><span class="default">Foo</span><span class="keyword">;<br /><br />const </span><span class="default">BAR </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br /><span class="default">&lt;?php<br /></span><span class="comment"># bar.php<br /></span><span class="keyword">require </span><span class="string">'foo.php'</span><span class="keyword">;<br /><br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">Foo</span><span class="keyword">\</span><span class="default">BAR</span><span class="keyword">); </span><span class="comment">// =&gt; int(1)<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114143">  <div class="votes">
    <div id="Vu114143">
    <a href="/manual/vote-note.php?id=114143&amp;page=language.oop5.constants&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114143">
    <a href="/manual/vote-note.php?id=114143&amp;page=language.oop5.constants&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114143" title="75% like this...">
    69
    </div>
  </div>
  <a href="#114143" class="name">
  <strong class="user"><em>delete dot this dot and dot dots dot gt at kani dot hu</em></strong></a><a class="genanchor" href="#114143"> &para;</a><div class="date" title="2014-01-16 11:05"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114143">
<div class="phpcode"><code><span class="html">
I think it's useful if we draw some attention to late static binding here:<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">A </span><span class="keyword">{<br />&nbsp; &nbsp; const </span><span class="default">MY_CONST </span><span class="keyword">= </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp; public function </span><span class="default">my_const_self</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">self</span><span class="keyword">::</span><span class="default">MY_CONST</span><span class="keyword">;<br />&nbsp; &nbsp; } <br />&nbsp; &nbsp; public function </span><span class="default">my_const_static</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return static::</span><span class="default">MY_CONST</span><span class="keyword">;<br />&nbsp; &nbsp; } <br />}<br /><br />class </span><span class="default">B </span><span class="keyword">extends </span><span class="default">A </span><span class="keyword">{<br />&nbsp;&nbsp; const </span><span class="default">MY_CONST </span><span class="keyword">= </span><span class="default">true</span><span class="keyword">;<br />}<br /><br /></span><span class="default">$b </span><span class="keyword">= new </span><span class="default">B</span><span class="keyword">();<br />echo </span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">my_const_self </span><span class="keyword">? </span><span class="string">'yes' </span><span class="keyword">: </span><span class="string">'no'</span><span class="keyword">; </span><span class="comment">// output: no<br /></span><span class="keyword">echo </span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">my_const_static </span><span class="keyword">? </span><span class="string">'yes' </span><span class="keyword">: </span><span class="string">'no'</span><span class="keyword">; </span><span class="comment">// output: yes<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120083">  <div class="votes">
    <div id="Vu120083">
    <a href="/manual/vote-note.php?id=120083&amp;page=language.oop5.constants&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120083">
    <a href="/manual/vote-note.php?id=120083&amp;page=language.oop5.constants&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120083" title="72% like this...">
    10
    </div>
  </div>
  <a href="#120083" class="name">
  <strong class="user"><em>jimmmy dot chief at gmail dot com</em></strong></a><a class="genanchor" href="#120083"> &para;</a><div class="date" title="2016-10-25 02:57"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom120083">
<div class="phpcode"><code><span class="html">
Hi, i would like to point out difference between self::CONST and $this::CONST with extended class.<br />Let us have class a:<br /><br /><span class="default">&lt;?php <br /></span><span class="keyword">class </span><span class="default">a </span><span class="keyword">{&nbsp; &nbsp; <br />&nbsp; &nbsp; const </span><span class="default">CONST_INT </span><span class="keyword">= </span><span class="default">10</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">getSelf</span><span class="keyword">(){<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">self</span><span class="keyword">::</span><span class="default">CONST_INT</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">getThis</span><span class="keyword">(){<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">::</span><span class="default">CONST_INT</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />And class b (which extends a)<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">b </span><span class="keyword">extends </span><span class="default">a </span><span class="keyword">{<br />&nbsp; &nbsp; const </span><span class="default">CONST_INT </span><span class="keyword">= </span><span class="default">20</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">getSelf</span><span class="keyword">(){<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">parent</span><span class="keyword">::</span><span class="default">getSelf</span><span class="keyword">();<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">getThis</span><span class="keyword">(){<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">parent</span><span class="keyword">::</span><span class="default">getThis</span><span class="keyword">();<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />Both classes have same named constant CONST_INT.<br />When child call method in parent class, there is different output between self and $this usage.<br /><br /><span class="default">&lt;?php<br />$b </span><span class="keyword">= new </span><span class="default">b</span><span class="keyword">();<br /><br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">getSelf</span><span class="keyword">());&nbsp; &nbsp;&nbsp; </span><span class="comment">//10<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">getThis</span><span class="keyword">());&nbsp; &nbsp;&nbsp; </span><span class="comment">//20<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118998">  <div class="votes">
    <div id="Vu118998">
    <a href="/manual/vote-note.php?id=118998&amp;page=language.oop5.constants&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118998">
    <a href="/manual/vote-note.php?id=118998&amp;page=language.oop5.constants&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118998" title="64% like this...">
    11
    </div>
  </div>
  <a href="#118998" class="name">
  <strong class="user"><em>nepomuk at nepda dot de</em></strong></a><a class="genanchor" href="#118998"> &para;</a><div class="date" title="2016-03-15 08:50"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom118998">
<div class="phpcode"><code><span class="html">
[Editor's note: that is already possible as of PHP 5.6.0.]<br /><br />Note, as of PHP7 it is possible to define class constants with an array.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">MyClass<br /></span><span class="keyword">{<br />&nbsp; &nbsp; const </span><span class="default">ABC </span><span class="keyword">= array(</span><span class="string">'A'</span><span class="keyword">, </span><span class="string">'B'</span><span class="keyword">, </span><span class="string">'C'</span><span class="keyword">);<br />&nbsp; &nbsp; const </span><span class="default">A </span><span class="keyword">= </span><span class="string">'1'</span><span class="keyword">;<br />&nbsp; &nbsp; const </span><span class="default">B </span><span class="keyword">= </span><span class="string">'2'</span><span class="keyword">;<br />&nbsp; &nbsp; const </span><span class="default">C </span><span class="keyword">= </span><span class="string">'3'</span><span class="keyword">;<br />&nbsp; &nbsp; const </span><span class="default">NUMBERS </span><span class="keyword">= array(<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">A</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">B</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">C</span><span class="keyword">,<br />&nbsp; &nbsp; );<br />}<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">MyClass</span><span class="keyword">::</span><span class="default">ABC</span><span class="keyword">);<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">MyClass</span><span class="keyword">::</span><span class="default">NUMBERS</span><span class="keyword">);<br /><br /></span><span class="comment">// Result:<br />/*<br />array(3) {<br />&nbsp; &nbsp; [0]=&gt;<br />&nbsp; string(1) "A"<br />&nbsp; &nbsp; [1]=&gt;<br />&nbsp; string(1) "B"<br />&nbsp; &nbsp; [2]=&gt;<br />&nbsp; string(1) "C"<br />}<br />array(3) {<br />&nbsp; &nbsp; [0]=&gt;<br />&nbsp; string(1) "1"<br />&nbsp; &nbsp; [1]=&gt;<br />&nbsp; string(1) "2"<br />&nbsp; &nbsp; [2]=&gt;<br />&nbsp; string(1) "3"<br />}<br />*/<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117265">  <div class="votes">
    <div id="Vu117265">
    <a href="/manual/vote-note.php?id=117265&amp;page=language.oop5.constants&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117265">
    <a href="/manual/vote-note.php?id=117265&amp;page=language.oop5.constants&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117265" title="64% like this...">
    5
    </div>
  </div>
  <a href="#117265" class="name">
  <strong class="user"><em>Paul</em></strong></a><a class="genanchor" href="#117265"> &para;</a><div class="date" title="2015-05-12 10:44"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117265">
<div class="phpcode"><code><span class="html">
Square or curly bracket syntax can normally be used to access a single byte (character) within a string. For example: $mystring[5]. However, please note that (for some reason) this syntax is not accepted for string class constants (at least, not in PHP 5.5.12).<br />For example, the following code gives "PHP Parse error:&nbsp; syntax error, unexpected '[' in php shell code on line 6".<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">SomeClass<br /></span><span class="keyword">{<br />&nbsp; const </span><span class="default">SOME_STRING </span><span class="keyword">= </span><span class="string">'0123456790'</span><span class="keyword">;<br />&nbsp; public static function </span><span class="default">ATest</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; return </span><span class="default">self</span><span class="keyword">::</span><span class="default">SOME_STRING</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">];<br />&nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span>It looks like you have to use a variable/class member instead.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113894">  <div class="votes">
    <div id="Vu113894">
    <a href="/manual/vote-note.php?id=113894&amp;page=language.oop5.constants&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113894">
    <a href="/manual/vote-note.php?id=113894&amp;page=language.oop5.constants&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113894" title="62% like this...">
    9
    </div>
  </div>
  <a href="#113894" class="name">
  <strong class="user"><em>keenskelly at gmail dot com</em></strong></a><a class="genanchor" href="#113894"> &para;</a><div class="date" title="2013-12-13 08:42"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113894">
<div class="phpcode"><code><span class="html">
Re: "The value must be a constant expression, not (for example) a variable, a property, a result of a mathematical operation, or a function call."<br /><br />I dare say that "a mathematical operation" can indeed be a constant expression. I was quite surprised by this limitation; you cannot, for example do something like:<br /><br />const LIMITMB = 20;<br />const LIMITB = LIMITMB * 1024 * 1024;<br /><br />It is very common to be able to express something like that in other languages, like C with #defines, where changing one definition has a cascading effect on others without having to pre-calculate hard-coded numbers all over the place. So beware, you might be better off using a private static or global contstant definition if you need to do anything more sophisticated than a name=primitive value pair.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="85703">  <div class="votes">
    <div id="Vu85703">
    <a href="/manual/vote-note.php?id=85703&amp;page=language.oop5.constants&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd85703">
    <a href="/manual/vote-note.php?id=85703&amp;page=language.oop5.constants&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V85703" title="61% like this...">
    11
    </div>
  </div>
  <a href="#85703" class="name">
  <strong class="user"><em>wbcarts at juno dot com</em></strong></a><a class="genanchor" href="#85703"> &para;</a><div class="date" title="2008-09-12 12:12"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom85703">
<div class="phpcode"><code><span class="html">
Use CONST to set UPPER and LOWER LIMITS<br /><br />If you have code that accepts user input or you just need to make sure input is acceptable, you can use constants to set upper and lower limits. Note: a static function that enforces your limits is highly recommended... sniff the clamp() function below for a taste.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">Dimension<br /></span><span class="keyword">{<br />&nbsp; const </span><span class="default">MIN </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">, </span><span class="default">MAX </span><span class="keyword">= </span><span class="default">800</span><span class="keyword">;<br /><br />&nbsp; public </span><span class="default">$width</span><span class="keyword">, </span><span class="default">$height</span><span class="keyword">;<br /><br />&nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$w </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">, </span><span class="default">$h </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">){<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">width&nbsp; </span><span class="keyword">= </span><span class="default">self</span><span class="keyword">::</span><span class="default">clamp</span><span class="keyword">(</span><span class="default">$w</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">height </span><span class="keyword">= </span><span class="default">self</span><span class="keyword">::</span><span class="default">clamp</span><span class="keyword">(</span><span class="default">$h</span><span class="keyword">);<br />&nbsp; }<br /><br />&nbsp; public function </span><span class="default">__toString</span><span class="keyword">(){<br />&nbsp; &nbsp; return </span><span class="string">"Dimension [width=</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">width</span><span class="string">, height=</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">height</span><span class="string">]"</span><span class="keyword">;<br />&nbsp; }<br /><br />&nbsp; protected static function </span><span class="default">clamp</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">){<br />&nbsp; &nbsp; if(</span><span class="default">$value </span><span class="keyword">&lt; </span><span class="default">self</span><span class="keyword">::</span><span class="default">MIN</span><span class="keyword">) </span><span class="default">$value </span><span class="keyword">= </span><span class="default">self</span><span class="keyword">::</span><span class="default">MIN</span><span class="keyword">;<br />&nbsp; &nbsp; if(</span><span class="default">$value </span><span class="keyword">&gt; </span><span class="default">self</span><span class="keyword">::</span><span class="default">MAX</span><span class="keyword">) </span><span class="default">$value </span><span class="keyword">= </span><span class="default">self</span><span class="keyword">::</span><span class="default">MAX</span><span class="keyword">;<br />&nbsp; &nbsp; return </span><span class="default">$value</span><span class="keyword">;<br />&nbsp; }<br />}<br /><br />echo (new </span><span class="default">Dimension</span><span class="keyword">()) . </span><span class="string">'&lt;br&gt;'</span><span class="keyword">;<br />echo (new </span><span class="default">Dimension</span><span class="keyword">(</span><span class="default">1500</span><span class="keyword">, </span><span class="default">97</span><span class="keyword">)) . </span><span class="string">'&lt;br&gt;'</span><span class="keyword">;<br />echo (new </span><span class="default">Dimension</span><span class="keyword">(</span><span class="default">14</span><span class="keyword">, -</span><span class="default">20</span><span class="keyword">)) . </span><span class="string">'&lt;br&gt;'</span><span class="keyword">;<br />echo (new </span><span class="default">Dimension</span><span class="keyword">(</span><span class="default">240</span><span class="keyword">, </span><span class="default">80</span><span class="keyword">)) . </span><span class="string">'&lt;br&gt;'</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;<br /></span><br />- - - - - - - -<br /> Dimension [width=0, height=0] - default size<br /> Dimension [width=800, height=97] - width has been clamped to MAX<br /> Dimension [width=14, height=0] - height has been clamped to MIN<br /> Dimension [width=240, height=80] - width and height unchanged<br />- - - - - - - -<br /><br />Setting upper and lower limits on your classes also help your objects make sense. For example, it is not possible for the width or height of a Dimension to be negative. It is up to you to keep phoney input from corrupting your objects, and to avoid potential errors and exceptions in other parts of your code.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113559">  <div class="votes">
    <div id="Vu113559">
    <a href="/manual/vote-note.php?id=113559&amp;page=language.oop5.constants&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113559">
    <a href="/manual/vote-note.php?id=113559&amp;page=language.oop5.constants&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113559" title="53% like this...">
    2
    </div>
  </div>
  <a href="#113559" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#113559"> &para;</a><div class="date" title="2013-10-29 11:38"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113559">
<div class="phpcode"><code><span class="html">
Noted by another is that class constants take up memory for every instance. I cannot see this functionality being accurate, so testing thusly:<br /><br />class SomeClass {<br /> const thing = 0;<br /> const thing2 = 1;<br />}<br /><br />$m0 = memory_get_usage();<br />$p0 = new SomeClass();<br />$p1 = new SomeClass();<br />$p2 = new SomeClass();<br />$m1 = memory_get_usage();<br />printf("memory %d&lt;br /&gt;", $m1 - $m0);<br /><br />The output does not change when one alters the count of constants in "SomeClass".</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121613">  <div class="votes">
    <div id="Vu121613">
    <a href="/manual/vote-note.php?id=121613&amp;page=language.oop5.constants&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121613">
    <a href="/manual/vote-note.php?id=121613&amp;page=language.oop5.constants&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121613" title="50% like this...">
    0
    </div>
  </div>
  <a href="#121613" class="name">
  <strong class="user"><em>Nimja</em></strong></a><a class="genanchor" href="#121613"> &para;</a><div class="date" title="2017-09-06 01:07"><strong>3 months ago</strong></div>
  <div class="text" id="Hcom121613">
<div class="phpcode"><code><span class="html">
Note that this magic constant DOES NOT load classes. And in fact can work on classes that do not exist.<br /><br />This means it does not mess with auto-loading.<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; $className </span><span class="keyword">= \</span><span class="default">Foo</span><span class="keyword">\</span><span class="default">Bar</span><span class="keyword">::class;<br />&nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$className</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">class_exists</span><span class="keyword">(</span><span class="default">$className</span><span class="keyword">, </span><span class="default">false</span><span class="keyword">));<br /></span><span class="default">?&gt;<br /></span><br />Will output: <br /><br />&nbsp; &nbsp; string(7) "Foo\Bar"<br />&nbsp; &nbsp; bool(false)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121539">  <div class="votes">
    <div id="Vu121539">
    <a href="/manual/vote-note.php?id=121539&amp;page=language.oop5.constants&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121539">
    <a href="/manual/vote-note.php?id=121539&amp;page=language.oop5.constants&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121539" title="50% like this...">
    0
    </div>
  </div>
  <a href="#121539" class="name">
  <strong class="user"><em>scohen987 at gmail dot com</em></strong></a><a class="genanchor" href="#121539"> &para;</a><div class="date" title="2017-08-18 06:16"><strong>3 months ago</strong></div>
  <div class="text" id="Hcom121539">
<div class="phpcode"><code><span class="html">
All non-class constants, declared or not, also have a magic class constant, ie:<br /><br />&nbsp; &nbsp; &gt;&gt;&gt; FOO<br />&nbsp; &nbsp; PHP error:&nbsp; Use of undefined constant FOO - assumed 'FOO' on line 1<br />&nbsp; &nbsp; &gt;&gt;&gt; FOO::class<br />&nbsp; &nbsp; =&gt; "FOO"<br />&nbsp; &nbsp; &gt;&gt;&gt; define('FOO','BAR')<br />&nbsp; &nbsp; =&gt; true<br />&nbsp; &nbsp; &gt;&gt;&gt; FOO<br />&nbsp; &nbsp; =&gt; "BAR"<br />&nbsp; &nbsp; &gt;&gt;&gt; FOO::class<br />&nbsp; &nbsp; =&gt; "FOO"</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114945">  <div class="votes">
    <div id="Vu114945">
    <a href="/manual/vote-note.php?id=114945&amp;page=language.oop5.constants&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114945">
    <a href="/manual/vote-note.php?id=114945&amp;page=language.oop5.constants&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114945" title="45% like this...">
    -1
    </div>
  </div>
  <a href="#114945" class="name">
  <strong class="user"><em>enrico_kaelert at kabelmail dot com</em></strong></a><a class="genanchor" href="#114945"> &para;</a><div class="date" title="2014-05-01 07:05"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114945">
<div class="phpcode"><code><span class="html">
additional to tmp dot 4 dot longoria at gmail dot com ´s post:<br />quote: <br />it's possible to declare constant in base class, and override it in child,<br />/quote<br /><br />Its not that we overwrite them.<br />Its more that each got its own:<br /><span class="default">&lt;?php <br /></span><span class="keyword">abstract class </span><span class="default">dbObject<br /></span><span class="keyword">{<br />&nbsp; &nbsp; const </span><span class="default">TABLE_NAME</span><span class="keyword">=</span><span class="string">'undefined'</span><span class="keyword">;<br />}<br /><br />class </span><span class="default">dbPerson </span><span class="keyword">extends </span><span class="default">dbObject<br /></span><span class="keyword">{<br />&nbsp; &nbsp; const </span><span class="default">TABLE_NAME</span><span class="keyword">=</span><span class="string">'persons'</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public static function </span><span class="default">getSelf</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">self</span><span class="keyword">::</span><span class="default">TABLE_NAME</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public static function </span><span class="default">getParent</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">parent</span><span class="keyword">::</span><span class="default">TABLE_NAME</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">dbAdmin </span><span class="keyword">extends </span><span class="default">dbPerson<br /></span><span class="keyword">{<br />&nbsp; &nbsp; const </span><span class="default">TABLE_NAME</span><span class="keyword">=</span><span class="string">'admins'</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public static function </span><span class="default">getSelf</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">self</span><span class="keyword">::</span><span class="default">TABLE_NAME</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public static function </span><span class="default">getParent</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">parent</span><span class="keyword">::</span><span class="default">TABLE_NAME</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />echo </span><span class="string">'&lt;pre&gt;<br />im class dbPerson{} and this is my:<br />&nbsp; &nbsp; self TABLE_NAME:&nbsp; &nbsp; '</span><span class="keyword">.</span><span class="default">dbPerson</span><span class="keyword">::</span><span class="default">getSelf</span><span class="keyword">().</span><span class="string">'&nbsp;&nbsp; // persons<br />&nbsp; &nbsp; parent TABLE_NAME: '</span><span class="keyword">.</span><span class="default">dbPerson</span><span class="keyword">::</span><span class="default">getParent</span><span class="keyword">().</span><span class="string">'&nbsp; // undefined<br /><br />im class dbAdmin{} and this is my:<br />&nbsp; &nbsp; self TABLE_NAME:&nbsp;&nbsp; '</span><span class="keyword">.</span><span class="default">dbAdmin</span><span class="keyword">::</span><span class="default">getSelf</span><span class="keyword">().</span><span class="string">'&nbsp; &nbsp; // admins<br />&nbsp; &nbsp; parent TABLE_NAME: '</span><span class="keyword">.</span><span class="default">dbAdmin</span><span class="keyword">::</span><span class="default">getParent</span><span class="keyword">().</span><span class="string">'&nbsp; // persons<br />'</span><span class="keyword">; <br /></span><span class="default">?&gt;<br /></span><br />or more readable:<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">ParentClass<br /></span><span class="keyword">{<br />&nbsp; &nbsp; const </span><span class="default">CONSTANT </span><span class="keyword">= </span><span class="string">'CONST_PARENT'</span><span class="keyword">;<br />}<br /><br />class </span><span class="default">A </span><span class="keyword">extends </span><span class="default">ParentClass<br /></span><span class="keyword">{<br />&nbsp; &nbsp; const </span><span class="default">CONSTANT </span><span class="keyword">= </span><span class="string">'CONST_A'</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public static function </span><span class="default">getSelf</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">self</span><span class="keyword">::</span><span class="default">CONSTANT</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public static function </span><span class="default">getParent</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">parent</span><span class="keyword">::</span><span class="default">CONSTANT</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />echo </span><span class="string">'&lt;pre&gt;<br />im class A{} and this is my:<br />&nbsp; &nbsp; self CONSTANT:&nbsp; &nbsp; '</span><span class="keyword">.</span><span class="default">A</span><span class="keyword">::</span><span class="default">getSelf</span><span class="keyword">().</span><span class="string">'&nbsp;&nbsp; // CONST_A<br />&nbsp; &nbsp; parent CONSTANT: '</span><span class="keyword">.</span><span class="default">A</span><span class="keyword">::</span><span class="default">getParent</span><span class="keyword">().</span><span class="string">'&nbsp; // CONST_PARENT<br />'</span><span class="keyword">;<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117423">  <div class="votes">
    <div id="Vu117423">
    <a href="/manual/vote-note.php?id=117423&amp;page=language.oop5.constants&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117423">
    <a href="/manual/vote-note.php?id=117423&amp;page=language.oop5.constants&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117423" title="41% like this...">
    -2
    </div>
  </div>
  <a href="#117423" class="name">
  <strong class="user"><em>info at stanzentech dot com</em></strong></a><a class="genanchor" href="#117423"> &para;</a><div class="date" title="2015-06-09 08:43"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117423">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br /></span><span class="comment">//<a href="http://php.net/manual/en/language.oop5.constants.php" rel="nofollow" target="_blank">http://php.net/manual/en/language.oop5.constants.php</a><br />/**<br /> * Constant name shouldn't start with $<br /> * Constant name may lower or uppercases.<br /> * Same constant name can be used as a property name but must start with $ symbol.<br /> * Constant doesn't available with $this-&gt; inside class definition.<br /> * Constant is available with self:: inside class definition.<br /> * Constant can't call with $this-&gt; outside class.<br /> * Constant is accessible with :: after "Class Name or Object".<br /> * <br /> */<br /></span><span class="keyword">class </span><span class="default">MyClass<br /></span><span class="keyword">{&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">// Parse error: syntax error, unexpected '$CONSTANT' (T_VARIABLE), expecting identifier (T_STRING) in constant.php<br />&nbsp; &nbsp; //const $CONSTANT&nbsp; &nbsp; &nbsp; =&nbsp;&nbsp; 'constant named "CONSTANT" ';<br />&nbsp; <br />&nbsp; &nbsp; </span><span class="keyword">const </span><span class="default">CONSTANT&nbsp; &nbsp; &nbsp; </span><span class="keyword">=&nbsp;&nbsp; </span><span class="string">'constant named "CONSTANT" '</span><span class="keyword">;<br />&nbsp; &nbsp; const </span><span class="default">small&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="keyword">=&nbsp;&nbsp; </span><span class="string">'constant named "small" '</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public </span><span class="default">$small&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">=&nbsp;&nbsp; </span><span class="string">'SAME CONTSNAT NAME AS PROPERTIES.'</span><span class="keyword">;&nbsp; <br /><br />&nbsp; &nbsp; </span><span class="comment">//Fatal error: Cannot redefine class constant MyClass::small in constant.php<br />&nbsp; &nbsp; // const small&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; =&nbsp;&nbsp; 'constant named "small" ';<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="keyword">function </span><span class="default">showConstant</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo&nbsp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">CONSTANT </span><span class="keyword">. </span><span class="string">"&lt;br&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//echo $this-&gt;CONSTANT . "&lt;br&gt;"; // Notice: Undefined property: MyClass::$CONSTANT in constant.php<br />&nbsp; &nbsp; </span><span class="keyword">}<br />}<br /><br /></span><span class="default">$class&nbsp; &nbsp; &nbsp; </span><span class="keyword">=&nbsp;&nbsp; new </span><span class="default">MyClass</span><span class="keyword">();<br /></span><span class="default">$class</span><span class="keyword">-&gt;</span><span class="default">showConstant</span><span class="keyword">();<br /><br /></span><span class="comment">//Notice: Undefined property: MyClass::$CONSTANT in constant.php<br />//echo $class-&gt;CONSTANT."&lt;br&gt;"; <br /><br /></span><span class="keyword">echo </span><span class="default">$class</span><span class="keyword">-&gt;</span><span class="default">small</span><span class="keyword">.</span><span class="string">"&lt;br&gt;"</span><span class="keyword">;&nbsp; </span><span class="comment">// SAME CONTSNAT NAME AS PROPERTIES.<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113547">  <div class="votes">
    <div id="Vu113547">
    <a href="/manual/vote-note.php?id=113547&amp;page=language.oop5.constants&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113547">
    <a href="/manual/vote-note.php?id=113547&amp;page=language.oop5.constants&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113547" title="38% like this...">
    -7
    </div>
  </div>
  <a href="#113547" class="name">
  <strong class="user"><em>jaimz at vertigolabs dot org</em></strong></a><a class="genanchor" href="#113547"> &para;</a><div class="date" title="2013-10-28 06:01"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113547">
<div class="phpcode"><code><span class="html">
I thought it would be relevant to point out that with php 5.5, you can not use self::class, static::class, or parent::class to produce a FQN. Doing so produces a PHP Parse error:<br /><br />"PHP Parse error:&nbsp; syntax error, unexpected 'class' (T_CLASS), expecting variable (T_VARIABLE) or '$'"<br /><br />It would be nice if you could do this however.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121390">  <div class="votes">
    <div id="Vu121390">
    <a href="/manual/vote-note.php?id=121390&amp;page=language.oop5.constants&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121390">
    <a href="/manual/vote-note.php?id=121390&amp;page=language.oop5.constants&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121390" title="33% like this...">
    -1
    </div>
  </div>
  <a href="#121390" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#121390"> &para;</a><div class="date" title="2017-07-17 07:40"><strong>4 months ago</strong></div>
  <div class="text" id="Hcom121390">
<div class="phpcode"><code><span class="html">
Before version 7.1.0 you couldn't write something like this:<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">foo</span><span class="keyword">{<br /><br />private const </span><span class="default">myvar </span><span class="keyword">= </span><span class="default">13</span><span class="keyword">;<br />...<br />}<br /></span><span class="default">?&gt;<br /></span><br />and an if&nbsp; with version_compare isn't also allowed how could i write the code for it so the class is compatible from 5.6 - 7.1.0?<br /><br />Also I don't understand which are the advantages of modifying the class scope of a constant because constant couldn't be change at runtime.<br /><br />Maybe someone could clarify this</span>
</code></div>
  </div>
 </div>
  <div class="note" id="100909">  <div class="votes">
    <div id="Vu100909">
    <a href="/manual/vote-note.php?id=100909&amp;page=language.oop5.constants&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd100909">
    <a href="/manual/vote-note.php?id=100909&amp;page=language.oop5.constants&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V100909" title="37% like this...">
    -8
    </div>
  </div>
  <a href="#100909" class="name">
  <strong class="user"><em>jakub dot lopuszanski at nasza-klasa dot pl</em></strong></a><a class="genanchor" href="#100909"> &para;</a><div class="date" title="2010-11-14 11:20"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom100909">
<div class="phpcode"><code><span class="html">
[Editor's note: that behavior has changed as of PHP 7.0.0, though.]<br /><br />Suprisingly consts are lazy bound even though you use self instead of static:<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">A</span><span class="keyword">{<br />&nbsp; const </span><span class="default">X</span><span class="keyword">=</span><span class="default">1</span><span class="keyword">;<br />&nbsp; const </span><span class="default">Y</span><span class="keyword">=</span><span class="default">self</span><span class="keyword">::</span><span class="default">X</span><span class="keyword">;<br />}<br />class </span><span class="default">B </span><span class="keyword">extends </span><span class="default">A</span><span class="keyword">{<br />&nbsp; const </span><span class="default">X</span><span class="keyword">=</span><span class="default">1.0</span><span class="keyword">;<br />}<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">B</span><span class="keyword">::</span><span class="default">Y</span><span class="keyword">); </span><span class="comment">// float(1.0)<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.oop5.constants&amp;redirect=http://php.net/manual/en/language.oop5.constants.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.oop5.php">Classes and Objects</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="oop5.intro.php" title="Introduction">Introduction</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.basic.php" title="The Basics">The Basics</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.properties.php" title="Properties">Properties</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.oop5.constants.php" title="Class Constants">Class Constants</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.autoload.php" title="Autoloading Classes">Autoloading Classes</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.decon.php" title="Constructors and Destructors">Constructors and Destructors</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.visibility.php" title="Visibility">Visibility</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.inheritance.php" title="Object Inheritance">Object Inheritance</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.paamayim-nekudotayim.php" title="Scope Resolution Operator (::)">Scope Resolution Operator (::)</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.static.php" title="Static Keyword">Static Keyword</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.abstract.php" title="Class Abstraction">Class Abstraction</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.interfaces.php" title="Object Interfaces">Object Interfaces</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.traits.php" title="Traits">Traits</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.anonymous.php" title="Anonymous classes">Anonymous classes</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.overloading.php" title="Overloading">Overloading</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.iterations.php" title="Object Iteration">Object Iteration</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.magic.php" title="Magic Methods">Magic Methods</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.final.php" title="Final Keyword">Final Keyword</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.cloning.php" title="Object Cloning">Object Cloning</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.object-comparison.php" title="Comparing Objects">Comparing Objects</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.typehinting.php" title="Type Hinting">Type Hinting</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.late-static-bindings.php" title="Late Static Bindings">Late Static Bindings</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.references.php" title="Objects and references">Objects and references</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.serialization.php" title="Object Serialization">Object Serialization</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.changelog.php" title="OOP Changelog">OOP Changelog</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

