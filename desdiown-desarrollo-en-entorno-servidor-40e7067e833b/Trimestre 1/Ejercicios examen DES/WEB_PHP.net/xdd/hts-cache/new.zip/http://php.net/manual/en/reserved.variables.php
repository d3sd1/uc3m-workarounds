<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Predefined Variables - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/reserved.variables.php">
 <link rel="shorturl" href="http://php.net/manual/en/reserved.variables.php">
 <link rel="alternate" href="http://php.net/manual/en/reserved.variables.php" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/langref.php">
 <link rel="prev" href="http://php.net/manual/en/language.references.spot.php">
 <link rel="next" href="http://php.net/manual/en/language.variables.superglobals.php">

 <link rel="alternate" href="http://php.net/manual/en/reserved.variables.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/reserved.variables.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/reserved.variables.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/reserved.variables.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/reserved.variables.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/reserved.variables.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/reserved.variables.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/reserved.variables.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/reserved.variables.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/reserved.variables.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/reserved.variables.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.variables.superglobals.php">
          Superglobals &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.references.spot.php">
          &laquo; Spotting References        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/reserved.variables.php' selected="selected">English</option>
            <option value='pt_BR/reserved.variables.php'>Brazilian Portuguese</option>
            <option value='zh/reserved.variables.php'>Chinese (Simplified)</option>
            <option value='fr/reserved.variables.php'>French</option>
            <option value='de/reserved.variables.php'>German</option>
            <option value='ja/reserved.variables.php'>Japanese</option>
            <option value='ro/reserved.variables.php'>Romanian</option>
            <option value='ru/reserved.variables.php'>Russian</option>
            <option value='es/reserved.variables.php'>Spanish</option>
            <option value='tr/reserved.variables.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/reserved.variables.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=reserved.variables">Report a Bug</a>
    </div>
  </div><div id="reserved.variables" class="reference">
 <h1 class="title">Predefined Variables</h1>

 <div class="partintro">

  <p class="para">
   PHP provides a large number of predefined variables to all scripts. The
   variables represent everything from
   <a href="language.variables.external.php" class="link">external variables</a> to
   built-in environment variables, last error messages to last retrieved
   headers.
  </p>
  
  <p class="para">
   See also the FAQ titled
   &quot;<a href="faq.using.php#faq.register-globals" class="link">How does register_globals affect me?</a>&quot;
  </p>

 </div>

 



 



 



 



 



 



 



 



 



 



 



 



 



 



 



 



 



 



 



 



 



 



 



 



 



 



 



 



 



 




<h2>Table of Contents</h2><ul class="chunklist chunklist_reference"><li><a href="language.variables.superglobals.php">Superglobals</a> — Superglobals are built-in variables that are always available in all scopes</li><li><a href="reserved.variables.globals.php">$GLOBALS</a> — References all variables available in global scope</li><li><a href="reserved.variables.server.php">$_SERVER</a> — Server and execution environment information</li><li><a href="reserved.variables.get.php">$_GET</a> — HTTP GET variables</li><li><a href="reserved.variables.post.php">$_POST</a> — HTTP POST variables</li><li><a href="reserved.variables.files.php">$_FILES</a> — HTTP File Upload variables</li><li><a href="reserved.variables.request.php">$_REQUEST</a> — HTTP Request variables</li><li><a href="reserved.variables.session.php">$_SESSION</a> — Session variables</li><li><a href="reserved.variables.environment.php">$_ENV</a> — Environment variables</li><li><a href="reserved.variables.cookies.php">$_COOKIE</a> — HTTP Cookies</li><li><a href="reserved.variables.phperrormsg.php">$php_errormsg</a> — The previous error message</li><li><a href="reserved.variables.httprawpostdata.php">$HTTP_RAW_POST_DATA</a> — Raw POST data</li><li><a href="reserved.variables.httpresponseheader.php">$http_response_header</a> — HTTP response headers</li><li><a href="reserved.variables.argc.php">$argc</a> — The number of arguments passed to script</li><li><a href="reserved.variables.argv.php">$argv</a> — Array of arguments passed to script</li></ul>
</div>

<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=reserved.variables&amp;redirect=http://php.net/manual/en/reserved.variables.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">44 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="55068">  <div class="votes">
    <div id="Vu55068">
    <a href="/manual/vote-note.php?id=55068&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd55068">
    <a href="/manual/vote-note.php?id=55068&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V55068" title="62% like this...">
    33
    </div>
  </div>
  <a href="#55068" class="name">
  <strong class="user"><em>New York PHP</em></strong></a><a class="genanchor" href="#55068"> &para;</a><div class="date" title="2005-07-24 06:59"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom55068">
<div class="phpcode"><code><span class="html">
Warning: $_SERVER['PHP_SELF'] can include arbitrary user input. The documentation should be updated to reflect this.<br /><br />The request "<a href="http://example.com/info.php/attack%20here" rel="nofollow" target="_blank">http://example.com/info.php/attack%20here</a>" will run /info.php, but in Apache $_SERVER['PHP_SELF'] will equal "/info.php/attack here". This is a feature, but it means that PHP_SELF must be treated as user input.<br /><br />The attack string could contain urlencoded HTML and JavaScript (cross-site scripting) or it could contain urlencoded linebreaks (HTTP response-splitting).<br /><br />The use of $_SERVER['SCRIPT_NAME'] is recommended instead.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="57325">  <div class="votes">
    <div id="Vu57325">
    <a href="/manual/vote-note.php?id=57325&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd57325">
    <a href="/manual/vote-note.php?id=57325&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V57325" title="63% like this...">
    6
    </div>
  </div>
  <a href="#57325" class="name">
  <strong class="user"><em>drew dot griffiths at clare dot net</em></strong></a><a class="genanchor" href="#57325"> &para;</a><div class="date" title="2005-09-30 08:51"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom57325">
<div class="phpcode"><code><span class="html">
Re: You can take advantage of 404 error to an usable redirection using REQUEST_URI ...<br /><br />Whilst this is effective, a line in the .htaccess such as:<br /><br />RewriteEngine On<br />RewriteRule ^profiles/([A-Za-z0-9-]+) showprofile.php?profile=$1 [L,NC,QSA]<br /><br />will throw the requested profile in a variable $profile to the showprofile.php page.&nbsp; <br /><br />You can further enhance the url (e.g <a href="http://servername/profiles/Jerry/homeaddress/index.htm" rel="nofollow" target="_blank">http://servername/profiles/Jerry/homeaddress/index.htm</a>) and the second variable value homeaddress becomes available in $url_array[3] when used below $url_array=explode("/",$_SERVER['REQUEST_URI']);&nbsp;&nbsp; <br /><br />Hope this helps - Works well for me<br /><br />Drew</span>
</code></div>
  </div>
 </div>
  <div class="note" id="37982">  <div class="votes">
    <div id="Vu37982">
    <a href="/manual/vote-note.php?id=37982&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd37982">
    <a href="/manual/vote-note.php?id=37982&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V37982" title="59% like this...">
    6
    </div>
  </div>
  <a href="#37982" class="name">
  <strong class="user"><em>josh,endquote,com</em></strong></a><a class="genanchor" href="#37982"> &para;</a><div class="date" title="2003-12-03 03:54"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom37982">
<div class="phpcode"><code><span class="html">
Running PHP 4.3 under IIS 5 on Windows XP, there is no $_SERVER['REQUEST_URI'] variable. This seems to fix it:<br /><br />if(!isset($_SERVER['REQUEST_URI'])) {<br />&nbsp; &nbsp; $_SERVER['REQUEST_URI'] = substr($_SERVER['argv'][0], strpos($_SERVER['argv'][0], ';') + 1);<br />}</span>
</code></div>
  </div>
 </div>
  <div class="note" id="49316">  <div class="votes">
    <div id="Vu49316">
    <a href="/manual/vote-note.php?id=49316&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd49316">
    <a href="/manual/vote-note.php?id=49316&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V49316" title="57% like this...">
    3
    </div>
  </div>
  <a href="#49316" class="name">
  <strong class="user"><em>marcus at lastcraft dot com</em></strong></a><a class="genanchor" href="#49316"> &para;</a><div class="date" title="2005-01-23 04:02"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom49316">
<div class="phpcode"><code><span class="html">
The variable $php_errormsg is not populated if you have XDebug running.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="62214">  <div class="votes">
    <div id="Vu62214">
    <a href="/manual/vote-note.php?id=62214&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd62214">
    <a href="/manual/vote-note.php?id=62214&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V62214" title="56% like this...">
    3
    </div>
  </div>
  <a href="#62214" class="name">
  <strong class="user"><em>nathan</em></strong></a><a class="genanchor" href="#62214"> &para;</a><div class="date" title="2006-02-22 08:05"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom62214">
<div class="phpcode"><code><span class="html">
Also on using IPs to look up country &amp; city, note that what you get might not be entirely accurate.&nbsp; If their ISP is based in a different city or province/state, the IPs may be owned by the head office, and used across several areas.&nbsp; <br />You also have rarer situations where they might be SSHed into another server, on the road, at work, at a friend's...&nbsp; It's a nice idea, but as the example code shows, it should only be used to set defaults.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="64443">  <div class="votes">
    <div id="Vu64443">
    <a href="/manual/vote-note.php?id=64443&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd64443">
    <a href="/manual/vote-note.php?id=64443&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V64443" title="56% like this...">
    3
    </div>
  </div>
  <a href="#64443" class="name">
  <strong class="user"><em>Ben XO</em></strong></a><a class="genanchor" href="#64443"> &para;</a><div class="date" title="2006-04-14 06:18"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom64443">
<div class="phpcode"><code><span class="html">
So you have an application in your web space, with a URL such as this:<br /><br /><a href="http://&lt;host&gt;/&lt;installation_path&gt;/" rel="nofollow" target="_blank">http://&lt;host&gt;/&lt;installation_path&gt;/</a><br /><br />and pages such as<br /><br /><a href="http://&lt;host&gt;/&lt;installation_path&gt;/subfolder1/subfolder2/page.php" rel="nofollow" target="_blank">http://&lt;host&gt;/&lt;installation_path&gt;/subfolder1/subfolder2/page.php</a><br /><br />You have a file called config.php in &lt;installation_path&gt; which is include()d by all pages (in subfolders or not).<br /><br />How to work out &lt;installation_path&gt; without hard-coding it into a config file? <br /><br /><span class="default">&lt;?php<br /><br /></span><span class="comment">// this is config.php, and it is in &lt;installation_path&gt;<br />// it is included by &lt;installation_path&gt;/page.php<br />// it is included by &lt;installation_path&gt;/subfolder/page2.php<br />// etc<br /><br /></span><span class="default">$_REAL_SCRIPT_DIR </span><span class="keyword">= </span><span class="default">realpath</span><span class="keyword">(</span><span class="default">dirname</span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'SCRIPT_FILENAME'</span><span class="keyword">])); </span><span class="comment">// filesystem path of this page's directory (page.php)<br /></span><span class="default">$_REAL_BASE_DIR </span><span class="keyword">= </span><span class="default">realpath</span><span class="keyword">(</span><span class="default">dirname</span><span class="keyword">(</span><span class="default">__FILE__</span><span class="keyword">)); </span><span class="comment">// filesystem path of this file's directory (config.php)<br /></span><span class="default">$_MY_PATH_PART </span><span class="keyword">= </span><span class="default">substr</span><span class="keyword">( </span><span class="default">$_REAL_SCRIPT_DIR</span><span class="keyword">, </span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$_REAL_BASE_DIR</span><span class="keyword">)); </span><span class="comment">// just the subfolder part between &lt;installation_path&gt; and the page<br /><br /></span><span class="default">$INSTALLATION_PATH </span><span class="keyword">= </span><span class="default">$_MY_PATH_PART<br />&nbsp; &nbsp; </span><span class="keyword">? </span><span class="default">substr</span><span class="keyword">( </span><span class="default">dirname</span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'SCRIPT_NAME'</span><span class="keyword">]), </span><span class="default">0</span><span class="keyword">, -</span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$_MY_PATH_PART</span><span class="keyword">) )<br />&nbsp; &nbsp; : </span><span class="default">dirname</span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'SCRIPT_NAME'</span><span class="keyword">])<br />; </span><span class="comment">// we subtract the subfolder part from the end of &lt;installation_path&gt;, leaving us with just &lt;installation_path&gt; :)<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="49964">  <div class="votes">
    <div id="Vu49964">
    <a href="/manual/vote-note.php?id=49964&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd49964">
    <a href="/manual/vote-note.php?id=49964&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V49964" title="56% like this...">
    3
    </div>
  </div>
  <a href="#49964" class="name">
  <strong class="user"><em>Gregory Boshoff</em></strong></a><a class="genanchor" href="#49964"> &para;</a><div class="date" title="2005-02-13 04:19"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom49964">
<div class="phpcode"><code><span class="html">
The Environment variable $ENV is useful for coding portable platform specific application constants. <br /><br />// Define a Windows or else Linux root directory path<br />$_ENV['OS'] == 'Windows_NT' ? $path = 'L:\\www\\' : $path = ' /var/www/';<br /><br />define('PATH', $path);<br /><br />echo PATH;</span>
</code></div>
  </div>
 </div>
  <div class="note" id="53617">  <div class="votes">
    <div id="Vu53617">
    <a href="/manual/vote-note.php?id=53617&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd53617">
    <a href="/manual/vote-note.php?id=53617&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V53617" title="53% like this...">
    3
    </div>
  </div>
  <a href="#53617" class="name">
  <strong class="user"><em>mfyahya at gmail dot com</em></strong></a><a class="genanchor" href="#53617"> &para;</a><div class="date" title="2005-06-07 06:33"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom53617">
<div class="phpcode"><code><span class="html">
If you use Apache's redirection features for custom error pages or whatever, the following Apache's REDIRECT variables are also available in $_SERVER:<br />$_SERVER['REDIRECT_UNIQUE_ID]' <br />$_SERVER['REDIRECT_SCRIPT_URL]' <br />$_SERVER['REDIRECT_SCRIPT_URI]' <br />$_SERVER['REDIRECT_SITE_ROOT]' <br />$_SERVER['REDIRECT_SITE_HTMLROOT]' <br />$_SERVER['REDIRECT_SITE_CGIROOT]' <br />$_SERVER['REDIRECT_STATUS]' <br />$_SERVER['REDIRECT_QUERY_STRING]' <br />$_SERVER['REDIRECT_URL]' <br /><br />I'm not sure if this is a complete list though</span>
</code></div>
  </div>
 </div>
  <div class="note" id="46658">  <div class="votes">
    <div id="Vu46658">
    <a href="/manual/vote-note.php?id=46658&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd46658">
    <a href="/manual/vote-note.php?id=46658&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V46658" title="54% like this...">
    2
    </div>
  </div>
  <a href="#46658" class="name">
  <strong class="user"><em>mrnopersonality at yahoo dot com</em></strong></a><a class="genanchor" href="#46658"> &para;</a><div class="date" title="2004-10-19 08:13"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom46658">
<div class="phpcode"><code><span class="html">
Nothing about the message-body ...<br /><br />You can get cookies, session variables, headers, the request-uri , the request method, etc but not the message body. You may want it sometimes when your page is to be requested with the POST method.<br /><br />Maybe they should have mentioned $HTTP_RAW_POST_DATA or php://stdin</span>
</code></div>
  </div>
 </div>
  <div class="note" id="74040">  <div class="votes">
    <div id="Vu74040">
    <a href="/manual/vote-note.php?id=74040&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd74040">
    <a href="/manual/vote-note.php?id=74040&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V74040" title="53% like this...">
    2
    </div>
  </div>
  <a href="#74040" class="name">
  <strong class="user"><em>danvasile at pentest dot ro</em></strong></a><a class="genanchor" href="#74040"> &para;</a><div class="date" title="2007-03-21 12:22"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom74040">
<div class="phpcode"><code><span class="html">
If you have problems with $_SERVER['HTTPS'], especially if it returns no values at all you should check the results of phpinfo(). It might not be listed at all. <br />Here is a solution to check and change, if necessary, to ssl/https that will work in all cases:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">if (</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'SERVER_PORT'</span><span class="keyword">]!=</span><span class="default">443</span><span class="keyword">) {<br /></span><span class="default">$sslport</span><span class="keyword">=</span><span class="default">443</span><span class="keyword">; </span><span class="comment">//whatever your ssl port is<br /></span><span class="default">$url </span><span class="keyword">= </span><span class="string">"<a href="https://" rel="nofollow" target="_blank">https://</a>"</span><span class="keyword">. </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'SERVER_NAME'</span><span class="keyword">] . </span><span class="string">":" </span><span class="keyword">. </span><span class="default">$sslport </span><span class="keyword">. </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'REQUEST_URI'</span><span class="keyword">];<br /></span><span class="default">header</span><span class="keyword">(</span><span class="string">"Location: </span><span class="default">$url</span><span class="string">"</span><span class="keyword">);<br />}<br /></span><span class="default">?&gt;<br /></span><br />Of course, this should be done before any html tag or php echo/print.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="65690">  <div class="votes">
    <div id="Vu65690">
    <a href="/manual/vote-note.php?id=65690&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd65690">
    <a href="/manual/vote-note.php?id=65690&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V65690" title="52% like this...">
    2
    </div>
  </div>
  <a href="#65690" class="name">
  <strong class="user"><em>jameslporter at gmail dot com</em></strong></a><a class="genanchor" href="#65690"> &para;</a><div class="date" title="2006-05-05 12:19"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom65690">
<div class="phpcode"><code><span class="html">
Refer to CanonicalName if you are not getting the ServerName in the $_SERVER[SERVER_NAME] variable....This was a pain to figure out for me...now it works as expected by turning canonical naming on.<br /><br /><a href="http://www.apacheref.com/ref/http_core/UseCanonicalName.html" rel="nofollow" target="_blank">http://www.apacheref.com/ref/http_core/UseCanonicalName.html</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="72572">  <div class="votes">
    <div id="Vu72572">
    <a href="/manual/vote-note.php?id=72572&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd72572">
    <a href="/manual/vote-note.php?id=72572&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V72572" title="52% like this...">
    1
    </div>
  </div>
  <a href="#72572" class="name">
  <strong class="user"><em>Joe Marty</em></strong></a><a class="genanchor" href="#72572"> &para;</a><div class="date" title="2007-01-24 11:53"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom72572">
<div class="phpcode"><code><span class="html">
I think it is very important to note that PHP will automatically replace dots ('.') AND spaces (' ') with underscores ('_') in any incoming POST or GET (or REQUEST) variables.<br /><br />This page notes the dot replacement, but not the space replacement:<br /><a href="http://us2.php.net/manual/en/language.variables.external.php" rel="nofollow" target="_blank">http://us2.php.net/manual/en/language.variables.external.php</a><br /><br />The reason is that '.' and ' ' are not valid characters to use in a variable name.&nbsp; This is confusing to many people, because most people use the format $_POST['name'] to access these values.&nbsp; In this case, the name is not used as a variable name but as an array index, in which those characters are valid.<br /><br />However, if the register_globals directive is set, these names must be used as variable names.&nbsp; As of now, PHP converts the names for these variables before inserting them into the external variable arrays, unfortunately - rather than leaving them as they are for the arrays and changing the names only for the variables set by register_globals.<br /><br />If you want to use:<br />&lt;input name="title for page3.php" type="text"&gt;<br /><br />The value you will get in your POST array, for isntance would be:<br />$_POST['title_for_page3_php']</span>
</code></div>
  </div>
 </div>
  <div class="note" id="54825">  <div class="votes">
    <div id="Vu54825">
    <a href="/manual/vote-note.php?id=54825&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd54825">
    <a href="/manual/vote-note.php?id=54825&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V54825" title="52% like this...">
    1
    </div>
  </div>
  <a href="#54825" class="name">
  <strong class="user"><em>daniel at softel dot jp</em></strong></a><a class="genanchor" href="#54825"> &para;</a><div class="date" title="2005-07-15 11:43"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom54825">
<div class="phpcode"><code><span class="html">
Note that $php_errormsg may contain a newline character. This can be problematic if you are trying to output it with a JavaScript "alert()" for example.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="63831">  <div class="votes">
    <div id="Vu63831">
    <a href="/manual/vote-note.php?id=63831&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd63831">
    <a href="/manual/vote-note.php?id=63831&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V63831" title="52% like this...">
    1
    </div>
  </div>
  <a href="#63831" class="name"><strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#63831"> &para;</a><div class="date" title="2006-03-31 09:56"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom63831">
<div class="phpcode"><code><span class="html">
I was unable to convince my hosting company to change their installation of PHP and therefore had to find my own way to computer $_SERVER["DOCUMENT_ROOT"].&nbsp; I eventually settled on the following, which is a combination of earlier notes (with some typos corrected):<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">if ( ! isset(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'DOCUMENT_ROOT'</span><span class="keyword">] ) )<br />&nbsp; </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'DOCUMENT_ROOT'</span><span class="keyword">] = </span><span class="default">str_replace</span><span class="keyword">( </span><span class="string">'\\'</span><span class="keyword">, </span><span class="string">'/'</span><span class="keyword">, </span><span class="default">substr</span><span class="keyword">(<br />&nbsp; &nbsp; </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'SCRIPT_FILENAME'</span><span class="keyword">], </span><span class="default">0</span><span class="keyword">, </span><span class="default">0</span><span class="keyword">-</span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_SELF'</span><span class="keyword">]) ) );<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="79359">  <div class="votes">
    <div id="Vu79359">
    <a href="/manual/vote-note.php?id=79359&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd79359">
    <a href="/manual/vote-note.php?id=79359&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V79359" title="51% like this...">
    1
    </div>
  </div>
  <a href="#79359" class="name">
  <strong class="user"><em>Nicolae Namolovan</em></strong></a><a class="genanchor" href="#79359"> &para;</a><div class="date" title="2007-11-22 11:49"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom79359">
<div class="phpcode"><code><span class="html">
SECURITY RISK !<br /><br />Never ever trust the values that comes from $_SERVER.<br /><br />HTTP_X_FORWARDED, HTTP_X_FORWARDED_FOR, HTTP_FORWARDED_FOR, HTTP_FORWARDED, etc.. can be spoofed !<br /><br />To get the ip of user, use only $_SERVER['REMOTE_ADDR'], otherwise the 'ip' of user can be easily changed by sending a HTTP_X_* header, so user can escape a ban or spoof a trusted ip.<br /><br />Of course this is well know, but I don't see it mentioned in these notes..<br /><br />If you use the ip only for tracking (not for any security features like banning or allow access to something by ip), you can also use HTTP_X_FORWARDED to get user's ip what are behind proxy.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="98485">  <div class="votes">
    <div id="Vu98485">
    <a href="/manual/vote-note.php?id=98485&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd98485">
    <a href="/manual/vote-note.php?id=98485&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V98485" title="50% like this...">
    0
    </div>
  </div>
  <a href="#98485" class="name">
  <strong class="user"><em>autofei at gmail dot com</em></strong></a><a class="genanchor" href="#98485"> &para;</a><div class="date" title="2010-06-17 05:57"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom98485">
<div class="phpcode"><code><span class="html">
if you try to run php through command line, for example: php.exe c:\AppServ\www\cron_cache.php. You better avoid to use $_SERVER['DOCUMENT_ROOT'], because it will return nothing. Instead, you can use dirname(__FILE__). The reason to use command line running php is set it as Windows Scheduled Tasks. I did not test under Linux environment, but might be same.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="78628">  <div class="votes">
    <div id="Vu78628">
    <a href="/manual/vote-note.php?id=78628&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd78628">
    <a href="/manual/vote-note.php?id=78628&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V78628" title="50% like this...">
    0
    </div>
  </div>
  <a href="#78628" class="name">
  <strong class="user"><em>jsan</em></strong></a><a class="genanchor" href="#78628"> &para;</a><div class="date" title="2007-10-19 12:39"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom78628">
<div class="phpcode"><code><span class="html">
@White-Gandalf: one can control this behavior by setting:<br /><br />UseCanonicalName On|Off<br /><br />in their apache config (at least, on *ix platforms).<br /><br />On =&gt; $_SERVER['SERVER_NAME'] is the ServerName var from either the global server or virtual host, whichever wraps the PHP app closest.<br /><br />Off =&gt; Whatever was in the Host: header sent by the client.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="63888">  <div class="votes">
    <div id="Vu63888">
    <a href="/manual/vote-note.php?id=63888&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd63888">
    <a href="/manual/vote-note.php?id=63888&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V63888" title="50% like this...">
    0
    </div>
  </div>
  <a href="#63888" class="name">
  <strong class="user"><em>todd dot kisov at yahoo dot com</em></strong></a><a class="genanchor" href="#63888"> &para;</a><div class="date" title="2006-04-03 02:11"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom63888">
<div class="phpcode"><code><span class="html">
To convert query string parameter values ($_GET, $_REQUEST), which include escaped Unicode values resulting from applying the JavaScript "escape" function to a Unicode string (%uNNNN%uNNNN%uNNNN) fast and simple is to use PECL JSON extension:<br /><br />function JavaScript_Unicode_URL_2_Str($js_uni_str) {<br />&nbsp; &nbsp; &nbsp; &nbsp; $res = preg_replace('/%u([[:alnum:]]{4})/', '\\u\1', $js_uni_str);<br />&nbsp; &nbsp; &nbsp; &nbsp; $res = str_replace('"', '\"', $res); // if in str "<br />&nbsp; &nbsp; &nbsp; &nbsp; $res = json_decode('["'.$res.'"]'); // JavaScrip array with string element<br />&nbsp; &nbsp; &nbsp; &nbsp; $res = $res[0];<br />&nbsp; &nbsp; &nbsp; &nbsp; $res = iconv('UTF-8', ini_get('default_charset'), $res);<br />&nbsp; &nbsp; &nbsp; &nbsp; return $res;<br />&nbsp; &nbsp; }</span>
</code></div>
  </div>
 </div>
  <div class="note" id="62708">  <div class="votes">
    <div id="Vu62708">
    <a href="/manual/vote-note.php?id=62708&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd62708">
    <a href="/manual/vote-note.php?id=62708&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V62708" title="50% like this...">
    0
    </div>
  </div>
  <a href="#62708" class="name">
  <strong class="user"><em>Aardvark</em></strong></a><a class="genanchor" href="#62708"> &para;</a><div class="date" title="2006-03-07 01:35"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom62708">
<div class="phpcode"><code><span class="html">
$_GET may not handle query string parameter values which include escaped Unicode values resulting from applying the JavaScript "escape" function to a Unicode string.<br />To handle this the query parameter value can be obtained&nbsp; using a function such as:<br /><br />function getQueryParameter ($strParam) {<br />&nbsp; $aParamList = explode('&amp;', $_SERVER['QUERY_STRING']);<br />&nbsp; $i = 0;<br />&nbsp; while ($i &lt; count($aParamList)) {<br />&nbsp; &nbsp; $aParam = split('=', $aParamList[$i]);<br />&nbsp; &nbsp; if ($strParam == $aParam[0]) {<br />&nbsp; &nbsp; &nbsp; return $aParam[1];<br />&nbsp; &nbsp; } <br />&nbsp; }<br />&nbsp; return "";<br />}<br /><br />or by directly building an array or query string values and then processing the parameter string using a function such as the "unescape" function which can be found at <a href="http://www.kanolife.com/escape/2006/03/unicode-url-escapes-in-php.html" rel="nofollow" target="_blank">http://www.kanolife.com/escape/2006/03/unicode-url-escapes-in-php.html</a> (or <a href="http://www.kanolife.com/escape/" rel="nofollow" target="_blank">http://www.kanolife.com/escape/</a> for related info).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="41295">  <div class="votes">
    <div id="Vu41295">
    <a href="/manual/vote-note.php?id=41295&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd41295">
    <a href="/manual/vote-note.php?id=41295&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V41295" title="50% like this...">
    0
    </div>
  </div>
  <a href="#41295" class="name">
  <strong class="user"><em>youdontmeanmuch [at] yahoo.com</em></strong></a><a class="genanchor" href="#41295"> &para;</a><div class="date" title="2004-04-05 09:20"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom41295">
<div class="phpcode"><code><span class="html">
Be carful when using $_SERVER['DOCUMENT_ROOT']; in your applications where you want to distribute them to other people with different server types. It isnt always supported by the webserver (IIS).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="102926">  <div class="votes">
    <div id="Vu102926">
    <a href="/manual/vote-note.php?id=102926&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd102926">
    <a href="/manual/vote-note.php?id=102926&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V102926" title="48% like this...">
    -1
    </div>
  </div>
  <a href="#102926" class="name">
  <strong class="user"><em>dusted at dusted dot dk</em></strong></a><a class="genanchor" href="#102926"> &para;</a><div class="date" title="2011-03-15 02:32"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom102926">
<div class="phpcode"><code><span class="html">
I use HTTP_X_FORWARDED_FOR because my webserver is behind a reverse proxy.<br />This can be made secure:<br />Configure the reverse proxy to block this field, and override it correctly.<br />Configure the apache server to only accept incoming connections from the reverse proxy.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="79811">  <div class="votes">
    <div id="Vu79811">
    <a href="/manual/vote-note.php?id=79811&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd79811">
    <a href="/manual/vote-note.php?id=79811&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V79811" title="47% like this...">
    -1
    </div>
  </div>
  <a href="#79811" class="name">
  <strong class="user"><em>php-net dot ucn dot extranet dot sys at dark-chiaki dot net</em></strong></a><a class="genanchor" href="#79811"> &para;</a><div class="date" title="2007-12-13 08:40"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom79811">
<div class="phpcode"><code><span class="html">
In addition to mfyahya at gmail dot com (2007-06-07 03:33):<br /><br />If You are working with the Apache module mod_rewrite and want to set some environment vars, the Apache manual says this vars could be accessed in CGI using $ENV{VAR}. In PHP You might want to write $_ENV['VAR'] to get the value of VAR, but You have to access if via $_SERVER, and in some different ways:<br /><br />1. Example: .htaccess and example.php<br /><br />RewriteEngine on<br />RewriteRule ^?var1=([^;]*);var2=([^;]*)$ \<br /> - [E=VAR1:$1,E=VAR2:$2]<br /><br /><span class="default">&lt;?php </span><span class="keyword">echo(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'VAR1'</span><span class="keyword">].</span><span class="string">"\r\n"<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">.</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'VAR2'</span><span class="keyword">]); </span><span class="default">?&gt;<br /></span><br />2. Example: .htaccess and index.php<br /><br />RewriteEngine on<br />RewriteRule ^index\.php$ - [L]<br />RewriteRule ?var1=([^;]*);var2=([^;]*)$ \<br /> index.php [E=VAR1:$1,E=VAR2:$2]<br /><br /><span class="default">&lt;?php </span><span class="keyword">echo(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'REDIRECT_VAR1'</span><span class="keyword">].</span><span class="string">"\r\n"<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">.</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'REDIRECT_VAR2'</span><span class="keyword">]); </span><span class="default">?&gt;<br /></span><br />Note: If any RewriteRule matches, an internal redirect than restarts (after the last defined rule, or immediately after the matched rule having a L-flag) checking the entire rule set again. For an internal redirect every defined VAR gets an 'REDIRECT_' prefix, i.e. VAR1 will be REDIRECT_VAR1, VAR2 will be REDIRECT_VAR2.<br /><br />Of course, You can (additionally) redefine the original VAR:<br /><br />RewriteEngine on<br />RewriteRule ^index\.php$ \<br /> - [E=VAR1:%{REDIRECT_VAR1},E=VAR2:%{REDIRECT_VAR2},L]<br />RewriteRule ?var1=([^;]*);var2=([^;]*)$ \<br /> index.php [E=VAR1:$1,E=VAR2:$2]<br /><br />With this, You will have $_SERVER['REDIRECT_VAR*'] -and- $_SERVER['VAR*'].<br /><br />***<br /><br />The given examples are only for explanation, in any case they are not intended to fit Your needs. The "\&lt;CRLF&gt;&lt;SP&gt;" in the .htaccess examples are only for display purpose, they should not occur in a real .htaccess file. The argument separator ';' in links can also be '&amp;', but this may cause some trouble with HTML/XHTML. See the following pages for more information about this issue:<br />- <a href="http://www.w3.org/TR/html4/appendix/notes.html#h-B.2.2" rel="nofollow" target="_blank">http://www.w3.org/TR/html4/appendix/notes.html#h-B.2.2</a><br />- <a href="http://www.w3.org/QA/2005/04/php-session" rel="nofollow" target="_blank">http://www.w3.org/QA/2005/04/php-session</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="62441">  <div class="votes">
    <div id="Vu62441">
    <a href="/manual/vote-note.php?id=62441&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd62441">
    <a href="/manual/vote-note.php?id=62441&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V62441" title="46% like this...">
    -2
    </div>
  </div>
  <a href="#62441" class="name">
  <strong class="user"><em>justin dot (nospam)george at gmail dot com</em></strong></a><a class="genanchor" href="#62441"> &para;</a><div class="date" title="2006-02-28 12:00"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom62441">
<div class="phpcode"><code><span class="html">
Note that it's a very, very bad idea to append to global variables in a loop, unless you really, really mean to do so in a global context. I just a while ago hung my server with a snippet of code like this:<br /><br /><span class="default">&lt;?php<br />$host&nbsp; </span><span class="keyword">= </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'HTTP_HOST'</span><span class="keyword">];<br /></span><span class="default">$uri&nbsp; </span><span class="keyword">= </span><span class="default">rtrim</span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_SELF'</span><span class="keyword">], </span><span class="string">"/\\"</span><span class="keyword">);<br /><br />&nbsp;&nbsp; <br /></span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">'SITE_ROOT'</span><span class="keyword">] = </span><span class="string">"<a href="http://" rel="nofollow" target="_blank">http://</a></span><span class="default">$host$uri</span><span class="string">"</span><span class="keyword">;<br /><br />while (</span><span class="default">$i </span><span class="keyword">&lt; </span><span class="default">somenumber</span><span class="keyword">)<br /></span><span class="default">readfile</span><span class="keyword">(</span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">'SITE_ROOT'</span><span class="keyword">] = </span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">'SITE_ROOT'</span><span class="keyword">] . </span><span class="string">'/this/file.php'</span><span class="keyword">);<br /></span><span class="default">$i</span><span class="keyword">++<br />}<br /></span><span class="default">?&gt;<br /></span><br />While it is an entertaining and unusual method of creating very long URLs and breaking servers, it's a pretty awesomely bad idea <br /><br />(Especially considering that the script in question ran concurrently with others of it's type, so the value in $GLOBALS['SITE_ROOT'] was unknown.)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="49402">  <div class="votes">
    <div id="Vu49402">
    <a href="/manual/vote-note.php?id=49402&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd49402">
    <a href="/manual/vote-note.php?id=49402&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V49402" title="43% like this...">
    -3
    </div>
  </div>
  <a href="#49402" class="name">
  <strong class="user"><em>niles AT atheos DOT net</em></strong></a><a class="genanchor" href="#49402"> &para;</a><div class="date" title="2005-01-26 12:51"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom49402">
<div class="phpcode"><code><span class="html">
If your having problems returning $_SERVER variables using apache, be sure you enable:<br /><br />ExtendedStatus On<br /><br />in your httpd.conf file.<br /><br />If it's off, then things like $_SERVER['HTTP_HOST'] won't be present.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="55337">  <div class="votes">
    <div id="Vu55337">
    <a href="/manual/vote-note.php?id=55337&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd55337">
    <a href="/manual/vote-note.php?id=55337&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V55337" title="42% like this...">
    -3
    </div>
  </div>
  <a href="#55337" class="name">
  <strong class="user"><em>Gregory Boshoff</em></strong></a><a class="genanchor" href="#55337"> &para;</a><div class="date" title="2005-07-31 02:41"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom55337">
<div class="phpcode"><code><span class="html">
$_SERVER['QUERY_STRING'] <br /><br />Does not contain XHTML 1.1 compliant ampersands i.e. &amp;amp;<br /><br />So you will need to do something like this if you are to use $_SERVER['QUERY_STRING'] in URL's.<br /><br />//&nbsp; XHTML 1.1 compliant ampersands <br />$_SERVER['QUERY_STRING'] = <br />str_replace(array('&amp;amp;', '&amp;'), array('&amp;', '&amp;amp;'), <br />$_SERVER['QUERY_STRING']);</span>
</code></div>
  </div>
 </div>
  <div class="note" id="78903">  <div class="votes">
    <div id="Vu78903">
    <a href="/manual/vote-note.php?id=78903&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd78903">
    <a href="/manual/vote-note.php?id=78903&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V78903" title="41% like this...">
    -3
    </div>
  </div>
  <a href="#78903" class="name">
  <strong class="user"><em>root at mantoru dot de</em></strong></a><a class="genanchor" href="#78903"> &para;</a><div class="date" title="2007-11-01 06:59"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom78903">
<div class="phpcode"><code><span class="html">
Note that some headers will be checked for validity (by Apache, I suppose) before showing up in $_SERVER -- If-Modified-Since for example.<br /><br /><span class="default">&lt;?php<br />$lastmod </span><span class="keyword">= </span><span class="default">gmdate</span><span class="keyword">(</span><span class="string">'D, d M Y H:i:s'</span><span class="keyword">, </span><span class="default">filemtime</span><span class="keyword">(</span><span class="string">'somefile'</span><span class="keyword">));<br /></span><span class="default">header</span><span class="keyword">(</span><span class="string">"Last-Modified: </span><span class="default">$lastmod</span><span class="string">"</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />This WON'T work, "GMT" is missing. Internet Explorer auto-fixes this by adding GMT, while Firefox resends this data as-is. (So an If-Modified-Since-header is sent, but neither shows up in $_SERVER nor in apache_request_headers()). This would be correct:<br /><br /><span class="default">&lt;?php<br />$lastmod </span><span class="keyword">= </span><span class="default">gmdate</span><span class="keyword">(</span><span class="string">'D, d M Y H:i:s'</span><span class="keyword">, </span><span class="default">filemtime</span><span class="keyword">(</span><span class="string">'somefile'</span><span class="keyword">)) . </span><span class="string">'GMT'</span><span class="keyword">;<br /></span><span class="default">header</span><span class="keyword">(</span><span class="string">"Last-Modified: </span><span class="default">$lastmod</span><span class="string">"</span><span class="keyword">);<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="71239">  <div class="votes">
    <div id="Vu71239">
    <a href="/manual/vote-note.php?id=71239&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd71239">
    <a href="/manual/vote-note.php?id=71239&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V71239" title="42% like this...">
    -4
    </div>
  </div>
  <a href="#71239" class="name">
  <strong class="user"><em>NeoSmart Technologies</em></strong></a><a class="genanchor" href="#71239"> &para;</a><div class="date" title="2006-11-18 06:22"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom71239">
<div class="phpcode"><code><span class="html">
The *only* way to make Request_URI work as a 100% Apache-Compliant server variable on IIS/Windows is to use an Isapi Filter - as documented at <a href="http://neosmart.net/blog/archives/291" rel="nofollow" target="_blank">http://neosmart.net/blog/archives/291</a> . The various steps mentioned below *completely* fail when a rewrite engine is employed, since IIS will *never* return a non-existent path (i.e. the actual pretty-URI used) via its server variables. <br /><br />This also applies to accessing index.php via a folder.<br />For instance, calls made to /folder/ will appear as /folder/index.php and not /folder/.<br /><br />The fix is to use the ISAPI filter provided at <a href="http://neosmart.net/blog/archives/291" rel="nofollow" target="_blank">http://neosmart.net/blog/archives/291</a><br /><br />You don't have to modify any of the actual scripts once this filter is in place - it automatically intercepts calls to REQUEST_URI and replaces them with the actual user-entered path.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="42327">  <div class="votes">
    <div id="Vu42327">
    <a href="/manual/vote-note.php?id=42327&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd42327">
    <a href="/manual/vote-note.php?id=42327&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V42327" title="41% like this...">
    -3
    </div>
  </div>
  <a href="#42327" class="name">
  <strong class="user"><em>david at grant dot org dot uk</em></strong></a><a class="genanchor" href="#42327"> &para;</a><div class="date" title="2004-05-12 05:34"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom42327">
<div class="phpcode"><code><span class="html">
$_SERVER['DOCUMENT_ROOT'] *is* supported by IIS, although only when running PHP as an ISAPI module.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="81059">  <div class="votes">
    <div id="Vu81059">
    <a href="/manual/vote-note.php?id=81059&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd81059">
    <a href="/manual/vote-note.php?id=81059&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V81059" title="41% like this...">
    -5
    </div>
  </div>
  <a href="#81059" class="name">
  <strong class="user"><em>spamtrap at scottydm dot com</em></strong></a><a class="genanchor" href="#81059"> &para;</a><div class="date" title="2008-02-12 06:15"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom81059">
<div class="phpcode"><code><span class="html">
I was a little frustrated by the fact that some of the _SERVER variables didn't seem to exist, so I did a bit of Googling and found the answer: many of these variables are supplied by the web server and not all web servers supply the same set of variables.<br /><br />I found a comparison between Apache v1.3.29 and IIS v5.1 on this page: <a href="http://koivi.com/apache-iis-php-server-array.php" rel="nofollow" target="_blank">http://koivi.com/apache-iis-php-server-array.php</a> Useful for those of us doing cross-platform development.<br /><br />While running experiments with different browsers I noticed some of the HTTP_* variables come and go depending on the browser used, or in the case of Opera by diddling the "user mode" (the widget that lets you look at a page as text only, etc.). For example: in IE and Opera HTTP_KEEP_ALIVE was missing, but was present in Firefox and Mozilla, and when I fiddled with Opera's "user mode" I got somethings called HTTP_TE and HTTP_CACHE_CONTROL.<br /><br />So, what you get is dependent on the web server AND the browser.<br /><br />I did see one IIS supplied variable not on that list: REQUEST_TIME, which seems to be in Unix timestamp format.<br /><br />While researching this I discovered there are plenty of people who have their phpinfo() page visible and indexed on a few search engines. For those who want to dig a bit deeper than that nice web page comparing Apache to IIS, looking at other peoples' phpinfo() pages could be useful. You get the version of PHP plus OS and web server they use, along with all the _SERVER variables. I found the highest percent of signal-to-noise by searching for "phpinfo()" (with the quotes) on Dogpile: <a href="http://www.dogpile.com/" rel="nofollow" target="_blank">http://www.dogpile.com/</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="76919">  <div class="votes">
    <div id="Vu76919">
    <a href="/manual/vote-note.php?id=76919&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd76919">
    <a href="/manual/vote-note.php?id=76919&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V76919" title="40% like this...">
    -4
    </div>
  </div>
  <a href="#76919" class="name">
  <strong class="user"><em>andres at andresj dot ath dot cx</em></strong></a><a class="genanchor" href="#76919"> &para;</a><div class="date" title="2007-08-05 09:41"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom76919">
<div class="phpcode"><code><span class="html">
To get the directory of the current script: (I think this is a little more resource-friendly, but then again with all the fast computers available, it does not matter so much...)<br />&lt;?<br />// For the script that is running:<br />$script_directory = substr($_SERVER['SCRIPT_FILENAME'], 0, strrpos($_SERVER['SCRIPT_FILENAME'], '/'));<br />// If your script is included from another script:<br />$included_directory = substr(__FILE__, 0, strrpos(__FILE__, '/'));<br />echo $script_directory . '&lt;br /&gt;';<br />echo $included_directory . '&lt;br /&gt;';<br />?&gt;<br />If you have a script that only includes the script written above in a directory called 'includer', and I access it from a web browser, this will be what I see:<br /><br />/path/to/includer/<br />/path/to/included/</span>
</code></div>
  </div>
 </div>
  <div class="note" id="115156">  <div class="votes">
    <div id="Vu115156">
    <a href="/manual/vote-note.php?id=115156&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115156">
    <a href="/manual/vote-note.php?id=115156&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115156" title="39% like this...">
    -5
    </div>
  </div>
  <a href="#115156" class="name">
  <strong class="user"><em>ca2</em></strong></a><a class="genanchor" href="#115156"> &para;</a><div class="date" title="2014-06-04 02:53"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115156">
<div class="phpcode"><code><span class="html">
Note $this and anything like it should be listed on this page.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="59245">  <div class="votes">
    <div id="Vu59245">
    <a href="/manual/vote-note.php?id=59245&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd59245">
    <a href="/manual/vote-note.php?id=59245&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V59245" title="40% like this...">
    -5
    </div>
  </div>
  <a href="#59245" class="name">
  <strong class="user"><em>chris at vault5 dot com</em></strong></a><a class="genanchor" href="#59245"> &para;</a><div class="date" title="2005-11-30 07:17"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom59245">
<div class="phpcode"><code><span class="html">
Since $_SERVER['DOCUMENT_ROOT'] is not always present, the following will provide it where $_SERVER dosen't.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">resolveDocumentRoot</span><span class="keyword">() {<br />&nbsp; &nbsp; </span><span class="default">$current_script </span><span class="keyword">= </span><span class="default">dirname</span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'SCRIPT_NAME'</span><span class="keyword">]);<br />&nbsp; &nbsp; </span><span class="default">$current_path&nbsp;&nbsp; </span><span class="keyword">= </span><span class="default">dirname</span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'SCRIPT_FILENAME'</span><span class="keyword">]);<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">/* work out how many folders we are away from document_root<br />&nbsp; &nbsp; &nbsp;&nbsp; by working out how many folders deep we are from the url.<br />&nbsp; &nbsp; &nbsp;&nbsp; this isn't fool proof */<br />&nbsp; &nbsp; </span><span class="default">$adjust </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">(</span><span class="string">"/"</span><span class="keyword">, </span><span class="default">$current_script</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$adjust </span><span class="keyword">= </span><span class="default">count</span><span class="keyword">(</span><span class="default">$adjust</span><span class="keyword">)-</span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">/* move up the path with ../ */<br />&nbsp; &nbsp; </span><span class="default">$traverse </span><span class="keyword">= </span><span class="default">str_repeat</span><span class="keyword">(</span><span class="string">"../"</span><span class="keyword">, </span><span class="default">$adjust</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$adjusted_path </span><span class="keyword">= </span><span class="default">sprintf</span><span class="keyword">(</span><span class="string">"%s/%s"</span><span class="keyword">, </span><span class="default">$current_path</span><span class="keyword">, </span><span class="default">$traverse</span><span class="keyword">);<br /><br />&nbsp; &nbsp; </span><span class="comment">/* real path expands the ../'s to the correct folder names */<br />&nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">realpath</span><span class="keyword">(</span><span class="default">$adjusted_path</span><span class="keyword">);&nbsp; &nbsp; <br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />It counts the number of folders down the path we are in the URL, then moves that number of folders up the current path... end result should be the document root :)<br /><br />It wont work with virtual folders or in any situation where the folder in the URL dosen't map to a real folder on the disk (like when using rewrites).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121445">  <div class="votes">
    <div id="Vu121445">
    <a href="/manual/vote-note.php?id=121445&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121445">
    <a href="/manual/vote-note.php?id=121445&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121445" title="33% like this...">
    -2
    </div>
  </div>
  <a href="#121445" class="name">
  <strong class="user"><em>cursodemicroagulhamentoonline at gmail dot com</em></strong></a><a class="genanchor" href="#121445"> &para;</a><div class="date" title="2017-07-27 07:57"><strong>4 months ago</strong></div>
  <div class="text" id="Hcom121445">
<div class="phpcode"><code><span class="html">
uma das coisar mais inovadoras do mercado da estética foi o microagulhamento: <a href="https://cursodemicroagulhamentoonline.com/" rel="nofollow" target="_blank">https://cursodemicroagulhamentoonline.com/</a><br />esse é um curso totalmente online e disponivel por m preço muito abaixo do que realmente vale.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="57693">  <div class="votes">
    <div id="Vu57693">
    <a href="/manual/vote-note.php?id=57693&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd57693">
    <a href="/manual/vote-note.php?id=57693&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V57693" title="36% like this...">
    -3
    </div>
  </div>
  <a href="#57693" class="name">
  <strong class="user"><em>webmaster at eclipse dot org</em></strong></a><a class="genanchor" href="#57693"> &para;</a><div class="date" title="2005-10-11 08:01"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom57693">
<div class="phpcode"><code><span class="html">
In response to tobias at net-clipping dot de<br /><br />It is not an Apache bug.&nbsp; Please read <a href="http://httpd.apache.org/docs/2.1/mod/core.html#errordocument" rel="nofollow" target="_blank">http://httpd.apache.org/docs/2.1/mod/core.html#errordocument</a> carefully (2.1 version here, 2.0 and 1.x is similar).&nbsp; <br /><br />In short, if your ErrorDocument start with <a href="http://" rel="nofollow" target="_blank">http://</a> Apache sends a redirect (302) to the error document, hence losing your original referer. If your ErrorDocument points to a relative path, 404 is maintained and so are your variables.<br /><br />From the Apache manual:<br /><br />"Note that when you specify an ErrorDocument&nbsp; that points to a remote URL (ie. anything with a method such as http in front of it), Apache will send a redirect to the client to tell it where to find the document, even if the document ends up being on the same server. This has several implications, the most important being that the client will not receive the original error status code, but instead will receive a redirect status code. This in turn can confuse web robots and other clients which try to determine if a URL is valid using the status code. In addition, if you use a remote URL in an ErrorDocument 401, the client will not know to prompt the user for a password since it will not receive the 401 status code. Therefore, if you use an ErrorDocument 401 directive then it must refer to a local document."<br /><br />D.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="82352">  <div class="votes">
    <div id="Vu82352">
    <a href="/manual/vote-note.php?id=82352&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd82352">
    <a href="/manual/vote-note.php?id=82352&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V82352" title="36% like this...">
    -5
    </div>
  </div>
  <a href="#82352" class="name">
  <strong class="user"><em>moochm@gmail</em></strong></a><a class="genanchor" href="#82352"> &para;</a><div class="date" title="2008-04-07 09:15"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom82352">
<div class="phpcode"><code><span class="html">
When using a php script like a remote function call, I find something like this useful for setting default parameters.<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">/**<br />/* combine _GET _POST _COOKIE variables with provided default values<br />/* defaults - associative array of default values<br />/* overwrite - if true, write result to _REQUEST superglobal<br />/* super_globals - array of super globals to fetch values from<br />**/<br /></span><span class="keyword">function </span><span class="default">get_params</span><span class="keyword">(</span><span class="default">$defaults </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">, </span><span class="default">$overwrite </span><span class="keyword">= </span><span class="default">false</span><span class="keyword">, </span><span class="default">$super_globals </span><span class="keyword">= array(</span><span class="string">'_GET'</span><span class="keyword">, </span><span class="string">'_POST'</span><span class="keyword">, </span><span class="string">'_COOKIE'</span><span class="keyword">))<br />{<br />&nbsp; &nbsp; </span><span class="default">$ret </span><span class="keyword">= array();<br /><br />&nbsp; &nbsp; </span><span class="comment">// fetch values from request<br />&nbsp; &nbsp; </span><span class="keyword">foreach(</span><span class="default">$super_globals </span><span class="keyword">as </span><span class="default">$sg</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach(</span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="default">$sg</span><span class="keyword">] as </span><span class="default">$k</span><span class="keyword">=&gt;</span><span class="default">$v</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$ret</span><span class="keyword">[</span><span class="default">$k</span><span class="keyword">] = </span><span class="default">$v</span><span class="keyword">;<br /><br />&nbsp; &nbsp; </span><span class="comment">// apply defaults for missing parameters<br />&nbsp; &nbsp; </span><span class="keyword">if(</span><span class="default">$defaults</span><span class="keyword">) foreach(</span><span class="default">$defaults </span><span class="keyword">as </span><span class="default">$k</span><span class="keyword">=&gt;</span><span class="default">$v</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; if(!isset(</span><span class="default">$ret</span><span class="keyword">[</span><span class="default">$k</span><span class="keyword">]))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$ret</span><span class="keyword">[</span><span class="default">$k</span><span class="keyword">] = </span><span class="default">$v</span><span class="keyword">;<br /><br />&nbsp; &nbsp; if(</span><span class="default">$overwrite</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$_REQUEST </span><span class="keyword">= </span><span class="default">$ret</span><span class="keyword">;<br /><br />&nbsp; &nbsp; return </span><span class="default">$ret</span><span class="keyword">;<br />}<br /><br /></span><span class="comment">// Example: page.php?style=modern<br /><br /></span><span class="default">$argv </span><span class="keyword">= </span><span class="default">get_params</span><span class="keyword">(array(</span><span class="string">'id'</span><span class="keyword">=&gt;</span><span class="default">42</span><span class="keyword">, </span><span class="string">'style'</span><span class="keyword">=&gt;</span><span class="string">'medieval'</span><span class="keyword">));<br /><br /></span><span class="comment">// $argv['id'] = 42<br />// $argv['style'] = 'modern'<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="79185">  <div class="votes">
    <div id="Vu79185">
    <a href="/manual/vote-note.php?id=79185&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd79185">
    <a href="/manual/vote-note.php?id=79185&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V79185" title="36% like this...">
    -5
    </div>
  </div>
  <a href="#79185" class="name">
  <strong class="user"><em>crescentfreshpot at yahoo dot com</em></strong></a><a class="genanchor" href="#79185"> &para;</a><div class="date" title="2007-11-14 10:03"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom79185">
<div class="phpcode"><code><span class="html">
In response to mathiasrav's getip() implementation on 28-Jul-2007, it should be noted that it:<br /><br />- assumes IPv4 addresses only<br />- returns $_SERVER['REMOTE_ADDR'] for any value of $_SERVER['HTTP_CLIENT_IP'] that matches 127.0.*.*, 192.168.*.* or 10.0.*.*, which is not desirable if you actually WANT the value of HTTP_CLIENT_IP<br /><br />dlyaza's prior snippet has neither of these problems.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="69741">  <div class="votes">
    <div id="Vu69741">
    <a href="/manual/vote-note.php?id=69741&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd69741">
    <a href="/manual/vote-note.php?id=69741&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V69741" title="37% like this...">
    -6
    </div>
  </div>
  <a href="#69741" class="name">
  <strong class="user"><em>Alexander Hars</em></strong></a><a class="genanchor" href="#69741"> &para;</a><div class="date" title="2006-09-19 02:16"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom69741">
<div class="phpcode"><code><span class="html">
If you want to use a form with multiple checkboxes (e.g. one per row) and assign the same name to each checkbox then the name needs to end with []. This tells PHP to put all checked values into an array variable. <br />For example:<br />&lt;input type="checkbox" name="id[]" value="value_1"&gt;<br />&lt;input type="checkbox" name="id[]" value="value_2"&gt;<br />..<br />&lt;input type="checkbox" name="id[]" value="value_x"&gt;<br /><br />You can now retrieve all values by using: <br />&nbsp;&nbsp; $values = $_POST['id'];<br /><br />If the name does not end with [], then only a single value will be available via the $_POST variable even if the user checks several checkboxes.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="78529">  <div class="votes">
    <div id="Vu78529">
    <a href="/manual/vote-note.php?id=78529&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd78529">
    <a href="/manual/vote-note.php?id=78529&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V78529" title="35% like this...">
    -6
    </div>
  </div>
  <a href="#78529" class="name">
  <strong class="user"><em>White-Gandalf</em></strong></a><a class="genanchor" href="#78529"> &para;</a><div class="date" title="2007-10-16 07:01"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom78529">
<div class="phpcode"><code><span class="html">
'SERVER_NAME' does NOT necessarily refer to the name of a virtual host or any other things defined in the apache config.<br />Instead it simply takes the value of the "Host:" entry of the HTTP-header sent by the client.<br />At least with apache version 2.2.5 on Windows.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="65190">  <div class="votes">
    <div id="Vu65190">
    <a href="/manual/vote-note.php?id=65190&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd65190">
    <a href="/manual/vote-note.php?id=65190&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V65190" title="34% like this...">
    -7
    </div>
  </div>
  <a href="#65190" class="name">
  <strong class="user"><em>tchamp</em></strong></a><a class="genanchor" href="#65190"> &para;</a><div class="date" title="2006-04-26 07:24"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom65190">
<div class="phpcode"><code><span class="html">
Be careful with HTTP_HOST behind a proxy server.&nbsp;&nbsp; Use these instead.<br />[HTTP_X_FORWARDED_FOR] <br />[HTTP_X_FORWARDED_HOST] <br />[HTTP_X_FORWARDED_SERVER]<br /><br />In my situation, I used [HTTP_X_FORWARDED_SERVER] in place of [HTTP_HOST] in order get the machine and hostname (www.myurl.com)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="48860">  <div class="votes">
    <div id="Vu48860">
    <a href="/manual/vote-note.php?id=48860&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd48860">
    <a href="/manual/vote-note.php?id=48860&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V48860" title="34% like this...">
    -8
    </div>
  </div>
  <a href="#48860" class="name">
  <strong class="user"><em>dotpointer</em></strong></a><a class="genanchor" href="#48860"> &para;</a><div class="date" title="2005-01-09 01:26"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom48860">
<div class="phpcode"><code><span class="html">
Running Xitami in Windows 2000 and PHP 4.3.7, nor PHP_SELF or SCRIPT_FILENAME is not availiable. Trying SCRIPT_NAME instead. Here is a function that returns the filename of a script without slashes. Good for use in HTML FORM ACTION=""-arguments...<br /><br />function getThisFile() {<br /><br /> /* try to use PHP_SELF first... */<br /> if (!empty($_SERVER['PHP_SELF'])) {<br />&nbsp; $strScript = $_SERVER['PHP_SELF'];<br /> /* otherwise, try SCRIPT_NAME */<br /> } else if (!empty($_SERVER['SCRIPT_NAME'])) {<br />&nbsp; $strScript = @$_SERVER['SCRIPT_NAME'];<br /> /* last resort - quit out and return nothing */<br /> } else {<br />&nbsp; return null;<br /> }<br /><br /> /* fint last frontslash in filename */<br /> $intLastSlash = strrpos($strScript, "/");<br /><br /> /* check if last backslash is more far away in filename */<br /> if (strrpos($strScript, "\\")&gt;$intLastSlash) {<br />&nbsp; /* if so, use the backslash position instead */<br />&nbsp; $intLastSlash = strrpos($strScript, "\\");<br /> }<br /><br /> /* cut out from the last slash and to the end of the filename */<br /> return substr($strScript, $intLastSlash+1, strlen($strScript));<br />}<br /><br />Tested on PHP 4.3.7/Win32 and PHP 5.0.3/Linux.<br />You may add more filepaths to the first if-section <br />to get more chances to catch up the filename if you can.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="54485">  <div class="votes">
    <div id="Vu54485">
    <a href="/manual/vote-note.php?id=54485&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd54485">
    <a href="/manual/vote-note.php?id=54485&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V54485" title="31% like this...">
    -7
    </div>
  </div>
  <a href="#54485" class="name">
  <strong class="user"><em>andy dot gajetzki at gmail dot com</em></strong></a><a class="genanchor" href="#54485"> &para;</a><div class="date" title="2005-07-05 06:22"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom54485">
<div class="phpcode"><code><span class="html">
I wanted to be able to embed a variable in the path. This is useful when, for example, images are rendered on the fly and you would like them to have different urls. <br /><br />Here is an illustration:<br /><br />www.somesite.com/image.php/IMAGETEXTHERE<br /><br />This would return an image with the text after "image.php/" contained in it. <br /><br />I could not recall the name of this feature, so I made a work-around in PHP...<br /><br />&lt;?&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; <br />function getPathVariables() {<br />&nbsp; &nbsp; &nbsp; &nbsp; $sPathPS = $_SERVER[PHP_SELF];<br />&nbsp; &nbsp; &nbsp; &nbsp; $sPathFS = __FILE__;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; $aPathPS = array_reverse(explode("/", $sPathPS));<br />&nbsp; &nbsp; &nbsp; &nbsp; $aPathFS = array_reverse(explode("/", $sPathFS));<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; $aImageArgs = array();<br />&nbsp; &nbsp; &nbsp; &nbsp; $x = 0;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; while ( $aPathPS[$x] != $aPathFS[$x] &amp;&amp; $aPathPS[$x] != $aPathFS[0] ) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; array_unshift($aImageArgs, $aPathPS[$x])&nbsp; &nbsp; &nbsp; &nbsp; ;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $x++;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; return $aImageArgs;<br /><br />}<br />?&gt;<br /><br />This function will return an array containing each "/" delimited portion of the path after the script name itself.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="53799">  <div class="votes">
    <div id="Vu53799">
    <a href="/manual/vote-note.php?id=53799&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd53799">
    <a href="/manual/vote-note.php?id=53799&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V53799" title="28% like this...">
    -6
    </div>
  </div>
  <a href="#53799" class="name">
  <strong class="user"><em>xangelusx at hotmail dot com</em></strong></a><a class="genanchor" href="#53799"> &para;</a><div class="date" title="2005-06-13 01:03"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom53799">
<div class="phpcode"><code><span class="html">
A note about the QUERY_STRING variable when using IIS:<br /><br />I have found that IIS does not handle large query strings gracefully when passed from PHP. In addition to truncating them to around 1024 kb, I have seen IIS actually add data from other server variables to the end of the truncated data. <br /><br />This occurred on Windows 2000 server running IIS 5.0 and PHP 4.3.8.&nbsp; The problem did not occur when handled by Apache, even on another Windows server.<br /><br />Note: I realize passing this much data is best accomplished using the POST method, which would avoid this problem all together. I'm merely detailing a problem that I came across.<br /><br />I have created a page that includes the (very long) query string that was used and some of the results that I saw while testing. It can be viewed at <a href="http://www.csb7.com/test/php_iis_qs_limit/." rel="nofollow" target="_blank">http://www.csb7.com/test/php_iis_qs_limit/.</a> I didn't want to include it here as it would stretch the page out significantly.<br /><br />~Chris Bloom</span>
</code></div>
  </div>
 </div>
  <div class="note" id="50420">  <div class="votes">
    <div id="Vu50420">
    <a href="/manual/vote-note.php?id=50420&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd50420">
    <a href="/manual/vote-note.php?id=50420&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V50420" title="26% like this...">
    -7
    </div>
  </div>
  <a href="#50420" class="name"><strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#50420"> &para;</a><div class="date" title="2005-02-27 06:41"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom50420">
<div class="phpcode"><code><span class="html">
Matt Johnson says that one should never urldecode() $_GET data. This is incorrect.<br /><br />If magic_quotes_gpc is turned off in php.ini, then you *do* need to urldecode() $_GET data.<br /><br />Having magic_quotes_gpc turned off is considered good practise.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="84025">  <div class="votes">
    <div id="Vu84025">
    <a href="/manual/vote-note.php?id=84025&amp;page=reserved.variables&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd84025">
    <a href="/manual/vote-note.php?id=84025&amp;page=reserved.variables&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V84025" title="23% like this...">
    -9
    </div>
  </div>
  <a href="#84025" class="name">
  <strong class="user"><em>gajillion at gmail dot com</em></strong></a><a class="genanchor" href="#84025"> &para;</a><div class="date" title="2008-06-24 09:08"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom84025">
<div class="phpcode"><code><span class="html">
@SilentChris at gmail dot com - I'm seeing the same thing but I'm starting to believe the issue is not PHP but Apache.&nbsp; It looks like Apache's rewrite module is double encoding strings with a '%' sign if they are followed by two or more other characters.&nbsp; So<br /><br />%25 translates correctly to '%'<br />%25b translates correctly to '%b'<br />%25ba translates incorrectly to � which when itself is run through urlencode translates to '%BA'.&nbsp; <br /><br />Further letters translate correctly.<br />%25bac produces '�c', etc.&nbsp; <br /><br />It only appears to happen on the first instance of %25 because further items are translated correctly.</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=reserved.variables&amp;redirect=http://php.net/manual/en/reserved.variables.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="langref.php">Language Reference</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.basic-syntax.php" title="Basic syntax">Basic syntax</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.php" title="Types">Types</a>
                        </li>
                          
                        <li class="">
                            <a href="language.variables.php" title="Variables">Variables</a>
                        </li>
                          
                        <li class="">
                            <a href="language.constants.php" title="Constants">Constants</a>
                        </li>
                          
                        <li class="">
                            <a href="language.expressions.php" title="Expressions">Expressions</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.php" title="Operators">Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.control-structures.php" title="Control Structures">Control Structures</a>
                        </li>
                          
                        <li class="">
                            <a href="language.functions.php" title="Functions">Functions</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.php" title="Classes and Objects">Classes and Objects</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.php" title="Namespaces">Namespaces</a>
                        </li>
                          
                        <li class="">
                            <a href="language.errors.php" title="Errors">Errors</a>
                        </li>
                          
                        <li class="">
                            <a href="language.exceptions.php" title="Exceptions">Exceptions</a>
                        </li>
                          
                        <li class="">
                            <a href="language.generators.php" title="Generators">Generators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.references.php" title="References Explained">References Explained</a>
                        </li>
                          
                        <li class="current">
                            <a href="reserved.variables.php" title="Predefined Variables">Predefined Variables</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.exceptions.php" title="Predefined Exceptions">Predefined Exceptions</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.interfaces.php" title="Predefined Interfaces and Classes">Predefined Interfaces and Classes</a>
                        </li>
                          
                        <li class="">
                            <a href="context.php" title="Context options and parameters">Context options and parameters</a>
                        </li>
                          
                        <li class="">
                            <a href="wrappers.php" title="Supported Protocols and Wrappers">Supported Protocols and Wrappers</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

