<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Object Cloning - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.oop5.cloning.php">
 <link rel="shorturl" href="http://php.net/oop5.cloning">
 <link rel="alternate" href="http://php.net/oop5.cloning" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.oop5.php">
 <link rel="prev" href="http://php.net/manual/en/language.oop5.final.php">
 <link rel="next" href="http://php.net/manual/en/language.oop5.object-comparison.php">

 <link rel="alternate" href="http://php.net/manual/en/language.oop5.cloning.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.oop5.cloning.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.oop5.cloning.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.oop5.cloning.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.oop5.cloning.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.oop5.cloning.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.oop5.cloning.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.oop5.cloning.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.oop5.cloning.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.oop5.cloning.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.oop5.cloning.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.oop5.object-comparison.php">
          Comparing Objects &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.oop5.final.php">
          &laquo; Final Keyword        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.oop5.php'>Classes and Objects</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.oop5.cloning.php' selected="selected">English</option>
            <option value='pt_BR/language.oop5.cloning.php'>Brazilian Portuguese</option>
            <option value='zh/language.oop5.cloning.php'>Chinese (Simplified)</option>
            <option value='fr/language.oop5.cloning.php'>French</option>
            <option value='de/language.oop5.cloning.php'>German</option>
            <option value='ja/language.oop5.cloning.php'>Japanese</option>
            <option value='ro/language.oop5.cloning.php'>Romanian</option>
            <option value='ru/language.oop5.cloning.php'>Russian</option>
            <option value='es/language.oop5.cloning.php'>Spanish</option>
            <option value='tr/language.oop5.cloning.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.oop5.cloning.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.oop5.cloning">Report a Bug</a>
    </div>
  </div><div id="language.oop5.cloning" class="sect1">
  <h2 class="title">Object Cloning</h2>
  
  <p class="para">
   Creating a copy of an object with fully replicated properties is not
   always the wanted behavior. A good example of the need for copy
   constructors, is if you have an object which represents a GTK window and the
   object holds the resource of this GTK window, when you create a duplicate
   you might want to create a new window with the same properties and have the
   new object hold the resource of the new window. Another example is if your
   object holds a reference to another object which it uses and when you
   replicate the parent object you want to create a new instance of this other
   object so that the replica has its own separate copy.
  </p>

  <p class="para">
   An object copy is created by using the <em class="emphasis">clone</em> keyword (which calls the
   object&#039;s <a href="language.oop5.cloning.php#object.clone" class="link">__clone()</a> method if possible).
   An object&#039;s <a href="language.oop5.cloning.php#object.clone" class="link">__clone()</a> method
   cannot be called directly.
  </p>

  <div class="informalexample">
   <div class="example-contents">
<div class="cdata"><pre>
$copy_of_object = clone $object;
</pre></div>
   </div>

  </div>

  <p class="para">
   When an object is cloned, PHP 5 will perform a shallow copy of all of the
   object&#039;s properties. Any properties that are references to other variables
   will remain references.
  </p>

  <div class="methodsynopsis dc-description" id="object.clone">
   <span class="type"><span class="type void">void</span></span> <span class="methodname"><strong>__clone</strong></span>
    ( <span class="methodparam">void</span>
   )</div>


  <p class="para">
   Once the cloning is complete, if a <a href="language.oop5.cloning.php#object.clone" class="link">__clone()</a> method is defined, then
   the newly created object&#039;s <a href="language.oop5.cloning.php#object.clone" class="link">__clone()</a> method will be called, to allow any
   necessary properties that need to be changed.
  </p>

  <div class="example" id="language.oop5.traits.static.ex2">
   <p><strong>Example #1 Cloning an object</strong></p>
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">SubObject<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;static&nbsp;</span><span style="color: #0000BB">$instances&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">0</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;</span><span style="color: #0000BB">$instance</span><span style="color: #007700">;<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">__construct</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">instance&nbsp;</span><span style="color: #007700">=&nbsp;++</span><span style="color: #0000BB">self</span><span style="color: #007700">::</span><span style="color: #0000BB">$instances</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">__clone</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">instance&nbsp;</span><span style="color: #007700">=&nbsp;++</span><span style="color: #0000BB">self</span><span style="color: #007700">::</span><span style="color: #0000BB">$instances</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br />class&nbsp;</span><span style="color: #0000BB">MyCloneable<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;</span><span style="color: #0000BB">$object1</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;</span><span style="color: #0000BB">$object2</span><span style="color: #007700">;<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;function&nbsp;</span><span style="color: #0000BB">__clone</span><span style="color: #007700">()<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;Force&nbsp;a&nbsp;copy&nbsp;of&nbsp;this-&gt;object,&nbsp;otherwise<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;it&nbsp;will&nbsp;point&nbsp;to&nbsp;same&nbsp;object.<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">object1&nbsp;</span><span style="color: #007700">=&nbsp;clone&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">object1</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br /></span><span style="color: #0000BB">$obj&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">MyCloneable</span><span style="color: #007700">();<br /><br /></span><span style="color: #0000BB">$obj</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">object1&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">SubObject</span><span style="color: #007700">();<br /></span><span style="color: #0000BB">$obj</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">object2&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">SubObject</span><span style="color: #007700">();<br /><br /></span><span style="color: #0000BB">$obj2&nbsp;</span><span style="color: #007700">=&nbsp;clone&nbsp;</span><span style="color: #0000BB">$obj</span><span style="color: #007700">;<br /><br /><br />print(</span><span style="color: #DD0000">"Original&nbsp;Object:\n"</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">print_r</span><span style="color: #007700">(</span><span style="color: #0000BB">$obj</span><span style="color: #007700">);<br /><br />print(</span><span style="color: #DD0000">"Cloned&nbsp;Object:\n"</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">print_r</span><span style="color: #007700">(</span><span style="color: #0000BB">$obj2</span><span style="color: #007700">);<br /><br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

   <div class="example-contents"><p>The above example will output:</p></div>
   <div class="example-contents screen">
<div class="cdata"><pre>
Original Object:
MyCloneable Object
(
    [object1] =&gt; SubObject Object
        (
            [instance] =&gt; 1
        )

    [object2] =&gt; SubObject Object
        (
            [instance] =&gt; 2
        )

)
Cloned Object:
MyCloneable Object
(
    [object1] =&gt; SubObject Object
        (
            [instance] =&gt; 3
        )

    [object2] =&gt; SubObject Object
        (
            [instance] =&gt; 2
        )

)
</pre></div>

   </div>

  </div>

  <p class="para">
   PHP 7.0.0 introduced the possibility to access a member of a freshly cloned
   object in a single expression:
  </p>
  <div class="example" id="language.oop5.traits.properties.example">
   <p><strong>Example #2 Access member of freshly cloned object</strong></p>
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$dateTime&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">DateTime</span><span style="color: #007700">();<br />echo&nbsp;(clone&nbsp;</span><span style="color: #0000BB">$dateTime</span><span style="color: #007700">)-&gt;</span><span style="color: #0000BB">format</span><span style="color: #007700">(</span><span style="color: #DD0000">'Y'</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

   <div class="example-contents"><p>The above example will output
something similar to:</p></div>
   <div class="example-contents screen">
<div class="cdata"><pre>
2016
</pre></div>
   </div>
  </div>

 </div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.oop5.cloning&amp;redirect=http://php.net/manual/en/language.oop5.cloning.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">15 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="72502">  <div class="votes">
    <div id="Vu72502">
    <a href="/manual/vote-note.php?id=72502&amp;page=language.oop5.cloning&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd72502">
    <a href="/manual/vote-note.php?id=72502&amp;page=language.oop5.cloning&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V72502" title="65% like this...">
    20
    </div>
  </div>
  <a href="#72502" class="name">
  <strong class="user"><em>MakariVerslund at gmail dot com</em></strong></a><a class="genanchor" href="#72502"> &para;</a><div class="date" title="2007-01-21 04:30"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom72502">
<div class="phpcode"><code><span class="html">
I ran into the same problem of an array of objects inside of an object that I wanted to clone all pointing to the same objects. However, I agreed that serializing the data was not the answer. It was relatively simple, really:<br /><br />public function __clone() {<br />&nbsp; &nbsp; foreach ($this-&gt;varName as &amp;$a) {<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach ($a as &amp;$b) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $b = clone $b;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />}<br /><br />Note, that I was working with a multi-dimensional array and I was not using the Key=&gt;Value pair system, but basically, the point is that if you use foreach, you need to specify that the copied data is to be accessed by reference.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="98297">  <div class="votes">
    <div id="Vu98297">
    <a href="/manual/vote-note.php?id=98297&amp;page=language.oop5.cloning&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd98297">
    <a href="/manual/vote-note.php?id=98297&amp;page=language.oop5.cloning&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V98297" title="66% like this...">
    17
    </div>
  </div>
  <a href="#98297" class="name">
  <strong class="user"><em>jojor at gmx dot net</em></strong></a><a class="genanchor" href="#98297"> &para;</a><div class="date" title="2010-06-07 01:47"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom98297">
<div class="phpcode"><code><span class="html">
Here is test script i wrote to test the behaviour of clone when i have arrays with primitive values in my class - as an additonal test of the note below by jeffrey at whinger dot nl<br /><br />&lt;pre&gt;<br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">MyClass </span><span class="keyword">{<br /><br />&nbsp; &nbsp; private </span><span class="default">$myArray </span><span class="keyword">= array();<br />&nbsp; &nbsp; function </span><span class="default">pushSomethingToArray</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">array_push</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">myArray</span><span class="keyword">, </span><span class="default">$var</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; function </span><span class="default">getArray</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">myArray</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />}<br /><br /></span><span class="comment">//push some values to the myArray of Mainclass<br /></span><span class="default">$myObj </span><span class="keyword">= new </span><span class="default">MyClass</span><span class="keyword">();<br /></span><span class="default">$myObj</span><span class="keyword">-&gt;</span><span class="default">pushSomethingToArray</span><span class="keyword">(</span><span class="string">'blue'</span><span class="keyword">);<br /></span><span class="default">$myObj</span><span class="keyword">-&gt;</span><span class="default">pushSomethingToArray</span><span class="keyword">(</span><span class="string">'orange'</span><span class="keyword">);<br /></span><span class="default">$myObjClone </span><span class="keyword">= clone </span><span class="default">$myObj</span><span class="keyword">;<br /></span><span class="default">$myObj</span><span class="keyword">-&gt;</span><span class="default">pushSomethingToArray</span><span class="keyword">(</span><span class="string">'pink'</span><span class="keyword">);<br /><br /></span><span class="comment">//testing<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$myObj</span><span class="keyword">-&gt;</span><span class="default">getArray</span><span class="keyword">());&nbsp; &nbsp;&nbsp; </span><span class="comment">//Array([0] =&gt; blue,[1] =&gt; orange,[2] =&gt; pink)<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$myObjClone</span><span class="keyword">-&gt;</span><span class="default">getArray</span><span class="keyword">());</span><span class="comment">//Array([0] =&gt; blue,[1] =&gt; orange)<br />//so array&nbsp; cloned <br /><br /></span><span class="default">?&gt;<br /></span>&lt;/pre&gt;</span>
</code></div>
  </div>
 </div>
  <div class="note" id="79886">  <div class="votes">
    <div id="Vu79886">
    <a href="/manual/vote-note.php?id=79886&amp;page=language.oop5.cloning&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd79886">
    <a href="/manual/vote-note.php?id=79886&amp;page=language.oop5.cloning&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V79886" title="62% like this...">
    11
    </div>
  </div>
  <a href="#79886" class="name">
  <strong class="user"><em>Hayley Watson</em></strong></a><a class="genanchor" href="#79886"> &para;</a><div class="date" title="2007-12-17 03:51"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom79886">
<div class="phpcode"><code><span class="html">
It should go without saying that if you have circular references, where a property of object A refers to object B while a property of B refers to A (or more indirect loops than that), then you'll be glad that clone does NOT automatically make a deep copy!<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">Foo<br /></span><span class="keyword">{<br />&nbsp; &nbsp; var </span><span class="default">$that</span><span class="keyword">;<br /><br />function </span><span class="default">__clone</span><span class="keyword">()<br />{<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">that </span><span class="keyword">= clone </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">that</span><span class="keyword">;<br />}<br /><br />}<br /><br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">Foo</span><span class="keyword">;<br /></span><span class="default">$b </span><span class="keyword">= new </span><span class="default">Foo</span><span class="keyword">;<br /></span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">that </span><span class="keyword">= </span><span class="default">$b</span><span class="keyword">;<br /></span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">that </span><span class="keyword">= </span><span class="default">$a</span><span class="keyword">;<br /><br /></span><span class="default">$c </span><span class="keyword">= clone </span><span class="default">$a</span><span class="keyword">;<br />echo </span><span class="string">'What happened?'</span><span class="keyword">;<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$c</span><span class="keyword">);</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119554">  <div class="votes">
    <div id="Vu119554">
    <a href="/manual/vote-note.php?id=119554&amp;page=language.oop5.cloning&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119554">
    <a href="/manual/vote-note.php?id=119554&amp;page=language.oop5.cloning&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119554" title="75% like this...">
    2
    </div>
  </div>
  <a href="#119554" class="name">
  <strong class="user"><em>yinzw at chuchujie dot com</em></strong></a><a class="genanchor" href="#119554"> &para;</a><div class="date" title="2016-07-05 01:10"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119554">
<div class="phpcode"><code><span class="html">
It's clearly depicted in the manual, about the mechanism of clone process:<br />- First, shallow copy: properties of references will keep references (refer to the same target/variable)<br />- Then, change content/property as requested (calling __clone method which is defined by user).<br /><br />To illustrate this process, the following example codes seems better, comparing the the original version:<br /><br />class SubObject<br />{<br />&nbsp; &nbsp; static $num_cons = 0;<br />&nbsp; &nbsp; static $num_clone = 0;<br /><br />&nbsp; &nbsp; public $construct_value;<br />&nbsp; &nbsp; public $clone_value;<br /><br />&nbsp; &nbsp; public function __construct() {<br />&nbsp; &nbsp; &nbsp; &nbsp; $this-&gt;construct_value = ++self::$num_cons;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function __clone() {<br />&nbsp; &nbsp; &nbsp; &nbsp; $this-&gt;clone_value = ++self::$num_clone;<br />&nbsp; &nbsp; }<br />}<br /><br />class MyCloneable<br />{<br />&nbsp; &nbsp; public $object1;<br />&nbsp; &nbsp; public $object2;<br /><br />&nbsp; &nbsp; function __clone()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; // 强制复制一份this-&gt;object， 否则仍然指向同一个对象<br />&nbsp; &nbsp; &nbsp; &nbsp; $this-&gt;object1 = clone $this-&gt;object1;<br />&nbsp; &nbsp; }<br />}<br /><br />$obj = new MyCloneable();<br /><br />$obj-&gt;object1 = new SubObject();<br />$obj-&gt;object2 = new SubObject();<br /><br />$obj2 = clone $obj;<br /><br />print("Original Object:\n");<br />print_r($obj);<br />echo '&lt;br&gt;';<br />print("Cloned Object:\n");<br />print_r($obj2);<br /><br />==================<br /><br />the output is as below<br /><br />Original Object:<br />MyCloneable Object<br />(<br />&nbsp; &nbsp; [object1] =&gt; SubObject Object<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [construct_value] =&gt; 1<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [clone_value] =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />&nbsp; &nbsp; [object2] =&gt; SubObject Object<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [construct_value] =&gt; 2<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [clone_value] =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />)<br />&lt;br&gt;Cloned Object:<br />MyCloneable Object<br />(<br />&nbsp; &nbsp; [object1] =&gt; SubObject Object<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [construct_value] =&gt; 1<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [clone_value] =&gt; 1<br />&nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />&nbsp; &nbsp; [object2] =&gt; SubObject Object<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [construct_value] =&gt; 2<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [clone_value] =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="51439">  <div class="votes">
    <div id="Vu51439">
    <a href="/manual/vote-note.php?id=51439&amp;page=language.oop5.cloning&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd51439">
    <a href="/manual/vote-note.php?id=51439&amp;page=language.oop5.cloning&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V51439" title="66% like this...">
    7
    </div>
  </div>
  <a href="#51439" class="name">
  <strong class="user"><em>jorge dot villalobos at gmail dot com</em></strong></a><a class="genanchor" href="#51439"> &para;</a><div class="date" title="2005-03-30 03:29"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom51439">
<div class="phpcode"><code><span class="html">
I think it's relevant to note that __clone is NOT an override. As the example shows, the normal cloning process always occurs, and it's the responsibility of the __clone method to "mend" any "wrong" action performed by it.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118877">  <div class="votes">
    <div id="Vu118877">
    <a href="/manual/vote-note.php?id=118877&amp;page=language.oop5.cloning&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118877">
    <a href="/manual/vote-note.php?id=118877&amp;page=language.oop5.cloning&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118877" title="64% like this...">
    4
    </div>
  </div>
  <a href="#118877" class="name">
  <strong class="user"><em>fabio at naoimporta dot com</em></strong></a><a class="genanchor" href="#118877"> &para;</a><div class="date" title="2016-02-21 09:53"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom118877">
<div class="phpcode"><code><span class="html">
It's possible to know how many clones have been created of a&nbsp; object. I'm think that is correct:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">Classe </span><span class="keyword">{<br /><br />&nbsp; &nbsp; public static </span><span class="default">$howManyClones </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public function </span><span class="default">__clone</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; ++static::</span><span class="default">$howManyClones</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public static function </span><span class="default">howManyClones</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return static::</span><span class="default">$howManyClones</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">__destruct</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; --static::</span><span class="default">$howManyClones</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">Classe</span><span class="keyword">;<br /><br /></span><span class="default">$b </span><span class="keyword">= clone </span><span class="default">$a</span><span class="keyword">;<br /></span><span class="default">$c </span><span class="keyword">= clone </span><span class="default">$b</span><span class="keyword">;<br /></span><span class="default">$d </span><span class="keyword">= clone </span><span class="default">$c</span><span class="keyword">;<br /><br />echo </span><span class="string">'Clones:' </span><span class="keyword">. </span><span class="default">Classe</span><span class="keyword">::</span><span class="default">howManyClones</span><span class="keyword">() . </span><span class="default">PHP_EOL</span><span class="keyword">;<br /><br />unset(</span><span class="default">$d</span><span class="keyword">);<br /><br />echo </span><span class="string">'Clones:' </span><span class="keyword">. </span><span class="default">Classe</span><span class="keyword">::</span><span class="default">howManyClones</span><span class="keyword">() . </span><span class="default">PHP_EOL</span><span class="keyword">;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="91323">  <div class="votes">
    <div id="Vu91323">
    <a href="/manual/vote-note.php?id=91323&amp;page=language.oop5.cloning&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd91323">
    <a href="/manual/vote-note.php?id=91323&amp;page=language.oop5.cloning&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V91323" title="57% like this...">
    5
    </div>
  </div>
  <a href="#91323" class="name">
  <strong class="user"><em>ben at last dot fm</em></strong></a><a class="genanchor" href="#91323"> &para;</a><div class="date" title="2009-06-05 10:33"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom91323">
<div class="phpcode"><code><span class="html">
Here are some cloning and reference gotchas we came up against at Last.fm.<br /><br />1. PHP treats variables as either 'values types' or 'reference types', where the difference is supposed to be transparent. Object cloning is one of the few times when it can make a big difference. I know of no programmatic way to tell if a variable is intrinsically a value or reference type. There IS however a non-programmatic ways to tell if an object property is value or reference type:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">A </span><span class="keyword">{ var </span><span class="default">$p</span><span class="keyword">; }<br /><br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">;<br /></span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">p </span><span class="keyword">= </span><span class="string">'Hello'</span><span class="keyword">; </span><span class="comment">// $a-&gt;p is a value type<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">);<br /><br /></span><span class="comment">/*<br />object(A)#1 (1) {<br />&nbsp; ["p"]=&gt;<br />&nbsp; string(5) "Hello" // &lt;-- no &amp;<br />}<br />*/<br /><br /></span><span class="default">$ref </span><span class="keyword">=&amp; </span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">p</span><span class="keyword">; </span><span class="comment">// note that this CONVERTS $a-&gt;p into a reference type!!<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">);<br /><br /></span><span class="comment">/*<br />object(A)#1 (1) {<br />&nbsp; ["p"]=&gt;<br />&nbsp; &amp;string(5) "Hello" // &lt;-- note the &amp;, this indicates it's a reference.<br />}<br />*/<br /><br /></span><span class="default">?&gt;<br /></span><br />2. unsetting all-but-one of the references will convert the remaining reference back into a value. Continuing from the previous example:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">unset(</span><span class="default">$ref</span><span class="keyword">);<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">);<br /><br /></span><span class="comment">/*<br />object(A)#1 (1) {<br />&nbsp; ["p"]=&gt;<br />&nbsp; string(5) "Hello"<br />}<br />*/<br /><br /></span><span class="default">?&gt;<br /></span><br />I interpret this as the reference-count jumping from 2 straight to 0. However...<br /><br />2. It IS possible to create a reference with a reference count of 1 - i.e. to convert an property from value type to reference type, without any extra references. All you have to do is declare that it refers to itself. This is HIGHLY idiosyncratic, but nevertheless it works. This leads to the observation that although the manual states that 'Any properties that are references to other variables, will remain references,' this is not strictly true. Any variables that are references, even to *themselves* (not necessarily to other variables), will be copied by reference rather than by value. <br /><br />Here's an example to demonstrate:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">ByVal<br /></span><span class="keyword">{<br />&nbsp; &nbsp; var </span><span class="default">$prop</span><span class="keyword">;<br />}<br /><br />class </span><span class="default">ByRef<br /></span><span class="keyword">{<br />&nbsp; &nbsp; var </span><span class="default">$prop</span><span class="keyword">;<br />&nbsp; &nbsp; function </span><span class="default">__construct</span><span class="keyword">() { </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">prop </span><span class="keyword">=&amp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">prop</span><span class="keyword">; }<br />}<br /><br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">ByVal</span><span class="keyword">;<br /></span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">prop </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br /></span><span class="default">$b </span><span class="keyword">= clone </span><span class="default">$a</span><span class="keyword">;<br /></span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">prop </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">; </span><span class="comment">// $a-&gt;prop remains at 1<br /><br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">ByRef</span><span class="keyword">;<br /></span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">prop </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br /></span><span class="default">$b </span><span class="keyword">= clone </span><span class="default">$a</span><span class="keyword">;<br /></span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">prop </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">; </span><span class="comment">// $a-&gt;prop is now 2<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116329">  <div class="votes">
    <div id="Vu116329">
    <a href="/manual/vote-note.php?id=116329&amp;page=language.oop5.cloning&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116329">
    <a href="/manual/vote-note.php?id=116329&amp;page=language.oop5.cloning&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116329" title="60% like this...">
    2
    </div>
  </div>
  <a href="#116329" class="name">
  <strong class="user"><em>stanislav dot eckert at vizson dot de</em></strong></a><a class="genanchor" href="#116329"> &para;</a><div class="date" title="2014-12-13 12:53"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom116329">
<div class="phpcode"><code><span class="html">
This base class automatically clones attributes of type object or array values of type object recursively. Just inherit your own classes from this base class.<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">class </span><span class="default">clone_base<br />&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; public function </span><span class="default">__clone</span><span class="keyword">()<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$object_vars </span><span class="keyword">= </span><span class="default">get_object_vars</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">);<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; foreach (</span><span class="default">$object_vars </span><span class="keyword">as </span><span class="default">$attr_name </span><span class="keyword">=&gt; </span><span class="default">$attr_value</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">is_object</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$attr_name</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$attr_name </span><span class="keyword">= clone </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$attr_name</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; else if (</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$attr_name</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Note: This copies only one dimension arrays<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">foreach (</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$attr_name </span><span class="keyword">as &amp;</span><span class="default">$attr_array_value</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">is_object</span><span class="keyword">(</span><span class="default">$attr_array_value</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$attr_array_value </span><span class="keyword">= clone </span><span class="default">$attr_array_value</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; unset(</span><span class="default">$attr_array_value</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /></span><span class="default">?&gt;<br /></span><br />Example:<br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">class </span><span class="default">foo </span><span class="keyword">extends </span><span class="default">clone_base<br />&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; public </span><span class="default">$attr </span><span class="keyword">= </span><span class="string">"Hello"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; public </span><span class="default">$b </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; public </span><span class="default">$attr2 </span><span class="keyword">= array();<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">()<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">b </span><span class="keyword">= new </span><span class="default">bar</span><span class="keyword">(</span><span class="string">"World"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">attr2</span><span class="keyword">[] = new </span><span class="default">bar</span><span class="keyword">(</span><span class="string">"What's"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">attr2</span><span class="keyword">[] = new </span><span class="default">bar</span><span class="keyword">(</span><span class="string">"up?"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; class </span><span class="default">bar </span><span class="keyword">extends </span><span class="default">clone_base<br />&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; public </span><span class="default">$attr</span><span class="keyword">;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$attr_value</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">attr </span><span class="keyword">= </span><span class="default">$attr_value</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; echo </span><span class="string">"&lt;pre&gt;"</span><span class="keyword">;<br /><br />&nbsp; &nbsp; </span><span class="default">$f1 </span><span class="keyword">= new </span><span class="default">foo</span><span class="keyword">();<br />&nbsp; &nbsp; </span><span class="default">$f2 </span><span class="keyword">= clone </span><span class="default">$f1</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$f2</span><span class="keyword">-&gt;</span><span class="default">attr </span><span class="keyword">= </span><span class="string">"James"</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$f2</span><span class="keyword">-&gt;</span><span class="default">b</span><span class="keyword">-&gt;</span><span class="default">attr </span><span class="keyword">= </span><span class="string">"Bond"</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$f2</span><span class="keyword">-&gt;</span><span class="default">attr2</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]-&gt;</span><span class="default">attr </span><span class="keyword">= </span><span class="string">"Agent"</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$f2</span><span class="keyword">-&gt;</span><span class="default">attr2</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]-&gt;</span><span class="default">attr </span><span class="keyword">= </span><span class="string">"007"</span><span class="keyword">;<br /><br />&nbsp; &nbsp; echo </span><span class="string">"f1.attr = " </span><span class="keyword">. </span><span class="default">$f1</span><span class="keyword">-&gt;</span><span class="default">attr </span><span class="keyword">. </span><span class="string">"\n"</span><span class="keyword">;<br />&nbsp; &nbsp; echo </span><span class="string">"f1.b.attr = " </span><span class="keyword">. </span><span class="default">$f1</span><span class="keyword">-&gt;</span><span class="default">b</span><span class="keyword">-&gt;</span><span class="default">attr </span><span class="keyword">. </span><span class="string">"\n"</span><span class="keyword">;<br />&nbsp; &nbsp; echo </span><span class="string">"f1.attr2[0] = " </span><span class="keyword">. </span><span class="default">$f1</span><span class="keyword">-&gt;</span><span class="default">attr2</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]-&gt;</span><span class="default">attr </span><span class="keyword">. </span><span class="string">"\n"</span><span class="keyword">;<br />&nbsp; &nbsp; echo </span><span class="string">"f1.attr2[1] = " </span><span class="keyword">. </span><span class="default">$f1</span><span class="keyword">-&gt;</span><span class="default">attr2</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]-&gt;</span><span class="default">attr </span><span class="keyword">. </span><span class="string">"\n"</span><span class="keyword">;<br />&nbsp; &nbsp; echo </span><span class="string">"\n"</span><span class="keyword">;<br />&nbsp; &nbsp; echo </span><span class="string">"f2.attr = " </span><span class="keyword">. </span><span class="default">$f2</span><span class="keyword">-&gt;</span><span class="default">attr </span><span class="keyword">. </span><span class="string">"\n"</span><span class="keyword">;<br />&nbsp; &nbsp; echo </span><span class="string">"f2.b.attr = " </span><span class="keyword">. </span><span class="default">$f2</span><span class="keyword">-&gt;</span><span class="default">b</span><span class="keyword">-&gt;</span><span class="default">attr </span><span class="keyword">. </span><span class="string">"\n"</span><span class="keyword">;<br />&nbsp; &nbsp; echo </span><span class="string">"f2.attr2[0] = " </span><span class="keyword">. </span><span class="default">$f2</span><span class="keyword">-&gt;</span><span class="default">attr2</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]-&gt;</span><span class="default">attr </span><span class="keyword">. </span><span class="string">"\n"</span><span class="keyword">;<br />&nbsp; &nbsp; echo </span><span class="string">"f2.attr2[1] = " </span><span class="keyword">. </span><span class="default">$f2</span><span class="keyword">-&gt;</span><span class="default">attr2</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]-&gt;</span><span class="default">attr </span><span class="keyword">. </span><span class="string">"\n"</span><span class="keyword">;<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121740">  <div class="votes">
    <div id="Vu121740">
    <a href="/manual/vote-note.php?id=121740&amp;page=language.oop5.cloning&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121740">
    <a href="/manual/vote-note.php?id=121740&amp;page=language.oop5.cloning&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121740" title="100% like this...">
    1
    </div>
  </div>
  <a href="#121740" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#121740"> &para;</a><div class="date" title="2017-10-08 11:51"><strong>2 months ago</strong></div>
  <div class="text" id="Hcom121740">
<div class="phpcode"><code><span class="html">
Erreur d'orthographe dans le titre : « clonage » et non « clônage »</span>
</code></div>
  </div>
 </div>
  <div class="note" id="96493">  <div class="votes">
    <div id="Vu96493">
    <a href="/manual/vote-note.php?id=96493&amp;page=language.oop5.cloning&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd96493">
    <a href="/manual/vote-note.php?id=96493&amp;page=language.oop5.cloning&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V96493" title="50% like this...">
    0
    </div>
  </div>
  <a href="#96493" class="name">
  <strong class="user"><em>emile at webflow dot nl</em></strong></a><a class="genanchor" href="#96493"> &para;</a><div class="date" title="2010-03-02 01:27"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom96493">
<div class="phpcode"><code><span class="html">
Another gotcha I encountered: like __construct and __desctruct, you must call parent::__clone() yourself from inside a child's __clone() function. The manual kind of got me on the wrong foot here: "An object's __clone() method cannot be called directly."</span>
</code></div>
  </div>
 </div>
  <div class="note" id="97348">  <div class="votes">
    <div id="Vu97348">
    <a href="/manual/vote-note.php?id=97348&amp;page=language.oop5.cloning&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd97348">
    <a href="/manual/vote-note.php?id=97348&amp;page=language.oop5.cloning&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V97348" title="42% like this...">
    -2
    </div>
  </div>
  <a href="#97348" class="name">
  <strong class="user"><em>jeffrey at whinger dot nl</em></strong></a><a class="genanchor" href="#97348"> &para;</a><div class="date" title="2010-04-15 05:41"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom97348">
<div class="phpcode"><code><span class="html">
For me it wasn't very clear to how this cloning of objects really worked so I made this little bit of code:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">foo<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$test</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">test</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'give us a '</span><span class="keyword">.</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">test</span><span class="keyword">.</span><span class="string">"&lt;br&gt;\n"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">bar<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$foo</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">insertFoo</span><span class="keyword">(</span><span class="default">$foo</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">foo </span><span class="keyword">= </span><span class="default">$foo</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$foo </span><span class="keyword">= new </span><span class="default">foo</span><span class="keyword">();<br /><br /></span><span class="default">$foo</span><span class="keyword">-&gt;</span><span class="default">test </span><span class="keyword">= </span><span class="string">'foo'</span><span class="keyword">;<br /><br /></span><span class="default">$bar </span><span class="keyword">= new </span><span class="default">bar</span><span class="keyword">();<br /><br /></span><span class="default">$bar</span><span class="keyword">-&gt;</span><span class="default">insertFoo</span><span class="keyword">(</span><span class="default">$foo</span><span class="keyword">);<br /><br /></span><span class="default">$foo</span><span class="keyword">-&gt;</span><span class="default">test</span><span class="keyword">();<br /><br /></span><span class="default">$bar</span><span class="keyword">-&gt;</span><span class="default">foo</span><span class="keyword">-&gt;</span><span class="default">test</span><span class="keyword">();<br /><br /></span><span class="default">$foo</span><span class="keyword">-&gt;</span><span class="default">test </span><span class="keyword">= </span><span class="string">'bar'</span><span class="keyword">;<br /><br /></span><span class="default">$foo</span><span class="keyword">-&gt;</span><span class="default">test</span><span class="keyword">();<br /><br /></span><span class="default">$bar</span><span class="keyword">-&gt;</span><span class="default">foo</span><span class="keyword">-&gt;</span><span class="default">test</span><span class="keyword">();<br /><br /></span><span class="default">$bar</span><span class="keyword">-&gt;</span><span class="default">foo </span><span class="keyword">= clone </span><span class="default">$foo</span><span class="keyword">;<br /><br /></span><span class="default">$bar</span><span class="keyword">-&gt;</span><span class="default">foo</span><span class="keyword">-&gt;</span><span class="default">test </span><span class="keyword">= </span><span class="string">'woop woop'</span><span class="keyword">;<br /><br /></span><span class="default">$foo</span><span class="keyword">-&gt;</span><span class="default">test</span><span class="keyword">();<br /><br /></span><span class="default">$bar</span><span class="keyword">-&gt;</span><span class="default">foo</span><span class="keyword">-&gt;</span><span class="default">test</span><span class="keyword">();<br /><br /></span><span class="comment">// result:<br />// give us a foo<br />// give us a foo<br />// give us a bar<br />// give us a bar<br />// give us a bar<br />// give us a woop woop<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="81774">  <div class="votes">
    <div id="Vu81774">
    <a href="/manual/vote-note.php?id=81774&amp;page=language.oop5.cloning&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd81774">
    <a href="/manual/vote-note.php?id=81774&amp;page=language.oop5.cloning&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V81774" title="41% like this...">
    -4
    </div>
  </div>
  <a href="#81774" class="name">
  <strong class="user"><em>crrodriguez at suse dot de</em></strong></a><a class="genanchor" href="#81774"> &para;</a><div class="date" title="2008-03-12 09:52"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom81774">
<div class="phpcode"><code><span class="html">
Keep in mind that since PHP 5.2.5, trying to clone a non-object correctly results in a fatal error, this differs from previous versions where only a Warning was thrown.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118049">  <div class="votes">
    <div id="Vu118049">
    <a href="/manual/vote-note.php?id=118049&amp;page=language.oop5.cloning&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118049">
    <a href="/manual/vote-note.php?id=118049&amp;page=language.oop5.cloning&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118049" title="33% like this...">
    -2
    </div>
  </div>
  <a href="#118049" class="name">
  <strong class="user"><em>jason at jewelrysupply dot com</em></strong></a><a class="genanchor" href="#118049"> &para;</a><div class="date" title="2015-09-24 09:44"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom118049">
<div class="phpcode"><code><span class="html">
@DPB<br /><br />I believe the two functions are not quite the same. The serialize followed by deserialize method is the way I've done deep cloning in other languages (bypasses any weird clone function behavior and ensures you have a no-strings-attached copy of the object).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="87066">  <div class="votes">
    <div id="Vu87066">
    <a href="/manual/vote-note.php?id=87066&amp;page=language.oop5.cloning&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd87066">
    <a href="/manual/vote-note.php?id=87066&amp;page=language.oop5.cloning&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V87066" title="36% like this...">
    -5
    </div>
  </div>
  <a href="#87066" class="name">
  <strong class="user"><em>cheetah at tanabi dot org</em></strong></a><a class="genanchor" href="#87066"> &para;</a><div class="date" title="2008-11-18 05:15"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom87066">
<div class="phpcode"><code><span class="html">
Want deep cloning without too much hassle?<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">__clone</span><span class="keyword">() {<br />&nbsp; &nbsp; foreach(</span><span class="default">$this </span><span class="keyword">as </span><span class="default">$key </span><span class="keyword">=&gt; </span><span class="default">$val</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">is_object</span><span class="keyword">(</span><span class="default">$val</span><span class="keyword">)||(</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$val</span><span class="keyword">))){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;{</span><span class="default">$key</span><span class="keyword">} = </span><span class="default">unserialize</span><span class="keyword">(</span><span class="default">serialize</span><span class="keyword">(</span><span class="default">$val</span><span class="keyword">));<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />That will insure any object, or array that may potentially contain objects, will get cloned without using recursion or other support methods.<br /><br /><br /><br />[EDIT BY danbrown AT php DOT net: An almost exact function was contributed on 02-DEC-2008-10:18 by (david ashe AT metabin):<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">function </span><span class="default">__clone</span><span class="keyword">(){<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach(</span><span class="default">$this </span><span class="keyword">as </span><span class="default">$name </span><span class="keyword">=&gt; </span><span class="default">$value</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">gettype</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">)==</span><span class="string">'object'</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$name</span><span class="keyword">= clone(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$name</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /></span><span class="default">?&gt;<br /></span><br />Giving credit where it's due.&nbsp; ~DPB]<br />[EDIT BY cmb AT php DOT net: the latter function fails to make deep copies of object arrays, and might end up with infinite recursion.]</span>
</code></div>
  </div>
 </div>
  <div class="note" id="73081">  <div class="votes">
    <div id="Vu73081">
    <a href="/manual/vote-note.php?id=73081&amp;page=language.oop5.cloning&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd73081">
    <a href="/manual/vote-note.php?id=73081&amp;page=language.oop5.cloning&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V73081" title="33% like this...">
    -4
    </div>
  </div>
  <a href="#73081" class="name">
  <strong class="user"><em>Alexey</em></strong></a><a class="genanchor" href="#73081"> &para;</a><div class="date" title="2007-02-08 07:18"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom73081">
<div class="phpcode"><code><span class="html">
To implement __clone() method in complex classes I use this simple function:<br /><br />function clone_($some)<br />{<br />&nbsp;&nbsp; return (is_object($some)) ? clone $some : $some;<br />}<br /><br />In this way I don't need to care about type of my class properties.</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.oop5.cloning&amp;redirect=http://php.net/manual/en/language.oop5.cloning.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.oop5.php">Classes and Objects</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="oop5.intro.php" title="Introduction">Introduction</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.basic.php" title="The Basics">The Basics</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.properties.php" title="Properties">Properties</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.constants.php" title="Class Constants">Class Constants</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.autoload.php" title="Autoloading Classes">Autoloading Classes</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.decon.php" title="Constructors and Destructors">Constructors and Destructors</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.visibility.php" title="Visibility">Visibility</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.inheritance.php" title="Object Inheritance">Object Inheritance</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.paamayim-nekudotayim.php" title="Scope Resolution Operator (::)">Scope Resolution Operator (::)</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.static.php" title="Static Keyword">Static Keyword</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.abstract.php" title="Class Abstraction">Class Abstraction</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.interfaces.php" title="Object Interfaces">Object Interfaces</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.traits.php" title="Traits">Traits</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.anonymous.php" title="Anonymous classes">Anonymous classes</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.overloading.php" title="Overloading">Overloading</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.iterations.php" title="Object Iteration">Object Iteration</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.magic.php" title="Magic Methods">Magic Methods</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.final.php" title="Final Keyword">Final Keyword</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.oop5.cloning.php" title="Object Cloning">Object Cloning</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.object-comparison.php" title="Comparing Objects">Comparing Objects</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.typehinting.php" title="Type Hinting">Type Hinting</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.late-static-bindings.php" title="Late Static Bindings">Late Static Bindings</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.references.php" title="Objects and references">Objects and references</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.serialization.php" title="Object Serialization">Object Serialization</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.changelog.php" title="OOP Changelog">OOP Changelog</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

