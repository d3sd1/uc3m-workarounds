<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Generator syntax - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.generators.syntax.php">
 <link rel="shorturl" href="http://php.net/generators.syntax">
 <link rel="alternate" href="http://php.net/generators.syntax" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.generators.php">
 <link rel="prev" href="http://php.net/manual/en/language.generators.overview.php">
 <link rel="next" href="http://php.net/manual/en/language.generators.comparison.php">

 <link rel="alternate" href="http://php.net/manual/en/language.generators.syntax.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.generators.syntax.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.generators.syntax.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.generators.syntax.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.generators.syntax.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.generators.syntax.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.generators.syntax.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.generators.syntax.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.generators.syntax.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.generators.syntax.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.generators.syntax.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.generators.comparison.php">
          Comparing generators with Iterator objects &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.generators.overview.php">
          &laquo; Generators overview        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.generators.php'>Generators</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.generators.syntax.php' selected="selected">English</option>
            <option value='pt_BR/language.generators.syntax.php'>Brazilian Portuguese</option>
            <option value='zh/language.generators.syntax.php'>Chinese (Simplified)</option>
            <option value='fr/language.generators.syntax.php'>French</option>
            <option value='de/language.generators.syntax.php'>German</option>
            <option value='ja/language.generators.syntax.php'>Japanese</option>
            <option value='ro/language.generators.syntax.php'>Romanian</option>
            <option value='ru/language.generators.syntax.php'>Russian</option>
            <option value='es/language.generators.syntax.php'>Spanish</option>
            <option value='tr/language.generators.syntax.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.generators.syntax.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.generators.syntax">Report a Bug</a>
    </div>
  </div><div id="language.generators.syntax" class="sect1">
  <h2 class="title">Generator syntax</h2>

  <p class="para">
   A generator function looks just like a normal function, except that instead
   of returning a value, a generator <a href="language.generators.syntax.php#control-structures.yield" class="link">yield</a>s as many values as it needs to.
  </p>

  <p class="para">
   When a generator function is called, it returns an object that can be
   iterated over. When you iterate over that object (for instance, via a
   <a href="control-structures.foreach.php" class="link">foreach</a> loop), PHP will call the generator function each time it needs a
   value, then saves the state of the generator when the generator yields a
   value so that it can be resumed when the next value is required.
  </p>

  <p class="para">
   Once there are no more values to be yielded, then the generator function
   can simply exit, and the calling code continues just as if an array has run
   out of values.
  </p>

  <blockquote class="note"><p><strong class="note">Note</strong>: 
   <p class="para">
    In PHP 5, a generator could not return a value: doing so would result in a compile
    error. An empty <strong class="command">return</strong> statement was valid syntax within
    a generator and it would terminate the generator. Since PHP 7.0, a generator can 
    return values, which can be retrieved using <span class="methodname"><a href="generator.getreturn.php" class="methodname">Generator::getReturn()</a></span>.
   </p>
  </p></blockquote>

  <div class="sect2" id="control-structures.yield">
   <h3 class="title"><strong class="command">yield</strong> keyword</h3>

   <p class="para">
    The heart of a generator function is the <strong class="command">yield</strong> keyword.
    In its simplest form, a yield statement looks much like a return
    statement, except that instead of stopping execution of the function and
    returning, yield instead provides a value to the code looping over the
    generator and pauses execution of the generator function.
   </p>

   <div class="example" id="example-285">
    <p><strong>Example #1 A simple example of yielding values</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">gen_one_to_three</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;for&nbsp;(</span><span style="color: #0000BB">$i&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">;&nbsp;</span><span style="color: #0000BB">$i&nbsp;</span><span style="color: #007700">&lt;=&nbsp;</span><span style="color: #0000BB">3</span><span style="color: #007700">;&nbsp;</span><span style="color: #0000BB">$i</span><span style="color: #007700">++)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;Note&nbsp;that&nbsp;$i&nbsp;is&nbsp;preserved&nbsp;between&nbsp;yields.<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">yield&nbsp;$i</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br /></span><span style="color: #0000BB">$generator&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">gen_one_to_three</span><span style="color: #007700">();<br />foreach&nbsp;(</span><span style="color: #0000BB">$generator&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">$value</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"</span><span style="color: #0000BB">$value</span><span style="color: #DD0000">\n"</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

    <div class="example-contents"><p>The above example will output:</p></div>
    <div class="example-contents screen">
<div class="cdata"><pre>
1
2
3
</pre></div>
    </div>
   </div>

   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <p class="para">
     Internally, sequential integer keys will be paired with the yielded
     values, just as with a non-associative array.
    </p>
   </p></blockquote>

   <div class="caution"><strong class="caution">Caution</strong>
    <p class="para">
     If you use yield in an expression context (for example, on the right hand
     side of an assignment), you must surround the yield statement with
     parentheses in PHP 5. For example, this is valid:
    </p>

    <div class="informalexample">
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
$data&nbsp;=&nbsp;(yield&nbsp;$value);</span>
</code></div>
     </div>

    </div>

    <p class="para">
     But this is not, and will result in a parse error in PHP 5:
    </p>

    <div class="informalexample">
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
$data&nbsp;=&nbsp;yield&nbsp;$value;</span>
</code></div>
     </div>

    </div>

    <p class="para">
     The parenthetical restrictions do not apply in PHP 7.
    </p>

    <p class="para">
     This syntax may be used in conjunction with the
     <span class="methodname"><a href="generator.send.php" class="methodname">Generator::send()</a></span> method.
    </p>
   </div>

   <div class="sect3" id="control-structures.yield.associative">
    <h4 class="title">Yielding values with keys</h4>

    <p class="para">
     PHP also supports associative arrays, and generators are no different. In
     addition to yielding simple values, as shown above, you can also yield a
     key at the same time.
    </p>

    <p class="para">
     The syntax for yielding a key/value pair is very similar to that used to
     define an associative array, as shown below.
    </p>

    <div class="example" id="example-286">
     <p><strong>Example #2 Yielding a key/value pair</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #FF8000">/*<br />&nbsp;*&nbsp;The&nbsp;input&nbsp;is&nbsp;semi-colon&nbsp;separated&nbsp;fields,&nbsp;with&nbsp;the&nbsp;first<br />&nbsp;*&nbsp;field&nbsp;being&nbsp;an&nbsp;ID&nbsp;to&nbsp;use&nbsp;as&nbsp;a&nbsp;key.<br />&nbsp;*/<br /><br /></span><span style="color: #0000BB">$input&nbsp;</span><span style="color: #007700">=&nbsp;&lt;&lt;&lt;'EOF'<br /></span><span style="color: #DD0000">1;PHP;Likes&nbsp;dollar&nbsp;signs<br />2;Python;Likes&nbsp;whitespace<br />3;Ruby;Likes&nbsp;blocks<br /></span><span style="color: #007700">EOF;<br /><br />function&nbsp;</span><span style="color: #0000BB">input_parser</span><span style="color: #007700">(</span><span style="color: #0000BB">$input</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;foreach&nbsp;(</span><span style="color: #0000BB">explode</span><span style="color: #007700">(</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$input</span><span style="color: #007700">)&nbsp;as&nbsp;</span><span style="color: #0000BB">$line</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$fields&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">explode</span><span style="color: #007700">(</span><span style="color: #DD0000">';'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$line</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$id&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">array_shift</span><span style="color: #007700">(</span><span style="color: #0000BB">$fields</span><span style="color: #007700">);<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">yield&nbsp;$id&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #0000BB">$fields</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br />foreach&nbsp;(</span><span style="color: #0000BB">input_parser</span><span style="color: #007700">(</span><span style="color: #0000BB">$input</span><span style="color: #007700">)&nbsp;as&nbsp;</span><span style="color: #0000BB">$id&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #0000BB">$fields</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"</span><span style="color: #0000BB">$id</span><span style="color: #DD0000">:\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$fields</span><span style="color: #007700">[</span><span style="color: #0000BB">0</span><span style="color: #007700">]</span><span style="color: #DD0000">\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$fields</span><span style="color: #007700">[</span><span style="color: #0000BB">1</span><span style="color: #007700">]</span><span style="color: #DD0000">\n"</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

     <div class="example-contents"><p>The above example will output:</p></div>
     <div class="example-contents screen">
<div class="cdata"><pre>
1:
    PHP
    Likes dollar signs
2:
    Python
    Likes whitespace
3:
    Ruby
    Likes blocks
</pre></div>
     </div>
    </div>

    <div class="caution"><strong class="caution">Caution</strong>
     <p class="para">
      As with the simple value yields shown earlier, yielding a key/value pair
      in an expression context requires the yield statement to be
      parenthesised:
     </p>

     <div class="informalexample">
      <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
$data&nbsp;=&nbsp;(yield&nbsp;$key&nbsp;=&gt;&nbsp;$value);</span>
</code></div>
      </div>

     </div>
    </div>
   </div>

   <div class="sect3" id="control-structures.yield.null">
    <h4 class="title">Yielding null values</h4>

    <p class="para">
     Yield can be called without an argument to yield a <strong><code>NULL</code></strong> value with an
     automatic key.
    </p>

    <div class="example" id="example-287">
     <p><strong>Example #3 Yielding <strong><code>NULL</code></strong>s</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">gen_three_nulls</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;foreach&nbsp;(</span><span style="color: #0000BB">range</span><span style="color: #007700">(</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">3</span><span style="color: #007700">)&nbsp;as&nbsp;</span><span style="color: #0000BB">$i</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">yield</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">iterator_to_array</span><span style="color: #007700">(</span><span style="color: #0000BB">gen_three_nulls</span><span style="color: #007700">()));<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

     <div class="example-contents"><p>The above example will output:</p></div>
     <div class="example-contents screen">
<div class="cdata"><pre>
array(3) {
  [0]=&gt;
  NULL
  [1]=&gt;
  NULL
  [2]=&gt;
  NULL
}
</pre></div>
     </div>
    </div>
   </div>

   <div class="sect3" id="control-structures.yield.references">
    <h4 class="title">Yielding by reference</h4>

    <p class="para">
     Generator functions are able to yield values by reference as well as by
     value. This is done in the same way as
     <a href="functions.returning-values.php" class="link">returning references from functions</a>: 
     by prepending an ampersand to the function name.
    </p>

    <div class="example" id="example-288">
     <p><strong>Example #4 Yielding values by reference</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;&amp;</span><span style="color: #0000BB">gen_reference</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$value&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">3</span><span style="color: #007700">;<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;while&nbsp;(</span><span style="color: #0000BB">$value&nbsp;</span><span style="color: #007700">&gt;&nbsp;</span><span style="color: #0000BB">0</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">yield&nbsp;$value</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br /></span><span style="color: #FF8000">/*<br />&nbsp;*&nbsp;Note&nbsp;that&nbsp;we&nbsp;can&nbsp;change&nbsp;$number&nbsp;within&nbsp;the&nbsp;loop,&nbsp;and<br />&nbsp;*&nbsp;because&nbsp;the&nbsp;generator&nbsp;is&nbsp;yielding&nbsp;references,&nbsp;$value<br />&nbsp;*&nbsp;within&nbsp;gen_reference()&nbsp;changes.<br />&nbsp;*/<br /></span><span style="color: #007700">foreach&nbsp;(</span><span style="color: #0000BB">gen_reference</span><span style="color: #007700">()&nbsp;as&nbsp;&amp;</span><span style="color: #0000BB">$number</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;(--</span><span style="color: #0000BB">$number</span><span style="color: #007700">).</span><span style="color: #DD0000">'...&nbsp;'</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

     <div class="example-contents"><p>The above example will output:</p></div>
     <div class="example-contents screen">
<div class="cdata"><pre>
2... 1... 0... 
</pre></div>
     </div>
    </div>
   </div>

   <div class="sect3" id="control-structures.yield.from">
    <h4 class="title">Generator delegation via <strong class="command">yield from</strong></h4>

    <p class="para">
     In PHP 7, generator delegation allows you to yield values from another
     generator, <a href="class.traversable.php" class="classname">Traversable</a> object, or
     <span class="type"><a href="language.types.array.php" class="type array">array</a></span> by using the <strong class="command">yield from</strong> keyword.
     The outer generator will then yield all values from the inner generator,
     object, or array until that is no longer valid, after which execution
     will continue in the outer generator.
    </p>

    <p class="para">
     If a generator is used with <strong class="command">yield from</strong>, the
     <strong class="command">yield from</strong> expression will also return any value
     returned by the inner generator.
    </p>
    
    <div class="caution"><strong class="caution">Caution</strong>
     <h1 class="title">Storing into an array (e.g. with <span class="function"><a href="function.iterator-to-array.php" class="function">iterator_to_array()</a></span>)</h1>

      <p class="para">
       <strong class="command">yield from</strong> does not reset the keys. It preserves
       the keys returned by the <a href="class.traversable.php" class="classname">Traversable</a> object, or
       <span class="type"><a href="language.types.array.php" class="type array">array</a></span>. Thus some values may share a common key with another
       <strong class="command">yield</strong> or <strong class="command">yield from</strong>, which, upon
       insertion into an array, will overwrite former values with that key.
      </p>

      <p class="para">
       A common case where this matters is <span class="function"><a href="function.iterator-to-array.php" class="function">iterator_to_array()</a></span>
       returning a keyed array by default, leading to possibly unexpected results.
       <span class="function"><a href="function.iterator-to-array.php" class="function">iterator_to_array()</a></span> has a second parameter
       <code class="parameter">use_keys</code> which can be set to <strong><code>FALSE</code></strong> to collect
       all the values while ignoring the keys returned by the <a href="class.generator.php" class="classname">Generator</a>.
      </p>
     
      <div class="example" id="example-289">
       <p><strong>Example #5 <strong class="command">yield from</strong> with <span class="function"><a href="function.iterator-to-array.php" class="function">iterator_to_array()</a></span></strong></p>
       <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">from</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">yield&nbsp;1</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;key&nbsp;0<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">yield&nbsp;2</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;key&nbsp;1<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">yield&nbsp;3</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;key&nbsp;2<br /></span><span style="color: #007700">}<br />function&nbsp;</span><span style="color: #0000BB">gen</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">yield&nbsp;0</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;key&nbsp;0<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">yield&nbsp;from&nbsp;from</span><span style="color: #007700">();&nbsp;</span><span style="color: #FF8000">//&nbsp;keys&nbsp;0-2<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">yield&nbsp;4</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;key&nbsp;1<br /></span><span style="color: #007700">}<br /></span><span style="color: #FF8000">//&nbsp;pass&nbsp;false&nbsp;as&nbsp;second&nbsp;parameter&nbsp;to&nbsp;get&nbsp;an&nbsp;array&nbsp;[0,&nbsp;1,&nbsp;2,&nbsp;3,&nbsp;4]<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">iterator_to_array</span><span style="color: #007700">(</span><span style="color: #0000BB">gen</span><span style="color: #007700">()));<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
       </div>

       <div class="example-contents"><p>The above example will output:</p></div>
       <div class="example-contents screen">
<div class="cdata"><pre>
array(3) {
  [0]=&gt;
  int(1)
  [1]=&gt;
  int(4)
  [2]=&gt;
  int(3)
}
</pre></div>
       </div>
      </div>
    </div>

    <div class="example" id="example-290">
     <p><strong>Example #6 Basic use of <strong class="command">yield from</strong></strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">count_to_ten</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">yield&nbsp;1</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">yield&nbsp;2</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">yield&nbsp;from&nbsp;</span><span style="color: #007700">[</span><span style="color: #0000BB">3</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">4</span><span style="color: #007700">];<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">yield&nbsp;from&nbsp;</span><span style="color: #007700">new&nbsp;</span><span style="color: #0000BB">ArrayIterator</span><span style="color: #007700">([</span><span style="color: #0000BB">5</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">6</span><span style="color: #007700">]);<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">yield&nbsp;from&nbsp;seven_eight</span><span style="color: #007700">();<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">yield&nbsp;9</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">yield&nbsp;10</span><span style="color: #007700">;<br />}<br /><br />function&nbsp;</span><span style="color: #0000BB">seven_eight</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">yield&nbsp;7</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">yield&nbsp;from&nbsp;eight</span><span style="color: #007700">();<br />}<br /><br />function&nbsp;</span><span style="color: #0000BB">eight</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">yield&nbsp;8</span><span style="color: #007700">;<br />}<br /><br />foreach&nbsp;(</span><span style="color: #0000BB">count_to_ten</span><span style="color: #007700">()&nbsp;as&nbsp;</span><span style="color: #0000BB">$num</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"</span><span style="color: #0000BB">$num</span><span style="color: #DD0000">&nbsp;"</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

     <div class="example-contents"><p>The above example will output:</p></div>
     <div class="example-contents screen">
<div class="cdata"><pre>
1 2 3 4 5 6 7 8 9 10 
</pre></div>
     </div>
    </div>

    <div class="example" id="example-291">
     <p><strong>Example #7 <strong class="command">yield from</strong> and return values</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">count_to_ten</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">yield&nbsp;1</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">yield&nbsp;2</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">yield&nbsp;from&nbsp;</span><span style="color: #007700">[</span><span style="color: #0000BB">3</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">4</span><span style="color: #007700">];<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">yield&nbsp;from&nbsp;</span><span style="color: #007700">new&nbsp;</span><span style="color: #0000BB">ArrayIterator</span><span style="color: #007700">([</span><span style="color: #0000BB">5</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">6</span><span style="color: #007700">]);<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">yield&nbsp;from&nbsp;seven_eight</span><span style="color: #007700">();<br />&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">yield&nbsp;from&nbsp;nine_ten</span><span style="color: #007700">();<br />}<br /><br />function&nbsp;</span><span style="color: #0000BB">seven_eight</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">yield&nbsp;7</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">yield&nbsp;from&nbsp;eight</span><span style="color: #007700">();<br />}<br /><br />function&nbsp;</span><span style="color: #0000BB">eight</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">yield&nbsp;8</span><span style="color: #007700">;<br />}<br /><br />function&nbsp;</span><span style="color: #0000BB">nine_ten</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">yield&nbsp;9</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">10</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #0000BB">$gen&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">count_to_ten</span><span style="color: #007700">();<br />foreach&nbsp;(</span><span style="color: #0000BB">$gen&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">$num</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"</span><span style="color: #0000BB">$num</span><span style="color: #DD0000">&nbsp;"</span><span style="color: #007700">;<br />}<br />echo&nbsp;</span><span style="color: #0000BB">$gen</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">getReturn</span><span style="color: #007700">();<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

     <div class="example-contents"><p>The above example will output:</p></div>
     <div class="example-contents screen">
<div class="cdata"><pre>
1 2 3 4 5 6 7 8 9 10
</pre></div>
     </div>
    </div>
   </div>
  </div>
 </div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.generators.syntax&amp;redirect=http://php.net/manual/en/language.generators.syntax.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">9 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="111969">  <div class="votes">
    <div id="Vu111969">
    <a href="/manual/vote-note.php?id=111969&amp;page=language.generators.syntax&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd111969">
    <a href="/manual/vote-note.php?id=111969&amp;page=language.generators.syntax&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V111969" title="87% like this...">
    83
    </div>
  </div>
  <a href="#111969" class="name">
  <strong class="user"><em>Adil lhan (adilmedya at gmail dot com)</em></strong></a><a class="genanchor" href="#111969"> &para;</a><div class="date" title="2013-04-18 09:02"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom111969">
<div class="phpcode"><code><span class="html">
For example yield keyword with Fibonacci:<br /><br />function getFibonacci()<br />{<br />&nbsp; &nbsp; $i = 0;<br />&nbsp; &nbsp; $k = 1; //first fibonacci value<br />&nbsp; &nbsp; yield $k;<br />&nbsp; &nbsp; while(true)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; $k = $i + $k;<br />&nbsp; &nbsp; &nbsp; &nbsp; $i = $k - $i;<br />&nbsp; &nbsp; &nbsp; &nbsp; yield $k;&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; }<br />}<br /><br />$y = 0;<br /><br />foreach(getFibonacci() as $fibonacci)<br />{<br />&nbsp; &nbsp; echo $fibonacci . "\n";<br />&nbsp; &nbsp; $y++;&nbsp; &nbsp; <br />&nbsp; &nbsp; if($y &gt; 30)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; break; // infinite loop prevent<br />&nbsp; &nbsp; }<br />}</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116577">  <div class="votes">
    <div id="Vu116577">
    <a href="/manual/vote-note.php?id=116577&amp;page=language.generators.syntax&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116577">
    <a href="/manual/vote-note.php?id=116577&amp;page=language.generators.syntax&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116577" title="95% like this...">
    18
    </div>
  </div>
  <a href="#116577" class="name">
  <strong class="user"><em>info at boukeversteegh dot nl</em></strong></a><a class="genanchor" href="#116577"> &para;</a><div class="date" title="2015-01-23 07:02"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom116577">
<div class="phpcode"><code><span class="html">
[This comment replaces my previous comment]<br /><br />You can use generators to do lazy loading of lists. You only compute the items that are actually used. However, when you want to load more items, how to cache the ones already loaded?<br /><br />Here is how to do cached lazy loading with a generator:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">CachedGenerator </span><span class="keyword">{<br />&nbsp; &nbsp; protected </span><span class="default">$cache </span><span class="keyword">= [];<br />&nbsp; &nbsp; protected </span><span class="default">$generator </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$generator</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">generator </span><span class="keyword">= </span><span class="default">$generator</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">generator</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">cache </span><span class="keyword">as </span><span class="default">$item</span><span class="keyword">) yield </span><span class="default">$item</span><span class="keyword">;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; while( </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">generator</span><span class="keyword">-&gt;</span><span class="default">valid</span><span class="keyword">() ) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">cache</span><span class="keyword">[] = </span><span class="default">$current </span><span class="keyword">= </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">generator</span><span class="keyword">-&gt;</span><span class="default">current</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">generator</span><span class="keyword">-&gt;</span><span class="default">next</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; yield </span><span class="default">$current</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />}<br />class </span><span class="default">Foobar </span><span class="keyword">{<br />&nbsp; &nbsp; protected </span><span class="default">$loader </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br /><br />&nbsp; &nbsp; protected function </span><span class="default">loadItems</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach(</span><span class="default">range</span><span class="keyword">(</span><span class="default">0</span><span class="keyword">,</span><span class="default">10</span><span class="keyword">) as </span><span class="default">$i</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">usleep</span><span class="keyword">(</span><span class="default">200000</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; yield </span><span class="default">$i</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">getItems</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">loader </span><span class="keyword">= </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">loader </span><span class="keyword">?: new </span><span class="default">CachedGenerator</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">loadItems</span><span class="keyword">());<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">loader</span><span class="keyword">-&gt;</span><span class="default">generator</span><span class="keyword">();<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$f </span><span class="keyword">= new </span><span class="default">Foobar</span><span class="keyword">;<br /><br /></span><span class="comment"># First<br /></span><span class="keyword">print </span><span class="string">"First\n"</span><span class="keyword">;<br />foreach(</span><span class="default">$f</span><span class="keyword">-&gt;</span><span class="default">getItems</span><span class="keyword">() as </span><span class="default">$i</span><span class="keyword">) {<br />&nbsp; &nbsp; print </span><span class="default">$i </span><span class="keyword">. </span><span class="string">"\n"</span><span class="keyword">;<br />&nbsp; &nbsp; if( </span><span class="default">$i </span><span class="keyword">== </span><span class="default">5 </span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="comment"># Second (items 1-5 are cached, 6-10 are loaded)<br /></span><span class="keyword">print </span><span class="string">"Second\n"</span><span class="keyword">;<br />foreach(</span><span class="default">$f</span><span class="keyword">-&gt;</span><span class="default">getItems</span><span class="keyword">() as </span><span class="default">$i</span><span class="keyword">) {<br />&nbsp; &nbsp; print </span><span class="default">$i </span><span class="keyword">. </span><span class="string">"\n"</span><span class="keyword">;<br />}<br /><br /></span><span class="comment"># Third (all items are cached and returned instantly)<br /></span><span class="keyword">print </span><span class="string">"Third\n"</span><span class="keyword">;<br />foreach(</span><span class="default">$f</span><span class="keyword">-&gt;</span><span class="default">getItems</span><span class="keyword">() as </span><span class="default">$i</span><span class="keyword">) {<br />&nbsp; &nbsp; print </span><span class="default">$i </span><span class="keyword">. </span><span class="string">"\n"</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117460">  <div class="votes">
    <div id="Vu117460">
    <a href="/manual/vote-note.php?id=117460&amp;page=language.generators.syntax&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117460">
    <a href="/manual/vote-note.php?id=117460&amp;page=language.generators.syntax&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117460" title="85% like this...">
    14
    </div>
  </div>
  <a href="#117460" class="name">
  <strong class="user"><em>Harun Yasar harunyasar at mail dot com</em></strong></a><a class="genanchor" href="#117460"> &para;</a><div class="date" title="2015-06-12 02:43"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117460">
<div class="phpcode"><code><span class="html">
That is a simple fibonacci generator.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">fibonacci</span><span class="keyword">(</span><span class="default">$item</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$a </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$b </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; for (</span><span class="default">$i </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">; </span><span class="default">$i </span><span class="keyword">&lt; </span><span class="default">$item</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">++) {<br />&nbsp; &nbsp; &nbsp; &nbsp; yield </span><span class="default">$a</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$a </span><span class="keyword">= </span><span class="default">$b </span><span class="keyword">- </span><span class="default">$a</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$b </span><span class="keyword">= </span><span class="default">$a </span><span class="keyword">+ </span><span class="default">$b</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="comment"># give me the first ten fibonacci numbers<br /></span><span class="default">$fibo </span><span class="keyword">= </span><span class="default">fibonacci</span><span class="keyword">(</span><span class="default">10</span><span class="keyword">);<br />foreach (</span><span class="default">$fibo </span><span class="keyword">as </span><span class="default">$value</span><span class="keyword">) {<br />&nbsp; &nbsp; echo </span><span class="string">"</span><span class="default">$value</span><span class="string">\n"</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118316">  <div class="votes">
    <div id="Vu118316">
    <a href="/manual/vote-note.php?id=118316&amp;page=language.generators.syntax&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118316">
    <a href="/manual/vote-note.php?id=118316&amp;page=language.generators.syntax&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118316" title="77% like this...">
    5
    </div>
  </div>
  <a href="#118316" class="name">
  <strong class="user"><em>zilvinas at kuusas dot lt</em></strong></a><a class="genanchor" href="#118316"> &para;</a><div class="date" title="2015-11-16 09:18"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom118316">
<div class="phpcode"><code><span class="html">
Do not call generator functions directly, that won't work.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">my_transform</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">);<br />&nbsp; &nbsp; return </span><span class="default">$value </span><span class="keyword">* </span><span class="default">2</span><span class="keyword">;<br />}<br /><br />function </span><span class="default">my_function</span><span class="keyword">(array </span><span class="default">$values</span><span class="keyword">) {<br />&nbsp; &nbsp; foreach (</span><span class="default">$values </span><span class="keyword">as </span><span class="default">$value</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; yield </span><span class="default">my_transform</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$data </span><span class="keyword">= [</span><span class="default">1</span><span class="keyword">, </span><span class="default">5</span><span class="keyword">, </span><span class="default">10</span><span class="keyword">];<br /></span><span class="comment">// my_transform() won't be called inside my_function()<br /></span><span class="default">my_function</span><span class="keyword">(</span><span class="default">$data</span><span class="keyword">);<br /><br /></span><span class="comment"># my_transform() will be called.<br /></span><span class="keyword">foreach (</span><span class="default">my_function</span><span class="keyword">(</span><span class="default">$data</span><span class="keyword">) as </span><span class="default">$val</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="comment">// ...<br /></span><span class="keyword">}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="115705">  <div class="votes">
    <div id="Vu115705">
    <a href="/manual/vote-note.php?id=115705&amp;page=language.generators.syntax&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115705">
    <a href="/manual/vote-note.php?id=115705&amp;page=language.generators.syntax&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115705" title="77% like this...">
    5
    </div>
  </div>
  <a href="#115705" class="name">
  <strong class="user"><em>christophe dot maymard at gmail dot com</em></strong></a><a class="genanchor" href="#115705"> &para;</a><div class="date" title="2014-09-11 04:43"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115705">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br /></span><span class="comment">//Example of class implementing IteratorAggregate using generator<br /><br /></span><span class="keyword">class </span><span class="default">ValueCollection </span><span class="keyword">implements </span><span class="default">IteratorAggregate<br /></span><span class="keyword">{<br />&nbsp; &nbsp; private </span><span class="default">$items </span><span class="keyword">= array();<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">addValue</span><span class="keyword">(</span><span class="default">$item</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">items</span><span class="keyword">[] = </span><span class="default">$item</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">getIterator</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach (</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">items </span><span class="keyword">as </span><span class="default">$item</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; yield </span><span class="default">$item</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="comment">//Initializes a collection<br /></span><span class="default">$collection </span><span class="keyword">= new </span><span class="default">ValueCollection</span><span class="keyword">();<br /></span><span class="default">$collection<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">-&gt;</span><span class="default">addValue</span><span class="keyword">(</span><span class="string">'A string'</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; -&gt;</span><span class="default">addValue</span><span class="keyword">(new </span><span class="default">stdClass</span><span class="keyword">())<br />&nbsp; &nbsp; &nbsp; &nbsp; -&gt;</span><span class="default">addValue</span><span class="keyword">(</span><span class="default">NULL</span><span class="keyword">);<br /><br />foreach (</span><span class="default">$collection </span><span class="keyword">as </span><span class="default">$item</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$item</span><span class="keyword">);<br />}</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118526">  <div class="votes">
    <div id="Vu118526">
    <a href="/manual/vote-note.php?id=118526&amp;page=language.generators.syntax&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118526">
    <a href="/manual/vote-note.php?id=118526&amp;page=language.generators.syntax&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118526" title="71% like this...">
    3
    </div>
  </div>
  <a href="#118526" class="name">
  <strong class="user"><em>Hayley Watson</em></strong></a><a class="genanchor" href="#118526"> &para;</a><div class="date" title="2015-12-21 09:14"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom118526">
<div class="phpcode"><code><span class="html">
If for some strange reason you need a generator that doesn't yield anything, an empty function doesn't work; the function needs a yield statement to be recognised as a generator.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">gndn</span><span class="keyword">()<br />{<br />}<br /><br />foreach(</span><span class="default">gndn</span><span class="keyword">() as </span><span class="default">$it</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; echo </span><span class="string">'FNORD'</span><span class="keyword">;<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br /> But it's enough to have the yield syntactically present even if it's not reachable:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">gndn</span><span class="keyword">()<br />{<br />&nbsp; &nbsp; if(</span><span class="default">false</span><span class="keyword">) { yield; }<br />}<br /><br />foreach(</span><span class="default">gndn</span><span class="keyword">() as </span><span class="default">$it</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; echo </span><span class="string">'FNORD'</span><span class="keyword">;<br />}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113636">  <div class="votes">
    <div id="Vu113636">
    <a href="/manual/vote-note.php?id=113636&amp;page=language.generators.syntax&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113636">
    <a href="/manual/vote-note.php?id=113636&amp;page=language.generators.syntax&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113636" title="53% like this...">
    1
    </div>
  </div>
  <a href="#113636" class="name">
  <strong class="user"><em>Shumeyko Dmitriy</em></strong></a><a class="genanchor" href="#113636"> &para;</a><div class="date" title="2013-11-08 07:46"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113636">
<div class="phpcode"><code><span class="html">
This is little example of using generators with recursion. Used version of php is 5.5.5<br />[php]<br /><span class="default">&lt;?php<br />define </span><span class="keyword">(</span><span class="string">"DS"</span><span class="keyword">, </span><span class="default">DIRECTORY_SEPARATOR</span><span class="keyword">);<br /></span><span class="default">define </span><span class="keyword">(</span><span class="string">"ZERO_DEPTH"</span><span class="keyword">, </span><span class="default">0</span><span class="keyword">);<br /></span><span class="default">define </span><span class="keyword">(</span><span class="string">"DEPTHLESS"</span><span class="keyword">, -</span><span class="default">1</span><span class="keyword">);<br /></span><span class="default">define </span><span class="keyword">(</span><span class="string">"OPEN_SUCCESS"</span><span class="keyword">, </span><span class="default">True</span><span class="keyword">);<br /></span><span class="default">define </span><span class="keyword">(</span><span class="string">"END_OF_LIST"</span><span class="keyword">, </span><span class="default">False</span><span class="keyword">);<br /></span><span class="default">define </span><span class="keyword">(</span><span class="string">"CURRENT_DIR"</span><span class="keyword">, </span><span class="string">"."</span><span class="keyword">);<br /></span><span class="default">define </span><span class="keyword">(</span><span class="string">"PARENT_DIR"</span><span class="keyword">, </span><span class="string">".."</span><span class="keyword">);<br /><br />function </span><span class="default">DirTreeTraversal</span><span class="keyword">(</span><span class="default">$DirName</span><span class="keyword">, </span><span class="default">$MaxDepth </span><span class="keyword">= </span><span class="default">DEPTHLESS</span><span class="keyword">, </span><span class="default">$CurrDepth </span><span class="keyword">= </span><span class="default">ZERO_DEPTH</span><span class="keyword">)<br />{<br />&nbsp; if ((</span><span class="default">$MaxDepth </span><span class="keyword">=== </span><span class="default">DEPTHLESS</span><span class="keyword">) || (</span><span class="default">$CurrDepth </span><span class="keyword">&lt; </span><span class="default">$MaxDepth</span><span class="keyword">)) { <br />&nbsp; &nbsp; </span><span class="default">$DirHandle </span><span class="keyword">= </span><span class="default">opendir</span><span class="keyword">(</span><span class="default">$DirName</span><span class="keyword">);<br />&nbsp; &nbsp; if (</span><span class="default">$DirHandle </span><span class="keyword">!== </span><span class="default">OPEN_SUCCESS</span><span class="keyword">) { <br />&nbsp; &nbsp; &nbsp; try{<br />&nbsp; &nbsp; &nbsp; &nbsp; while ((</span><span class="default">$FileName </span><span class="keyword">= </span><span class="default">readdir</span><span class="keyword">(</span><span class="default">$DirHandle</span><span class="keyword">)) !== </span><span class="default">END_OF_LIST</span><span class="keyword">) { </span><span class="comment">//read all file in directory<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">if ((</span><span class="default">$FileName </span><span class="keyword">!= </span><span class="default">CURRENT_DIR</span><span class="keyword">) &amp;&amp; (</span><span class="default">$FileName </span><span class="keyword">!= </span><span class="default">PARENT_DIR</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$FullName </span><span class="keyword">= </span><span class="default">$DirName</span><span class="keyword">.</span><span class="default">$FileName</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; yield </span><span class="default">$FullName</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">is_dir</span><span class="keyword">(</span><span class="default">$FullName</span><span class="keyword">)) { </span><span class="comment">//include sub files and directories<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$SubTrav </span><span class="keyword">= </span><span class="default">DirTreeTraversal</span><span class="keyword">(</span><span class="default">$FullName</span><span class="keyword">.</span><span class="default">DS</span><span class="keyword">, </span><span class="default">$MaxDepth</span><span class="keyword">, (</span><span class="default">$CurrDepth </span><span class="keyword">+ </span><span class="default">1</span><span class="keyword">));<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; foreach(</span><span class="default">$SubTrav </span><span class="keyword">as </span><span class="default">$SubItem</span><span class="keyword">) yield </span><span class="default">$SubItem</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; } finally {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">closedir</span><span class="keyword">(</span><span class="default">$DirHandle</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; }<br />}<br /><br /></span><span class="default">$PathTrav </span><span class="keyword">= </span><span class="default">DirTreeTraversal</span><span class="keyword">(</span><span class="string">"C:"</span><span class="keyword">.</span><span class="default">DS</span><span class="keyword">, </span><span class="default">2</span><span class="keyword">);<br />print </span><span class="string">"&lt;pre&gt;"</span><span class="keyword">;<br />foreach(</span><span class="default">$PathTrav </span><span class="keyword">as </span><span class="default">$FileName</span><span class="keyword">) </span><span class="default">printf</span><span class="keyword">(</span><span class="string">"%s\n"</span><span class="keyword">, </span><span class="default">$FileName</span><span class="keyword">);<br />print </span><span class="string">"&lt;/pre&gt;"</span><span class="keyword">;<br />[/</span><span class="default">php</span><span class="keyword">]</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114844">  <div class="votes">
    <div id="Vu114844">
    <a href="/manual/vote-note.php?id=114844&amp;page=language.generators.syntax&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114844">
    <a href="/manual/vote-note.php?id=114844&amp;page=language.generators.syntax&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114844" title="28% like this...">
    -16
    </div>
  </div>
  <a href="#114844" class="name">
  <strong class="user"><em>denshadewillspam at HOTMAIL dot com</em></strong></a><a class="genanchor" href="#114844"> &para;</a><div class="date" title="2014-04-13 10:46"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114844">
<div class="phpcode"><code><span class="html">
Note that you can't use count() on generators.<br /><br />/**<br /> * @return integer[]<br /> */<br />function xrange() {<br />&nbsp; &nbsp; for ($a = 0; $a &lt; 10; $a++)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; yield $a;<br />&nbsp; &nbsp; }<br />}<br /><br />function mycount(Traversable $traversable)<br />{<br />&nbsp; &nbsp; $skip = 0;<br />&nbsp; &nbsp; foreach($traversable as $skip)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; $skip++;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; return $skip;<br />}<br />echo "Count:" . count(xrange()). PHP_EOL;<br />echo "Count:" . mycount(xrange()). PHP_EOL;</span>
</code></div>
  </div>
 </div>
  <div class="note" id="115863">  <div class="votes">
    <div id="Vu115863">
    <a href="/manual/vote-note.php?id=115863&amp;page=language.generators.syntax&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115863">
    <a href="/manual/vote-note.php?id=115863&amp;page=language.generators.syntax&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115863" title="16% like this...">
    -8
    </div>
  </div>
  <a href="#115863" class="name">
  <strong class="user"><em>dejiakala at gmail dot com</em></strong></a><a class="genanchor" href="#115863"> &para;</a><div class="date" title="2014-10-05 08:31"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115863">
<div class="phpcode"><code><span class="html">
Another Fibonacci sequence with yield keyword:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">getFibonacci</span><span class="keyword">(</span><span class="default">$first</span><span class="keyword">, </span><span class="default">$second</span><span class="keyword">, </span><span class="default">$total</span><span class="keyword">) {<br />&nbsp; yield </span><span class="default">$first</span><span class="keyword">;<br />&nbsp; yield </span><span class="default">$second</span><span class="keyword">;<br />&nbsp; for (</span><span class="default">$i </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">, </span><span class="default">$total </span><span class="keyword">-= </span><span class="default">2</span><span class="keyword">; </span><span class="default">$i </span><span class="keyword">&lt;= </span><span class="default">$total</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">++) {<br />&nbsp; &nbsp; </span><span class="default">$sum </span><span class="keyword">= </span><span class="default">$first </span><span class="keyword">+ </span><span class="default">$second</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$first </span><span class="keyword">= </span><span class="default">$second</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$second </span><span class="keyword">= </span><span class="default">$sum</span><span class="keyword">;<br />&nbsp; &nbsp; yield </span><span class="default">$sum</span><span class="keyword">;<br />&nbsp; }<br />}<br /><br /></span><span class="comment">// Generate first 10 numbers of the Fibonacci sequence starting from 0, 1<br /></span><span class="keyword">foreach (</span><span class="default">getFibonacci</span><span class="keyword">(</span><span class="default">0</span><span class="keyword">, </span><span class="default">1</span><span class="keyword">, </span><span class="default">10</span><span class="keyword">) as </span><span class="default">$fibonacci</span><span class="keyword">) {<br />&nbsp; </span><span class="comment">// 0 1 1 2 3 5 8 13 21 34<br />&nbsp; </span><span class="keyword">echo </span><span class="default">$fibonacci </span><span class="keyword">. </span><span class="string">" "</span><span class="keyword">; <br />}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.generators.syntax&amp;redirect=http://php.net/manual/en/language.generators.syntax.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.generators.php">Generators</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.generators.overview.php" title="Generators overview">Generators overview</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.generators.syntax.php" title="Generator syntax">Generator syntax</a>
                        </li>
                          
                        <li class="">
                            <a href="language.generators.comparison.php" title="Comparing generators with Iterator objects">Comparing generators with Iterator objects</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

