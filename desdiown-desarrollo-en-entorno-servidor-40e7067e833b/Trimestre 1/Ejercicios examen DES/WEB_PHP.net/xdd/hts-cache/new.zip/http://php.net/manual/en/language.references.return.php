<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Returning References - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.references.return.php">
 <link rel="shorturl" href="http://php.net/references.return">
 <link rel="alternate" href="http://php.net/references.return" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.references.php">
 <link rel="prev" href="http://php.net/manual/en/language.references.pass.php">
 <link rel="next" href="http://php.net/manual/en/language.references.unset.php">

 <link rel="alternate" href="http://php.net/manual/en/language.references.return.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.references.return.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.references.return.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.references.return.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.references.return.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.references.return.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.references.return.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.references.return.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.references.return.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.references.return.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.references.return.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.references.unset.php">
          Unsetting References &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.references.pass.php">
          &laquo; Passing by Reference        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.references.php'>References Explained</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.references.return.php' selected="selected">English</option>
            <option value='pt_BR/language.references.return.php'>Brazilian Portuguese</option>
            <option value='zh/language.references.return.php'>Chinese (Simplified)</option>
            <option value='fr/language.references.return.php'>French</option>
            <option value='de/language.references.return.php'>German</option>
            <option value='ja/language.references.return.php'>Japanese</option>
            <option value='ro/language.references.return.php'>Romanian</option>
            <option value='ru/language.references.return.php'>Russian</option>
            <option value='es/language.references.return.php'>Spanish</option>
            <option value='tr/language.references.return.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.references.return.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.references.return">Report a Bug</a>
    </div>
  </div><div id="language.references.return" class="sect1">
   <h2 class="title">Returning References</h2>
   <p class="para">
    Returning by reference is useful when you want to use a function
    to find to which variable a reference should be bound. Do
    <em class="emphasis">not</em> use return-by-reference to increase performance.
    The engine will automatically optimize this on its own. Only return
    references when you have a valid technical reason to do so. To
    return references, use this syntax:
    <div class="informalexample">
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">foo&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;</span><span style="color: #0000BB">$value&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">42</span><span style="color: #007700">;<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;&amp;</span><span style="color: #0000BB">getValue</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">value</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br /></span><span style="color: #0000BB">$obj&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">foo</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$myValue&nbsp;</span><span style="color: #007700">=&nbsp;&amp;</span><span style="color: #0000BB">$obj</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">getValue</span><span style="color: #007700">();&nbsp;</span><span style="color: #FF8000">//&nbsp;$myValue&nbsp;is&nbsp;a&nbsp;reference&nbsp;to&nbsp;$obj-&gt;value,&nbsp;which&nbsp;is&nbsp;42.<br /></span><span style="color: #0000BB">$obj</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">value&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">;<br />echo&nbsp;</span><span style="color: #0000BB">$myValue</span><span style="color: #007700">;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;prints&nbsp;the&nbsp;new&nbsp;value&nbsp;of&nbsp;$obj-&gt;value,&nbsp;i.e.&nbsp;2.<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
    In this example, the property of the object returned by the
    <var class="varname"><var class="varname">getValue</var></var> function would be set, not the
    copy, as it would be without using reference syntax.
   </p>
   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <span class="simpara">
     Unlike parameter passing, here you have to use
     <em>&amp;</em> in both places - to indicate that you
     want to return by reference, not a copy, and to indicate that
     reference binding, rather than usual assignment, should be done
     for <var class="varname"><var class="varname">$myValue</var></var>.
    </span>
   </p></blockquote>
   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <span class="simpara">
     If you try to return a reference from a function with the syntax:
     <em>return ($this-&gt;value);</em> this will <em class="emphasis">not</em>
     work as you are attempting to return the result of an
     <em class="emphasis">expression</em>, and not a variable, by reference. You can
     only return variables by reference from a function - nothing else.
     Since PHP 5.1.0, an
     <strong><code>E_NOTICE</code></strong> error is issued if the code tries to return
     a dynamic expression or a result of the <em>new</em> operator.
    </span>
   </p></blockquote>
   <p class="para">
   To use the returned reference, you must use reference assigment:
    <div class="informalexample">
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;&amp;</span><span style="color: #0000BB">collector</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;static&nbsp;</span><span style="color: #0000BB">$collection&nbsp;</span><span style="color: #007700">=&nbsp;array();<br />&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">$collection</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">$collection&nbsp;</span><span style="color: #007700">=&nbsp;&amp;</span><span style="color: #0000BB">collector</span><span style="color: #007700">();<br /></span><span style="color: #0000BB">$collection</span><span style="color: #007700">[]&nbsp;=&nbsp;</span><span style="color: #DD0000">'foo'</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   To pass the returned reference to another function expecting a reference
   you can use this syntax:
    <div class="informalexample">
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;&amp;</span><span style="color: #0000BB">collector</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;static&nbsp;</span><span style="color: #0000BB">$collection&nbsp;</span><span style="color: #007700">=&nbsp;array();<br />&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">$collection</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">array_push</span><span style="color: #007700">(</span><span style="color: #0000BB">collector</span><span style="color: #007700">(),&nbsp;</span><span style="color: #DD0000">'foo'</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>
   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <span class="simpara">
      Note that <em>array_push(&amp;collector(), &#039;foo&#039;);</em> will
      <em class="emphasis">not</em> work, it results in a fatal error.
    </span>
   </p></blockquote>
  </div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.references.return&amp;redirect=http://php.net/manual/en/language.references.return.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">16 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="80776">  <div class="votes">
    <div id="Vu80776">
    <a href="/manual/vote-note.php?id=80776&amp;page=language.references.return&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd80776">
    <a href="/manual/vote-note.php?id=80776&amp;page=language.references.return&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V80776" title="82% like this...">
    64
    </div>
  </div>
  <a href="#80776" class="name">
  <strong class="user"><em>Spad-XIII</em></strong></a><a class="genanchor" href="#80776"> &para;</a><div class="date" title="2008-01-31 05:01"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom80776">
<div class="phpcode"><code><span class="html">
a little addition to the example of pixel at minikomp dot com here below<br /><span class="default">&lt;?php<br /><br />&nbsp; &nbsp; </span><span class="keyword">function &amp;</span><span class="default">func</span><span class="keyword">(){<br />&nbsp; &nbsp; &nbsp; &nbsp; static </span><span class="default">$static </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$static</span><span class="keyword">++;<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$static</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="default">$var1 </span><span class="keyword">=&amp; </span><span class="default">func</span><span class="keyword">();<br />&nbsp; &nbsp; echo </span><span class="string">"var1:"</span><span class="keyword">, </span><span class="default">$var1</span><span class="keyword">; </span><span class="comment">// 1<br />&nbsp; &nbsp; </span><span class="default">func</span><span class="keyword">();<br />&nbsp; &nbsp; </span><span class="default">func</span><span class="keyword">();<br />&nbsp; &nbsp; echo </span><span class="string">"var1:"</span><span class="keyword">, </span><span class="default">$var1</span><span class="keyword">; </span><span class="comment">// 3<br />&nbsp; &nbsp; </span><span class="default">$var2 </span><span class="keyword">= </span><span class="default">func</span><span class="keyword">(); </span><span class="comment">// assignment without the &amp;<br />&nbsp; &nbsp; </span><span class="keyword">echo </span><span class="string">"var2:"</span><span class="keyword">, </span><span class="default">$var2</span><span class="keyword">; </span><span class="comment">// 4<br />&nbsp; &nbsp; </span><span class="default">func</span><span class="keyword">();<br />&nbsp; &nbsp; </span><span class="default">func</span><span class="keyword">();<br />&nbsp; &nbsp; echo </span><span class="string">"var1:"</span><span class="keyword">, </span><span class="default">$var1</span><span class="keyword">; </span><span class="comment">// 6<br />&nbsp; &nbsp; </span><span class="keyword">echo </span><span class="string">"var2:"</span><span class="keyword">, </span><span class="default">$var2</span><span class="keyword">; </span><span class="comment">// still 4<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="102139">  <div class="votes">
    <div id="Vu102139">
    <a href="/manual/vote-note.php?id=102139&amp;page=language.references.return&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd102139">
    <a href="/manual/vote-note.php?id=102139&amp;page=language.references.return&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V102139" title="80% like this...">
    9
    </div>
  </div>
  <a href="#102139" class="name">
  <strong class="user"><em>szymoncofalik at gmail dot com</em></strong></a><a class="genanchor" href="#102139"> &para;</a><div class="date" title="2011-01-28 12:41"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom102139">
<div class="phpcode"><code><span class="html">
Sometimes, you would like to return NULL with a function returning reference, to indicate the end of chain of elements. However this generates E_NOTICE. Here is little tip, how to prevent that:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Foo </span><span class="keyword">{<br />&nbsp;&nbsp; const </span><span class="default">$nullGuard </span><span class="keyword">= </span><span class="default">NULL</span><span class="keyword">;<br />&nbsp;&nbsp; </span><span class="comment">// ... some declarations and definitions<br />&nbsp;&nbsp; </span><span class="keyword">public function &amp;</span><span class="default">next</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; </span><span class="comment">// ...<br />&nbsp; &nbsp; &nbsp; </span><span class="keyword">if (!</span><span class="default">$end</span><span class="keyword">) return </span><span class="default">$bar</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; else return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">nullGuard</span><span class="keyword">;<br />&nbsp;&nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />by doing this you can do smth like this without notices:<br /><br /><span class="default">&lt;?php<br />$f </span><span class="keyword">= new </span><span class="default">Foo</span><span class="keyword">();<br /></span><span class="comment">// ...<br /></span><span class="keyword">while ((</span><span class="default">$item </span><span class="keyword">= </span><span class="default">$f</span><span class="keyword">-&gt;</span><span class="default">next</span><span class="keyword">()) != </span><span class="default">NULL</span><span class="keyword">) {<br /></span><span class="comment">// ...<br /></span><span class="keyword">}<br /></span><span class="default">?&gt;<br /></span><br />you may also use global variable:<br />global $nullGuard;<br />return $nullGuard;</span>
</code></div>
  </div>
 </div>
  <div class="note" id="115745">  <div class="votes">
    <div id="Vu115745">
    <a href="/manual/vote-note.php?id=115745&amp;page=language.references.return&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115745">
    <a href="/manual/vote-note.php?id=115745&amp;page=language.references.return&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115745" title="80% like this...">
    3
    </div>
  </div>
  <a href="#115745" class="name">
  <strong class="user"><em>civilization28 at gmail dot com</em></strong></a><a class="genanchor" href="#115745"> &para;</a><div class="date" title="2014-09-17 01:49"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115745">
<div class="phpcode"><code><span class="html">
Zayfod's example above is useful, but I feel that it needs more explanation. The point that should be made is that a parameter passed in by reference can be changed to reference something else, resulting in later changes to the local variable not affecting the passed in variable:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function&nbsp; &nbsp; &amp; </span><span class="default">func_b </span><span class="keyword">()<br />{<br />&nbsp; &nbsp; </span><span class="default">$some_var </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">;<br />&nbsp; &nbsp; return </span><span class="default">$some_var</span><span class="keyword">;<br />}<br /><br />function&nbsp; &nbsp; </span><span class="default">func_a </span><span class="keyword">(&amp; </span><span class="default">$param</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="comment"># $param is 1 here<br />&nbsp; &nbsp; </span><span class="default">$param </span><span class="keyword">= &amp; </span><span class="default">func_b</span><span class="keyword">();&nbsp; &nbsp; </span><span class="comment"># Here the reference is changed and<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; # the "&amp;" in "func_a (&amp; $param)"<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; # is no longer in effect at all.<br />&nbsp; &nbsp; # $param is 2 here<br />&nbsp; &nbsp; </span><span class="default">$param</span><span class="keyword">++;&nbsp; &nbsp; </span><span class="comment"># Has no effect on $var.<br /></span><span class="keyword">}<br /><br /></span><span class="default">$var </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br /></span><span class="default">func_a</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">);<br /></span><span class="comment"># $var is still 1 here!!!&nbsp; &nbsp; Because the reference was changed.<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="96860">  <div class="votes">
    <div id="Vu96860">
    <a href="/manual/vote-note.php?id=96860&amp;page=language.references.return&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd96860">
    <a href="/manual/vote-note.php?id=96860&amp;page=language.references.return&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V96860" title="77% like this...">
    5
    </div>
  </div>
  <a href="#96860" class="name">
  <strong class="user"><em>spidgorny at gmail dot com</em></strong></a><a class="genanchor" href="#96860"> &para;</a><div class="date" title="2010-03-19 06:18"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom96860">
<div class="phpcode"><code><span class="html">
When returning reference to the object member which is instantiated inside the function, the object is destructed upon returning (which is a problem). It's easier to see the code:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">MemcacheArray </span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$data</span><span class="keyword">;<br /><br />&nbsp; &nbsp; ...<br /><br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Super-clever one line cache reading AND WRITING!<br />&nbsp; &nbsp;&nbsp; * Usage $data = &amp;MemcacheArray::getData(__METHOD__);<br />&nbsp; &nbsp;&nbsp; * Hopefully PHP will know that $this-&gt;data is still used <br />&nbsp; &nbsp;&nbsp; * and will call destructor after data changes.<br />&nbsp; &nbsp;&nbsp; * Ooops, it's not the case.&nbsp; &nbsp; <br />&nbsp; &nbsp;&nbsp; *<br />&nbsp; &nbsp;&nbsp; * @return unknown<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">function &amp;</span><span class="default">getData</span><span class="keyword">(</span><span class="default">$file</span><span class="keyword">, </span><span class="default">$expire </span><span class="keyword">= </span><span class="default">3600</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$o </span><span class="keyword">= new </span><span class="default">MemcacheArray</span><span class="keyword">(</span><span class="default">$file</span><span class="keyword">, </span><span class="default">$expire</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$o</span><span class="keyword">-&gt;</span><span class="default">data</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /></span><span class="default">?&gt;<br /></span><br />Here, destructor is called upon return() and the reference becomes a normal variable.<br /><br />My solution is to store objects in a pool until the final exit(), but I don't like it. Any other ideas?<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">protected static </span><span class="default">$instances </span><span class="keyword">= array();<br /><br />&nbsp; &nbsp; function &amp;</span><span class="default">getData</span><span class="keyword">(</span><span class="default">$file</span><span class="keyword">, </span><span class="default">$expire </span><span class="keyword">= </span><span class="default">3600</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$o </span><span class="keyword">= new </span><span class="default">MemcacheArray</span><span class="keyword">(</span><span class="default">$file</span><span class="keyword">, </span><span class="default">$expire</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">$instances</span><span class="keyword">[</span><span class="default">$file</span><span class="keyword">] = </span><span class="default">$o</span><span class="keyword">; </span><span class="comment">// keep object from destructing too early<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">$o</span><span class="keyword">-&gt;</span><span class="default">data</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="62391">  <div class="votes">
    <div id="Vu62391">
    <a href="/manual/vote-note.php?id=62391&amp;page=language.references.return&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd62391">
    <a href="/manual/vote-note.php?id=62391&amp;page=language.references.return&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V62391" title="80% like this...">
    3
    </div>
  </div>
  <a href="#62391" class="name">
  <strong class="user"><em>rwruck</em></strong></a><a class="genanchor" href="#62391"> &para;</a><div class="date" title="2006-02-27 09:22"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom62391">
<div class="phpcode"><code><span class="html">
The note about using parentheses when returning references is only true if the variable you try to return does not already contain a reference.<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">// Will return a reference<br /></span><span class="keyword">function&amp; </span><span class="default">getref1</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; </span><span class="default">$ref </span><span class="keyword">=&amp; </span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">'somevar'</span><span class="keyword">];<br />&nbsp; return (</span><span class="default">$ref</span><span class="keyword">);<br />&nbsp; }<br /><br /></span><span class="comment">// Will return a value (and emit a notice)<br /></span><span class="keyword">function&amp; </span><span class="default">getref2</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; </span><span class="default">$ref </span><span class="keyword">= </span><span class="default">42</span><span class="keyword">;<br />&nbsp; return (</span><span class="default">$ref</span><span class="keyword">);<br />&nbsp; }<br /><br /></span><span class="comment">// Will return a reference<br /></span><span class="keyword">function&amp; </span><span class="default">getref3</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; static </span><span class="default">$ref </span><span class="keyword">= </span><span class="default">42</span><span class="keyword">;<br />&nbsp; return (</span><span class="default">$ref</span><span class="keyword">);<br />&nbsp; }<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="78123">  <div class="votes">
    <div id="Vu78123">
    <a href="/manual/vote-note.php?id=78123&amp;page=language.references.return&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd78123">
    <a href="/manual/vote-note.php?id=78123&amp;page=language.references.return&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V78123" title="73% like this...">
    11
    </div>
  </div>
  <a href="#78123" class="name">
  <strong class="user"><em>stanlemon at mac dot com</em></strong></a><a class="genanchor" href="#78123"> &para;</a><div class="date" title="2007-09-28 10:51"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom78123">
<div class="phpcode"><code><span class="html">
I haven't seen anyone note method chaining in PHP5.&nbsp; When an object is returned by a method in PHP5 it is returned by default as a reference, and the new Zend Engine 2 allows you to chain method calls from those returned objects.&nbsp; For example consider this code:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">Foo </span><span class="keyword">{<br /><br />&nbsp; &nbsp; protected </span><span class="default">$bar</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">bar </span><span class="keyword">= new </span><span class="default">Bar</span><span class="keyword">();<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; print </span><span class="string">"Foo\n"</span><span class="keyword">;<br />&nbsp; &nbsp; }&nbsp; &nbsp; <br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">getBar</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">bar</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">Bar </span><span class="keyword">{<br /><br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; print </span><span class="string">"Bar\n"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">helloWorld</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; print </span><span class="string">"Hello World\n"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />function </span><span class="default">test</span><span class="keyword">() {<br />&nbsp; &nbsp; return new </span><span class="default">Foo</span><span class="keyword">();<br />}<br /><br /></span><span class="default">test</span><span class="keyword">()-&gt;</span><span class="default">getBar</span><span class="keyword">()-&gt;</span><span class="default">helloWorld</span><span class="keyword">();<br /><br /></span><span class="default">?&gt;<br /></span><br />Notice how we called test() which was not on an object, but returned an instance of Foo, followed by a method on Foo, getBar() which returned an instance of Bar and finally called one of its methods helloWorld().&nbsp; Those familiar with other interpretive languages (Java to name one) will recognize this functionality.&nbsp; For whatever reason this change doesn't seem to be documented very well, so hopefully someone will find this helpful.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="48468">  <div class="votes">
    <div id="Vu48468">
    <a href="/manual/vote-note.php?id=48468&amp;page=language.references.return&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd48468">
    <a href="/manual/vote-note.php?id=48468&amp;page=language.references.return&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V48468" title="72% like this...">
    11
    </div>
  </div>
  <a href="#48468" class="name">
  <strong class="user"><em>obscvresovl at NOSPAM dot hotmail dot com</em></strong></a><a class="genanchor" href="#48468"> &para;</a><div class="date" title="2004-12-24 01:09"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom48468">
<div class="phpcode"><code><span class="html">
An example of returning references:<br /><br />&lt;?<br /><br />$var = 1;<br />$num = NULL;<br /><br />function &amp;blah()<br />{<br />&nbsp; &nbsp; $var =&amp; $GLOBALS["var"]; # the same as global $var;<br />&nbsp; &nbsp; $var++;<br />&nbsp; &nbsp; return $var;<br />}<br /><br />$num = &amp;blah();<br /><br />echo $num; # 2<br /><br />blah();<br /><br />echo $num; # 3<br /><br />?&gt;<br /><br />Note: if you take the &amp; off from the function, the second echo will be 2, because without &amp; the var $num contains its returning value and not its returning reference.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="86761">  <div class="votes">
    <div id="Vu86761">
    <a href="/manual/vote-note.php?id=86761&amp;page=language.references.return&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86761">
    <a href="/manual/vote-note.php?id=86761&amp;page=language.references.return&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86761" title="71% like this...">
    6
    </div>
  </div>
  <a href="#86761" class="name">
  <strong class="user"><em>sandaimespaceman at gmail dot com</em></strong></a><a class="genanchor" href="#86761"> &para;</a><div class="date" title="2008-11-02 08:52"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86761">
<div class="phpcode"><code><span class="html">
The &amp;b() function returns a reference of $a in the global scope.<br /><br /><span class="default">&lt;?php<br />$a </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />function &amp;</span><span class="default">b</span><span class="keyword">()<br />{<br />&nbsp; &nbsp; global </span><span class="default">$a</span><span class="keyword">;<br />&nbsp; &nbsp; return </span><span class="default">$a</span><span class="keyword">;<br />}<br /></span><span class="default">$c </span><span class="keyword">= &amp;</span><span class="default">b</span><span class="keyword">();<br /></span><span class="default">$c</span><span class="keyword">++;<br />echo<br /></span><span class="string">"<br />\$a: </span><span class="default">$a</span><span class="string"><br />\$b: </span><span class="default">$c</span><span class="string"><br />"<br /></span><span class="default">?&gt;<br /></span><br />It outputs:<br /><br />$a: 1 $b: 1</span>
</code></div>
  </div>
 </div>
  <div class="note" id="102593">  <div class="votes">
    <div id="Vu102593">
    <a href="/manual/vote-note.php?id=102593&amp;page=language.references.return&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd102593">
    <a href="/manual/vote-note.php?id=102593&amp;page=language.references.return&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V102593" title="71% like this...">
    3
    </div>
  </div>
  <a href="#102593" class="name">
  <strong class="user"><em>benjamin dot delespierre at gmail dot com</em></strong></a><a class="genanchor" href="#102593"> &para;</a><div class="date" title="2011-02-23 05:36"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom102593">
<div class="phpcode"><code><span class="html">
Keep in mind that returning by reference doesn't work with __callStatic:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Test </span><span class="keyword">{<br />&nbsp; private static </span><span class="default">$_inst</span><span class="keyword">;<br />&nbsp; public static function &amp; </span><span class="default">__callStatic </span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">, </span><span class="default">$args</span><span class="keyword">) {<br />&nbsp; &nbsp; if (!isset(static::</span><span class="default">$_inst</span><span class="keyword">)){ <br />&nbsp; &nbsp; &nbsp; echo </span><span class="string">"create"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; static::</span><span class="default">$_inst </span><span class="keyword">= (object)</span><span class="string">"test"</span><span class="keyword">;<br />&nbsp;&nbsp; }<br />&nbsp;&nbsp; return static::</span><span class="default">$_inst</span><span class="keyword">;<br />}<br /><br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$a </span><span class="keyword">= &amp;</span><span class="default">Test</span><span class="keyword">::</span><span class="default">abc</span><span class="keyword">()); </span><span class="comment">// prints 'create'<br /></span><span class="default">$a </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">Test</span><span class="keyword">::</span><span class="default">abc</span><span class="keyword">()); </span><span class="comment">// doesn't prints and the instance still exists in Test::$_inst<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="72824">  <div class="votes">
    <div id="Vu72824">
    <a href="/manual/vote-note.php?id=72824&amp;page=language.references.return&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd72824">
    <a href="/manual/vote-note.php?id=72824&amp;page=language.references.return&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V72824" title="66% like this...">
    1
    </div>
  </div>
  <a href="#72824" class="name">
  <strong class="user"><em>php at thunder-2000 dot com</em></strong></a><a class="genanchor" href="#72824"> &para;</a><div class="date" title="2007-02-02 02:31"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom72824">
<div class="phpcode"><code><span class="html">
If you want to get a part of an array to manipulate, you can use this function<br /><br />function &amp;getArrayField(&amp;$array,$path) {<br />&nbsp; if (!empty($path)) {<br />&nbsp; &nbsp; if (empty($array[$path[0]])) return NULL;<br />&nbsp; &nbsp; else return getArrayField($array[$path[0]], array_slice($path, 1));<br />&nbsp; } else {<br />&nbsp; &nbsp; return $array;<br />&nbsp; }<br />}<br /><br />Use it like this:<br /><br />$partArray =&amp; getArrayField($GLOBALS,array("config","modul1"));<br /><br />You can manipulate $partArray and the changes are also made with $GLOBALS.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="57632">  <div class="votes">
    <div id="Vu57632">
    <a href="/manual/vote-note.php?id=57632&amp;page=language.references.return&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd57632">
    <a href="/manual/vote-note.php?id=57632&amp;page=language.references.return&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V57632" title="60% like this...">
    1
    </div>
  </div>
  <a href="#57632" class="name">
  <strong class="user"><em>willem at designhulp dot nl</em></strong></a><a class="genanchor" href="#57632"> &para;</a><div class="date" title="2005-10-09 04:54"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom57632">
<div class="phpcode"><code><span class="html">
There is an important difference between php5 and php4 with references.<br /><br />Lets say you have a class with a method called 'get_instance' to get a reference to an exsisting class and it's properties.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">mysql </span><span class="keyword">{<br />&nbsp; &nbsp; function </span><span class="default">get_instance</span><span class="keyword">(){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// check if object exsists<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">if(empty(</span><span class="default">$_ENV</span><span class="keyword">[</span><span class="string">'instances'</span><span class="keyword">][</span><span class="string">'mysql'</span><span class="keyword">])){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// no object yet, create an object<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$_ENV</span><span class="keyword">[</span><span class="string">'instances'</span><span class="keyword">][</span><span class="string">'mysql'</span><span class="keyword">] = new </span><span class="default">mysql</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// return reference to object<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$ref </span><span class="keyword">= &amp;</span><span class="default">$_ENV</span><span class="keyword">[</span><span class="string">'instances'</span><span class="keyword">][</span><span class="string">'mysql'</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$ref</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />Now to get the exsisting object you can use<br />mysql::get_instance();<br /><br />Though this works in php4 and in php5, but in php4 all data will be lost as if it is a new object while in php5 all properties in the object remain.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="37961">  <div class="votes">
    <div id="Vu37961">
    <a href="/manual/vote-note.php?id=37961&amp;page=language.references.return&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd37961">
    <a href="/manual/vote-note.php?id=37961&amp;page=language.references.return&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V37961" title="60% like this...">
    1
    </div>
  </div>
  <a href="#37961" class="name">
  <strong class="user"><em>zayfod at yahoo dot com</em></strong></a><a class="genanchor" href="#37961"> &para;</a><div class="date" title="2003-12-03 09:23"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom37961">
<div class="phpcode"><code><span class="html">
There is a small exception to the note on this page of the documentation. You do not have to use &amp; to indicate that reference binding should be done when you assign to a value passed by reference the result of a function which returns by reference.<br /><br />Consider the following two exaples:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function&nbsp; &nbsp; &amp; </span><span class="default">func_b </span><span class="keyword">()<br />{<br />&nbsp; &nbsp; </span><span class="default">$some_var </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">;<br />&nbsp; &nbsp; return </span><span class="default">$some_var</span><span class="keyword">;<br />}<br /><br />function&nbsp; &nbsp; </span><span class="default">func_a </span><span class="keyword">(&amp; </span><span class="default">$param</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="comment"># $param is 1 here<br />&nbsp; &nbsp; </span><span class="default">$param </span><span class="keyword">= &amp; </span><span class="default">func_b</span><span class="keyword">();<br />&nbsp; &nbsp; </span><span class="comment"># $param is 2 here<br /></span><span class="keyword">}<br /><br /></span><span class="default">$var </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br /></span><span class="default">func_a</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">);<br /></span><span class="comment"># $var is still 1 here!!!<br /><br /></span><span class="default">?&gt;<br /></span><br />The second example works as intended:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function&nbsp; &nbsp; &amp; </span><span class="default">func_b </span><span class="keyword">()<br />{<br />&nbsp; &nbsp; </span><span class="default">$some_var </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">;<br />&nbsp; &nbsp; return </span><span class="default">$some_var</span><span class="keyword">;<br />}<br /><br />function&nbsp; &nbsp; </span><span class="default">func_a </span><span class="keyword">(&amp; </span><span class="default">$param</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="comment"># $param is 1 here<br />&nbsp; &nbsp; </span><span class="default">$param </span><span class="keyword">= </span><span class="default">func_b</span><span class="keyword">();<br />&nbsp; &nbsp; </span><span class="comment"># $param is 2 here<br /></span><span class="keyword">}<br /><br /></span><span class="default">$var </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br /></span><span class="default">func_a</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">);<br /></span><span class="comment"># $var is 2 here as intended<br /><br /></span><span class="default">?&gt;<br /></span><br />(Experienced with PHP 4.3.0)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114541">  <div class="votes">
    <div id="Vu114541">
    <a href="/manual/vote-note.php?id=114541&amp;page=language.references.return&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114541">
    <a href="/manual/vote-note.php?id=114541&amp;page=language.references.return&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114541" title="50% like this...">
    0
    </div>
  </div>
  <a href="#114541" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#114541"> &para;</a><div class="date" title="2014-03-05 04:18"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114541">
<div class="phpcode"><code><span class="html">
I learned a painful lesson working with a class method that would pass by reference.&nbsp;&nbsp; <br /><br />In short, if you have a method in a class that is initialed with ampersand during declaration, do not use another ampersand when using the method as in &amp;$this-&gt;method();<br /><br />For example<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">A </span><span class="keyword">{<br />&nbsp; &nbsp; public function &amp;</span><span class="default">hello</span><span class="keyword">(){<br />&nbsp; &nbsp; &nbsp; &nbsp; static </span><span class="default">$a</span><span class="keyword">=</span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$a</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public function </span><span class="default">bello</span><span class="keyword">(){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$b</span><span class="keyword">=&amp;</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">hello</span><span class="keyword">();&nbsp; </span><span class="comment">// incorrect. Do not use ampersand.<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$b</span><span class="keyword">=</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">hello</span><span class="keyword">();&nbsp; </span><span class="comment">// $b is a reference&nbsp; to the static variable.<br /></span><span class="keyword">}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="39841">  <div class="votes">
    <div id="Vu39841">
    <a href="/manual/vote-note.php?id=39841&amp;page=language.references.return&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd39841">
    <a href="/manual/vote-note.php?id=39841&amp;page=language.references.return&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V39841" title="100% like this...">
    1
    </div>
  </div>
  <a href="#39841" class="name">
  <strong class="user"><em>contact at infopol dot fr</em></strong></a><a class="genanchor" href="#39841"> &para;</a><div class="date" title="2004-02-12 09:36"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom39841">
<div class="phpcode"><code><span class="html">
A note about returning references embedded in non-reference arrays :<br /><br />&lt;?<br />$foo;<br /><br />function bar () {<br />&nbsp; &nbsp; global $foo;<br />&nbsp; &nbsp; $return = array();<br />&nbsp; &nbsp; $return[] =&amp; $foo;<br />&nbsp; &nbsp; return $return;<br />}<br /><br />$foo = 1;<br />$foobar = bar();<br />$foobar[0] = 2;<br />echo $foo;<br />?&gt;<br /><br />results in "2" because the reference is copied (pretty neat).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="40846">  <div class="votes">
    <div id="Vu40846">
    <a href="/manual/vote-note.php?id=40846&amp;page=language.references.return&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd40846">
    <a href="/manual/vote-note.php?id=40846&amp;page=language.references.return&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V40846" title="50% like this...">
    0
    </div>
  </div>
  <a href="#40846" class="name">
  <strong class="user"><em>hawcue at yahoo dot com</em></strong></a><a class="genanchor" href="#40846"> &para;</a><div class="date" title="2004-03-16 07:58"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom40846">
<div class="phpcode"><code><span class="html">
Be careful when using tinary operation condition?value1:value2<br /><br />See the following code:<br /><br />$a=1;<br />function &amp;foo()<br />{<br />&nbsp; global $a;<br />&nbsp; return isset($a)?$a:null;<br />}<br />$b=&amp;foo();<br />echo $b;&nbsp;&nbsp; // shows 1<br />$b=2;<br />echo $a;&nbsp;&nbsp; // shows 1 (not 2! because $b got a copy of $a)<br /><br />To let $b be a reference to $a, use "if..then.." in the function.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="80132">  <div class="votes">
    <div id="Vu80132">
    <a href="/manual/vote-note.php?id=80132&amp;page=language.references.return&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd80132">
    <a href="/manual/vote-note.php?id=80132&amp;page=language.references.return&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V80132" title="28% like this...">
    -3
    </div>
  </div>
  <a href="#80132" class="name">
  <strong class="user"><em>pixel at minikomp dot com</em></strong></a><a class="genanchor" href="#80132"> &para;</a><div class="date" title="2007-12-30 04:21"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom80132">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br /><br />&nbsp; &nbsp; </span><span class="keyword">function &amp;</span><span class="default">func</span><span class="keyword">(){<br />&nbsp; &nbsp; &nbsp; &nbsp; static </span><span class="default">$static </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$static</span><span class="keyword">++;<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$static</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="default">$var </span><span class="keyword">=&amp; </span><span class="default">func</span><span class="keyword">();<br />&nbsp; &nbsp; echo </span><span class="default">$var</span><span class="keyword">; </span><span class="comment">// 1<br />&nbsp; &nbsp; </span><span class="default">func</span><span class="keyword">();<br />&nbsp; &nbsp; </span><span class="default">func</span><span class="keyword">();<br />&nbsp; &nbsp; </span><span class="default">func</span><span class="keyword">();<br />&nbsp; &nbsp; </span><span class="default">func</span><span class="keyword">();<br />&nbsp; &nbsp; echo </span><span class="default">$var</span><span class="keyword">; </span><span class="comment">// 5<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.references.return&amp;redirect=http://php.net/manual/en/language.references.return.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.references.php">References Explained</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.references.whatare.php" title="What References Are">What References Are</a>
                        </li>
                          
                        <li class="">
                            <a href="language.references.whatdo.php" title="What References Do">What References Do</a>
                        </li>
                          
                        <li class="">
                            <a href="language.references.arent.php" title="What References Are Not">What References Are Not</a>
                        </li>
                          
                        <li class="">
                            <a href="language.references.pass.php" title="Passing by Reference">Passing by Reference</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.references.return.php" title="Returning References">Returning References</a>
                        </li>
                          
                        <li class="">
                            <a href="language.references.unset.php" title="Unsetting References">Unsetting References</a>
                        </li>
                          
                        <li class="">
                            <a href="language.references.spot.php" title="Spotting References">Spotting References</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

