<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: else - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/control-structures.else.php">
 <link rel="shorturl" href="http://php.net/else">
 <link rel="alternate" href="http://php.net/else" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.control-structures.php">
 <link rel="prev" href="http://php.net/manual/en/control-structures.if.php">
 <link rel="next" href="http://php.net/manual/en/control-structures.elseif.php">

 <link rel="alternate" href="http://php.net/manual/en/control-structures.else.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/control-structures.else.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/control-structures.else.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/control-structures.else.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/control-structures.else.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/control-structures.else.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/control-structures.else.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/control-structures.else.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/control-structures.else.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/control-structures.else.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/control-structures.else.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="control-structures.elseif.php">
          elseif/else if &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="control-structures.if.php">
          &laquo; if        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.control-structures.php'>Control Structures</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/control-structures.else.php' selected="selected">English</option>
            <option value='pt_BR/control-structures.else.php'>Brazilian Portuguese</option>
            <option value='zh/control-structures.else.php'>Chinese (Simplified)</option>
            <option value='fr/control-structures.else.php'>French</option>
            <option value='de/control-structures.else.php'>German</option>
            <option value='ja/control-structures.else.php'>Japanese</option>
            <option value='ro/control-structures.else.php'>Romanian</option>
            <option value='ru/control-structures.else.php'>Russian</option>
            <option value='es/control-structures.else.php'>Spanish</option>
            <option value='tr/control-structures.else.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/control-structures.else.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=control-structures.else">Report a Bug</a>
    </div>
  </div><div id="control-structures.else" class="sect1">
 <h2 class="title"><em>else</em></h2>
 <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p>
 <p class="para">
  Often you&#039;d want to execute a statement if a certain condition is
  met, and a different statement if the condition is not met.  This
  is what <em>else</em> is for.  <em>else</em>
  extends an <em>if</em> statement to execute a statement
  in case the expression in the <em>if</em> statement
  evaluates to <strong><code>FALSE</code></strong>.  For example, the following
  code would display <span class="computeroutput">a is greater than
  b</span> if <var class="varname"><var class="varname">$a</var></var> is greater than
  <var class="varname"><var class="varname">$b</var></var>, and <span class="computeroutput">a is NOT greater
  than b</span> otherwise:
  <div class="informalexample">
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">if&nbsp;(</span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">&gt;&nbsp;</span><span style="color: #0000BB">$b</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"a&nbsp;is&nbsp;greater&nbsp;than&nbsp;b"</span><span style="color: #007700">;<br />}&nbsp;else&nbsp;{<br />&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"a&nbsp;is&nbsp;NOT&nbsp;greater&nbsp;than&nbsp;b"</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>

  The <em>else</em> statement is only executed if the
  <em>if</em> expression evaluated to
  <strong><code>FALSE</code></strong>, and if there were any
  <em>elseif</em> expressions - only if they evaluated to
  <strong><code>FALSE</code></strong> as well (see <a href="control-structures.elseif.php" class="link">elseif</a>).

 </p>
</div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=control-structures.else&amp;redirect=http://php.net/manual/en/control-structures.else.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">7 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="47252">  <div class="votes">
    <div id="Vu47252">
    <a href="/manual/vote-note.php?id=47252&amp;page=control-structures.else&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd47252">
    <a href="/manual/vote-note.php?id=47252&amp;page=control-structures.else&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V47252" title="56% like this...">
    16
    </div>
  </div>
  <a href="#47252" class="name">
  <strong class="user"><em>Caliban Darklock</em></strong></a><a class="genanchor" href="#47252"> &para;</a><div class="date" title="2004-11-08 11:24"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom47252">
<div class="phpcode"><code><span class="html">
If you're coming from another language that does not have the "elseif" construct (e.g. C++), it's important to recognise that "else if" is a nested language construct and "elseif" is a linear language construct; they may be compared in performance to a recursive loop as opposed to an iterative loop. <br /><br /><span class="default">&lt;?php<br />$limit</span><span class="keyword">=</span><span class="default">1000</span><span class="keyword">;<br />for(</span><span class="default">$idx</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">;</span><span class="default">$idx</span><span class="keyword">&lt;</span><span class="default">$limit</span><span class="keyword">;</span><span class="default">$idx</span><span class="keyword">++)&nbsp; <br />{ </span><span class="default">$list</span><span class="keyword">[]=</span><span class="string">"if(false) echo \"</span><span class="default">$idx</span><span class="string">;\n\"; else"</span><span class="keyword">; }<br /></span><span class="default">$list</span><span class="keyword">[]=</span><span class="string">" echo \"</span><span class="default">$idx</span><span class="string">\n\";"</span><span class="keyword">;<br /></span><span class="default">$space</span><span class="keyword">=</span><span class="default">implode</span><span class="keyword">(</span><span class="string">" "</span><span class="keyword">,</span><span class="default">$list</span><span class="keyword">);| </span><span class="comment">// if ... else if ... else<br /></span><span class="default">$nospace</span><span class="keyword">=</span><span class="default">implode</span><span class="keyword">(</span><span class="string">""</span><span class="keyword">,</span><span class="default">$list</span><span class="keyword">); </span><span class="comment">// if ... elseif ... else<br /></span><span class="default">$start</span><span class="keyword">=</span><span class="default">array_sum</span><span class="keyword">(</span><span class="default">explode</span><span class="keyword">(</span><span class="string">" "</span><span class="keyword">,</span><span class="default">microtime</span><span class="keyword">()));<br />eval(</span><span class="default">$space</span><span class="keyword">);<br /></span><span class="default">$end</span><span class="keyword">=</span><span class="default">array_sum</span><span class="keyword">(</span><span class="default">explode</span><span class="keyword">(</span><span class="string">" "</span><span class="keyword">,</span><span class="default">microtime</span><span class="keyword">()));<br />echo </span><span class="default">$end</span><span class="keyword">-</span><span class="default">$start </span><span class="keyword">. </span><span class="string">" seconds\n"</span><span class="keyword">;<br /></span><span class="default">$start</span><span class="keyword">=</span><span class="default">array_sum</span><span class="keyword">(</span><span class="default">explode</span><span class="keyword">(</span><span class="string">" "</span><span class="keyword">,</span><span class="default">microtime</span><span class="keyword">()));<br />eval(</span><span class="default">$nospace</span><span class="keyword">);<br /></span><span class="default">$end</span><span class="keyword">=</span><span class="default">array_sum</span><span class="keyword">(</span><span class="default">explode</span><span class="keyword">(</span><span class="string">" "</span><span class="keyword">,</span><span class="default">microtime</span><span class="keyword">()));<br />echo </span><span class="default">$end</span><span class="keyword">-</span><span class="default">$start </span><span class="keyword">. </span><span class="string">" seconds\n"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />This test should show that "elseif" executes in roughly two-thirds the time of "else if". (Increasing $limit will also eventually cause a parser stack overflow error, but the level where this happens is ridiculous in real world terms. Nobody normally nests if() blocks to more than a thousand levels unless they're trying to break things, which is a whole different problem.)<br /><br />There is still a need for "else if", as you may have additional code to be executed unconditionally at some rung of the ladder; an "else if" construction allows this unconditional code to be elegantly inserted before or after the entire rest of the process. Consider the following elseif() ladder:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">if(</span><span class="default">$a</span><span class="keyword">) { </span><span class="default">conditional1</span><span class="keyword">(); }<br />elseif(</span><span class="default">$b</span><span class="keyword">) { </span><span class="default">conditional2</span><span class="keyword">(); }<br />elseif(</span><span class="default">$c</span><span class="keyword">) { </span><span class="default">conditional3</span><span class="keyword">(); }<br />elseif(</span><span class="default">$d</span><span class="keyword">) { </span><span class="default">conditional4</span><span class="keyword">(); }<br />elseif(</span><span class="default">$e</span><span class="keyword">) { </span><span class="default">conditional5</span><span class="keyword">(); }<br />elseif(</span><span class="default">$f</span><span class="keyword">) { </span><span class="default">conditional6</span><span class="keyword">(); }<br />elseif(</span><span class="default">$g</span><span class="keyword">) { </span><span class="default">conditional7</span><span class="keyword">(); }<br />elseif(</span><span class="default">$h</span><span class="keyword">) { </span><span class="default">conditional8</span><span class="keyword">(); }<br />else { </span><span class="default">conditional9</span><span class="keyword">(); }<br /></span><span class="default">?&gt;<br /></span><br />To insert unconditional preprocessing code for $e onward, one need only split the "elseif":<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">if(</span><span class="default">$a</span><span class="keyword">) { </span><span class="default">conditional1</span><span class="keyword">(); }<br />elseif(</span><span class="default">$b</span><span class="keyword">) { </span><span class="default">conditional2</span><span class="keyword">(); }<br />elseif(</span><span class="default">$c</span><span class="keyword">) { </span><span class="default">conditional3</span><span class="keyword">(); }<br />elseif(</span><span class="default">$d</span><span class="keyword">) { </span><span class="default">conditional4</span><span class="keyword">(); }<br />else {<br />....</span><span class="default">unconditional</span><span class="keyword">();<br />....if(</span><span class="default">$e</span><span class="keyword">) { </span><span class="default">conditional5</span><span class="keyword">(); }<br />....elseif(</span><span class="default">$f</span><span class="keyword">) { </span><span class="default">conditional6</span><span class="keyword">(); }<br />....elseif(</span><span class="default">$g</span><span class="keyword">) { </span><span class="default">conditional7</span><span class="keyword">(); }<br />....elseif(</span><span class="default">$h</span><span class="keyword">) { </span><span class="default">conditional8</span><span class="keyword">(); }<br />....else { </span><span class="default">conditional9</span><span class="keyword">(); }<br />}<br /></span><span class="default">?&gt;<br /></span><br />The alternative is to duplicate the unconditional code throughout the construct.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="82472">  <div class="votes">
    <div id="Vu82472">
    <a href="/manual/vote-note.php?id=82472&amp;page=control-structures.else&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd82472">
    <a href="/manual/vote-note.php?id=82472&amp;page=control-structures.else&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V82472" title="54% like this...">
    4
    </div>
  </div>
  <a href="#82472" class="name">
  <strong class="user"><em>dormeydo at gmail dot com</em></strong></a><a class="genanchor" href="#82472"> &para;</a><div class="date" title="2008-04-12 04:51"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom82472">
<div class="phpcode"><code><span class="html">
An alternative and very useful syntax is the following one:<br /><br />statement ? execute if true : execute if false<br /><br />Ths is very usefull for dynamic outout inside strings, for example:<br /><br />print('$a is ' . ($a &gt; $b ? 'bigger than' : ($a == $b ? 'equal to' : 'smaler than' )) .&nbsp; '&nbsp; $b');<br /><br />This will print "$a is smaler than $b" is $b is bigger than $a, "$a is bigger than $b" if $a si bigger and "$a is equal to $b" if they are same.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="76636">  <div class="votes">
    <div id="Vu76636">
    <a href="/manual/vote-note.php?id=76636&amp;page=control-structures.else&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd76636">
    <a href="/manual/vote-note.php?id=76636&amp;page=control-structures.else&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V76636" title="48% like this...">
    -1
    </div>
  </div>
  <a href="#76636" class="name">
  <strong class="user"><em>mitch at mitchellbeaumont dot com</em></strong></a><a class="genanchor" href="#76636"> &para;</a><div class="date" title="2007-07-24 12:09"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom76636">
<div class="phpcode"><code><span class="html">
At gwmpro at yahoo dot com<br /><br />The curly brace is not required however, for readability and maintenance, many developers would consider it bad style not to include them.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="104753">  <div class="votes">
    <div id="Vu104753">
    <a href="/manual/vote-note.php?id=104753&amp;page=control-structures.else&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd104753">
    <a href="/manual/vote-note.php?id=104753&amp;page=control-structures.else&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V104753" title="47% like this...">
    -3
    </div>
  </div>
  <a href="#104753" class="name">
  <strong class="user"><em>php at keith tyler dot com</em></strong></a><a class="genanchor" href="#104753"> &para;</a><div class="date" title="2011-07-05 10:52"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom104753">
<div class="phpcode"><code><span class="html">
This is valid syntax:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">if (</span><span class="default">$a</span><span class="keyword">) print </span><span class="string">"a is true"</span><span class="keyword">;<br />else print </span><span class="string">"a is false"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />A holdover from the bash-style compatibility in older PHP versions, perhaps.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="92972">  <div class="votes">
    <div id="Vu92972">
    <a href="/manual/vote-note.php?id=92972&amp;page=control-structures.else&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd92972">
    <a href="/manual/vote-note.php?id=92972&amp;page=control-structures.else&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V92972" title="44% like this...">
    -6
    </div>
  </div>
  <a href="#92972" class="name">
  <strong class="user"><em>Larry H-C</em></strong></a><a class="genanchor" href="#92972"> &para;</a><div class="date" title="2009-08-17 10:08"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom92972">
<div class="phpcode"><code><span class="html">
When you escape out of HTML, you can get an UNEXPECTED T_ELSE error with the following:<br /><br />Error:<br /><br />&lt;? if( $condition ) { <br />&nbsp; &nbsp; &nbsp; &nbsp; dosomething; <br />&nbsp;&nbsp; } <br />?&gt;<br /><br />&lt;? else { <br />&nbsp; &nbsp; &nbsp;&nbsp; dosomethingelse; <br />&nbsp;&nbsp; } <br />?&gt;<br /><br />Correct:<br /><br />&lt;? if( $condition ) { <br />&nbsp; &nbsp; &nbsp;&nbsp; dosomething; <br />?&gt;<br /><br />&lt;? } else { <br />&nbsp; &nbsp; &nbsp;&nbsp; dosomethingelse; <br />&nbsp;&nbsp; } <br />?&gt;<br /><br />Apparently the compiler thinks a ?&gt; &lt;? breaks the connection between the } and the else</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119787">  <div class="votes">
    <div id="Vu119787">
    <a href="/manual/vote-note.php?id=119787&amp;page=control-structures.else&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119787">
    <a href="/manual/vote-note.php?id=119787&amp;page=control-structures.else&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119787" title="33% like this...">
    -2
    </div>
  </div>
  <a href="#119787" class="name">
  <strong class="user"><em>zithronospam at remove dot gmail dot com at </em></strong></a><a class="genanchor" href="#119787"> &para;</a><div class="date" title="2016-08-25 05:31"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119787">
<div class="phpcode"><code><span class="html">
Alternate syntax is great (dont remove it!), but take care using "else:" after one liners, this wont work:<br /><span class="default">&lt;?php<br /></span><span class="keyword">if (</span><span class="default">true</span><span class="keyword">):<br />&nbsp; &nbsp; if (</span><span class="default">true</span><span class="keyword">) print(</span><span class="string">'This results in a parse error (unexpected ":" on line &lt;the_else_line&gt;)'</span><span class="keyword">);<br />else:<br />&nbsp; &nbsp; if (</span><span class="default">true</span><span class="keyword">) { print(</span><span class="string">'Replacing above line with this one also triggers a parse error, curly braces do not help in this case'</span><span class="keyword">) }<br />endif; </span><span class="default">?&gt;<br /></span><br />Either use the alternate syntax on the line in error: <span class="default">&lt;?php </span><span class="keyword">if(</span><span class="default">true</span><span class="keyword">):print(</span><span class="string">'This works as its ended by an'</span><span class="keyword">);endif; </span><span class="default">?&gt;<br /></span>Or write some more code on a newline between the one-liner and the following else (eg. "$var=1;" is enough, even a single semi-colon is, but read below).<br /><br />A third way is to add a semi-colon to the one-liner, having two if necessary:<br /><span class="default">&lt;?php<br /></span><span class="keyword">if (</span><span class="default">true</span><span class="keyword">):<br />&nbsp; &nbsp; if (</span><span class="default">true</span><span class="keyword">) print(</span><span class="string">'This is valid again'</span><span class="keyword">);;<br />else:<br />&nbsp; &nbsp; </span><span class="comment">// ...<br /></span><span class="keyword">endif;<br /><br /></span><span class="comment">// It works with the curly braces form too:<br /></span><span class="keyword">if (</span><span class="default">true</span><span class="keyword">):<br />&nbsp; &nbsp; if (</span><span class="default">true</span><span class="keyword">) { print(</span><span class="string">'This get displayed, even if the doc says the opposite about mixing syntaxes'</span><span class="keyword">) };<br />else:<br />&nbsp; &nbsp; </span><span class="comment">// ...<br /></span><span class="keyword">endif;<br /></span><span class="default">?&gt;<br /></span>I can only guess that the added semi-colon makes it work by "closing the if" in a way.<br />Subsequent semi-colons don't matter, and the semi-colon can be anywhere: at the end of the line, on the following line on its own, or just before the else like ";else". But who would do that anyway.<br /><br />TL;DR/conclusion:<br />- avoid mixing alternate syntax and one liners in if/else control structures<br />- avoid mixing syntaxes inside the blocks (even if it works using this semi-colon trick).<br /><br />================================<br />Note to editors: the behaviour described is specifically linked to the use of an else, but this note could also be added to the more general "Alternative syntax for control structures" page as it's also commenting on mixing syntaxes. You know better!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="82771">  <div class="votes">
    <div id="Vu82771">
    <a href="/manual/vote-note.php?id=82771&amp;page=control-structures.else&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd82771">
    <a href="/manual/vote-note.php?id=82771&amp;page=control-structures.else&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V82771" title="20% like this...">
    -24
    </div>
  </div>
  <a href="#82771" class="name">
  <strong class="user"><em>Theoden</em></strong></a><a class="genanchor" href="#82771"> &para;</a><div class="date" title="2008-04-24 05:42"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom82771">
<div class="phpcode"><code><span class="html">
At Caliban Darklock<br /><br />I don't know if it is just improvements in the parser, but there is a negligible difference in the performance of "elseif" vs "else if" as of version 5. One thousandth of a second in your example and 8 thousandths if the eval statement is repeated 5 times. <br />If the constructs are in regular code, then there appears to be no difference. This leads me to believe that the difference in the eval code is from there being an extra parser token. <br /><br />Also the main performance burden of recursive functions is the stack operations of changing the context. In this case I believe that it would parse to very similar (if not identical) jmp controls.<br /><br />In summary, use your preference. Readability and maintainability rank far higher on the priority scale.<br /><br />One Additional note, there appears to be a limit of the number of "else if" statements (perhaps nested statements in general) that php will handle before starting to get screwy. This limit is about 1100. "elseif" is not affected by this.</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=control-structures.else&amp;redirect=http://php.net/manual/en/control-structures.else.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.control-structures.php">Control Structures</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="control-structures.intro.php" title="Introduction">Introduction</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.if.php" title="if">if</a>
                        </li>
                          
                        <li class="current">
                            <a href="control-structures.else.php" title="else">else</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.elseif.php" title="elseif/else if">elseif/else if</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.alternative-syntax.php" title="Alternative syntax for control structures">Alternative syntax for control structures</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.while.php" title="while">while</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.do.while.php" title="do-&#8203;while">do-&#8203;while</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.for.php" title="for">for</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.foreach.php" title="foreach">foreach</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.break.php" title="break">break</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.continue.php" title="continue">continue</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.switch.php" title="switch">switch</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.declare.php" title="declare">declare</a>
                        </li>
                          
                        <li class="">
                            <a href="function.return.php" title="return">return</a>
                        </li>
                          
                        <li class="">
                            <a href="function.require.php" title="require">require</a>
                        </li>
                          
                        <li class="">
                            <a href="function.include.php" title="include">include</a>
                        </li>
                          
                        <li class="">
                            <a href="function.require-once.php" title="require_&#8203;once">require_&#8203;once</a>
                        </li>
                          
                        <li class="">
                            <a href="function.include-once.php" title="include_&#8203;once">include_&#8203;once</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.goto.php" title="goto">goto</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

