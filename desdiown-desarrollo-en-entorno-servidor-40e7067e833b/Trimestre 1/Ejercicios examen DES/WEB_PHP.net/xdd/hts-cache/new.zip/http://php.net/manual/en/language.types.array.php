<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Arrays - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.types.array.php">
 <link rel="shorturl" href="http://php.net/types.array">
 <link rel="alternate" href="http://php.net/types.array" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.types.php">
 <link rel="prev" href="http://php.net/manual/en/language.types.string.php">
 <link rel="next" href="http://php.net/manual/en/language.types.iterable.php">

 <link rel="alternate" href="http://php.net/manual/en/language.types.array.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.types.array.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.types.array.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.types.array.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.types.array.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.types.array.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.types.array.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.types.array.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.types.array.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.types.array.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.types.array.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.types.iterable.php">
          Iterables &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.types.string.php">
          &laquo; Strings        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.types.php'>Types</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.types.array.php' selected="selected">English</option>
            <option value='pt_BR/language.types.array.php'>Brazilian Portuguese</option>
            <option value='zh/language.types.array.php'>Chinese (Simplified)</option>
            <option value='fr/language.types.array.php'>French</option>
            <option value='de/language.types.array.php'>German</option>
            <option value='ja/language.types.array.php'>Japanese</option>
            <option value='ro/language.types.array.php'>Romanian</option>
            <option value='ru/language.types.array.php'>Russian</option>
            <option value='es/language.types.array.php'>Spanish</option>
            <option value='tr/language.types.array.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.types.array.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.types.array">Report a Bug</a>
    </div>
  </div><div id="language.types.array" class="sect1">
 <h2 class="title">Arrays</h2>

 <p class="para">
  An <span class="type"><a href="language.types.array.php" class="type array">array</a></span> in PHP is actually an ordered map. A map is a type that
  associates <em class="emphasis">values</em> to <em class="emphasis">keys</em>. This type
  is optimized for several different uses; it can be treated as an array,
  list (vector), hash table (an implementation of a map), dictionary,
  collection, stack, queue, and probably more. As <span class="type"><a href="language.types.array.php" class="type array">array</a></span> values can
  be other <span class="type"><a href="language.types.array.php" class="type array">array</a></span>s, trees and multidimensional <span class="type"><a href="language.types.array.php" class="type array">array</a></span>s
  are also possible.
 </p>

 <p class="para">
  Explanation of those data structures is beyond the scope of this manual, but
  at least one example is provided for each of them. For more information, look
  towards the considerable literature that exists about this broad topic.
 </p>
   
 <div class="sect2" id="language.types.array.syntax">
  <h3 class="title">Syntax</h3>
  
  <div class="sect3" id="language.types.array.syntax.array-func">
   <h4 class="title">Specifying with <span class="function"><a href="function.array.php" class="function">array()</a></span></h4>

   <p class="para">
    An <span class="type"><a href="language.types.array.php" class="type array">array</a></span> can be created using the <span class="function"><a href="function.array.php" class="function">array()</a></span>
    language construct. It takes any number of comma-separated
    <em><span class="replaceable">key</span> =&gt; <span class="replaceable">value</span></em> pairs
    as arguments.
   </p>

   <pre class="synopsis">
array(
    <span class="optional"><span class="replaceable">key</span>  =&gt; </span><span class="replaceable">value</span>,
    <span class="optional"><span class="replaceable">key2</span> =&gt; </span><span class="replaceable">value2</span>,
    <span class="optional"><span class="replaceable">key3</span> =&gt; </span><span class="replaceable">value3</span>,
    ...
)</pre>
   

   <p class="para">
    The comma after the last array element is optional and can be omitted. This is usually done
    for single-line arrays, i.e. <em>array(1, 2)</em> is preferred over
    <em>array(1, 2, )</em>. For multi-line arrays on the other hand the trailing comma
    is commonly used, as it allows easier addition of new elements at the end.
   </p>
   
   <p class="para">
    As of PHP 5.4 you can also use the short array syntax, which replaces
    <em>array()</em> with <em>[]</em>.
   </p>
   
   <div class="example" id="example-56">
    <p><strong>Example #1 A simple array</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$array&nbsp;</span><span style="color: #007700">=&nbsp;array(<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"foo"&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">"bar"</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"bar"&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">"foo"</span><span style="color: #007700">,<br />);<br /><br /></span><span style="color: #FF8000">//&nbsp;as&nbsp;of&nbsp;PHP&nbsp;5.4<br /></span><span style="color: #0000BB">$array&nbsp;</span><span style="color: #007700">=&nbsp;[<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"foo"&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">"bar"</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"bar"&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">"foo"</span><span style="color: #007700">,<br />];<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
   
   <p class="para">
    The <span class="replaceable">key</span> can either be an <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span>
    or a <span class="type"><a href="language.types.string.php" class="type string">string</a></span>. The <span class="replaceable">value</span> can be
    of any type.
   </p>
   
   <p class="para">
    Additionally the following <span class="replaceable">key</span> casts will occur:
    <ul class="itemizedlist">
     <li class="listitem">
      <span class="simpara">
       <span class="type"><a href="language.types.string.php" class="type String">String</a></span>s containing valid decimal <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span>s, unless the number is preceded by a <em>+</em> sign, will be cast to the
       <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span> type. E.g. the key <em>&quot;8&quot;</em> will actually be
       stored under <em>8</em>. On the other hand <em>&quot;08&quot;</em> will
       not be cast, as it isn&#039;t a valid decimal integer.
      </span>
     </li>
     <li class="listitem">
      <span class="simpara">
       <span class="type"><a href="language.types.float.php" class="type Float">Float</a></span>s are also cast to <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span>s, which means that the
       fractional part will be truncated. E.g. the key <em>8.7</em> will actually
       be stored under <em>8</em>.
      </span>
     </li>
     <li class="listitem">
      <span class="simpara">
       <span class="type"><a href="language.types.boolean.php" class="type Bool">Bool</a></span>s are cast to <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span>s, too, i.e. the key
       <em>true</em> will actually be stored under <em>1</em>
       and the key <em>false</em> under <em>0</em>.
      </span>
     </li>
     <li class="listitem">
      <span class="simpara">
       <span class="type"><a href="language.types.null.php" class="type Null">Null</a></span> will be cast to the empty string, i.e. the key
       <em>null</em> will actually be stored under <em>&quot;&quot;</em>.
      </span>
     </li>
     <li class="listitem">
      <span class="simpara">
       <span class="type"><a href="language.types.array.php" class="type Array">Array</a></span>s and <span class="type"><a href="language.types.object.php" class="type object">object</a></span>s <em class="emphasis">can not</em> be used as keys.
       Doing so will result in a warning: <em>Illegal offset type</em>.
      </span>
     </li>
    </ul>
   </p>
   
   <p class="para">
    If multiple elements in the array declaration use the same key, only the last one
    will be used as all others are overwritten.
   </p>
   
   <div class="example" id="example-57">
    <p><strong>Example #2 Type Casting and Overwriting example</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$array&nbsp;</span><span style="color: #007700">=&nbsp;array(<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">1&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">"a"</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"1"&nbsp;&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">"b"</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">1.5&nbsp;&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">"c"</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">true&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">"d"</span><span style="color: #007700">,<br />);<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$array</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

    <div class="example-contents"><p>The above example will output:</p></div>
    <div class="example-contents screen">
<div class="cdata"><pre>
array(1) {
  [1]=&gt;
  string(1) &quot;d&quot;
}
</pre></div>
    </div>
    <div class="example-contents"><p>
     As all the keys in the above example are cast to <em>1</em>, the value will be overwritten
     on every new element and the last assigned value <em>&quot;d&quot;</em> is the only one left over.
    </p></div>
   </div>  
   
   <p class="para">
    PHP arrays can contain <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span> and <span class="type"><a href="language.types.string.php" class="type string">string</a></span> keys at the same time
    as PHP does not distinguish between indexed and associative arrays.
   </p>
   
   <div class="example" id="example-58">
    <p><strong>Example #3 Mixed <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span> and <span class="type"><a href="language.types.string.php" class="type string">string</a></span> keys</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$array&nbsp;</span><span style="color: #007700">=&nbsp;array(<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"foo"&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">"bar"</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"bar"&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">"foo"</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">100&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">=&gt;&nbsp;-</span><span style="color: #0000BB">100</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;-</span><span style="color: #0000BB">100&nbsp;&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #0000BB">100</span><span style="color: #007700">,<br />);<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$array</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

    <div class="example-contents"><p>The above example will output:</p></div>
    <div class="example-contents screen">
<div class="cdata"><pre>
array(4) {
  [&quot;foo&quot;]=&gt;
  string(3) &quot;bar&quot;
  [&quot;bar&quot;]=&gt;
  string(3) &quot;foo&quot;
  [100]=&gt;
  int(-100)
  [-100]=&gt;
  int(100)
}
</pre></div>
    </div>
   </div>
   
   <p class="para">
    The <span class="replaceable">key</span> is optional. If it is not specified, PHP will
    use the increment of the largest previously used <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span> key.
   </p>
   
   <div class="example" id="example-59">
    <p><strong>Example #4 Indexed arrays without key</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$array&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">"foo"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"bar"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"hello"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"world"</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$array</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

    <div class="example-contents"><p>The above example will output:</p></div>
    <div class="example-contents screen">
<div class="cdata"><pre>
array(4) {
  [0]=&gt;
  string(3) &quot;foo&quot;
  [1]=&gt;
  string(3) &quot;bar&quot;
  [2]=&gt;
  string(5) &quot;hello&quot;
  [3]=&gt;
  string(5) &quot;world&quot;
}
</pre></div>
    </div>
   </div>
   
   <p class="para">
    It is possible to specify the key only for some elements and leave it out for others:
   </p>
   
   <div class="example" id="example-60">
    <p><strong>Example #5 Keys not on all elements</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$array&nbsp;</span><span style="color: #007700">=&nbsp;array(<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"a"</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"b"</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">6&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">"c"</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"d"</span><span style="color: #007700">,<br />);<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$array</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

    <div class="example-contents"><p>The above example will output:</p></div>
    <div class="example-contents screen">
<div class="cdata"><pre>
array(4) {
  [0]=&gt;
  string(1) &quot;a&quot;
  [1]=&gt;
  string(1) &quot;b&quot;
  [6]=&gt;
  string(1) &quot;c&quot;
  [7]=&gt;
  string(1) &quot;d&quot;
}
</pre></div>
    </div>
    <div class="example-contents"><p>
     As you can see the last value <em>&quot;d&quot;</em> was assigned the key
     <em>7</em>. This is because the largest integer key before that
     was <em>6</em>.
    </p></div>
   </div>
  </div>
  
  <div class="sect3" id="language.types.array.syntax.accessing">
   <h4 class="title">Accessing array elements with square bracket syntax</h4>
   
   <p class="para">
    Array elements can be accessed using the <em>array[key]</em> syntax.
   </p>
   
   <div class="example" id="example-61">
    <p><strong>Example #6 Accessing array elements</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$array&nbsp;</span><span style="color: #007700">=&nbsp;array(<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"foo"&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">"bar"</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">42&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #0000BB">24</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"multi"&nbsp;</span><span style="color: #007700">=&gt;&nbsp;array(<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"dimensional"&nbsp;</span><span style="color: #007700">=&gt;&nbsp;array(<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"array"&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">"foo"<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">)<br />&nbsp;&nbsp;&nbsp;&nbsp;)<br />);<br /><br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$array</span><span style="color: #007700">[</span><span style="color: #DD0000">"foo"</span><span style="color: #007700">]);<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$array</span><span style="color: #007700">[</span><span style="color: #0000BB">42</span><span style="color: #007700">]);<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$array</span><span style="color: #007700">[</span><span style="color: #DD0000">"multi"</span><span style="color: #007700">][</span><span style="color: #DD0000">"dimensional"</span><span style="color: #007700">][</span><span style="color: #DD0000">"array"</span><span style="color: #007700">]);<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

    <div class="example-contents"><p>The above example will output:</p></div>
    <div class="example-contents screen">
<div class="cdata"><pre>
string(3) &quot;bar&quot;
int(24)
string(3) &quot;foo&quot;
</pre></div>
    </div>
   </div>
   
   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <p class="para">
     Both square brackets and curly braces can be used interchangeably
     for accessing array elements (e.g. <em>$array[42]</em> and <em>$array{42}</em> will
     both do the same thing in the example above).
    </p>
   </p></blockquote>

   <p class="para">
    As of PHP 5.4 it is possible to array dereference the result of a function
    or method call directly. Before it was only possible using a temporary
    variable.
   </p>
   
   <p class="para">
    As of PHP 5.5 it is possible to array dereference an array literal.
   </p>
   
   <div class="example" id="example-62">
    <p><strong>Example #7 Array dereferencing</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">getArray</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;array(</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">3</span><span style="color: #007700">);<br />}<br /><br /></span><span style="color: #FF8000">//&nbsp;on&nbsp;PHP&nbsp;5.4<br /></span><span style="color: #0000BB">$secondElement&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">getArray</span><span style="color: #007700">()[</span><span style="color: #0000BB">1</span><span style="color: #007700">];<br /><br /></span><span style="color: #FF8000">//&nbsp;previously<br /></span><span style="color: #0000BB">$tmp&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">getArray</span><span style="color: #007700">();<br /></span><span style="color: #0000BB">$secondElement&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$tmp</span><span style="color: #007700">[</span><span style="color: #0000BB">1</span><span style="color: #007700">];<br /><br /></span><span style="color: #FF8000">//&nbsp;or<br /></span><span style="color: #007700">list(,&nbsp;</span><span style="color: #0000BB">$secondElement</span><span style="color: #007700">)&nbsp;=&nbsp;</span><span style="color: #0000BB">getArray</span><span style="color: #007700">();<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
   
   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <p class="para">
      Attempting to access an array key which has not been defined is
      the same as accessing any other undefined variable:
      an <strong><code>E_NOTICE</code></strong>-level error message will be
      issued, and the result will be <strong><code>NULL</code></strong>.
    </p>
   </p></blockquote>
   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <p class="para">
     Array dereferencing a scalar value which is not a <span class="type"><a href="language.types.string.php" class="type string">string</a></span>
     silently yields <strong><code>NULL</code></strong>, i.e. without issuing an error message.
    </p>
   </p></blockquote>
  </div>
  
  <div class="sect3" id="language.types.array.syntax.modifying">
   <h4 class="title">Creating/modifying with square bracket syntax</h4>

   <p class="para">
    An existing <span class="type"><a href="language.types.array.php" class="type array">array</a></span> can be modified by explicitly setting values
    in it.
   </p>

   <p class="para">
    This is done by assigning values to the <span class="type"><a href="language.types.array.php" class="type array">array</a></span>, specifying the
    key in brackets. The key can also be omitted, resulting in an empty pair of
    brackets (<em>[]</em>).
   </p>
   
   <pre class="synopsis">
$arr[<span class="replaceable">key</span>] = <span class="replaceable">value</span>;
$arr[] = <span class="replaceable">value</span>;
// <span class="replaceable">key</span> may be an <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span> or <span class="type"><a href="language.types.string.php" class="type string">string</a></span>
// <span class="replaceable">value</span> may be any value of any type</pre>
   
   <p class="para">
    If <var class="varname"><var class="varname">$arr</var></var> doesn&#039;t exist yet, it will be created, so this is
    also an alternative way to create an <span class="type"><a href="language.types.array.php" class="type array">array</a></span>. This practice is
    however discouraged because if <var class="varname"><var class="varname">$arr</var></var> already contains
    some value (e.g. <span class="type"><a href="language.types.string.php" class="type string">string</a></span> from request variable) then this
    value will stay in the place and <em>[]</em> may actually stand
    for <a href="language.types.string.php#language.types.string.substr" class="link">string access
    operator</a>. It is always better to initialize a variable by a direct
    assignment.
   </p>
   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <span class="simpara">
     As of PHP 7.1.0, applying the empty index operator on a string throws a fatal
     error. Formerly, the string was silently converted to an array.
    </span>
   </p></blockquote>

   <p class="para">
    To change a certain
    value, assign a new value to that element using its key. To remove a
    key/value pair, call the <span class="function"><a href="function.unset.php" class="function">unset()</a></span> function on it.
   </p>

   <div class="informalexample">
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$arr&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #0000BB">5&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">12&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">);<br /><br /></span><span style="color: #0000BB">$arr</span><span style="color: #007700">[]&nbsp;=&nbsp;</span><span style="color: #0000BB">56</span><span style="color: #007700">;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;This&nbsp;is&nbsp;the&nbsp;same&nbsp;as&nbsp;$arr[13]&nbsp;=&nbsp;56;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;at&nbsp;this&nbsp;point&nbsp;of&nbsp;the&nbsp;script<br /><br /></span><span style="color: #0000BB">$arr</span><span style="color: #007700">[</span><span style="color: #DD0000">"x"</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #0000BB">42</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;This&nbsp;adds&nbsp;a&nbsp;new&nbsp;element&nbsp;to<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;the&nbsp;array&nbsp;with&nbsp;key&nbsp;"x"<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br /></span><span style="color: #007700">unset(</span><span style="color: #0000BB">$arr</span><span style="color: #007700">[</span><span style="color: #0000BB">5</span><span style="color: #007700">]);&nbsp;</span><span style="color: #FF8000">//&nbsp;This&nbsp;removes&nbsp;the&nbsp;element&nbsp;from&nbsp;the&nbsp;array<br /><br /></span><span style="color: #007700">unset(</span><span style="color: #0000BB">$arr</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;This&nbsp;deletes&nbsp;the&nbsp;whole&nbsp;array<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div> 
    </div>

   </div>

   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <p class="para">
     As mentioned above, if no key is specified, the maximum of the existing
     <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span> indices is taken, and the new key will be that maximum
     value plus 1 (but at least 0). If no <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span> indices exist yet, the key will
     be <em>0</em> (zero). 
    </p>

    <p class="para">
     Note that the maximum integer key used for this <em class="emphasis">need not
     currently exist in the <span class="type"><a href="language.types.array.php" class="type array">array</a></span></em>. It need only have
     existed in the <span class="type"><a href="language.types.array.php" class="type array">array</a></span> at some time since the last time the
     <span class="type"><a href="language.types.array.php" class="type array">array</a></span> was re-indexed. The following example illustrates:
    </p>

    <div class="informalexample">
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #FF8000">//&nbsp;Create&nbsp;a&nbsp;simple&nbsp;array.<br /></span><span style="color: #0000BB">$array&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">3</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">4</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">5</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">print_r</span><span style="color: #007700">(</span><span style="color: #0000BB">$array</span><span style="color: #007700">);<br /><br /></span><span style="color: #FF8000">//&nbsp;Now&nbsp;delete&nbsp;every&nbsp;item,&nbsp;but&nbsp;leave&nbsp;the&nbsp;array&nbsp;itself&nbsp;intact:<br /></span><span style="color: #007700">foreach&nbsp;(</span><span style="color: #0000BB">$array&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">$i&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #0000BB">$value</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;unset(</span><span style="color: #0000BB">$array</span><span style="color: #007700">[</span><span style="color: #0000BB">$i</span><span style="color: #007700">]);<br />}<br /></span><span style="color: #0000BB">print_r</span><span style="color: #007700">(</span><span style="color: #0000BB">$array</span><span style="color: #007700">);<br /><br /></span><span style="color: #FF8000">//&nbsp;Append&nbsp;an&nbsp;item&nbsp;(note&nbsp;that&nbsp;the&nbsp;new&nbsp;key&nbsp;is&nbsp;5,&nbsp;instead&nbsp;of&nbsp;0).<br /></span><span style="color: #0000BB">$array</span><span style="color: #007700">[]&nbsp;=&nbsp;</span><span style="color: #0000BB">6</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">print_r</span><span style="color: #007700">(</span><span style="color: #0000BB">$array</span><span style="color: #007700">);<br /><br /></span><span style="color: #FF8000">//&nbsp;Re-index:<br /></span><span style="color: #0000BB">$array&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">array_values</span><span style="color: #007700">(</span><span style="color: #0000BB">$array</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">$array</span><span style="color: #007700">[]&nbsp;=&nbsp;</span><span style="color: #0000BB">7</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">print_r</span><span style="color: #007700">(</span><span style="color: #0000BB">$array</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div> 
     </div>

     <p class="para">The above example will output:</p>
     <div class="example-contents screen">
<div class="cdata"><pre>
Array
(
    [0] =&gt; 1
    [1] =&gt; 2
    [2] =&gt; 3
    [3] =&gt; 4
    [4] =&gt; 5
)
Array
(
)
Array
(
    [5] =&gt; 6
)
Array
(
    [0] =&gt; 6
    [1] =&gt; 7
)
</pre></div>
     </div>
    </div>       

   </p></blockquote>

  </div>
 </div>
 
 <div class="sect2" id="language.types.array.useful-funcs">
  <h3 class="title">Useful functions</h3>

  <p class="para">
   There are quite a few useful functions for working with arrays. See the
   <a href="ref.array.php" class="link">array functions</a> section.
  </p>

  <blockquote class="note"><p><strong class="note">Note</strong>: 
   <p class="para">
    The <span class="function"><a href="function.unset.php" class="function">unset()</a></span> function allows removing keys from an
    <span class="type"><a href="language.types.array.php" class="type array">array</a></span>. Be aware that the array will <em class="emphasis">not</em> be
    reindexed. If a true &quot;remove and shift&quot; behavior is desired, the
    <span class="type"><a href="language.types.array.php" class="type array">array</a></span> can be reindexed using the
    <span class="function"><a href="function.array-values.php" class="function">array_values()</a></span> function.
   </p>
   
   <div class="informalexample">
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$a&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #0000BB">1&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'one'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'two'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">3&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'three'</span><span style="color: #007700">);<br />unset(</span><span style="color: #0000BB">$a</span><span style="color: #007700">[</span><span style="color: #0000BB">2</span><span style="color: #007700">]);<br /></span><span style="color: #FF8000">/*&nbsp;will&nbsp;produce&nbsp;an&nbsp;array&nbsp;that&nbsp;would&nbsp;have&nbsp;been&nbsp;defined&nbsp;as<br />&nbsp;&nbsp;&nbsp;$a&nbsp;=&nbsp;array(1&nbsp;=&gt;&nbsp;'one',&nbsp;3&nbsp;=&gt;&nbsp;'three');<br />&nbsp;&nbsp;&nbsp;and&nbsp;NOT<br />&nbsp;&nbsp;&nbsp;$a&nbsp;=&nbsp;array(1&nbsp;=&gt;&nbsp;'one',&nbsp;2&nbsp;=&gt;'three');<br />*/<br /><br /></span><span style="color: #0000BB">$b&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">array_values</span><span style="color: #007700">(</span><span style="color: #0000BB">$a</span><span style="color: #007700">);<br /></span><span style="color: #FF8000">//&nbsp;Now&nbsp;$b&nbsp;is&nbsp;array(0&nbsp;=&gt;&nbsp;'one',&nbsp;1&nbsp;=&gt;'three')<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
  </p></blockquote> 

  <p class="para">
   The <a href="control-structures.foreach.php" class="link">foreach</a> control
   structure exists specifically for <span class="type"><a href="language.types.array.php" class="type array">array</a></span>s. It provides an easy
   way to traverse an <span class="type"><a href="language.types.array.php" class="type array">array</a></span>.
  </p>
 </div>
 
 <div class="sect2" id="language.types.array.donts">
  <h3 class="title">Array do&#039;s and don&#039;ts</h3>

  <div class="sect3" id="language.types.array.foo-bar">
   <h4 class="title">Why is <em>$foo[bar]</em> wrong?</h4>

   <p class="para">
    Always use quotes around a string literal array index. For example,
    <em>$foo[&#039;bar&#039;]</em> is correct, while
    <em>$foo[bar]</em> is not. But why? It is common to encounter this
    kind of syntax in old scripts:
   </p>

   <div class="informalexample">
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$foo</span><span style="color: #007700">[</span><span style="color: #0000BB">bar</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #DD0000">'enemy'</span><span style="color: #007700">;<br />echo&nbsp;</span><span style="color: #0000BB">$foo</span><span style="color: #007700">[</span><span style="color: #0000BB">bar</span><span style="color: #007700">];<br /></span><span style="color: #FF8000">//&nbsp;etc<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
   
   <p class="para">
    This is wrong, but it works. The reason is that this code has an undefined
    constant (<em>bar</em>) rather than a <span class="type"><a href="language.types.string.php" class="type string">string</a></span> (<em>&#039;bar&#039;</em> - notice the
    quotes). It works because PHP automatically converts a
    <em class="emphasis">bare string</em> (an unquoted <span class="type"><a href="language.types.string.php" class="type string">string</a></span> which does
    not correspond to any known symbol) into a <span class="type"><a href="language.types.string.php" class="type string">string</a></span> which
    contains the bare <span class="type"><a href="language.types.string.php" class="type string">string</a></span>. For instance, if there is no defined 
    constant named <strong><code>bar</code></strong>, then PHP will substitute in the
    <span class="type"><a href="language.types.string.php" class="type string">string</a></span> <em>&#039;bar&#039;</em> and use that.
   </p>

   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <span class="simpara">
     This does not mean to <em class="emphasis">always</em> quote the key. Do not
     quote keys which are <a href="language.constants.php" class="link">constants</a> or
     <a href="language.variables.php" class="link">variables</a>, as this will prevent
     PHP from interpreting them.
    </span>

    <div class="informalexample">
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />error_reporting</span><span style="color: #007700">(</span><span style="color: #0000BB">E_ALL</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">ini_set</span><span style="color: #007700">(</span><span style="color: #DD0000">'display_errors'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">true</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">ini_set</span><span style="color: #007700">(</span><span style="color: #DD0000">'html_errors'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">false</span><span style="color: #007700">);<br /></span><span style="color: #FF8000">//&nbsp;Simple&nbsp;array:<br /></span><span style="color: #0000BB">$array&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">$count&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">count</span><span style="color: #007700">(</span><span style="color: #0000BB">$array</span><span style="color: #007700">);<br />for&nbsp;(</span><span style="color: #0000BB">$i&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">0</span><span style="color: #007700">;&nbsp;</span><span style="color: #0000BB">$i&nbsp;</span><span style="color: #007700">&lt;&nbsp;</span><span style="color: #0000BB">$count</span><span style="color: #007700">;&nbsp;</span><span style="color: #0000BB">$i</span><span style="color: #007700">++)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"\nChecking&nbsp;</span><span style="color: #0000BB">$i</span><span style="color: #DD0000">:&nbsp;\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"Bad:&nbsp;"&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">$array</span><span style="color: #007700">[</span><span style="color: #DD0000">'$i'</span><span style="color: #007700">]&nbsp;.&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"Good:&nbsp;"&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">$array</span><span style="color: #007700">[</span><span style="color: #0000BB">$i</span><span style="color: #007700">]&nbsp;.&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"Bad:&nbsp;</span><span style="color: #007700">{</span><span style="color: #0000BB">$array</span><span style="color: #007700">[</span><span style="color: #DD0000">'$i'</span><span style="color: #007700">]}</span><span style="color: #DD0000">\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"Good:&nbsp;</span><span style="color: #007700">{</span><span style="color: #0000BB">$array</span><span style="color: #007700">[</span><span style="color: #0000BB">$i</span><span style="color: #007700">]}</span><span style="color: #DD0000">\n"</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
    <p class="para">The above example will output:</p>
    <div class="example-contents screen">
<div class="cdata"><pre>
Checking 0: 
Notice: Undefined index:  $i in /path/to/script.html on line 9
Bad: 
Good: 1
Notice: Undefined index:  $i in /path/to/script.html on line 11
Bad: 
Good: 1

Checking 1: 
Notice: Undefined index:  $i in /path/to/script.html on line 9
Bad: 
Good: 2
Notice: Undefined index:  $i in /path/to/script.html on line 11
Bad: 
Good: 2
</pre></div>        
    </div>
   </p></blockquote>

   <p class="para">
    More examples to demonstrate this behaviour:
   </p>

   <div class="informalexample">
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #FF8000">//&nbsp;Show&nbsp;all&nbsp;errors<br /></span><span style="color: #0000BB">error_reporting</span><span style="color: #007700">(</span><span style="color: #0000BB">E_ALL</span><span style="color: #007700">);<br /><br /></span><span style="color: #0000BB">$arr&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">'fruit'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'apple'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'veggie'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'carrot'</span><span style="color: #007700">);<br /><br /></span><span style="color: #FF8000">//&nbsp;Correct<br /></span><span style="color: #007700">print&nbsp;</span><span style="color: #0000BB">$arr</span><span style="color: #007700">[</span><span style="color: #DD0000">'fruit'</span><span style="color: #007700">];&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;apple<br /></span><span style="color: #007700">print&nbsp;</span><span style="color: #0000BB">$arr</span><span style="color: #007700">[</span><span style="color: #DD0000">'veggie'</span><span style="color: #007700">];&nbsp;</span><span style="color: #FF8000">//&nbsp;carrot<br /><br />//&nbsp;Incorrect.&nbsp;&nbsp;This&nbsp;works&nbsp;but&nbsp;also&nbsp;throws&nbsp;a&nbsp;PHP&nbsp;error&nbsp;of&nbsp;level&nbsp;E_NOTICE&nbsp;because<br />//&nbsp;of&nbsp;an&nbsp;undefined&nbsp;constant&nbsp;named&nbsp;fruit<br />//&nbsp;<br />//&nbsp;Notice:&nbsp;Use&nbsp;of&nbsp;undefined&nbsp;constant&nbsp;fruit&nbsp;-&nbsp;assumed&nbsp;'fruit'&nbsp;in...<br /></span><span style="color: #007700">print&nbsp;</span><span style="color: #0000BB">$arr</span><span style="color: #007700">[</span><span style="color: #0000BB">fruit</span><span style="color: #007700">];&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;apple<br /><br />//&nbsp;This&nbsp;defines&nbsp;a&nbsp;constant&nbsp;to&nbsp;demonstrate&nbsp;what's&nbsp;going&nbsp;on.&nbsp;&nbsp;The&nbsp;value&nbsp;'veggie'<br />//&nbsp;is&nbsp;assigned&nbsp;to&nbsp;a&nbsp;constant&nbsp;named&nbsp;fruit.<br /></span><span style="color: #0000BB">define</span><span style="color: #007700">(</span><span style="color: #DD0000">'fruit'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'veggie'</span><span style="color: #007700">);<br /><br /></span><span style="color: #FF8000">//&nbsp;Notice&nbsp;the&nbsp;difference&nbsp;now<br /></span><span style="color: #007700">print&nbsp;</span><span style="color: #0000BB">$arr</span><span style="color: #007700">[</span><span style="color: #DD0000">'fruit'</span><span style="color: #007700">];&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;apple<br /></span><span style="color: #007700">print&nbsp;</span><span style="color: #0000BB">$arr</span><span style="color: #007700">[</span><span style="color: #0000BB">fruit</span><span style="color: #007700">];&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;carrot<br /><br />//&nbsp;The&nbsp;following&nbsp;is&nbsp;okay,&nbsp;as&nbsp;it's&nbsp;inside&nbsp;a&nbsp;string.&nbsp;Constants&nbsp;are&nbsp;not&nbsp;looked&nbsp;for<br />//&nbsp;within&nbsp;strings,&nbsp;so&nbsp;no&nbsp;E_NOTICE&nbsp;occurs&nbsp;here<br /></span><span style="color: #007700">print&nbsp;</span><span style="color: #DD0000">"Hello&nbsp;</span><span style="color: #0000BB">$arr</span><span style="color: #007700">[</span><span style="color: #0000BB">fruit</span><span style="color: #007700">]</span><span style="color: #DD0000">"</span><span style="color: #007700">;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;Hello&nbsp;apple<br /><br />//&nbsp;With&nbsp;one&nbsp;exception:&nbsp;braces&nbsp;surrounding&nbsp;arrays&nbsp;within&nbsp;strings&nbsp;allows&nbsp;constants<br />//&nbsp;to&nbsp;be&nbsp;interpreted<br /></span><span style="color: #007700">print&nbsp;</span><span style="color: #DD0000">"Hello&nbsp;</span><span style="color: #007700">{</span><span style="color: #0000BB">$arr</span><span style="color: #007700">[</span><span style="color: #0000BB">fruit</span><span style="color: #007700">]}</span><span style="color: #DD0000">"</span><span style="color: #007700">;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;Hello&nbsp;carrot<br /></span><span style="color: #007700">print&nbsp;</span><span style="color: #DD0000">"Hello&nbsp;</span><span style="color: #007700">{</span><span style="color: #0000BB">$arr</span><span style="color: #007700">[</span><span style="color: #DD0000">'fruit'</span><span style="color: #007700">]}</span><span style="color: #DD0000">"</span><span style="color: #007700">;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;Hello&nbsp;apple<br /><br />//&nbsp;This&nbsp;will&nbsp;not&nbsp;work,&nbsp;and&nbsp;will&nbsp;result&nbsp;in&nbsp;a&nbsp;parse&nbsp;error,&nbsp;such&nbsp;as:<br />//&nbsp;Parse&nbsp;error:&nbsp;parse&nbsp;error,&nbsp;expecting&nbsp;T_STRING'&nbsp;or&nbsp;T_VARIABLE'&nbsp;or&nbsp;T_NUM_STRING'<br />//&nbsp;This&nbsp;of&nbsp;course&nbsp;applies&nbsp;to&nbsp;using&nbsp;superglobals&nbsp;in&nbsp;strings&nbsp;as&nbsp;well<br /></span><span style="color: #007700">print&nbsp;</span><span style="color: #DD0000">"Hello&nbsp;</span><span style="color: #0000BB">$arr</span><span style="color: #007700">[</span><span style="color: #DD0000">'fruit']"</span><span style="color: #007700">;<br />print&nbsp;</span><span style="color: #DD0000">"Hello&nbsp;</span><span style="color: #0000BB">$_GET</span><span style="color: #007700">[</span><span style="color: #DD0000">'foo']"</span><span style="color: #007700">;<br /><br /></span><span style="color: #FF8000">//&nbsp;Concatenation&nbsp;is&nbsp;another&nbsp;option<br /></span><span style="color: #007700">print&nbsp;</span><span style="color: #DD0000">"Hello&nbsp;"&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">$arr</span><span style="color: #007700">[</span><span style="color: #DD0000">'fruit'</span><span style="color: #007700">];&nbsp;</span><span style="color: #FF8000">//&nbsp;Hello&nbsp;apple<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>

   <p class="para">
    When <a href="errorfunc.configuration.php#ini.error-reporting" class="link">error_reporting</a> is set to
    show <strong><code>E_NOTICE</code></strong> level errors (by setting it to
    <strong><code>E_ALL</code></strong>, for example), such uses will become immediately
    visible. By default,
    <a href="errorfunc.configuration.php#ini.error-reporting" class="link">error_reporting</a> is set not to
    show notices.
   </p>

   <p class="para">
    As stated in the <a href="language.types.array.php#language.types.array.syntax" class="link">syntax</a>
    section, what&#039;s inside the square brackets (&#039;<em>[</em>&#039; and
    &#039;<em>]</em>&#039;) must be an expression. This means that code like
    this works:
   </p>

   <div class="informalexample">
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #0000BB">$arr</span><span style="color: #007700">[</span><span style="color: #0000BB">somefunc</span><span style="color: #007700">(</span><span style="color: #0000BB">$bar</span><span style="color: #007700">)];<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
   
   <p class="para">
    This is an example of using a function return value as the array index. PHP
    also knows about constants:
   </p>

   <div class="informalexample">
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$error_descriptions</span><span style="color: #007700">[</span><span style="color: #0000BB">E_ERROR</span><span style="color: #007700">]&nbsp;&nbsp;&nbsp;=&nbsp;</span><span style="color: #DD0000">"A&nbsp;fatal&nbsp;error&nbsp;has&nbsp;occurred"</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$error_descriptions</span><span style="color: #007700">[</span><span style="color: #0000BB">E_WARNING</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #DD0000">"PHP&nbsp;issued&nbsp;a&nbsp;warning"</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$error_descriptions</span><span style="color: #007700">[</span><span style="color: #0000BB">E_NOTICE</span><span style="color: #007700">]&nbsp;&nbsp;=&nbsp;</span><span style="color: #DD0000">"This&nbsp;is&nbsp;just&nbsp;an&nbsp;informal&nbsp;notice"</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
   
   <p class="para">
    Note that <strong><code>E_ERROR</code></strong> is also a valid identifier, just like
    <em>bar</em> in the first example. But the last example is in fact
    the same as writing:
   </p>
  
   <div class="informalexample">
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$error_descriptions</span><span style="color: #007700">[</span><span style="color: #0000BB">1</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #DD0000">"A&nbsp;fatal&nbsp;error&nbsp;has&nbsp;occurred"</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$error_descriptions</span><span style="color: #007700">[</span><span style="color: #0000BB">2</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #DD0000">"PHP&nbsp;issued&nbsp;a&nbsp;warning"</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$error_descriptions</span><span style="color: #007700">[</span><span style="color: #0000BB">8</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #DD0000">"This&nbsp;is&nbsp;just&nbsp;an&nbsp;informal&nbsp;notice"</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
   
   <p class="para">
    because <strong><code>E_ERROR</code></strong> equals <em>1</em>, etc.
   </p>

   <div class="sect4" id="language.types.array.foo-bar.why">
    <h5 class="title">So why is it bad then?</h5>

    <p class="para">
     At some point in the future, the PHP team might want to add another
     constant or keyword, or a constant in other code may interfere. For
     example, it is already wrong to use the words <em>empty</em> and
     <em>default</em> this way, since they are
     <a href="reserved.php" class="link">reserved keywords</a>.
    </p>

    <blockquote class="note"><p><strong class="note">Note</strong>: 
     <span class="simpara">
      To reiterate, inside a double-quoted <span class="type"><a href="language.types.string.php" class="type string">string</a></span>, it&#039;s valid to
      not surround array indexes with quotes so <em>&quot;$foo[bar]&quot;</em>
      is valid. See the above examples for details on why as well as the section
      on <a href="language.types.string.php#language.types.string.parsing" class="link">variable parsing in
      strings</a>.
     </span>
    </p></blockquote>

   </div>
  </div>
 </div>

 <div class="sect2" id="language.types.array.casting">
  <h3 class="title">Converting to array</h3>
  
  <p class="para">
   For any of the types <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span>, <span class="type"><a href="language.types.float.php" class="type float">float</a></span>,
   <span class="type"><a href="language.types.string.php" class="type string">string</a></span>, <span class="type"><a href="language.types.boolean.php" class="type boolean">boolean</a></span> and <span class="type"><a href="language.types.resource.php" class="type resource">resource</a></span>,
   converting a value to an <span class="type"><a href="language.types.array.php" class="type array">array</a></span> results in an array with a single
   element with index zero and the value of the scalar which was converted. In
   other words, <em>(array)$scalarValue</em> is exactly the same as
   <em>array($scalarValue)</em>.
  </p>
  
  <p class="para">
   If an <span class="type"><a href="language.types.object.php" class="type object">object</a></span> is converted to an <span class="type"><a href="language.types.array.php" class="type array">array</a></span>, the result
   is an <span class="type"><a href="language.types.array.php" class="type array">array</a></span> whose elements are the <span class="type"><a href="language.types.object.php" class="type object">object</a></span>&#039;s
   properties. The keys are the member variable names, with a few notable
   exceptions: integer properties are unaccessible;
   private variables have the class name prepended to the variable
   name; protected variables have a &#039;*&#039; prepended to the variable name. These
   prepended values have null bytes on either side. This can result in some
   unexpected behaviour:
  </p>

  <div class="informalexample">
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /><br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">A&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;private&nbsp;</span><span style="color: #0000BB">$A</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;This&nbsp;will&nbsp;become&nbsp;'\0A\0A'<br /></span><span style="color: #007700">}<br /><br />class&nbsp;</span><span style="color: #0000BB">B&nbsp;</span><span style="color: #007700">extends&nbsp;</span><span style="color: #0000BB">A&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;private&nbsp;</span><span style="color: #0000BB">$A</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;This&nbsp;will&nbsp;become&nbsp;'\0B\0A'<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">public&nbsp;</span><span style="color: #0000BB">$AA</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;This&nbsp;will&nbsp;become&nbsp;'AA'<br /></span><span style="color: #007700">}<br /><br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">((array)&nbsp;new&nbsp;</span><span style="color: #0000BB">B</span><span style="color: #007700">());<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>

  <p class="para">
   The above will appear to have two keys named &#039;AA&#039;, although one of them is
   actually named &#039;\0A\0A&#039;.
  </p>
  
  <p class="para">
   Converting <strong><code>NULL</code></strong> to an <span class="type"><a href="language.types.array.php" class="type array">array</a></span> results in an empty
   <span class="type"><a href="language.types.array.php" class="type array">array</a></span>.
  </p>
 </div>

 <div class="sect2" id="language.types.array.comparing">
  <h3 class="title">Comparing</h3>

  <p class="para">
   It is possible to compare arrays with the <span class="function"><a href="function.array-diff.php" class="function">array_diff()</a></span>
   function and with
   <a href="language.operators.array.php" class="link">array operators</a>.
  </p>
 </div>

 <div class="sect2" id="language.types.array.examples">
  <h3 class="title">Examples</h3>

  <p class="para">
   The array type in PHP is very versatile. Here are some examples:
  </p>

  <div class="informalexample">
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #FF8000">//&nbsp;This:<br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;array(&nbsp;</span><span style="color: #DD0000">'color'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'red'</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'taste'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'sweet'</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'shape'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'round'</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'name'&nbsp;&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'apple'</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">4&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;key&nbsp;will&nbsp;be&nbsp;0<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">);<br /><br /></span><span style="color: #0000BB">$b&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">'a'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'b'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'c'</span><span style="color: #007700">);<br /><br /></span><span style="color: #FF8000">//&nbsp;.&nbsp;.&nbsp;.is&nbsp;completely&nbsp;equivalent&nbsp;with&nbsp;this:<br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;array();<br /></span><span style="color: #0000BB">$a</span><span style="color: #007700">[</span><span style="color: #DD0000">'color'</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #DD0000">'red'</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$a</span><span style="color: #007700">[</span><span style="color: #DD0000">'taste'</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #DD0000">'sweet'</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$a</span><span style="color: #007700">[</span><span style="color: #DD0000">'shape'</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #DD0000">'round'</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$a</span><span style="color: #007700">[</span><span style="color: #DD0000">'name'</span><span style="color: #007700">]&nbsp;&nbsp;=&nbsp;</span><span style="color: #DD0000">'apple'</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$a</span><span style="color: #007700">[]&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;</span><span style="color: #0000BB">4</span><span style="color: #007700">;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;key&nbsp;will&nbsp;be&nbsp;0<br /><br /></span><span style="color: #0000BB">$b&nbsp;</span><span style="color: #007700">=&nbsp;array();<br /></span><span style="color: #0000BB">$b</span><span style="color: #007700">[]&nbsp;=&nbsp;</span><span style="color: #DD0000">'a'</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$b</span><span style="color: #007700">[]&nbsp;=&nbsp;</span><span style="color: #DD0000">'b'</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$b</span><span style="color: #007700">[]&nbsp;=&nbsp;</span><span style="color: #DD0000">'c'</span><span style="color: #007700">;<br /><br /></span><span style="color: #FF8000">//&nbsp;After&nbsp;the&nbsp;above&nbsp;code&nbsp;is&nbsp;executed,&nbsp;$a&nbsp;will&nbsp;be&nbsp;the&nbsp;array<br />//&nbsp;array('color'&nbsp;=&gt;&nbsp;'red',&nbsp;'taste'&nbsp;=&gt;&nbsp;'sweet',&nbsp;'shape'&nbsp;=&gt;&nbsp;'round',&nbsp;<br />//&nbsp;'name'&nbsp;=&gt;&nbsp;'apple',&nbsp;0&nbsp;=&gt;&nbsp;4),&nbsp;and&nbsp;$b&nbsp;will&nbsp;be&nbsp;the&nbsp;array&nbsp;<br />//&nbsp;array(0&nbsp;=&gt;&nbsp;'a',&nbsp;1&nbsp;=&gt;&nbsp;'b',&nbsp;2&nbsp;=&gt;&nbsp;'c'),&nbsp;or&nbsp;simply&nbsp;array('a',&nbsp;'b',&nbsp;'c').<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>

  <div class="example" id="example-63">
   <p><strong>Example #8 Using array()</strong></p>
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #FF8000">//&nbsp;Array&nbsp;as&nbsp;(property-)map<br /></span><span style="color: #0000BB">$map&nbsp;</span><span style="color: #007700">=&nbsp;array(&nbsp;</span><span style="color: #DD0000">'version'&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #0000BB">4</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'OS'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'Linux'</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'lang'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'english'</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'short_tags'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #0000BB">true<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br /></span><span style="color: #FF8000">//&nbsp;strictly&nbsp;numerical&nbsp;keys<br /></span><span style="color: #0000BB">$array&nbsp;</span><span style="color: #007700">=&nbsp;array(&nbsp;</span><span style="color: #0000BB">7</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">8</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">0</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">156</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-</span><span style="color: #0000BB">10<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">);<br /></span><span style="color: #FF8000">//&nbsp;this&nbsp;is&nbsp;the&nbsp;same&nbsp;as&nbsp;array(0&nbsp;=&gt;&nbsp;7,&nbsp;1&nbsp;=&gt;&nbsp;8,&nbsp;...)<br /><br /></span><span style="color: #0000BB">$switching&nbsp;</span><span style="color: #007700">=&nbsp;array(&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">10</span><span style="color: #007700">,&nbsp;</span><span style="color: #FF8000">//&nbsp;key&nbsp;=&nbsp;0<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">5&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">=&gt;&nbsp;&nbsp;</span><span style="color: #0000BB">6</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">3&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">=&gt;&nbsp;&nbsp;</span><span style="color: #0000BB">7</span><span style="color: #007700">,&nbsp;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'a'&nbsp;&nbsp;</span><span style="color: #007700">=&gt;&nbsp;&nbsp;</span><span style="color: #0000BB">4</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">11</span><span style="color: #007700">,&nbsp;</span><span style="color: #FF8000">//&nbsp;key&nbsp;=&nbsp;6&nbsp;(maximum&nbsp;of&nbsp;integer-indices&nbsp;was&nbsp;5)<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'8'&nbsp;&nbsp;</span><span style="color: #007700">=&gt;&nbsp;&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">,&nbsp;</span><span style="color: #FF8000">//&nbsp;key&nbsp;=&nbsp;8&nbsp;(integer!)<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'02'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #0000BB">77</span><span style="color: #007700">,&nbsp;</span><span style="color: #FF8000">//&nbsp;key&nbsp;=&nbsp;'02'<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">0&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #0000BB">12&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;the&nbsp;value&nbsp;10&nbsp;will&nbsp;be&nbsp;overwritten&nbsp;by&nbsp;12<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br /></span><span style="color: #FF8000">//&nbsp;empty&nbsp;array<br /></span><span style="color: #0000BB">$empty&nbsp;</span><span style="color: #007700">=&nbsp;array();&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>

   </div>

  </div>

  <div class="example" id="example-64">
   <p><strong>Example #9 Collection</strong></p>
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$colors&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">'red'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'blue'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'green'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'yellow'</span><span style="color: #007700">);<br /><br />foreach&nbsp;(</span><span style="color: #0000BB">$colors&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">$color</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"Do&nbsp;you&nbsp;like&nbsp;</span><span style="color: #0000BB">$color</span><span style="color: #DD0000">?\n"</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

   <div class="example-contents"><p>The above example will output:</p></div>
   <div class="example-contents screen">
<div class="cdata"><pre>
Do you like red?
Do you like blue?
Do you like green?
Do you like yellow?
</pre></div>
   </div>
  </div>
  
  <p class="para">
   Changing the values of the <span class="type"><a href="language.types.array.php" class="type array">array</a></span> directly is possible
   by passing them by reference.
  </p>

  <div class="example" id="example-65">
   <p><strong>Example #10 Changing element in the loop</strong></p>
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">foreach&nbsp;(</span><span style="color: #0000BB">$colors&nbsp;</span><span style="color: #007700">as&nbsp;&amp;</span><span style="color: #0000BB">$color</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$color&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">strtoupper</span><span style="color: #007700">(</span><span style="color: #0000BB">$color</span><span style="color: #007700">);<br />}<br />unset(</span><span style="color: #0000BB">$color</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">/*&nbsp;ensure&nbsp;that&nbsp;following&nbsp;writes&nbsp;to<br />$color&nbsp;will&nbsp;not&nbsp;modify&nbsp;the&nbsp;last&nbsp;array&nbsp;element&nbsp;*/<br /><br /></span><span style="color: #0000BB">print_r</span><span style="color: #007700">(</span><span style="color: #0000BB">$colors</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

   <div class="example-contents"><p>The above example will output:</p></div>
   <div class="example-contents screen">
<div class="cdata"><pre>
Array
(
    [0] =&gt; RED
    [1] =&gt; BLUE
    [2] =&gt; GREEN
    [3] =&gt; YELLOW
)
</pre></div>
   </div>
  </div>

  <p class="para">
   This example creates a one-based array.
  </p>

  <div class="example" id="example-66">
   <p><strong>Example #11 One-based index</strong></p>
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$firstquarter&nbsp;&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #0000BB">1&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'January'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'February'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'March'</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">print_r</span><span style="color: #007700">(</span><span style="color: #0000BB">$firstquarter</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

   <div class="example-contents"><p>The above example will output:</p></div>
   <div class="example-contents screen">
<div class="cdata"><pre>
Array 
(
    [1] =&gt; &#039;January&#039;
    [2] =&gt; &#039;February&#039;
    [3] =&gt; &#039;March&#039;
)
</pre></div>   
   </div>
  </div>

  <div class="example" id="example-67">
   <p><strong>Example #12 Filling an array</strong></p>
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #FF8000">//&nbsp;fill&nbsp;an&nbsp;array&nbsp;with&nbsp;all&nbsp;items&nbsp;from&nbsp;a&nbsp;directory<br /></span><span style="color: #0000BB">$handle&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">opendir</span><span style="color: #007700">(</span><span style="color: #DD0000">'.'</span><span style="color: #007700">);<br />while&nbsp;(</span><span style="color: #0000BB">false&nbsp;</span><span style="color: #007700">!==&nbsp;(</span><span style="color: #0000BB">$file&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">readdir</span><span style="color: #007700">(</span><span style="color: #0000BB">$handle</span><span style="color: #007700">)))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$files</span><span style="color: #007700">[]&nbsp;=&nbsp;</span><span style="color: #0000BB">$file</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">closedir</span><span style="color: #007700">(</span><span style="color: #0000BB">$handle</span><span style="color: #007700">);&nbsp;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>

  <p class="para">
   <span class="type"><a href="language.types.array.php" class="type Array">Array</a></span>s are ordered. The order can be changed using various
   sorting functions. See the <a href="ref.array.php" class="link">array functions</a>
   section for more information. The <span class="function"><a href="function.count.php" class="function">count()</a></span> function can be
   used to count the number of items in an <span class="type"><a href="language.types.array.php" class="type array">array</a></span>.
  </p>

  <div class="example" id="example-68">
   <p><strong>Example #13 Sorting an array</strong></p>
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />sort</span><span style="color: #007700">(</span><span style="color: #0000BB">$files</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">print_r</span><span style="color: #007700">(</span><span style="color: #0000BB">$files</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>

  <p class="para">
   Because the value of an <span class="type"><a href="language.types.array.php" class="type array">array</a></span> can be anything, it can also be
   another <span class="type"><a href="language.types.array.php" class="type array">array</a></span>. This enables the creation of recursive and
   multi-dimensional <span class="type"><a href="language.types.array.php" class="type array">array</a></span>s.
  </p>

  <div class="example" id="example-69">
   <p><strong>Example #14 Recursive and multi-dimensional arrays</strong></p>
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$fruits&nbsp;</span><span style="color: #007700">=&nbsp;array&nbsp;(&nbsp;</span><span style="color: #DD0000">"fruits"&nbsp;&nbsp;</span><span style="color: #007700">=&gt;&nbsp;array&nbsp;(&nbsp;</span><span style="color: #DD0000">"a"&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">"orange"</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"b"&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">"banana"</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"c"&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">"apple"<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">),<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"numbers"&nbsp;</span><span style="color: #007700">=&gt;&nbsp;array&nbsp;(&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">3</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">4</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">5</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">6<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">),<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"holes"&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">=&gt;&nbsp;array&nbsp;(&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"first"</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">5&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">"second"</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"third"<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">)<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;);<br /><br /></span><span style="color: #FF8000">//&nbsp;Some&nbsp;examples&nbsp;to&nbsp;address&nbsp;values&nbsp;in&nbsp;the&nbsp;array&nbsp;above&nbsp;<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #0000BB">$fruits</span><span style="color: #007700">[</span><span style="color: #DD0000">"holes"</span><span style="color: #007700">][</span><span style="color: #0000BB">5</span><span style="color: #007700">];&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;prints&nbsp;"second"<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #0000BB">$fruits</span><span style="color: #007700">[</span><span style="color: #DD0000">"fruits"</span><span style="color: #007700">][</span><span style="color: #DD0000">"a"</span><span style="color: #007700">];&nbsp;</span><span style="color: #FF8000">//&nbsp;prints&nbsp;"orange"<br /></span><span style="color: #007700">unset(</span><span style="color: #0000BB">$fruits</span><span style="color: #007700">[</span><span style="color: #DD0000">"holes"</span><span style="color: #007700">][</span><span style="color: #0000BB">0</span><span style="color: #007700">]);&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;remove&nbsp;"first"<br /><br />//&nbsp;Create&nbsp;a&nbsp;new&nbsp;multi-dimensional&nbsp;array<br /></span><span style="color: #0000BB">$juices</span><span style="color: #007700">[</span><span style="color: #DD0000">"apple"</span><span style="color: #007700">][</span><span style="color: #DD0000">"green"</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #DD0000">"good"</span><span style="color: #007700">;&nbsp;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>

  <p class="para">
   <span class="type"><a href="language.types.array.php" class="type Array">Array</a></span> assignment always involves value copying. Use the
   <a href="language.operators.php" class="link">reference operator</a> to copy an
   <span class="type"><a href="language.types.array.php" class="type array">array</a></span> by reference.
  </p>

  <div class="informalexample">
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$arr1&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #0000BB">2</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">3</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">$arr2&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$arr1</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$arr2</span><span style="color: #007700">[]&nbsp;=&nbsp;</span><span style="color: #0000BB">4</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;$arr2&nbsp;is&nbsp;changed,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;$arr1&nbsp;is&nbsp;still&nbsp;array(2,&nbsp;3)<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br /></span><span style="color: #0000BB">$arr3&nbsp;</span><span style="color: #007700">=&nbsp;&amp;</span><span style="color: #0000BB">$arr1</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$arr3</span><span style="color: #007700">[]&nbsp;=&nbsp;</span><span style="color: #0000BB">4</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;now&nbsp;$arr1&nbsp;and&nbsp;$arr3&nbsp;are&nbsp;the&nbsp;same<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>

 </div>
</div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.types.array&amp;redirect=http://php.net/manual/en/language.types.array.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">22 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="104064">  <div class="votes">
    <div id="Vu104064">
    <a href="/manual/vote-note.php?id=104064&amp;page=language.types.array&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd104064">
    <a href="/manual/vote-note.php?id=104064&amp;page=language.types.array&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V104064" title="54% like this...">
    88
    </div>
  </div>
  <a href="#104064" class="name">
  <strong class="user"><em>mlvljr</em></strong></a><a class="genanchor" href="#104064"> &para;</a><div class="date" title="2011-05-20 06:37"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom104064">
<div class="phpcode"><code><span class="html">
please note that when arrays are copied, the "reference status" of their members is preserved (<a href="http://www.php.net/manual/en/language.references.whatdo.php" rel="nofollow" target="_blank">http://www.php.net/manual/en/language.references.whatdo.php</a>).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118855">  <div class="votes">
    <div id="Vu118855">
    <a href="/manual/vote-note.php?id=118855&amp;page=language.types.array&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118855">
    <a href="/manual/vote-note.php?id=118855&amp;page=language.types.array&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118855" title="61% like this...">
    29
    </div>
  </div>
  <a href="#118855" class="name">
  <strong class="user"><em>thomas tulinsky</em></strong></a><a class="genanchor" href="#118855"> &para;</a><div class="date" title="2016-02-17 08:10"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom118855">
<div class="phpcode"><code><span class="html">
I think your first, main example is needlessly confusing, very confusing to newbies:<br /><br />$array = array(<br />&nbsp; &nbsp; "foo" =&gt; "bar",<br />&nbsp; &nbsp; "bar" =&gt; "foo",<br />);<br /><br />It should be removed.<br /> <br />For newbies:<br />An array index can be any string value, even a value that is also a value in the array. <br />The value of array["foo"] is "bar".<br />The value of array["bar"] is "foo"<br /><br />The following expressions are both true:<br />$array["foo"] == "bar"<br />$array["bar"] == "foo"</span>
</code></div>
  </div>
 </div>
  <div class="note" id="80311">  <div class="votes">
    <div id="Vu80311">
    <a href="/manual/vote-note.php?id=80311&amp;page=language.types.array&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd80311">
    <a href="/manual/vote-note.php?id=80311&amp;page=language.types.array&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V80311" title="52% like this...">
    50
    </div>
  </div>
  <a href="#80311" class="name">
  <strong class="user"><em>ken underscore yap atsign email dot com</em></strong></a><a class="genanchor" href="#80311"> &para;</a><div class="date" title="2008-01-09 08:00"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom80311">
<div class="phpcode"><code><span class="html">
"If you convert a NULL value to an array, you get an empty array."<br /><br />This turns out to be a useful property. Say you have a search function that returns an array of values on success or NULL if nothing found.<br /><br /><span class="default">&lt;?php $values </span><span class="keyword">= </span><span class="default">search</span><span class="keyword">(...); </span><span class="default">?&gt;<br /></span><br />Now you want to merge the array with another array. What do we do if $values is NULL? No problem:<br /><br /><span class="default">&lt;?php $combined </span><span class="keyword">= </span><span class="default">array_merge</span><span class="keyword">((array)</span><span class="default">$values</span><span class="keyword">, </span><span class="default">$other</span><span class="keyword">); </span><span class="default">?&gt;<br /></span><br />Voila.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="52124">  <div class="votes">
    <div id="Vu52124">
    <a href="/manual/vote-note.php?id=52124&amp;page=language.types.array&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd52124">
    <a href="/manual/vote-note.php?id=52124&amp;page=language.types.array&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V52124" title="52% like this...">
    44
    </div>
  </div>
  <a href="#52124" class="name">
  <strong class="user"><em>jeff splat codedread splot com</em></strong></a><a class="genanchor" href="#52124"> &para;</a><div class="date" title="2005-04-21 09:16"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom52124">
<div class="phpcode"><code><span class="html">
Beware that if you're using strings as indices in the $_POST array, that periods are transformed into underscores:<br /><br />&lt;html&gt;<br />&lt;body&gt;<br /><span class="default">&lt;?php<br />&nbsp; &nbsp; printf</span><span class="keyword">(</span><span class="string">"POST: "</span><span class="keyword">); </span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$_POST</span><span class="keyword">); </span><span class="default">printf</span><span class="keyword">(</span><span class="string">"&lt;br/&gt;"</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span>&lt;form method="post" action="<span class="default">&lt;?php </span><span class="keyword">echo </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_SELF'</span><span class="keyword">]; </span><span class="default">?&gt;</span>"&gt;<br />&nbsp; &nbsp; &lt;input type="hidden" name="Windows3.1" value="Sux"&gt;<br />&nbsp; &nbsp; &lt;input type="submit" value="Click" /&gt;<br />&lt;/form&gt;<br />&lt;/body&gt;<br />&lt;/html&gt;<br /><br />Once you click on the button, the page displays the following:<br /><br />POST: Array ( [Windows3_1] =&gt; Sux )</span>
</code></div>
  </div>
 </div>
  <div class="note" id="112289">  <div class="votes">
    <div id="Vu112289">
    <a href="/manual/vote-note.php?id=112289&amp;page=language.types.array&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd112289">
    <a href="/manual/vote-note.php?id=112289&amp;page=language.types.array&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V112289" title="53% like this...">
    28
    </div>
  </div>
  <a href="#112289" class="name">
  <strong class="user"><em>chris at ocportal dot com</em></strong></a><a class="genanchor" href="#112289"> &para;</a><div class="date" title="2013-05-28 09:01"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom112289">
<div class="phpcode"><code><span class="html">
Note that array value buckets are reference-safe, even through serialization.<br /><br /><span class="default">&lt;?php<br />$x</span><span class="keyword">=</span><span class="string">'initial'</span><span class="keyword">;<br /></span><span class="default">$test</span><span class="keyword">=array(</span><span class="string">'A'</span><span class="keyword">=&gt;&amp;</span><span class="default">$x</span><span class="keyword">,</span><span class="string">'B'</span><span class="keyword">=&gt;&amp;</span><span class="default">$x</span><span class="keyword">);<br /></span><span class="default">$test</span><span class="keyword">=</span><span class="default">unserialize</span><span class="keyword">(</span><span class="default">serialize</span><span class="keyword">(</span><span class="default">$test</span><span class="keyword">));<br /></span><span class="default">$test</span><span class="keyword">[</span><span class="string">'A'</span><span class="keyword">]=</span><span class="string">'changed'</span><span class="keyword">;<br />echo </span><span class="default">$test</span><span class="keyword">[</span><span class="string">'B'</span><span class="keyword">]; </span><span class="comment">// Outputs "changed"<br /></span><span class="default">?&gt;<br /></span><br />This can be useful in some cases, for example saving RAM within complex structures.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120571">  <div class="votes">
    <div id="Vu120571">
    <a href="/manual/vote-note.php?id=120571&amp;page=language.types.array&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120571">
    <a href="/manual/vote-note.php?id=120571&amp;page=language.types.array&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120571" title="57% like this...">
    7
    </div>
  </div>
  <a href="#120571" class="name">
  <strong class="user"><em>as at asgl dot de</em></strong></a><a class="genanchor" href="#120571"> &para;</a><div class="date" title="2017-02-01 10:44"><strong>10 months ago</strong></div>
  <div class="text" id="Hcom120571">
<div class="phpcode"><code><span class="html">
// On PHP 7.1 until Jan. 20 2017<br />$testVar = "";<br />$testVar[2] = "Meine eigene Lösung";<br />echo $testVar[2];<br /><br />// Result:<br />// Meine eigene Lösung =&gt; $testVar is an ARRAY<br /><br />// On PHP 7.1.1 after Jan. 20 2017<br />$testVar = "";<br />$testVar[2] = "Meine eigene Lösung";<br />echo $testVar[2];<br />// Result:<br />// M =&gt; $testVar is a STRING !!!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="51348">  <div class="votes">
    <div id="Vu51348">
    <a href="/manual/vote-note.php?id=51348&amp;page=language.types.array&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd51348">
    <a href="/manual/vote-note.php?id=51348&amp;page=language.types.array&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V51348" title="52% like this...">
    39
    </div>
  </div>
  <a href="#51348" class="name">
  <strong class="user"><em>lars-phpcomments at ukmix dot net</em></strong></a><a class="genanchor" href="#51348"> &para;</a><div class="date" title="2005-03-28 08:40"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom51348">
<div class="phpcode"><code><span class="html">
Used to creating arrays like this in Perl?<br /><br />@array = ("All", "A".."Z");<br /><br />Looks like we need the range() function in PHP:<br /><br /><span class="default">&lt;?php<br />$array </span><span class="keyword">= </span><span class="default">array_merge</span><span class="keyword">(array(</span><span class="string">'All'</span><span class="keyword">), </span><span class="default">range</span><span class="keyword">(</span><span class="string">'A'</span><span class="keyword">, </span><span class="string">'Z'</span><span class="keyword">));<br /></span><span class="default">?&gt;<br /></span><br />You don't need to array_merge if it's just one range:<br /><br /><span class="default">&lt;?php<br />$array </span><span class="keyword">= </span><span class="default">range</span><span class="keyword">(</span><span class="string">'A'</span><span class="keyword">, </span><span class="string">'Z'</span><span class="keyword">);<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="115819">  <div class="votes">
    <div id="Vu115819">
    <a href="/manual/vote-note.php?id=115819&amp;page=language.types.array&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115819">
    <a href="/manual/vote-note.php?id=115819&amp;page=language.types.array&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115819" title="54% like this...">
    13
    </div>
  </div>
  <a href="#115819" class="name">
  <strong class="user"><em>mathiasgrimm at gmail dot com</em></strong></a><a class="genanchor" href="#115819"> &para;</a><div class="date" title="2014-09-29 04:20"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115819">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br /><br />$a</span><span class="keyword">[</span><span class="string">'a'</span><span class="keyword">] = </span><span class="default">null</span><span class="keyword">;<br /></span><span class="default">$a</span><span class="keyword">[</span><span class="string">'b'</span><span class="keyword">] = array();<br /><br />echo </span><span class="default">$a</span><span class="keyword">[</span><span class="string">'a'</span><span class="keyword">][</span><span class="string">'non-existent'</span><span class="keyword">]; </span><span class="comment">// DOES NOT throw an E_NOTICE error as expected.<br /><br /></span><span class="keyword">echo </span><span class="default">$a</span><span class="keyword">[</span><span class="string">'b'</span><span class="keyword">][</span><span class="string">'non-existent'</span><span class="keyword">]; </span><span class="comment">// throws an E_NOTICE as expected<br /></span><span class="default">?&gt;<br /></span><br />I added this bug to bugs.php.net (<a href="https://bugs.php.net/bug.php?id=68110" rel="nofollow" target="_blank">https://bugs.php.net/bug.php?id=68110</a>)<br />however I made tests with php4, 5.4 and 5.5 versions and all behave the same way.<br /><br />This, in my point of view, should be cast to an array type and throw the same error.<br /><br />This is, according to the documentation on this page, wrong.<br /><br />From doc:<br />"Note:<br />Attempting to access an array key which has not been defined is the same as accessing any other undefined variable: an E_NOTICE-level error message will be issued, and the result will be NULL."</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120704">  <div class="votes">
    <div id="Vu120704">
    <a href="/manual/vote-note.php?id=120704&amp;page=language.types.array&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120704">
    <a href="/manual/vote-note.php?id=120704&amp;page=language.types.array&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120704" title="56% like this...">
    3
    </div>
  </div>
  <a href="#120704" class="name">
  <strong class="user"><em>Yesterday php&amp;#39;er</em></strong></a><a class="genanchor" href="#120704"> &para;</a><div class="date" title="2017-02-24 03:22"><strong>9 months ago</strong></div>
  <div class="text" id="Hcom120704">
<div class="phpcode"><code><span class="html">
--- quote ---<br />Note:<br />Both square brackets and curly braces can be used interchangeably for accessing array elements<br />--- quote end ---<br /><br />At least for php 5.4 and 5.6; if function returns an array, the curly brackets does not work directly accessing function result, eg. WillReturnArray(){1} . This will give "syntax error, unexpected '{' in...".<br />Personally I use only square brackets, expect for accessing single char in string. Old habits...</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113086">  <div class="votes">
    <div id="Vu113086">
    <a href="/manual/vote-note.php?id=113086&amp;page=language.types.array&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113086">
    <a href="/manual/vote-note.php?id=113086&amp;page=language.types.array&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113086" title="52% like this...">
    17
    </div>
  </div>
  <a href="#113086" class="name">
  <strong class="user"><em>ivegner at yandex dot ru</em></strong></a><a class="genanchor" href="#113086"> &para;</a><div class="date" title="2013-08-28 08:43"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113086">
<div class="phpcode"><code><span class="html">
Note that objects of classes extending ArrayObject SPL class are treated as arrays, and not as objects when converting to array.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">ArrayObjectExtended </span><span class="keyword">extends </span><span class="default">ArrayObject<br /></span><span class="keyword">{<br />&nbsp; &nbsp; private </span><span class="default">$private </span><span class="keyword">= </span><span class="string">'private'</span><span class="keyword">;<br />&nbsp; &nbsp; public </span><span class="default">$hello </span><span class="keyword">= </span><span class="string">'world'</span><span class="keyword">;<br />}<br /><br /></span><span class="default">$object </span><span class="keyword">= new </span><span class="default">ArrayObjectExtended</span><span class="keyword">();<br /></span><span class="default">$array </span><span class="keyword">= (array) </span><span class="default">$object</span><span class="keyword">;<br /><br /></span><span class="comment">// This will not expose $private and $hello properties of $object,<br />// but return an empty array instead.<br /></span><span class="default">var_export</span><span class="keyword">(</span><span class="default">$array</span><span class="keyword">);<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="57312">  <div class="votes">
    <div id="Vu57312">
    <a href="/manual/vote-note.php?id=57312&amp;page=language.types.array&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd57312">
    <a href="/manual/vote-note.php?id=57312&amp;page=language.types.array&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V57312" title="51% like this...">
    29
    </div>
  </div>
  <a href="#57312" class="name">
  <strong class="user"><em>ia [AT] zoznam [DOT] sk</em></strong></a><a class="genanchor" href="#57312"> &para;</a><div class="date" title="2005-09-30 02:55"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom57312">
<div class="phpcode"><code><span class="html">
Regarding the previous comment, beware of the fact that reference to the last value of the array remains stored in $value after the foreach:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">foreach ( </span><span class="default">$arr </span><span class="keyword">as </span><span class="default">$key </span><span class="keyword">=&gt; &amp;</span><span class="default">$value </span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="default">$value </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />}<br /><br /></span><span class="comment">// without next line you can get bad results...<br />//unset( $value );<br /><br /></span><span class="default">$value </span><span class="keyword">= </span><span class="default">159</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />Now the last element of $arr has the value of '159'. If we remove the comment in the unset() line, everything works as expected ($arr has all values of '1').<br /><br />Bad results can also appear in nested foreach loops (the same reason as above).<br /><br />So either unset $value after each foreach or better use the longer form:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">foreach ( </span><span class="default">$arr </span><span class="keyword">as </span><span class="default">$key </span><span class="keyword">=&gt; </span><span class="default">$value </span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="default">$arr</span><span class="keyword">[ </span><span class="default">$key </span><span class="keyword">] = </span><span class="default">1</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114078">  <div class="votes">
    <div id="Vu114078">
    <a href="/manual/vote-note.php?id=114078&amp;page=language.types.array&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114078">
    <a href="/manual/vote-note.php?id=114078&amp;page=language.types.array&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114078" title="53% like this...">
    9
    </div>
  </div>
  <a href="#114078" class="name">
  <strong class="user"><em>note dot php dot lorriman at spamgourmet dot org</em></strong></a><a class="genanchor" href="#114078"> &para;</a><div class="date" title="2014-01-09 03:01"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114078">
<div class="phpcode"><code><span class="html">
There is another kind of array (php&gt;=&nbsp; 5.3.0) produced by <br /><br />$array = new SplFixedArray(5);<br /><br />Standard arrays, as documented here, are marvellously flexible and, due to the underlying hashtable, extremely fast for certain kinds of lookup operation. <br /><br />Supposing a large string-keyed array <br /><br />$arr=['string1'=&gt;$data1, 'string2'=&gt;$data2 etc....]<br /><br />when getting the keyed data with <br /><br />$data=$arr['string1'];<br /><br />php does *not* have to search through the array comparing each key string to the given key ('string1') one by one, which could take a long time with a large array. Instead the hashtable means that php takes the given key string and computes from it the memory location of the keyed data, and then instantly retrieves the data. Marvellous! And so quick. And no need to know anything about hashtables as it's all hidden away.<br /><br />However, there is a lot of overhead in that. It uses lots of memory, as hashtables tend to (also nearly doubling on a 64bit server), and should be significantly slower for integer keyed arrays than old-fashioned (non-hashtable) integer-keyed arrays. For that see more on SplFixedArray :<br /><br /><a href="http://uk3.php.net/SplFixedArray" rel="nofollow" target="_blank">http://uk3.php.net/SplFixedArray</a><br /><br />Unlike a standard php (hashtabled) array, if you lookup by integer then the integer itself denotes the memory location of the data, no hashtable computation on the integer key needed. This is much quicker. It's also quicker to build the array compared to the complex operations needed for hashtables. And it uses a lot less memory as there is no hashtable data structure. This is really an optimisation decision, but in some cases of large integer keyed arrays it may significantly reduce server memory and increase performance (including the avoiding of expensive memory deallocation of hashtable arrays at the exiting of the script).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="56234">  <div class="votes">
    <div id="Vu56234">
    <a href="/manual/vote-note.php?id=56234&amp;page=language.types.array&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd56234">
    <a href="/manual/vote-note.php?id=56234&amp;page=language.types.array&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V56234" title="50% like this...">
    14
    </div>
  </div>
  <a href="#56234" class="name">
  <strong class="user"><em>caifara aaaat im dooaat be</em></strong></a><a class="genanchor" href="#56234"> &para;</a><div class="date" title="2005-08-28 02:28"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom56234">
<div class="phpcode"><code><span class="html">
[Editor's note: You can achieve what you're looking for by referencing $single, rather than copying it by value in your foreach statement. See <a href="http://php.net/foreach" rel="nofollow" target="_blank">http://php.net/foreach</a> for more details.]<br /><br />Don't know if this is known or not, but it did eat some of my time and maybe it won't eat your time now...<br /><br />I tried to add something to a multidimensional array, but that didn't work at first, look at the code below to see what I mean:<br /><br /><span class="default">&lt;?php<br /><br />$a1 </span><span class="keyword">= array( </span><span class="string">"a" </span><span class="keyword">=&gt; </span><span class="default">0</span><span class="keyword">, </span><span class="string">"b" </span><span class="keyword">=&gt; </span><span class="default">1 </span><span class="keyword">);<br /></span><span class="default">$a2 </span><span class="keyword">= array( </span><span class="string">"aa" </span><span class="keyword">=&gt; </span><span class="default">00</span><span class="keyword">, </span><span class="string">"bb" </span><span class="keyword">=&gt; </span><span class="default">11 </span><span class="keyword">);<br /><br /></span><span class="default">$together </span><span class="keyword">= array( </span><span class="default">$a1</span><span class="keyword">, </span><span class="default">$a2 </span><span class="keyword">);<br /><br />foreach( </span><span class="default">$together </span><span class="keyword">as </span><span class="default">$single </span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$single</span><span class="keyword">[ </span><span class="string">"c" </span><span class="keyword">] = </span><span class="default">3 </span><span class="keyword">;<br />}<br /><br /></span><span class="default">print_r</span><span class="keyword">( </span><span class="default">$together </span><span class="keyword">); <br /></span><span class="comment">/* nothing changed result is:<br />Array<br />(<br />&nbsp; &nbsp; [0] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [a] =&gt; 0<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [b] =&gt; 1<br />&nbsp; &nbsp; &nbsp; &nbsp; )<br />&nbsp; &nbsp; [1] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [aa] =&gt; 0<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [bb] =&gt; 11<br />&nbsp; &nbsp; &nbsp; &nbsp; )<br />) */<br /><br /></span><span class="keyword">foreach( </span><span class="default">$together </span><span class="keyword">as </span><span class="default">$key </span><span class="keyword">=&gt; </span><span class="default">$value </span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$together</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">][</span><span class="string">"c"</span><span class="keyword">] = </span><span class="default">3 </span><span class="keyword">;<br />}<br /><br /></span><span class="default">print_r</span><span class="keyword">( </span><span class="default">$together </span><span class="keyword">);<br /><br /></span><span class="comment">/* now it works, this prints<br />Array<br />(<br />&nbsp; &nbsp; [0] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [a] =&gt; 0<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [b] =&gt; 1<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [c] =&gt; 3<br />&nbsp; &nbsp; &nbsp; &nbsp; )<br />&nbsp; &nbsp; [1] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [aa] =&gt; 0<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [bb] =&gt; 11<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [c] =&gt; 3<br />&nbsp; &nbsp; &nbsp; &nbsp; )<br />)<br />*/<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121909">  <div class="votes">
    <div id="Vu121909">
    <a href="/manual/vote-note.php?id=121909&amp;page=language.types.array&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121909">
    <a href="/manual/vote-note.php?id=121909&amp;page=language.types.array&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121909" title="no votes...">
    0
    </div>
  </div>
  <a href="#121909" class="name">
  <strong class="user"><em>liberchen at gmail dot com</em></strong></a><a class="genanchor" href="#121909"> &para;</a><div class="date" title="2017-11-23 03:34"><strong>21 days ago</strong></div>
  <div class="text" id="Hcom121909">
<div class="phpcode"><code><span class="html">
Since PHP 7.1, the string will not be converted to array automatically.<br /><br />Below codes will fail:<br /><br />$a=array();<br />$a['a']='';<br />$a['a']['b']='';&nbsp; <br />//Warning: Illegal string offset 'b'<br />//Warning: Cannot assign an empty string to a string offset<br /><br />You have to change to as below:<br /><br />$a=array();<br /><br />$a['a']=array(); // Declare it is an array first<br />$a['a']['b']='';</span>
</code></div>
  </div>
 </div>
  <div class="note" id="99363">  <div class="votes">
    <div id="Vu99363">
    <a href="/manual/vote-note.php?id=99363&amp;page=language.types.array&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd99363">
    <a href="/manual/vote-note.php?id=99363&amp;page=language.types.array&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V99363" title="50% like this...">
    3
    </div>
  </div>
  <a href="#99363" class="name">
  <strong class="user"><em>Walter Tross</em></strong></a><a class="genanchor" href="#99363"> &para;</a><div class="date" title="2010-08-12 11:04"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom99363">
<div class="phpcode"><code><span class="html">
It is true that "array assignment always involves value copying", but the copy is a "lazy copy". This means that the data of the two variables occupy the same memory as long as no array element changes.<br /><br />E.g., if you have to pass an array to a function that only needs to read it, there is no advantage at all in passing it by reference.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="108106">  <div class="votes">
    <div id="Vu108106">
    <a href="/manual/vote-note.php?id=108106&amp;page=language.types.array&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd108106">
    <a href="/manual/vote-note.php?id=108106&amp;page=language.types.array&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V108106" title="49% like this...">
    -4
    </div>
  </div>
  <a href="#108106" class="name">
  <strong class="user"><em>martijntje at martijnotto dot nl</em></strong></a><a class="genanchor" href="#108106"> &para;</a><div class="date" title="2012-03-29 07:48"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom108106">
<div class="phpcode"><code><span class="html">
Please note that adding the magic __toString() method to your objects will not allow you to seek an array with it, it still throws an Illegal Offset warning.<br /><br />The solution is to cast it to a string first, like this<br /><br />$array[(string) $stringableObject]</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114092">  <div class="votes">
    <div id="Vu114092">
    <a href="/manual/vote-note.php?id=114092&amp;page=language.types.array&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114092">
    <a href="/manual/vote-note.php?id=114092&amp;page=language.types.array&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114092" title="47% like this...">
    -8
    </div>
  </div>
  <a href="#114092" class="name">
  <strong class="user"><em>brta dot akos at gmail dot com</em></strong></a><a class="genanchor" href="#114092"> &para;</a><div class="date" title="2014-01-10 01:45"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114092">
<div class="phpcode"><code><span class="html">
Why not to user one-based arrays:<br /><br /><span class="default">&lt;?php<br />$a&nbsp; </span><span class="keyword">= array(</span><span class="default">1 </span><span class="keyword">=&gt; </span><span class="string">'a'</span><span class="keyword">, </span><span class="string">'b'</span><span class="keyword">, </span><span class="string">'d'</span><span class="keyword">);<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">);<br /></span><span class="default">array_splice</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">,</span><span class="default">2</span><span class="keyword">,</span><span class="default">0</span><span class="keyword">,</span><span class="string">'c'</span><span class="keyword">);<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />output:<br />Array ( [1] =&gt; a [2] =&gt; b [3] =&gt; d ) Array ( [0] =&gt; a [1] =&gt; b [2] =&gt; c [3] =&gt; d )</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119412">  <div class="votes">
    <div id="Vu119412">
    <a href="/manual/vote-note.php?id=119412&amp;page=language.types.array&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119412">
    <a href="/manual/vote-note.php?id=119412&amp;page=language.types.array&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119412" title="45% like this...">
    -8
    </div>
  </div>
  <a href="#119412" class="name">
  <strong class="user"><em>php at markuszeller dot com</em></strong></a><a class="genanchor" href="#119412"> &para;</a><div class="date" title="2016-06-01 09:24"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119412">
<div class="phpcode"><code><span class="html">
Sometimes I need to match fieldnames from database tables. But if a source field is used many times you can not use a hash "=&gt;", because it overrides the key.<br /><br />My approach is to use a comma separated array and use a while-loop in conjunction with each. Having that you can iterate key/value based, but may have a key multiple times.<br /><br />$fieldmap = array<br />(<br />&nbsp; &nbsp; 'id', 'import_id',<br />&nbsp; &nbsp; 'productname', 'title',<br />&nbsp; &nbsp; 'datetime_online', 'onlineDate',<br />&nbsp; &nbsp; 'datetime_test_final', 'offlineDate',<br />&nbsp; &nbsp; 'active', 'status',<br />&nbsp; &nbsp; 'questionaire_intro', 'text_lead',<br />&nbsp; &nbsp; 'datetime_online', 'createdAt',<br />&nbsp; &nbsp; 'datetime_online', 'updatedAt'<br />);<br /><br />while(list(,$key) = each($fieldmap))<br />{<br />&nbsp; &nbsp; list(,$value) = each($fieldmap);<br />&nbsp; &nbsp; echo "$key: $value\n";<br />}</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117787">  <div class="votes">
    <div id="Vu117787">
    <a href="/manual/vote-note.php?id=117787&amp;page=language.types.array&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117787">
    <a href="/manual/vote-note.php?id=117787&amp;page=language.types.array&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117787" title="45% like this...">
    -11
    </div>
  </div>
  <a href="#117787" class="name">
  <strong class="user"><em>aditycse at gmail dot com</em></strong></a><a class="genanchor" href="#117787"> &para;</a><div class="date" title="2015-08-10 09:23"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117787">
<div class="phpcode"><code><span class="html">
/*<br /> * Name : Aditya Mehrotra <br /> * Email: aditycse@gmail.com<br /> */<br /><span class="default">&lt;?php<br /></span><span class="comment">//Array can have following data type in key i.e string,integer<br />//Behaviour of array in case of array key has data type float or double<br /><br /></span><span class="default">$exampleArray </span><span class="keyword">= array(</span><span class="default">0</span><span class="keyword">,<br />&nbsp; &nbsp; </span><span class="default">1</span><span class="keyword">,<br />&nbsp; &nbsp; </span><span class="string">"2.99999999" </span><span class="keyword">=&gt; </span><span class="default">56</span><span class="keyword">,<br />&nbsp; &nbsp; </span><span class="default">2 </span><span class="keyword">=&gt; </span><span class="default">2</span><span class="keyword">,<br />&nbsp; &nbsp; </span><span class="default">3.9999 </span><span class="keyword">=&gt; </span><span class="default">3</span><span class="keyword">,<br />&nbsp; &nbsp; </span><span class="default">3 </span><span class="keyword">=&gt; </span><span class="default">3.1</span><span class="keyword">,<br />&nbsp; &nbsp; </span><span class="default">true </span><span class="keyword">=&gt; </span><span class="default">4</span><span class="keyword">,<br />&nbsp; &nbsp; </span><span class="default">false </span><span class="keyword">=&gt; </span><span class="default">6</span><span class="keyword">,<br />);<br /><br /></span><span class="comment">//array structure<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$exampleArray</span><span class="keyword">);<br /></span><span class="comment">/* Array<br />&nbsp; (<br />&nbsp; &nbsp; &nbsp; [0] =&gt; 6<br />&nbsp; &nbsp; &nbsp; [1] =&gt; 4<br />&nbsp; &nbsp; &nbsp; [2.99999999] =&gt; 56<br />&nbsp; &nbsp; &nbsp; [2] =&gt; 2<br />&nbsp; &nbsp; &nbsp; [3] =&gt; 3.1<br />&nbsp; )<br /> */<br /><br />//array of array keys <br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">array_keys</span><span class="keyword">(</span><span class="default">$exampleArray</span><span class="keyword">));<br /></span><span class="comment">/*<br />Array<br />(<br />&nbsp; &nbsp; [0] =&gt; 0<br />&nbsp; &nbsp; [1] =&gt; 1<br />&nbsp; &nbsp; [2] =&gt; 2.99999999<br />&nbsp; &nbsp; [3] =&gt; 2<br />&nbsp; &nbsp; [4] =&gt; 3<br />)<br /> */</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="73936">  <div class="votes">
    <div id="Vu73936">
    <a href="/manual/vote-note.php?id=73936&amp;page=language.types.array&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd73936">
    <a href="/manual/vote-note.php?id=73936&amp;page=language.types.array&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V73936" title="48% like this...">
    -22
    </div>
  </div>
  <a href="#73936" class="name">
  <strong class="user"><em>Spudley</em></strong></a><a class="genanchor" href="#73936"> &para;</a><div class="date" title="2007-03-16 01:44"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom73936">
<div class="phpcode"><code><span class="html">
On array recursion...<br /><br />Given the following code:<br /><br /><span class="default">&lt;?php<br />$myarray </span><span class="keyword">= array(</span><span class="string">'test'</span><span class="keyword">,</span><span class="default">123</span><span class="keyword">);<br /></span><span class="default">$myarray</span><span class="keyword">[] = &amp;</span><span class="default">$myarray</span><span class="keyword">;<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$myarray</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />The print_r() will display *RECURSION* when it gets to the third element of the array.<br /><br />There doesn't appear to be any other way to scan an array for recursive references, so if you need to check for them, you'll have to use print_r() with its second parameter to capture the output and look for the word *RECURSION*.<br /><br />It's not an elegant solution, but it's the only one I've found, so I hope it helps someone.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="70730">  <div class="votes">
    <div id="Vu70730">
    <a href="/manual/vote-note.php?id=70730&amp;page=language.types.array&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd70730">
    <a href="/manual/vote-note.php?id=70730&amp;page=language.types.array&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V70730" title="48% like this...">
    -23
    </div>
  </div>
  <a href="#70730" class="name"><strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#70730"> &para;</a><div class="date" title="2006-10-25 09:18"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom70730">
<div class="phpcode"><code><span class="html">
This page should include details about how associative arrays are implemened inside PHP; e.g. using hash-maps or b-trees.<br /><br />This has important implictions on the permance characteristics of associative arrays and how they should be used; e.g. b-tree are slow to insert but handle collisions better than hashmaps.&nbsp; Hashmaps are faster if there are no collisions, but are slower to retrieve when there are collisions.&nbsp; These factors have implictions on how associative arrays should be used.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="77642">  <div class="votes">
    <div id="Vu77642">
    <a href="/manual/vote-note.php?id=77642&amp;page=language.types.array&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd77642">
    <a href="/manual/vote-note.php?id=77642&amp;page=language.types.array&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V77642" title="45% like this...">
    -86
    </div>
  </div>
  <a href="#77642" class="name">
  <strong class="user"><em>carl at linkleaf dot com</em></strong></a><a class="genanchor" href="#77642"> &para;</a><div class="date" title="2007-09-06 11:36"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom77642">
<div class="phpcode"><code><span class="html">
Its worth noting that there does not appear to be any functional limitations on the length or content of string indexes. The string indexes for your arrays can contain any characters, including new line characters, and can be of any length:<br /><br /><span class="default">&lt;?php<br /><br />$key </span><span class="keyword">= </span><span class="string">"XXXXX"</span><span class="keyword">;<br /></span><span class="default">$test </span><span class="keyword">= array(</span><span class="default">$key </span><span class="keyword">=&gt; </span><span class="string">"test5"</span><span class="keyword">);<br /><br />for (</span><span class="default">$x </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">; </span><span class="default">$x </span><span class="keyword">&lt; </span><span class="default">500</span><span class="keyword">; </span><span class="default">$x</span><span class="keyword">++) {<br />&nbsp; </span><span class="default">$key </span><span class="keyword">.= </span><span class="string">"X"</span><span class="keyword">;<br />&nbsp; </span><span class="default">$value </span><span class="keyword">= </span><span class="string">"test" </span><span class="keyword">. </span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$key</span><span class="keyword">);<br />&nbsp; </span><span class="default">$test</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">] = </span><span class="default">$value</span><span class="keyword">;<br />}<br /><br />echo </span><span class="string">"&lt;pre&gt;"</span><span class="keyword">;<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$test</span><span class="keyword">);<br />echo </span><span class="string">"&lt;/pre&gt;"</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;<br /></span><br />Keep in mind that using extremely long array indexes is not a good practice and could cost you lots of extra CPU time. However, if you have to use a long string as an array index you won't have to worry about the length or content.</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.types.array&amp;redirect=http://php.net/manual/en/language.types.array.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.types.php">Types</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.types.intro.php" title="Introduction">Introduction</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.boolean.php" title="Booleans">Booleans</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.integer.php" title="Integers">Integers</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.float.php" title="Floating point numbers">Floating point numbers</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.string.php" title="Strings">Strings</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.types.array.php" title="Arrays">Arrays</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.iterable.php" title="Iterables">Iterables</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.object.php" title="Objects">Objects</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.resource.php" title="Resources">Resources</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.null.php" title="NULL">NULL</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.callable.php" title="Callbacks / Callables">Callbacks / Callables</a>
                        </li>
                          
                        <li class="">
                            <a href="language.pseudo-types.php" title="Pseudo-&#8203;types and variables used in this documentation">Pseudo-&#8203;types and variables used in this documentation</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.type-juggling.php" title="Type Juggling">Type Juggling</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

