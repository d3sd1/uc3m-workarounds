<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Anonymous functions - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/functions.anonymous.php">
 <link rel="shorturl" href="http://php.net/manual/en/functions.anonymous.php">
 <link rel="alternate" href="http://php.net/manual/en/functions.anonymous.php" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.functions.php">
 <link rel="prev" href="http://php.net/manual/en/functions.internal.php">
 <link rel="next" href="http://php.net/manual/en/language.oop5.php">

 <link rel="alternate" href="http://php.net/manual/en/functions.anonymous.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/functions.anonymous.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/functions.anonymous.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/functions.anonymous.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/functions.anonymous.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/functions.anonymous.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/functions.anonymous.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/functions.anonymous.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/functions.anonymous.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/functions.anonymous.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/functions.anonymous.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.oop5.php">
          Classes and Objects &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="functions.internal.php">
          &laquo; Internal (built-in) functions        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.functions.php'>Functions</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/functions.anonymous.php' selected="selected">English</option>
            <option value='pt_BR/functions.anonymous.php'>Brazilian Portuguese</option>
            <option value='zh/functions.anonymous.php'>Chinese (Simplified)</option>
            <option value='fr/functions.anonymous.php'>French</option>
            <option value='de/functions.anonymous.php'>German</option>
            <option value='ja/functions.anonymous.php'>Japanese</option>
            <option value='ro/functions.anonymous.php'>Romanian</option>
            <option value='ru/functions.anonymous.php'>Russian</option>
            <option value='es/functions.anonymous.php'>Spanish</option>
            <option value='tr/functions.anonymous.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/functions.anonymous.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=functions.anonymous">Report a Bug</a>
    </div>
  </div><div id="functions.anonymous" class="sect1">
   <h2 class="title">Anonymous functions</h2>

   <p class="simpara">
    Anonymous functions, also known as <em>closures</em>, allow the
    creation of functions which have no specified name. They are most useful as
    the value of <a href="language.pseudo-types.php#language.types.callback" class="link">callback</a>
    parameters, but they have many other uses.
   </p>
   <p class="simpara">
    Anonymous functions are implemented using the <a href="class.closure.php" class="link">
    <a href="class.closure.php" class="classname">Closure</a></a> class.
   </p>

   <div class="example" id="example-163">
    <p><strong>Example #1 Anonymous function example</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #0000BB">preg_replace_callback</span><span style="color: #007700">(</span><span style="color: #DD0000">'~-([a-z])~'</span><span style="color: #007700">,&nbsp;function&nbsp;(</span><span style="color: #0000BB">$match</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">strtoupper</span><span style="color: #007700">(</span><span style="color: #0000BB">$match</span><span style="color: #007700">[</span><span style="color: #0000BB">1</span><span style="color: #007700">]);<br />},&nbsp;</span><span style="color: #DD0000">'hello-world'</span><span style="color: #007700">);<br /></span><span style="color: #FF8000">//&nbsp;outputs&nbsp;helloWorld<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>

   <p class="simpara">
    Closures can also be used as the values of variables; PHP automatically 
    converts such expressions into instances of the
    <a href="class.closure.php" class="classname">Closure</a> internal class. Assigning a closure to a
    variable uses the same syntax as any other assignment, including the
    trailing semicolon:
   </p>

   <div class="example" id="example-164">
    <p><strong>Example #2 Anonymous function variable assignment example</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$greet&nbsp;</span><span style="color: #007700">=&nbsp;function(</span><span style="color: #0000BB">$name</span><span style="color: #007700">)<br />{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">printf</span><span style="color: #007700">(</span><span style="color: #DD0000">"Hello&nbsp;%s\r\n"</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$name</span><span style="color: #007700">);<br />};<br /><br /></span><span style="color: #0000BB">$greet</span><span style="color: #007700">(</span><span style="color: #DD0000">'World'</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">$greet</span><span style="color: #007700">(</span><span style="color: #DD0000">'PHP'</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
   
   <p class="simpara">
    Closures may also inherit variables from the parent scope. Any such
    variables must be passed to the <em>use</em> language construct.
    From PHP 7.1, these variables must not include <a href="language.variables.predefined.php" class="link">superglobals</a>,
    <var class="varname"><var class="varname">$this</var></var>, or variables with the same name as a parameter.
   </p>

   <div class="example" id="example-165">
    <p><strong>Example #3 Inheriting variables from the parent scope</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$message&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'hello'</span><span style="color: #007700">;<br /><br /></span><span style="color: #FF8000">//&nbsp;No&nbsp;"use"<br /></span><span style="color: #0000BB">$example&nbsp;</span><span style="color: #007700">=&nbsp;function&nbsp;()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$message</span><span style="color: #007700">);<br />};<br /></span><span style="color: #0000BB">$example</span><span style="color: #007700">();<br /><br /></span><span style="color: #FF8000">//&nbsp;Inherit&nbsp;$message<br /></span><span style="color: #0000BB">$example&nbsp;</span><span style="color: #007700">=&nbsp;function&nbsp;()&nbsp;use&nbsp;(</span><span style="color: #0000BB">$message</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$message</span><span style="color: #007700">);<br />};<br /></span><span style="color: #0000BB">$example</span><span style="color: #007700">();<br /><br /></span><span style="color: #FF8000">//&nbsp;Inherited&nbsp;variable's&nbsp;value&nbsp;is&nbsp;from&nbsp;when&nbsp;the&nbsp;function<br />//&nbsp;is&nbsp;defined,&nbsp;not&nbsp;when&nbsp;called<br /></span><span style="color: #0000BB">$message&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'world'</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$example</span><span style="color: #007700">();<br /><br /></span><span style="color: #FF8000">//&nbsp;Reset&nbsp;message<br /></span><span style="color: #0000BB">$message&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'hello'</span><span style="color: #007700">;<br /><br /></span><span style="color: #FF8000">//&nbsp;Inherit&nbsp;by-reference<br /></span><span style="color: #0000BB">$example&nbsp;</span><span style="color: #007700">=&nbsp;function&nbsp;()&nbsp;use&nbsp;(&amp;</span><span style="color: #0000BB">$message</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$message</span><span style="color: #007700">);<br />};<br /></span><span style="color: #0000BB">$example</span><span style="color: #007700">();<br /><br /></span><span style="color: #FF8000">//&nbsp;The&nbsp;changed&nbsp;value&nbsp;in&nbsp;the&nbsp;parent&nbsp;scope<br />//&nbsp;is&nbsp;reflected&nbsp;inside&nbsp;the&nbsp;function&nbsp;call<br /></span><span style="color: #0000BB">$message&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'world'</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$example</span><span style="color: #007700">();<br /><br /></span><span style="color: #FF8000">//&nbsp;Closures&nbsp;can&nbsp;also&nbsp;accept&nbsp;regular&nbsp;arguments<br /></span><span style="color: #0000BB">$example&nbsp;</span><span style="color: #007700">=&nbsp;function&nbsp;(</span><span style="color: #0000BB">$arg</span><span style="color: #007700">)&nbsp;use&nbsp;(</span><span style="color: #0000BB">$message</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$arg&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">'&nbsp;'&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">$message</span><span style="color: #007700">);<br />};<br /></span><span style="color: #0000BB">$example</span><span style="color: #007700">(</span><span style="color: #DD0000">"hello"</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

    <div class="example-contents"><p>The above example will output
something similar to:</p></div>
    <div class="example-contents screen">
<div class="cdata"><pre>
Notice: Undefined variable: message in /example.php on line 6
NULL
string(5) &quot;hello&quot;
string(5) &quot;hello&quot;
string(5) &quot;hello&quot;
string(5) &quot;world&quot;
string(11) &quot;hello world&quot;
</pre></div>
    </div>
   </div>

   <p class="simpara">
    Inheriting variables from the parent scope is <em class="emphasis">not</em> 
    the same as using global variables. 
    Global variables exist in the global scope, which is the same no
    matter what function is executing. The parent scope of a closure is the
    function in which the closure was declared (not necessarily the function it
    was called from). See the following example:
   </p>

   <div class="example" id="example-166">
    <p><strong>Example #4 Closures and scoping</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #FF8000">//&nbsp;A&nbsp;basic&nbsp;shopping&nbsp;cart&nbsp;which&nbsp;contains&nbsp;a&nbsp;list&nbsp;of&nbsp;added&nbsp;products<br />//&nbsp;and&nbsp;the&nbsp;quantity&nbsp;of&nbsp;each&nbsp;product.&nbsp;Includes&nbsp;a&nbsp;method&nbsp;which<br />//&nbsp;calculates&nbsp;the&nbsp;total&nbsp;price&nbsp;of&nbsp;the&nbsp;items&nbsp;in&nbsp;the&nbsp;cart&nbsp;using&nbsp;a<br />//&nbsp;closure&nbsp;as&nbsp;a&nbsp;callback.<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">Cart<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;const&nbsp;</span><span style="color: #0000BB">PRICE_BUTTER&nbsp;&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1.00</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;const&nbsp;</span><span style="color: #0000BB">PRICE_MILK&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">3.00</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;const&nbsp;</span><span style="color: #0000BB">PRICE_EGGS&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">6.95</span><span style="color: #007700">;<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;protected&nbsp;</span><span style="color: #0000BB">$products&nbsp;</span><span style="color: #007700">=&nbsp;array();<br />&nbsp;&nbsp;&nbsp;&nbsp;<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">add</span><span style="color: #007700">(</span><span style="color: #0000BB">$product</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$quantity</span><span style="color: #007700">)<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">products</span><span style="color: #007700">[</span><span style="color: #0000BB">$product</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #0000BB">$quantity</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;&nbsp;&nbsp;&nbsp;<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">getQuantity</span><span style="color: #007700">(</span><span style="color: #0000BB">$product</span><span style="color: #007700">)<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;isset(</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">products</span><span style="color: #007700">[</span><span style="color: #0000BB">$product</span><span style="color: #007700">])&nbsp;?&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">products</span><span style="color: #007700">[</span><span style="color: #0000BB">$product</span><span style="color: #007700">]&nbsp;:<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">FALSE</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;&nbsp;&nbsp;&nbsp;<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">getTotal</span><span style="color: #007700">(</span><span style="color: #0000BB">$tax</span><span style="color: #007700">)<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$total&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">0.00</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$callback&nbsp;</span><span style="color: #007700">=<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;function&nbsp;(</span><span style="color: #0000BB">$quantity</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$product</span><span style="color: #007700">)&nbsp;use&nbsp;(</span><span style="color: #0000BB">$tax</span><span style="color: #007700">,&nbsp;&amp;</span><span style="color: #0000BB">$total</span><span style="color: #007700">)<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$pricePerItem&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">constant</span><span style="color: #007700">(</span><span style="color: #0000BB">__CLASS__&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">"::PRICE_"&nbsp;</span><span style="color: #007700">.<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">strtoupper</span><span style="color: #007700">(</span><span style="color: #0000BB">$product</span><span style="color: #007700">));<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$total&nbsp;</span><span style="color: #007700">+=&nbsp;(</span><span style="color: #0000BB">$pricePerItem&nbsp;</span><span style="color: #007700">*&nbsp;</span><span style="color: #0000BB">$quantity</span><span style="color: #007700">)&nbsp;*&nbsp;(</span><span style="color: #0000BB">$tax&nbsp;</span><span style="color: #007700">+&nbsp;</span><span style="color: #0000BB">1.0</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;};<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">array_walk</span><span style="color: #007700">(</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">products</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$callback</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">round</span><span style="color: #007700">(</span><span style="color: #0000BB">$total</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br /></span><span style="color: #0000BB">$my_cart&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">Cart</span><span style="color: #007700">;<br /><br /></span><span style="color: #FF8000">//&nbsp;Add&nbsp;some&nbsp;items&nbsp;to&nbsp;the&nbsp;cart<br /></span><span style="color: #0000BB">$my_cart</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">add</span><span style="color: #007700">(</span><span style="color: #DD0000">'butter'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">$my_cart</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">add</span><span style="color: #007700">(</span><span style="color: #DD0000">'milk'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">3</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">$my_cart</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">add</span><span style="color: #007700">(</span><span style="color: #DD0000">'eggs'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">6</span><span style="color: #007700">);<br /><br /></span><span style="color: #FF8000">//&nbsp;Print&nbsp;the&nbsp;total&nbsp;with&nbsp;a&nbsp;5%&nbsp;sales&nbsp;tax.<br /></span><span style="color: #007700">print&nbsp;</span><span style="color: #0000BB">$my_cart</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">getTotal</span><span style="color: #007700">(</span><span style="color: #0000BB">0.05</span><span style="color: #007700">)&nbsp;.&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br /></span><span style="color: #FF8000">//&nbsp;The&nbsp;result&nbsp;is&nbsp;54.29<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>

   <div class="example" id="example-167">
    <p><strong>Example #5 Automatic binding of <em>$this</em></strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /><br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">Test<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">testing</span><span style="color: #007700">()<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;function()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$this</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;};<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br /></span><span style="color: #0000BB">$object&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">Test</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$function&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$object</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">testing</span><span style="color: #007700">();<br /></span><span style="color: #0000BB">$function</span><span style="color: #007700">();<br />&nbsp;&nbsp;&nbsp;&nbsp;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

    <div class="example-contents"><p>The above example will output:</p></div>
    <div class="example-contents screen">
<div class="cdata"><pre>
object(Test)#1 (0) {
}
</pre></div>
    </div>
    <div class="example-contents"><p>Output of the above example in PHP 5.3:</p></div>
    <div class="example-contents screen">
<div class="cdata"><pre>
Notice: Undefined variable: this in script.php on line 8
NULL</pre></div>
    </div>
   </div>

   <p class="para">
    As of PHP 5.4.0, when declared in the context of a class, the current class is
    automatically bound to it, making <em>$this</em> available
    inside of the function&#039;s scope. If this automatic binding of the current
    class is not wanted, then
    <a href="functions.anonymous.php#functions.anonymous-functions.static" class="link">static anonymous
    functions</a> may be used instead.
   </p>

   <div class="sect2" id="functions.anonymous-functions.static">
    <h3 class="title">Static anonymous functions</h3>
    <p class="para">
     As of PHP 5.4, anonymous functions may be declared statically. This
     prevents them from having the current class automatically bound to
     them. Objects may also not be bound to them at runtime.
    </p>
    <p class="para">
     <div class="example" id="example-168">
      <p><strong>Example #6 Attempting to use <em>$this</em> inside a static anonymous function</strong></p>
      <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /><br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">Foo<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;function&nbsp;</span><span style="color: #0000BB">__construct</span><span style="color: #007700">()<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$func&nbsp;</span><span style="color: #007700">=&nbsp;static&nbsp;function()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$this</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;};<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$func</span><span style="color: #007700">();<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />};<br />new&nbsp;</span><span style="color: #0000BB">Foo</span><span style="color: #007700">();<br /><br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
      </div>

      <div class="example-contents"><p>The above example will output:</p></div>
      <div class="example-contents screen">
<div class="cdata"><pre>
Notice: Undefined variable: this in %s on line %d
NULL
</pre></div>
      </div>
     </div>
    </p>

    <p class="para">
     <div class="example" id="example-169">
      <p><strong>Example #7 Attempting to bind an object to a static anonymous function</strong></p>
      <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /><br />$func&nbsp;</span><span style="color: #007700">=&nbsp;static&nbsp;function()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;function&nbsp;body<br /></span><span style="color: #007700">};<br /></span><span style="color: #0000BB">$func&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$func</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">bindTo</span><span style="color: #007700">(new&nbsp;</span><span style="color: #0000BB">StdClass</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">$func</span><span style="color: #007700">();<br /><br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
      </div>

      <div class="example-contents"><p>The above example will output:</p></div>
      <div class="example-contents screen">
<div class="cdata"><pre>
Warning: Cannot bind an instance to a static closure in %s on line %d
</pre></div>
      </div>
     </div>
    </p>
   </div>
   
   <div class="sect2">
    <h3 class="title">Changelog</h3>
    <p class="para">
     <table class="doctable informaltable">
      
       <thead>
        <tr>
         <th>Version</th>
         <th>Description</th>
        </tr>

       </thead>

       <tbody class="tbody">
        <tr>
         <td>7.1.0</td>
         <td>
          Anonymous functions may not close over <a href="language.variables.predefined.php" class="link">superglobals</a>,
          <var class="varname"><var class="varname">$this</var></var>, or any variable with the same name as a
          parameter.
         </td>
        </tr>

        <tr>
         <td>5.4.0</td>
         <td>
          Anonymous functions may use <var class="varname"><var class="varname">$this</var></var>, as well as be
          declared statically.
         </td>
        </tr>

        <tr>
         <td>5.3.0</td>
         <td>
          Anonymous functions become available.
         </td>
        </tr>

       </tbody>
      
     </table>

    </p>
   </div>

   <div class="sect2">
    <h3 class="title">Notes</h3>
    <blockquote class="note"><p><strong class="note">Note</strong>: 
     <span class="simpara">
      It is possible to use <span class="function"><a href="function.func-num-args.php" class="function">func_num_args()</a></span>,
      <span class="function"><a href="function.func-get-arg.php" class="function">func_get_arg()</a></span>, and <span class="function"><a href="function.func-get-args.php" class="function">func_get_args()</a></span>
      from within a closure.
     </span>
    </p></blockquote>
   </div>

  </div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=functions.anonymous&amp;redirect=http://php.net/manual/en/functions.anonymous.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">49 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="99287">  <div class="votes">
    <div id="Vu99287">
    <a href="/manual/vote-note.php?id=99287&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd99287">
    <a href="/manual/vote-note.php?id=99287&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V99287" title="82% like this...">
    217
    </div>
  </div>
  <a href="#99287" class="name">
  <strong class="user"><em>orls</em></strong></a><a class="genanchor" href="#99287"> &para;</a><div class="date" title="2010-08-08 06:53"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom99287">
<div class="phpcode"><code><span class="html">
Watch out when 'importing' variables to a closure's scope&nbsp; -- it's easy to miss / forget that they are actually being *copied* into the closure's scope, rather than just being made available.<br /><br />So you will need to explicitly pass them in by reference if your closure cares about their contents over time:<br /><br /><span class="default">&lt;?php<br />$result </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br /><br /></span><span class="default">$one </span><span class="keyword">= function()<br />{ </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$result</span><span class="keyword">); };<br /><br /></span><span class="default">$two </span><span class="keyword">= function() use (</span><span class="default">$result</span><span class="keyword">)<br />{ </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$result</span><span class="keyword">); };<br /><br /></span><span class="default">$three </span><span class="keyword">= function() use (&amp;</span><span class="default">$result</span><span class="keyword">)<br />{ </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$result</span><span class="keyword">); };<br /><br /></span><span class="default">$result</span><span class="keyword">++;<br /><br /></span><span class="default">$one</span><span class="keyword">();&nbsp; &nbsp; </span><span class="comment">// outputs NULL: $result is not in scope<br /></span><span class="default">$two</span><span class="keyword">();&nbsp; &nbsp; </span><span class="comment">// outputs int(0): $result was copied<br /></span><span class="default">$three</span><span class="keyword">();&nbsp; &nbsp; </span><span class="comment">// outputs int(1)<br /></span><span class="default">?&gt;<br /></span><br />Another less trivial example with objects (what I actually tripped up on):<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">//set up variable in advance<br /></span><span class="default">$myInstance </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br /><br /></span><span class="default">$broken </span><span class="keyword">= function() </span><span class="default">uses </span><span class="keyword">(</span><span class="default">$myInstance</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; if(!empty(</span><span class="default">$myInstance</span><span class="keyword">)) </span><span class="default">$myInstance</span><span class="keyword">-&gt;</span><span class="default">doSomething</span><span class="keyword">();<br />};<br /><br /></span><span class="default">$working </span><span class="keyword">= function() </span><span class="default">uses </span><span class="keyword">(&amp;</span><span class="default">$myInstance</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; if(!empty(</span><span class="default">$myInstance</span><span class="keyword">)) </span><span class="default">$myInstance</span><span class="keyword">-&gt;</span><span class="default">doSomething</span><span class="keyword">();<br />}<br /><br /></span><span class="comment">//$myInstance might be instantiated, might not be<br /></span><span class="keyword">if(</span><span class="default">SomeBusinessLogic</span><span class="keyword">::</span><span class="default">worked</span><span class="keyword">() == </span><span class="default">true</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="default">$myInstance </span><span class="keyword">= new </span><span class="default">myClass</span><span class="keyword">();<br />}<br /><br /></span><span class="default">$broken</span><span class="keyword">();&nbsp; &nbsp; </span><span class="comment">// will never do anything: $myInstance will ALWAYS be null inside this closure.<br /></span><span class="default">$working</span><span class="keyword">();&nbsp; &nbsp; </span><span class="comment">// will call doSomething if $myInstance is instantiated<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="94313">  <div class="votes">
    <div id="Vu94313">
    <a href="/manual/vote-note.php?id=94313&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd94313">
    <a href="/manual/vote-note.php?id=94313&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V94313" title="84% like this...">
    81
    </div>
  </div>
  <a href="#94313" class="name">
  <strong class="user"><em>mike at blueroot dot co dot uk</em></strong></a><a class="genanchor" href="#94313"> &para;</a><div class="date" title="2009-10-28 08:40"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom94313">
<div class="phpcode"><code><span class="html">
To recursively call a closure, use this code.<br /><br /><span class="default">&lt;?php<br />$recursive </span><span class="keyword">= function () use (&amp;</span><span class="default">$recursive</span><span class="keyword">){<br />&nbsp; &nbsp; </span><span class="comment">// The function is now available as $recursive<br /></span><span class="keyword">}<br /></span><span class="default">?&gt;<br /></span><br />This DOES NOT WORK<br /><br /><span class="default">&lt;?php<br />$recursive </span><span class="keyword">= function () use (</span><span class="default">$recursive</span><span class="keyword">){<br />&nbsp; &nbsp; </span><span class="comment">// The function is now available as $recursive<br /></span><span class="keyword">}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120611">  <div class="votes">
    <div id="Vu120611">
    <a href="/manual/vote-note.php?id=120611&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120611">
    <a href="/manual/vote-note.php?id=120611&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120611" title="90% like this...">
    8
    </div>
  </div>
  <a href="#120611" class="name">
  <strong class="user"><em>john at binkmail dot com</em></strong></a><a class="genanchor" href="#120611"> &para;</a><div class="date" title="2017-02-07 07:36"><strong>10 months ago</strong></div>
  <div class="text" id="Hcom120611">
<div class="phpcode"><code><span class="html">
PERFORMANCE BENCHMARK 2017!<br /><br />I decided to compare a single, saved closure against constantly creating the same anonymous closure on every loop iteration. And I tried 10 million loop iterations, in PHP 7.0.14 from Dec 2016. Result:<br /><br />a single saved closure kept in a variable and re-used (10000000 iterations): 1.3874590396881 seconds<br /><br />new anonymous closure created each time (10000000 iterations): 2.8460240364075 seconds<br /><br />In other words, over the course of 10 million iterations, creating the closure again during every iteration only added a total of "1.459 seconds" to the runtime. So that means that every creation of a new anonymous closure takes about 146 nanoseconds on my 7 years old dual-core laptop. I guess PHP keeps a cached "template" for the anonymous function and therefore doesn't need much time to create a new instance of the closure!<br /><br />So you do NOT have to worry about constantly re-creating your anonymous closures over and over again in tight loops! At least not as of PHP 7! There is absolutely NO need to save an instance in a variable and re-use it. And not being restricted by that is a great thing, because it means you can feel free to use anonymous functions exactly where they matter, as opposed to defining them somewhere else in the code. :-)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="102615">  <div class="votes">
    <div id="Vu102615">
    <a href="/manual/vote-note.php?id=102615&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd102615">
    <a href="/manual/vote-note.php?id=102615&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V102615" title="79% like this...">
    53
    </div>
  </div>
  <a href="#102615" class="name">
  <strong class="user"><em>fabiolimasouto at gmail dot com</em></strong></a><a class="genanchor" href="#102615"> &para;</a><div class="date" title="2011-02-24 07:51"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom102615">
<div class="phpcode"><code><span class="html">
You may have been disapointed if you tried to call a closure stored in an instance variable as you would regularly do with methods:<br /><br /><span class="default">&lt;?php<br /><br />$obj </span><span class="keyword">= new </span><span class="default">StdClass</span><span class="keyword">();<br /><br /></span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">func </span><span class="keyword">= function(){<br /> echo </span><span class="string">"hello"</span><span class="keyword">;<br />};<br /><br /></span><span class="comment">//$obj-&gt;func(); // doesn't work! php tries to match an instance method called "func" that is not defined in the original class' signature<br /><br />// you have to do this instead:<br /></span><span class="default">$func </span><span class="keyword">= </span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">func</span><span class="keyword">;<br /></span><span class="default">$func</span><span class="keyword">();<br /><br /></span><span class="comment">// or:<br /></span><span class="default">call_user_func</span><span class="keyword">(</span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">func</span><span class="keyword">);<br /><br /></span><span class="comment">// however, you might wanna check this out:<br /></span><span class="default">$array</span><span class="keyword">[</span><span class="string">'func'</span><span class="keyword">] = function(){<br /> echo </span><span class="string">"hello"</span><span class="keyword">;<br />};<br /><br /></span><span class="default">$array</span><span class="keyword">[</span><span class="string">'func'</span><span class="keyword">](); </span><span class="comment">// it works! i discovered that just recently ;)<br /></span><span class="default">?&gt;<br /></span><br />Now, coming back to the problem of assigning functions/methods "on the fly" to an object and being able to call them as if they were regular methods, you could trick php with this lawbreaker-code:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">test</span><span class="keyword">{<br /> private </span><span class="default">$functions </span><span class="keyword">= array();<br /> private </span><span class="default">$vars </span><span class="keyword">= array();<br /> <br /> function </span><span class="default">__set</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">,</span><span class="default">$data</span><span class="keyword">)<br /> {<br />&nbsp; if(</span><span class="default">is_callable</span><span class="keyword">(</span><span class="default">$data</span><span class="keyword">))<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">functions</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">] = </span><span class="default">$data</span><span class="keyword">;<br />&nbsp; else<br />&nbsp;&nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">vars</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">] = </span><span class="default">$data</span><span class="keyword">;<br /> }<br /> <br /> function </span><span class="default">__get</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">)<br /> {<br />&nbsp; if(isset(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">vars</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">]))<br />&nbsp;&nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">vars</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">];<br /> }<br /> <br /> function </span><span class="default">__call</span><span class="keyword">(</span><span class="default">$method</span><span class="keyword">,</span><span class="default">$args</span><span class="keyword">)<br /> {<br />&nbsp; if(isset(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">functions</span><span class="keyword">[</span><span class="default">$method</span><span class="keyword">]))<br />&nbsp; {<br />&nbsp;&nbsp; </span><span class="default">call_user_func_array</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">functions</span><span class="keyword">[</span><span class="default">$method</span><span class="keyword">],</span><span class="default">$args</span><span class="keyword">);<br />&nbsp; } else {<br />&nbsp;&nbsp; </span><span class="comment">// error out<br />&nbsp; </span><span class="keyword">}<br /> }<br />}<br /><br /></span><span class="comment">// LET'S BREAK SOME LAW NOW!<br /></span><span class="default">$obj </span><span class="keyword">= new </span><span class="default">test</span><span class="keyword">;<br /><br /></span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">sayHelloWithMyName </span><span class="keyword">= function(</span><span class="default">$name</span><span class="keyword">){<br /> echo </span><span class="string">"Hello </span><span class="default">$name</span><span class="string">!"</span><span class="keyword">;<br />};<br /><br /></span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">sayHelloWithMyName</span><span class="keyword">(</span><span class="string">'Fabio'</span><span class="keyword">); </span><span class="comment">// Hello Fabio!<br /><br />// THE OLD WAY (NON-CLOSURE) ALSO WORKS:<br /><br /></span><span class="keyword">function </span><span class="default">sayHello</span><span class="keyword">()<br />{<br /> echo </span><span class="string">"Hello!"</span><span class="keyword">;<br />}<br /><br /></span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">justSayHello </span><span class="keyword">= </span><span class="string">'sayHello'</span><span class="keyword">;<br /></span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">justSayHello</span><span class="keyword">(); </span><span class="comment">// Hello!<br /></span><span class="default">?&gt;<br /></span><br />NOTICE: of course this is very bad practice since you cannot refere to protected or private fields/methods inside these pseudo "methods" as they are not instance methods at all but rather ordinary functions/closures assigned to the object's instance variables "on the fly". But I hope you've enjoyed the jurney ;)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113896">  <div class="votes">
    <div id="Vu113896">
    <a href="/manual/vote-note.php?id=113896&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113896">
    <a href="/manual/vote-note.php?id=113896&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113896" title="84% like this...">
    18
    </div>
  </div>
  <a href="#113896" class="name">
  <strong class="user"><em>cHao</em></strong></a><a class="genanchor" href="#113896"> &para;</a><div class="date" title="2013-12-13 11:42"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113896">
<div class="phpcode"><code><span class="html">
In case you were wondering (cause i was), anonymous functions can return references just like named functions can.&nbsp; Simply use the &amp; the same way you would for a named function...right after the `function` keyword (and right before the nonexistent name).<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; $value </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$fn </span><span class="keyword">= function &amp;() use (&amp;</span><span class="default">$value</span><span class="keyword">) { return </span><span class="default">$value</span><span class="keyword">; };<br /><br />&nbsp; &nbsp; </span><span class="default">$x </span><span class="keyword">=&amp; </span><span class="default">$fn</span><span class="keyword">();<br />&nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$x</span><span class="keyword">, </span><span class="default">$value</span><span class="keyword">);&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// 'int(0)', 'int(0)'<br />&nbsp; &nbsp; </span><span class="keyword">++</span><span class="default">$x</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$x</span><span class="keyword">, </span><span class="default">$value</span><span class="keyword">);&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// 'int(1)', 'int(1)'</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="94804">  <div class="votes">
    <div id="Vu94804">
    <a href="/manual/vote-note.php?id=94804&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd94804">
    <a href="/manual/vote-note.php?id=94804&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V94804" title="83% like this...">
    4
    </div>
  </div>
  <a href="#94804" class="name">
  <strong class="user"><em>rob at ubrio dot us</em></strong></a><a class="genanchor" href="#94804"> &para;</a><div class="date" title="2009-11-25 10:20"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom94804">
<div class="phpcode"><code><span class="html">
You can always call protected members using the __call() method - similar to how you hack around this in Ruby using send.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">Fun<br /></span><span class="keyword">{<br /> protected function </span><span class="default">debug</span><span class="keyword">(</span><span class="default">$message</span><span class="keyword">)<br /> {<br />&nbsp;&nbsp; echo </span><span class="string">"DEBUG: </span><span class="default">$message</span><span class="string">\n"</span><span class="keyword">;<br /> }<br /><br /> public function </span><span class="default">yield_something</span><span class="keyword">(</span><span class="default">$callback</span><span class="keyword">)<br /> {<br />&nbsp;&nbsp; return </span><span class="default">$callback</span><span class="keyword">(</span><span class="string">"Soemthing!!"</span><span class="keyword">);<br /> }<br /><br /> public function </span><span class="default">having_fun</span><span class="keyword">()<br /> {<br />&nbsp;&nbsp; </span><span class="default">$self </span><span class="keyword">=&amp; </span><span class="default">$this</span><span class="keyword">;<br />&nbsp;&nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">yield_something</span><span class="keyword">(function(</span><span class="default">$data</span><span class="keyword">) use (&amp;</span><span class="default">$self</span><span class="keyword">)<br />&nbsp;&nbsp; {<br />&nbsp; &nbsp;&nbsp; </span><span class="default">$self</span><span class="keyword">-&gt;</span><span class="default">debug</span><span class="keyword">(</span><span class="string">"Doing stuff to the data"</span><span class="keyword">);<br />&nbsp; &nbsp;&nbsp; </span><span class="comment">// do something with $data<br />&nbsp; &nbsp;&nbsp; </span><span class="default">$self</span><span class="keyword">-&gt;</span><span class="default">debug</span><span class="keyword">(</span><span class="string">"Finished doing stuff with the data."</span><span class="keyword">);<br />&nbsp;&nbsp; });<br /> }<br /><br /> </span><span class="comment">// Ah-Ha!<br /> </span><span class="keyword">public function </span><span class="default">__call</span><span class="keyword">(</span><span class="default">$method</span><span class="keyword">, </span><span class="default">$args </span><span class="keyword">= array())<br /> {<br />&nbsp;&nbsp; if(</span><span class="default">is_callable</span><span class="keyword">(array(</span><span class="default">$this</span><span class="keyword">, </span><span class="default">$method</span><span class="keyword">)))<br />&nbsp; &nbsp;&nbsp; return </span><span class="default">call_user_func_array</span><span class="keyword">(array(</span><span class="default">$this</span><span class="keyword">, </span><span class="default">$method</span><span class="keyword">), </span><span class="default">$args</span><span class="keyword">);<br /> }<br />}<br /><br /></span><span class="default">$fun </span><span class="keyword">= new </span><span class="default">Fun</span><span class="keyword">();<br />echo </span><span class="default">$fun</span><span class="keyword">-&gt;</span><span class="default">having_fun</span><span class="keyword">();<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117504">  <div class="votes">
    <div id="Vu117504">
    <a href="/manual/vote-note.php?id=117504&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117504">
    <a href="/manual/vote-note.php?id=117504&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117504" title="77% like this...">
    15
    </div>
  </div>
  <a href="#117504" class="name">
  <strong class="user"><em>erolmon dot kskn at gmail dot com</em></strong></a><a class="genanchor" href="#117504"> &para;</a><div class="date" title="2015-06-19 09:48"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117504">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="comment">/*<br />&nbsp; &nbsp; (string) $name Name of the function that you will add to class.<br />&nbsp; &nbsp; Usage : $Foo-&gt;add(function(){},$name);<br />&nbsp; &nbsp; This will add a public function in Foo Class.<br />&nbsp; &nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">class </span><span class="default">Foo<br />&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; public function </span><span class="default">add</span><span class="keyword">(</span><span class="default">$func</span><span class="keyword">,</span><span class="default">$name</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;{</span><span class="default">$name</span><span class="keyword">} = </span><span class="default">$func</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; public function </span><span class="default">__call</span><span class="keyword">(</span><span class="default">$func</span><span class="keyword">,</span><span class="default">$arguments</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">call_user_func_array</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;{</span><span class="default">$func</span><span class="keyword">}, </span><span class="default">$arguments</span><span class="keyword">); <br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; </span><span class="default">$Foo </span><span class="keyword">= new </span><span class="default">Foo</span><span class="keyword">();<br />&nbsp; &nbsp; </span><span class="default">$Foo</span><span class="keyword">-&gt;</span><span class="default">add</span><span class="keyword">(function(){<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Hello World"</span><span class="keyword">;<br />&nbsp; &nbsp; },</span><span class="string">"helloWorldFunction"</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$Foo</span><span class="keyword">-&gt;</span><span class="default">add</span><span class="keyword">(function(</span><span class="default">$parameterone</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">$parameterone</span><span class="keyword">;<br />&nbsp; &nbsp; },</span><span class="string">"exampleFunction"</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$Foo</span><span class="keyword">-&gt;</span><span class="default">helloWorldFunction</span><span class="keyword">(); </span><span class="comment">/*Output : Hello World*/<br />&nbsp; &nbsp; </span><span class="default">$Foo</span><span class="keyword">-&gt;</span><span class="default">exampleFunction</span><span class="keyword">(</span><span class="string">"Hello PHP"</span><span class="keyword">); </span><span class="comment">/*Output : Hello PHP*/<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="91610">  <div class="votes">
    <div id="Vu91610">
    <a href="/manual/vote-note.php?id=91610&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd91610">
    <a href="/manual/vote-note.php?id=91610&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V91610" title="77% like this...">
    10
    </div>
  </div>
  <a href="#91610" class="name">
  <strong class="user"><em>a dot schaffhirt at sedna-soft dot de</em></strong></a><a class="genanchor" href="#91610"> &para;</a><div class="date" title="2009-06-19 02:55"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom91610">
<div class="phpcode"><code><span class="html">
When using anonymous functions as properties in Classes, note that there are three name scopes: one for constants, one for properties and one for methods. That means, you can use the same name for a constant, for a property and for a method at a time.<br /><br />Since a property can be also an anonymous function as of PHP 5.3.0, an oddity arises when they share the same name, not meaning that there would be any conflict.<br /><br />Consider the following example:<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">class </span><span class="default">MyClass </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; const </span><span class="default">member </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; public </span><span class="default">$member</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; public function </span><span class="default">member </span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">"method 'member'"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; public function </span><span class="default">__construct </span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">member </span><span class="keyword">= function () {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">"anonymous function 'member'"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; };<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">"Content-Type: text/plain"</span><span class="keyword">);<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="default">$myObj </span><span class="keyword">= new </span><span class="default">MyClass</span><span class="keyword">();<br /><br />&nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">MyClass</span><span class="keyword">::</span><span class="default">member</span><span class="keyword">);&nbsp; </span><span class="comment">// int(1)<br />&nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$myObj</span><span class="keyword">-&gt;</span><span class="default">member</span><span class="keyword">);&nbsp;&nbsp; </span><span class="comment">// object(Closure)#2 (0) {}<br />&nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$myObj</span><span class="keyword">-&gt;</span><span class="default">member</span><span class="keyword">()); </span><span class="comment">// string(15) "method 'member'"<br />&nbsp; &nbsp; </span><span class="default">$myMember </span><span class="keyword">= </span><span class="default">$myObj</span><span class="keyword">-&gt;</span><span class="default">member</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$myMember</span><span class="keyword">());&nbsp; &nbsp; &nbsp; </span><span class="comment">// string(27) "anonymous function 'member'"<br /></span><span class="default">?&gt;<br /></span><br />That means, regular method invocations work like expected and like before. The anonymous function instead, must be retrieved into a variable first (just like a property) and can only then be invoked.<br /><br />Best regards,</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119902">  <div class="votes">
    <div id="Vu119902">
    <a href="/manual/vote-note.php?id=119902&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119902">
    <a href="/manual/vote-note.php?id=119902&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119902" title="75% like this...">
    6
    </div>
  </div>
  <a href="#119902" class="name">
  <strong class="user"><em>ohcc at 163 dot com</em></strong></a><a class="genanchor" href="#119902"> &para;</a><div class="date" title="2016-09-17 10:36"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119902">
<div class="phpcode"><code><span class="html">
Supported by PHP 7.0+ only.<br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">(function(</span><span class="default">$name</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'My name is ' </span><span class="keyword">. </span><span class="default">$name</span><span class="keyword">;<br />&nbsp; &nbsp; })(</span><span class="string">'Wu Xiancheng'</span><span class="keyword">);<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="96755">  <div class="votes">
    <div id="Vu96755">
    <a href="/manual/vote-note.php?id=96755&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd96755">
    <a href="/manual/vote-note.php?id=96755&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V96755" title="75% like this...">
    10
    </div>
  </div>
  <a href="#96755" class="name">
  <strong class="user"><em>housni dot yakoob at gmail dot com</em></strong></a><a class="genanchor" href="#96755"> &para;</a><div class="date" title="2010-03-14 09:22"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom96755">
<div class="phpcode"><code><span class="html">
If you want to make sure that one of the parameters of your function is a Closure, you can use Type Hinting.<br />see: <a href="http://php.net/manual/en/language.oop5.typehinting.php" rel="nofollow" target="_blank">http://php.net/manual/en/language.oop5.typehinting.php</a><br /><br />Example:<br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">TheRoot<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">poidh</span><span class="keyword">(</span><span class="default">$param</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"TheRoot </span><span class="default">$param</span><span class="string">!"</span><span class="keyword">;<br />&nbsp; &nbsp; }&nbsp;&nbsp; <br /><br />}<br /><br />class </span><span class="default">Internet<br /></span><span class="keyword">{<br />&nbsp; &nbsp; </span><span class="comment"># here, $my_closure must be of type object Closure<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">run_my_closure</span><span class="keyword">(</span><span class="default">$bar</span><span class="keyword">, </span><span class="default">Closure $my_closure</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$my_closure</span><span class="keyword">(</span><span class="default">$bar</span><span class="keyword">);<br />&nbsp; &nbsp; }&nbsp;&nbsp; <br />}<br /><br /></span><span class="default">$Internet </span><span class="keyword">= new </span><span class="default">Internet</span><span class="keyword">();<br /></span><span class="default">$Root </span><span class="keyword">= new </span><span class="default">TheRoot</span><span class="keyword">();<br /><br /></span><span class="default">$Internet</span><span class="keyword">-&gt;</span><span class="default">run_my_closure</span><span class="keyword">(</span><span class="default">$Root</span><span class="keyword">, function(</span><span class="default">$Object</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$Object</span><span class="keyword">-&gt;</span><span class="default">poidh</span><span class="keyword">(</span><span class="default">42</span><span class="keyword">);<br />});<br /><br /></span><span class="default">?&gt;<br /></span>The above code simply yields:<br />"TheRoot 42!"<br /><br />NOTE: If you are using namespaces, make sure you give a fully qualified namespace.<br /><br />print_r() of Internet::run_my_closure's $my_closure<br /><span class="default">&lt;?php<br />Closure Object<br /></span><span class="keyword">(<br />&nbsp; &nbsp; [</span><span class="default">parameter</span><span class="keyword">] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [</span><span class="default">$Object</span><span class="keyword">] =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />)<br /></span><span class="default">?&gt;<br /></span><br />var_dump() of Internet::run_my_closure's $my_closure<br /><span class="default">&lt;?php<br />object</span><span class="keyword">(</span><span class="default">Closure</span><span class="keyword">)</span><span class="comment">#3 (1) {<br />&nbsp; </span><span class="keyword">[</span><span class="string">"parameter"</span><span class="keyword">]=&gt;<br />&nbsp; array(</span><span class="default">1</span><span class="keyword">) {<br />&nbsp; &nbsp; [</span><span class="string">"</span><span class="default">$Object</span><span class="string">"</span><span class="keyword">]=&gt;<br />&nbsp; &nbsp; </span><span class="default">string</span><span class="keyword">(</span><span class="default">10</span><span class="keyword">) </span><span class="string">""<br />&nbsp; </span><span class="keyword">}<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119388">  <div class="votes">
    <div id="Vu119388">
    <a href="/manual/vote-note.php?id=119388&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119388">
    <a href="/manual/vote-note.php?id=119388&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119388" title="72% like this...">
    5
    </div>
  </div>
  <a href="#119388" class="name">
  <strong class="user"><em>jigar</em></strong></a><a class="genanchor" href="#119388"> &para;</a><div class="date" title="2016-05-25 07:46"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119388">
<div class="phpcode"><code><span class="html">
Will result in a "Parse error: syntax error, unexpected '[', expecting ',' or ')' ... "<br /><br /><span class="default">&lt;?php<br /><br />$fruits </span><span class="keyword">= [</span><span class="string">'apples'</span><span class="keyword">, </span><span class="string">'oranges'</span><span class="keyword">];<br /></span><span class="default">$example </span><span class="keyword">= function () use (</span><span class="default">$fruits</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]) {<br />&nbsp; &nbsp; echo </span><span class="default">$fruits</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]; <br />};<br /></span><span class="default">$example</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span><br />Would have to do this:<br /><br /><span class="default">&lt;?php<br /><br />$fruits </span><span class="keyword">= [</span><span class="string">'apples'</span><span class="keyword">, </span><span class="string">'oranges'</span><span class="keyword">];<br /></span><span class="default">$example </span><span class="keyword">= function () use (</span><span class="default">$fruits</span><span class="keyword">) {<br />&nbsp; &nbsp; echo </span><span class="default">$fruits</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]; </span><span class="comment">// will echo 'apples'<br /></span><span class="keyword">};<br /></span><span class="default">$example</span><span class="keyword">();<br /><br /></span><span class="default">?&gt;<br /></span><br />Or this instead:<br /><br /><span class="default">&lt;?php<br /><br />$fruits </span><span class="keyword">= [</span><span class="string">'apples'</span><span class="keyword">, </span><span class="string">'oranges'</span><span class="keyword">];<br /></span><span class="default">$fruit </span><span class="keyword">= </span><span class="default">$fruits</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">];<br /></span><span class="default">$example </span><span class="keyword">= function () use (</span><span class="default">$fruit</span><span class="keyword">) {<br />&nbsp; &nbsp; echo </span><span class="default">$fruit</span><span class="keyword">; </span><span class="comment">// will echo 'apples'<br /></span><span class="keyword">};<br /></span><span class="default">$example</span><span class="keyword">();</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="98978">  <div class="votes">
    <div id="Vu98978">
    <a href="/manual/vote-note.php?id=98978&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd98978">
    <a href="/manual/vote-note.php?id=98978&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V98978" title="75% like this...">
    4
    </div>
  </div>
  <a href="#98978" class="name">
  <strong class="user"><em>gabriel dot totoliciu at ddsec dot net</em></strong></a><a class="genanchor" href="#98978"> &para;</a><div class="date" title="2010-07-19 10:56"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom98978">
<div class="phpcode"><code><span class="html">
If you want to make a recursive closure, you will need to write this:<br /><br />$some_var1="1";<br />$some_var2="2";<br /><br />function($param1, $param2) use ($some_var1, $some_var2)<br />{<br /><br />//some code here<br /><br />call_user_func(__FUNCTION__, $other_param1, $other_param2);<br /><br />//some code here<br /><br />}<br /><br />If you need to pass values by reference you should check out<br /><br /><a href="http://www.php.net/manual/en/function.call-user-func.php" rel="nofollow" target="_blank">http://www.php.net/manual/en/function.call-user-func.php</a><br /><a href="http://www.php.net/manual/en/function.call-user-func-array.php" rel="nofollow" target="_blank">http://www.php.net/manual/en/function.call-user-func-array.php</a><br /><br />If you're wondering if $some_var1 and $some_var2 are still visible by using the call_user_func, yes, they are available.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="100545">  <div class="votes">
    <div id="Vu100545">
    <a href="/manual/vote-note.php?id=100545&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd100545">
    <a href="/manual/vote-note.php?id=100545&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V100545" title="72% like this...">
    8
    </div>
  </div>
  <a href="#100545" class="name">
  <strong class="user"><em>Hayley Watson</em></strong></a><a class="genanchor" href="#100545"> &para;</a><div class="date" title="2010-10-22 07:00"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom100545">
<div class="phpcode"><code><span class="html">
As an alternative to gabriel's recursive construction, you may instead assign the recursive function to a variable, and use it by reference, thus:<br /><br /><span class="default">&lt;?php<br />$fib </span><span class="keyword">= function(</span><span class="default">$n</span><span class="keyword">)use(&amp;</span><span class="default">$fib</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; if(</span><span class="default">$n </span><span class="keyword">== </span><span class="default">0 </span><span class="keyword">|| </span><span class="default">$n </span><span class="keyword">== </span><span class="default">1</span><span class="keyword">) return </span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; return </span><span class="default">$fib</span><span class="keyword">(</span><span class="default">$n </span><span class="keyword">- </span><span class="default">1</span><span class="keyword">) + </span><span class="default">$fib</span><span class="keyword">(</span><span class="default">$n </span><span class="keyword">- </span><span class="default">2</span><span class="keyword">);<br />};<br /><br />echo </span><span class="default">$fib</span><span class="keyword">(</span><span class="default">10</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span>Hardly a sensible implementation of the Fibonacci sequence, but that's not the point! The point is that the variable needs to be used by reference, not value.<br /><br />Without the '&amp;', the anonymous function gets the value of $fib at the time the function is being created. But until the function has been created, $fib can't have it as a value! It's not until AFTER the function has been assigned to $fib that $fib can be used to call the function - but by then it's too late to pass its value to the function being created!<br /><br />Using a reference resolves the dilemma: when called, the anonymous function will use $fib's current value, which will be the anonymous function itself.<br /><br />At least, it will be if you don't reassign $fib to anything else between creating the function and calling it:<br /><br /><span class="default">&lt;?php<br />$fib </span><span class="keyword">= function(</span><span class="default">$n</span><span class="keyword">)use(&amp;</span><span class="default">$fib</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; if(</span><span class="default">$n </span><span class="keyword">== </span><span class="default">0 </span><span class="keyword">|| </span><span class="default">$n </span><span class="keyword">== </span><span class="default">1</span><span class="keyword">) return </span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; return </span><span class="default">$fib</span><span class="keyword">(</span><span class="default">$n </span><span class="keyword">- </span><span class="default">1</span><span class="keyword">) + </span><span class="default">$fib</span><span class="keyword">(</span><span class="default">$n </span><span class="keyword">- </span><span class="default">2</span><span class="keyword">);<br />};<br /><br /></span><span class="default">$lie </span><span class="keyword">= </span><span class="default">$fib</span><span class="keyword">;<br /><br /></span><span class="default">$fib </span><span class="keyword">= function(</span><span class="default">$n</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; return </span><span class="default">100</span><span class="keyword">;<br />};<br /><br />echo </span><span class="default">$lie</span><span class="keyword">(</span><span class="default">10</span><span class="keyword">); </span><span class="comment">// 200, because $fib(10 - 1) and $fib(10 - 2) both return 100.<br /></span><span class="default">?&gt;<br /></span><br />Of course, that's true of any variable: if you don't want its value to change, don't change its value.<br /><br />All the usual scoping rules for variables still apply: a local variable in a function is a different variable from another one with the same name in another function:<br /><br /><span class="default">&lt;?php<br />$fib </span><span class="keyword">= function(</span><span class="default">$n</span><span class="keyword">)use(&amp;</span><span class="default">$fib</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; if(</span><span class="default">$n </span><span class="keyword">== </span><span class="default">0 </span><span class="keyword">|| </span><span class="default">$n </span><span class="keyword">== </span><span class="default">1</span><span class="keyword">) return </span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; return </span><span class="default">$fib</span><span class="keyword">(</span><span class="default">$n </span><span class="keyword">- </span><span class="default">1</span><span class="keyword">) + </span><span class="default">$fib</span><span class="keyword">(</span><span class="default">$n </span><span class="keyword">- </span><span class="default">2</span><span class="keyword">);<br />};<br /><br /></span><span class="default">$bark </span><span class="keyword">= function(</span><span class="default">$f</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="default">$fib </span><span class="keyword">= </span><span class="string">'cake'</span><span class="keyword">;&nbsp; &nbsp; </span><span class="comment">// A totally different variable from the $fib above.<br />&nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">2 </span><span class="keyword">* </span><span class="default">$f</span><span class="keyword">(</span><span class="default">5</span><span class="keyword">);<br />};<br /><br />echo </span><span class="default">$bark</span><span class="keyword">(</span><span class="default">$fib</span><span class="keyword">); </span><span class="comment">// 16, twice the fifth Fibonacci number<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113637">  <div class="votes">
    <div id="Vu113637">
    <a href="/manual/vote-note.php?id=113637&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113637">
    <a href="/manual/vote-note.php?id=113637&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113637" title="68% like this...">
    7
    </div>
  </div>
  <a href="#113637" class="name">
  <strong class="user"><em>assarte dot draven at gmail dot com</em></strong></a><a class="genanchor" href="#113637"> &para;</a><div class="date" title="2013-11-08 08:51"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113637">
<div class="phpcode"><code><span class="html">
You cannot use closures as a class variable member in its declaration like this:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">foo<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$bar </span><span class="keyword">= function() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"baz"</span><span class="keyword">;<br />&nbsp; &nbsp; };<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />I don't know why but this will raise a<br />Parse error: syntax error, unexpected 'function' (T_FUNCTION)<br /><br />(used PHP 5.4)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="105261">  <div class="votes">
    <div id="Vu105261">
    <a href="/manual/vote-note.php?id=105261&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd105261">
    <a href="/manual/vote-note.php?id=105261&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V105261" title="68% like this...">
    6
    </div>
  </div>
  <a href="#105261" class="name">
  <strong class="user"><em>simon at generalflows dot com</em></strong></a><a class="genanchor" href="#105261"> &para;</a><div class="date" title="2011-08-05 08:23"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom105261">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br /><br /></span><span class="comment">/* <br /> * An example showing how to use closures to implement a Python-like decorator <br /> * pattern.<br /> *<br /> * My goal was that you should be able to decorate a function with any<br /> * other function, then call the decorated function directly: <br /> *<br /> * Define function:&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; $foo = function($a, $b, $c, ...) {...}<br /> * Define decorator:&nbsp; &nbsp; &nbsp; &nbsp; $decorator = function($func) {...}<br /> * Decorate it:&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; $foo = $decorator($foo)<br /> * Call it:&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; $foo($a, $b, $c, ...)<br /> *<br /> * This example show an authentication decorator for a service, using a simple<br /> * mock session and mock service. <br /> */<br /> <br /></span><span class="default">session_start</span><span class="keyword">();<br /><br /></span><span class="comment">/* <br /> * Define an example decorator. A decorator function should take the form:<br /> * $decorator = function($func) {<br /> *&nbsp; &nbsp;&nbsp; return function() use $func) {<br /> *&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; // Do something, then call the decorated function when needed:<br /> *&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; $args = func_get_args($func);<br /> *&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; call_user_func_array($func, $args);<br /> *&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; // Do something else.<br /> *&nbsp; &nbsp;&nbsp; };<br /> * };<br /> */<br /></span><span class="default">$authorise </span><span class="keyword">= function(</span><span class="default">$func</span><span class="keyword">) {<br />&nbsp; &nbsp; return function() use (</span><span class="default">$func</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'is_authorised'</span><span class="keyword">] == </span><span class="default">true</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$args </span><span class="keyword">= </span><span class="default">func_get_args</span><span class="keyword">(</span><span class="default">$func</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">call_user_func_array</span><span class="keyword">(</span><span class="default">$func</span><span class="keyword">, </span><span class="default">$args</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Access Denied"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; };<br />};<br /><br /></span><span class="comment">/* <br /> * Define a function to be decorated, in this example a mock service that<br /> * need to be authorised. <br /> */ <br /></span><span class="default">$service </span><span class="keyword">= function(</span><span class="default">$foo</span><span class="keyword">) {<br />&nbsp; &nbsp; echo </span><span class="string">"Service returns: </span><span class="default">$foo</span><span class="string">"</span><span class="keyword">;<br />};<br /><br /></span><span class="comment">/* <br /> * Decorate it. Ensure you replace the origin function reference with the<br /> * decorated function; ie just $authorise($service) won't work, so do<br /> * $service = $authorise($service)<br /> */<br /></span><span class="default">$service </span><span class="keyword">= </span><span class="default">$authorise</span><span class="keyword">(</span><span class="default">$service</span><span class="keyword">);<br /><br /></span><span class="comment">/* <br /> * Establish mock authorisation, call the service; should get <br /> * 'Service returns: test 1'. <br /> */<br /></span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'is_authorised'</span><span class="keyword">] = </span><span class="default">true</span><span class="keyword">;<br /></span><span class="default">$service</span><span class="keyword">(</span><span class="string">'test 1'</span><span class="keyword">);<br /><br /></span><span class="comment">/* <br /> * Remove mock authorisation, call the service; should get 'Access Denied'. <br /> */<br /></span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'is_authorised'</span><span class="keyword">] = </span><span class="default">false</span><span class="keyword">;<br /></span><span class="default">$service</span><span class="keyword">(</span><span class="string">'test 2'</span><span class="keyword">);<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118567">  <div class="votes">
    <div id="Vu118567">
    <a href="/manual/vote-note.php?id=118567&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118567">
    <a href="/manual/vote-note.php?id=118567&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118567" title="66% like this...">
    4
    </div>
  </div>
  <a href="#118567" class="name">
  <strong class="user"><em>varuninorbit at yahoo dot co dot in</em></strong></a><a class="genanchor" href="#118567"> &para;</a><div class="date" title="2015-12-29 07:29"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom118567">
<div class="phpcode"><code><span class="html">
Here is a simple example to use clousers<br /><span class="default">&lt;?php <br /><br /></span><span class="keyword">function </span><span class="default">add</span><span class="keyword">(</span><span class="default">$x</span><span class="keyword">,</span><span class="default">$y</span><span class="keyword">){<br />&nbsp; &nbsp; return </span><span class="default">$x</span><span class="keyword">+</span><span class="default">$y</span><span class="keyword">();&nbsp; &nbsp; <br />}<br /><br />echo </span><span class="default">add</span><span class="keyword">(</span><span class="default">3</span><span class="keyword">,function(){<br />&nbsp; &nbsp; return </span><span class="default">5</span><span class="keyword">;<br />});<br /><br /></span><span class="default">?&gt;<br /></span><br />prints 8</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114433">  <div class="votes">
    <div id="Vu114433">
    <a href="/manual/vote-note.php?id=114433&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114433">
    <a href="/manual/vote-note.php?id=114433&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114433" title="66% like this...">
    5
    </div>
  </div>
  <a href="#114433" class="name">
  <strong class="user"><em>mail at mkharitonov dot net</em></strong></a><a class="genanchor" href="#114433"> &para;</a><div class="date" title="2014-02-20 11:20"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114433">
<div class="phpcode"><code><span class="html">
Some comparisons of PHP and JavaScript closures.<br /><br />=== Example 1 (passing by value) ===<br />PHP code:<br /><span class="default">&lt;?php<br />$aaa </span><span class="keyword">= </span><span class="default">111</span><span class="keyword">;<br /></span><span class="default">$func </span><span class="keyword">= function() use(</span><span class="default">$aaa</span><span class="keyword">){ print </span><span class="default">$aaa</span><span class="keyword">; };<br /></span><span class="default">$aaa </span><span class="keyword">= </span><span class="default">222</span><span class="keyword">;<br /></span><span class="default">$func</span><span class="keyword">(); </span><span class="comment">// Outputs "111"<br /></span><span class="default">?&gt;<br /></span><br />Similar JavaScript code:<br />&lt;script type="text/javascript"&gt;<br />var aaa = 111;<br />var func = (function(aaa){ return function(){ alert(aaa); } })(aaa);<br />aaa = 222;<br />func(); // Outputs "111"<br />&lt;/script&gt;<br /><br />Be careful, following code is not similar to previous code:<br />&lt;script type="text/javascript"&gt;<br />var aaa = 111;<br />var bbb = aaa;<br />var func = function(){ alert(bbb); };<br />aaa = 222;<br />func(); // Outputs "111", but only while "bbb" is not changed after function declaration<br /><br />// And this technique is not working in loops:<br />var functions = [];<br />for (var i = 0; i &lt; 2; i++)<br />{<br />&nbsp; &nbsp; var i2 = i;<br />&nbsp; &nbsp; functions.push(function(){ alert(i2); });<br />}<br />functions[0](); // Outputs "1", wrong!<br />functions[1](); // Outputs "1", ok<br />&lt;/script&gt;<br /><br />=== Example 2 (passing by reference) ===<br />PHP code:<br /><span class="default">&lt;?php<br />$aaa </span><span class="keyword">= </span><span class="default">111</span><span class="keyword">;<br /></span><span class="default">$func </span><span class="keyword">= function() use(&amp;</span><span class="default">$aaa</span><span class="keyword">){ print </span><span class="default">$aaa</span><span class="keyword">; };<br /></span><span class="default">$aaa </span><span class="keyword">= </span><span class="default">222</span><span class="keyword">;<br /></span><span class="default">$func</span><span class="keyword">(); </span><span class="comment">// Outputs "222"<br /></span><span class="default">?&gt;<br /></span><br />Similar JavaScript code:<br />&lt;script type="text/javascript"&gt;<br />var aaa = 111;<br />var func = function(){ alert(aaa); };<br />aaa = 222; // Outputs "222"<br />func();<br />&lt;/script&gt;</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113422">  <div class="votes">
    <div id="Vu113422">
    <a href="/manual/vote-note.php?id=113422&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113422">
    <a href="/manual/vote-note.php?id=113422&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113422" title="66% like this...">
    3
    </div>
  </div>
  <a href="#113422" class="name">
  <strong class="user"><em>rmckay at webaware dot com dot au</em></strong></a><a class="genanchor" href="#113422"> &para;</a><div class="date" title="2013-10-08 11:10"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113422">
<div class="phpcode"><code><span class="html">
Some hosts are installing the eAccelerator opcode cache with PHP 5.4, and current production versions of this opcode cache break closures. If you find that your nice, working closures break when you load your code to a hosted website, check for eAccelerator (e.g. by calling phpinfo() and checking the output).<br /><br />Simple fixes include:<br /><br />* disabling eAccelerator and opcode caching<br />* replacing eAccelerator with Zend's opcache<br />* reverting to PHP 5.3<br /><br />Apparently, the eAccelerator project has solved this issue, but hosts move slowly so I recommend removing eAccelerator from the equation for now.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="105385">  <div class="votes">
    <div id="Vu105385">
    <a href="/manual/vote-note.php?id=105385&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd105385">
    <a href="/manual/vote-note.php?id=105385&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V105385" title="64% like this...">
    4
    </div>
  </div>
  <a href="#105385" class="name">
  <strong class="user"><em>ldrut</em></strong></a><a class="genanchor" href="#105385"> &para;</a><div class="date" title="2011-08-13 01:24"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom105385">
<div class="phpcode"><code><span class="html">
A common way to avoid contaminating Javascript global space with unneeded variables is to move the code into an immediately called anonymous closure.<br /><br />(function(){ ... })()<br /><br />The equivalent way to do that in PHP 5.3+ is<br /><br />call_user_func(function() use(closure-vars){ ... });</span>
</code></div>
  </div>
 </div>
  <div class="note" id="96579">  <div class="votes">
    <div id="Vu96579">
    <a href="/manual/vote-note.php?id=96579&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd96579">
    <a href="/manual/vote-note.php?id=96579&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V96579" title="63% like this...">
    11
    </div>
  </div>
  <a href="#96579" class="name">
  <strong class="user"><em>aaron at afloorabove dot com</em></strong></a><a class="genanchor" href="#96579"> &para;</a><div class="date" title="2010-03-05 02:42"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom96579">
<div class="phpcode"><code><span class="html">
Anonymous functions are great for events!<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">Event </span><span class="keyword">{<br /><br />&nbsp; public static </span><span class="default">$events </span><span class="keyword">= array();<br />&nbsp; <br />&nbsp; public static function </span><span class="default">bind</span><span class="keyword">(</span><span class="default">$event</span><span class="keyword">, </span><span class="default">$callback</span><span class="keyword">, </span><span class="default">$obj </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">) {<br />&nbsp; &nbsp; if (!</span><span class="default">self</span><span class="keyword">::</span><span class="default">$events</span><span class="keyword">[</span><span class="default">$event</span><span class="keyword">]) {<br />&nbsp; &nbsp; &nbsp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">$events</span><span class="keyword">[</span><span class="default">$event</span><span class="keyword">] = array();<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">$events</span><span class="keyword">[</span><span class="default">$event</span><span class="keyword">][] = (</span><span class="default">$obj </span><span class="keyword">=== </span><span class="default">null</span><span class="keyword">)&nbsp; ? </span><span class="default">$callback </span><span class="keyword">: array(</span><span class="default">$obj</span><span class="keyword">, </span><span class="default">$callback</span><span class="keyword">);<br />&nbsp; }<br />&nbsp; <br />&nbsp; public static function </span><span class="default">run</span><span class="keyword">(</span><span class="default">$event</span><span class="keyword">) {<br />&nbsp; &nbsp; if (!</span><span class="default">self</span><span class="keyword">::</span><span class="default">$events</span><span class="keyword">[</span><span class="default">$event</span><span class="keyword">]) return;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; foreach (</span><span class="default">self</span><span class="keyword">::</span><span class="default">$events</span><span class="keyword">[</span><span class="default">$event</span><span class="keyword">] as </span><span class="default">$callback</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; if (</span><span class="default">call_user_func</span><span class="keyword">(</span><span class="default">$callback</span><span class="keyword">) === </span><span class="default">false</span><span class="keyword">) break;<br />&nbsp; &nbsp; }<br />&nbsp; }<br /><br />}<br /><br />function </span><span class="default">hello</span><span class="keyword">() {<br />&nbsp; echo </span><span class="string">"Hello from function hello()\n"</span><span class="keyword">;<br />}<br /><br />class </span><span class="default">Foo </span><span class="keyword">{<br />&nbsp; function </span><span class="default">hello</span><span class="keyword">() {<br />&nbsp; &nbsp; echo </span><span class="string">"Hello from foo-&gt;hello()\n"</span><span class="keyword">;<br />&nbsp; }<br />}<br /><br />class </span><span class="default">Bar </span><span class="keyword">{<br />&nbsp; function </span><span class="default">hello</span><span class="keyword">() {<br />&nbsp; &nbsp; echo </span><span class="string">"Hello from Bar::hello()\n"</span><span class="keyword">;<br />&nbsp; }<br />}<br /><br /></span><span class="default">$foo </span><span class="keyword">= new </span><span class="default">Foo</span><span class="keyword">();<br /><br /></span><span class="comment">// bind a global function to the 'test' event<br /></span><span class="default">Event</span><span class="keyword">::</span><span class="default">bind</span><span class="keyword">(</span><span class="string">"test"</span><span class="keyword">, </span><span class="string">"hello"</span><span class="keyword">);<br /><br /></span><span class="comment">// bind an anonymous function<br /></span><span class="default">Event</span><span class="keyword">::</span><span class="default">bind</span><span class="keyword">(</span><span class="string">"test"</span><span class="keyword">, function() { echo </span><span class="string">"Hello from anonymous function\n"</span><span class="keyword">; });<br /><br /></span><span class="comment">// bind an class function on an instance<br /></span><span class="default">Event</span><span class="keyword">::</span><span class="default">bind</span><span class="keyword">(</span><span class="string">"test"</span><span class="keyword">, </span><span class="string">"hello"</span><span class="keyword">, </span><span class="default">$foo</span><span class="keyword">);<br /><br /></span><span class="comment">// bind a static class function<br /></span><span class="default">Event</span><span class="keyword">::</span><span class="default">bind</span><span class="keyword">(</span><span class="string">"test"</span><span class="keyword">, </span><span class="string">"Bar::hello"</span><span class="keyword">);<br /><br /></span><span class="default">Event</span><span class="keyword">::</span><span class="default">run</span><span class="keyword">(</span><span class="string">"test"</span><span class="keyword">);<br /><br /></span><span class="comment">/* Output<br />Hello from function hello()<br />Hello from anonymous function<br />Hello from foo-&gt;hello()<br />Hello from Bar::hello()<br />*/<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="97906">  <div class="votes">
    <div id="Vu97906">
    <a href="/manual/vote-note.php?id=97906&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd97906">
    <a href="/manual/vote-note.php?id=97906&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V97906" title="62% like this...">
    7
    </div>
  </div>
  <a href="#97906" class="name">
  <strong class="user"><em>kdelux at gmail dot com</em></strong></a><a class="genanchor" href="#97906"> &para;</a><div class="date" title="2010-05-14 08:55"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom97906">
<div class="phpcode"><code><span class="html">
Here is an example of one way to define, then use the variable ( $this ) in Closure functions.&nbsp; The code below explores all uses, and shows restrictions.<br /><br />The most useful tool in this snippet is the requesting_class() function that will tell you which class is responsible for executing the current Closure().&nbsp; <br /><br />Overview:<br />-----------------------<br />Successfully find calling object reference.<br />Successfully call $this(__invoke);<br />Successfully reference $$this-&gt;name;<br />Successfully call call_user_func(array($this, 'method'))<br /><br />Failure: reference anything through $this-&gt;<br />Failure: $this-&gt;name = ''; <br />Failure: $this-&gt;delfect(); <br /><br /><span class="default">&lt;?php<br /> <br />&nbsp; &nbsp; <br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="keyword">function </span><span class="default">requesting_class</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach(</span><span class="default">debug_backtrace</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">) as </span><span class="default">$stack</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(isset(</span><span class="default">$stack</span><span class="keyword">[</span><span class="string">'object'</span><span class="keyword">])){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$stack</span><span class="keyword">[</span><span class="string">'object'</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; <br />&nbsp; &nbsp; <br />&nbsp; &nbsp; <br />&nbsp; &nbsp; <br />&nbsp; &nbsp; class </span><span class="default">Person<br />&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; public </span><span class="default">$name </span><span class="keyword">= </span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; public </span><span class="default">$head </span><span class="keyword">= </span><span class="default">true</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; public </span><span class="default">$feet </span><span class="keyword">= </span><span class="default">true</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; public </span><span class="default">$deflected </span><span class="keyword">= </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; function </span><span class="default">__invoke</span><span class="keyword">(</span><span class="default">$p</span><span class="keyword">){ return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$p</span><span class="keyword">; }<br />&nbsp; &nbsp; &nbsp; &nbsp; function </span><span class="default">__toString</span><span class="keyword">(){ return </span><span class="string">'this'</span><span class="keyword">; } </span><span class="comment">// test for reference<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">){ </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">name </span><span class="keyword">= </span><span class="default">$name</span><span class="keyword">; }<br />&nbsp; &nbsp; &nbsp; &nbsp; function </span><span class="default">deflect</span><span class="keyword">(){ </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">deflected </span><span class="keyword">= </span><span class="default">true</span><span class="keyword">; }<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; public function </span><span class="default">shoot</span><span class="keyword">()<br />&nbsp; &nbsp; &nbsp; &nbsp; { </span><span class="comment">// If customAttack is defined, use that as the shoot resut.&nbsp; Otherwise shoot feet<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">if(</span><span class="default">is_callable</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">customAttack</span><span class="keyword">)){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">call_user_func</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">customAttack</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">feet </span><span class="keyword">= </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="default">$p </span><span class="keyword">= new </span><span class="default">Person</span><span class="keyword">(</span><span class="string">'Bob'</span><span class="keyword">);<br /><br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="default">$p</span><span class="keyword">-&gt;</span><span class="default">customAttack </span><span class="keyword">= <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; function(){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">$this</span><span class="keyword">; </span><span class="comment">// Notice: Undefined variable: this<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; #$this = new Class() // FATAL ERROR<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; // Trick to assign the variable '$this'<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">extract</span><span class="keyword">(array(</span><span class="string">'this' </span><span class="keyword">=&gt; </span><span class="default">requesting_class</span><span class="keyword">())); </span><span class="comment">// Determine what class is responsible for making the call to Closure<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">( </span><span class="default">$this&nbsp; </span><span class="keyword">);&nbsp; </span><span class="comment">// Passive reference works<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">( $</span><span class="default">$this </span><span class="keyword">); </span><span class="comment">// Added to class:&nbsp; function __toString(){ return 'this'; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$name </span><span class="keyword">= </span><span class="default">$this</span><span class="keyword">(</span><span class="string">'name'</span><span class="keyword">); </span><span class="comment">// Success<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">echo </span><span class="default">$name</span><span class="keyword">;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Outputs: Bob<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">echo </span><span class="string">'&lt;br /&gt;'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo $</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">name</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">call_user_func_array</span><span class="keyword">(array(</span><span class="default">$this</span><span class="keyword">, </span><span class="string">'deflect'</span><span class="keyword">), array()); </span><span class="comment">// SUCCESSFULLY CALLED<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; #$this-&gt;head = 0; //** FATAL ERROR: Using $this when not in object context<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">$</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">head </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;&nbsp; </span><span class="comment">// Successfully sets value<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">};<br /> <br />&nbsp; &nbsp; </span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$p</span><span class="keyword">);<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="default">$p</span><span class="keyword">-&gt;</span><span class="default">shoot</span><span class="keyword">();<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$p</span><span class="keyword">);<br /><br />&nbsp; &nbsp; <br />&nbsp; &nbsp; die();<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="105564">  <div class="votes">
    <div id="Vu105564">
    <a href="/manual/vote-note.php?id=105564&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd105564">
    <a href="/manual/vote-note.php?id=105564&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V105564" title="62% like this...">
    4
    </div>
  </div>
  <a href="#105564" class="name">
  <strong class="user"><em>reinaldorock at yahoo dot com dot br</em></strong></a><a class="genanchor" href="#105564"> &para;</a><div class="date" title="2011-08-27 08:15"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom105564">
<div class="phpcode"><code><span class="html">
Using closure to encapsulate environment<br /><span class="default">&lt;?php<br />&nbsp; &nbsp; $fib </span><span class="keyword">= function(</span><span class="default">$n</span><span class="keyword">) use(&amp;</span><span class="default">$fib</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">$n </span><span class="keyword">== </span><span class="default">0 </span><span class="keyword">|| </span><span class="default">$n </span><span class="keyword">== </span><span class="default">1</span><span class="keyword">) return </span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$fib</span><span class="keyword">(</span><span class="default">$n </span><span class="keyword">- </span><span class="default">1</span><span class="keyword">) + </span><span class="default">$fib</span><span class="keyword">(</span><span class="default">$n </span><span class="keyword">- </span><span class="default">2</span><span class="keyword">);<br />&nbsp; &nbsp; };<br /><br />&nbsp;&nbsp; echo </span><span class="default">$fib</span><span class="keyword">(</span><span class="default">2</span><span class="keyword">) . </span><span class="string">"\n"</span><span class="keyword">; </span><span class="comment">// 2<br />&nbsp;&nbsp; </span><span class="default">$lie </span><span class="keyword">= </span><span class="default">$fib</span><span class="keyword">;<br />&nbsp;&nbsp; </span><span class="default">$fib </span><span class="keyword">= function(){die(</span><span class="string">'error'</span><span class="keyword">);};</span><span class="comment">//rewrite $fib variable <br />&nbsp;&nbsp; </span><span class="keyword">echo </span><span class="default">$lie</span><span class="keyword">(</span><span class="default">5</span><span class="keyword">); </span><span class="comment">// error&nbsp;&nbsp; because $fib is referenced by closure<br /><br /></span><span class="default">?&gt;<br /></span><br />Alternative Fibonacci implementation using a self called function like javascript to encapsulate references variables.<br /><br /><span class="default">&lt;?php<br />$fib </span><span class="keyword">= </span><span class="default">call_user_func</span><span class="keyword">(function(){<br />&nbsp;&nbsp; <br />&nbsp; &nbsp; </span><span class="default">$fib </span><span class="keyword">= function(</span><span class="default">$n</span><span class="keyword">) use(&amp;</span><span class="default">$fib</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">$n </span><span class="keyword">== </span><span class="default">0 </span><span class="keyword">|| </span><span class="default">$n </span><span class="keyword">== </span><span class="default">1</span><span class="keyword">) return </span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$fib</span><span class="keyword">(</span><span class="default">$n </span><span class="keyword">- </span><span class="default">1</span><span class="keyword">) + </span><span class="default">$fib</span><span class="keyword">(</span><span class="default">$n </span><span class="keyword">- </span><span class="default">2</span><span class="keyword">);<br />&nbsp; &nbsp; };<br /><br />&nbsp; &nbsp; return </span><span class="default">$fib</span><span class="keyword">;<br />});<br /><br />echo </span><span class="default">$fib</span><span class="keyword">(</span><span class="default">2</span><span class="keyword">) . </span><span class="string">"\n"</span><span class="keyword">;</span><span class="comment">//2<br /></span><span class="default">$ok </span><span class="keyword">= </span><span class="default">$fib</span><span class="keyword">;<br /><br /></span><span class="default">$fib </span><span class="keyword">= function(){die(</span><span class="string">'error'</span><span class="keyword">)};</span><span class="comment">//rewrite $fib variable but don't referenced $fib used by closure<br /></span><span class="keyword">echo </span><span class="default">$ok</span><span class="keyword">(</span><span class="default">5</span><span class="keyword">);</span><span class="comment">//result ok <br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="107245">  <div class="votes">
    <div id="Vu107245">
    <a href="/manual/vote-note.php?id=107245&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd107245">
    <a href="/manual/vote-note.php?id=107245&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V107245" title="60% like this...">
    3
    </div>
  </div>
  <a href="#107245" class="name">
  <strong class="user"><em>mike at borft dot student dot utwente dot nl</em></strong></a><a class="genanchor" href="#107245"> &para;</a><div class="date" title="2012-01-24 02:46"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom107245">
<div class="phpcode"><code><span class="html">
Since it is possible to assign closures to class variables, it is a shame it is not possible to call them directly. ie. the following does not work:<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">foo </span><span class="keyword">{<br /><br />&nbsp; public </span><span class="default">test</span><span class="keyword">;<br /><br />&nbsp; public function </span><span class="default">__construct</span><span class="keyword">(){<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">test </span><span class="keyword">= function(</span><span class="default">$a</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; print </span><span class="string">"</span><span class="default">$a</span><span class="string">\n"</span><span class="keyword">;<br />&nbsp; &nbsp; };<br />&nbsp; }<br />}<br /><br /></span><span class="default">$f </span><span class="keyword">= new </span><span class="default">foo</span><span class="keyword">();<br /><br /></span><span class="default">$f</span><span class="keyword">-&gt;</span><span class="default">test</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span><br />However, it is possible using the magic __call function:<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">foo </span><span class="keyword">{<br /><br />&nbsp; public </span><span class="default">test</span><span class="keyword">;<br /><br />&nbsp; public function </span><span class="default">__construct</span><span class="keyword">(){<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">test </span><span class="keyword">= function(</span><span class="default">$a</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; print </span><span class="string">"</span><span class="default">$a</span><span class="string">\n"</span><span class="keyword">;<br />&nbsp; &nbsp; };<br />&nbsp; }<br /><br />&nbsp; public function </span><span class="default">__call</span><span class="keyword">(</span><span class="default">$method</span><span class="keyword">, </span><span class="default">$args</span><span class="keyword">){<br />&nbsp; &nbsp; if ( </span><span class="default">$this</span><span class="keyword">-&gt;{</span><span class="default">$method</span><span class="keyword">} instanceof </span><span class="default">Closure </span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; return </span><span class="default">call_user_func_array</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;{</span><span class="default">$method</span><span class="keyword">},</span><span class="default">$args</span><span class="keyword">);<br />&nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; return </span><span class="default">parent</span><span class="keyword">::</span><span class="default">__call</span><span class="keyword">(</span><span class="default">$method</span><span class="keyword">, </span><span class="default">$args</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; }<br />}<br /></span><span class="default">$f </span><span class="keyword">= new </span><span class="default">foo</span><span class="keyword">();<br /></span><span class="default">$f</span><span class="keyword">-&gt;</span><span class="default">test</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span>it <br />Hope it helps someone ;)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="99477">  <div class="votes">
    <div id="Vu99477">
    <a href="/manual/vote-note.php?id=99477&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd99477">
    <a href="/manual/vote-note.php?id=99477&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V99477" title="59% like this...">
    6
    </div>
  </div>
  <a href="#99477" class="name">
  <strong class="user"><em>anonymous</em></strong></a><a class="genanchor" href="#99477"> &para;</a><div class="date" title="2010-08-19 03:21"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom99477">
<div class="phpcode"><code><span class="html">
Base dao class illustrating the usefulness of closures.<br />* Handles opening and closing of connections.<br />* Adds slashes sql<br />* Type checking of sql parameters and casts as appropriate<br />* Provides hook for processing of result set and emitting one or more objects.<br />* Provides hook for accessing underlying link and result objects.<br /><br /><span class="default">&lt;?php<br /><br />define</span><span class="keyword">(</span><span class="string">"userName"</span><span class="keyword">,</span><span class="string">"root"</span><span class="keyword">);<br /></span><span class="default">define</span><span class="keyword">(</span><span class="string">"password"</span><span class="keyword">,</span><span class="string">"root"</span><span class="keyword">);<br /></span><span class="default">define</span><span class="keyword">(</span><span class="string">"dbName"</span><span class="keyword">,</span><span class="string">"ahcdb"</span><span class="keyword">);<br /></span><span class="default">define</span><span class="keyword">(</span><span class="string">"hostName"</span><span class="keyword">,</span><span class="string">"localhost"</span><span class="keyword">);<br /><br />class </span><span class="default">BaseDao </span><span class="keyword">{<br /><br />&nbsp; &nbsp; function </span><span class="default">getConnection</span><span class="keyword">()&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$link </span><span class="keyword">= </span><span class="default">mysql_connect</span><span class="keyword">(</span><span class="default">hostName</span><span class="keyword">, </span><span class="default">userName</span><span class="keyword">, </span><span class="default">password</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; if (!</span><span class="default">$link</span><span class="keyword">) <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; die(</span><span class="string">"Could not connect: " </span><span class="keyword">. </span><span class="default">mysql_error</span><span class="keyword">());<br />&nbsp; &nbsp; &nbsp; &nbsp; if (!</span><span class="default">mysql_select_db</span><span class="keyword">(</span><span class="default">dbName</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; die(</span><span class="string">"Could not select database: " </span><span class="keyword">. </span><span class="default">mysql_error</span><span class="keyword">());<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$link</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">setParams</span><span class="keyword">(&amp; </span><span class="default">$sql</span><span class="keyword">, </span><span class="default">$params</span><span class="keyword">)&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">$params </span><span class="keyword">!= </span><span class="default">null</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$sql </span><span class="keyword">= </span><span class="default">vsprintf</span><span class="keyword">(</span><span class="default">$sql</span><span class="keyword">, </span><span class="default">array_map</span><span class="keyword">(function(</span><span class="default">$n</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">is_int</span><span class="keyword">(</span><span class="default">$n</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return (int)</span><span class="default">$n</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">is_float</span><span class="keyword">(</span><span class="default">$n</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return (float)</span><span class="default">$n</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">is_string</span><span class="keyword">(</span><span class="default">$n</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">"'"</span><span class="keyword">.</span><span class="default">mysql_real_escape_string</span><span class="keyword">(</span><span class="default">$n</span><span class="keyword">).</span><span class="string">"'"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">mysql_real_escape_string</span><span class="keyword">(</span><span class="default">$n</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }, </span><span class="default">$params</span><span class="keyword">));<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; function </span><span class="default">executeQuery</span><span class="keyword">(</span><span class="default">$sql</span><span class="keyword">, </span><span class="default">$params</span><span class="keyword">, </span><span class="default">$callback </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">)&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$link&nbsp; </span><span class="keyword">= </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">getConnection</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">setParams</span><span class="keyword">(</span><span class="default">$sql</span><span class="keyword">, </span><span class="default">$params</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$return </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; if((</span><span class="default">$result </span><span class="keyword">= </span><span class="default">mysql_query</span><span class="keyword">(</span><span class="default">$sql</span><span class="keyword">, </span><span class="default">$link</span><span class="keyword">)) != </span><span class="default">null</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">$callback </span><span class="keyword">!= </span><span class="default">null</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$return </span><span class="keyword">= </span><span class="default">$callback</span><span class="keyword">(</span><span class="default">$result</span><span class="keyword">, </span><span class="default">$link</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">$link </span><span class="keyword">!= </span><span class="default">null</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">mysql_close</span><span class="keyword">(</span><span class="default">$link</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; if(!</span><span class="default">$result</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; die(</span><span class="string">"Fatal Error: Invalid query '</span><span class="default">$sql</span><span class="string">' : " </span><span class="keyword">. </span><span class="default">mysql_error</span><span class="keyword">());<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$return</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /> <br />&nbsp; &nbsp; function </span><span class="default">getList</span><span class="keyword">(</span><span class="default">$sql</span><span class="keyword">, </span><span class="default">$params</span><span class="keyword">, </span><span class="default">$callback</span><span class="keyword">)&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">executeQuery</span><span class="keyword">(</span><span class="default">$sql</span><span class="keyword">, </span><span class="default">$params</span><span class="keyword">, function(</span><span class="default">$result</span><span class="keyword">, </span><span class="default">$link</span><span class="keyword">) use (</span><span class="default">$callback</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$idx </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$list </span><span class="keyword">= array();<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; while (</span><span class="default">$row </span><span class="keyword">= </span><span class="default">mysql_fetch_assoc</span><span class="keyword">(</span><span class="default">$result</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">$callback </span><span class="keyword">!= </span><span class="default">null</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$list</span><span class="keyword">[</span><span class="default">$idx</span><span class="keyword">] = </span><span class="default">$callback</span><span class="keyword">(</span><span class="default">$idx</span><span class="keyword">++, </span><span class="default">$row</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$list</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; });<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">getSingle</span><span class="keyword">(</span><span class="default">$sql</span><span class="keyword">, </span><span class="default">$params</span><span class="keyword">, </span><span class="default">$callback</span><span class="keyword">)&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">executeQuery</span><span class="keyword">(</span><span class="default">$sql</span><span class="keyword">, </span><span class="default">$params</span><span class="keyword">, function(</span><span class="default">$result</span><span class="keyword">, </span><span class="default">$link</span><span class="keyword">) use (</span><span class="default">$callback</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$row </span><span class="keyword">= </span><span class="default">mysql_fetch_assoc</span><span class="keyword">(</span><span class="default">$result</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$obj </span><span class="keyword">= </span><span class="default">$callback</span><span class="keyword">(</span><span class="default">$row</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$obj</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; });<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">Example&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; var </span><span class="default">$id</span><span class="keyword">;<br />&nbsp; &nbsp; var </span><span class="default">$name</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">Example</span><span class="keyword">(</span><span class="default">$id</span><span class="keyword">, </span><span class="default">$name</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">id </span><span class="keyword">= </span><span class="default">$id</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">name </span><span class="keyword">= </span><span class="default">$name</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">setId</span><span class="keyword">(</span><span class="default">$id</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">id </span><span class="keyword">= </span><span class="default">$id</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">ExampleDao </span><span class="keyword">extends </span><span class="default">BaseDao&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">getAll</span><span class="keyword">(){<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">parent</span><span class="keyword">::</span><span class="default">getList</span><span class="keyword">(</span><span class="string">"select * from nodes"</span><span class="keyword">, </span><span class="default">null</span><span class="keyword">, function(</span><span class="default">$idx</span><span class="keyword">, </span><span class="default">$row</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return new </span><span class="default">Example</span><span class="keyword">(</span><span class="default">$row</span><span class="keyword">[</span><span class="string">"id"</span><span class="keyword">], </span><span class="default">$row</span><span class="keyword">[</span><span class="string">"name"</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp; &nbsp; });<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">load</span><span class="keyword">(</span><span class="default">$id</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">parent</span><span class="keyword">::</span><span class="default">getSingle</span><span class="keyword">(</span><span class="string">"select * from nodes where id = %1\$s"</span><span class="keyword">, array(</span><span class="default">$id</span><span class="keyword">), function(</span><span class="default">$row</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return new </span><span class="default">Example</span><span class="keyword">(</span><span class="default">$row</span><span class="keyword">[</span><span class="string">"id"</span><span class="keyword">], </span><span class="default">$row</span><span class="keyword">[</span><span class="string">"name"</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp; &nbsp; });<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">update</span><span class="keyword">(</span><span class="default">$example</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">parent</span><span class="keyword">::</span><span class="default">executeQuery</span><span class="keyword">(</span><span class="string">"update nodes set name = '' where&nbsp; id = -1"</span><span class="keyword">, </span><span class="default">null</span><span class="keyword">, function(</span><span class="default">$result</span><span class="keyword">, </span><span class="default">$link</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$result</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; });<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">insert</span><span class="keyword">(&amp; </span><span class="default">$example</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">parent</span><span class="keyword">::</span><span class="default">executeQuery</span><span class="keyword">(</span><span class="string">"insert into nodes"</span><span class="keyword">, </span><span class="default">null</span><span class="keyword">, function(</span><span class="default">$result</span><span class="keyword">, </span><span class="default">$link</span><span class="keyword">) use (</span><span class="default">$example</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$id </span><span class="keyword">= </span><span class="default">mysql_insert_id</span><span class="keyword">(</span><span class="default">$link</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$example</span><span class="keyword">-&gt;</span><span class="default">setId</span><span class="keyword">(</span><span class="default">$id</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$result</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; });<br />&nbsp; &nbsp; }&nbsp; &nbsp; <br />}<br /><br /></span><span class="default">$exampleDao </span><span class="keyword">= new </span><span class="default">ExampleDao</span><span class="keyword">();<br /><br /></span><span class="default">$list </span><span class="keyword">= </span><span class="default">$exampleDao</span><span class="keyword">-&gt;</span><span class="default">getAll</span><span class="keyword">());<br /><br /></span><span class="default">$exampleObject </span><span class="keyword">= </span><span class="default">$exampleDao</span><span class="keyword">-&gt;</span><span class="default">load</span><span class="keyword">(</span><span class="default">1</span><span class="keyword">));<br /><br /></span><span class="default">$exampleDao</span><span class="keyword">-&gt;</span><span class="default">update</span><span class="keyword">(</span><span class="default">$exampleObject</span><span class="keyword">);<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="110962">  <div class="votes">
    <div id="Vu110962">
    <a href="/manual/vote-note.php?id=110962&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd110962">
    <a href="/manual/vote-note.php?id=110962&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V110962" title="58% like this...">
    3
    </div>
  </div>
  <a href="#110962" class="name">
  <strong class="user"><em>marcellorvalle at gmail dot com</em></strong></a><a class="genanchor" href="#110962"> &para;</a><div class="date" title="2012-12-29 10:05"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom110962">
<div class="phpcode"><code><span class="html">
I fell uncomfortable with php's way to pass callbacks ahead. It's just a personal opinion but i think the structure array($object, 'method') a little bit ugly. In some special cases i would like to do something more verbose, like that:<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; $sortedArray </span><span class="keyword">= </span><span class="default">ArrayServices</span><span class="keyword">::</span><span class="default">sort</span><span class="keyword">(</span><span class="default">$arrayOfPerson</span><span class="keyword">, </span><span class="default">$sortPerson</span><span class="keyword">-&gt;</span><span class="default">byName</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />Here, "$sortPerson-&gt;byName" is a pointer to a function that receives 2 instances of Person and return true if the name of the first is "bigger" than the second. "ArrayServices::sort" is a function that can sort any kind of array using different criterias, it uses the function passed on the second parameter to compare two items on the array<br /><br />I am able do that defining a simple abstract class which gives the ability to it's children to expose their methods as closures using __get() magic funtion.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">abstract class </span><span class="default">ClosureExposerObject<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">__get</span><span class="keyword">(</span><span class="default">$methodName</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">is_callable</span><span class="keyword">(<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; array(</span><span class="default">$this</span><span class="keyword">, </span><span class="default">$methodName</span><span class="keyword">)))<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return function() use (</span><span class="default">$methodName</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$args </span><span class="keyword">= </span><span class="default">func_get_args</span><span class="keyword">(); <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">call_user_func_array</span><span class="keyword">(array(</span><span class="default">$this</span><span class="keyword">, </span><span class="default">$methodName</span><span class="keyword">), </span><span class="default">$args</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; };<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$className </span><span class="keyword">= </span><span class="default">get_class</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw new \</span><span class="default">BadMethodCallException</span><span class="keyword">(</span><span class="string">"</span><span class="default">$method</span><span class="string"> is not a callable at </span><span class="default">$className</span><span class="string"> class."</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />Now it is possible to define a class SortPerson so that i could use it like in the first code snippet.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">SortPerson </span><span class="keyword">extends </span><span class="default">ClosureExposerObject<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">byName</span><span class="keyword">(</span><span class="default">Person p1</span><span class="keyword">, </span><span class="default">Person p2</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">p1</span><span class="keyword">-&gt;</span><span class="default">getName</span><span class="keyword">() &gt; </span><span class="default">p2</span><span class="keyword">-&gt;</span><span class="default">getName</span><span class="keyword">();<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">byAge</span><span class="keyword">(</span><span class="default">Person p1</span><span class="keyword">, </span><span class="default">Person p2</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">p1</span><span class="keyword">-&gt;</span><span class="default">getAge</span><span class="keyword">() &gt; </span><span class="default">p2</span><span class="keyword">-&gt;</span><span class="default">getAge</span><span class="keyword">();<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">bySurName</span><span class="keyword">(</span><span class="default">Person p1</span><span class="keyword">, </span><span class="default">Person p2</span><span class="keyword">)<br />&nbsp; &nbsp; (...)<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />I just needed to extend ClosureExposerObject and do nothing more. <br /><br />Some observations: SortPerson is a service class but i decided not to implement it with static methods. It is a personal matter but i really dont like to implement such small classes with statics. Also i have inverted some naming conventions (class names as substantives and methods as verbs) but in some very special cases i thing that it actually helps readability.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114480">  <div class="votes">
    <div id="Vu114480">
    <a href="/manual/vote-note.php?id=114480&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114480">
    <a href="/manual/vote-note.php?id=114480&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114480" title="57% like this...">
    2
    </div>
  </div>
  <a href="#114480" class="name">
  <strong class="user"><em>Victor</em></strong></a><a class="genanchor" href="#114480"> &para;</a><div class="date" title="2014-02-25 08:26"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114480">
<div class="phpcode"><code><span class="html">
Please note that while You can assign a closure to an array key with the method<br /><br />$array['key'] = function() { return $whatever; };<br /><br />You cannot do the same with the array assignment operator.<br /><br />So<br /><br />$array = Array(<br />&nbsp; 'key' =&gt; function() { return $whatever; }<br />);<br /><br />will NOT work.<br />(This is indeed awkward.)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114178">  <div class="votes">
    <div id="Vu114178">
    <a href="/manual/vote-note.php?id=114178&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114178">
    <a href="/manual/vote-note.php?id=114178&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114178" title="57% like this...">
    1
    </div>
  </div>
  <a href="#114178" class="name">
  <strong class="user"><em>jc at jmccc dot com</em></strong></a><a class="genanchor" href="#114178"> &para;</a><div class="date" title="2014-01-21 05:48"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114178">
<div class="phpcode"><code><span class="html">
In 5.3, $this cannot be used in an anonymous function, though you can simply assign $this to another variable and pass that into the function in the use section, This quick and dirty hack works for at least calling public functions and accessing public variables of the parent class.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">Example </span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$blah</span><span class="keyword">;<br />&nbsp; &nbsp; function </span><span class="default">foo</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$that </span><span class="keyword">= </span><span class="default">$this</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$tmp </span><span class="keyword">= function() use (</span><span class="default">$that</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; return </span><span class="default">$that</span><span class="keyword">-&gt;</span><span class="default">blah</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$tmp</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$test </span><span class="keyword">= new </span><span class="default">Example</span><span class="keyword">();<br /></span><span class="default">$example</span><span class="keyword">-&gt;</span><span class="default">blah </span><span class="keyword">= </span><span class="string">"whatever"</span><span class="keyword">;<br />echo </span><span class="default">$example</span><span class="keyword">-&gt;</span><span class="default">foo</span><span class="keyword">(); </span><span class="comment">// prints "whatever"</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114079">  <div class="votes">
    <div id="Vu114079">
    <a href="/manual/vote-note.php?id=114079&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114079">
    <a href="/manual/vote-note.php?id=114079&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114079" title="57% like this...">
    1
    </div>
  </div>
  <a href="#114079" class="name">
  <strong class="user"><em>derkontrollfreak+9hy5l at gmail dot com</em></strong></a><a class="genanchor" href="#114079"> &para;</a><div class="date" title="2014-01-09 04:41"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114079">
<div class="phpcode"><code><span class="html">
Beware that since PHP 5.4 registering a Closure as an object property that has been instantiated in the same object scope will create a circular reference which prevents immediate object destruction:<br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">Test<br /></span><span class="keyword">{<br />&nbsp; &nbsp; private </span><span class="default">$closure</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">closure </span><span class="keyword">= function () {<br />&nbsp; &nbsp; &nbsp; &nbsp; };<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">__destruct</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"destructed\n"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />new </span><span class="default">Test</span><span class="keyword">;<br />echo </span><span class="string">"finished\n"</span><span class="keyword">;<br /><br /></span><span class="comment">/*<br /> * Result in PHP 5.3:<br /> * ------------------<br /> * destructed<br /> * finished<br /> *<br /> * Result since PHP 5.4:<br /> * ---------------------<br /> * finished<br /> * destructed<br /> */<br /><br /></span><span class="default">?&gt;<br /></span><br />To circumvent this, you can instantiate the Closure in a static method:<br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">public function </span><span class="default">__construct</span><span class="keyword">()<br />{<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">closure </span><span class="keyword">= </span><span class="default">self</span><span class="keyword">::</span><span class="default">createClosure</span><span class="keyword">();<br />}<br /><br />public static function </span><span class="default">createClosure</span><span class="keyword">()<br />{<br />&nbsp; &nbsp; return function () {<br />&nbsp; &nbsp; };<br />}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114546">  <div class="votes">
    <div id="Vu114546">
    <a href="/manual/vote-note.php?id=114546&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114546">
    <a href="/manual/vote-note.php?id=114546&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114546" title="56% like this...">
    3
    </div>
  </div>
  <a href="#114546" class="name">
  <strong class="user"><em>andris at codeaid dot net</em></strong></a><a class="genanchor" href="#114546"> &para;</a><div class="date" title="2014-03-05 12:33"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114546">
<div class="phpcode"><code><span class="html">
Haven't seen it documented anywhere but PHP 5.4 now allows accessing private and protected members of an object if it's passed into a lambda function:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Scope<br /></span><span class="keyword">{<br />&nbsp; &nbsp; protected </span><span class="default">$property </span><span class="keyword">= </span><span class="string">'default'</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="comment">// or even<br />&nbsp; &nbsp; // private $property = 'default';<br /><br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">run</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$self </span><span class="keyword">= </span><span class="default">$this</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$func </span><span class="keyword">= function() use (</span><span class="default">$self</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$self</span><span class="keyword">-&gt;</span><span class="default">property </span><span class="keyword">= </span><span class="string">'changed'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; };<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$func</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">property</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$scope </span><span class="keyword">= new </span><span class="default">Scope</span><span class="keyword">();<br /></span><span class="default">$scope</span><span class="keyword">-&gt;</span><span class="default">run</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span><br />When running the file under PHP 5.3 you get the following error message:<br /> * Fatal error: Cannot access protected property Scope::$property in ./file.php on line 11<br /><br />PHP 5.4, however, does not complain and outputs "changed" as expected. <br /><br />Not sure why it's like that but I suspect it has something to do with 5.4 supporting passing $this into lambda functions.<br /><br />Speaking of which, something to remember is that the following won't work:<br /><span class="default">&lt;?php<br />$func </span><span class="keyword">= function() use (</span><span class="default">$this</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">property </span><span class="keyword">= </span><span class="string">'changed'</span><span class="keyword">;<br />};<br /></span><span class="default">?&gt;<br /></span>The error you'll get is:<br /> * PHP Fatal error:&nbsp; Cannot use $this as lexical variable in ./file.php on line 9<br /><br />You have to totally omit the use statement for it to work:<br /><span class="default">&lt;?php<br />$func </span><span class="keyword">= function() {<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">property </span><span class="keyword">= </span><span class="string">'changed'</span><span class="keyword">;<br />};<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="112335">  <div class="votes">
    <div id="Vu112335">
    <a href="/manual/vote-note.php?id=112335&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd112335">
    <a href="/manual/vote-note.php?id=112335&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V112335" title="57% like this...">
    1
    </div>
  </div>
  <a href="#112335" class="name">
  <strong class="user"><em>mrdaniel619 at gmail dot com</em></strong></a><a class="genanchor" href="#112335"> &para;</a><div class="date" title="2013-06-03 06:54"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom112335">
<div class="phpcode"><code><span class="html">
just in case you ever want to change a member function run time<br /><br /><span class="default">&lt;?php <br /><br /></span><span class="keyword">class </span><span class="default">t<br /></span><span class="keyword">{<br />&nbsp; &nbsp; var </span><span class="default">$num</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; var </span><span class="default">$dynamic_function</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">dynamic_function</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$func </span><span class="keyword">= </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">dynamic_function</span><span class="keyword">; <br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$func</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">); <br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$p </span><span class="keyword">= new </span><span class="default">t</span><span class="keyword">();<br /><br /></span><span class="default">$p</span><span class="keyword">-&gt;</span><span class="default">num </span><span class="keyword">= </span><span class="default">5</span><span class="keyword">;<br /><br /></span><span class="default">$p</span><span class="keyword">-&gt;</span><span class="default">dynamic_function </span><span class="keyword">= function(</span><span class="default">$this_ref</span><span class="keyword">) </span><span class="comment">// param cannot be named $this<br /></span><span class="keyword">{<br />&nbsp; &nbsp; echo </span><span class="default">$this_ref</span><span class="keyword">-&gt;</span><span class="default">num</span><span class="keyword">++.</span><span class="string">'&lt;br /&gt;'</span><span class="keyword">;<br />};<br /><br /></span><span class="default">$p</span><span class="keyword">-&gt;</span><span class="default">dynamic_function</span><span class="keyword">(); </span><span class="comment">// CALL YOUR DYNAMIC FUNCTION<br /><br /></span><span class="default">$p</span><span class="keyword">-&gt;</span><span class="default">dynamic_function </span><span class="keyword">= function(</span><span class="default">$this_ref</span><span class="keyword">) </span><span class="comment">// NEW DYNAMIC fUNCRION<br /></span><span class="keyword">{<br />&nbsp; &nbsp; echo </span><span class="default">$this_ref</span><span class="keyword">-&gt;</span><span class="default">num</span><span class="keyword">.</span><span class="string">'&lt;br /&gt;'</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="default">$this_ref</span><span class="keyword">-&gt;</span><span class="default">num </span><span class="keyword">*= </span><span class="default">3</span><span class="keyword">;<br />};<br /><br /></span><span class="default">$p</span><span class="keyword">-&gt;</span><span class="default">dynamic_function</span><span class="keyword">(); </span><span class="comment">// CALL DYNAMIC FUNCTION<br /><br /></span><span class="keyword">echo </span><span class="default">$p</span><span class="keyword">-&gt;</span><span class="default">num</span><span class="keyword">; </span><span class="comment">// display number<br /><br /></span><span class="keyword">exit;<br /><br /></span><span class="default">?&gt;<br /></span><br />output:<br />5<br />6<br />18</span>
</code></div>
  </div>
 </div>
  <div class="note" id="98384">  <div class="votes">
    <div id="Vu98384">
    <a href="/manual/vote-note.php?id=98384&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd98384">
    <a href="/manual/vote-note.php?id=98384&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V98384" title="57% like this...">
    3
    </div>
  </div>
  <a href="#98384" class="name">
  <strong class="user"><em>martin dot partel at gmail dot com</em></strong></a><a class="genanchor" href="#98384"> &para;</a><div class="date" title="2010-06-11 10:50"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom98384">
<div class="phpcode"><code><span class="html">
$this is currently (PHP 5.3.2) not usable directly with closures.<br /><br />One can write:<br /><span class="default">&lt;?php<br />$self </span><span class="keyword">= </span><span class="default">$this</span><span class="keyword">;<br />function () use (</span><span class="default">$self</span><span class="keyword">) { ... }<br /></span><span class="default">?&gt;<br /></span>but then the private/protected members of $this cannot be used inside the closure. This makes closures much less useful in OO code.<br /><br />Until this is fixed, one can cheat using reflection:<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">FullAccessWrapper<br /></span><span class="keyword">{<br />&nbsp; &nbsp; protected </span><span class="default">$_self</span><span class="keyword">;<br />&nbsp; &nbsp; protected </span><span class="default">$_refl</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$self</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">_self </span><span class="keyword">= </span><span class="default">$self</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">_refl </span><span class="keyword">= new </span><span class="default">ReflectionObject</span><span class="keyword">(</span><span class="default">$self</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">__call</span><span class="keyword">(</span><span class="default">$method</span><span class="keyword">, </span><span class="default">$args</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$mrefl </span><span class="keyword">= </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">_refl</span><span class="keyword">-&gt;</span><span class="default">getMethod</span><span class="keyword">(</span><span class="default">$method</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$mrefl</span><span class="keyword">-&gt;</span><span class="default">setAccessible</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$mrefl</span><span class="keyword">-&gt;</span><span class="default">invokeArgs</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">_self</span><span class="keyword">, </span><span class="default">$args</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">__set</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">, </span><span class="default">$value</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$prefl </span><span class="keyword">= </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">_refl</span><span class="keyword">-&gt;</span><span class="default">getProperty</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$prefl</span><span class="keyword">-&gt;</span><span class="default">setAccessible</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$prefl</span><span class="keyword">-&gt;</span><span class="default">setValue</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">_self</span><span class="keyword">, </span><span class="default">$value</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">__get</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$prefl </span><span class="keyword">= </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">_refl</span><span class="keyword">-&gt;</span><span class="default">getProperty</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$prefl</span><span class="keyword">-&gt;</span><span class="default">setAccessible</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$prefl</span><span class="keyword">-&gt;</span><span class="default">getValue</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">_self</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">__isset</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$value </span><span class="keyword">= </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">__get</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; return isset(</span><span class="default">$value</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="comment">/**<br /> * Usage:<br /> * $self = giveAccess($this);<br /> * function() use ($self) { $self-&gt;privateMember... }<br /> */<br /></span><span class="keyword">function </span><span class="default">giveAccess</span><span class="keyword">(</span><span class="default">$obj</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; return new </span><span class="default">FullAccessWrapper</span><span class="keyword">(</span><span class="default">$obj</span><span class="keyword">);<br />}<br /><br /></span><span class="comment">// Example:<br /><br /></span><span class="keyword">class </span><span class="default">Foo<br /></span><span class="keyword">{<br />&nbsp; &nbsp; private </span><span class="default">$x </span><span class="keyword">= </span><span class="default">3</span><span class="keyword">;<br />&nbsp; &nbsp; private function </span><span class="default">f</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">15</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">getClosureUsingPrivates</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$self </span><span class="keyword">= </span><span class="default">giveAccess</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; return function () use (</span><span class="default">$self</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$self</span><span class="keyword">-&gt;</span><span class="default">x </span><span class="keyword">* </span><span class="default">$self</span><span class="keyword">-&gt;</span><span class="default">f</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; };<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$foo </span><span class="keyword">= new </span><span class="default">Foo</span><span class="keyword">();<br /></span><span class="default">$closure </span><span class="keyword">= </span><span class="default">$foo</span><span class="keyword">-&gt;</span><span class="default">getClosureUsingPrivates</span><span class="keyword">();<br />echo </span><span class="default">$closure</span><span class="keyword">() . </span><span class="string">"\n"</span><span class="keyword">; </span><span class="comment">// Prints 45 as expected<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="92664">  <div class="votes">
    <div id="Vu92664">
    <a href="/manual/vote-note.php?id=92664&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd92664">
    <a href="/manual/vote-note.php?id=92664&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V92664" title="58% like this...">
    2
    </div>
  </div>
  <a href="#92664" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#92664"> &para;</a><div class="date" title="2009-08-03 02:50"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom92664">
<div class="phpcode"><code><span class="html">
If you want to check whether you're dealing with a closure specifically and not a string or array callback you can do this:<br /><br /><span class="default">&lt;?php<br />$isAClosure </span><span class="keyword">= </span><span class="default">is_callable</span><span class="keyword">(</span><span class="default">$thing</span><span class="keyword">) &amp;&amp; </span><span class="default">is_object</span><span class="keyword">(</span><span class="default">$thing</span><span class="keyword">);<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="91871">  <div class="votes">
    <div id="Vu91871">
    <a href="/manual/vote-note.php?id=91871&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd91871">
    <a href="/manual/vote-note.php?id=91871&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V91871" title="58% like this...">
    2
    </div>
  </div>
  <a href="#91871" class="name">
  <strong class="user"><em>mcm dot matt at gmail dot com</em></strong></a><a class="genanchor" href="#91871"> &para;</a><div class="date" title="2009-06-30 05:49"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom91871">
<div class="phpcode"><code><span class="html">
Example using uasort.<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">// Usual method.<br /></span><span class="keyword">function </span><span class="default">cmp</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">) {<br />&nbsp; &nbsp; return(</span><span class="default">$a </span><span class="keyword">&gt; </span><span class="default">$b</span><span class="keyword">);<br />}<br /></span><span class="default">uasort</span><span class="keyword">(</span><span class="default">$array</span><span class="keyword">, </span><span class="string">'cmp'</span><span class="keyword">);<br /><br /></span><span class="comment">// New<br /></span><span class="default">uasort</span><span class="keyword">(</span><span class="default">$array</span><span class="keyword">, function(</span><span class="default">$a</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">) {<br />&nbsp; &nbsp; return(</span><span class="default">$a </span><span class="keyword">&gt; </span><span class="default">$b</span><span class="keyword">);<br />});<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113753">  <div class="votes">
    <div id="Vu113753">
    <a href="/manual/vote-note.php?id=113753&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113753">
    <a href="/manual/vote-note.php?id=113753&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113753" title="55% like this...">
    2
    </div>
  </div>
  <a href="#113753" class="name">
  <strong class="user"><em>alexander at cheprasov dot com</em></strong></a><a class="genanchor" href="#113753"> &para;</a><div class="date" title="2013-11-26 01:06"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113753">
<div class="phpcode"><code><span class="html">
Example: <br /><br /><span class="default">&lt;?php<br />$a </span><span class="keyword">= </span><span class="default">213</span><span class="keyword">;<br /><br /></span><span class="default">$f </span><span class="keyword">= function() use (</span><span class="default">$a</span><span class="keyword">){<br />&nbsp; &nbsp; echo </span><span class="default">$a</span><span class="keyword">;<br />};<br /><br /></span><span class="default">$a </span><span class="keyword">= </span><span class="default">144</span><span class="keyword">;<br />echo </span><span class="default">$a</span><span class="keyword">;<br /><br /></span><span class="default">$f</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span><br />Result: <br />144<br />213</span>
</code></div>
  </div>
 </div>
  <div class="note" id="94037">  <div class="votes">
    <div id="Vu94037">
    <a href="/manual/vote-note.php?id=94037&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd94037">
    <a href="/manual/vote-note.php?id=94037&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V94037" title="57% like this...">
    1
    </div>
  </div>
  <a href="#94037" class="name">
  <strong class="user"><em>kukoman at pobox dot sk</em></strong></a><a class="genanchor" href="#94037"> &para;</a><div class="date" title="2009-10-13 05:22"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom94037">
<div class="phpcode"><code><span class="html">
be aware of&nbsp; Fatal error: Using $this when not in object context when using in closures<br /><br /><a href="http://wiki.php.net/rfc/closures/removal-of-this" rel="nofollow" target="_blank">http://wiki.php.net/rfc/closures/removal-of-this</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="111265">  <div class="votes">
    <div id="Vu111265">
    <a href="/manual/vote-note.php?id=111265&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd111265">
    <a href="/manual/vote-note.php?id=111265&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V111265" title="55% like this...">
    1
    </div>
  </div>
  <a href="#111265" class="name">
  <strong class="user"><em>benkuhl at gmail dot com</em></strong></a><a class="genanchor" href="#111265"> &para;</a><div class="date" title="2013-01-31 04:34"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom111265">
<div class="phpcode"><code><span class="html">
Beware of scope!&nbsp; $this refers to the class that the function was defined within.<br /><br /> ----------- Example #1 - Doesn't work (Notice: Undefined variable: this) ----------- <br /><span class="default">&lt;?php<br /><br />$callableFunc </span><span class="keyword">= function () {<br />&nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">);<br />};<br /><br /></span><span class="default">call_user_func</span><span class="keyword">(</span><span class="default">$callableFunc</span><span class="keyword">);<br /><br /></span><span class="default">?&gt;<br /></span><br /> ----------- Example #2 - Doesn't work (Notice: Undefined variable: this) ----------- <br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">myClass </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">execute</span><span class="keyword">(</span><span class="default">$func</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">is_callable</span><span class="keyword">(</span><span class="default">$func</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">call_user_func</span><span class="keyword">(</span><span class="default">$func</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$class </span><span class="keyword">= new </span><span class="default">myClass</span><span class="keyword">();<br /></span><span class="default">$class</span><span class="keyword">-&gt;</span><span class="default">execute</span><span class="keyword">(function () {<br />&nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">);<br />});<br /></span><span class="default">?&gt;<br /></span><br /> ----------- Example #3 - Works! ----------- <br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">myClass </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">getMyExecutableFunction</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return function () {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; };<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">execute</span><span class="keyword">(</span><span class="default">$func</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">is_callable</span><span class="keyword">(</span><span class="default">$func</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">call_user_func</span><span class="keyword">(</span><span class="default">$func</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$class </span><span class="keyword">= new </span><span class="default">myClass</span><span class="keyword">();<br /></span><span class="default">$class</span><span class="keyword">-&gt;</span><span class="default">execute</span><span class="keyword">(</span><span class="default">$class</span><span class="keyword">-&gt;</span><span class="default">getMyExecutableFunction</span><span class="keyword">()); </span><span class="comment">//object(myClass)[1]<br /></span><span class="default">?&gt;<br /></span><br />$this is not available in a static method!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="107949">  <div class="votes">
    <div id="Vu107949">
    <a href="/manual/vote-note.php?id=107949&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd107949">
    <a href="/manual/vote-note.php?id=107949&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V107949" title="55% like this...">
    1
    </div>
  </div>
  <a href="#107949" class="name">
  <strong class="user"><em>orwellophile at phpblue dot net</em></strong></a><a class="genanchor" href="#107949"> &para;</a><div class="date" title="2012-03-16 04:42"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom107949">
<div class="phpcode"><code><span class="html">
You can create a dynamic method with a class, with access to member variables, with a little bit of trickery:<br /><br />&lt;?<br />&nbsp; &nbsp; class DynamicFunction {<br />&nbsp; &nbsp; &nbsp; &nbsp; var $functionPointer;<br />&nbsp; &nbsp; &nbsp; &nbsp; var $mv = "The Member Variable";<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; function __construct() {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $this-&gt;functionPointer = function($arg) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return sprintf("I am the default closure, argument is %s\n", $arg);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; };<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; function changeFunction($functionSource) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $functionSource = str_replace('$this', '$_this', $functionSource);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $_this = clone $this;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $f = '$this-&gt;functionPointer = function($arg) use ($_this) {' . PHP_EOL;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $f.= $functionSource . PHP_EOL . "};";<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; eval($f);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; function __call($method, $args) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if ( $this-&gt;{$method} instanceof Closure ) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return call_user_func_array($this-&gt;{$method},$args);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw new Exception("Invalid Function");<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; if (!empty($argc) &amp;&amp; !strcmp(basename($argv[0]), basename(__FILE__))) {<br />&nbsp; &nbsp; &nbsp; &nbsp; $dfstring1 = 'return sprintf("I am dynamic function 1, argument is %s, member variables is %s\n", $arg, $this-&gt;mv);';<br />&nbsp; &nbsp; &nbsp; &nbsp; $dfstring2 = 'return sprintf("I am dynamic function 2, argument is %s, member variables is %s\n", $arg, $this-&gt;mv);';<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; $df = new DynamicFunction();<br />&nbsp; &nbsp; &nbsp; &nbsp; $df-&gt;changeFunction($dfstring1);<br />&nbsp; &nbsp; &nbsp; &nbsp; echo $df-&gt;functionPointer("Rabbit");<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; $df-&gt;changeFunction($dfstring2);<br />&nbsp; &nbsp; &nbsp; &nbsp; $df-&gt;mv = "A different var";<br />&nbsp; &nbsp; &nbsp; &nbsp; echo $df-&gt;functionPointer("Cow");<br />&nbsp; &nbsp; };<br />?&gt;</span>
</code></div>
  </div>
 </div>
  <div class="note" id="115892">  <div class="votes">
    <div id="Vu115892">
    <a href="/manual/vote-note.php?id=115892&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115892">
    <a href="/manual/vote-note.php?id=115892&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115892" title="53% like this...">
    1
    </div>
  </div>
  <a href="#115892" class="name">
  <strong class="user"><em>inaitana</em></strong></a><a class="genanchor" href="#115892"> &para;</a><div class="date" title="2014-10-10 04:12"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115892">
<div class="phpcode"><code><span class="html">
Doesn't anyone else think Closure is used here with an inappropriate meaning?<br /><br />Isn't closure just the concept of being able to reference the outer function environment from the inner function, as in example #3?<br /><br />It's commonly used with anonymous functions, but from what I know it's not the same thing as an anonymous function.<br />"Lambda functions" might be another name for anonymous functions, not "Closures".<br /><br />I mean, a named function could employ closure too.<br />And anonymous functions don't necessarily support closure in all languages.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="95124">  <div class="votes">
    <div id="Vu95124">
    <a href="/manual/vote-note.php?id=95124&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd95124">
    <a href="/manual/vote-note.php?id=95124&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V95124" title="55% like this...">
    1
    </div>
  </div>
  <a href="#95124" class="name">
  <strong class="user"><em>puskulcu at gmail dot com</em></strong></a><a class="genanchor" href="#95124"> &para;</a><div class="date" title="2009-12-14 12:46"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom95124">
<div class="phpcode"><code><span class="html">
hello there!<br />here is a little code which shows use of the closures as event handlers:<br /><br /><span class="default">&lt;?php<br /><br />&nbsp; </span><span class="keyword">class </span><span class="default">Button<br />&nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$OnBeforeClick</span><span class="keyword">;<br />&nbsp; &nbsp; public </span><span class="default">$OnAfterClick</span><span class="keyword">;<br />&nbsp; &nbsp; public </span><span class="default">$Name</span><span class="keyword">;<br /><br />&nbsp; &nbsp; function </span><span class="default">Button</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">Name </span><span class="keyword">= </span><span class="string">'MyButton'</span><span class="keyword">;&nbsp; &nbsp; <br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">Click</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">DoBeforeClick</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; echo </span><span class="string">'Click!'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">DoAfterClick</span><span class="keyword">();<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; private function </span><span class="default">DoBeforeClick</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; if (isset(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">OnBeforeClick</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$Event </span><span class="keyword">= </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">OnBeforeClick</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$Event</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; private function </span><span class="default">DoAfterClick</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; if (isset(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">OnAfterClick</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$Event </span><span class="keyword">= </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">OnAfterClick</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$Event</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; }<br />&nbsp; <br />&nbsp; </span><span class="comment">//eclipse may warn here about syntax error but no problem, it runs well.<br />&nbsp; </span><span class="default">$BeforeClickEventHandler </span><span class="keyword">= function(</span><span class="default">$Sender</span><span class="keyword">) { echo </span><span class="default">$Sender</span><span class="keyword">-&gt;</span><span class="default">Name </span><span class="keyword">. </span><span class="string">' (Before Click)'</span><span class="keyword">; };&nbsp; <br />&nbsp; </span><span class="default">$AfterClickEventHandler </span><span class="keyword">= function(</span><span class="default">$Sender</span><span class="keyword">) { echo </span><span class="default">$Sender</span><span class="keyword">-&gt;</span><span class="default">Name </span><span class="keyword">. </span><span class="string">' (After Click)'</span><span class="keyword">; };&nbsp; <br />&nbsp; <br />&nbsp; </span><span class="default">$MyWidget </span><span class="keyword">= new </span><span class="default">Button</span><span class="keyword">();<br />&nbsp; </span><span class="default">$MyWidget</span><span class="keyword">-&gt;</span><span class="default">OnBeforeClick </span><span class="keyword">= </span><span class="default">$BeforeClickEventHandler</span><span class="keyword">;<br />&nbsp; </span><span class="default">$MyWidget</span><span class="keyword">-&gt;</span><span class="default">OnAfterClick </span><span class="keyword">= </span><span class="default">$AfterClickEventHandler</span><span class="keyword">;<br />&nbsp; </span><span class="default">$MyWidget</span><span class="keyword">-&gt;</span><span class="default">Click</span><span class="keyword">();<br /><br /></span><span class="default">?&gt;<br /></span><br />output:<br />MyButton (Before Click)<br />Click!<br />MyButton (After Click)<br /><br />i hope you find this useful.<br />regards.<br />emre</span>
</code></div>
  </div>
 </div>
  <div class="note" id="102785">  <div class="votes">
    <div id="Vu102785">
    <a href="/manual/vote-note.php?id=102785&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd102785">
    <a href="/manual/vote-note.php?id=102785&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V102785" title="54% like this...">
    1
    </div>
  </div>
  <a href="#102785" class="name">
  <strong class="user"><em>paul at somewhere dot com</em></strong></a><a class="genanchor" href="#102785"> &para;</a><div class="date" title="2011-03-06 02:36"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom102785">
<div class="phpcode"><code><span class="html">
I benched instantiating a function and lambda function.<br /><br />Functions used:<br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">data</span><span class="keyword">() {<br /> </span><span class="default">$var </span><span class="keyword">= </span><span class="string">'hi'</span><span class="keyword">;<br />}<br /></span><span class="default">$lambda </span><span class="keyword">= function() {<br /> </span><span class="default">$var </span><span class="keyword">= </span><span class="string">'hi'</span><span class="keyword">;<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />Bench for instantiating a function:<br />1.692800000000000082422957 μs<br />Bench for instantiating Lambda Function:<br />0.906000000000000027533531 μs<br />Bench for calling function:<br />0.7153000000000000468958206 μs<br />Bench for calling lambda function:<br />0.6914000000000000145661261 μs<br /><br />Calling the lambda function and regular function fluctuates between .81 and .65 so they seem to be the same.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="96341">  <div class="votes">
    <div id="Vu96341">
    <a href="/manual/vote-note.php?id=96341&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd96341">
    <a href="/manual/vote-note.php?id=96341&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V96341" title="54% like this...">
    1
    </div>
  </div>
  <a href="#96341" class="name">
  <strong class="user"><em>ljackson at jjcons dot com</em></strong></a><a class="genanchor" href="#96341"> &para;</a><div class="date" title="2010-02-21 10:46"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom96341">
<div class="phpcode"><code><span class="html">
appears kwilson at shuttlebox dot net that you may have just made unintended side effect. Note that adding the global $variable to your test function make the closure function echo second rather than first So the anonymous function works as expected with respect to globals.<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; $variable </span><span class="keyword">= </span><span class="string">"first"</span><span class="keyword">;<br /><br />&nbsp; &nbsp; </span><span class="default">$closure </span><span class="keyword">= function() {<br />&nbsp; &nbsp; &nbsp; &nbsp; global </span><span class="default">$variable</span><span class="keyword">;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">$variable </span><span class="keyword">. </span><span class="string">"\n"</span><span class="keyword">;<br />&nbsp; &nbsp; };<br /><br />&nbsp; &nbsp; </span><span class="default">$closure</span><span class="keyword">();<br /><br />&nbsp; &nbsp; function </span><span class="default">test</span><span class="keyword">(</span><span class="default">$closure</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; global </span><span class="default">$variable</span><span class="keyword">; </span><span class="comment">//Note the scope added here <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$variable </span><span class="keyword">= </span><span class="string">"second"</span><span class="keyword">;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$closure</span><span class="keyword">();<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="default">test</span><span class="keyword">(</span><span class="default">$closure</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />prints:<br />first<br />second<br /><br />tested with php 5.3.1</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120612">  <div class="votes">
    <div id="Vu120612">
    <a href="/manual/vote-note.php?id=120612&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120612">
    <a href="/manual/vote-note.php?id=120612&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120612" title="100% like this...">
    2
    </div>
  </div>
  <a href="#120612" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#120612"> &para;</a><div class="date" title="2017-02-07 07:48"><strong>10 months ago</strong></div>
  <div class="text" id="Hcom120612">
<div class="phpcode"><code><span class="html">
If you want to create and then immediately call a closure directly, in-line, and immediately get its return value (instead of the closure reference itself), then the proper syntax is as follows:<br /><br /><span class="default">&lt;?php<br /><br />$a </span><span class="keyword">= </span><span class="string">'foo'</span><span class="keyword">; </span><span class="default">$b </span><span class="keyword">= </span><span class="string">'bar'</span><span class="keyword">;<br /></span><span class="default">$test </span><span class="keyword">= (function() use(</span><span class="default">$a</span><span class="keyword">,</span><span class="default">$b</span><span class="keyword">) { return </span><span class="default">$a </span><span class="keyword">. </span><span class="default">$b</span><span class="keyword">; })();<br />echo </span><span class="default">$test</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;<br /></span><br />As for why you would want to do that? Well, that's up to you. I'm sure there are some legitimate reasons. It's a pretty common pattern in some other famous scripting languages. But if you're doing this in PHP, you should think carefully and ask yourself if you really have a good reason for it, or if you should just go and re-structure your code instead. ;-)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121034">  <div class="votes">
    <div id="Vu121034">
    <a href="/manual/vote-note.php?id=121034&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121034">
    <a href="/manual/vote-note.php?id=121034&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121034" title="50% like this...">
    0
    </div>
  </div>
  <a href="#121034" class="name">
  <strong class="user"><em>ayon at hyurl dot com</em></strong></a><a class="genanchor" href="#121034"> &para;</a><div class="date" title="2017-04-29 05:35"><strong>7 months ago</strong></div>
  <div class="text" id="Hcom121034">
<div class="phpcode"><code><span class="html">
One way to call a anonymous function recursively is to use the USE keyword and pass a reference to the function itself:<br /><br /><span class="default">&lt;?php<br />$count </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br /></span><span class="default">$add </span><span class="keyword">= function(</span><span class="default">$count</span><span class="keyword">) use (&amp;</span><span class="default">$add</span><span class="keyword">){<br />&nbsp; &nbsp; </span><span class="default">$count </span><span class="keyword">+= </span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; if(</span><span class="default">$count </span><span class="keyword">&lt; </span><span class="default">10</span><span class="keyword">) </span><span class="default">$count </span><span class="keyword">= </span><span class="default">$add</span><span class="keyword">(</span><span class="default">$count</span><span class="keyword">); </span><span class="comment">//recursive calling<br />&nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">$count</span><span class="keyword">;<br />};<br />echo </span><span class="default">$add</span><span class="keyword">(</span><span class="default">$count</span><span class="keyword">); </span><span class="comment">//Will output 10 as expected<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120396">  <div class="votes">
    <div id="Vu120396">
    <a href="/manual/vote-note.php?id=120396&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120396">
    <a href="/manual/vote-note.php?id=120396&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120396" title="0% like this...">
    -2
    </div>
  </div>
  <a href="#120396" class="name">
  <strong class="user"><em>marcio dot a dot siena at gmail dot com</em></strong></a><a class="genanchor" href="#120396"> &para;</a><div class="date" title="2016-12-31 03:33"><strong>11 months ago</strong></div>
  <div class="text" id="Hcom120396">
<div class="phpcode"><code><span class="html">
A simple trick to call an anonymous function from inside itself.<br />Please note the use of a global variable and, therefore, the limitations of this hack:<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="comment">// Counts recursively from $x down to 0<br />&nbsp; &nbsp; </span><span class="default">$ref </span><span class="keyword">= function(</span><span class="default">$x</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; global </span><span class="default">$ref</span><span class="keyword">; </span><span class="comment">// reference to global that references this anonymous function<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">echo </span><span class="string">"Counting </span><span class="default">$x</span><span class="string"> &lt;br/&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$x </span><span class="keyword">&gt; </span><span class="default">0</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$ref</span><span class="keyword">(</span><span class="default">$x </span><span class="keyword">- </span><span class="default">1</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; };<br /><br />&nbsp; &nbsp; </span><span class="default">$ref</span><span class="keyword">(</span><span class="default">3</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />OUTPUT:<br /><br />Counting 3 <br />Counting 2 <br />Counting 1 <br />Counting 0</span>
</code></div>
  </div>
 </div>
  <div class="note" id="100649">  <div class="votes">
    <div id="Vu100649">
    <a href="/manual/vote-note.php?id=100649&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd100649">
    <a href="/manual/vote-note.php?id=100649&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V100649" title="46% like this...">
    -1
    </div>
  </div>
  <a href="#100649" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#100649"> &para;</a><div class="date" title="2010-10-28 12:54"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom100649">
<div class="phpcode"><code><span class="html">
use() parameters are early binding - they use the variable's value at the point where the lambda function is declared, rather than the point where the lambda function is called (late binding).<br /><br />If you want late binding put &amp; before the variable inside use()<br /><span class="default">&lt;?php<br />$fn </span><span class="keyword">= function () use (&amp;</span><span class="default">$var</span><span class="keyword">) { echo </span><span class="default">$var</span><span class="keyword">; };<br /></span><span class="default">?&gt;<br /></span>Examples:<br /><span class="default">&lt;?php<br /></span><span class="comment">// problem 1: this should echo "Canada", not a php notice<br /></span><span class="default">$fn </span><span class="keyword">= function () use (</span><span class="default">$country</span><span class="keyword">) { echo </span><span class="default">$country </span><span class="keyword">. </span><span class="string">"\n"</span><span class="keyword">; };<br /></span><span class="default">$country </span><span class="keyword">= </span><span class="string">'Canada'</span><span class="keyword">;<br /></span><span class="default">$fn</span><span class="keyword">();<br /><br /></span><span class="comment">// problem 2: this should echo "Canada", not "UnitedStates"<br /></span><span class="default">$country </span><span class="keyword">= </span><span class="string">'UnitedStates'</span><span class="keyword">;<br /></span><span class="default">$fn </span><span class="keyword">= function () use (</span><span class="default">$country</span><span class="keyword">) { echo </span><span class="default">$country </span><span class="keyword">. </span><span class="string">"\n"</span><span class="keyword">; };<br /></span><span class="default">$country </span><span class="keyword">= </span><span class="string">'Canada'</span><span class="keyword">;<br /></span><span class="default">$fn</span><span class="keyword">();<br /><br /></span><span class="comment">// problem 3: this should echo "Canada", not "UnitedStates"<br /></span><span class="default">$country </span><span class="keyword">= (object)array(</span><span class="string">'name' </span><span class="keyword">=&gt; </span><span class="string">'UnitedStates'</span><span class="keyword">);<br /></span><span class="default">$fn </span><span class="keyword">= function () use (</span><span class="default">$country</span><span class="keyword">) { echo </span><span class="default">$country</span><span class="keyword">-&gt;</span><span class="default">name </span><span class="keyword">. </span><span class="string">"\n"</span><span class="keyword">; };<br /></span><span class="default">$country </span><span class="keyword">= (object)array(</span><span class="string">'name' </span><span class="keyword">=&gt; </span><span class="string">'Canada'</span><span class="keyword">);<br /></span><span class="default">$fn</span><span class="keyword">();<br /><br /></span><span class="comment">// problem 4: this outputs "Canada". if this outputs "Canada",<br />// then so should problem 2 above. otherwise this should be<br />// just as broken as problem 2 and be outputting "UnitedStates"<br /></span><span class="default">$country </span><span class="keyword">= (object)array(</span><span class="string">'name' </span><span class="keyword">=&gt; </span><span class="string">'UnitedStates'</span><span class="keyword">);<br /></span><span class="default">$fn </span><span class="keyword">= function () use (</span><span class="default">$country</span><span class="keyword">) { echo </span><span class="default">$country</span><span class="keyword">-&gt;</span><span class="default">name </span><span class="keyword">. </span><span class="string">"\n"</span><span class="keyword">; };<br /></span><span class="default">$country</span><span class="keyword">-&gt;</span><span class="default">name </span><span class="keyword">= </span><span class="string">'Canada'</span><span class="keyword">;<br /></span><span class="default">$fn</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span>see <a href="http://bugs.php.net/bug.php?id=50980" rel="nofollow" target="_blank">http://bugs.php.net/bug.php?id=50980</a><br />(I've just quoted from there, but if you want you can read there the whole feature request)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="97296">  <div class="votes">
    <div id="Vu97296">
    <a href="/manual/vote-note.php?id=97296&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd97296">
    <a href="/manual/vote-note.php?id=97296&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V97296" title="40% like this...">
    -2
    </div>
  </div>
  <a href="#97296" class="name">
  <strong class="user"><em>Hayley Watson</em></strong></a><a class="genanchor" href="#97296"> &para;</a><div class="date" title="2010-04-12 06:53"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom97296">
<div class="phpcode"><code><span class="html">
In the code<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">new_counter</span><span class="keyword">()<br />{<br />&nbsp; &nbsp; </span><span class="default">$counter </span><span class="keyword">= </span><span class="default">mt_rand</span><span class="keyword">();<br />&nbsp; &nbsp; return function()use(&amp;</span><span class="default">$counter</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return ++</span><span class="default">$counter</span><span class="keyword">;<br />&nbsp; &nbsp; };<br />}<br /><br /></span><span class="default">$t1 </span><span class="keyword">= </span><span class="default">new_counter</span><span class="keyword">();<br /></span><span class="default">$t2 </span><span class="keyword">= </span><span class="default">new_counter</span><span class="keyword">();<br /><br />echo </span><span class="default">$t1</span><span class="keyword">(),</span><span class="string">"\n"</span><span class="keyword">;<br />echo </span><span class="default">$t1</span><span class="keyword">(),</span><span class="string">"\n"</span><span class="keyword">;<br />echo </span><span class="default">$t2</span><span class="keyword">(),</span><span class="string">"\n"</span><span class="keyword">;<br />echo </span><span class="default">$t2</span><span class="keyword">(),</span><span class="string">"\n"</span><span class="keyword">;<br />echo </span><span class="default">$t1</span><span class="keyword">(),</span><span class="string">"\n"</span><span class="keyword">;<br />echo </span><span class="default">$t1</span><span class="keyword">(),</span><span class="string">"\n"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />The variable $counter is local to new_counter() and is used by reference by the returned lambda function.<br /><br />Because $counter is not static, a new variable is created each time new_counter() is called.<br /><br />But because the lambda function uses a REFERENCE to the $counter variable - and not a new local variable with a copy of the value $counter had when the lambda function was constructed - the $counter variable created when new_counter() ran still exists (because a reference to it still exists).<br /><br />Every lambda function has a variable reference "hardwired" into it. That variable therefore persists across calls to the lambda function - rather like a static variable.<br /><br />But that variable is only LOCAL to the new_counter() function that created it. As soon as new_counter() returns, it gives up its reference to $counter. When new_counter() is called again, it gets allocated a NEW $counter variable and gives a reference to THAT variable to the lambda function it constructs.<br /><br />So the lambda functions in $t1 and $t2 each have their OWN $counter variable - separate from the other's, which persists from one call to the next.<br /><br />The effect is very similar to declaring and initialising $counter as static within the lambda function - and then it doesn't need to use anything from new_counter() - but you can't initialise a static variable with a function call like mt_rand()!<br /><br />Pending a decision on what it should mean, $this is not currently (as of 5.3.2) usable within anonymous functions.<br /><br />There are roughly two positions (plus attempts at compromise), that can be called "early" and "late".<br /><br />Early: $this refers to the object in whose scope the anonymous function is constructed.<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Creator<br /></span><span class="keyword">{<br />&nbsp;&nbsp; public function </span><span class="default">make_anonymous</span><span class="keyword">()<br />&nbsp;&nbsp; {<br />&nbsp; &nbsp; &nbsp;&nbsp; return function()<br />&nbsp; &nbsp; &nbsp;&nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; return </span><span class="default">$this</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp;&nbsp; };<br />&nbsp;&nbsp; }<br />}<br /><br />class </span><span class="default">Caller<br /></span><span class="keyword">{<br />&nbsp;&nbsp; public </span><span class="default">$p</span><span class="keyword">;<br />&nbsp;&nbsp; public function </span><span class="default">call_anonymous</span><span class="keyword">(</span><span class="default">$f</span><span class="keyword">)<br />&nbsp;&nbsp; {<br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">p </span><span class="keyword">= </span><span class="default">$f</span><span class="keyword">();<br />&nbsp;&nbsp; }<br />}<br /><br /></span><span class="default">$alpha </span><span class="keyword">= new </span><span class="default">Creator</span><span class="keyword">;<br /></span><span class="default">$omega </span><span class="keyword">= new </span><span class="default">Caller</span><span class="keyword">;<br /></span><span class="default">$omega</span><span class="keyword">-&gt;</span><span class="default">call_anonymous</span><span class="keyword">(</span><span class="default">$alpha</span><span class="keyword">-&gt;</span><span class="default">create_anonymous</span><span class="keyword">());<br /></span><span class="comment">// $omega-&gt;p === $alpha<br /></span><span class="default">?&gt;<br /></span><br />Late: $this refers to the object in whose scope the anonymous function is called.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Creator<br /></span><span class="keyword">{<br />&nbsp;&nbsp; public function </span><span class="default">make_anonymous</span><span class="keyword">()<br />&nbsp;&nbsp; {<br />&nbsp; &nbsp; &nbsp;&nbsp; return function()<br />&nbsp; &nbsp; &nbsp;&nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; return </span><span class="default">$this</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp;&nbsp; };<br />&nbsp;&nbsp; }<br />}<br /><br />class </span><span class="default">Caller<br /></span><span class="keyword">{<br />&nbsp;&nbsp; public </span><span class="default">$p</span><span class="keyword">;<br />&nbsp;&nbsp; public function </span><span class="default">call_anonymous</span><span class="keyword">(</span><span class="default">$f</span><span class="keyword">)<br />&nbsp;&nbsp; {<br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">p </span><span class="keyword">= </span><span class="default">$f</span><span class="keyword">();<br />&nbsp;&nbsp; }<br />}<br /><br /></span><span class="default">$alpha </span><span class="keyword">= new </span><span class="default">Creator</span><span class="keyword">;<br /></span><span class="default">$omega </span><span class="keyword">= new </span><span class="default">Caller</span><span class="keyword">;<br /></span><span class="default">$omega</span><span class="keyword">-&gt;</span><span class="default">call_anonymous</span><span class="keyword">(</span><span class="default">$alpha</span><span class="keyword">-&gt;</span><span class="default">create_anonymous</span><span class="keyword">());<br /></span><span class="comment">// $omega-&gt;p === $omega<br /></span><span class="default">?&gt;<br /></span><br />So until this is cleared up, $this won't work in an anonymous function. (Personally, I favour the early method; otherwise the anonymous function - and therefore its Creator - has access to all of the Caller's private properties.)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="95778">  <div class="votes">
    <div id="Vu95778">
    <a href="/manual/vote-note.php?id=95778&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd95778">
    <a href="/manual/vote-note.php?id=95778&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V95778" title="40% like this...">
    -2
    </div>
  </div>
  <a href="#95778" class="name">
  <strong class="user"><em>kwilson at shuttlebox dot net</em></strong></a><a class="genanchor" href="#95778"> &para;</a><div class="date" title="2010-01-21 07:24"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom95778">
<div class="phpcode"><code><span class="html">
Using the global keyword apparently pulls variables from the scope where the function was created, not where it is executed. <br /><br />Example:<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; $variable </span><span class="keyword">= </span><span class="string">"first"</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="default">$closure </span><span class="keyword">= function() {<br />&nbsp; &nbsp; &nbsp; &nbsp; global </span><span class="default">$variable</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">$variable </span><span class="keyword">. </span><span class="string">"\n"</span><span class="keyword">;<br />&nbsp; &nbsp; };<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="default">$closure</span><span class="keyword">();<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">test</span><span class="keyword">(</span><span class="default">$closure</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$variable </span><span class="keyword">= </span><span class="string">"second"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$closure</span><span class="keyword">();<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="default">test</span><span class="keyword">(</span><span class="default">$closure</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />Will print:<br /><br />first<br />first</span>
</code></div>
  </div>
 </div>
  <div class="note" id="93935">  <div class="votes">
    <div id="Vu93935">
    <a href="/manual/vote-note.php?id=93935&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd93935">
    <a href="/manual/vote-note.php?id=93935&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V93935" title="40% like this...">
    -3
    </div>
  </div>
  <a href="#93935" class="name">
  <strong class="user"><em>gerard at visei dot nl</em></strong></a><a class="genanchor" href="#93935"> &para;</a><div class="date" title="2009-10-07 07:41"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom93935">
<div class="phpcode"><code><span class="html">
The text above the third example tries to explain that anonymous functions can inherit variables from the parent scope, but fails to properly explain how this is done: namely using the "use" keyword in the function definition.<br /><br />The following page has a much more detailed explanation of closures in PHP 5.3:<br /><a href="http://wiki.php.net/rfc/closures" rel="nofollow" target="_blank">http://wiki.php.net/rfc/closures</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="92818">  <div class="votes">
    <div id="Vu92818">
    <a href="/manual/vote-note.php?id=92818&amp;page=functions.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd92818">
    <a href="/manual/vote-note.php?id=92818&amp;page=functions.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V92818" title="26% like this...">
    -7
    </div>
  </div>
  <a href="#92818" class="name">
  <strong class="user"><em>dave at mausner dot us</em></strong></a><a class="genanchor" href="#92818"> &para;</a><div class="date" title="2009-08-10 02:34"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom92818">
<div class="phpcode"><code><span class="html">
Ulderico had it almost right.&nbsp; To avoid confusing the interpreter, when using a simple closure stored in a $variable, you must invoke the nameless function using the function syntax.<br /><br /><span class="default">&lt;?php <br />$helloworld </span><span class="keyword">= function(){ <br />&nbsp; &nbsp; return </span><span class="string">"each hello world is different... "</span><span class="keyword">.</span><span class="default">date</span><span class="keyword">(</span><span class="string">"His"</span><span class="keyword">); <br />}; <br /><br />echo </span><span class="default">$helloworld</span><span class="keyword">( ); <br /></span><span class="default">?&gt;</span> <br /><br />Note the empty actual-parameter list in the "echo".&nbsp; NOW IT WORKS.</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=functions.anonymous&amp;redirect=http://php.net/manual/en/functions.anonymous.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.functions.php">Functions</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="functions.user-defined.php" title="User-&#8203;defined functions">User-&#8203;defined functions</a>
                        </li>
                          
                        <li class="">
                            <a href="functions.arguments.php" title="Function arguments">Function arguments</a>
                        </li>
                          
                        <li class="">
                            <a href="functions.returning-values.php" title="Returning values">Returning values</a>
                        </li>
                          
                        <li class="">
                            <a href="functions.variable-functions.php" title="Variable functions">Variable functions</a>
                        </li>
                          
                        <li class="">
                            <a href="functions.internal.php" title="Internal (built-&#8203;in) functions">Internal (built-&#8203;in) functions</a>
                        </li>
                          
                        <li class="current">
                            <a href="functions.anonymous.php" title="Anonymous functions">Anonymous functions</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

