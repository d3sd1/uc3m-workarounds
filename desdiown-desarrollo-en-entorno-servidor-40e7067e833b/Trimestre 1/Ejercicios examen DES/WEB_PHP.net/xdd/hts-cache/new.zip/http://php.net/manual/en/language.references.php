<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: References Explained - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.references.php">
 <link rel="shorturl" href="http://php.net/references">
 <link rel="alternate" href="http://php.net/references" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/langref.php">
 <link rel="prev" href="http://php.net/manual/en/language.generators.comparison.php">
 <link rel="next" href="http://php.net/manual/en/language.references.whatare.php">

 <link rel="alternate" href="http://php.net/manual/en/language.references.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.references.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.references.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.references.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.references.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.references.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.references.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.references.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.references.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.references.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.references.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.references.whatare.php">
          What References Are &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.generators.comparison.php">
          &laquo; Comparing generators with Iterator objects        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.references.php' selected="selected">English</option>
            <option value='pt_BR/language.references.php'>Brazilian Portuguese</option>
            <option value='zh/language.references.php'>Chinese (Simplified)</option>
            <option value='fr/language.references.php'>French</option>
            <option value='de/language.references.php'>German</option>
            <option value='ja/language.references.php'>Japanese</option>
            <option value='ro/language.references.php'>Romanian</option>
            <option value='ru/language.references.php'>Russian</option>
            <option value='es/language.references.php'>Spanish</option>
            <option value='tr/language.references.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.references.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.references">Report a Bug</a>
    </div>
  </div><div id="language.references" class="chapter">
  <h1>References Explained</h1>
<h2>Table of Contents</h2><ul class="chunklist chunklist_chapter"><li><a href="language.references.whatare.php">What References Are</a></li><li><a href="language.references.whatdo.php">What References Do</a></li><li><a href="language.references.arent.php">What References Are Not</a></li><li><a href="language.references.pass.php">Passing by Reference</a></li><li><a href="language.references.return.php">Returning References</a></li><li><a href="language.references.unset.php">Unsetting References</a></li><li><a href="language.references.spot.php">Spotting References</a></li></ul>

  
  

  

  

  

  

  

  

 </div>

<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.references&amp;redirect=http://php.net/manual/en/language.references.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">48 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="83325">  <div class="votes">
    <div id="Vu83325">
    <a href="/manual/vote-note.php?id=83325&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd83325">
    <a href="/manual/vote-note.php?id=83325&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V83325" title="68% like this...">
    37
    </div>
  </div>
  <a href="#83325" class="name">
  <strong class="user"><em>Dave at SymmetricDesigns dot com</em></strong></a><a class="genanchor" href="#83325"> &para;</a><div class="date" title="2008-05-20 11:24"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom83325">
<div class="phpcode"><code><span class="html">
Another example of something to watch out for when using references with arrays.&nbsp; It seems that even an usused reference to an array cell modifies the *source* of the reference.&nbsp; Strange behavior for an assignment statement (is this why I've seen it written as an =&amp; operator?&nbsp; - although this doesn't happen with regular variables).<br /><span class="default">&lt;?php<br />&nbsp; &nbsp; $array1 </span><span class="keyword">= array(</span><span class="default">1</span><span class="keyword">,</span><span class="default">2</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$x </span><span class="keyword">= &amp;</span><span class="default">$array1</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">];&nbsp;&nbsp; </span><span class="comment">// Unused reference<br />&nbsp; &nbsp; </span><span class="default">$array2 </span><span class="keyword">= </span><span class="default">$array1</span><span class="keyword">;&nbsp; </span><span class="comment">// reference now also applies to $array2 !<br />&nbsp; &nbsp; </span><span class="default">$array2</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]=</span><span class="default">22</span><span class="keyword">;&nbsp; &nbsp; &nbsp; </span><span class="comment">// (changing [0] will not affect $array1)<br />&nbsp; &nbsp; </span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$array1</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span>Produces:<br />&nbsp; &nbsp; Array<br />&nbsp; &nbsp; (<br />&nbsp; &nbsp; [0] =&gt; 1<br />&nbsp; &nbsp; [1] =&gt; 22&nbsp; &nbsp; // var_dump() will show the &amp; here<br />&nbsp; &nbsp; )<br /><br />I fixed my bug by rewriting the code without references, but it can also be fixed with the unset() function:<br /><span class="default">&lt;?php<br />&nbsp; &nbsp; $array1 </span><span class="keyword">= array(</span><span class="default">1</span><span class="keyword">,</span><span class="default">2</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$x </span><span class="keyword">= &amp;</span><span class="default">$array1</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">];<br />&nbsp; &nbsp; </span><span class="default">$array2 </span><span class="keyword">= </span><span class="default">$array1</span><span class="keyword">;<br />&nbsp; &nbsp; unset(</span><span class="default">$x</span><span class="keyword">); </span><span class="comment">// Array copy is now unaffected by above reference<br />&nbsp; &nbsp; </span><span class="default">$array2</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]=</span><span class="default">22</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$array1</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span>Produces:<br />&nbsp; &nbsp; Array<br />&nbsp; &nbsp; (<br />&nbsp; &nbsp; [0] =&gt; 1<br />&nbsp; &nbsp; [1] =&gt; 2<br />&nbsp; &nbsp; )</span>
</code></div>
  </div>
 </div>
  <div class="note" id="87532">  <div class="votes">
    <div id="Vu87532">
    <a href="/manual/vote-note.php?id=87532&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd87532">
    <a href="/manual/vote-note.php?id=87532&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V87532" title="56% like this...">
    18
    </div>
  </div>
  <a href="#87532" class="name">
  <strong class="user"><em>ivan at mailinator dot com</em></strong></a><a class="genanchor" href="#87532"> &para;</a><div class="date" title="2008-12-09 05:09"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom87532">
<div class="phpcode"><code><span class="html">
A little gotcha (be careful with references!):<br /><br /><span class="default">&lt;?php<br />$arr </span><span class="keyword">= array(</span><span class="string">'a'</span><span class="keyword">=&gt;</span><span class="string">'first'</span><span class="keyword">, </span><span class="string">'b'</span><span class="keyword">=&gt;</span><span class="string">'second'</span><span class="keyword">, </span><span class="string">'c'</span><span class="keyword">=&gt;</span><span class="string">'third'</span><span class="keyword">);<br />foreach (</span><span class="default">$arr </span><span class="keyword">as &amp;</span><span class="default">$a</span><span class="keyword">); </span><span class="comment">// do nothing. maybe?<br /></span><span class="keyword">foreach (</span><span class="default">$arr </span><span class="keyword">as </span><span class="default">$a</span><span class="keyword">);&nbsp; </span><span class="comment">// do nothing. maybe?<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$arr</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span>Output:<br /><br />Array<br />(<br />&nbsp; &nbsp; [a] =&gt; first<br />&nbsp; &nbsp; [b] =&gt; second<br />&nbsp; &nbsp; [c] =&gt; second<br />)<br /><br />Add 'unset($a)' between the foreachs to obtain the 'correct' output:<br /><br />Array<br />(<br />&nbsp; &nbsp; [a] =&gt; first<br />&nbsp; &nbsp; [b] =&gt; second<br />&nbsp; &nbsp; [c] =&gt; third<br />)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="70852">  <div class="votes">
    <div id="Vu70852">
    <a href="/manual/vote-note.php?id=70852&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd70852">
    <a href="/manual/vote-note.php?id=70852&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V70852" title="64% like this...">
    9
    </div>
  </div>
  <a href="#70852" class="name">
  <strong class="user"><em>sneskid at hotmail dot com</em></strong></a><a class="genanchor" href="#70852"> &para;</a><div class="date" title="2006-10-31 09:33"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom70852">
<div class="phpcode"><code><span class="html">
in addition to what 'jw at jwscripts dot com' wrote about unset; it can also be used to "detach" the variable alias so that it may work on a unique piece of memory again.<br /><br />here's an example<br /><br /><span class="default">&lt;?php<br />define</span><span class="keyword">(</span><span class="string">'NL'</span><span class="keyword">, </span><span class="string">"\r\n"</span><span class="keyword">);<br /><br /></span><span class="default">$v1 </span><span class="keyword">= </span><span class="string">'shared'</span><span class="keyword">;<br /></span><span class="default">$v2 </span><span class="keyword">= &amp;</span><span class="default">$v1</span><span class="keyword">;<br /></span><span class="default">$v3 </span><span class="keyword">= &amp;</span><span class="default">$v2</span><span class="keyword">;<br /></span><span class="default">$v4 </span><span class="keyword">= &amp;</span><span class="default">$v3</span><span class="keyword">;<br /><br />echo </span><span class="string">'before:'</span><span class="keyword">.</span><span class="default">NL</span><span class="keyword">;<br />echo </span><span class="string">'v1=' </span><span class="keyword">. </span><span class="default">$v1 </span><span class="keyword">. </span><span class="default">NL</span><span class="keyword">;<br />echo </span><span class="string">'v2=' </span><span class="keyword">. </span><span class="default">$v2 </span><span class="keyword">. </span><span class="default">NL</span><span class="keyword">;<br />echo </span><span class="string">'v3=' </span><span class="keyword">. </span><span class="default">$v3 </span><span class="keyword">. </span><span class="default">NL</span><span class="keyword">;<br />echo </span><span class="string">'v4=' </span><span class="keyword">. </span><span class="default">$v4 </span><span class="keyword">. </span><span class="default">NL</span><span class="keyword">;<br /><br /></span><span class="comment">// detach messy<br /></span><span class="default">$detach </span><span class="keyword">= </span><span class="default">$v1</span><span class="keyword">;<br />unset(</span><span class="default">$v1</span><span class="keyword">);<br /></span><span class="default">$v1 </span><span class="keyword">= </span><span class="default">$detach</span><span class="keyword">;<br /><br /></span><span class="comment">// detach pretty, but slower<br /></span><span class="keyword">eval(</span><span class="default">detach</span><span class="keyword">(</span><span class="string">'$v2'</span><span class="keyword">));<br /><br /></span><span class="default">$v1 </span><span class="keyword">.= </span><span class="string">'?'</span><span class="keyword">;<br /></span><span class="default">$v2 </span><span class="keyword">.= </span><span class="string">' no more'</span><span class="keyword">;<br /></span><span class="default">$v3 </span><span class="keyword">.= </span><span class="string">' sti'</span><span class="keyword">;<br /></span><span class="default">$v4 </span><span class="keyword">.= </span><span class="string">'ll'</span><span class="keyword">;<br /><br />echo </span><span class="default">NL</span><span class="keyword">.</span><span class="string">'after:'</span><span class="keyword">.</span><span class="default">NL</span><span class="keyword">;<br />echo </span><span class="string">'v1=' </span><span class="keyword">. </span><span class="default">$v1 </span><span class="keyword">. </span><span class="default">NL</span><span class="keyword">;<br />echo </span><span class="string">'v2=' </span><span class="keyword">. </span><span class="default">$v2 </span><span class="keyword">. </span><span class="default">NL</span><span class="keyword">;<br />echo </span><span class="string">'v3=' </span><span class="keyword">. </span><span class="default">$v3 </span><span class="keyword">. </span><span class="default">NL</span><span class="keyword">;<br />echo </span><span class="string">'v4=' </span><span class="keyword">. </span><span class="default">$v4 </span><span class="keyword">. </span><span class="default">NL</span><span class="keyword">;<br /><br />function </span><span class="default">detach</span><span class="keyword">(</span><span class="default">$v</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$e </span><span class="keyword">= </span><span class="string">'$detach = ' </span><span class="keyword">. </span><span class="default">$v </span><span class="keyword">. </span><span class="string">';'</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$e </span><span class="keyword">.= </span><span class="string">'unset('</span><span class="keyword">.</span><span class="default">$v</span><span class="keyword">.</span><span class="string">');'</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$e </span><span class="keyword">.= </span><span class="default">$v </span><span class="keyword">. </span><span class="string">' = $detach;'</span><span class="keyword">;<br />&nbsp; &nbsp; return </span><span class="default">$e</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />output {<br />before:<br />v1=shared<br />v2=shared<br />v3=shared<br />v4=shared<br /><br />after:<br />v1=shared?<br />v2=shared no more<br />v3=shared still<br />v4=shared still<br />}<br /><br /><a href="http://www.obdev.at/developers/articles/00002.html" rel="nofollow" target="_blank">http://www.obdev.at/developers/articles/00002.html</a> says there's no such thing as an "object reference" in PHP, but with detaching it becomes possible.<br /><br />Hopefully detach, or something like it, will become a language construct in the future.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="89264">  <div class="votes">
    <div id="Vu89264">
    <a href="/manual/vote-note.php?id=89264&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd89264">
    <a href="/manual/vote-note.php?id=89264&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V89264" title="58% like this...">
    12
    </div>
  </div>
  <a href="#89264" class="name">
  <strong class="user"><em>midir</em></strong></a><a class="genanchor" href="#89264"> &para;</a><div class="date" title="2009-02-28 11:44"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom89264">
<div class="phpcode"><code><span class="html">
Here is a good magazine article (PDF format) that explains the internals of PHP's reference mechanism in detail: <a href="http://derickrethans.nl/files/phparch-php-variables-article.pdf" rel="nofollow" target="_blank">http://derickrethans.nl/files/phparch-php-variables-article.pdf</a><br /><br />It should explain some of the odd behavior PHP sometimes seems to exhibit, as well as why you can't create "references to references" (unlike in C++), and why you should never attempt to use references to speed up passing of large strings or arrays (it will make no difference, or it will slow things down).<br /><br />It was written for PHP 4 but it still applies. The only difference is in how PHP 5 handles objects: passing object variables by value only copies an internal pointer to the object. Objects in PHP 5 are only ever duplicated if you explicitly use the clone keyword.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118500">  <div class="votes">
    <div id="Vu118500">
    <a href="/manual/vote-note.php?id=118500&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118500">
    <a href="/manual/vote-note.php?id=118500&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118500" title="60% like this...">
    7
    </div>
  </div>
  <a href="#118500" class="name">
  <strong class="user"><em>Someone</em></strong></a><a class="genanchor" href="#118500"> &para;</a><div class="date" title="2015-12-16 09:37"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom118500">
<div class="phpcode"><code><span class="html">
Another example of something to watch out for when using references with arrays.&nbsp; It seems that even an usused reference to an array cell modifies the *source* of the reference.&nbsp; Strange behavior for an assignment statement (is this why I've seen it written as an =&amp; operator?&nbsp; - although this doesn't happen with regular variables).<br /><span class="default">&lt;?php<br />&nbsp; &nbsp; $array1 </span><span class="keyword">= array(</span><span class="default">1</span><span class="keyword">,</span><span class="default">2</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$x </span><span class="keyword">= &amp;</span><span class="default">$array1</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">];&nbsp;&nbsp; </span><span class="comment">// Unused reference<br />&nbsp; &nbsp; </span><span class="default">$array2 </span><span class="keyword">= </span><span class="default">$array1</span><span class="keyword">;&nbsp; </span><span class="comment">// reference now also applies to $array2 !<br />&nbsp; &nbsp; </span><span class="default">$array2</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]=</span><span class="default">22</span><span class="keyword">;&nbsp; &nbsp; &nbsp; </span><span class="comment">// (changing [0] will not affect $array1)<br />&nbsp; &nbsp; </span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$array1</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span>Produces:<br />&nbsp; &nbsp; Array<br />&nbsp; &nbsp; (<br />&nbsp; &nbsp; [0] =&gt; 1<br />&nbsp; &nbsp; [1] =&gt; 22&nbsp; &nbsp; // var_dump() will show the &amp; here<br />&nbsp; &nbsp; )<br /><br />//above was Noted By Dave at SymmetricDesign dot com//<br />//and below is my opinion to this simple problem. //<br /><br />This is an normal referencing problem.<br /><br />when you gain an reference to a memory at some variable.<br />this variable, means "memory itself". (in above example, this would be -&gt;&nbsp; $x = &amp;$array1[1];&nbsp;&nbsp; // Unused reference)<br /><br />and you've copied original one($array1) to another one($array2).<br />and the copy means "paste everything on itself". including references or pointers, etcs. so, when you copied $array1 to $array2, this $array2 has same referencers that original $array1 has. meaning that $x = &amp;$array1[1]&nbsp; = &amp;$array2[1];<br />and again i said above. this reference means "memory itself".<br />when you choose to inserting some values to $array2[1], <br />$x; reference is affected by $array2[1]'s value. because, in allocated memory, $array2[1] is a copy of $array1[1]. this means that $array2[1] = $array1[1], also means &amp;$array2[1] = &amp;$array1[1]&nbsp; as said above. this causes memory's&nbsp; value reallocation on $array1[1]. at this moment. the problem of this topic is cleared by '$x', the memory itself.&nbsp; and this problem was solved by unsetting the '$x'. unsetting this reference triggers memory reallocation of $array2[1]. this closes the reference link between the copied one($array1, which is the original) and copy($array2). this is where that bug(clearly, it's not a bug. it's just a missunderstanding) has triggered by. closing reference link makes two array object to be separated on memory. and this work was done through the unset() function. this topic was posted 7 years ago, but i just want to clarify that it's not a bug.<br /><br />if there's some problems in my notes, plz, note that on above.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="83737">  <div class="votes">
    <div id="Vu83737">
    <a href="/manual/vote-note.php?id=83737&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd83737">
    <a href="/manual/vote-note.php?id=83737&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V83737" title="59% like this...">
    10
    </div>
  </div>
  <a href="#83737" class="name">
  <strong class="user"><em>dnhuff at acm dot org</em></strong></a><a class="genanchor" href="#83737"> &para;</a><div class="date" title="2008-06-09 12:40"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom83737">
<div class="phpcode"><code><span class="html">
This is discussed before (below) but bears repeating:<br /><br />$a = null; ($a =&amp; null; does not parse) is NOT the same as unset($a);<br /><br />$a = null; replaces the value at the destination of $a with the null value;<br /><br />If you chose to use a convention like $NULL = NULL;<br /><br />THEN, you could say $a =&amp; $NULL to break any previous reference assignment to $a (setting it of course to $NULL), which could still get you into trouble if you forgot and then said $a = '5'. Now $NULL would be '5'.<br /><br />Moral: use unset when it is called for.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="41300">  <div class="votes">
    <div id="Vu41300">
    <a href="/manual/vote-note.php?id=41300&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd41300">
    <a href="/manual/vote-note.php?id=41300&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V41300" title="64% like this...">
    5
    </div>
  </div>
  <a href="#41300" class="name">
  <strong class="user"><em>nathan</em></strong></a><a class="genanchor" href="#41300"> &para;</a><div class="date" title="2004-04-05 10:53"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom41300">
<div class="phpcode"><code><span class="html">
On the post that says php4 automagically makes references, this appears to *not* apply to objects:<br /><br /><a href="http://www.php.net/manual/en/language.references.whatdo.php" rel="nofollow" target="_blank">http://www.php.net/manual/en/language.references.whatdo.php</a><br /><br />"Note:&nbsp; Not using the &amp; operator causes a copy of the object to be made. If you use $this in the class it will operate on the current instance of the class. The assignment without &amp; will copy the instance (i.e. the object) and $this will operate on the copy, which is not always what is desired. Usually you want to have a single instance to work with, due to performance and memory consumption issues."</span>
</code></div>
  </div>
 </div>
  <div class="note" id="79086">  <div class="votes">
    <div id="Vu79086">
    <a href="/manual/vote-note.php?id=79086&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd79086">
    <a href="/manual/vote-note.php?id=79086&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V79086" title="61% like this...">
    5
    </div>
  </div>
  <a href="#79086" class="name">
  <strong class="user"><em>warnickr at gmail dot com</em></strong></a><a class="genanchor" href="#79086"> &para;</a><div class="date" title="2007-11-10 01:15"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom79086">
<div class="phpcode"><code><span class="html">
I must say that it has been rather confusing following all of the explanations of PHP references, especially since I've worked a lot with C pointers.&nbsp; As far as I can tell PHP references are the same as C pointers for all practical purposes.&nbsp; I think a lot of the confusion comes from examples like the one shown below where people expect that a C pointer version of this would change what $bar references.&nbsp; <br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">foo</span><span class="keyword">(&amp;</span><span class="default">$var</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="default">$var </span><span class="keyword">=&amp; </span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">"baz"</span><span class="keyword">];<br />}<br /></span><span class="default">foo</span><span class="keyword">(</span><span class="default">$bar</span><span class="keyword">); <br /></span><span class="default">?&gt;</span> <br /><br />This is not the case.&nbsp; In fact, a C pointer version of this example (shown below) would behave exactly the same way (it would not modify what bar references) as the PHP reference version.<br /><br />int baz = 5;<br />int* bar;<br />void foo(int* var)<br />{<br />&nbsp; &nbsp; var = &amp;baz;<br />}<br />foo(bar);<br /><br />In this case, just as in the case of PHP references, the call foo(bar) doesn't change what bar references.&nbsp; If you wanted to change what bar references, then you would need to work with a double pointer like so:<br /><br />int baz = 5;<br />int* bar;<br />void foo(int** var)<br />{<br />&nbsp; &nbsp; *var = &amp;baz;<br />}<br />foo(&amp;bar);</span>
</code></div>
  </div>
 </div>
  <div class="note" id="100451">  <div class="votes">
    <div id="Vu100451">
    <a href="/manual/vote-note.php?id=100451&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd100451">
    <a href="/manual/vote-note.php?id=100451&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V100451" title="59% like this...">
    6
    </div>
  </div>
  <a href="#100451" class="name">
  <strong class="user"><em>zoranbankovic at gmail dot com</em></strong></a><a class="genanchor" href="#100451"> &para;</a><div class="date" title="2010-10-16 01:59"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom100451">
<div class="phpcode"><code><span class="html">
If someone wants to add slashes to multidimensional array directly, can use recursive (pass-by-reference) function like this:<br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">slashit</span><span class="keyword">(&amp;</span><span class="default">$aray</span><span class="keyword">, </span><span class="default">$db_link</span><span class="keyword">)<br />{<br />&nbsp; foreach (</span><span class="default">$aray </span><span class="keyword">as </span><span class="default">$key </span><span class="keyword">=&gt; &amp;</span><span class="default">$value</span><span class="keyword">)<br />&nbsp;&nbsp; if(</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">)) </span><span class="default">slashit</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">, </span><span class="default">$link</span><span class="keyword">);<br />&nbsp;&nbsp; else </span><span class="default">$aray</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">] = </span><span class="default">mysql_real_escape_string</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">, </span><span class="default">$db_link</span><span class="keyword">);<br />}<br /><br /></span><span class="comment">// Test:<br /></span><span class="default">$fruits </span><span class="keyword">= array (<br />&nbsp; &nbsp; </span><span class="string">"fruits"&nbsp; </span><span class="keyword">=&gt; array(</span><span class="string">"a" </span><span class="keyword">=&gt; </span><span class="string">"or'ange"</span><span class="keyword">, </span><span class="string">"b" </span><span class="keyword">=&gt; </span><span class="string">"ban'ana"</span><span class="keyword">, </span><span class="string">"c" </span><span class="keyword">=&gt; </span><span class="string">"apple'"</span><span class="keyword">),<br />&nbsp; &nbsp; </span><span class="string">"numbers" </span><span class="keyword">=&gt; array(</span><span class="default">1</span><span class="keyword">, </span><span class="default">2</span><span class="keyword">, </span><span class="default">3</span><span class="keyword">, </span><span class="default">4</span><span class="keyword">, </span><span class="default">5</span><span class="keyword">, </span><span class="default">6</span><span class="keyword">),<br />&nbsp; &nbsp; </span><span class="string">"holes"&nbsp;&nbsp; </span><span class="keyword">=&gt; array(</span><span class="string">"fir'st"</span><span class="keyword">, </span><span class="default">5 </span><span class="keyword">=&gt; </span><span class="string">"sec'ond"</span><span class="keyword">, </span><span class="string">"thir'd"</span><span class="keyword">),<br />&nbsp; &nbsp; </span><span class="string">"odma"&nbsp; &nbsp; </span><span class="keyword">=&gt; </span><span class="string">"jugo'slavija"<br /></span><span class="keyword">);<br /><br /></span><span class="comment">// You have to make link to the database or can use addslashes instead of mysql_real_escape_string and remove $link from function definition<br /><br /></span><span class="default">slashit</span><span class="keyword">(</span><span class="default">$fruits</span><span class="keyword">, </span><span class="default">$dbLink</span><span class="keyword">);<br />echo </span><span class="string">"&lt;pre&gt;"</span><span class="keyword">; </span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$fruits</span><span class="keyword">); echo </span><span class="string">"&lt;/pre&gt;"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />// Output:<br />Array<br />(<br />&nbsp; &nbsp; [fruits] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [a] =&gt; or\'ange<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [b] =&gt; ban\'ana<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [c] =&gt; apple\'<br />&nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />&nbsp; &nbsp; [numbers] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0] =&gt; 1<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [1] =&gt; 2<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [2] =&gt; 3<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [3] =&gt; 4<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [4] =&gt; 5<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [5] =&gt; 6<br />&nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />&nbsp; &nbsp; [holes] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0] =&gt; fir\'st<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [5] =&gt; sec\'ond<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [6] =&gt; thir\'d<br />&nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />&nbsp; &nbsp; [odma] =&gt; jugo\'slavija<br />)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="84502">  <div class="votes">
    <div id="Vu84502">
    <a href="/manual/vote-note.php?id=84502&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd84502">
    <a href="/manual/vote-note.php?id=84502&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V84502" title="60% like this...">
    5
    </div>
  </div>
  <a href="#84502" class="name">
  <strong class="user"><em>zzo38</em></strong></a><a class="genanchor" href="#84502"> &para;</a><div class="date" title="2008-07-16 01:08"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom84502">
<div class="phpcode"><code><span class="html">
You can make references like pointers. Example:<br /><span class="default">&lt;?php<br />&nbsp; $a</span><span class="keyword">=</span><span class="default">6</span><span class="keyword">;<br />&nbsp; </span><span class="default">$b</span><span class="keyword">=array(&amp;</span><span class="default">$a</span><span class="keyword">); </span><span class="comment">// $b is a pointer to $a<br />&nbsp; </span><span class="default">$c</span><span class="keyword">=array(&amp;</span><span class="default">$b</span><span class="keyword">); </span><span class="comment">// $c is a pointer to $b<br />&nbsp; </span><span class="default">$d</span><span class="keyword">=</span><span class="default">7</span><span class="keyword">;<br />&nbsp; </span><span class="default">$c</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">][</span><span class="default">0</span><span class="keyword">]=</span><span class="default">9</span><span class="keyword">; </span><span class="comment">// $a is 9<br />&nbsp; </span><span class="default">$c</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]=array(&amp;</span><span class="default">$d</span><span class="keyword">); </span><span class="comment">// $b is a pointer to $d<br />&nbsp; </span><span class="default">$c</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">][</span><span class="default">0</span><span class="keyword">]=</span><span class="default">4</span><span class="keyword">; </span><span class="comment">// $d is 4<br />&nbsp; </span><span class="default">$b</span><span class="keyword">=array(&amp;</span><span class="default">$a</span><span class="keyword">); </span><span class="comment">// $b is a pointer to $a again<br />&nbsp; </span><span class="keyword">echo </span><span class="default">$a</span><span class="keyword">.</span><span class="default">$b</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">].</span><span class="default">$c</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">][</span><span class="default">0</span><span class="keyword">].</span><span class="default">$d</span><span class="keyword">; </span><span class="comment">// outputs 9994<br /></span><span class="default">?&gt;<br /></span>These kind of pointers may even be passed to functions or returned from functions, copied and stored in multiple arrays/variables/objects, etc.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="56115">  <div class="votes">
    <div id="Vu56115">
    <a href="/manual/vote-note.php?id=56115&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd56115">
    <a href="/manual/vote-note.php?id=56115&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V56115" title="62% like this...">
    4
    </div>
  </div>
  <a href="#56115" class="name">
  <strong class="user"><em>php at REMOVEMEkennel17 dot co dot uk</em></strong></a><a class="genanchor" href="#56115"> &para;</a><div class="date" title="2005-08-23 06:56"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom56115">
<div class="phpcode"><code><span class="html">
I found a very useful summary of how references work in PHP4 (and some of the common pitfalls) in this article: <a href="http://www.obdev.at/developers/articles/00002.html" rel="nofollow" target="_blank">http://www.obdev.at/developers/articles/00002.html</a><br /><br />It deals with some subtle situations and I recommend it to anyone having difficulty with their references.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="79220">  <div class="votes">
    <div id="Vu79220">
    <a href="/manual/vote-note.php?id=79220&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd79220">
    <a href="/manual/vote-note.php?id=79220&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V79220" title="61% like this...">
    4
    </div>
  </div>
  <a href="#79220" class="name">
  <strong class="user"><em>marco at greenlightsolutions dot nl</em></strong></a><a class="genanchor" href="#79220"> &para;</a><div class="date" title="2007-11-15 02:38"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom79220">
<div class="phpcode"><code><span class="html">
I ran into a bit of a problem recently, with an array copy resulting in a reference copy of one of the elements instead of a clone. Sample code:<br /><br /><span class="default">&lt;?php<br />$a</span><span class="keyword">=array(</span><span class="default">1 </span><span class="keyword">=&gt; </span><span class="string">"A"</span><span class="keyword">);<br /></span><span class="default">$b</span><span class="keyword">=&amp;</span><span class="default">$a</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">];<br /></span><span class="default">$c</span><span class="keyword">=</span><span class="default">$a</span><span class="keyword">; </span><span class="comment">// should be a deep cloning<br /></span><span class="default">$c</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]=</span><span class="string">"C"</span><span class="keyword">;<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]); </span><span class="comment">// yields 'C' instead of 'A'<br /></span><span class="default">?&gt;<br /></span><br />After some searching, I found that it was a known bug which would be too costly to fix (see <a href="http://bugs.php.net/bug.php?id=20993" rel="nofollow" target="_blank">http://bugs.php.net/bug.php?id=20993</a>). There was supposed to be some documentation on this behaviour on this page:<br /><br />"Due to peculiarities of the internal workings of PHP, if a reference&nbsp; is made to a single element of an array and then the array is copied, whether by assignment or when passed by value in a function call, the reference is copied as part of the array.&nbsp; This means that changes to any such elements in either array will be duplicated in the other array (and in the other references), even if the arrays have different scopes (e.g. one is an argument inside a function and the other is global)!&nbsp; Elements that did not have references at the time of the copy, as well as references assigned to those other elements after the copy of the array, will behave normally (i.e. independent of the other array)."<br /><br />However, this paragraph appears to have been removed from this page at some point, presumably because it was a bit obscure. The comments section seem to be a proper place for this, though.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="60986">  <div class="votes">
    <div id="Vu60986">
    <a href="/manual/vote-note.php?id=60986&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd60986">
    <a href="/manual/vote-note.php?id=60986&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V60986" title="61% like this...">
    4
    </div>
  </div>
  <a href="#60986" class="name">
  <strong class="user"><em>Ed</em></strong></a><a class="genanchor" href="#60986"> &para;</a><div class="date" title="2006-01-22 11:29"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom60986">
<div class="phpcode"><code><span class="html">
Responding to Slava Kudinov.&nbsp; The only reason why your script takes longer when you pass by reference is that you do not at all modify the array that your passing to your functions.&nbsp; If you do that the diffrences in execution time will be a lot smaller.&nbsp; In fact&nbsp; passing by reference will be faster if just by a little bit.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="50994">  <div class="votes">
    <div id="Vu50994">
    <a href="/manual/vote-note.php?id=50994&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd50994">
    <a href="/manual/vote-note.php?id=50994&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V50994" title="61% like this...">
    4
    </div>
  </div>
  <a href="#50994" class="name">
  <strong class="user"><em>nslater at gmail dot com</em></strong></a><a class="genanchor" href="#50994"> &para;</a><div class="date" title="2005-03-15 07:12"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom50994">
<div class="phpcode"><code><span class="html">
In addition to the note made by "Francis dot a at gmx dot net" you should not normally be using a function such as sizeof() or count() in a control structure such as FOR because the same value is being calculated repeatedly for each iteration. This can slow things down immensely, regardless of whether you pass by value or reference.<br /><br />It is generally much better to calculate the static values before the defining the looping control structure.<br /><br />Example:<br /><br /><span class="default">&lt;?php<br /><br />$intSize </span><span class="keyword">= </span><span class="default">sizeof</span><span class="keyword">(</span><span class="default">$arrData</span><span class="keyword">);<br /><br />for(</span><span class="default">$i </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">; </span><span class="default">$i </span><span class="keyword">&lt; </span><span class="default">$intSize</span><span class="keyword">; </span><span class="default">$n</span><span class="keyword">++) {<br />&nbsp; &nbsp; </span><span class="comment">// Do stuff<br /></span><span class="keyword">}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="46590">  <div class="votes">
    <div id="Vu46590">
    <a href="/manual/vote-note.php?id=46590&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd46590">
    <a href="/manual/vote-note.php?id=46590&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V46590" title="61% like this...">
    4
    </div>
  </div>
  <a href="#46590" class="name">
  <strong class="user"><em>jw at jwscripts dot com</em></strong></a><a class="genanchor" href="#46590"> &para;</a><div class="date" title="2004-10-16 05:18"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom46590">
<div class="phpcode"><code><span class="html">
Re-using variables which where references before, without unsetting them first, leads to unexpected behaviour.<br /><br />The following code:<br /><br /><span class="default">&lt;?php<br /><br />$numbers </span><span class="keyword">= array();<br /><br />for (</span><span class="default">$i </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">; </span><span class="default">$i </span><span class="keyword">&lt; </span><span class="default">4</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">++) {<br />&nbsp; &nbsp; </span><span class="default">$numbers</span><span class="keyword">[] = </span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$num </span><span class="keyword">= </span><span class="default">count</span><span class="keyword">(</span><span class="default">$numbers</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$index </span><span class="keyword">=&amp; </span><span class="default">$numbers</span><span class="keyword">[</span><span class="default">$num </span><span class="keyword">? </span><span class="default">$num </span><span class="keyword">- </span><span class="default">1 </span><span class="keyword">: </span><span class="default">$num</span><span class="keyword">];<br />&nbsp; &nbsp; </span><span class="default">$index </span><span class="keyword">= </span><span class="default">$i</span><span class="keyword">;<br />}<br /><br />foreach (</span><span class="default">$numbers </span><span class="keyword">as </span><span class="default">$index</span><span class="keyword">) {<br />&nbsp; &nbsp; print </span><span class="string">"</span><span class="default">$index</span><span class="string">\n"</span><span class="keyword">;<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />Does not produce:<br />1<br />2<br />3<br /><br />But instead:<br />1<br />2<br />2<br /><br />Applying unset($index) before re-using the variable fixes this and the expected list will be produced:<br />1<br />2<br />3</span>
</code></div>
  </div>
 </div>
  <div class="note" id="84088">  <div class="votes">
    <div id="Vu84088">
    <a href="/manual/vote-note.php?id=84088&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd84088">
    <a href="/manual/vote-note.php?id=84088&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V84088" title="60% like this...">
    3
    </div>
  </div>
  <a href="#84088" class="name">
  <strong class="user"><em>mpapec</em></strong></a><a class="genanchor" href="#84088"> &para;</a><div class="date" title="2008-06-26 05:23"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom84088">
<div class="phpcode"><code><span class="html">
It's strange that function definition AND call to the same function must have "&amp;" before them. <br /><br />$arr = array();<br />$ref =&amp; oras($arr['blah'], array());<br />$ref []= "via ref";<br />print_r($arr);<br /><br />/* result<br />Array<br />(<br />&nbsp; &nbsp; [blah] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0] =&gt; via ref<br />&nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />)<br />*/<br /><br />// perl like ||=<br />function &amp;oras (&amp;$v, $new) {<br />&nbsp; $v or $v = $new;<br />&nbsp; return $v;<br />}</span>
</code></div>
  </div>
 </div>
  <div class="note" id="49829">  <div class="votes">
    <div id="Vu49829">
    <a href="/manual/vote-note.php?id=49829&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd49829">
    <a href="/manual/vote-note.php?id=49829&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V49829" title="58% like this...">
    5
    </div>
  </div>
  <a href="#49829" class="name">
  <strong class="user"><em>Francis dot a at gmx dot net</em></strong></a><a class="genanchor" href="#49829"> &para;</a><div class="date" title="2005-02-09 10:53"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom49829">
<div class="phpcode"><code><span class="html">
I don't know if this is a bug (I'm using PHP 5.01) but you should be careful when using&nbsp; references on arrays.<br />I had a for-loop that was incredibly slow and it took me some time to find out that most of the time was wasted with the&nbsp; function sizeof() at every loop, and even more time I spent&nbsp; finding out that this problem it must be somehow related to the fact, that I used a reference of the array. Take a look at the following example:<br /><br />function test_ref(&amp;$arr) {<br />&nbsp; &nbsp; $time = time();<br />&nbsp; &nbsp; for($n=0; $n&lt;sizeof($arr); $n++) {<br />&nbsp; &nbsp; &nbsp; &nbsp; $x = 1;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; echo "&lt;br /&gt;The function using a reference took ".(time() - $time)." s";<br />}<br /><br />function test_val($arr) {<br />&nbsp; &nbsp; $time = time();<br />&nbsp; &nbsp; for($n=0; $n&lt;sizeof($arr); $n++) {<br />&nbsp; &nbsp; &nbsp; &nbsp; $x = 1;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; echo "&lt;br /&gt;The funktion using a value took: ".(time() - $time)." s";<br />}<br /><br />// fill array<br />for($n=0; $n&lt;2000; $n++) {<br />&nbsp; &nbsp; $ar[] = "test".$n;<br />}<br /><br />test_ref($ar);<br />test_val($ar);<br />echo "&lt;br /&gt;Done";<br /><br />When I tested it, the first function was done after 9 seconds, while the second (although the array must be copied) was done in not even one.<br /><br />The difference is inproportional smaller when the array size is reduced:<br />When using 1000 loops the first function was running for 1 second, when using 4000 it wasn't even done after 30 Seconds.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="73663">  <div class="votes">
    <div id="Vu73663">
    <a href="/manual/vote-note.php?id=73663&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd73663">
    <a href="/manual/vote-note.php?id=73663&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V73663" title="58% like this...">
    4
    </div>
  </div>
  <a href="#73663" class="name">
  <strong class="user"><em>sneskid at hotmail dot com</em></strong></a><a class="genanchor" href="#73663"> &para;</a><div class="date" title="2007-03-06 12:47"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom73663">
<div class="phpcode"><code><span class="html">
(v5.1.4)<br />One cool thing about var_dump is it shows which variables are references (when dumping arrays), symbolized by '∫' for int/null, and by '&amp;' for boolean/double/string/array/object. I don't know why the difference in symmmmbolism.<br />After playing around I found a better way to implement detaching (twas by accident). var_dump can show what's going on.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function &amp;</span><span class="default">detach</span><span class="keyword">(</span><span class="default">$v</span><span class="keyword">=</span><span class="default">null</span><span class="keyword">){return </span><span class="default">$v</span><span class="keyword">;}<br /><br /></span><span class="default">$A</span><span class="keyword">=array(</span><span class="string">'x' </span><span class="keyword">=&gt; </span><span class="default">123</span><span class="keyword">, </span><span class="string">'y' </span><span class="keyword">=&gt; </span><span class="default">321</span><span class="keyword">);<br /></span><span class="default">$A</span><span class="keyword">[</span><span class="string">'x'</span><span class="keyword">] = &amp;</span><span class="default">$A</span><span class="keyword">[</span><span class="string">'x'</span><span class="keyword">];<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$A</span><span class="keyword">);<br /></span><span class="comment">/* x became it's own reference...<br />array(2) {<br />&nbsp; ["x"]=&gt; ∫(123)<br />&nbsp; ["y"]=&gt; int(321)<br />}*/<br /><br /></span><span class="default">$A</span><span class="keyword">[</span><span class="string">'y'</span><span class="keyword">]=&amp;</span><span class="default">$A</span><span class="keyword">[</span><span class="string">'x'</span><span class="keyword">];<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$A</span><span class="keyword">);<br /></span><span class="comment">/* now both are references<br />array(2) {<br />&nbsp; ["x"]=&gt; ∫(123)<br />&nbsp; ["y"]=&gt; ∫(123)<br />}*/<br /><br /></span><span class="default">$z </span><span class="keyword">= </span><span class="string">'hi'</span><span class="keyword">;<br /></span><span class="default">$A</span><span class="keyword">[</span><span class="string">'y'</span><span class="keyword">]=&amp;</span><span class="default">detach</span><span class="keyword">(&amp;</span><span class="default">$z</span><span class="keyword">);<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$A</span><span class="keyword">);<br /></span><span class="comment">/* x is still a reference, y and z share<br />array(2) {<br />&nbsp; ["x"]=&gt; ∫(123)<br />&nbsp; ["y"]=&gt; &amp;string(2) "hi"<br />}*/<br /><br /></span><span class="default">$A</span><span class="keyword">[</span><span class="string">'x'</span><span class="keyword">] = </span><span class="default">$A</span><span class="keyword">[</span><span class="string">'x'</span><span class="keyword">];<br /></span><span class="default">$A</span><span class="keyword">[</span><span class="string">'y'</span><span class="keyword">]=&amp;</span><span class="default">detach</span><span class="keyword">();<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$A</span><span class="keyword">,</span><span class="default">$z</span><span class="keyword">);<br /></span><span class="comment">/* x returned to normal, y is on its own, z is still "hi"<br />array(2) {<br />&nbsp; ["x"]=&gt; int(123)<br />&nbsp; ["y"]=&gt; NULL<br />}*/<br /></span><span class="default">?&gt;<br /></span><br />For detach to work you need to use '&amp;' in the function declaration, and every time you call it.<br /><br />Use this when you know a variable is a reference, and you want to assign a new value without effecting other vars referencing that piece of memory. You can initialize it with a new constant value, or variable, or new reference all in once step.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="41114">  <div class="votes">
    <div id="Vu41114">
    <a href="/manual/vote-note.php?id=41114&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd41114">
    <a href="/manual/vote-note.php?id=41114&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V41114" title="60% like this...">
    3
    </div>
  </div>
  <a href="#41114" class="name">
  <strong class="user"><em>iryoku at terra dot es</em></strong></a><a class="genanchor" href="#41114"> &para;</a><div class="date" title="2004-03-30 10:22"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom41114">
<div class="phpcode"><code><span class="html">
You should have in mind that php4 keep assigned variables "automagically" referenced until they are overwritten. So the variable copy is not executed on assignment, but on modification. Say you have this:<br /><br />$var1 = 5;<br />$var2 = $var1; // In this point these two variables share the same memory location<br />$var1 = 3; // Here $var1 and $var2 have they own memory locations with values 3 and 5 respectively<br /><br />Don't use references in function parameters to speed up aplications, because this is automatically done. I think that this should be in the manual, because it can lead to confusion.<br /><br />More about this here:<br /><a href="http://www.zend.com/zend/art/ref-count.php" rel="nofollow" target="_blank">http://www.zend.com/zend/art/ref-count.php</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="99644">  <div class="votes">
    <div id="Vu99644">
    <a href="/manual/vote-note.php?id=99644&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd99644">
    <a href="/manual/vote-note.php?id=99644&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V99644" title="57% like this...">
    3
    </div>
  </div>
  <a href="#99644" class="name">
  <strong class="user"><em>gnuffo1 at gmail dot com</em></strong></a><a class="genanchor" href="#99644"> &para;</a><div class="date" title="2010-08-27 07:07"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom99644">
<div class="phpcode"><code><span class="html">
If you want to know the reference count of a particular variable, then here's a function that makes use of debug_zval_dump() to do so:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">refcount</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="default">ob_start</span><span class="keyword">();<br />&nbsp; &nbsp; </span><span class="default">debug_zval_dump</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$dump </span><span class="keyword">= </span><span class="default">ob_get_clean</span><span class="keyword">();<br /><br />&nbsp; &nbsp; </span><span class="default">$matches </span><span class="keyword">= array();<br />&nbsp; &nbsp; </span><span class="default">preg_match</span><span class="keyword">(</span><span class="string">'/refcount\(([0-9]+)/'</span><span class="keyword">, </span><span class="default">$dump</span><span class="keyword">, </span><span class="default">$matches</span><span class="keyword">);<br /><br />&nbsp; &nbsp; </span><span class="default">$count </span><span class="keyword">= </span><span class="default">$matches</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">];<br /><br />&nbsp; &nbsp; </span><span class="comment">//3 references are added, including when calling debug_zval_dump()<br />&nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">$count </span><span class="keyword">- </span><span class="default">3</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />debug_zval_dump() is a confusing function, as explained in its documentation, as among other things, it adds a reference count when being called as there is a reference within the function. refcount() takes account of these extra references by subtracting them for the return value.<br /><br />It's also even more confusing when dealing with variables that have been assigned by reference (=&amp;), either on the right or left side of the assignment, so for that reason, the above function doesn't really work for those sorts of variables. I'd use it more on object instances.<br /><br />However, even taking into account that passing a variable to a function adds one to the reference count; which should mean that calling refcount() adds one, and then calling debug_zval_dump() adds another, refcount() seems to have aquired another reference from somewhere; hence subtracting 3 instead of 2 in the return line. Not quite sure where that comes from.<br /><br />I've only tested this on 5.3; due to the nature of debug_zval_dump(), the results may be completely different on other versions.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="45696">  <div class="votes">
    <div id="Vu45696">
    <a href="/manual/vote-note.php?id=45696&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd45696">
    <a href="/manual/vote-note.php?id=45696&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V45696" title="58% like this...">
    3
    </div>
  </div>
  <a href="#45696" class="name">
  <strong class="user"><em>hkmaly at bigfoot dot com</em></strong></a><a class="genanchor" href="#45696"> &para;</a><div class="date" title="2004-09-15 08:11"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom45696">
<div class="phpcode"><code><span class="html">
It seems like PHP has problems with references, like that it can't work properly with circular references or free properly structure with more references. See <a href="http://bugs.php.net/?id=30053." rel="nofollow" target="_blank">http://bugs.php.net/?id=30053.</a><br /><br />I have big problem with this and I hope someone from PHP add proper warning with explanation IN manual, if they can't fix it.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="50950">  <div class="votes">
    <div id="Vu50950">
    <a href="/manual/vote-note.php?id=50950&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd50950">
    <a href="/manual/vote-note.php?id=50950&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V50950" title="58% like this...">
    2
    </div>
  </div>
  <a href="#50950" class="name">
  <strong class="user"><em>Carlos</em></strong></a><a class="genanchor" href="#50950"> &para;</a><div class="date" title="2005-03-14 12:09"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom50950">
<div class="phpcode"><code><span class="html">
in the example below, you would get the same result if you change the function to something like:<br /><br />function test_ref(&amp;$arr) {<br />&nbsp;&nbsp; $time = time();<br />&nbsp;&nbsp; $size = sizeof($arr);&nbsp; &nbsp; &nbsp;&nbsp; // &lt;--- this makes difference...<br />&nbsp;&nbsp; for($n=0; $n&lt;$size; $n++) {<br />&nbsp; &nbsp; &nbsp;&nbsp; $x = 1;<br />&nbsp;&nbsp; }<br /><br />&nbsp;&nbsp; echo "&lt;br /&gt;The function using a reference took ".(time() - $time)." s";<br />}</span>
</code></div>
  </div>
 </div>
  <div class="note" id="59611">  <div class="votes">
    <div id="Vu59611">
    <a href="/manual/vote-note.php?id=59611&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd59611">
    <a href="/manual/vote-note.php?id=59611&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V59611" title="57% like this...">
    2
    </div>
  </div>
  <a href="#59611" class="name">
  <strong class="user"><em>cesoid at yahoo dot com</em></strong></a><a class="genanchor" href="#59611"> &para;</a><div class="date" title="2005-12-10 06:28"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom59611">
<div class="phpcode"><code><span class="html">
Responding to post from nathan (who was responding to iryoku).<br /><br />It is important to note the difference between what php is doing from the programmer's point of view and what it is doing internally. The note that nathan refers to, about how (for example) $something = $this makes a "copy" of the current object, is talking about making a "copy" from the programmer's perspective. That is, for the programmer, for all practical purposes, $something is a copy, even if internally nothing has been copied yet. For example, changing the data in member $something-&gt;somethingVar will not change your current object's data (i.e. it will not change $this-&gt;somethingVar).<br /><br />What it does internally is a totally different story. I've tested&nbsp; "copying" an object which contains a 200,000 element array, it takes almost no time at all until you finally change something in one of the copies, because internally it only makes the copy when it becomes necessary. The original assignment takes less than a millisecond, but when I alter one of the copies, it takes something like a quarter of a second. But this only happens if I alter the 200,000 element array, if I alter a single integer of the object, it takes less than a microsecond again, so the interpretter seems to be smart enough to make copies of some of the objects variables and not others.<br /><br />The result is that when you change a function to pass by reference, it will only become more efficient if, inside the function, the passed variable is having its data altered, in which case passing by reference causes your code to alter the data of the original copy. If you are passing an object and calling a function in that object, that function may alter the object without you even knowing, which means that you should pass an object by reference as long as it is ok for the original copy to be effected by what you do with the object inside the function.<br /><br />I think the real moral of the story is this:<br />1) Pass by reference anything that should refer to and affect the original copy.<br />2) Pass not by reference things that will definitely not be altered in the function (for an object, it may be impossible to know whether it alters itself upon calling one of its functions).<br />3) If something needs to be altered inside a function without effecting the original copy, pass it not by reference, and pass the smallest practical part that needs to change, rather than passing, for example, a huge array of which one little integer will be altered.<br /><br />Or a shorter version: Only pass things by reference when you need to refer to the original copy! (And don't pass huge arrays or long strings when you need to change just a small part of them!)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="107946">  <div class="votes">
    <div id="Vu107946">
    <a href="/manual/vote-note.php?id=107946&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd107946">
    <a href="/manual/vote-note.php?id=107946&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V107946" title="55% like this...">
    2
    </div>
  </div>
  <a href="#107946" class="name">
  <strong class="user"><em>sneskid at hotmail dot com</em></strong></a><a class="genanchor" href="#107946"> &para;</a><div class="date" title="2012-03-15 10:19"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom107946">
<div class="phpcode"><code><span class="html">
There is no built in method (yet) to check if two variables are references to the same piece of data, but you can do a "reference sniff" test. This is rarely needed, but can be very useful. The function bellow is a slightly modified version of this technique I saw in a forum regarding this comparison limitation.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">is_ref_to</span><span class="keyword">(&amp;</span><span class="default">$a</span><span class="keyword">, &amp;</span><span class="default">$b</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="default">$t </span><span class="keyword">= </span><span class="default">$a</span><span class="keyword">;<br />&nbsp; &nbsp; if(</span><span class="default">$r</span><span class="keyword">=(</span><span class="default">$b</span><span class="keyword">===(</span><span class="default">$a</span><span class="keyword">=</span><span class="default">1</span><span class="keyword">))){ </span><span class="default">$r </span><span class="keyword">= (</span><span class="default">$b</span><span class="keyword">===(</span><span class="default">$a</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">)); }<br />&nbsp; &nbsp; </span><span class="default">$a </span><span class="keyword">= </span><span class="default">$t</span><span class="keyword">;<br />&nbsp; &nbsp; return </span><span class="default">$r</span><span class="keyword">;<br />}<br /><br /></span><span class="default">$varA </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br /></span><span class="default">$varB </span><span class="keyword">= </span><span class="default">$varA</span><span class="keyword">;<br /></span><span class="default">$varC </span><span class="keyword">=&amp;</span><span class="default">$varA</span><span class="keyword">;<br /><br /></span><span class="default">var_dump</span><span class="keyword">( </span><span class="default">is_ref_to</span><span class="keyword">(</span><span class="default">$varA</span><span class="keyword">, </span><span class="default">$varB</span><span class="keyword">) ); </span><span class="comment">// bool(false)<br /></span><span class="default">var_dump</span><span class="keyword">( </span><span class="default">is_ref_to</span><span class="keyword">(</span><span class="default">$varA</span><span class="keyword">, </span><span class="default">$varC</span><span class="keyword">) ); </span><span class="comment">// bool(true)<br /></span><span class="default">?&gt;<br /></span><br />The test above uses a two step process to be 100% generic.<br />But if you are sure the variables being tested will not be a certain value, example null, then use that value to allow a one step check.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">is_ref_to_1step</span><span class="keyword">(&amp;</span><span class="default">$a</span><span class="keyword">, &amp;</span><span class="default">$b</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="default">$t </span><span class="keyword">= </span><span class="default">$a</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$r</span><span class="keyword">=(</span><span class="default">$b</span><span class="keyword">===(</span><span class="default">$a</span><span class="keyword">=</span><span class="default">null</span><span class="keyword">));<br />&nbsp; &nbsp; </span><span class="default">$a </span><span class="keyword">= </span><span class="default">$t</span><span class="keyword">;<br />&nbsp; &nbsp; return </span><span class="default">$r</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="55766">  <div class="votes">
    <div id="Vu55766">
    <a href="/manual/vote-note.php?id=55766&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd55766">
    <a href="/manual/vote-note.php?id=55766&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V55766" title="53% like this...">
    1
    </div>
  </div>
  <a href="#55766" class="name">
  <strong class="user"><em>grayson at uiuc dot edu</em></strong></a><a class="genanchor" href="#55766"> &para;</a><div class="date" title="2005-08-12 08:59"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom55766">
<div class="phpcode"><code><span class="html">
I found a subtle feature of references that caused a bug in one of my PHP applications.&nbsp; In short, if an object passes one of its members to an external function that takes a reference as an argument, the external function can turn that member into a reference to an anonymous point in memory.<br /><br />Why is this a problem?&nbsp; Later, when you copy the object with $a = $b, the copy and the original share memory.<br /><br />Solution: If you want to have a function that uses references to modify a member of your object, your object should never pass the member to the function directly. It should first make a copy of the member. Then give that copy to the function.&nbsp; Then copy the new value of that copy in to your original object member.<br /><br />Below is some code that can reporoduce the this feature and demonstrate the workaround.<br /><br />function modify1 ( &amp;$pointer_obj ){<br />&nbsp; $pointer_obj-&gt;property = 'Original Value';<br />}<br /><br />function modify2 ( &amp;$pointer_obj ){<br />&nbsp; $newObj-&gt;property = 'Original Value';<br />&nbsp; $pointer_obj = $newObj;<br />}<br /><br />class a {<br />&nbsp; var $i;&nbsp;&nbsp; # an object with properties<br /><br />&nbsp; function corrupt1(){<br />&nbsp; &nbsp; modify1 ($this-&gt;i);<br />&nbsp; }<br /><br />&nbsp; function doNotCorrupt1(){<br />&nbsp; &nbsp; $tmpi = $this-&gt;i;<br />&nbsp; &nbsp; modify1 ($tmpi);<br />&nbsp; &nbsp; $this-&gt;i = $tmpi;<br />&nbsp; }<br /><br />&nbsp; function corrupt2(){<br />&nbsp; &nbsp; modify2 ($this-&gt;i);<br />&nbsp; }<br /><br />&nbsp; function doNotCorrupt2(){<br />&nbsp; &nbsp; $tmpi = $this-&gt;i;<br />&nbsp; &nbsp; modify2 ($tmpi);<br />&nbsp; &nbsp; $this-&gt;i = $tmpi;<br />&nbsp; }<br /><br />}<br /><br />$functions = array ('corrupt1', 'corrupt2', 'doNotCorrupt1', 'doNotCorrupt2');<br /><br />foreach ($functions as $func){<br /><br />&nbsp; $original = new a;<br /><br />&nbsp; ### Load some data in to the orginal with one of the four $functions<br />&nbsp; $original-&gt;$func();<br /><br />&nbsp; $copy = $original;<br /><br />&nbsp; $copy-&gt;i-&gt;property = "Changed after the copy was made.";<br /><br />&nbsp; echo "\n{$func}: \$original-&gt;i-&gt;property = '" . $original-&gt;i-&gt;property . "'";<br />}<br /><br />The script generates output:<br /><br />corrupt1: $original-&gt;i-&gt;property = 'Changed after the copy was made.'<br />corrupt2: $original-&gt;i-&gt;property = 'Changed after the copy was made.'<br />doNotCorrupt1: $original-&gt;i-&gt;property = 'Original Value'<br />doNotCorrupt2: $original-&gt;i-&gt;property = 'Original Value'</span>
</code></div>
  </div>
 </div>
  <div class="note" id="74950">  <div class="votes">
    <div id="Vu74950">
    <a href="/manual/vote-note.php?id=74950&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd74950">
    <a href="/manual/vote-note.php?id=74950&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V74950" title="52% like this...">
    1
    </div>
  </div>
  <a href="#74950" class="name">
  <strong class="user"><em>trucex at gmail dot com</em></strong></a><a class="genanchor" href="#74950"> &para;</a><div class="date" title="2007-05-05 01:49"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom74950">
<div class="phpcode"><code><span class="html">
In response to Xor and Slava:<br /><br />I recommend you read up a bit more on the way PHP handles memory management. Take the following code for example:<br /><br /><span class="default">&lt;?php<br /><br />$data </span><span class="keyword">= </span><span class="default">$_POST</span><span class="keyword">[</span><span class="string">'lotsofdata'</span><span class="keyword">];<br /></span><span class="default">$data2 </span><span class="keyword">= </span><span class="default">$data</span><span class="keyword">;<br /></span><span class="default">$data3 </span><span class="keyword">= </span><span class="default">$data</span><span class="keyword">;<br /></span><span class="default">$data4 </span><span class="keyword">= </span><span class="default">$data</span><span class="keyword">;<br /></span><span class="default">$data5 </span><span class="keyword">= </span><span class="default">$data</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;<br /></span><br />Assuming we post 10MB of data to this PHP file, what will PHP do with the memory? <br /><br />PHP uses a table of sorts that maps variable names to the data that variable refers to in memory. The $_POST superglobal will actually be the first instance of that data in the execution, so it will be the first variable referenced to that data in the memory. It will consume 10MB. Each $data var will simply point to the same data in memory. Until you change that data PHP will NOT duplicate it.<br /><br />Passing a variable by value does just what I did with each $data var. There is no significant overhead to assigning a new name to the same data. It is only when you modify the data passed to the function that it must allocate memory for the data. Passing a variable by reference will do essentially the same thing when you pass the data to the function, only modifying it will modify the data that is in the memory already versus copying it to a new location in memory.<br /><br />If for learning purposes you choose to disregard the obvious pointlessness in benchmarking the difference between these two methods of passing arguments, you will need to modify the data when it is passed to the function in order to obtain more accurate results.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="44203">  <div class="votes">
    <div id="Vu44203">
    <a href="/manual/vote-note.php?id=44203&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd44203">
    <a href="/manual/vote-note.php?id=44203&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V44203" title="52% like this...">
    1
    </div>
  </div>
  <a href="#44203" class="name">
  <strong class="user"><em>jlaing at gmail dot com</em></strong></a><a class="genanchor" href="#44203"> &para;</a><div class="date" title="2004-07-17 08:28"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom44203">
<div class="phpcode"><code><span class="html">
While trying to do object references with the special $this variable I found that this will not work:<br />class foo {<br />&nbsp; function bar() {<br />&nbsp; &nbsp; ...<br />&nbsp; &nbsp; $this =&amp; $some_other_foo_obj;<br />&nbsp; }<br />}<br /><br />If you want to emulate this functionality you must iterate through the vars of the class and assign references like this:<br /><br />$vars = get_class_vars('foo');<br />foreach (array_keys($vars) as $field) {<br />&nbsp; $this-&gt;$field =&amp; $some_other_foo_obj-&gt;$field;<br />}<br /><br />Now if you modify values within $this they will be modified within $some_other_foo_obj and vice versa.<br /><br />Hope that helps some people!<br /><br />p.s.<br />developer at sirspot dot com's note about object references doesn't seem correct to me.<br /><br />&nbsp; $temp =&amp; $object;<br />&nbsp; $object =&amp; $temp-&gt;getNext();<br /><br />Does the same exact thing as:<br /><br />&nbsp; $object =&amp; $object-&gt;getNext();<br /><br />when you refernce $temp to $object all it does is make $temp an alias to the same memory as $object, so doing $temp-&gt;getNext(); and $object-&gt;getNext(); are calling the same function on the same object.&nbsp; Try it out if you don't believe me.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119048">  <div class="votes">
    <div id="Vu119048">
    <a href="/manual/vote-note.php?id=119048&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119048">
    <a href="/manual/vote-note.php?id=119048&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119048" title="50% like this...">
    0
    </div>
  </div>
  <a href="#119048" class="name">
  <strong class="user"><em>jszoja at gmail dot com</em></strong></a><a class="genanchor" href="#119048"> &para;</a><div class="date" title="2016-03-23 11:09"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119048">
<div class="phpcode"><code><span class="html">
Be aware of a reference to another reference. It is probably bad practice to even do that.<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">class </span><span class="default">Obj1 </span><span class="keyword">{ public </span><span class="default">$name </span><span class="keyword">= </span><span class="string">'Obj1'</span><span class="keyword">; }<br />&nbsp; &nbsp; class </span><span class="default">Obj2 </span><span class="keyword">{ public </span><span class="default">$name </span><span class="keyword">= </span><span class="string">'Obj2'</span><span class="keyword">; }<br /><br />&nbsp; &nbsp; </span><span class="default">$objects </span><span class="keyword">= [];<br />&nbsp; &nbsp; </span><span class="default">$toLoad </span><span class="keyword">= [ </span><span class="string">'Obj1'</span><span class="keyword">, </span><span class="string">'Obj2' </span><span class="keyword">];<br /><br />&nbsp; &nbsp; foreach( </span><span class="default">$toLoad </span><span class="keyword">as </span><span class="default">$i </span><span class="keyword">=&gt; </span><span class="default">$obj </span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$ref </span><span class="keyword">= new </span><span class="default">$obj</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$objects</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">] =&amp; </span><span class="default">$ref</span><span class="keyword">; </span><span class="comment">// a reference to a reference<br />&nbsp; &nbsp; &nbsp; &nbsp; // $objects[$i] = $ref; // that would work<br />&nbsp; &nbsp; </span><span class="keyword">}<br /><br />&nbsp; &nbsp; echo </span><span class="default">$objects</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]-&gt;</span><span class="default">name</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// outputs 'Obj2' !<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113187">  <div class="votes">
    <div id="Vu113187">
    <a href="/manual/vote-note.php?id=113187&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113187">
    <a href="/manual/vote-note.php?id=113187&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113187" title="50% like this...">
    0
    </div>
  </div>
  <a href="#113187" class="name">
  <strong class="user"><em>shooo dot xz at gmail dot com</em></strong></a><a class="genanchor" href="#113187"> &para;</a><div class="date" title="2013-09-10 12:53"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113187">
<div class="phpcode"><code><span class="html">
Hi, i've worked a abit on reference stuff.<br />Here is what i've noticed.<br /><br />The problem: Sort mysql result through columns<br /><br />$rewrite_self = gt::recombine(array('lang', 'id'), 'value_column', $sql_result);<br /><br />public static function recombine($keys, $value, &amp;$arr) {<br />&nbsp; &nbsp; &nbsp; &nbsp; $ref = array();<br />&nbsp; &nbsp; &nbsp; &nbsp; $main = &amp;$ref;<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach($arr as $data) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; foreach($keys as $key) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (!is_array($ref[$data[$key]])) $ref[$data[$key]] = array();<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $ref = &amp;$ref[$data[$key]];<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $ref = $data[$value];<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $ref = &amp;$main;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; return $main;<br />}<br /><br />array(2) {<br />&nbsp; ["pl"]=&gt;<br />&nbsp; array(2) {<br />&nbsp; &nbsp; [2]=&gt;<br />&nbsp; &nbsp; string(4) "value_column_str"<br />&nbsp; &nbsp; [3]=&gt;<br />&nbsp; &nbsp; string(4) "value_column_str2"<br />&nbsp; }<br />&nbsp; ["en"]=&gt;<br />&nbsp; array(1) {<br />&nbsp; &nbsp; [13]=&gt;<br />&nbsp; &nbsp; string(7) "value_column_str3"<br />&nbsp; }<br />}<br /><br />Enjoy!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="95154">  <div class="votes">
    <div id="Vu95154">
    <a href="/manual/vote-note.php?id=95154&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd95154">
    <a href="/manual/vote-note.php?id=95154&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V95154" title="50% like this...">
    0
    </div>
  </div>
  <a href="#95154" class="name">
  <strong class="user"><em>Youssef Omar</em></strong></a><a class="genanchor" href="#95154"> &para;</a><div class="date" title="2009-12-15 12:27"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom95154">
<div class="phpcode"><code><span class="html">
This is to show the affect of changing property of object A through another object B when you pass object A as a property of another object B.<br /><br /><span class="default">&lt;?php<br /> </span><span class="comment">// data class to be passed to another class as an object<br /> </span><span class="keyword">class </span><span class="default">A</span><span class="keyword">{<br />&nbsp; &nbsp;&nbsp; public </span><span class="default">$info</span><span class="keyword">;<br />&nbsp; &nbsp; function </span><span class="default">__construct</span><span class="keyword">(){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">info </span><span class="keyword">= </span><span class="string">"eeee"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /> }<br /> <br /> </span><span class="comment">// B class to change the info in A obj<br /> </span><span class="keyword">class </span><span class="default">B_class</span><span class="keyword">{<br />&nbsp; &nbsp;&nbsp; public </span><span class="default">$A_obj</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$A_obj</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">A_obj </span><span class="keyword">=&nbsp; </span><span class="default">$A_obj</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public function </span><span class="default">change</span><span class="keyword">(</span><span class="default">$newVal</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">A_obj</span><span class="keyword">-&gt;</span><span class="default">info </span><span class="keyword">= </span><span class="default">$newVal</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /> }<br /><br /> </span><span class="comment">// create data object from the A<br /> </span><span class="default">$A_obj </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">();<br /> </span><span class="comment">// print the info property<br /> </span><span class="keyword">echo </span><span class="string">'A_obj info: ' </span><span class="keyword">. </span><span class="default">$A_obj</span><span class="keyword">-&gt;</span><span class="default">info </span><span class="keyword">. </span><span class="string">'&lt;br/&gt;'</span><span class="keyword">;<br /> <br /> </span><span class="comment">// create the B object and pass the A_obj we created above<br /> </span><span class="default">$B_obj </span><span class="keyword">= new </span><span class="default">B_class</span><span class="keyword">(</span><span class="default">$A_obj</span><span class="keyword">);<br /> </span><span class="comment">// print the info property through the B object to make sure it has the same value 'eeee'<br /> </span><span class="keyword">echo </span><span class="string">'B_obj info: ' </span><span class="keyword">. </span><span class="default">$B_obj</span><span class="keyword">-&gt;</span><span class="default">A_obj</span><span class="keyword">-&gt;</span><span class="default">info </span><span class="keyword">. </span><span class="string">'&lt;br/&gt;'</span><span class="keyword">;<br /> <br /> </span><span class="comment">// chage the info property<br /> </span><span class="default">$B_obj</span><span class="keyword">-&gt;</span><span class="default">change</span><span class="keyword">(</span><span class="string">'xxxxx'</span><span class="keyword">);<br /> </span><span class="comment">// print the info property through the B object to make sure it changed the value to 'xxxxxx'<br /> </span><span class="keyword">echo </span><span class="string">'B_obj info after change: ' </span><span class="keyword">. </span><span class="default">$B_obj</span><span class="keyword">-&gt;</span><span class="default">A_obj</span><span class="keyword">-&gt;</span><span class="default">info </span><span class="keyword">. </span><span class="string">'&lt;br/&gt;'</span><span class="keyword">;<br /> </span><span class="comment">// print the info property from the A_obj to see if the change through B_obj has affected it<br /> </span><span class="keyword">echo </span><span class="string">'A_obj info: ' </span><span class="keyword">. </span><span class="default">$A_obj</span><span class="keyword">-&gt;</span><span class="default">info </span><span class="keyword">. </span><span class="string">'&lt;br/&gt;'</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;<br /></span><br />The result:<br /><br />A_obj info: eeee<br />B_obj info: eeee<br />B_obj info after change: xxxxx<br />A_obj info: xxxxx</span>
</code></div>
  </div>
 </div>
  <div class="note" id="85118">  <div class="votes">
    <div id="Vu85118">
    <a href="/manual/vote-note.php?id=85118&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd85118">
    <a href="/manual/vote-note.php?id=85118&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V85118" title="50% like this...">
    0
    </div>
  </div>
  <a href="#85118" class="name">
  <strong class="user"><em>blake</em></strong></a><a class="genanchor" href="#85118"> &para;</a><div class="date" title="2008-08-15 07:22"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom85118">
<div class="phpcode"><code><span class="html">
To ffmandu13 at hotmail dot com, that's not correct. If you do a little research, you'll see that the Zend Engine employs "copy-on-write" logic, meaning that variables will be referenced instead of copied until it's actually written to. There's really no need to circumvent Zend's internal optimizations, since they're probably much more advanced than you think. Here's a good link to read over:<br /><br /><a href="http://bytes.com/forum/thread769586.html" rel="nofollow" target="_blank">http://bytes.com/forum/thread769586.html</a><br /><br />As stated, there's rarely (if ever) a need to use references for optimization purposes. When in doubt, remember that in most cases, the Zend Engine &gt; you.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="78789">  <div class="votes">
    <div id="Vu78789">
    <a href="/manual/vote-note.php?id=78789&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd78789">
    <a href="/manual/vote-note.php?id=78789&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V78789" title="50% like this...">
    0
    </div>
  </div>
  <a href="#78789" class="name">
  <strong class="user"><em>henrik at newdawn dot dk</em></strong></a><a class="genanchor" href="#78789"> &para;</a><div class="date" title="2007-10-27 03:21"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom78789">
<div class="phpcode"><code><span class="html">
A note for those of you that are using constructs like the following:<br />return $this-&gt;$MyVarName<br />in your objects.<br /><br />Consider the following:<br />class Test {<br />&nbsp; &nbsp; &nbsp; &nbsp; var $MyArray = array();<br />&nbsp; &nbsp; &nbsp; &nbsp; function add($var) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $this-&gt;$var[rand(1,100)] = rand(1,100);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; function show($var) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo "\nEcho from Test:\n";<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; print_r($this-&gt;$var);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />}<br />$test = new Test();<br />$test-&gt;show('MyArray');<br />$test-&gt;add('MyArray');<br />$test-&gt;add('MyArray');<br />$test-&gt;add('MyArray');<br />$test-&gt;show('MyArray');<br /><br />will output<br /><br />Echo from Test:<br />Array<br />(<br />)<br /><br />Fatal error: Cannot access empty property in /home/webroot/framework_devhost_dk/compiler/test2.php on line 5<br /><br />For this to work properly you have to use a construct similar to this:<br />class Test {<br />&nbsp; &nbsp; &nbsp; &nbsp; var $MyArray = array();<br />&nbsp; &nbsp; &nbsp; &nbsp; function add($var) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $tmp =&amp; $this-&gt;$var; //This is the trick... strange but true ;)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $tmp[rand(1,100)] = rand(1,100);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; function show($var) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo "\nEcho from Test:\n";<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; print_r($this-&gt;$var);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />}<br />$test = new Test();<br />$test-&gt;show('MyArray');<br />$test-&gt;add('MyArray');<br />$test-&gt;add('MyArray');<br />$test-&gt;add('MyArray');<br />$test-&gt;show('MyArray');<br /><br />Will output:<br />Echo from Test:<br />Array<br />(<br />)<br /><br />Echo from Test:<br />Array<br />(<br />&nbsp; &nbsp; [19] =&gt; 17<br />&nbsp; &nbsp; [53] =&gt; 57<br />&nbsp; &nbsp; [96] =&gt; 43<br />)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="75056">  <div class="votes">
    <div id="Vu75056">
    <a href="/manual/vote-note.php?id=75056&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd75056">
    <a href="/manual/vote-note.php?id=75056&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V75056" title="50% like this...">
    0
    </div>
  </div>
  <a href="#75056" class="name">
  <strong class="user"><em>maghiel at mdijksman dot nl</em></strong></a><a class="genanchor" href="#75056"> &para;</a><div class="date" title="2007-05-10 04:02"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom75056">
<div class="phpcode"><code><span class="html">
Note that:<br /><br />Call-time pass-by-reference has been deprecated - argument passed by value; If you would like to pass it by reference, modify the declaration of xxxxx. If you would like to enable call-time pass-by-reference, you can set allow_call_time_pass_reference to true in your INI file. However, future versions may not support this any longer</span>
</code></div>
  </div>
 </div>
  <div class="note" id="57732">  <div class="votes">
    <div id="Vu57732">
    <a href="/manual/vote-note.php?id=57732&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd57732">
    <a href="/manual/vote-note.php?id=57732&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V57732" title="50% like this...">
    0
    </div>
  </div>
  <a href="#57732" class="name">
  <strong class="user"><em>mramirez (at) star (minus) dev (dot) com</em></strong></a><a class="genanchor" href="#57732"> &para;</a><div class="date" title="2005-10-12 09:10"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom57732">
<div class="phpcode"><code><span class="html">
For php programmers that come from pascal,<br />in object pascal (delphi),<br />variable references are used with the "absolute" keyword.<br /><br />PHP example:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">global </span><span class="default">$myglobal</span><span class="keyword">;<br /><br /></span><span class="default">$myglobal </span><span class="keyword">= </span><span class="default">5</span><span class="keyword">;<br /><br />function </span><span class="default">test</span><span class="keyword">()<br />{<br />global </span><span class="default">$myglobal</span><span class="keyword">;<br /><br /></span><span class="comment">/*local*/ </span><span class="default">$mylocal </span><span class="keyword">=&amp; </span><span class="default">$myglobal</span><span class="keyword">;<br /><br />echo </span><span class="string">"local: " </span><span class="keyword">. </span><span class="default">$mylocal </span><span class="keyword">. </span><span class="string">"\n"</span><span class="keyword">;<br />echo </span><span class="string">"gloal: " </span><span class="keyword">. </span><span class="default">$myglobal </span><span class="keyword">. </span><span class="string">"\n"</span><span class="keyword">;<br />}<br /><br /></span><span class="default">test</span><span class="keyword">();<br /><br /></span><span class="default">?&gt;<br /></span><br />Pascal example:<br /><br />program dontcare;<br /><br />var myglobal: integer;<br /><br />procedure test;<br />var mylocal ABSOLUTE myglobal;<br />begin<br />&nbsp; write("local: ", mylocal);<br />&nbsp; write("global: ", myglobal);<br />end;<br /><br />begin<br />&nbsp; myglobal := 5;<br />&nbsp; test;<br />end.<br /><br />By the way, a "local" keyword in php for local variables,<br />could be welcome :-)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="75635">  <div class="votes">
    <div id="Vu75635">
    <a href="/manual/vote-note.php?id=75635&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd75635">
    <a href="/manual/vote-note.php?id=75635&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V75635" title="48% like this...">
    -1
    </div>
  </div>
  <a href="#75635" class="name">
  <strong class="user"><em>eduardofleury at uol dot com dot br</em></strong></a><a class="genanchor" href="#75635"> &para;</a><div class="date" title="2007-06-09 06:58"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom75635">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br />$foo </span><span class="keyword">= </span><span class="string">'Hello'</span><span class="keyword">; <br /></span><span class="default">$bar </span><span class="keyword">= </span><span class="string">'World'</span><span class="keyword">;&nbsp; <br />print </span><span class="default">$foo </span><span class="keyword">. </span><span class="string">" " </span><span class="keyword">. </span><span class="default">$bar</span><span class="keyword">;</span><span class="comment">// Hello World<br /><br /></span><span class="default">$foo </span><span class="keyword">= &amp;</span><span class="default">$bar</span><span class="keyword">;<br /></span><span class="default">$bar </span><span class="keyword">= </span><span class="string">'Hello My World'</span><span class="keyword">;<br /><br />print </span><span class="default">$foo</span><span class="keyword">;</span><span class="comment">// Hello My World<br /></span><span class="keyword">print </span><span class="default">$bar</span><span class="keyword">;</span><span class="comment">// Hello My World<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114620">  <div class="votes">
    <div id="Vu114620">
    <a href="/manual/vote-note.php?id=114620&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114620">
    <a href="/manual/vote-note.php?id=114620&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114620" title="46% like this...">
    -1
    </div>
  </div>
  <a href="#114620" class="name">
  <strong class="user"><em>alexander at gamerev dot org</em></strong></a><a class="genanchor" href="#114620"> &para;</a><div class="date" title="2014-03-13 02:47"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114620">
<div class="phpcode"><code><span class="html">
Simply put, here's an example of what referencing IS:<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; $foo&nbsp; </span><span class="keyword">= </span><span class="default">5</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$bar </span><span class="keyword">= &amp;</span><span class="default">$foo</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$bar</span><span class="keyword">++;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; echo </span><span class="default">$foo</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />The above example will output the value 6, because $bar references the value of $foo, therefore, when changing $bar's value, you also change $foo's value too.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="84378">  <div class="votes">
    <div id="Vu84378">
    <a href="/manual/vote-note.php?id=84378&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd84378">
    <a href="/manual/vote-note.php?id=84378&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V84378" title="47% like this...">
    -1
    </div>
  </div>
  <a href="#84378" class="name">
  <strong class="user"><em>jasonpvp at gmail dot com</em></strong></a><a class="genanchor" href="#84378"> &para;</a><div class="date" title="2008-07-10 04:16"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom84378">
<div class="phpcode"><code><span class="html">
To change values in a multi-dimensional array while looping through:<br /><br />$var=array('a'=&gt;array(1,2,3),'b'=&gt;array(4,5,6));<br /><br />foreach ($var as &amp;$sub) {<br />&nbsp; foreach ($sub as &amp;$element) {<br />&nbsp; &nbsp; $element=$element+1;<br />&nbsp; }<br />}<br /><br />var_dump($var);<br /><br />------------------------------<br />produces:<br />------------------------------<br />array(2) {<br />&nbsp; ["a"]=&gt;<br />&nbsp; array(3) {<br />&nbsp; &nbsp; [0]=&gt;<br />&nbsp; &nbsp; int(2)<br />&nbsp; &nbsp; [1]=&gt;<br />&nbsp; &nbsp; int(3)<br />&nbsp; &nbsp; [2]=&gt;<br />&nbsp; &nbsp; int(4)<br />&nbsp; }<br />&nbsp; ["b"]=&gt;<br />&nbsp; array(3) {<br />&nbsp; &nbsp; [0]=&gt;<br />&nbsp; &nbsp; int(5)<br />&nbsp; &nbsp; [1]=&gt;<br />&nbsp; &nbsp; int(6)<br />&nbsp; &nbsp; [2]=&gt;<br />&nbsp; &nbsp; int(7)<br />&nbsp; }<br />}</span>
</code></div>
  </div>
 </div>
  <div class="note" id="57365">  <div class="votes">
    <div id="Vu57365">
    <a href="/manual/vote-note.php?id=57365&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd57365">
    <a href="/manual/vote-note.php?id=57365&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V57365" title="47% like this...">
    -1
    </div>
  </div>
  <a href="#57365" class="name">
  <strong class="user"><em>pike at kw dot nl</em></strong></a><a class="genanchor" href="#57365"> &para;</a><div class="date" title="2005-10-01 06:08"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom57365">
<div class="phpcode"><code><span class="html">
if your object seems to "forget" assignments you make after instantiation, realize that in<br /><br />$foo = new Bar()<br /><br />the variable on the left hand is a *copy* of the variable on the right hand. As a result, &amp; references made during instantiation may point to the righthandside version of Bar() and not to $foo. you'd better use<br /><br />$foo = &amp; new Bar()</span>
</code></div>
  </div>
 </div>
  <div class="note" id="68747">  <div class="votes">
    <div id="Vu68747">
    <a href="/manual/vote-note.php?id=68747&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd68747">
    <a href="/manual/vote-note.php?id=68747&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V68747" title="46% like this...">
    -1
    </div>
  </div>
  <a href="#68747" class="name">
  <strong class="user"><em>gunter dot sammet at gmail dot com</em></strong></a><a class="genanchor" href="#68747"> &para;</a><div class="date" title="2006-08-09 01:23"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom68747">
<div class="phpcode"><code><span class="html">
I tried to create an array with n depth using a recursive function passing array references around. So far I haven't had much luck and I couldn't find anything on the web. So I ended up using eval() and it seems to work well:<br /><span class="default">&lt;?php<br />&nbsp; &nbsp; &nbsp; </span><span class="keyword">foreach(</span><span class="default">array_keys</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">quantity_array</span><span class="keyword">) AS </span><span class="default">$key</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">quantity_array</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">] &gt; </span><span class="default">0</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$combinations </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">(</span><span class="string">'-'</span><span class="keyword">, </span><span class="default">$key</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$eval_string </span><span class="keyword">= </span><span class="string">'$eval_array'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; foreach(</span><span class="default">array_keys</span><span class="keyword">(</span><span class="default">$combinations</span><span class="keyword">) AS </span><span class="default">$key2</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$option_key_value </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">(</span><span class="string">'_'</span><span class="keyword">, </span><span class="default">$combinations</span><span class="keyword">[</span><span class="default">$key2</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$eval_string </span><span class="keyword">.= </span><span class="string">'['</span><span class="keyword">.</span><span class="default">$option_key_value</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">].</span><span class="string">']['</span><span class="keyword">.</span><span class="default">$option_key_value</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">].</span><span class="string">']'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$eval_string </span><span class="keyword">.= </span><span class="string">' = '</span><span class="keyword">.</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">quantity_array</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">].</span><span class="string">';'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; eval(</span><span class="default">$eval_string</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; }<br /></span><span class="default">?&gt;<br /></span><br />This produces an n dimensional array that will be available in the $eval_array variable. Hope it helps somebody!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="57550">  <div class="votes">
    <div id="Vu57550">
    <a href="/manual/vote-note.php?id=57550&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd57550">
    <a href="/manual/vote-note.php?id=57550&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V57550" title="46% like this...">
    -1
    </div>
  </div>
  <a href="#57550" class="name">
  <strong class="user"><em>y007pig at yahoo dot com dot cn</em></strong></a><a class="genanchor" href="#57550"> &para;</a><div class="date" title="2005-10-06 11:02"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom57550">
<div class="phpcode"><code><span class="html">
In reply to pike at kw dot nl, '&amp;' is only apply to PHP 4.<br />PHP 5 changed the behavior and the object is defaultly passed by references and if you turn on E_STRICT, you will get a notice:<br />Strict Standards: Assigning the return value of new by reference is deprecated in xxxx<br />If you want to *copy* object in PHP 5, use object clone.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="39588">  <div class="votes">
    <div id="Vu39588">
    <a href="/manual/vote-note.php?id=39588&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd39588">
    <a href="/manual/vote-note.php?id=39588&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V39588" title="43% like this...">
    -2
    </div>
  </div>
  <a href="#39588" class="name">
  <strong class="user"><em>developer at sirspot dot com</em></strong></a><a class="genanchor" href="#39588"> &para;</a><div class="date" title="2004-02-03 10:30"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom39588">
<div class="phpcode"><code><span class="html">
Since references are more like hardlinks than pointers, it is not possible to change a reference to an object by using that same reference.&nbsp; For example:<br /><br />The following WILL NOT WORK as expected and may even crash the PHP interpreter:<br /><br />$object =&amp; $object-&gt;getNext();<br /><br />However, by changing the previous statement to use a temporary reference, this WILL WORK:<br /><br />$temp =&amp; $object;<br />$object =&amp; $temp-&gt;getNext();</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118271">  <div class="votes">
    <div id="Vu118271">
    <a href="/manual/vote-note.php?id=118271&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118271">
    <a href="/manual/vote-note.php?id=118271&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118271" title="41% like this...">
    -3
    </div>
  </div>
  <a href="#118271" class="name">
  <strong class="user"><em>www.reddit.com/user/Tiny_Mo</em></strong></a><a class="genanchor" href="#118271"> &para;</a><div class="date" title="2015-11-06 06:57"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom118271">
<div class="phpcode"><code><span class="html">
Another very interesting example:<br /><span class="default">&lt;?php<br />$a </span><span class="keyword">= [</span><span class="default">1</span><span class="keyword">, </span><span class="default">2</span><span class="keyword">];<br /></span><span class="default">$b </span><span class="keyword">= [</span><span class="default">3</span><span class="keyword">, </span><span class="default">4</span><span class="keyword">];<br /></span><span class="default">$b</span><span class="keyword">[] = &amp;</span><span class="default">$a</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">];<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">);<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$b</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span>gives:<br />Array<br />(<br />&nbsp; &nbsp; [0] =&gt; 3<br />&nbsp; &nbsp; [1] =&gt; 4<br />&nbsp; &nbsp; [2] =&gt; 4<br />)<br />Array<br />(<br />&nbsp; &nbsp; [0] =&gt; 3<br />&nbsp; &nbsp; [1] =&gt; 4<br />&nbsp; &nbsp; [2] =&gt; 4<br />)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="92215">  <div class="votes">
    <div id="Vu92215">
    <a href="/manual/vote-note.php?id=92215&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd92215">
    <a href="/manual/vote-note.php?id=92215&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V92215" title="42% like this...">
    -3
    </div>
  </div>
  <a href="#92215" class="name">
  <strong class="user"><em>wernerdegroot at nospam dot gmail</em></strong></a><a class="genanchor" href="#92215"> &para;</a><div class="date" title="2009-07-14 11:56"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom92215">
<div class="phpcode"><code><span class="html">
In the following case you don't have to use = &amp; operator when returning a reference:<br /><br /><span class="default">&lt;?php<br /><br />&nbsp; &nbsp; </span><span class="keyword">class </span><span class="default">a </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; public </span><span class="default">$a </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; class </span><span class="default">b </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; static </span><span class="default">$var</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; public static function &amp; </span><span class="default">gvar</span><span class="keyword">(</span><span class="default">$i</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(!(isset(</span><span class="default">b</span><span class="keyword">::</span><span class="default">$var</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">]))) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">b</span><span class="keyword">::</span><span class="default">$var</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">] = new </span><span class="default">a</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">b</span><span class="keyword">::</span><span class="default">$var</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="default">$b </span><span class="keyword">= new </span><span class="default">b</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$a </span><span class="keyword">= </span><span class="default">b</span><span class="keyword">::</span><span class="default">gvar</span><span class="keyword">(</span><span class="default">1</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">a </span><span class="keyword">= </span><span class="default">14</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="default">$c </span><span class="keyword">= </span><span class="default">b</span><span class="keyword">::</span><span class="default">gvar</span><span class="keyword">(</span><span class="default">1</span><span class="keyword">);<br />&nbsp; &nbsp; echo </span><span class="default">$c</span><span class="keyword">-&gt;</span><span class="default">a</span><span class="keyword">; </span><span class="comment">// 14<br /></span><span class="default">?&gt;<br /></span><br />Note the $a = b::gvar(1) instead of $a = &amp; b::gvar(1)!!!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="93812">  <div class="votes">
    <div id="Vu93812">
    <a href="/manual/vote-note.php?id=93812&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd93812">
    <a href="/manual/vote-note.php?id=93812&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V93812" title="42% like this...">
    -3
    </div>
  </div>
  <a href="#93812" class="name">
  <strong class="user"><em>strata_ranger at hotmail dot com</em></strong></a><a class="genanchor" href="#93812"> &para;</a><div class="date" title="2009-09-30 11:59"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom93812">
<div class="phpcode"><code><span class="html">
Note that in PHP5 you generally don't need the reference operator -- at all -- when dealing with class objects, because PHP5 implements objects using Instances (which are more like C pointers than PHP's references system).<br /><br />For example:<br /><span class="default">&lt;?php<br /></span><span class="comment">//<br />// Since PHP 5<br />//<br /><br /></span><span class="default">$foo </span><span class="keyword">= new </span><span class="default">stdClass</span><span class="keyword">();<br /><br /></span><span class="comment">// $bar and $foo are still holding the same (single) object<br /></span><span class="default">$bar </span><span class="keyword">= </span><span class="default">$foo</span><span class="keyword">;<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$foo</span><span class="keyword">, </span><span class="default">$bar</span><span class="keyword">)<br /></span><span class="comment">// object(stdClass)#1 (0) { }<br />// object(stdClass)#1 (0) { }<br /><br /></span><span class="default">$bar</span><span class="keyword">-&gt;</span><span class="default">member </span><span class="keyword">= </span><span class="string">"Something"</span><span class="keyword">;<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$foo</span><span class="keyword">, </span><span class="default">$bar</span><span class="keyword">);<br /></span><span class="comment">// object(stdClass)#1 (1) {<br />//&nbsp; ["member"]=&gt;<br />//&nbsp; string(9) "Something"<br />// }<br />// object(stdClass)#1 (1) {<br />//&nbsp;&nbsp; ["member"]=&gt;<br />//&nbsp;&nbsp; string(9) "Something"<br />// }<br /><br />// Use the 'clone' keyword to make a separate copy of the object<br /></span><span class="default">$bar </span><span class="keyword">= clone </span><span class="default">$foo</span><span class="keyword">;<br /></span><span class="default">$bar</span><span class="keyword">-&gt;</span><span class="default">member </span><span class="keyword">= </span><span class="string">"Something"</span><span class="keyword">;<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$foo</span><span class="keyword">, </span><span class="default">$bar</span><span class="keyword">);<br /></span><span class="comment">// object(stdClass)#1 (0) { }<br />// object(stdClass)#2 (1) {<br />//&nbsp;&nbsp; ["member"]=&gt;<br />//&nbsp;&nbsp; string(9) "Something"<br />// }<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="93292">  <div class="votes">
    <div id="Vu93292">
    <a href="/manual/vote-note.php?id=93292&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd93292">
    <a href="/manual/vote-note.php?id=93292&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V93292" title="41% like this...">
    -3
    </div>
  </div>
  <a href="#93292" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#93292"> &para;</a><div class="date" title="2009-09-01 01:07"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom93292">
<div class="phpcode"><code><span class="html">
After hours of confusion and reading tons of posts I finally figured out that replacing PHP 4 style object creation, where new is assigned by reference:<br /><br />$node_obj =&amp; new someClass($somearg, $moreargs);<br /><br />which in PHP 5.3.0 generates an E_STRICT message telling you that "Assigning the return value of new by reference is deprecated" <br /><br />with the following, where &amp; has been removed:<br /><br />$node_obj = new someClass($somearg, $moreargs);<br /><br />in some cases (at least in recursive loops while creating a tree of nodes containing child nodes) requires<br /><br />unset($node_obj);<br /><br />before the actual object assignment line to avoid all child nodes becoming identical. <br /><br />Hope that delicate piece of information will save someone else a few hours.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="52926">  <div class="votes">
    <div id="Vu52926">
    <a href="/manual/vote-note.php?id=52926&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd52926">
    <a href="/manual/vote-note.php?id=52926&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V52926" title="41% like this...">
    -3
    </div>
  </div>
  <a href="#52926" class="name">
  <strong class="user"><em>rlynch at lynchmarks dot com</em></strong></a><a class="genanchor" href="#52926"> &para;</a><div class="date" title="2005-05-17 02:51"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom52926">
<div class="phpcode"><code><span class="html">
And, further...<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; $intSize </span><span class="keyword">= </span><span class="default">sizeof</span><span class="keyword">(</span><span class="default">$arrData</span><span class="keyword">);<br /><br />&nbsp; &nbsp; for(</span><span class="default">$i </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">; </span><span class="default">$i </span><span class="keyword">&lt; </span><span class="default">$intSize</span><span class="keyword">; </span><span class="default">$n</span><span class="keyword">++) {<br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="comment">// Do stuff<br />&nbsp; &nbsp; </span><span class="keyword">}<br /></span><span class="default">?&gt;</span> <br /><br />Can be shortened even further by using the often overlooked 'decrement until zero' concept.&nbsp; I don't much like decrementing to get a job done, but it can make a lot of sense when the evaluation-of-doneness is time-costly:<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">for(</span><span class="default">$i </span><span class="keyword">= </span><span class="default">sizeof</span><span class="keyword">(</span><span class="default">$arrData</span><span class="keyword">); </span><span class="default">$i</span><span class="keyword">-- &gt; </span><span class="default">0 </span><span class="keyword">; ) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Do stuff&nbsp;&nbsp; <br />&nbsp; &nbsp; </span><span class="keyword">}<br /></span><span class="default">?&gt;</span> <br /><br />One less variable to toss on the heap.&nbsp; NOTE that rather inconveniently, the $i goes to and hits zero only in the case where it starts out positive.&nbsp; When it is zero to begin with, it will become -1.&nbsp; Bug or feature?&nbsp; I've used it as a feature as a quick test of whether the $arrData array was empty to begin with.&nbsp; If you don't plan on using $i after the loop for anything, it makes no difference.<br /><br />If you need to be doing something ascending-sequential though, then the temporary variable suggestions that others have made makes the most sense.<br /><br />Finally (and important) ... if the $arrData array is somehow being dynamically modified in size due to the //Do-Stuff routine underneath, then you may have little-to-no recourse except to use the sizeof() method/function in the loop.&nbsp; Or, keep up the temporary variable in the loop as you push and pop things into and off the array.&nbsp; <br /><br />(sigh... this is the notable failing of deeply linked internal data structures: to figure out the size of any linked list of arbitrarily composed elements, the entire array needs to be "walked" every time the sizeof() or count() method is used.&nbsp; But compared to the flexibility of associative arrays, the cost is mitigated by careful use.)<br /><br />GoatGuy</span>
</code></div>
  </div>
 </div>
  <div class="note" id="82703">  <div class="votes">
    <div id="Vu82703">
    <a href="/manual/vote-note.php?id=82703&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd82703">
    <a href="/manual/vote-note.php?id=82703&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V82703" title="37% like this...">
    -4
    </div>
  </div>
  <a href="#82703" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#82703"> &para;</a><div class="date" title="2008-04-22 11:42"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom82703">
<div class="phpcode"><code><span class="html">
To henrik at newdawn dot dk, 28-Oct-2007<br /><br />No, it's not strange.<br />$this-&gt;$var['key'] tries to look up 'key' in the array $var and then use that for the property name. $this-&gt;{$var}['key'], on the other hand...</span>
</code></div>
  </div>
 </div>
  <div class="note" id="88821">  <div class="votes">
    <div id="Vu88821">
    <a href="/manual/vote-note.php?id=88821&amp;page=language.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd88821">
    <a href="/manual/vote-note.php?id=88821&amp;page=language.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V88821" title="31% like this...">
    -6
    </div>
  </div>
  <a href="#88821" class="name">
  <strong class="user"><em>bytepirate</em></strong></a><a class="genanchor" href="#88821"> &para;</a><div class="date" title="2009-02-09 02:00"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom88821">
<div class="phpcode"><code><span class="html">
in additon to blakes comment. try this:<br /><br /><span class="default">&lt;?php<br />$strlen</span><span class="keyword">=</span><span class="default">60000</span><span class="keyword">;<br /></span><span class="default">$bstring</span><span class="keyword">=</span><span class="default">str_repeat</span><span class="keyword">(</span><span class="string">"X"</span><span class="keyword">,</span><span class="default">$strlen</span><span class="keyword">);<br /></span><span class="default">$astring</span><span class="keyword">=</span><span class="default">$bstring</span><span class="keyword">;<br /></span><span class="default">$starttime</span><span class="keyword">=</span><span class="default">microtime</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">);<br />for(</span><span class="default">$i</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">;</span><span class="default">$i</span><span class="keyword">&lt;=</span><span class="default">$strlen</span><span class="keyword">;</span><span class="default">$i</span><span class="keyword">++){<br />&nbsp; if(</span><span class="default">$i</span><span class="keyword">==</span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$astring</span><span class="keyword">))<br />&nbsp; &nbsp;&nbsp; echo </span><span class="string">"End of String&lt;br&gt;"</span><span class="keyword">;<br />}<br />echo (</span><span class="default">microtime</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">)-</span><span class="default">$starttime</span><span class="keyword">).</span><span class="string">" seconds expired"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />and now change '$astring=$bstring;' to '$astring=&amp;$bstring;'<br />on my system its 200 times slower with the reference.<br />increase $strlen and it gets even worse ;-)<br /><br />(PHP 5.25 on UNIX)</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.references&amp;redirect=http://php.net/manual/en/language.references.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="langref.php">Language Reference</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.basic-syntax.php" title="Basic syntax">Basic syntax</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.php" title="Types">Types</a>
                        </li>
                          
                        <li class="">
                            <a href="language.variables.php" title="Variables">Variables</a>
                        </li>
                          
                        <li class="">
                            <a href="language.constants.php" title="Constants">Constants</a>
                        </li>
                          
                        <li class="">
                            <a href="language.expressions.php" title="Expressions">Expressions</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.php" title="Operators">Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.control-structures.php" title="Control Structures">Control Structures</a>
                        </li>
                          
                        <li class="">
                            <a href="language.functions.php" title="Functions">Functions</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.php" title="Classes and Objects">Classes and Objects</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.php" title="Namespaces">Namespaces</a>
                        </li>
                          
                        <li class="">
                            <a href="language.errors.php" title="Errors">Errors</a>
                        </li>
                          
                        <li class="">
                            <a href="language.exceptions.php" title="Exceptions">Exceptions</a>
                        </li>
                          
                        <li class="">
                            <a href="language.generators.php" title="Generators">Generators</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.references.php" title="References Explained">References Explained</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.php" title="Predefined Variables">Predefined Variables</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.exceptions.php" title="Predefined Exceptions">Predefined Exceptions</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.interfaces.php" title="Predefined Interfaces and Classes">Predefined Interfaces and Classes</a>
                        </li>
                          
                        <li class="">
                            <a href="context.php" title="Context options and parameters">Context options and parameters</a>
                        </li>
                          
                        <li class="">
                            <a href="wrappers.php" title="Supported Protocols and Wrappers">Supported Protocols and Wrappers</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

