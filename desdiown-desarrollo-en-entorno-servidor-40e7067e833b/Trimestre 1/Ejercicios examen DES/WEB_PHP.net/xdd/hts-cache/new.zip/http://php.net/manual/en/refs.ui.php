<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: GUI Extensions - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/refs.ui.php">
 <link rel="shorturl" href="http://php.net/manual/en/refs.ui.php">
 <link rel="alternate" href="http://php.net/manual/en/refs.ui.php" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/funcref.php">
 <link rel="prev" href="http://php.net/manual/en/xsltprocessor.transformtoxml.php">
 <link rel="next" href="http://php.net/manual/en/book.ui.php">

 <link rel="alternate" href="http://php.net/manual/en/refs.ui.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/refs.ui.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/refs.ui.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/refs.ui.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/refs.ui.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/refs.ui.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/refs.ui.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/refs.ui.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/refs.ui.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/refs.ui.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/refs.ui.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="book.ui.php">
          UI &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="xsltprocessor.transformtoxml.php">
          &laquo; XSLTProcessor::transformToXML        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='funcref.php'>Function Reference</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/refs.ui.php' selected="selected">English</option>
            <option value='pt_BR/refs.ui.php'>Brazilian Portuguese</option>
            <option value='zh/refs.ui.php'>Chinese (Simplified)</option>
            <option value='fr/refs.ui.php'>French</option>
            <option value='de/refs.ui.php'>German</option>
            <option value='ja/refs.ui.php'>Japanese</option>
            <option value='ro/refs.ui.php'>Romanian</option>
            <option value='ru/refs.ui.php'>Russian</option>
            <option value='es/refs.ui.php'>Spanish</option>
            <option value='tr/refs.ui.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/refs.ui.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=refs.ui">Report a Bug</a>
    </div>
  </div><div id="refs.ui" class="set">
   <h1 class="title">GUI Extensions</h1>
   






  <ul class="chunklist chunklist_set"><li><a href="book.ui.php">UI</a><ul class="chunklist chunklist_set chunklist_children"><li><a href="intro.ui.php">Introduction</a></li><li><a href="ui.setup.php">Installing/Configuring</a></li><li><a href="class.ui-point.php">UI\Point</a> — Represents a position (x,y)</li><li><a href="class.ui-size.php">UI\Size</a> — Represents dimenstions (width, height)</li><li><a href="class.ui-window.php">UI\Window</a> — Window</li><li><a href="class.ui-control.php">UI\Control</a> — Control</li><li><a href="class.ui-menu.php">UI\Menu</a> — Menu</li><li><a href="class.ui-menuitem.php">UI\MenuItem</a> — Menu Item</li><li><a href="class.ui-area.php">UI\Area</a> — Area</li><li><a href="class.ui-executor.php">UI\Executor</a> — Execution Scheduler</li><li><a href="class.ui-controls-tab.php">UI\Controls\Tab</a> — Tab Control</li><li><a href="class.ui-controls-check.php">UI\Controls\Check</a> — Check Control</li><li><a href="class.ui-controls-button.php">UI\Controls\Button</a> — Button Control</li><li><a href="class.ui-controls-colorbutton.php">UI\Controls\ColorButton</a> — ColorButton Control</li><li><a href="class.ui-controls-label.php">UI\Controls\Label</a> — Label Control</li><li><a href="class.ui-controls-entry.php">UI\Controls\Entry</a> — Entry Control</li><li><a href="class.ui-controls-multilineentry.php">UI\Controls\MultilineEntry</a> — MultilineEntry Control</li><li><a href="class.ui-controls-spin.php">UI\Controls\Spin</a> — Spin Control</li><li><a href="class.ui-controls-slider.php">UI\Controls\Slider</a> — Slider Control</li><li><a href="class.ui-controls-progress.php">UI\Controls\Progress</a> — Progress Control</li><li><a href="class.ui-controls-separator.php">UI\Controls\Separator</a> — Control Separator</li><li><a href="class.ui-controls-combo.php">UI\Controls\Combo</a> — Combo Control</li><li><a href="class.ui-controls-editablecombo.php">UI\Controls\EditableCombo</a> — EdiableCombo Control</li><li><a href="class.ui-controls-radio.php">UI\Controls\Radio</a> — Radio Control</li><li><a href="class.ui-controls-picker.php">UI\Controls\Picker</a> — Picker Control</li><li><a href="class.ui-controls-form.php">UI\Controls\Form</a> — Control Form (Arrangement)</li><li><a href="class.ui-controls-grid.php">UI\Controls\Grid</a> — Control Grid (Arrangement)</li><li><a href="class.ui-controls-group.php">UI\Controls\Group</a> — Control Group (Arrangement)</li><li><a href="class.ui-controls-box.php">UI\Controls\Box</a> — Control Box (Arrangement)</li><li><a href="class.ui-draw-pen.php">UI\Draw\Pen</a> — Draw Pen</li><li><a href="class.ui-draw-path.php">UI\Draw\Path</a> — Draw Path</li><li><a href="class.ui-draw-matrix.php">UI\Draw\Matrix</a> — Draw Matrix</li><li><a href="class.ui-draw-color.php">UI\Draw\Color</a> — Color Representation</li><li><a href="class.ui-draw-stroke.php">UI\Draw\Stroke</a> — Draw Stroke</li><li><a href="class.ui-draw-brush.php">UI\Draw\Brush</a> — Brushes</li><li><a href="class.ui-draw-brush-gradient.php">UI\Draw\Brush\Gradient</a> — Gradient Brushes</li><li><a href="class.ui-draw-brush-lineargradient.php">UI\Draw\Brush\LinearGradient</a> — Linear Gradient</li><li><a href="class.ui-draw-brush-radialgradient.php">UI\Draw\Brush\RadialGradient</a> — Radial Gradient</li><li><a href="class.ui-draw-text-layout.php">UI\Draw\Text\Layout</a> — Represents Text Layout</li><li><a href="class.ui-draw-text-font.php">UI\Draw\Text\Font</a> — Represents a Font</li><li><a href="class.ui-draw-text-font-descriptor.php">UI\Draw\Text\Font\Descriptor</a> — Font Descriptor</li><li><a href="ref.ui.php">UI Functions</a></li><li><a href="class.ui-draw-text-font-weight.php">UI\Draw\Text\Font\Weight</a> — Font Weight Settings</li><li><a href="class.ui-draw-text-font-italic.php">UI\Draw\Text\Font\Italic</a> — Italic Font Settings</li><li><a href="class.ui-draw-text-font-stretch.php">UI\Draw\Text\Font\Stretch</a> — Font Stretch Settings</li><li><a href="class.ui-draw-line-cap.php">UI\Draw\Line\Cap</a> — Line Cap Settings</li><li><a href="class.ui-draw-line-join.php">UI\Draw\Line\Join</a> — Line Join Settings</li><li><a href="class.ui-key.php">UI\Key</a> — Key Identifiers</li><li><a href="class.ui-exception-invalidargumentexception.php">UI\Exception\InvalidArgumentException</a> — InvalidArgumentException</li><li><a href="class.ui-exception-runtimeexception.php">UI\Exception\RuntimeException</a> — RuntimeException</li></ul></li></ul></div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=refs.ui&amp;redirect=http://php.net/manual/en/refs.ui.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes </h3>
 </div>
 <div class="note">There are no user contributed notes for this page.</div></section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="funcref.php">Function Reference</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="refs.basic.php.php" title="Affecting PHP's Behaviour">Affecting PHP's Behaviour</a>
                        </li>
                          
                        <li class="">
                            <a href="refs.utilspec.audio.php" title="Audio Formats Manipulation">Audio Formats Manipulation</a>
                        </li>
                          
                        <li class="">
                            <a href="refs.remote.auth.php" title="Authentication Services">Authentication Services</a>
                        </li>
                          
                        <li class="">
                            <a href="refs.utilspec.cmdline.php" title="Command Line Specific Extensions">Command Line Specific Extensions</a>
                        </li>
                          
                        <li class="">
                            <a href="refs.compression.php" title="Compression and Archive Extensions">Compression and Archive Extensions</a>
                        </li>
                          
                        <li class="">
                            <a href="refs.creditcard.php" title="Credit Card Processing">Credit Card Processing</a>
                        </li>
                          
                        <li class="">
                            <a href="refs.crypto.php" title="Cryptography Extensions">Cryptography Extensions</a>
                        </li>
                          
                        <li class="">
                            <a href="refs.database.php" title="Database Extensions">Database Extensions</a>
                        </li>
                          
                        <li class="">
                            <a href="refs.calendar.php" title="Date and Time Related Extensions">Date and Time Related Extensions</a>
                        </li>
                          
                        <li class="">
                            <a href="refs.fileprocess.file.php" title="File System Related Extensions">File System Related Extensions</a>
                        </li>
                          
                        <li class="">
                            <a href="refs.international.php" title="Human Language and Character Encoding Support">Human Language and Character Encoding Support</a>
                        </li>
                          
                        <li class="">
                            <a href="refs.utilspec.image.php" title="Image Processing and Generation">Image Processing and Generation</a>
                        </li>
                          
                        <li class="">
                            <a href="refs.remote.mail.php" title="Mail Related Extensions">Mail Related Extensions</a>
                        </li>
                          
                        <li class="">
                            <a href="refs.math.php" title="Mathematical Extensions">Mathematical Extensions</a>
                        </li>
                          
                        <li class="">
                            <a href="refs.utilspec.nontext.php" title="Non-&#8203;Text MIME Output">Non-&#8203;Text MIME Output</a>
                        </li>
                          
                        <li class="">
                            <a href="refs.fileprocess.process.php" title="Process Control Extensions">Process Control Extensions</a>
                        </li>
                          
                        <li class="">
                            <a href="refs.basic.other.php" title="Other Basic Extensions">Other Basic Extensions</a>
                        </li>
                          
                        <li class="">
                            <a href="refs.remote.other.php" title="Other Services">Other Services</a>
                        </li>
                          
                        <li class="">
                            <a href="refs.search.php" title="Search Engine Extensions">Search Engine Extensions</a>
                        </li>
                          
                        <li class="">
                            <a href="refs.utilspec.server.php" title="Server Specific Extensions">Server Specific Extensions</a>
                        </li>
                          
                        <li class="">
                            <a href="refs.basic.session.php" title="Session Extensions">Session Extensions</a>
                        </li>
                          
                        <li class="">
                            <a href="refs.basic.text.php" title="Text Processing">Text Processing</a>
                        </li>
                          
                        <li class="">
                            <a href="refs.basic.vartype.php" title="Variable and Type Related Extensions">Variable and Type Related Extensions</a>
                        </li>
                          
                        <li class="">
                            <a href="refs.webservice.php" title="Web Services">Web Services</a>
                        </li>
                          
                        <li class="">
                            <a href="refs.utilspec.windows.php" title="Windows Only Extensions">Windows Only Extensions</a>
                        </li>
                          
                        <li class="">
                            <a href="refs.xml.php" title="XML Manipulation">XML Manipulation</a>
                        </li>
                          
                        <li class="current">
                            <a href="refs.ui.php" title="GUI Extensions">GUI Extensions</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

