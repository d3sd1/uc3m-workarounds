<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Magic Methods - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.oop5.magic.php">
 <link rel="shorturl" href="http://php.net/oop5.magic">
 <link rel="alternate" href="http://php.net/oop5.magic" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.oop5.php">
 <link rel="prev" href="http://php.net/manual/en/language.oop5.iterations.php">
 <link rel="next" href="http://php.net/manual/en/language.oop5.final.php">

 <link rel="alternate" href="http://php.net/manual/en/language.oop5.magic.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.oop5.magic.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.oop5.magic.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.oop5.magic.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.oop5.magic.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.oop5.magic.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.oop5.magic.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.oop5.magic.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.oop5.magic.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.oop5.magic.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.oop5.magic.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.oop5.final.php">
          Final Keyword &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.oop5.iterations.php">
          &laquo; Object Iteration        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.oop5.php'>Classes and Objects</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.oop5.magic.php' selected="selected">English</option>
            <option value='pt_BR/language.oop5.magic.php'>Brazilian Portuguese</option>
            <option value='zh/language.oop5.magic.php'>Chinese (Simplified)</option>
            <option value='fr/language.oop5.magic.php'>French</option>
            <option value='de/language.oop5.magic.php'>German</option>
            <option value='ja/language.oop5.magic.php'>Japanese</option>
            <option value='ro/language.oop5.magic.php'>Romanian</option>
            <option value='ru/language.oop5.magic.php'>Russian</option>
            <option value='es/language.oop5.magic.php'>Spanish</option>
            <option value='tr/language.oop5.magic.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.oop5.magic.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.oop5.magic">Report a Bug</a>
    </div>
  </div><div id="language.oop5.magic" class="sect1">
  <h2 class="title">Magic Methods</h2>
  <p class="para">
   The function names
   <a href="language.oop5.decon.php#object.construct" class="link">__construct()</a>,
   <a href="language.oop5.decon.php#object.destruct" class="link">__destruct()</a>,
   <a href="language.oop5.overloading.php#object.call" class="link">__call()</a>,
   <a href="language.oop5.overloading.php#object.callstatic" class="link">__callStatic()</a>,
   <a href="language.oop5.overloading.php#object.get" class="link">__get()</a>,
   <a href="language.oop5.overloading.php#object.set" class="link">__set()</a>,
   <a href="language.oop5.overloading.php#object.isset" class="link">__isset()</a>,
   <a href="language.oop5.overloading.php#object.unset" class="link">__unset()</a>,
   <a href="language.oop5.magic.php#object.sleep" class="link">__sleep()</a>,
   <a href="language.oop5.magic.php#object.wakeup" class="link">__wakeup()</a>,
   <a href="language.oop5.magic.php#object.tostring" class="link">__toString()</a>,
   <a href="language.oop5.magic.php#object.invoke" class="link">__invoke()</a>,
   <a href="language.oop5.magic.php#object.set-state" class="link">__set_state()</a>,
   <a href="language.oop5.cloning.php#object.clone" class="link">__clone()</a> and
   <a href="language.oop5.magic.php#object.debuginfo" class="link">__debugInfo()</a>
   are magical in PHP classes. You
   cannot have functions with these names in any of your
   classes unless you want the magic functionality associated
   with them.
  </p>

  <div class="caution"><strong class="caution">Caution</strong>
   <p class="simpara">
    PHP reserves all function names starting with __ as magical.
    It is recommended that you do not use function names with
    __ in PHP unless you want some documented magic functionality.
   </p>
  </div>
 
  <div class="sect2" id="language.oop5.magic.sleep">
   <h3 class="title">
    <a href="language.oop5.magic.php#object.sleep" class="link">__sleep()</a> and
    <a href="language.oop5.magic.php#object.wakeup" class="link">__wakeup()</a>
   </h3>
   
   <div class="methodsynopsis dc-description" id="object.sleep">
    <span class="modifier">public</span> <span class="type">array</span> <span class="methodname"><strong>__sleep</strong></span>
     ( <span class="methodparam">void</span>
    )</div>

   <div class="methodsynopsis dc-description" id="object.wakeup">
    <span class="type"><span class="type void">void</span></span> <span class="methodname"><strong>__wakeup</strong></span>
     ( <span class="methodparam">void</span>
    )</div>

   
   <p class="para">
    <span class="function"><a href="function.serialize.php" class="function">serialize()</a></span> checks if your class has a function with
    the magic name <a href="language.oop5.magic.php#object.sleep" class="link">__sleep()</a>. If so, that function is
    executed prior to any serialization. It can clean up the object
    and is supposed to return an array with the names of all variables
    of that object that should be serialized.
    If the method doesn&#039;t return anything then <strong><code>NULL</code></strong> is serialized and
    <strong><code>E_NOTICE</code></strong> is issued.
   </p>
   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <p class="para">
     It is not possible for <a href="language.oop5.magic.php#object.sleep" class="link">__sleep()</a> to return names of
     private properties in parent classes. Doing this will result in an
     <strong><code>E_NOTICE</code></strong> level error. Instead you may use the
     <a href="class.serializable.php" class="classname">Serializable</a> interface.
    </p>
   </p></blockquote>
   <p class="para">
    The intended use of <a href="language.oop5.magic.php#object.sleep" class="link">__sleep()</a> is to commit pending
    data or perform similar cleanup tasks. Also, the function is
    useful if you have very large objects which do not need to be
    saved completely.
   </p>
   <p class="para">
    Conversely, <span class="function"><a href="function.unserialize.php" class="function">unserialize()</a></span> checks for the
    presence of a function with the magic name 
    <a href="language.oop5.magic.php#object.wakeup" class="link">__wakeup()</a>. If present, this function can
    reconstruct any resources that the object may have.
   </p>
   <p class="para">
    The intended use of <a href="language.oop5.magic.php#object.wakeup" class="link">__wakeup()</a> is to
    reestablish any database connections that may have been lost
    during serialization and perform other reinitialization
    tasks.
   </p>
   <div class="example" id="language.oop5.traits.precedence.examples.ex2">
    <p><strong>Example #1 Sleep and wakeup</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">Connection<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;protected&nbsp;</span><span style="color: #0000BB">$link</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;private&nbsp;</span><span style="color: #0000BB">$dsn</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$username</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$password</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">__construct</span><span style="color: #007700">(</span><span style="color: #0000BB">$dsn</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$username</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$password</span><span style="color: #007700">)<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">dsn&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$dsn</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">username&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$username</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">password&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$password</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">connect</span><span style="color: #007700">();<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;&nbsp;&nbsp;&nbsp;<br />&nbsp;&nbsp;&nbsp;&nbsp;private&nbsp;function&nbsp;</span><span style="color: #0000BB">connect</span><span style="color: #007700">()<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">link&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">PDO</span><span style="color: #007700">(</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">dsn</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">username</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">password</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;&nbsp;&nbsp;&nbsp;<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">__sleep</span><span style="color: #007700">()<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;array(</span><span style="color: #DD0000">'dsn'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'username'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'password'</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;&nbsp;&nbsp;&nbsp;<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">__wakeup</span><span style="color: #007700">()<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">connect</span><span style="color: #007700">();<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}</span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
  </div>

  <div class="sect2" id="language.oop5.magic.tostring">
   <h3 class="title"><a href="language.oop5.magic.php#object.tostring" class="link">__toString()</a></h3>
   <div class="methodsynopsis dc-description" id="object.tostring">
    <span class="modifier">public</span> <span class="type">string</span> <span class="methodname"><strong>__toString</strong></span>
     ( <span class="methodparam">void</span>
    )</div>

   <p class="para">
    The <a href="language.oop5.magic.php#object.tostring" class="link">__toString()</a> method allows a class to decide
    how it will react when it is treated like a string. For example,
    what <em>echo $obj;</em> will print. This method must
    return a string, as otherwise a fatal <strong><code>E_RECOVERABLE_ERROR</code></strong>
    level error is emitted.
   </p>
   <div class="warning"><strong class="warning">Warning</strong>
    <p class="simpara">
     You cannot throw an exception from within a
     <a href="language.oop5.magic.php#object.tostring" class="link">__toString()</a> method. Doing so will
     result in a fatal error.
    </p>
   </div>
   <div class="example" id="language.oop5.traits.multiple.ex1">
    <p><strong>Example #2 Simple example</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #FF8000">//&nbsp;Declare&nbsp;a&nbsp;simple&nbsp;class<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">TestClass<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;</span><span style="color: #0000BB">$foo</span><span style="color: #007700">;<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">__construct</span><span style="color: #007700">(</span><span style="color: #0000BB">$foo</span><span style="color: #007700">)<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">foo&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$foo</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">__toString</span><span style="color: #007700">()<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">foo</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br /></span><span style="color: #0000BB">$class&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">TestClass</span><span style="color: #007700">(</span><span style="color: #DD0000">'Hello'</span><span style="color: #007700">);<br />echo&nbsp;</span><span style="color: #0000BB">$class</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

    <div class="example-contents"><p>The above example will output:</p></div>
    <div class="example-contents screen">
<div class="cdata"><pre>
Hello
</pre></div>
    </div>
   </div>
   <p class="para">
    It is worth noting that before PHP 5.2.0 the <a href="language.oop5.magic.php#object.tostring" class="link">__toString()</a>
    method was only called when it was directly combined with
    <span class="function"><a href="function.echo.php" class="function">echo</a></span> or <span class="function"><a href="function.print.php" class="function">print</a></span>.
    Since PHP 5.2.0, it is called in any string context (e.g. in
    <span class="function"><a href="function.printf.php" class="function">printf()</a></span> with <em>%s</em> modifier) but not
    in other types contexts (e.g. with <em>%d</em> modifier).
    Since PHP 5.2.0, converting objects without <a href="language.oop5.magic.php#object.tostring" class="link">__toString()</a>
    method to string would cause <strong><code>E_RECOVERABLE_ERROR</code></strong>.
   </p>
  </div>

  <div class="sect2" id="language.oop5.magic.invoke">
   <h3 class="title"><a href="language.oop5.magic.php#object.invoke" class="link">__invoke()</a></h3>
   <div class="methodsynopsis dc-description" id="object.invoke">
    <span class="type"><a href="language.pseudo-types.php#language.types.mixed" class="type mixed">mixed</a></span> <span class="methodname"><strong>__invoke</strong></span>
     ([ <span class="methodparam"> <code class="parameter">$...</code></span>
   ] )</div>

   <p class="para">
    The <a href="language.oop5.magic.php#object.invoke" class="link">__invoke()</a> method is called when a script tries to
    call an object as a function.
   </p>
   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <p class="para">
     This feature is available since PHP 5.3.0.
    </p>
   </p></blockquote>
   <div class="example" id="language.oop5.traits.conflict.ex1">
    <p><strong>Example #3 Using <a href="language.oop5.magic.php#object.invoke" class="link">__invoke()</a></strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">CallableClass<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">__invoke</span><span style="color: #007700">(</span><span style="color: #0000BB">$x</span><span style="color: #007700">)<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$x</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /></span><span style="color: #0000BB">$obj&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">CallableClass</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$obj</span><span style="color: #007700">(</span><span style="color: #0000BB">5</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">is_callable</span><span style="color: #007700">(</span><span style="color: #0000BB">$obj</span><span style="color: #007700">));<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

    <div class="example-contents"><p>The above example will output:</p></div>
    <div class="example-contents screen">
<div class="cdata"><pre>
int(5)
bool(true)
</pre></div>
    </div>
   </div>
  </div>

  <div class="sect2" id="language.oop5.magic.set-state">
   <h3 class="title"><a href="language.oop5.magic.php#object.set-state" class="link">__set_state()</a></h3>
   <div class="methodsynopsis dc-description" id="object.set-state">
    <span class="modifier">static</span> <span class="type">object</span> <span class="methodname"><strong>__set_state</strong></span>
     ( <span class="methodparam"><span class="type">array</span> <code class="parameter">$properties</code></span>
    )</div>

   <p class="para">
    This <a href="language.oop5.static.php" class="link">static</a> method is called
    for classes exported by <span class="function"><a href="function.var-export.php" class="function">var_export()</a></span> since PHP 5.1.0.
   </p>
   <p class="para">
    The only parameter of this method is an array containing exported
    properties in the form <em>array(&#039;property&#039; =&gt; value, ...)</em>.
   </p>
   <div class="example" id="language.oop5.traits.visibility.ex1">
    <p><strong>Example #4 Using <a href="language.oop5.magic.php#object.set-state" class="link">__set_state()</a> (since PHP 5.1.0)</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /><br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">A<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;</span><span style="color: #0000BB">$var1</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;</span><span style="color: #0000BB">$var2</span><span style="color: #007700">;<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;static&nbsp;function&nbsp;</span><span style="color: #0000BB">__set_state</span><span style="color: #007700">(</span><span style="color: #0000BB">$an_array</span><span style="color: #007700">)&nbsp;</span><span style="color: #FF8000">//&nbsp;As&nbsp;of&nbsp;PHP&nbsp;5.1.0<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$obj&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">A</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$obj</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">var1&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$an_array</span><span style="color: #007700">[</span><span style="color: #DD0000">'var1'</span><span style="color: #007700">];<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$obj</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">var2&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$an_array</span><span style="color: #007700">[</span><span style="color: #DD0000">'var2'</span><span style="color: #007700">];<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">$obj</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">A</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$a</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">var1&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">5</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$a</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">var2&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'foo'</span><span style="color: #007700">;<br /><br />eval(</span><span style="color: #DD0000">'$b&nbsp;=&nbsp;'&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">var_export</span><span style="color: #007700">(</span><span style="color: #0000BB">$a</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">true</span><span style="color: #007700">)&nbsp;.&nbsp;</span><span style="color: #DD0000">';'</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;$b&nbsp;=&nbsp;A::__set_state(array(<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;&nbsp;&nbsp;&nbsp;'var1'&nbsp;=&gt;&nbsp;5,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;&nbsp;&nbsp;&nbsp;'var2'&nbsp;=&gt;&nbsp;'foo',<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;));<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$b</span><span style="color: #007700">);<br /><br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

    <div class="example-contents"><p>The above example will output:</p></div>
    <div class="example-contents screen">
<div class="cdata"><pre>
object(A)#2 (2) {
  [&quot;var1&quot;]=&gt;
  int(5)
  [&quot;var2&quot;]=&gt;
  string(3) &quot;foo&quot;
}
</pre></div>
    </div>
   </div>
   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <span class="simpara">
     When exporting an object, <span class="function"><a href="function.var-export.php" class="function">var_export()</a></span> does not check
     whether <a href="language.oop5.magic.php#object.set-state" class="link">__set_state()</a> is
     implemented by the object&#039;s class, so re-importing such objects will fail,
     if __set_state() is not implemented. Particularly, this affects some
     internal classes.
    </span>
    <span class="simpara">
     It is the responsibility of the programmer to verify that only objects will
     be re-imported, whose class implements __set_state().
    </span>
   </p></blockquote>
  </div>

  <div class="sect2" id="language.oop5.magic.debuginfo">
   <h3 class="title"><a href="language.oop5.magic.php#object.debuginfo" class="link">__debugInfo()</a></h3>
   <div class="methodsynopsis dc-description" id="object.debuginfo">
    <span class="type">array</span> <span class="methodname"><strong>__debugInfo</strong></span>
     ( <span class="methodparam">void</span>
    )</div>

   <p class="para">
    This method is called by <span class="function"><a href="function.var-dump.php" class="function">var_dump()</a></span> when dumping an
    object to get the properties that should be shown. If the method isn&#039;t
    defined on an object, then all public, protected and private properties
    will be shown.
   </p>
   <p class="para">
    This feature was added in PHP 5.6.0.
   </p>
   <div class="example" id="language.oop5.traits.composition.ex1">
    <p><strong>Example #5 Using <a href="language.oop5.magic.php#object.debuginfo" class="link">__debugInfo()</a></strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">C&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;private&nbsp;</span><span style="color: #0000BB">$prop</span><span style="color: #007700">;<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">__construct</span><span style="color: #007700">(</span><span style="color: #0000BB">$val</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">prop&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$val</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">__debugInfo</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;[<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'propSquared'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">prop&nbsp;</span><span style="color: #007700">**&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;];<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(new&nbsp;</span><span style="color: #0000BB">C</span><span style="color: #007700">(</span><span style="color: #0000BB">42</span><span style="color: #007700">));<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

    <div class="example-contents"><p>The above example will output:</p></div>
    <div class="example-contents screen">
<div class="cdata"><pre>
object(C)#1 (1) {
  [&quot;propSquared&quot;]=&gt;
  int(1764)
}
</pre></div>
    </div>
   </div>
  </div>
 </div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.oop5.magic&amp;redirect=http://php.net/manual/en/language.oop5.magic.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">45 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="86111">  <div class="votes">
    <div id="Vu86111">
    <a href="/manual/vote-note.php?id=86111&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86111">
    <a href="/manual/vote-note.php?id=86111&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86111" title="74% like this...">
    30
    </div>
  </div>
  <a href="#86111" class="name">
  <strong class="user"><em>jon at webignition dot net</em></strong></a><a class="genanchor" href="#86111"> &para;</a><div class="date" title="2008-10-03 07:26"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86111">
<div class="phpcode"><code><span class="html">
The __toString() method is extremely useful for converting class attribute names and values into common string representations of data (of which there are many choices). I mention this as previous references to __toString() refer only to debugging uses.<br /><br />I have previously used the __toString() method in the following ways:<br /><br /> - representing a data-holding object as:<br />&nbsp;&nbsp; - XML<br />&nbsp;&nbsp; - raw POST data<br />&nbsp;&nbsp; - a GET query string<br />&nbsp;&nbsp; - header name:value pairs<br /><br /> - representing a custom mail object as an actual email (headers then body, all correctly represented)<br /><br />When creating a class, consider what possible standard string representations are available and, of those, which would be the most relevant with respect to the purpose of the class.<br /><br />Being able to represent data-holding objects in standardised string forms makes it much easier for your internal representations of data to be shared in an interoperable way with other applications.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="87404">  <div class="votes">
    <div id="Vu87404">
    <a href="/manual/vote-note.php?id=87404&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd87404">
    <a href="/manual/vote-note.php?id=87404&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V87404" title="66% like this...">
    7
    </div>
  </div>
  <a href="#87404" class="name">
  <strong class="user"><em>jsnell at e-normous dot com</em></strong></a><a class="genanchor" href="#87404"> &para;</a><div class="date" title="2008-12-03 02:01"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom87404">
<div class="phpcode"><code><span class="html">
Be very careful to define __set_state() in classes which inherit from a parent using it, as the static __set_state() call will be called for any children.&nbsp; If you are not careful, you will end up with an object of the wrong type.&nbsp; Here is an example:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">A<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$var1</span><span class="keyword">; <br /><br />&nbsp; &nbsp; public static function </span><span class="default">__set_state</span><span class="keyword">(</span><span class="default">$an_array</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$obj </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">var1 </span><span class="keyword">= </span><span class="default">$an_array</span><span class="keyword">[</span><span class="string">'var1'</span><span class="keyword">];&nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$obj</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">B </span><span class="keyword">extends </span><span class="default">A </span><span class="keyword">{<br />}<br /><br /></span><span class="default">$b </span><span class="keyword">= new </span><span class="default">B</span><span class="keyword">;<br /></span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">var1 </span><span class="keyword">= </span><span class="default">5</span><span class="keyword">;<br /><br />eval(</span><span class="string">'$new_b = ' </span><span class="keyword">. </span><span class="default">var_export</span><span class="keyword">(</span><span class="default">$b</span><span class="keyword">, </span><span class="default">true</span><span class="keyword">) . </span><span class="string">';'</span><span class="keyword">); <br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$new_b</span><span class="keyword">);<br /></span><span class="comment">/*<br />object(A)#2 (1) {<br />&nbsp; ["var1"]=&gt;<br />&nbsp; int(5)<br />}<br />*/<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="49413">  <div class="votes">
    <div id="Vu49413">
    <a href="/manual/vote-note.php?id=49413&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd49413">
    <a href="/manual/vote-note.php?id=49413&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V49413" title="62% like this...">
    8
    </div>
  </div>
  <a href="#49413" class="name">
  <strong class="user"><em>ddavenport at newagedigital dot com</em></strong></a><a class="genanchor" href="#49413"> &para;</a><div class="date" title="2005-01-26 11:09"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom49413">
<div class="phpcode"><code><span class="html">
One of the principles of OOP is encapsulation--the idea that an object should handle its own data and no others'.&nbsp; Asking base classes to take care of subclasses' data, esp considering that a class can't possibly know how many dozens of ways it will be extended, is irresponsible and dangerous.<br /><br />Consider the following...<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">SomeStupidStorageClass<br /></span><span class="keyword">{<br />&nbsp; public function </span><span class="default">getContents</span><span class="keyword">(</span><span class="default">$pos</span><span class="keyword">, </span><span class="default">$len</span><span class="keyword">) { ...</span><span class="default">stuff</span><span class="keyword">... }<br />}<br /><br />class </span><span class="default">CryptedStorageClass </span><span class="keyword">extends </span><span class="default">SomeStupidStorageClass<br /></span><span class="keyword">{<br />&nbsp; private </span><span class="default">$decrypted_block</span><span class="keyword">;<br />&nbsp; public function </span><span class="default">getContents</span><span class="keyword">(</span><span class="default">$pos</span><span class="keyword">, </span><span class="default">$len</span><span class="keyword">) { ...</span><span class="default">decrypt</span><span class="keyword">... }<br />}<br /></span><span class="default">?&gt;<br /></span><br />If SomeStupidStorageClass decided to serialize its subclasses' data as well as its own, a portion of what was once an encrypted thingie could be stored, in the clear, wherever the thingie was stored.&nbsp; Obviously, CryptedStorageClass would never have chosen this...but it had to either know how to serialize its parent class's data without calling parent::_sleep(), or let the base class do what it wanted to.<br /><br />Considering encapsulation again, no class should have to know how the parent handles its own private data.&nbsp; And it certainly shouldn't have to worry that users will find a way to break access controls in the name of convenience.<br /><br />If a class wants both to have private/protected data and to survive serialization, it should have its own __sleep() method which asks the parent to report its own fields and then adds to the list if applicable.&nbsp; Like so....<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">BetterClass<br /></span><span class="keyword">{<br />&nbsp; private </span><span class="default">$content</span><span class="keyword">;<br /><br />&nbsp; public function </span><span class="default">__sleep</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; return array(</span><span class="string">'basedata1'</span><span class="keyword">, </span><span class="string">'basedata2'</span><span class="keyword">);<br />&nbsp; }<br /><br />&nbsp; public function </span><span class="default">getContents</span><span class="keyword">() { ...</span><span class="default">stuff</span><span class="keyword">... }<br />}<br /><br />class </span><span class="default">BetterDerivedClass </span><span class="keyword">extends </span><span class="default">BetterClass<br /></span><span class="keyword">{<br />&nbsp; private </span><span class="default">$decrypted_block</span><span class="keyword">;<br /><br />&nbsp; public function </span><span class="default">__sleep</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; return </span><span class="default">parent</span><span class="keyword">::</span><span class="default">__sleep</span><span class="keyword">();<br />&nbsp; }<br /><br />&nbsp; public function </span><span class="default">getContents</span><span class="keyword">() { ...</span><span class="default">decrypt</span><span class="keyword">... }<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />The derived class has better control over its data, and we don't have to worry about something being stored that shouldn't be.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="55844">  <div class="votes">
    <div id="Vu55844">
    <a href="/manual/vote-note.php?id=55844&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd55844">
    <a href="/manual/vote-note.php?id=55844&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V55844" title="66% like this...">
    4
    </div>
  </div>
  <a href="#55844" class="name">
  <strong class="user"><em>martin dot goldinger at netserver dot ch</em></strong></a><a class="genanchor" href="#55844"> &para;</a><div class="date" title="2005-08-15 04:47"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom55844">
<div class="phpcode"><code><span class="html">
When you use sessions, its very important to keep the sessiondata small, due to low performance with unserialize. Every class shoud extend from this class. The result will be, that no null Values are written to the sessiondata. It will increase performance.<br /><br />&lt;?<br />class BaseObject<br />{<br />&nbsp; &nbsp; function __sleep()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; $vars = (array)$this;<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach ($vars as $key =&gt; $val)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (is_null($val))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; unset($vars[$key]);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }&nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; return array_keys($vars);<br />&nbsp; &nbsp; }<br />};<br />?&gt;</span>
</code></div>
  </div>
 </div>
  <div class="note" id="107509">  <div class="votes">
    <div id="Vu107509">
    <a href="/manual/vote-note.php?id=107509&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd107509">
    <a href="/manual/vote-note.php?id=107509&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V107509" title="57% like this...">
    10
    </div>
  </div>
  <a href="#107509" class="name">
  <strong class="user"><em>daan dot broekhof at gmail dot com</em></strong></a><a class="genanchor" href="#107509"> &para;</a><div class="date" title="2012-02-14 10:54"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom107509">
<div class="phpcode"><code><span class="html">
Ever wondered why you can't throw exceptions from __toString()? Yeah me too. <br /><br />Well now you can! This trick allows you to throw any type of exception from within a __toString(), with a full &amp; correct backtrace.<br /><br />How does it work? Well PHP __toString() handling is not as strict in every case: throwing an Exception from __toString() triggers a fatal E_ERROR, but returning a non-string value from a __toString() triggers a non-fatal E_RECOVERABLE_ERROR. <br />Add a little bookkeeping, and can circumvented this PHP deficiency!<br />(tested to work PHP 5.3+)<br /><br /><span class="default">&lt;?php<br /><br />set_error_handler</span><span class="keyword">(array(</span><span class="string">'My_ToStringFixer'</span><span class="keyword">, </span><span class="string">'errorHandler'</span><span class="keyword">));<br /></span><span class="default">error_reporting</span><span class="keyword">(</span><span class="default">E_ALL </span><span class="keyword">| </span><span class="default">E_STRICT</span><span class="keyword">);<br /><br />class </span><span class="default">My_ToStringFixer<br /></span><span class="keyword">{<br />&nbsp; &nbsp; protected static </span><span class="default">$_toStringException</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public static function </span><span class="default">errorHandler</span><span class="keyword">(</span><span class="default">$errorNumber</span><span class="keyword">, </span><span class="default">$errorMessage</span><span class="keyword">, </span><span class="default">$errorFile</span><span class="keyword">, </span><span class="default">$errorLine</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (isset(</span><span class="default">self</span><span class="keyword">::</span><span class="default">$_toStringException</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$exception </span><span class="keyword">= </span><span class="default">self</span><span class="keyword">::</span><span class="default">$_toStringException</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Always unset '_toStringException', we don't want a straggler to be found later if something came between the setting and the error<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">$_toStringException </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">preg_match</span><span class="keyword">(</span><span class="string">'~^Method .*::__toString\(\) must return a string value$~'</span><span class="keyword">, </span><span class="default">$errorMessage</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw </span><span class="default">$exception</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public static function </span><span class="default">throwToStringException</span><span class="keyword">(</span><span class="default">$exception</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Should not occur with prescribed usage, but in case of recursion: clean out exception, return a valid string, and weep<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">if (isset(</span><span class="default">self</span><span class="keyword">::</span><span class="default">$_toStringException</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">$_toStringException </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">$_toStringException </span><span class="keyword">= </span><span class="default">$exception</span><span class="keyword">;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">My_Class<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">doComplexStuff</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">Exception</span><span class="keyword">(</span><span class="string">'Oh noes!'</span><span class="keyword">);<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">__toString</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; try<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// do your complex thing which might trigger an exception<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">doComplexStuff</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; catch (</span><span class="default">Exception $e</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// The 'return' is required to trigger the trick<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">My_ToStringFixer</span><span class="keyword">::</span><span class="default">throwToStringException</span><span class="keyword">(</span><span class="default">$e</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$x </span><span class="keyword">= new </span><span class="default">My_Class</span><span class="keyword">();<br /><br />try<br />{<br />&nbsp; &nbsp; echo </span><span class="default">$x</span><span class="keyword">;<br />}<br />catch (</span><span class="default">Exception $e</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; echo </span><span class="string">'Caught Exception! : '</span><span class="keyword">. </span><span class="default">$e</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="81492">  <div class="votes">
    <div id="Vu81492">
    <a href="/manual/vote-note.php?id=81492&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd81492">
    <a href="/manual/vote-note.php?id=81492&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V81492" title="59% like this...">
    8
    </div>
  </div>
  <a href="#81492" class="name">
  <strong class="user"><em>dhuseby domain getback tld com</em></strong></a><a class="genanchor" href="#81492"> &para;</a><div class="date" title="2008-02-29 06:22"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom81492">
<div class="phpcode"><code><span class="html">
The above hint for using array_keys((array)$obj) got me investigating how to get __sleep to really work with object hierarchies.<br /><br />With PHP 5.2.3, If you want to serialize an object that is part of an object hierarchy and you want to selectively serialize members (public, private, and protected) by manually specifying the array of members, there are a few simple rules for naming members that you must follow:<br /><br />1. public members should be named using just their member name, like so:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Foo </span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$bar</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public function </span><span class="default">__sleep</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return array(</span><span class="string">"bar"</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />2. protected members should be named using "\0" . "*" . "\0" . member name, like so:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Foo </span><span class="keyword">{<br />&nbsp; &nbsp; protected </span><span class="default">$bar</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public function </span><span class="default">__sleep</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return array(</span><span class="string">"\0*\0bar"</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />3. private members should be named using "\0" . class name . "\0" . member name, like so:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Foo </span><span class="keyword">{<br />&nbsp; &nbsp; private </span><span class="default">$bar</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public function </span><span class="default">__sleep</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return array(</span><span class="string">"\0Foo\0bar"</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />So with this information let us serialize a class hierarchy correctly:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">Base </span><span class="keyword">{<br />&nbsp; &nbsp; private </span><span class="default">$foo </span><span class="keyword">= </span><span class="string">"foo_value"</span><span class="keyword">;<br />&nbsp; &nbsp; protected </span><span class="default">$bar </span><span class="keyword">= </span><span class="string">"bar_value"</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public function </span><span class="default">__sleep</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return array(</span><span class="string">"\0Base\0foo"</span><span class="keyword">, </span><span class="string">"\0*\0bar"</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">Derived </span><span class="keyword">extends </span><span class="default">Base </span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$baz </span><span class="keyword">= </span><span class="string">"baz_value"</span><span class="keyword">;<br />&nbsp; &nbsp; private </span><span class="default">$boo </span><span class="keyword">= </span><span class="string">"boo_value"</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public function </span><span class="default">__sleep</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// we have to merge our members with our parent's<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">array_merge</span><span class="keyword">(array(</span><span class="string">"baz"</span><span class="keyword">, </span><span class="string">"\0Derived\0boo"</span><span class="keyword">), </span><span class="default">parent</span><span class="keyword">::</span><span class="default">__sleep</span><span class="keyword">());<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">Leaf </span><span class="keyword">extends </span><span class="default">Derived </span><span class="keyword">{<br />&nbsp; &nbsp; private </span><span class="default">$qux </span><span class="keyword">= </span><span class="string">"qux_value"</span><span class="keyword">;<br />&nbsp; &nbsp; protected </span><span class="default">$zaz </span><span class="keyword">= </span><span class="string">"zaz_value"</span><span class="keyword">;<br />&nbsp; &nbsp; public </span><span class="default">$blah </span><span class="keyword">= </span><span class="string">"blah_value"</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public function </span><span class="default">__sleep</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// again, merge our members with our parent's<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">array_merge</span><span class="keyword">(array(</span><span class="string">"\0Leaf\0qux"</span><span class="keyword">, </span><span class="string">"\0*\0zaz"</span><span class="keyword">, </span><span class="string">"blah"</span><span class="keyword">), </span><span class="default">parent</span><span class="keyword">::</span><span class="default">__sleep</span><span class="keyword">());<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="comment">// test it<br /></span><span class="default">$test </span><span class="keyword">= new </span><span class="default">Leaf</span><span class="keyword">();<br /></span><span class="default">$s </span><span class="keyword">= </span><span class="default">serialize</span><span class="keyword">(</span><span class="default">$test</span><span class="keyword">);<br /></span><span class="default">$test2 </span><span class="keyword">= </span><span class="default">unserialize</span><span class="keyword">(</span><span class="default">$s</span><span class="keyword">);<br />echo </span><span class="default">$s</span><span class="keyword">;<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$test</span><span class="keyword">);<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$test2</span><span class="keyword">);<br /><br /></span><span class="default">?&gt;<br /></span><br />Now if you comment out all of the __sleep() functions and output the serialized string, you will see that the output doesn't change.&nbsp; The most important part of course is that with the proper __sleep() functions, we can unserialize the string and get a properly set up object.<br /><br />I hope this solves the mystery for everybody.&nbsp; __sleep() does work, if you use it correctly :-)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="48849">  <div class="votes">
    <div id="Vu48849">
    <a href="/manual/vote-note.php?id=48849&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd48849">
    <a href="/manual/vote-note.php?id=48849&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V48849" title="58% like this...">
    9
    </div>
  </div>
  <a href="#48849" class="name">
  <strong class="user"><em>krisj1010 at gmail.com</em></strong></a><a class="genanchor" href="#48849"> &para;</a><div class="date" title="2005-01-09 12:09"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom48849">
<div class="phpcode"><code><span class="html">
If you are attempting to write an abstract/base class which automates the __sleep process in PHP5 you will run into some trouble if the subclasses which are being serialized have private/protected variables you need to be serialized.&nbsp; <br /><br />The reason is, even though get_class($this) within the base class will return the subclass -- get_class_vars(get_class($this)) will *not* return the subclass' protected/private variables.&nbsp; Which makes sense -- using OO principles.&nbsp; <br /><br />However, when automating __sleep it becomes necissary to have access to the private/protected subclass variables because their names have to be returned by __sleep.<br /><br />So here is the work around:<br /><span class="default">&lt;?php<br /></span><span class="keyword">public function </span><span class="default">__sleep</span><span class="keyword">()<br />{<br /> ... </span><span class="default">code </span><span class="keyword">...<br /></span><span class="default">$sleepVars&nbsp; &nbsp; </span><span class="keyword">= </span><span class="default">array_keys</span><span class="keyword">((array)</span><span class="default">$this</span><span class="keyword">);<br />return </span><span class="default">$sleepVars</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />Even though array_keys includes more information about the variable names than just the variable names -- it still seems to work appropriately.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="98691">  <div class="votes">
    <div id="Vu98691">
    <a href="/manual/vote-note.php?id=98691&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd98691">
    <a href="/manual/vote-note.php?id=98691&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V98691" title="62% like this...">
    4
    </div>
  </div>
  <a href="#98691" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#98691"> &para;</a><div class="date" title="2010-06-30 09:29"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom98691">
<div class="phpcode"><code><span class="html">
C++-style operator overloading finally makes an appearance with the introduction to __invoke().&nbsp; Unfortunately, with just '()'.&nbsp; In that sense, it is no more useful than having a default class method (probably quite useful actually) and not having to type out an entire method name.&nbsp; Complimenting wbcarts at juno dot com's point class below, the following allows calculating distance between one or more graph points...<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">point </span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$x</span><span class="keyword">;<br />&nbsp; &nbsp; public </span><span class="default">$y</span><span class="keyword">;<br /><br />&nbsp; &nbsp; function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$x</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">, </span><span class="default">$y</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">x </span><span class="keyword">= (int) </span><span class="default">$x</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">y </span><span class="keyword">= (int) </span><span class="default">$y</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">__invoke</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$args </span><span class="keyword">= </span><span class="default">func_get_args</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$total_distance </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$current_loc </span><span class="keyword">= </span><span class="default">$this</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach (</span><span class="default">$args </span><span class="keyword">as </span><span class="default">$arg</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">is_object</span><span class="keyword">(</span><span class="default">$arg</span><span class="keyword">) and (</span><span class="default">get_class</span><span class="keyword">(</span><span class="default">$arg</span><span class="keyword">) === </span><span class="default">get_class</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">))) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$total_distance </span><span class="keyword">+= </span><span class="default">sqrt</span><span class="keyword">(</span><span class="default">pow</span><span class="keyword">(</span><span class="default">$arg</span><span class="keyword">-&gt;</span><span class="default">x </span><span class="keyword">- </span><span class="default">$current_loc</span><span class="keyword">-&gt;</span><span class="default">x</span><span class="keyword">, </span><span class="default">2</span><span class="keyword">) + </span><span class="default">pow</span><span class="keyword">((int) </span><span class="default">$arg</span><span class="keyword">-&gt;</span><span class="default">y </span><span class="keyword">- </span><span class="default">$current_loc</span><span class="keyword">-&gt;</span><span class="default">y</span><span class="keyword">, </span><span class="default">2</span><span class="keyword">));<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$current_loc </span><span class="keyword">= </span><span class="default">$arg</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">trigger_error</span><span class="keyword">(</span><span class="string">"Arguments must be objects of this class."</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$total_distance</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; }<br /><br /></span><span class="default">$p1 </span><span class="keyword">= new </span><span class="default">point</span><span class="keyword">(</span><span class="default">1</span><span class="keyword">,</span><span class="default">1</span><span class="keyword">);<br /></span><span class="default">$p2 </span><span class="keyword">= new </span><span class="default">point</span><span class="keyword">(</span><span class="default">23</span><span class="keyword">,-</span><span class="default">6</span><span class="keyword">);<br /></span><span class="default">$p3 </span><span class="keyword">= new </span><span class="default">point</span><span class="keyword">(</span><span class="default">15</span><span class="keyword">,</span><span class="default">20</span><span class="keyword">);<br />echo </span><span class="default">$p1</span><span class="keyword">(</span><span class="default">$p2</span><span class="keyword">,</span><span class="default">$p3</span><span class="keyword">,</span><span class="default">$p1</span><span class="keyword">); </span><span class="comment">// round trip 73.89<br /><br /></span><span class="default">?&gt;<br /></span><br />Functionally, __invoke() can also be used to mimic the use of variable functions.&nbsp; Sadly, attempting any calling of __invoke() on a static level will produce a fatal error.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="112193">  <div class="votes">
    <div id="Vu112193">
    <a href="/manual/vote-note.php?id=112193&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd112193">
    <a href="/manual/vote-note.php?id=112193&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V112193" title="58% like this...">
    5
    </div>
  </div>
  <a href="#112193" class="name">
  <strong class="user"><em>staff at pro-unreal dot de</em></strong></a><a class="genanchor" href="#112193"> &para;</a><div class="date" title="2013-05-16 06:08"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom112193">
<div class="phpcode"><code><span class="html">
To avoid instanciating the parent instead of the inherited class for __set_state() as reported by jsnell, you could use late static binding introduced in PHP 5.3:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">A </span><span class="keyword">{<br />&nbsp; &nbsp; public static function </span><span class="default">__set_state</span><span class="keyword">(</span><span class="default">$data</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; return new static();<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">B </span><span class="keyword">extends </span><span class="default">A </span><span class="keyword">{<br />}<br /><br /></span><span class="default">$instance </span><span class="keyword">= new </span><span class="default">B</span><span class="keyword">();<br />eval(</span><span class="string">'$test = ' </span><span class="keyword">. </span><span class="default">var_export</span><span class="keyword">(</span><span class="default">$instance</span><span class="keyword">, </span><span class="default">true</span><span class="keyword">) . </span><span class="string">';'</span><span class="keyword">);<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$test</span><span class="keyword">);<br /></span><span class="comment">// -&gt; object(B)#2 (0) {<br />// }<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="82629">  <div class="votes">
    <div id="Vu82629">
    <a href="/manual/vote-note.php?id=82629&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd82629">
    <a href="/manual/vote-note.php?id=82629&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V82629" title="61% like this...">
    3
    </div>
  </div>
  <a href="#82629" class="name">
  <strong class="user"><em>michal dot kocarek at seznam dot cz</em></strong></a><a class="genanchor" href="#82629"> &para;</a><div class="date" title="2008-04-18 02:34"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom82629">
<div class="phpcode"><code><span class="html">
Remember that setters and getters (__set, __get) will work in your class as long as you NOT SET the property with given name.<br /><br />If you still want to have the public property definition in the class source code (phpDocumentor, editor code completition, or any other reason) when using these magic methods, simply unset() your public properties inside the constructor.<br />__set/__get function will be called and code reader will see at first sight, which public properties are available.<br /><br />Example:<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">user </span><span class="keyword">{<br />&nbsp;&nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp; * @var int Gets and sets the user ID<br />&nbsp; &nbsp; */<br />&nbsp;&nbsp; </span><span class="keyword">public </span><span class="default">$UserID</span><span class="keyword">;<br />&nbsp;&nbsp; private </span><span class="default">$_userID</span><span class="keyword">;<br /><br />&nbsp;&nbsp; public function </span><span class="default">__construct</span><span class="keyword">() {<br /><br />&nbsp; &nbsp; &nbsp; </span><span class="comment">// All the magic is in single line:<br />&nbsp; &nbsp; &nbsp; // We unset public property, so our setters and getters<br />&nbsp; &nbsp; &nbsp; // are used and phpDoc and editors with code completition are happy<br />&nbsp; &nbsp; &nbsp; </span><span class="keyword">unset(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">UserID</span><span class="keyword">);<br /><br />&nbsp;&nbsp; }<br /><br />&nbsp;&nbsp; public function </span><span class="default">__set</span><span class="keyword">(</span><span class="default">$key</span><span class="keyword">, </span><span class="default">$value</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; </span><span class="comment">// assign value for key UserID to _userID property<br />&nbsp;&nbsp; </span><span class="keyword">}<br /><br />&nbsp;&nbsp; public function </span><span class="default">__get</span><span class="keyword">(</span><span class="default">$key</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; </span><span class="comment">// return value of _userID for UserID property<br />&nbsp;&nbsp; </span><span class="keyword">}<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="72532">  <div class="votes">
    <div id="Vu72532">
    <a href="/manual/vote-note.php?id=72532&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd72532">
    <a href="/manual/vote-note.php?id=72532&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V72532" title="60% like this...">
    3
    </div>
  </div>
  <a href="#72532" class="name">
  <strong class="user"><em>Dérico Filho</em></strong></a><a class="genanchor" href="#72532"> &para;</a><div class="date" title="2007-01-23 07:33"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom72532">
<div class="phpcode"><code><span class="html">
Since PHP 5.2.0, you'll always get an error like this:<br />"Object of class foo could not be converted to string"<br /><br />When one tries to use an object as string, for instance:<br /><br />class Test{}<br />echo new Test();<br /><br />Thus, one way to avoid this problem is to programme the magic method __toString.<br /><br />However, in the older versions, it would output a string saying that it was an object together a unique obj id. Therefore, the __toString() method must comply with this behaviour.<br /><br />My suggestion:<br /><br />class Test{<br />&nbsp; &nbsp; function __toString(){<br />&nbsp; &nbsp; &nbsp; &nbsp; if(!isset($this-&gt;__uniqid))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $this-&gt;__uniqid = md5(uniqid(rand(), true));<br />&nbsp; &nbsp; &nbsp; &nbsp; return(get_class($this)."@".$this-&gt;__uniqid);<br />&nbsp; &nbsp; }<br /><br />}<br /><br />echo new Test();<br /><br />would output something like this:<br /><br />Test@6006ba04f5569544c10a588b04849cf7</span>
</code></div>
  </div>
 </div>
  <div class="note" id="112209">  <div class="votes">
    <div id="Vu112209">
    <a href="/manual/vote-note.php?id=112209&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd112209">
    <a href="/manual/vote-note.php?id=112209&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V112209" title="58% like this...">
    2
    </div>
  </div>
  <a href="#112209" class="name">
  <strong class="user"><em>danillo dot paiva dot toledo at gmail dot com</em></strong></a><a class="genanchor" href="#112209"> &para;</a><div class="date" title="2013-05-16 07:39"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom112209">
<div class="phpcode"><code><span class="html">
While I was studying Ruby I saw as such interesting things as properties created + its getters and setters in just one line.<br /><br />I tryied to do the same in PHP and this is the code I have<br /><br />class Father {<br />&nbsp; &nbsp; public function __call($name, $args) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if(isset($this-&gt;$name)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(isset($args[0]))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return $this-&gt;$name = $args[0];<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return $this-&gt;$name;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; return false;<br />&nbsp; &nbsp; }<br />}<br /><br />class Child extends Father {<br />&nbsp; &nbsp; public $country = "Brazil";<br />&nbsp; &nbsp; public $state = "Sao Paulo";<br />}<br /><br />Sometimes we don't need things like that on all classes but is quite interesting.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="55806">  <div class="votes">
    <div id="Vu55806">
    <a href="/manual/vote-note.php?id=55806&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd55806">
    <a href="/manual/vote-note.php?id=55806&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V55806" title="60% like this...">
    2
    </div>
  </div>
  <a href="#55806" class="name">
  <strong class="user"><em>jeffxlevy at gmail dot com</em></strong></a><a class="genanchor" href="#55806"> &para;</a><div class="date" title="2005-08-13 06:26"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom55806">
<div class="phpcode"><code><span class="html">
Intriguing what happens when __sleep() and __wakeup() and sessions() are mixed. I had a hunch that, as session data is serialized, __sleep would be called when an object, or whatever, is stored in _SESSION. true. The same hunch applied when session_start() was called. Would __wakeup() be called? True. Very helpful, specifically as I'm building massive objects (well, lots of simple objects stored in sessions), and need lots of automated tasks (potentially) reloaded at "wakeup" time. (for instance, restarting a database session/connection).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="107031">  <div class="votes">
    <div id="Vu107031">
    <a href="/manual/vote-note.php?id=107031&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd107031">
    <a href="/manual/vote-note.php?id=107031&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V107031" title="54% like this...">
    3
    </div>
  </div>
  <a href="#107031" class="name">
  <strong class="user"><em>osbertv at yahoo dot com</em></strong></a><a class="genanchor" href="#107031"> &para;</a><div class="date" title="2011-12-29 09:42"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom107031">
<div class="phpcode"><code><span class="html">
Invoking a class inside a class results in an error.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">A<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">__invoke</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Invoking A() Class"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">B <br /></span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$a</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">a </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">();<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">__invoke</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Invoking B() Class"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">();<br /></span><span class="default">$b </span><span class="keyword">= new </span><span class="default">B</span><span class="keyword">();<br /></span><span class="default">$a</span><span class="keyword">();<br /></span><span class="default">$b</span><span class="keyword">();<br /></span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">a</span><span class="keyword">();<br /><br /></span><span class="default">?&gt;<br /></span><br />returns<br />Invoking B() Class<br />PHP Fatal error:&nbsp; Call to undefined method B::a()</span>
</code></div>
  </div>
 </div>
  <div class="note" id="69361">  <div class="votes">
    <div id="Vu69361">
    <a href="/manual/vote-note.php?id=69361&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd69361">
    <a href="/manual/vote-note.php?id=69361&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V69361" title="54% like this...">
    1
    </div>
  </div>
  <a href="#69361" class="name">
  <strong class="user"><em>jstubbs at work-at dot co dot jp</em></strong></a><a class="genanchor" href="#69361"> &para;</a><div class="date" title="2006-09-02 12:32"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom69361">
<div class="phpcode"><code><span class="html">
$myclass-&gt;foo['bar'] = 'baz';<br /><br />When overriding __get and __set, the above code can work (as expected) but it depends on your __get implementation rather than your __set. In fact, __set is never called with the above code. It appears that PHP (at least as of 5.1) uses a reference to whatever was returned by __get. To be more verbose, the above code is essentially identical to:<br /><br />$tmp_array = &amp;$myclass-&gt;foo;<br />$tmp_array['bar'] = 'baz';<br />unset($tmp_array);<br /><br />Therefore, the above won't do anything if your __get implementation resembles this:<br /><br />function __get($name) {<br />&nbsp; &nbsp; return array_key_exists($name, $this-&gt;values)<br />&nbsp; &nbsp; &nbsp; &nbsp; ? $this-&gt;values[$name] : null;<br />}<br /><br />You will actually need to set the value in __get and return that, as in the following code:<br /><br />function __get($name) {<br />&nbsp; &nbsp; if (!array_key_exists($name, $this-&gt;values))<br />&nbsp; &nbsp; &nbsp; &nbsp; $this-&gt;values[$name] = null;<br />&nbsp; &nbsp; return $this-&gt;values[$name];<br />}</span>
</code></div>
  </div>
 </div>
  <div class="note" id="75010">  <div class="votes">
    <div id="Vu75010">
    <a href="/manual/vote-note.php?id=75010&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd75010">
    <a href="/manual/vote-note.php?id=75010&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V75010" title="52% like this...">
    1
    </div>
  </div>
  <a href="#75010" class="name">
  <strong class="user"><em>Travis Swicegood</em></strong></a><a class="genanchor" href="#75010"> &para;</a><div class="date" title="2007-05-08 07:43"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom75010">
<div class="phpcode"><code><span class="html">
There is no need to use eval() to mimic mixins (i.e., multiple inheritance) within PHP 5.&nbsp; You only need to:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">MyClass<br /></span><span class="keyword">{<br />&nbsp; &nbsp; private </span><span class="default">$_obj </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$obj</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">_obj </span><span class="keyword">= </span><span class="default">$obj</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">__call</span><span class="keyword">(</span><span class="default">$method</span><span class="keyword">, </span><span class="default">$args</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (!</span><span class="default">method_exists</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">_obj</span><span class="keyword">, </span><span class="default">$method</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">Exception</span><span class="keyword">(</span><span class="string">"unknown method [</span><span class="default">$method</span><span class="string">]"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">call_user_func_array</span><span class="keyword">(<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; array(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">_obj</span><span class="keyword">, </span><span class="default">$method</span><span class="keyword">),<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$args<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />You could just as easily add an addMixin() method that would allow you to add multiple objects to an array, and then iterate over that array until you found the right method.&nbsp; As noted, these are referred to as a Mixins in other languages.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121158">  <div class="votes">
    <div id="Vu121158">
    <a href="/manual/vote-note.php?id=121158&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121158">
    <a href="/manual/vote-note.php?id=121158&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121158" title="50% like this...">
    0
    </div>
  </div>
  <a href="#121158" class="name">
  <strong class="user"><em>kguest at php dot net</em></strong></a><a class="genanchor" href="#121158"> &para;</a><div class="date" title="2017-05-30 01:27"><strong>6 months ago</strong></div>
  <div class="text" id="Hcom121158">
<div class="phpcode"><code><span class="html">
__debugInfo&nbsp; is also utilised when calling print_r on an object:<br /><br />$ cat test.php<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">FooQ </span><span class="keyword">{<br /><br />&nbsp; &nbsp;&nbsp; private </span><span class="default">$bar </span><span class="keyword">= </span><span class="string">''</span><span class="keyword">;<br /><br />&nbsp; &nbsp;&nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$val</span><span class="keyword">) {<br /><br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">bar </span><span class="keyword">= </span><span class="default">$val</span><span class="keyword">;<br />&nbsp; &nbsp;&nbsp; }<br /><br />&nbsp; &nbsp;&nbsp; public function </span><span class="default">__debugInfo</span><span class="keyword">()<br />&nbsp; &nbsp;&nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; return [</span><span class="string">'_bar' </span><span class="keyword">=&gt; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">bar</span><span class="keyword">];<br />&nbsp; &nbsp;&nbsp; }<br />}<br /></span><span class="default">$fooq </span><span class="keyword">= new </span><span class="default">FooQ</span><span class="keyword">(</span><span class="string">"q"</span><span class="keyword">);<br /></span><span class="default">print_r </span><span class="keyword">(</span><span class="default">$fooq</span><span class="keyword">);<br /><br />$ </span><span class="default">php test</span><span class="keyword">.</span><span class="default">php<br />FooQ Object<br /></span><span class="keyword">(<br />&nbsp; &nbsp; [</span><span class="default">_bar</span><span class="keyword">] =&gt; </span><span class="default">q<br /></span><span class="keyword">)<br />$</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="111981">  <div class="votes">
    <div id="Vu111981">
    <a href="/manual/vote-note.php?id=111981&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd111981">
    <a href="/manual/vote-note.php?id=111981&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V111981" title="50% like this...">
    0
    </div>
  </div>
  <a href="#111981" class="name">
  <strong class="user"><em>igorbt</em></strong></a><a class="genanchor" href="#111981"> &para;</a><div class="date" title="2013-04-18 08:30"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom111981">
<div class="phpcode"><code><span class="html">
In recent versions of PHP, if you define __toString with arguments it will trigger a Fatal error: "__tostring() cannot take arguments". But, if you really need this (like I needed, because my framework heavily used these arguments), you have a workaround:<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">a <br /></span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">__toString</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; list(</span><span class="default">$a</span><span class="keyword">) = </span><span class="default">func_get_args</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$a</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">a</span><span class="keyword">();<br />echo </span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">__toString</span><span class="keyword">(</span><span class="string">'PHP'</span><span class="keyword">); </span><span class="comment">// PHP<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="90194">  <div class="votes">
    <div id="Vu90194">
    <a href="/manual/vote-note.php?id=90194&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd90194">
    <a href="/manual/vote-note.php?id=90194&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V90194" title="50% like this...">
    0
    </div>
  </div>
  <a href="#90194" class="name">
  <strong class="user"><em>rudie-de-hotblocks at osu1 dot php dot net</em></strong></a><a class="genanchor" href="#90194"> &para;</a><div class="date" title="2009-04-09 06:35"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom90194">
<div class="phpcode"><code><span class="html">
Note also that the constructor is executed also, and before __set_state(), making this magic function less magic, imho, (except for the ability to assign private members).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="83110">  <div class="votes">
    <div id="Vu83110">
    <a href="/manual/vote-note.php?id=83110&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd83110">
    <a href="/manual/vote-note.php?id=83110&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V83110" title="50% like this...">
    0
    </div>
  </div>
  <a href="#83110" class="name">
  <strong class="user"><em>yanleech at gmail dot com</em></strong></a><a class="genanchor" href="#83110"> &para;</a><div class="date" title="2008-05-10 06:24"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom83110">
<div class="phpcode"><code><span class="html">
Maybe we can using unserialize() &amp; __wakeup() instead "new" when creating a new instance of class.<br /><br />Consider following codes:<br /><br />class foo<br />{<br />&nbsp; &nbsp; static public $WAKEUP_STR = 'O:3:"foo":0:{}';<br />&nbsp; &nbsp; public function foo(){}<br />&nbsp; &nbsp; public function bar(){}<br />}<br /><br />$foo = unserialize(foo::$WAKEUP_STR);</span>
</code></div>
  </div>
 </div>
  <div class="note" id="61130">  <div class="votes">
    <div id="Vu61130">
    <a href="/manual/vote-note.php?id=61130&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd61130">
    <a href="/manual/vote-note.php?id=61130&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V61130" title="50% like this...">
    0
    </div>
  </div>
  <a href="#61130" class="name">
  <strong class="user"><em>b dot schoppmeier at bas-consult dot de</em></strong></a><a class="genanchor" href="#61130"> &para;</a><div class="date" title="2006-01-26 03:18"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom61130">
<div class="phpcode"><code><span class="html">
The sequence of events regarding __sleep and __destruct is unusual __ as __destruct is called before __sleep. The following code snippet:<br /><br /><span class="default">&lt;?php<br />$sequence </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />class </span><span class="default">foo </span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$stuff</span><span class="keyword">;&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$param</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; global </span><span class="default">$sequence</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Seq: "</span><span class="keyword">, </span><span class="default">$sequence</span><span class="keyword">++, </span><span class="string">" - constructor\n"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">stuff </span><span class="keyword">= </span><span class="default">$param</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public function </span><span class="default">__destruct</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; global </span><span class="default">$sequence</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Seq: "</span><span class="keyword">, </span><span class="default">$sequence</span><span class="keyword">++, </span><span class="string">" - destructor\n"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public function </span><span class="default">__sleep</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; global </span><span class="default">$sequence</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Seq: "</span><span class="keyword">, </span><span class="default">$sequence</span><span class="keyword">++, </span><span class="string">" - __sleep\n"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; return array(</span><span class="string">"stuff"</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public function </span><span class="default">__wakeup</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; global </span><span class="default">$sequence</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Seq: "</span><span class="keyword">, </span><span class="default">$sequence</span><span class="keyword">++, </span><span class="string">" - __wakeup\n"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">session_start</span><span class="keyword">();<br /></span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">"obj"</span><span class="keyword">] = new </span><span class="default">foo</span><span class="keyword">(</span><span class="string">"A foo"</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />yields the output:<br /><br />Seq: 0 - constructor<br />Seq: 1 - destructor<br />Seq: 2 - __sleep<br /><br />Only when you end your script with a call to session_write_close() as in:<br /><br /><span class="default">&lt;?php<br />$sequence </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />class </span><span class="default">foo </span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$stuff</span><span class="keyword">;&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$param</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; global </span><span class="default">$sequence</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Seq: "</span><span class="keyword">, </span><span class="default">$sequence</span><span class="keyword">++, </span><span class="string">" - constructor\n"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">stuff </span><span class="keyword">= </span><span class="default">$param</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public function </span><span class="default">__destruct</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; global </span><span class="default">$sequence</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Seq: "</span><span class="keyword">, </span><span class="default">$sequence</span><span class="keyword">++, </span><span class="string">" - destructor\n"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public function </span><span class="default">__sleep</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; global </span><span class="default">$sequence</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Seq: "</span><span class="keyword">, </span><span class="default">$sequence</span><span class="keyword">++, </span><span class="string">" - __sleep\n"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; return array(</span><span class="string">"stuff"</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public function </span><span class="default">__wakeup</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; global </span><span class="default">$sequence</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Seq: "</span><span class="keyword">, </span><span class="default">$sequence</span><span class="keyword">++, </span><span class="string">" - __wakeup\n"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">session_start</span><span class="keyword">();<br /></span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">"obj"</span><span class="keyword">] = new </span><span class="default">foo</span><span class="keyword">(</span><span class="string">"A foo"</span><span class="keyword">);<br /></span><span class="default">session_write_close</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span><br />the sequence is as common sense would expect it to be as the following output shows:<br /><br />Seq: 0 - constructor<br />Seq: 1 - __sleep<br />Seq: 2 - destructor</span>
</code></div>
  </div>
 </div>
  <div class="note" id="99058">  <div class="votes">
    <div id="Vu99058">
    <a href="/manual/vote-note.php?id=99058&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd99058">
    <a href="/manual/vote-note.php?id=99058&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V99058" title="47% like this...">
    -1
    </div>
  </div>
  <a href="#99058" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#99058"> &para;</a><div class="date" title="2010-07-24 07:41"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom99058">
<div class="phpcode"><code><span class="html">
Concerning __set() with protected/private/overloaded properties, the behavior might not be so intuitive without knowing some underlying rules.&nbsp; Consider this test object for the following examples...<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">A </span><span class="keyword">{<br />&nbsp; &nbsp; protected </span><span class="default">$test_int </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">;<br />&nbsp; &nbsp; protected </span><span class="default">$test_array </span><span class="keyword">= array(</span><span class="string">'key' </span><span class="keyword">=&gt; </span><span class="string">'test'</span><span class="keyword">);<br />&nbsp; &nbsp; protected </span><span class="default">$test_obj</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">__construct</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">test_obj </span><span class="keyword">= new </span><span class="default">stdClass</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">__get</span><span class="keyword">(</span><span class="default">$prop</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$prop</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">__set</span><span class="keyword">(</span><span class="default">$prop</span><span class="keyword">, </span><span class="default">$val</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$prop </span><span class="keyword">= </span><span class="default">$val</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">();<br /><br /></span><span class="default">?&gt;<br /></span><br />Combined Operators (.=, +=, *=, etc): you must also define a companion __get() method to grant write -and- read access to the property.&nbsp; Remember, "$x += $y" is shorthand for "$x = $x + $y".&nbsp; In other words, "__set($x, (__get($x) + $y))".<br /><br />Properties that are Arrays: attempting to set array values like "$a-&gt;test_array[] = 'asdf';" from outside this object will result in an "Indirect modification of overloaded property" notice and the operation completely ignored.&nbsp; You can't use '[]' for array value assignment in this context (with the exception only if you made __get() return by reference, in which case, it would work fine and bypass the __set() method altogether).&nbsp; You can work around this doing something like unioning the array instead:<br /><br /><span class="default">&lt;?php<br /><br />$a</span><span class="keyword">-&gt;</span><span class="default">test_array</span><span class="keyword">[] = </span><span class="string">'asdf'</span><span class="keyword">; </span><span class="comment">// notice given and ignored unless __get() was declared to return by reference<br /></span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">test_array </span><span class="keyword">+= array(</span><span class="default">1 </span><span class="keyword">=&gt; </span><span class="string">'asdf'</span><span class="keyword">); </span><span class="comment">// to add a key/value<br /></span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">test_array </span><span class="keyword">= array(</span><span class="string">"key" </span><span class="keyword">=&gt; </span><span class="string">'asdf'</span><span class="keyword">) + </span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">test_array</span><span class="keyword">; </span><span class="comment">// to overwrite a&nbsp; key/value.<br /><br /></span><span class="default">?&gt;<br /></span><br />Properties that are Objects: as long as you have that __get() method, you can freely access and alter that sub object's own properties, bypassing __set() entirely.&nbsp; Remember, objects are assigned and passed by reference naturally. <br /><br /><span class="default">&lt;?php<br /><br />$a</span><span class="keyword">-&gt;</span><span class="default">test_obj</span><span class="keyword">-&gt;</span><span class="default">prop </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">; </span><span class="comment">// fine if $a did not have a set method declared.<br /><br /></span><span class="default">?&gt;<br /></span><br />All above tested in 5.3.2.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="104138">  <div class="votes">
    <div id="Vu104138">
    <a href="/manual/vote-note.php?id=104138&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd104138">
    <a href="/manual/vote-note.php?id=104138&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V104138" title="44% like this...">
    -1
    </div>
  </div>
  <a href="#104138" class="name">
  <strong class="user"><em>Wesley</em></strong></a><a class="genanchor" href="#104138"> &para;</a><div class="date" title="2011-05-25 12:10"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom104138">
<div class="phpcode"><code><span class="html">
Warning __toString can be triggerd more then one time<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">if(</span><span class="default">strstr</span><span class="keyword">(</span><span class="default">substr</span><span class="keyword">(</span><span class="default">$obj</span><span class="keyword">,</span><span class="default">0</span><span class="keyword">,</span><span class="default">1024</span><span class="keyword">), </span><span class="string">'somestuff'</span><span class="keyword">)<br />&nbsp; &nbsp; echo </span><span class="default">$obj</span><span class="keyword">;<br />return </span><span class="string">'missing somestuff at the start, create container!'</span><span class="keyword">;<br /><br /></span><span class="default">substr</span><span class="keyword">() </span><span class="default">will trigger a __toString aswell </span><span class="keyword">as echo </span><span class="default">$obj</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />wich cause a performance issue since it will gather all data twice.<br /><br />what i used as a hotfix:<br /><br /><span class="default">&lt;?php<br />__toString</span><span class="keyword">(){<br />&nbsp; if(</span><span class="default">null </span><span class="keyword">=== </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">sToString</span><span class="keyword">)<br />&nbsp; &nbsp;&nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">sToString </span><span class="keyword">= </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">_show</span><span class="keyword">();<br />&nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">sToString</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="66140">  <div class="votes">
    <div id="Vu66140">
    <a href="/manual/vote-note.php?id=66140&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd66140">
    <a href="/manual/vote-note.php?id=66140&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V66140" title="45% like this...">
    -1
    </div>
  </div>
  <a href="#66140" class="name">
  <strong class="user"><em>taylorbarstow at google's mail service</em></strong></a><a class="genanchor" href="#66140"> &para;</a><div class="date" title="2006-05-15 01:54"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom66140">
<div class="phpcode"><code><span class="html">
I've just come accross something interesting relating to storing PHP5 objects in a session.&nbsp; If you don't provide an __autoload(), then you MUST load the class definition before calling session_start().&nbsp; I guess that when you call session_start(), any objects in the session are unserialized then and there and placed into $_SESSION.&nbsp; If you don't provide the class definition before calling session_start(), your object will get the class __PHP_Incomplete_Class, and you won't be able to use it for anything.<br /><br />Examples:<br /><br /><span class="default">&lt;?php<br />session_start</span><span class="keyword">();<br />require_once </span><span class="string">'MyClass.php'</span><span class="keyword">;<br /></span><span class="default">$obj </span><span class="keyword">= new </span><span class="default">MyClass</span><span class="keyword">;<br /></span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'obj'</span><span class="keyword">] = </span><span class="default">$obj</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />Works fine.&nbsp; Then on a subsequent page load:<br /><br /><span class="default">&lt;?php<br />session_start</span><span class="keyword">();<br />require_once </span><span class="string">'MyClass.php'</span><span class="keyword">;<br /></span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'obj'</span><span class="keyword">]-&gt;</span><span class="default">callSomeMethod</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span><br />Fatal error:&nbsp; The script tried to execute a method or access a property of an incomplete object. Please ensure that the class definition "MyClass" of the object you are trying to operate on was loaded _before_ unserialize() gets called or provide a __autoload() function to load the class definition.<br /><br />But if you do this instead, it works fine:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">require_once </span><span class="string">'MyClass.php'</span><span class="keyword">;<br /></span><span class="default">session_start</span><span class="keyword">();<br /></span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'obj'</span><span class="keyword">]-&gt;</span><span class="default">callSomeMethod</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span><br />Hopefully in some future release of PHP, __PHP_Incomplete_Class will be smart enough to check for a class definition at time of use (method call or property operation), and, if the class exists, magically "complete" itself and turn into the desired object.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118617">  <div class="votes">
    <div id="Vu118617">
    <a href="/manual/vote-note.php?id=118617&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118617">
    <a href="/manual/vote-note.php?id=118617&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118617" title="42% like this...">
    -1
    </div>
  </div>
  <a href="#118617" class="name">
  <strong class="user"><em>smiley at HELLOSPAMBOT dot chillerlan dot net</em></strong></a><a class="genanchor" href="#118617"> &para;</a><div class="date" title="2016-01-09 04:30"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom118617">
<div class="phpcode"><code><span class="html">
A simple API wrapper, using __call() and the PHP 5.6 "..." token.<br /><a href="http://php.net/manual/functions.arguments.php#functions.variable-arg-list" rel="nofollow" target="_blank">http://php.net/manual/functions.arguments.php#functions.variable-arg-list</a><br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">namespace </span><span class="default">Example</span><span class="keyword">;<br /><br />use </span><span class="default">Exception</span><span class="keyword">;<br />use </span><span class="default">ReflectionClass</span><span class="keyword">;<br />use </span><span class="default">SomeApiInterface</span><span class="keyword">;<br />use </span><span class="default">SomeHttpClient</span><span class="keyword">;<br />use </span><span class="default">SomeEndpointHandler</span><span class="keyword">;<br /><br /></span><span class="comment">/**<br /> * Class SomeApiWrapper<br /> * <br /> * @method SomeEndpointHandler method1(MethodParams $param1)<br /> * @method SomeEndpointHandler method2(MethodParams $param1, AuthParams $param2 = null)<br /> * ...<br /> * @method SomeEndpointHandler method42()<br /> */<br /></span><span class="keyword">class </span><span class="default">SomeApiWrapper</span><span class="keyword">{<br /><br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * @var \SomeHttpClient<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">private </span><span class="default">$httpClient</span><span class="keyword">;<br /><br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * @var array<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">private </span><span class="default">$methodMap </span><span class="keyword">= [];<br /><br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * SomeApiWrapper constructor.<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">__construct</span><span class="keyword">(){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">mapApiMethods</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">httpClient </span><span class="keyword">= new </span><span class="default">SomeHttpClient</span><span class="keyword">();<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * The API is flat and has ~ 150 endpoints, all of which take optional parameters<br />&nbsp; &nbsp;&nbsp; * from up to 3 groups (method params, authentication, filters). Instead of<br />&nbsp; &nbsp;&nbsp; * implementing the interface and adding countless stubs that have basically<br />&nbsp; &nbsp;&nbsp; * the same signature, i just map its methods here and use __call().<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">private function </span><span class="default">mapApiMethods</span><span class="keyword">(){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$reflectionClass </span><span class="keyword">= new </span><span class="default">ReflectionClass</span><span class="keyword">(</span><span class="default">SomeApiInterface</span><span class="keyword">::class);<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; foreach(</span><span class="default">$reflectionClass</span><span class="keyword">-&gt;</span><span class="default">getMethods</span><span class="keyword">() as </span><span class="default">$m</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">methodMap</span><span class="keyword">[] = </span><span class="default">$m</span><span class="keyword">-&gt;</span><span class="default">name</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Thanks to the PHP 5.6+ "..." token, there's no hassle with the arguments anymore<br />&nbsp; &nbsp;&nbsp; * (ugh, bad pun). Just hand the method parameters into the endpoint handler,<br />&nbsp; &nbsp;&nbsp; * along with other mandatory params - type hints are your friends.<br />&nbsp; &nbsp;&nbsp; * <br />&nbsp; &nbsp;&nbsp; * It's magic!<br />&nbsp; &nbsp;&nbsp; * <br />&nbsp; &nbsp;&nbsp; * @param string $method<br />&nbsp; &nbsp;&nbsp; * @param array&nbsp; $arguments<br />&nbsp; &nbsp;&nbsp; *<br />&nbsp; &nbsp;&nbsp; * @return \SomeEndpointHandler<br />&nbsp; &nbsp;&nbsp; * @throws \Exception<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">__call</span><span class="keyword">(</span><span class="default">$method</span><span class="keyword">, </span><span class="default">$arguments</span><span class="keyword">){<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">in_array</span><span class="keyword">(</span><span class="default">$method</span><span class="keyword">, </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">methodMap</span><span class="keyword">)){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return new </span><span class="default">SomeEndpointHandler</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">httpClient</span><span class="keyword">, </span><span class="default">$method</span><span class="keyword">, ...</span><span class="default">$arguments</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">Exception</span><span class="keyword">(</span><span class="string">'Endpoint "'</span><span class="keyword">.</span><span class="default">$method</span><span class="keyword">.</span><span class="string">'" does not exist'</span><span class="keyword">);<br />&nbsp; &nbsp; }<br /><br />}</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="76643">  <div class="votes">
    <div id="Vu76643">
    <a href="/manual/vote-note.php?id=76643&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd76643">
    <a href="/manual/vote-note.php?id=76643&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V76643" title="46% like this...">
    -2
    </div>
  </div>
  <a href="#76643" class="name">
  <strong class="user"><em>amir_abiri at ipcmedia dot com</em></strong></a><a class="genanchor" href="#76643"> &para;</a><div class="date" title="2007-07-24 04:58"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom76643">
<div class="phpcode"><code><span class="html">
Another small thing that is important to note about __sleep() and privte member variables:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">A<br /></span><span class="keyword">{<br />&nbsp; private </span><span class="default">$a</span><span class="keyword">;<br />&nbsp; <br />&nbsp; public function </span><span class="default">__construct</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">a </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />&nbsp; }<br />}<br /><br />class </span><span class="default">B </span><span class="keyword">extends </span><span class="default">A<br /></span><span class="keyword">{<br />&nbsp; protected </span><span class="default">$b</span><span class="keyword">;<br />&nbsp; <br />&nbsp; public function </span><span class="default">__construct</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; </span><span class="default">parent</span><span class="keyword">::</span><span class="default">__construct</span><span class="keyword">();<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">b </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">;<br />&nbsp; }<br />&nbsp; <br />&nbsp; function </span><span class="default">__sleep</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; return array(</span><span class="string">'a'</span><span class="keyword">, </span><span class="string">'b'</span><span class="keyword">);<br />&nbsp; }<br />}<br /><br /></span><span class="default">serialize</span><span class="keyword">(new </span><span class="default">B</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />result:<br />Notice: serialize(): "a" returned as member variable from __sleep() but does not exist in ...<br /><br />To summerize: in a given class hierarchy in which parent classes contain private member variables, those variables are serialized when __sleep() is not defined. However, once __sleep() is defined, there is no way to make those private member variables serialized as well. From that point on, serialization is performed from the visibility scope of the subclass.<br /><br />It is particularly important to note this little quirk when designing base classes that their derivables may be serialized, or when subclassing an external library class.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="105936">  <div class="votes">
    <div id="Vu105936">
    <a href="/manual/vote-note.php?id=105936&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd105936">
    <a href="/manual/vote-note.php?id=105936&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V105936" title="44% like this...">
    -3
    </div>
  </div>
  <a href="#105936" class="name">
  <strong class="user"><em>hyponiq at gmail dot com</em></strong></a><a class="genanchor" href="#105936"> &para;</a><div class="date" title="2011-09-26 06:07"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom105936">
<div class="phpcode"><code><span class="html">
I think it's fair to note the undocumented fact that the __invoke magic method can take any number of arguments (or none).<br /><br />Example:<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">InvokeNoParams </span><span class="keyword">{<br /></span><span class="default">    function __invoke</span><span class="keyword">()<br /></span><span class="default">    </span><span class="keyword">{<br /></span><span class="default">        print __METHOD__ </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;<br /></span><span class="default">        $i </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br /></span><span class="default">        foreach </span><span class="keyword">(</span><span class="default">func_get_args</span><span class="keyword">() as </span><span class="default">$arg</span><span class="keyword">) {<br /></span><span class="default">            print </span><span class="string">"The value of \$param</span><span class="keyword">{</span><span class="default">$i</span><span class="keyword">}</span><span class="string"> is: " </span><span class="keyword">. </span><span class="default">$arg </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;<br /></span><span class="default">            </span><span class="keyword">++</span><span class="default">$i</span><span class="keyword">;<br /></span><span class="default">        </span><span class="keyword">}<br />&nbsp; &nbsp; &nbsp; &nbsp; print </span><span class="default">PHP_EOL</span><span class="keyword">;<br /></span><span class="default">    </span><span class="keyword">}<br />}<br /></span><span class="default"> <br /></span><span class="keyword">class </span><span class="default">InvokeSingleParam </span><span class="keyword">{<br /></span><span class="default">    function __invoke</span><span class="keyword">(</span><span class="default">$param1</span><span class="keyword">)<br /></span><span class="default">    </span><span class="keyword">{<br /></span><span class="default">        print __METHOD__ </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;<br /></span><span class="default">        print </span><span class="string">"Value of \$param1 is: " </span><span class="keyword">. </span><span class="default">$param1 </span><span class="keyword">. </span><span class="default">PHP_EOL </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;<br /></span><span class="default">    </span><span class="keyword">}<br />}<br /></span><span class="default"> <br /></span><span class="keyword">class </span><span class="default">InvokeMultiParams </span><span class="keyword">{<br /></span><span class="default">    function __invoke</span><span class="keyword">(</span><span class="default">$param1</span><span class="keyword">, </span><span class="default">$param2</span><span class="keyword">, </span><span class="default">$param3</span><span class="keyword">) {<br /></span><span class="default">        print __METHOD__ </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;<br /></span><span class="default">        print </span><span class="string">"Value of \$param1 is: " </span><span class="keyword">. </span><span class="default">$param1 </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;<br /></span><span class="default">        print </span><span class="string">"Value of \$param2 is: " </span><span class="keyword">. </span><span class="default">$param2 </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;<br /></span><span class="default">        print </span><span class="string">"Value of \$param3 is: " </span><span class="keyword">. </span><span class="default">$param3 </span><span class="keyword">. </span><span class="default">PHP_EOL </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;<br /></span><span class="default">    </span><span class="keyword">}<br />}<br /></span><span class="default"> <br />$no </span><span class="keyword">= new </span><span class="default">InvokeNoParams</span><span class="keyword">;<br /></span><span class="default">$single </span><span class="keyword">= new </span><span class="default">InvokeSingleParam</span><span class="keyword">;<br /></span><span class="default">$multi </span><span class="keyword">= new </span><span class="default">InvokeMultiParams</span><span class="keyword">;<br /></span><span class="default"> <br />$no</span><span class="keyword">(</span><span class="default">1</span><span class="keyword">, </span><span class="default">2</span><span class="keyword">, </span><span class="default">3</span><span class="keyword">);<br /></span><span class="default">$single</span><span class="keyword">(</span><span class="string">'one param'</span><span class="keyword">);<br /></span><span class="default">$multi</span><span class="keyword">(</span><span class="string">'param 1'</span><span class="keyword">, </span><span class="string">'param 2'</span><span class="keyword">, </span><span class="string">'param 3'</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />This outputs:<br />InvokeNoParams::__invoke<br />The value of $param1 is: 1<br />The value of $param2 is: 2<br />The value of $param3 is: 3<br /><br />InvokeSingleParam::__invoke<br />Value of $param1 is: one param<br /><br />InvokeMultiParams::__invoke<br />Value of $param1 is: param 1<br />Value of $param2 is: param 2<br />Value of $param3 is: param 3</span>
</code></div>
  </div>
 </div>
  <div class="note" id="83556">  <div class="votes">
    <div id="Vu83556">
    <a href="/manual/vote-note.php?id=83556&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd83556">
    <a href="/manual/vote-note.php?id=83556&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V83556" title="42% like this...">
    -1
    </div>
  </div>
  <a href="#83556" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#83556"> &para;</a><div class="date" title="2008-05-31 04:24"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom83556">
<div class="phpcode"><code><span class="html">
Serializing objects is problematic with references. This is solved redefining the __sleep() magic method. This is also problematic when parent class has private variables since the parent object is not accessible nor its private variables from within the child object.<br /><br />I found a solution that seems working for classes that implements this __sleep() method, and for its subclasses. Without more work in subclasses. The inheritance system does the trick.<br /><br />Recursively __sleep() call parent' __sleep() and return the whole array of variables of the object instance to be serialized.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">foo </span><span class="keyword">{<br />}<br /><br />class </span><span class="default">a </span><span class="keyword">{<br />&nbsp; private </span><span class="default">$var1</span><span class="keyword">;<br /><br />&nbsp; function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">foo </span><span class="keyword">&amp;</span><span class="default">$obj </span><span class="keyword">= </span><span class="default">NULL</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">var1 </span><span class="keyword">= &amp;</span><span class="default">$obj</span><span class="keyword">;<br />&nbsp; }<br /><br />&nbsp; </span><span class="comment">/** Return its variables array, if its parent exists and the __sleep method is accessible, call it and push the result into the array and return the whole thing. */<br />&nbsp; </span><span class="keyword">public function </span><span class="default">__sleep</span><span class="keyword">() {<br />&nbsp; &nbsp; </span><span class="default">$a </span><span class="keyword">= </span><span class="default">array_keys</span><span class="keyword">(</span><span class="default">get_object_vars</span><span class="keyword">(&amp;</span><span class="default">$this</span><span class="keyword">));<br />&nbsp; &nbsp; if (</span><span class="default">method_exists</span><span class="keyword">(</span><span class="default">parent</span><span class="keyword">, </span><span class="string">'__sleep'</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$p </span><span class="keyword">= </span><span class="default">parent</span><span class="keyword">::</span><span class="default">__sleep</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; </span><span class="default">array_push</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">, </span><span class="default">$p</span><span class="keyword">);<br />&nbsp; &nbsp; };<br />&nbsp; &nbsp; return </span><span class="default">$a</span><span class="keyword">;<br />&nbsp; }<br />}<br /><br />class </span><span class="default">b </span><span class="keyword">extends </span><span class="default">a </span><span class="keyword">{<br />&nbsp; function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">foo </span><span class="keyword">&amp;</span><span class="default">$obj </span><span class="keyword">= </span><span class="default">NULL</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">parent</span><span class="keyword">::</span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$obj</span><span class="keyword">);<br />&nbsp; }<br />}<br /><br /></span><span class="default">session_start</span><span class="keyword">();<br /></span><span class="default">$myfoo </span><span class="keyword">= &amp;new </span><span class="default">foo</span><span class="keyword">();<br /></span><span class="default">$myb </span><span class="keyword">= &amp;new </span><span class="default">b</span><span class="keyword">(</span><span class="default">$myfoo</span><span class="keyword">);<br /></span><span class="default">$myb </span><span class="keyword">= </span><span class="default">unserialize</span><span class="keyword">(</span><span class="default">serialize</span><span class="keyword">(&amp;</span><span class="default">$myb</span><span class="keyword">));<br /></span><span class="default">?&gt;<br /></span><br />This should work, I haven't tested deeper.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="109967">  <div class="votes">
    <div id="Vu109967">
    <a href="/manual/vote-note.php?id=109967&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd109967">
    <a href="/manual/vote-note.php?id=109967&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V109967" title="41% like this...">
    -2
    </div>
  </div>
  <a href="#109967" class="name">
  <strong class="user"><em>qfox at ya dot ru</em></strong></a><a class="genanchor" href="#109967"> &para;</a><div class="date" title="2012-09-06 12:12"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom109967">
<div class="phpcode"><code><span class="html">
For those of you who have the same trouble as osbertv.<br /><span class="default">&lt;?php<br /></span><span class="comment">// ...<br /><br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">();<br /></span><span class="default">$b </span><span class="keyword">= new </span><span class="default">B</span><span class="keyword">();<br /></span><span class="default">$a</span><span class="keyword">();<br /></span><span class="default">$b</span><span class="keyword">();<br /></span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">a</span><span class="keyword">();<br /><br /></span><span class="default">?&gt;<br /></span><br />PHP Fatal error:&nbsp; Call to undefined method B::a()<br /><br />It's because PHP have bug in parsing syntax (a lot of).<br />Just make it easier to parse and it would work.<br />For example, like this:<br /><span class="default">&lt;?php<br />$c </span><span class="keyword">= </span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">a</span><span class="keyword">;<br /></span><span class="default">$c</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span><br />Or this, if you use 5.4 (if you using 5.3 just move call function to the each class which need it or to some base abstract class):<br /><span class="default">&lt;?php<br /></span><span class="keyword">trait </span><span class="default">TInnerClosuresInvoker </span><span class="keyword">{<br />&nbsp; function </span><span class="default">__call</span><span class="keyword">(</span><span class="default">$method</span><span class="keyword">, </span><span class="default">$args</span><span class="keyword">) {<br />&nbsp; &nbsp; if (isset(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$method</span><span class="keyword">) &amp;&amp; </span><span class="default">is_callable</span><span class="keyword">(</span><span class="default">$method</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$closure </span><span class="keyword">= </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$method</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; </span><span class="default">call_user_func_array</span><span class="keyword">(</span><span class="default">$closure</span><span class="keyword">, </span><span class="default">$args</span><span class="keyword">);<br />&nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; </span><span class="default">trigger_error</span><span class="keyword">(</span><span class="string">'Call to undefined method '</span><span class="keyword">.</span><span class="default">__CLASS__</span><span class="keyword">.</span><span class="string">'::'</span><span class="keyword">.</span><span class="default">$method</span><span class="keyword">.</span><span class="string">'()'</span><span class="keyword">, </span><span class="default">E_USER_ERROR</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; }<br />}<br />class </span><span class="default">A </span><span class="keyword">{<br />&nbsp; use </span><span class="default">TInnerClosuresInvoker</span><span class="keyword">;<br />&nbsp; ...<br />}<br /></span><span class="default">?&gt;<br /></span><br />It's a little bit dirty, but it works.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="79062">  <div class="votes">
    <div id="Vu79062">
    <a href="/manual/vote-note.php?id=79062&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd79062">
    <a href="/manual/vote-note.php?id=79062&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V79062" title="42% like this...">
    -2
    </div>
  </div>
  <a href="#79062" class="name">
  <strong class="user"><em>andrew dot minerd at sellingsource dot com</em></strong></a><a class="genanchor" href="#79062"> &para;</a><div class="date" title="2007-11-08 07:55"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom79062">
<div class="phpcode"><code><span class="html">
Until __sleep is "fixed" (here's hoping), a function that will return ALL members of a given object -- public, protected, AND private:<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">getPropertyNames</span><span class="keyword">(array </span><span class="default">$filter </span><span class="keyword">= </span><span class="default">NULL</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$rc </span><span class="keyword">= new </span><span class="default">ReflectionObject</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$names </span><span class="keyword">= array();<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; while (</span><span class="default">$rc </span><span class="keyword">instanceof </span><span class="default">ReflectionClass</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; foreach (</span><span class="default">$rc</span><span class="keyword">-&gt;</span><span class="default">getProperties</span><span class="keyword">() as </span><span class="default">$prop</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (!</span><span class="default">$filter </span><span class="keyword">|| !</span><span class="default">in_array</span><span class="keyword">(</span><span class="default">$prop</span><span class="keyword">-&gt;</span><span class="default">getName</span><span class="keyword">(), </span><span class="default">$filter</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$names</span><span class="keyword">[] = </span><span class="default">$prop</span><span class="keyword">-&gt;</span><span class="default">getName</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$rc </span><span class="keyword">= </span><span class="default">$rc</span><span class="keyword">-&gt;</span><span class="default">getParentClass</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$names</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="55783">  <div class="votes">
    <div id="Vu55783">
    <a href="/manual/vote-note.php?id=55783&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd55783">
    <a href="/manual/vote-note.php?id=55783&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V55783" title="40% like this...">
    -1
    </div>
  </div>
  <a href="#55783" class="name">
  <strong class="user"><em>mastabog at hotmail dot com</em></strong></a><a class="genanchor" href="#55783"> &para;</a><div class="date" title="2005-08-12 05:06"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom55783">
<div class="phpcode"><code><span class="html">
In reply to krisj1010 at gmail.com below:<br /><br />__sleep() handles protected/private properties very well. You should never rely on get_class_vars() to retrieve property names since this function only returns the public properties. Use the Reflection API instead for that purpose. Better yet, if you know which ones you want to save it is always faster to specify the return array manually.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="63863">  <div class="votes">
    <div id="Vu63863">
    <a href="/manual/vote-note.php?id=63863&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd63863">
    <a href="/manual/vote-note.php?id=63863&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V63863" title="40% like this...">
    -2
    </div>
  </div>
  <a href="#63863" class="name">
  <strong class="user"><em>rayRO</em></strong></a><a class="genanchor" href="#63863"> &para;</a><div class="date" title="2006-04-02 09:55"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom63863">
<div class="phpcode"><code><span class="html">
If you use the Magical Method '__set()', be shure that the call of<br /><span class="default">&lt;?php<br />$myobject</span><span class="keyword">-&gt;</span><span class="default">test</span><span class="keyword">[</span><span class="string">'myarray'</span><span class="keyword">] = </span><span class="string">'data'</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span>will not appear!<br /><br />For that u have to do it the fine way if you want to use __set Method ;)<br /><span class="default">&lt;?php<br />$myobject</span><span class="keyword">-&gt;</span><span class="default">test </span><span class="keyword">= array(</span><span class="string">'myarray' </span><span class="keyword">=&gt; </span><span class="string">'data'</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />If a Variable is already set, the __set Magic Method already wont appear!<br /><br />My first solution was to use a Caller Class.<br />With that, i ever knew which Module i currently use!<br />But who needs it... :]<br />There are quiet better solutions for this...<br />Here's the Code:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Caller </span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$caller</span><span class="keyword">;<br />&nbsp; &nbsp; public </span><span class="default">$module</span><span class="keyword">;<br /><br />&nbsp; &nbsp; function </span><span class="default">__call</span><span class="keyword">(</span><span class="default">$funcname</span><span class="keyword">, </span><span class="default">$args </span><span class="keyword">= array()) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">setModuleInformation</span><span class="keyword">();<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">is_object</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">caller</span><span class="keyword">) &amp;&amp; </span><span class="default">function_exists</span><span class="keyword">(</span><span class="string">'call_user_func_array'</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$return </span><span class="keyword">= </span><span class="default">call_user_func_array</span><span class="keyword">(array(&amp;</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">caller</span><span class="keyword">, </span><span class="default">$funcname</span><span class="keyword">), </span><span class="default">$args</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">trigger_error</span><span class="keyword">(</span><span class="string">"Call to Function with call_user_func_array failed"</span><span class="keyword">, </span><span class="default">E_USER_ERROR</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">unsetModuleInformation</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$return</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$callerClassName </span><span class="keyword">= </span><span class="default">false</span><span class="keyword">, </span><span class="default">$callerModuleName </span><span class="keyword">= </span><span class="string">'Webboard'</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$callerClassName </span><span class="keyword">== </span><span class="default">false</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">trigger_error</span><span class="keyword">(</span><span class="string">'No Classname'</span><span class="keyword">, </span><span class="default">E_USER_ERROR</span><span class="keyword">);<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">module </span><span class="keyword">= </span><span class="default">$callerModuleName</span><span class="keyword">;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">class_exists</span><span class="keyword">(</span><span class="default">$callerClassName</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">caller </span><span class="keyword">= new </span><span class="default">$callerClassName</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">trigger_error</span><span class="keyword">(</span><span class="string">'Class not exists: \''</span><span class="keyword">.</span><span class="default">$callerClassName</span><span class="keyword">.</span><span class="string">'\''</span><span class="keyword">, </span><span class="default">E_USER_ERROR</span><span class="keyword">);<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">is_object</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">caller</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">setModuleInformation</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">method_exists</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">caller</span><span class="keyword">, </span><span class="string">'__init'</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">caller</span><span class="keyword">-&gt;</span><span class="default">__init</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">unsetModuleInformation</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">trigger_error</span><span class="keyword">(</span><span class="string">'Caller is no object!'</span><span class="keyword">, </span><span class="default">E_USER_ERROR</span><span class="keyword">);<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; function </span><span class="default">__destruct</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">setModuleInformation</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">method_exists</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">caller</span><span class="keyword">, </span><span class="string">'__deinit'</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">caller</span><span class="keyword">-&gt;</span><span class="default">__deinit</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">unsetModuleInformation</span><span class="keyword">();<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; function </span><span class="default">__isset</span><span class="keyword">(</span><span class="default">$isset</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">setModuleInformation</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">is_object</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">caller</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$return </span><span class="keyword">= isset(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">caller</span><span class="keyword">-&gt;{</span><span class="default">$isset</span><span class="keyword">});<br />&nbsp; &nbsp; &nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">trigger_error</span><span class="keyword">(</span><span class="string">'Caller is no object!'</span><span class="keyword">, </span><span class="default">E_USER_ERROR</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">unsetModuleInformation</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$return</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; function </span><span class="default">__unset</span><span class="keyword">(</span><span class="default">$unset</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">setModuleInformation</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">is_object</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">caller</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (isset(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">caller</span><span class="keyword">-&gt;{</span><span class="default">$unset</span><span class="keyword">}))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; unset(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">caller</span><span class="keyword">-&gt;{</span><span class="default">$unset</span><span class="keyword">});<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">trigger_error</span><span class="keyword">(</span><span class="string">'Caller is no object!'</span><span class="keyword">, </span><span class="default">E_USER_ERROR</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">unsetModuleInformation</span><span class="keyword">();<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; function </span><span class="default">__set</span><span class="keyword">(</span><span class="default">$set</span><span class="keyword">, </span><span class="default">$val</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">setModuleInformation</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">is_object</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">caller</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">caller</span><span class="keyword">-&gt;{</span><span class="default">$set</span><span class="keyword">} = </span><span class="default">$val</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">trigger_error</span><span class="keyword">(</span><span class="string">'Caller is no object!'</span><span class="keyword">, </span><span class="default">E_USER_ERROR</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">unsetModuleInformation</span><span class="keyword">();<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; function </span><span class="default">__get</span><span class="keyword">(</span><span class="default">$get</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">setModuleInformation</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">is_object</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">caller</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (isset(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">caller</span><span class="keyword">-&gt;{</span><span class="default">$get</span><span class="keyword">}))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$return </span><span class="keyword">= </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">caller</span><span class="keyword">-&gt;{</span><span class="default">$get</span><span class="keyword">};<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$return </span><span class="keyword">= </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">trigger_error</span><span class="keyword">(</span><span class="string">'Caller is no object!'</span><span class="keyword">, </span><span class="default">E_USER_ERROR</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">unsetModuleInformation</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$return</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">setModuleInformation</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">caller</span><span class="keyword">-&gt;</span><span class="default">module </span><span class="keyword">= </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">module</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; function </span><span class="default">unsetModuleInformation</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">caller</span><span class="keyword">-&gt;</span><span class="default">module </span><span class="keyword">= </span><span class="default">NULL</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="comment">// Well this can be a Config Class?<br /></span><span class="keyword">class </span><span class="default">Config </span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$module</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public </span><span class="default">$test</span><span class="keyword">;<br /><br />&nbsp; &nbsp; function </span><span class="default">__construct</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; print(</span><span class="string">'Constructor will have no Module Information... Use __init() instead!&lt;br /&gt;'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; print(</span><span class="string">'--&gt; '</span><span class="keyword">.</span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">module</span><span class="keyword">, </span><span class="default">1</span><span class="keyword">).</span><span class="string">' &lt;--'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; print(</span><span class="string">'&lt;br /&gt;'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; print(</span><span class="string">'&lt;br /&gt;'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">test </span><span class="keyword">= </span><span class="string">'123'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">__init</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; print(</span><span class="string">'Using of __init()!&lt;br /&gt;'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; print(</span><span class="string">'--&gt; '</span><span class="keyword">.</span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">module</span><span class="keyword">, </span><span class="default">1</span><span class="keyword">).</span><span class="string">' &lt;--'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; print(</span><span class="string">'&lt;br /&gt;'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; print(</span><span class="string">'&lt;br /&gt;'</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">testFunction</span><span class="keyword">(</span><span class="default">$test </span><span class="keyword">= </span><span class="default">false</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$test </span><span class="keyword">!= </span><span class="default">false</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">test </span><span class="keyword">= </span><span class="default">$test</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />echo(</span><span class="string">'&lt;pre&gt;'</span><span class="keyword">);<br /></span><span class="default">$wow </span><span class="keyword">= new </span><span class="default">Caller</span><span class="keyword">(</span><span class="string">'Config'</span><span class="keyword">, </span><span class="string">'Guestbook'</span><span class="keyword">);<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$wow</span><span class="keyword">-&gt;</span><span class="default">test</span><span class="keyword">);<br />print(</span><span class="string">'&lt;br /&gt;'</span><span class="keyword">);<br />print(</span><span class="string">'&lt;br /&gt;'</span><span class="keyword">);<br /></span><span class="default">$wow</span><span class="keyword">-&gt;</span><span class="default">test </span><span class="keyword">= </span><span class="string">'456'</span><span class="keyword">;<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$wow</span><span class="keyword">-&gt;</span><span class="default">test</span><span class="keyword">);<br />print(</span><span class="string">'&lt;br /&gt;'</span><span class="keyword">);<br />print(</span><span class="string">'&lt;br /&gt;'</span><span class="keyword">);<br /></span><span class="default">$wow</span><span class="keyword">-&gt;</span><span class="default">testFunction</span><span class="keyword">(</span><span class="string">'789'</span><span class="keyword">);<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$wow</span><span class="keyword">-&gt;</span><span class="default">test</span><span class="keyword">);<br />print(</span><span class="string">'&lt;br /&gt;'</span><span class="keyword">);<br />print(</span><span class="string">'&lt;br /&gt;'</span><span class="keyword">);<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$wow</span><span class="keyword">-&gt;</span><span class="default">module</span><span class="keyword">);<br />echo(</span><span class="string">'&lt;/pre&gt;'</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />Outputs something Like:<br /><br />Constructor will have no Module Information... Use __init() instead!<br />--&gt;&nbsp; &lt;--<br /><br />Using of __init()!<br />--&gt; Guestbook &lt;--<br /><br />123<br /><br />456<br /><br />789<br /><br />Guestbook</span>
</code></div>
  </div>
 </div>
  <div class="note" id="75037">  <div class="votes">
    <div id="Vu75037">
    <a href="/manual/vote-note.php?id=75037&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd75037">
    <a href="/manual/vote-note.php?id=75037&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V75037" title="40% like this...">
    -3
    </div>
  </div>
  <a href="#75037" class="name">
  <strong class="user"><em>alejandro dot gama at gmail dot com</em></strong></a><a class="genanchor" href="#75037"> &para;</a><div class="date" title="2007-05-09 07:47"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom75037">
<div class="phpcode"><code><span class="html">
Referering my previus note: there was an error in the code. But i find a better way:<br /><br />&lt;?<br />session_start();<br /><br />class Classes{<br />&nbsp; private $name;<br />&nbsp; private $statics;<br />&nbsp; &nbsp; <br />&nbsp; function __construct($name){<br />&nbsp; &nbsp; $this-&gt;name=$name;<br />&nbsp; &nbsp; $this-&gt;statics=array();<br />&nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; function setStatic($k,$v){<br />&nbsp; &nbsp; if(!is_resource($v))<br />&nbsp; &nbsp; &nbsp; $this-&gt;statics[$k]=$v;<br />&nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; <br />&nbsp; function __wakeup(){<br />&nbsp; &nbsp; foreach($this-&gt;statics as $k=&gt;$v)<br />&nbsp; &nbsp; &nbsp; eval($this-&gt;name."::\$".$k."=\$this-&gt;statics['".$k."'];");<br />&nbsp; }<br />}<br /><br />function storeStaticAttributes(){<br />&nbsp; $classes=get_declared_classes();<br />&nbsp; foreach($classes as $name){<br />&nbsp; &nbsp; $reflect=new ReflectionClass($name);<br /><br />&nbsp; &nbsp; if($reflect-&gt;isUserDefined()){<br />&nbsp; &nbsp; &nbsp; $statics=$reflect-&gt;getStaticProperties();<br /><br />&nbsp; &nbsp; &nbsp; if(empty($_SESSION["_classes"]))<br />&nbsp; &nbsp; &nbsp; &nbsp; $_SESSION["_classes"]=array();<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; if(empty($_SESSION["_classes"][$name]))<br />&nbsp; &nbsp; &nbsp; &nbsp; $_SESSION["_classes"][$name]=new Classes($name);<br /><br />&nbsp; &nbsp; &nbsp; foreach($statics as $k=&gt;$v)<br />&nbsp; &nbsp; &nbsp; &nbsp; $_SESSION["_classes"][$name]-&gt;setStatic($k,$v);&nbsp; &nbsp; <br />&nbsp; &nbsp; }<br />&nbsp; }<br />}<br />register_shutdown_function('storeStaticAttributes');<br />?&gt;</span>
</code></div>
  </div>
 </div>
  <div class="note" id="107535">  <div class="votes">
    <div id="Vu107535">
    <a href="/manual/vote-note.php?id=107535&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd107535">
    <a href="/manual/vote-note.php?id=107535&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V107535" title="38% like this...">
    -3
    </div>
  </div>
  <a href="#107535" class="name">
  <strong class="user"><em>Voitcus at wp dot pl</em></strong></a><a class="genanchor" href="#107535"> &para;</a><div class="date" title="2012-02-15 09:48"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom107535">
<div class="phpcode"><code><span class="html">
You don't need to serialize the class default values, only those which have changed. It might be important for large objects. Note the example below, for simplicity, always serializes arrays and objects.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">MyBaseClass </span><span class="keyword">{<br />&nbsp; public </span><span class="default">$name</span><span class="keyword">=</span><span class="string">'object'</span><span class="keyword">; </span><span class="comment">// these are default class values<br />&nbsp; </span><span class="keyword">public </span><span class="default">$test</span><span class="keyword">=</span><span class="default">1</span><span class="keyword">;<br />&nbsp; public </span><span class="default">$test2</span><span class="keyword">; </span><span class="comment">// equals to NULL in fact<br /><br />&nbsp; </span><span class="keyword">public function </span><span class="default">__construct</span><span class="keyword">(){<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">test2</span><span class="keyword">=</span><span class="string">'some text'</span><span class="keyword">;&nbsp; </span><span class="comment">// this is not a default value, although called in the constructor<br />&nbsp; </span><span class="keyword">}<br /><br />&nbsp; public function </span><span class="default">__sleep</span><span class="keyword">(){<br />&nbsp; &nbsp; </span><span class="comment">// default class values:<br />&nbsp; &nbsp; </span><span class="default">$defaults</span><span class="keyword">=</span><span class="default">get_class_vars</span><span class="keyword">(</span><span class="default">get_class</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">)); </span><span class="comment">// not __CLASS__ or self::, if you'd like to use in descendant classes<br />&nbsp; &nbsp; // values of $this object:<br />&nbsp; &nbsp; </span><span class="default">$present</span><span class="keyword">=</span><span class="default">get_object_vars</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$result</span><span class="keyword">=array(); </span><span class="comment">// output array<br />&nbsp; &nbsp; </span><span class="keyword">foreach(</span><span class="default">$present </span><span class="keyword">as </span><span class="default">$key</span><span class="keyword">=&gt;</span><span class="default">$value</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; if(!</span><span class="default">is_resource</span><span class="keyword">(</span><span class="default">$defaults</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">]) &amp;&amp; ( </span><span class="comment">// don't store resources<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">is_object</span><span class="keyword">(</span><span class="default">$defaults</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">]) ||&nbsp; &nbsp; </span><span class="comment">// always store objects<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$defaults</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">])&nbsp; ||&nbsp; &nbsp; </span><span class="comment">// and arrays<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$defaults</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">]!==</span><span class="default">$value</span><span class="keyword">) </span><span class="comment">// and of course all that is not the default value<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">) </span><span class="comment">// tip: try is_scalar as well<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$result</span><span class="keyword">[]=</span><span class="default">$key</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; return </span><span class="default">$result</span><span class="keyword">;<br />&nbsp; }<br />}<br /><br /></span><span class="default">$obj1</span><span class="keyword">=new </span><span class="default">MyBaseClass</span><span class="keyword">();<br />echo (</span><span class="default">$s1</span><span class="keyword">=</span><span class="default">serialize</span><span class="keyword">(</span><span class="default">$obj1</span><span class="keyword">)).</span><span class="string">"&lt;br&gt;"</span><span class="keyword">; </span><span class="comment">// only test2 is stored, as it was changed in the constructor<br /><br /></span><span class="default">$obj2</span><span class="keyword">=new </span><span class="default">MyBaseClass</span><span class="keyword">();<br /></span><span class="default">$obj2</span><span class="keyword">-&gt;</span><span class="default">name</span><span class="keyword">=</span><span class="string">'object 2'</span><span class="keyword">; </span><span class="comment">// change default value here<br /></span><span class="keyword">echo (</span><span class="default">$s2</span><span class="keyword">=</span><span class="default">serialize</span><span class="keyword">(</span><span class="default">$obj2</span><span class="keyword">)).</span><span class="string">"&lt;br&gt;"</span><span class="keyword">; </span><span class="comment">// stored name and test2<br /><br /></span><span class="default">$obj3</span><span class="keyword">=new </span><span class="default">MyBaseClass</span><span class="keyword">();<br /></span><span class="default">$obj3</span><span class="keyword">-&gt;</span><span class="default">test2</span><span class="keyword">=</span><span class="default">NULL</span><span class="keyword">; </span><span class="comment">// switch back to default value<br /></span><span class="keyword">echo (</span><span class="default">$s3</span><span class="keyword">=</span><span class="default">serialize</span><span class="keyword">(</span><span class="default">$obj3</span><span class="keyword">)).</span><span class="string">"&lt;br&gt;"</span><span class="keyword">; </span><span class="comment">// nothing is stored but the class name<br /><br />// let us check if we can retrieve the objects<br /></span><span class="keyword">unset(</span><span class="default">$obj1</span><span class="keyword">, </span><span class="default">$obj2</span><span class="keyword">, </span><span class="default">$obj3</span><span class="keyword">);<br /></span><span class="default">$obj1</span><span class="keyword">=</span><span class="default">unserialize</span><span class="keyword">(</span><span class="default">$s1</span><span class="keyword">);<br /></span><span class="default">$obj2</span><span class="keyword">=</span><span class="default">unserialize</span><span class="keyword">(</span><span class="default">$s2</span><span class="keyword">);<br /></span><span class="default">$obj3</span><span class="keyword">=</span><span class="default">unserialize</span><span class="keyword">(</span><span class="default">$s3</span><span class="keyword">);<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$obj1</span><span class="keyword">);<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$obj2</span><span class="keyword">);<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$obj3</span><span class="keyword">);<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="86096">  <div class="votes">
    <div id="Vu86096">
    <a href="/manual/vote-note.php?id=86096&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86096">
    <a href="/manual/vote-note.php?id=86096&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86096" title="37% like this...">
    -2
    </div>
  </div>
  <a href="#86096" class="name">
  <strong class="user"><em>wbcarts at juno dot com</em></strong></a><a class="genanchor" href="#86096"> &para;</a><div class="date" title="2008-10-02 04:12"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86096">
<div class="phpcode"><code><span class="html">
To be helpful, the __toString() method should return the class name and the state of all its properties inside square brackets.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Point </span><span class="keyword">{<br />&nbsp; protected </span><span class="default">$x</span><span class="keyword">, </span><span class="default">$y</span><span class="keyword">;<br /><br />&nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$xVal </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">, </span><span class="default">$yVal </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">x </span><span class="keyword">= </span><span class="default">$xVal</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">y </span><span class="keyword">= </span><span class="default">$yVal</span><span class="keyword">;<br />&nbsp; }&nbsp; &nbsp; <br /><br />&nbsp; public function </span><span class="default">__toString</span><span class="keyword">() {&nbsp; &nbsp; &nbsp; </span><span class="comment">// the function we're interested in...<br />&nbsp; &nbsp; </span><span class="keyword">return </span><span class="string">"Point[x=</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">x</span><span class="string">, y=</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">y</span><span class="string">]"</span><span class="keyword">;<br />&nbsp; }<br />}<br /><br /></span><span class="default">$point1 </span><span class="keyword">= new </span><span class="default">Point</span><span class="keyword">(</span><span class="default">10</span><span class="keyword">, </span><span class="default">10</span><span class="keyword">);<br /></span><span class="default">$point2 </span><span class="keyword">= new </span><span class="default">Point</span><span class="keyword">(</span><span class="default">50</span><span class="keyword">, </span><span class="default">50</span><span class="keyword">);<br />echo </span><span class="default">$point1 </span><span class="keyword">. </span><span class="string">'&lt;br&gt;'</span><span class="keyword">;<br />echo </span><span class="default">$point2 </span><span class="keyword">. </span><span class="string">'&lt;br&gt;&lt;br&gt;'</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />Point[x=10, y=10]<br />Point[x=50, y=50]<br /><br />Classes that include objects, should call that objects __toString() method.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Line </span><span class="keyword">{<br />&nbsp; protected </span><span class="default">$start</span><span class="keyword">, </span><span class="default">$end</span><span class="keyword">;<br /><br />&nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">Point $p1</span><span class="keyword">, </span><span class="default">Point $p2</span><span class="keyword">){<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">start </span><span class="keyword">= </span><span class="default">$p1</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">end </span><span class="keyword">= </span><span class="default">$p2</span><span class="keyword">;<br />&nbsp; }<br /><br />&nbsp; public function </span><span class="default">__toString</span><span class="keyword">() {&nbsp; &nbsp; &nbsp; </span><span class="comment">// the function we're interested in...<br />&nbsp; &nbsp; </span><span class="keyword">return </span><span class="string">'Line[start=' </span><span class="keyword">. </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">start</span><span class="keyword">-&gt;</span><span class="default">__toString</span><span class="keyword">() .&nbsp; </span><span class="comment">// call __toString()<br />&nbsp; &nbsp;&nbsp; </span><span class="string">', end=' </span><span class="keyword">. </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">end</span><span class="keyword">-&gt;</span><span class="default">__toString</span><span class="keyword">() . </span><span class="string">']'</span><span class="keyword">;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// call __toString()<br />&nbsp; </span><span class="keyword">}<br />}<br /><br />echo (new </span><span class="default">Line</span><span class="keyword">(</span><span class="default">$point1</span><span class="keyword">, </span><span class="default">$point2</span><span class="keyword">));<br /></span><span class="default">?&gt;<br /></span><br />Line[start=Point[x=10, y=10], end=Point[x=50, y=50]]</span>
</code></div>
  </div>
 </div>
  <div class="note" id="98963">  <div class="votes">
    <div id="Vu98963">
    <a href="/manual/vote-note.php?id=98963&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd98963">
    <a href="/manual/vote-note.php?id=98963&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V98963" title="38% like this...">
    -4
    </div>
  </div>
  <a href="#98963" class="name">
  <strong class="user"><em>tom</em></strong></a><a class="genanchor" href="#98963"> &para;</a><div class="date" title="2010-07-18 03:20"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom98963">
<div class="phpcode"><code><span class="html">
Note a common pitfall when using __wakeup.<br /><br />If you unserialize a datastructure, you may not rely on the parent object to have been fully unserialized by the time __wakeup is called. Example<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">A </span><span class="keyword">{<br /> public </span><span class="default">$b</span><span class="keyword">;<br /> public </span><span class="default">$name</span><span class="keyword">;<br />}<br /><br />class </span><span class="default">B </span><span class="keyword">extends </span><span class="default">A </span><span class="keyword">{<br /> public </span><span class="default">$parent</span><span class="keyword">;<br /> public function </span><span class="default">__wakeup</span><span class="keyword">() {<br />&nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$parent</span><span class="keyword">-&gt;</span><span class="default">name</span><span class="keyword">);<br /> }<br />}<br /><br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">();<br /></span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">name </span><span class="keyword">= </span><span class="string">"foo"</span><span class="keyword">;<br /></span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">b </span><span class="keyword">= new </span><span class="default">B</span><span class="keyword">();<br /></span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">b</span><span class="keyword">-&gt;</span><span class="default">parent </span><span class="keyword">= </span><span class="default">$a</span><span class="keyword">;<br /></span><span class="default">$s </span><span class="keyword">= </span><span class="default">serialize</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">);<br /></span><span class="default">$a </span><span class="keyword">= </span><span class="default">unserialize</span><span class="keyword">(</span><span class="default">$s</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />Expected output: "foo".<br />Actual output: NULL.<br /><br />Reason: $b is unserialized before $name. By the time B::__wakeup is called, $a-&gt;name does not yet have a value.<br /><br />So be aware that the order in which your class variables are defined is important! You need to manually order them by dependencies - or write a __sleep function and order them by depencies there. (Currently I can't tell which option I hate more)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="92466">  <div class="votes">
    <div id="Vu92466">
    <a href="/manual/vote-note.php?id=92466&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd92466">
    <a href="/manual/vote-note.php?id=92466&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V92466" title="38% like this...">
    -4
    </div>
  </div>
  <a href="#92466" class="name">
  <strong class="user"><em>moechofe</em></strong></a><a class="genanchor" href="#92466"> &para;</a><div class="date" title="2009-07-25 02:47"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom92466">
<div class="phpcode"><code><span class="html">
__invoke() cannot be used to create fluente interface like in the "D language"<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">CallableClass<br /></span><span class="keyword">{<br />&nbsp; &nbsp; var </span><span class="default">$next</span><span class="keyword">;<br />&nbsp; &nbsp; function </span><span class="default">__invoke</span><span class="keyword">(</span><span class="default">$x</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$x</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">;<br />&nbsp;&nbsp; }<br />}<br /></span><span class="default">$obj </span><span class="keyword">= new </span><span class="default">CallableClass</span><span class="keyword">;<br /></span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">next </span><span class="keyword">= new </span><span class="default">CallableClass</span><span class="keyword">;<br /></span><span class="default">var_dump</span><span class="keyword">( </span><span class="default">$obj</span><span class="keyword">(</span><span class="default">5</span><span class="keyword">) ); </span><span class="comment">// OK!<br /></span><span class="default">var_dump</span><span class="keyword">( </span><span class="default">$obj</span><span class="keyword">(</span><span class="default">5</span><span class="keyword">)(</span><span class="default">6</span><span class="keyword">) ); </span><span class="comment">// Parse error<br /></span><span class="default">var_dump</span><span class="keyword">( </span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">next</span><span class="keyword">(</span><span class="default">7</span><span class="keyword">) ); </span><span class="comment">// Fatal error: Call to undefined method CallableClass::next()<br /></span><span class="default">var_dump</span><span class="keyword">( {</span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">next</span><span class="keyword">}(</span><span class="default">7</span><span class="keyword">) ); </span><span class="comment">// Parse error<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="84960">  <div class="votes">
    <div id="Vu84960">
    <a href="/manual/vote-note.php?id=84960&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd84960">
    <a href="/manual/vote-note.php?id=84960&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V84960" title="35% like this...">
    -4
    </div>
  </div>
  <a href="#84960" class="name">
  <strong class="user"><em>rc @ nospam @ vorklift dot sea oh em</em></strong></a><a class="genanchor" href="#84960"> &para;</a><div class="date" title="2008-08-07 07:03"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom84960">
<div class="phpcode"><code><span class="html">
A note: __wakeup occurs before saving the unserialization of an session object.<br /><br />Therefore, $_SESSION['var']::__wakeup() setting $_SESSION['var'] = new Class() will fail and $_SESSION['var'] will remain unchanged.<br /><br />This means that if you have a pseudo-temporary object that contains a class to auto revert to, you have to revert that session object in the initialization of the website rather than via a __wakeup() script.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="59560">  <div class="votes">
    <div id="Vu59560">
    <a href="/manual/vote-note.php?id=59560&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd59560">
    <a href="/manual/vote-note.php?id=59560&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V59560" title="33% like this...">
    -2
    </div>
  </div>
  <a href="#59560" class="name">
  <strong class="user"><em>docey</em></strong></a><a class="genanchor" href="#59560"> &para;</a><div class="date" title="2005-12-09 08:44"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom59560">
<div class="phpcode"><code><span class="html">
about __sleep and _wakeup, consider using a method like this:<br /><br />class core<br />{<br /><br /> var $sub_core; //ref of subcore<br /> var $_sleep_subcore; // place where serialize version of sub_core will be stored<br /><br /> function core(){<br />&nbsp; $this-&gt;sub_core = new sub_core();<br />&nbsp; return true;<br /> }<br /><br /> function __wakeup()<br /> {<br />&nbsp; // on wakeup of core, core unserializes sub_core<br />&nbsp; // wich it had stored when it was serialized itself<br />&nbsp; $this-&gt;sub_core = unserialize($this-&gt;_sleep_subcore);<br />&nbsp; return true;<br /> }<br /><br /> function __sleep()<br /> {<br />&nbsp; // sub_core will be serialized when core is serialized.<br />&nbsp; // the serialized subcore will be stored as a string inside core.<br />&nbsp;&nbsp; $this-&gt;_sleep_subcore = serialize($this-&gt;sub_core);<br />&nbsp;&nbsp; $return_arr[] = "_sleep_subcore";<br />&nbsp;&nbsp; return $return_arr;<br /> }<br /><br />}<br /><br />class sub_core<br />{<br /> var $info;<br /><br /> function sub_core()<br /> {<br />&nbsp; $this-&gt;info["somedata"] = "somedata overhere"<br /> }<br /><br /> function __wakeup()<br /> {<br />&nbsp; return true;<br /> }<br /><br /> function __sleep()<br /> {<br />&nbsp; $return_arr[] = "info"<br />&nbsp; return $return_arr; <br /> }<br /><br />}<br /><br />this way subcore is being serialized by core when core is being serialized. subcore handles its own data and core stores it as a serialize string inside itself. on wakeup core unserializes subcore. <br /><br />this may have a performance cost, but if you have many objects connected this way this is the best way of serializing them. you only need to serialize the the main object wich will serialize all those below which will serialize all those below them again. in effect causing a sort of chainreaction in wich each object takes care of its own info.<br /><br />offcoarse you always need to store the eventualy serialized string in a safe place. somebody got experience with this way of __wakeup and __sleep. <br /><br />works in PHP4&amp;5</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119890">  <div class="votes">
    <div id="Vu119890">
    <a href="/manual/vote-note.php?id=119890&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119890">
    <a href="/manual/vote-note.php?id=119890&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119890" title="28% like this...">
    -3
    </div>
  </div>
  <a href="#119890" class="name">
  <strong class="user"><em>ryan dot jentzsch at gmail dot com</em></strong></a><a class="genanchor" href="#119890"> &para;</a><div class="date" title="2016-09-15 07:04"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119890">
<div class="phpcode"><code><span class="html">
PHP 7+ solves a problem with __invoke noted about 4 yrs ago:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">a </span><span class="keyword">{<br />&nbsp; &nbsp; function </span><span class="default">__construct</span><span class="keyword">() { }<br />&nbsp; &nbsp; function </span><span class="default">__invoke</span><span class="keyword">() { echo(</span><span class="string">"Invoked\n"</span><span class="keyword">); }<br />}<br /><br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">a</span><span class="keyword">();<br /></span><span class="default">$a</span><span class="keyword">();<br /></span><span class="comment">// Output: Invoked<br /><br /></span><span class="keyword">class </span><span class="default">b </span><span class="keyword">{<br />&nbsp; &nbsp; private </span><span class="default">$x</span><span class="keyword">;<br /><br />&nbsp; &nbsp; function </span><span class="default">__construct</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">x </span><span class="keyword">= new </span><span class="default">a</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; (</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">x</span><span class="keyword">)();&nbsp; </span><span class="comment">// Works in PHP 7+<br />&nbsp; &nbsp; &nbsp; &nbsp; // $this-&gt;x(); // Will blow up in your face: undefined method b::x<br />&nbsp; &nbsp; </span><span class="keyword">} <br />}<br /><br /></span><span class="default">$b </span><span class="keyword">= new </span><span class="default">b</span><span class="keyword">();<br /></span><span class="comment">// Output: Invoked</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="88045">  <div class="votes">
    <div id="Vu88045">
    <a href="/manual/vote-note.php?id=88045&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd88045">
    <a href="/manual/vote-note.php?id=88045&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V88045" title="30% like this...">
    -4
    </div>
  </div>
  <a href="#88045" class="name">
  <strong class="user"><em>muratyaman at gmail dot com</em></strong></a><a class="genanchor" href="#88045"> &para;</a><div class="date" title="2009-01-07 07:54"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom88045">
<div class="phpcode"><code><span class="html">
Regarding __toString:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">my_tag_A</span><span class="keyword">{<br /><br />&nbsp; &nbsp; public </span><span class="default">$id</span><span class="keyword">=</span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; public </span><span class="default">$href</span><span class="keyword">=</span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; public </span><span class="default">$target</span><span class="keyword">=</span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; public </span><span class="default">$class</span><span class="keyword">=</span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public </span><span class="default">$label</span><span class="keyword">=</span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$href</span><span class="keyword">, </span><span class="default">$label</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">href </span><span class="keyword">= </span><span class="default">$href</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">label </span><span class="keyword">= </span><span class="default">$label</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">__toString</span><span class="keyword">(){<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">'&lt;a '</span><span class="keyword">.</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">nz_arr</span><span class="keyword">(array(</span><span class="string">'id'</span><span class="keyword">, </span><span class="string">'href'</span><span class="keyword">, </span><span class="string">'target'</span><span class="keyword">, </span><span class="string">'class'</span><span class="keyword">)). </span><span class="string">' &gt;' </span><span class="keyword">. </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">label </span><span class="keyword">. </span><span class="string">'&lt;/a&gt;'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">nz_arr</span><span class="keyword">(</span><span class="default">$attrib_arr</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$s </span><span class="keyword">= </span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach(</span><span class="default">$attrib_arr </span><span class="keyword">as </span><span class="default">$attrib</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$s </span><span class="keyword">.= </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">nz</span><span class="keyword">(</span><span class="default">$attrib</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$s</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Print the tag attribute if it is not blank, such as id="$this-&gt;id"<br />&nbsp; &nbsp;&nbsp; * @param string $attrib<br />&nbsp; &nbsp;&nbsp; * @return string<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">function </span><span class="default">nz</span><span class="keyword">(</span><span class="default">$attrib</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$s </span><span class="keyword">= </span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$attrib </span><span class="keyword">!= </span><span class="string">''</span><span class="keyword">) </span><span class="default">$s </span><span class="keyword">= </span><span class="default">$attrib </span><span class="keyword">.</span><span class="string">' = "' </span><span class="keyword">. </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$attrib </span><span class="keyword">. </span><span class="string">'"'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$s</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">//This causes RECURSION because of parsing between double quotes. This is a very UNEXPECTED behaviour!<br />&nbsp; &nbsp; </span><span class="keyword">function </span><span class="default">nz_</span><span class="keyword">(</span><span class="default">$attrib</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$s </span><span class="keyword">= </span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$attrib </span><span class="keyword">!= </span><span class="string">''</span><span class="keyword">) </span><span class="default">$s </span><span class="keyword">= </span><span class="string">"</span><span class="default">$attrib</span><span class="string"> = \"</span><span class="default">$this</span><span class="string">-&gt;</span><span class="default">$attrib</span><span class="string">\""</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$s</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />}</span><span class="comment">//end&nbsp; class<br /><br />//usage<br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">my_tag_A</span><span class="keyword">(</span><span class="string">'abc.php'</span><span class="keyword">, </span><span class="string">'ABC'</span><span class="keyword">); </span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">target </span><span class="keyword">= </span><span class="string">'_blank'</span><span class="keyword">;<br />echo </span><span class="default">$a</span><span class="keyword">;<br /></span><span class="comment">//prints:<br />//&nbsp; &nbsp; &lt;a href="abc.php" target="_blank" &gt;ABC&lt;/a&gt;<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="86622">  <div class="votes">
    <div id="Vu86622">
    <a href="/manual/vote-note.php?id=86622&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86622">
    <a href="/manual/vote-note.php?id=86622&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86622" title="28% like this...">
    -3
    </div>
  </div>
  <a href="#86622" class="name">
  <strong class="user"><em>patricknegri at gmail dot com</em></strong></a><a class="genanchor" href="#86622"> &para;</a><div class="date" title="2008-10-26 03:57"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86622">
<div class="phpcode"><code><span class="html">
Imports Pattern - Extend Classes in Real Time:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">BaseClass<br /></span><span class="keyword">{<br />&nbsp; &nbsp; var </span><span class="default">$__imported</span><span class="keyword">;<br />&nbsp; &nbsp; var </span><span class="default">$__imported_functions</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">__construct</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$__imported </span><span class="keyword">= Array();<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$__imported_functions </span><span class="keyword">= Array();<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">Imports</span><span class="keyword">(</span><span class="default">$object</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$new_imports </span><span class="keyword">= new </span><span class="default">$object</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$imports_name </span><span class="keyword">= </span><span class="default">get_class</span><span class="keyword">(</span><span class="default">$new_imports</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">array_push</span><span class="keyword">( </span><span class="default">$__imported</span><span class="keyword">, Array(</span><span class="default">$imports_name</span><span class="keyword">,</span><span class="default">$new_imports</span><span class="keyword">) );<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$imports_function </span><span class="keyword">= </span><span class="default">get_class_methods</span><span class="keyword">(</span><span class="default">$new_imports</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach (</span><span class="default">$imports_function </span><span class="keyword">as </span><span class="default">$i</span><span class="keyword">=&gt;</span><span class="default">$function_name</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">__imported_functions</span><span class="keyword">[</span><span class="default">$function_name</span><span class="keyword">] = &amp;</span><span class="default">$new_imports</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">__call</span><span class="keyword">(</span><span class="default">$m</span><span class="keyword">, </span><span class="default">$a</span><span class="keyword">)<br />&nbsp; &nbsp; {&nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">array_key_exists</span><span class="keyword">(</span><span class="default">$m</span><span class="keyword">,</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">__imported_functions</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; {&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">call_user_func_array</span><span class="keyword">(Array(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">__imported_functions</span><span class="keyword">[</span><span class="default">$m</span><span class="keyword">],</span><span class="default">$m</span><span class="keyword">),</span><span class="default">$a</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">ErrorException </span><span class="keyword">(</span><span class="string">'Call to Undefined Method/Class Function'</span><span class="keyword">, </span><span class="default">0</span><span class="keyword">, </span><span class="default">E_ERROR</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">ExternalFunc<br /></span><span class="keyword">{<br />&nbsp; &nbsp; function </span><span class="default">TestB</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"External Imported!"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">B </span><span class="keyword">extends </span><span class="default">BaseClass<br /></span><span class="keyword">{<br />&nbsp; &nbsp; function </span><span class="default">__construct</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">Imports</span><span class="keyword">(</span><span class="string">"ExternalFunc"</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">Msg</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Hello world&lt;br /&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$b </span><span class="keyword">= new </span><span class="default">B</span><span class="keyword">();<br /></span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">Msg</span><span class="keyword">();<br /></span><span class="comment">// or call $b-&gt;Imports("ExternalFunc");<br /></span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">TestB</span><span class="keyword">();<br /></span><span class="comment">//$b-&gt;TestB(1,3,4);<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="74937">  <div class="votes">
    <div id="Vu74937">
    <a href="/manual/vote-note.php?id=74937&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd74937">
    <a href="/manual/vote-note.php?id=74937&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V74937" title="25% like this...">
    -4
    </div>
  </div>
  <a href="#74937" class="name">
  <strong class="user"><em>adar at darkpoetry dot de</em></strong></a><a class="genanchor" href="#74937"> &para;</a><div class="date" title="2007-05-04 06:09"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom74937">
<div class="phpcode"><code><span class="html">
Maybe not really new and all in all definitely not the best solution,but if you cant extend a class (if your class alreay extends an abstract or other things like that) you can 'fake' a extend.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">MyClass<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">extends </span><span class="default">SomeAbstractUnknownClass </span><span class="keyword">{<br /><br />&nbsp; &nbsp; private </span><span class="default">$classObject</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public function </span><span class="default">__construct </span><span class="keyword">( </span><span class="default">classObject $classToExtend </span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">classObject </span><span class="keyword">= </span><span class="default">$classToExtend</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">__call</span><span class="keyword">(</span><span class="default">$func</span><span class="keyword">, </span><span class="default">$var</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if ( !</span><span class="default">count</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">) ) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">classObject</span><span class="keyword">-&gt;</span><span class="default">$func</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$str </span><span class="keyword">= </span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$values </span><span class="keyword">= </span><span class="default">array_values</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; for ( </span><span class="default">$i</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">&lt;</span><span class="default">count</span><span class="keyword">(</span><span class="default">$values</span><span class="keyword">); </span><span class="default">$i</span><span class="keyword">++ ) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$str </span><span class="keyword">.= </span><span class="string">"'"</span><span class="keyword">.</span><span class="default">$values</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">].</span><span class="string">"' ,"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }&nbsp;&nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$str </span><span class="keyword">= </span><span class="default">substr</span><span class="keyword">(</span><span class="default">$str</span><span class="keyword">, </span><span class="default">0</span><span class="keyword">, -</span><span class="default">2</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return eval(</span><span class="string">'return $this-&gt;classObject-&gt;'</span><span class="keyword">.</span><span class="default">$func</span><span class="keyword">.</span><span class="string">'('</span><span class="keyword">.</span><span class="default">$str</span><span class="keyword">.</span><span class="string">');'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }&nbsp;&nbsp; <br />&nbsp; &nbsp; }&nbsp;&nbsp; <br />}<br /></span><span class="default">?&gt;<br /></span><br />So if you'll do a $myClass-&gt;unknownMethod() and it is found neither in MyClass nor in SomeAbstractUnknownClass, MyClass will try to call this method in $classObject.<br /><br />I use this for 'extending' a UserObject-Class which already extends an other one.<br /><br />Better solutions are always welcome ;)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="61745">  <div class="votes">
    <div id="Vu61745">
    <a href="/manual/vote-note.php?id=61745&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd61745">
    <a href="/manual/vote-note.php?id=61745&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V61745" title="20% like this...">
    -6
    </div>
  </div>
  <a href="#61745" class="name">
  <strong class="user"><em>ksamvel at gmail dot com</em></strong></a><a class="genanchor" href="#61745"> &para;</a><div class="date" title="2006-02-10 09:29"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom61745">
<div class="phpcode"><code><span class="html">
To copy base part of derived class appropriate method in base should be defined. E.g.:<br /><br />&nbsp; class A {<br />&nbsp; &nbsp; public function setAVar( $oAVar) { $this-&gt;oAVar = $oAVar; }<br />&nbsp; &nbsp; public function getAVar() { return $this-&gt;oAVar; }<br /><br />&nbsp; &nbsp; public function copyA( &amp;$roDest) {<br />&nbsp; &nbsp; &nbsp; if( $roDest instanceof A)<br />&nbsp; &nbsp; &nbsp; &nbsp; $this-&gt;oAVar = $roDest-&gt;oAVar;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; private $oAVar;<br />&nbsp; }<br /><br />&nbsp; class B extends A {<br />&nbsp; &nbsp; public function setBVar( $oBVar) { $this-&gt;oBVar = $oBVar; }<br />&nbsp; &nbsp; public function getBVar() { return $this-&gt;oBVar; }<br /><br />&nbsp; &nbsp; private $oBVar;<br />&nbsp; }<br /><br />&nbsp; $oA = new A();<br />&nbsp; $oB = new B();<br /><br />&nbsp; $oA-&gt;setAVar( 4);<br /><br />&nbsp; $oB-&gt;setAVar( 5);<br />&nbsp; $oB-&gt;setBVar( 6);<br />&nbsp; echo "oA::oAVar " . $oA-&gt;getAVar() . "&lt;br&gt;";<br />&nbsp; echo "oB::oAVar " . $oB-&gt;getAVar() . "&lt;br&gt;";<br />&nbsp; echo "oB::oBVar " . $oB-&gt;getBVar() . "&lt;br&gt;";<br />&nbsp; echo "&lt;br&gt;";<br /><br />&nbsp; $oB-&gt;copyA( $oA);<br /><br />&nbsp; echo "oA::oAVar " . $oA-&gt;getAVar() . "&lt;br&gt;";<br />&nbsp; echo "oB::oAVar " . $oB-&gt;getAVar() . "&lt;br&gt;";<br />&nbsp; echo "oB::oBVar " . $oB-&gt;getBVar() . "&lt;br&gt;";<br /><br />Output:<br /><br />oA::oAVar 4<br />oB::oAVar 5<br />oB::oBVar 6<br /><br />oA::oAVar 4<br />oB::oAVar 4<br />oB::oBVar 6</span>
</code></div>
  </div>
 </div>
  <div class="note" id="91104">  <div class="votes">
    <div id="Vu91104">
    <a href="/manual/vote-note.php?id=91104&amp;page=language.oop5.magic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd91104">
    <a href="/manual/vote-note.php?id=91104&amp;page=language.oop5.magic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V91104" title="20% like this...">
    -9
    </div>
  </div>
  <a href="#91104" class="name">
  <strong class="user"><em>zach at bygeekz dot com</em></strong></a><a class="genanchor" href="#91104"> &para;</a><div class="date" title="2009-05-25 12:45"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom91104">
<div class="phpcode"><code><span class="html">
Try this one on. <br /><br /><span class="default">&lt;?php<br />$ret </span><span class="keyword">= new </span><span class="default">Test</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">);<br /></span><span class="default">var_dump</span><span class="keyword">((bool)(string)</span><span class="default">$ret</span><span class="keyword">);<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$ret</span><span class="keyword">);<br /></span><span class="default">$ret</span><span class="keyword">=</span><span class="default">null</span><span class="keyword">;<br /></span><span class="default">$ret </span><span class="keyword">= new </span><span class="default">Test</span><span class="keyword">();<br /></span><span class="default">var_dump</span><span class="keyword">((bool)(string)</span><span class="default">$ret</span><span class="keyword">);<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$ret</span><span class="keyword">);<br /><br />class </span><span class="default">Test </span><span class="keyword">{<br />&nbsp; &nbsp; protected </span><span class="default">$state</span><span class="keyword">=</span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$state</span><span class="keyword">=</span><span class="default">null</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">state </span><span class="keyword">= </span><span class="default">$state</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; function </span><span class="default">__toString</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">state</span><span class="keyword">) { return </span><span class="string">"1"</span><span class="keyword">; } else { return </span><span class="string">"0"</span><span class="keyword">; }<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />You could for instance do..<br /><br />if(!(bool)(string)$ret) { do_something!; }<br /><br />Alternatively, just make state public, and check it.<br /><br />if(!$ret-&gt;state) {}. <br /><br />There is no automatic way I have found aside from some internal state check to verify a class. It will always return an object. The only way around that is to force it out to string either where I did, or $ret = (string) new Test(); then test the bool of your output.. <br /><br />if (!$ret) { echo "noooo!"; } <br /><br />But now you have no calling methods, so I hope you passed some data in to get a usable string out.<br /><br />Of course, if your class isn't named test, you can add a method..<br /><br />public function test() {<br />&nbsp; &nbsp;&nbsp; return $this-&gt;state;<br />}<br /><br />Logically that will work regardless of the _toString(), but I had hoped to post this to help others see that there are a multitude of ways to check the validity of a class once it is loaded. In __construct you can add any number of checks and set your state appropriately.</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.oop5.magic&amp;redirect=http://php.net/manual/en/language.oop5.magic.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.oop5.php">Classes and Objects</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="oop5.intro.php" title="Introduction">Introduction</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.basic.php" title="The Basics">The Basics</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.properties.php" title="Properties">Properties</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.constants.php" title="Class Constants">Class Constants</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.autoload.php" title="Autoloading Classes">Autoloading Classes</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.decon.php" title="Constructors and Destructors">Constructors and Destructors</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.visibility.php" title="Visibility">Visibility</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.inheritance.php" title="Object Inheritance">Object Inheritance</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.paamayim-nekudotayim.php" title="Scope Resolution Operator (::)">Scope Resolution Operator (::)</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.static.php" title="Static Keyword">Static Keyword</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.abstract.php" title="Class Abstraction">Class Abstraction</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.interfaces.php" title="Object Interfaces">Object Interfaces</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.traits.php" title="Traits">Traits</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.anonymous.php" title="Anonymous classes">Anonymous classes</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.overloading.php" title="Overloading">Overloading</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.iterations.php" title="Object Iteration">Object Iteration</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.oop5.magic.php" title="Magic Methods">Magic Methods</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.final.php" title="Final Keyword">Final Keyword</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.cloning.php" title="Object Cloning">Object Cloning</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.object-comparison.php" title="Comparing Objects">Comparing Objects</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.typehinting.php" title="Type Hinting">Type Hinting</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.late-static-bindings.php" title="Late Static Bindings">Late Static Bindings</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.references.php" title="Objects and references">Objects and references</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.serialization.php" title="Object Serialization">Object Serialization</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.changelog.php" title="OOP Changelog">OOP Changelog</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

