<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Generators overview - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.generators.overview.php">
 <link rel="shorturl" href="http://php.net/generators.overview">
 <link rel="alternate" href="http://php.net/generators.overview" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.generators.php">
 <link rel="prev" href="http://php.net/manual/en/language.generators.php">
 <link rel="next" href="http://php.net/manual/en/language.generators.syntax.php">

 <link rel="alternate" href="http://php.net/manual/en/language.generators.overview.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.generators.overview.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.generators.overview.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.generators.overview.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.generators.overview.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.generators.overview.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.generators.overview.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.generators.overview.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.generators.overview.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.generators.overview.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.generators.overview.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.generators.syntax.php">
          Generator syntax &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.generators.php">
          &laquo; Generators        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.generators.php'>Generators</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.generators.overview.php' selected="selected">English</option>
            <option value='pt_BR/language.generators.overview.php'>Brazilian Portuguese</option>
            <option value='zh/language.generators.overview.php'>Chinese (Simplified)</option>
            <option value='fr/language.generators.overview.php'>French</option>
            <option value='de/language.generators.overview.php'>German</option>
            <option value='ja/language.generators.overview.php'>Japanese</option>
            <option value='ro/language.generators.overview.php'>Romanian</option>
            <option value='ru/language.generators.overview.php'>Russian</option>
            <option value='es/language.generators.overview.php'>Spanish</option>
            <option value='tr/language.generators.overview.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.generators.overview.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.generators.overview">Report a Bug</a>
    </div>
  </div><div id="language.generators.overview" class="sect1">
  <h2 class="title">Generators overview</h2>
  <p class="verinfo">(PHP 5 &gt;= 5.5.0, PHP 7)</p>

  <p class="para">
   Generators provide an easy way to implement simple
   <a href="language.oop5.iterations.php" class="link">iterators</a> without the
   overhead or complexity of implementing a class that implements the
   <a href="class.iterator.php" class="classname">Iterator</a> interface.
  </p>

  <p class="para">
   A generator allows you to write code that uses <a href="control-structures.foreach.php" class="link">foreach</a> to iterate over a
   set of data without needing to build an array in memory, which may cause
   you to exceed a memory limit, or require a considerable amount of
   processing time to generate. Instead, you can write a generator function,
   which is the same as a normal
   <a href="functions.user-defined.php" class="link">function</a>, except that instead
   of
   <a href="functions.returning-values.php" class="link">return</a>ing once, a
   generator can <a href="language.generators.syntax.php#control-structures.yield" class="link">yield</a> as many times as it needs to in order to provide the
   values to be iterated over.
  </p>

  <p class="para">
   A simple example of this is to reimplement the <span class="function"><a href="function.range.php" class="function">range()</a></span>
   function as a generator. The standard <span class="function"><a href="function.range.php" class="function">range()</a></span> function
   has to generate an array with every value in it and return it, which can
   result in large arrays: for example, calling
   <strong class="command">range(0, 1000000)</strong> will result in well over 100 MB of
   memory being used.
  </p>

  <p class="para">
   As an alternative, we can implement an <em>xrange()</em>
   generator, which will only ever need enough memory to create an
   <a href="class.iterator.php" class="classname">Iterator</a> object and track the current state of the
   generator internally, which turns out to be less than 1 kilobyte.
  </p>

  <div class="example" id="example-284">
   <p><strong>Example #1 Implementing <span class="function"><a href="function.range.php" class="function">range()</a></span> as a generator</strong></p>
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">xrange</span><span style="color: #007700">(</span><span style="color: #0000BB">$start</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$limit</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$step&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(</span><span style="color: #0000BB">$start&nbsp;</span><span style="color: #007700">&lt;&nbsp;</span><span style="color: #0000BB">$limit</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(</span><span style="color: #0000BB">$step&nbsp;</span><span style="color: #007700">&lt;=&nbsp;</span><span style="color: #0000BB">0</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;throw&nbsp;new&nbsp;</span><span style="color: #0000BB">LogicException</span><span style="color: #007700">(</span><span style="color: #DD0000">'Step&nbsp;must&nbsp;be&nbsp;+ve'</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;for&nbsp;(</span><span style="color: #0000BB">$i&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$start</span><span style="color: #007700">;&nbsp;</span><span style="color: #0000BB">$i&nbsp;</span><span style="color: #007700">&lt;=&nbsp;</span><span style="color: #0000BB">$limit</span><span style="color: #007700">;&nbsp;</span><span style="color: #0000BB">$i&nbsp;</span><span style="color: #007700">+=&nbsp;</span><span style="color: #0000BB">$step</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">yield&nbsp;$i</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;&nbsp;&nbsp;&nbsp;}&nbsp;else&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(</span><span style="color: #0000BB">$step&nbsp;</span><span style="color: #007700">&gt;=&nbsp;</span><span style="color: #0000BB">0</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;throw&nbsp;new&nbsp;</span><span style="color: #0000BB">LogicException</span><span style="color: #007700">(</span><span style="color: #DD0000">'Step&nbsp;must&nbsp;be&nbsp;-ve'</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;for&nbsp;(</span><span style="color: #0000BB">$i&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$start</span><span style="color: #007700">;&nbsp;</span><span style="color: #0000BB">$i&nbsp;</span><span style="color: #007700">&gt;=&nbsp;</span><span style="color: #0000BB">$limit</span><span style="color: #007700">;&nbsp;</span><span style="color: #0000BB">$i&nbsp;</span><span style="color: #007700">+=&nbsp;</span><span style="color: #0000BB">$step</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">yield&nbsp;$i</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br /></span><span style="color: #FF8000">/*<br />&nbsp;*&nbsp;Note&nbsp;that&nbsp;both&nbsp;range()&nbsp;and&nbsp;xrange()&nbsp;result&nbsp;in&nbsp;the&nbsp;same<br />&nbsp;*&nbsp;output&nbsp;below.<br />&nbsp;*/<br /><br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">'Single&nbsp;digit&nbsp;odd&nbsp;numbers&nbsp;from&nbsp;range():&nbsp;&nbsp;'</span><span style="color: #007700">;<br />foreach&nbsp;(</span><span style="color: #0000BB">range</span><span style="color: #007700">(</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">9</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">)&nbsp;as&nbsp;</span><span style="color: #0000BB">$number</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"</span><span style="color: #0000BB">$number</span><span style="color: #DD0000">&nbsp;"</span><span style="color: #007700">;<br />}<br />echo&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br /><br />echo&nbsp;</span><span style="color: #DD0000">'Single&nbsp;digit&nbsp;odd&nbsp;numbers&nbsp;from&nbsp;xrange():&nbsp;'</span><span style="color: #007700">;<br />foreach&nbsp;(</span><span style="color: #0000BB">xrange</span><span style="color: #007700">(</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">9</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">)&nbsp;as&nbsp;</span><span style="color: #0000BB">$number</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"</span><span style="color: #0000BB">$number</span><span style="color: #DD0000">&nbsp;"</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

   <div class="example-contents"><p>The above example will output:</p></div>
   <div class="example-contents screen">
<div class="cdata"><pre>
Single digit odd numbers from range():  1 3 5 7 9 
Single digit odd numbers from xrange(): 1 3 5 7 9 
</pre></div>
   </div>
  </div>

  <div class="sect2" id="language.generators.object">
   <h3 class="title"><a href="class.generator.php" class="classname">Generator</a> objects</h3>
   <p class="para">
    When a generator function is called for the first time, an object of the
    internal <a href="class.generator.php" class="classname">Generator</a> class is returned. This object
    implements the <a href="class.iterator.php" class="classname">Iterator</a> interface in much the same
    way as a forward-only iterator object would, and provides methods that can
    be called to manipulate the state of the generator, including sending
    values to and returning values from it.
   </p>
  </div>
 </div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.generators.overview&amp;redirect=http://php.net/manual/en/language.generators.overview.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">8 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="112985">  <div class="votes">
    <div id="Vu112985">
    <a href="/manual/vote-note.php?id=112985&amp;page=language.generators.overview&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd112985">
    <a href="/manual/vote-note.php?id=112985&amp;page=language.generators.overview&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V112985" title="79% like this...">
    75
    </div>
  </div>
  <a href="#112985" class="name">
  <strong class="user"><em>bloodjazman at gmail dot com</em></strong></a><a class="genanchor" href="#112985"> &para;</a><div class="date" title="2013-08-15 07:32"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom112985">
<div class="phpcode"><code><span class="html">
for the protection from the leaking of resources <br />see RFC <a href="https://wiki.php.net/rfc/generators#closing_a_generator" rel="nofollow" target="_blank">https://wiki.php.net/rfc/generators#closing_a_generator</a><br /><br />and use finnaly<br /><br />sample code<br /><br />function getLines($file) {<br />&nbsp; &nbsp; $f = fopen($file, 'r');<br />&nbsp; &nbsp; try {<br />&nbsp; &nbsp; &nbsp; &nbsp; while ($line = fgets($f)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; yield $line;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; } finally {<br />&nbsp; &nbsp; &nbsp; &nbsp; fclose($f);<br />&nbsp; &nbsp; }<br />}<br /><br />foreach (getLines("file.txt") as $n =&gt; $line) {<br />&nbsp; &nbsp; if ($n &gt; 5) break;<br />&nbsp; &nbsp; echo $line;<br />}</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119275">  <div class="votes">
    <div id="Vu119275">
    <a href="/manual/vote-note.php?id=119275&amp;page=language.generators.overview&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119275">
    <a href="/manual/vote-note.php?id=119275&amp;page=language.generators.overview&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119275" title="68% like this...">
    8
    </div>
  </div>
  <a href="#119275" class="name">
  <strong class="user"><em>montoriusz at gmail dot com</em></strong></a><a class="genanchor" href="#119275"> &para;</a><div class="date" title="2016-05-01 11:55"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119275">
<div class="phpcode"><code><span class="html">
Bear in mind that execution of a generator function is postponed until iteration over its result (the Generator object) begins. This might confuse one if the result of a generator is assigned to a variable instead of immediate iteration.<br /><br /><span class="default">&lt;?php<br /><br />$some_state </span><span class="keyword">= </span><span class="string">'initial'</span><span class="keyword">;<br /><br />function </span><span class="default">gen</span><span class="keyword">() {<br />&nbsp; &nbsp; global </span><span class="default">$some_state</span><span class="keyword">; <br /><br />&nbsp; &nbsp; echo </span><span class="string">"gen() execution start\n"</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$some_state </span><span class="keyword">= </span><span class="string">"changed"</span><span class="keyword">;<br /><br />&nbsp; &nbsp; yield </span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; yield </span><span class="default">2</span><span class="keyword">;<br />}<br /><br />function </span><span class="default">peek_state</span><span class="keyword">() {<br />&nbsp; &nbsp; global </span><span class="default">$some_state</span><span class="keyword">;<br />&nbsp; &nbsp; echo </span><span class="string">"\$some_state = </span><span class="default">$some_state</span><span class="string">\n"</span><span class="keyword">;<br />}<br /><br />echo </span><span class="string">"calling gen()...\n"</span><span class="keyword">;<br /></span><span class="default">$result </span><span class="keyword">= </span><span class="default">gen</span><span class="keyword">();<br />echo </span><span class="string">"gen() was called\n"</span><span class="keyword">;<br /><br /></span><span class="default">peek_state</span><span class="keyword">();<br /><br />echo </span><span class="string">"iterating...\n"</span><span class="keyword">;<br />foreach (</span><span class="default">$result </span><span class="keyword">as </span><span class="default">$val</span><span class="keyword">) {<br />&nbsp; &nbsp; echo </span><span class="string">"iteration: </span><span class="default">$val</span><span class="string">\n"</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">peek_state</span><span class="keyword">();<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />If you need to perform some action when the function is called and before the result is used, you'll have to wrap your generator in another function.<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">/**<br />&nbsp; * @return Generator<br />&nbsp; */<br /></span><span class="keyword">function </span><span class="default">some_generator</span><span class="keyword">() {<br />&nbsp; &nbsp; global </span><span class="default">$some_state</span><span class="keyword">;<br /><br />&nbsp; &nbsp; </span><span class="default">$some_state </span><span class="keyword">= </span><span class="string">"changed"</span><span class="keyword">;<br />&nbsp; &nbsp; return </span><span class="default">gen</span><span class="keyword">();<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114409">  <div class="votes">
    <div id="Vu114409">
    <a href="/manual/vote-note.php?id=114409&amp;page=language.generators.overview&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114409">
    <a href="/manual/vote-note.php?id=114409&amp;page=language.generators.overview&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114409" title="64% like this...">
    19
    </div>
  </div>
  <a href="#114409" class="name">
  <strong class="user"><em>dc at libertyskull dot com</em></strong></a><a class="genanchor" href="#114409"> &para;</a><div class="date" title="2014-02-17 02:59"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114409">
<div class="phpcode"><code><span class="html">
Same example, different results:<br /><br />----------------------------------<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; |&nbsp; time&nbsp; | memory, mb |<br />----------------------------------<br />| not gen&nbsp; | 0.7589 | 146.75&nbsp; &nbsp;&nbsp; |<br />|---------------------------------<br />| with gen | 0.7469 | 8.75&nbsp; &nbsp; &nbsp;&nbsp; |<br />|---------------------------------<br /><br />Time in results varying from 6.5 to 7.8 on both examples.<br />So no real drawbacks concerning processing speed.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118529">  <div class="votes">
    <div id="Vu118529">
    <a href="/manual/vote-note.php?id=118529&amp;page=language.generators.overview&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118529">
    <a href="/manual/vote-note.php?id=118529&amp;page=language.generators.overview&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118529" title="65% like this...">
    9
    </div>
  </div>
  <a href="#118529" class="name">
  <strong class="user"><em>info at boukeversteegh dot nl</em></strong></a><a class="genanchor" href="#118529"> &para;</a><div class="date" title="2015-12-21 12:21"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom118529">
<div class="phpcode"><code><span class="html">
Here's how to detect loop breaks, and how to handle or cleanup after an interruption.<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">function </span><span class="default">generator</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$complete </span><span class="keyword">= </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; try {<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; while ((</span><span class="default">$result </span><span class="keyword">= </span><span class="default">some_function</span><span class="keyword">())) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; yield </span><span class="default">$result</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$complete </span><span class="keyword">= </span><span class="default">true</span><span class="keyword">;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; } finally {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (!</span><span class="default">$complete</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// cleanup when loop breaks <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">} else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// cleanup when loop completes<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">}<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Do something only after loop completes<br />&nbsp; &nbsp; </span><span class="keyword">}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114136">  <div class="votes">
    <div id="Vu114136">
    <a href="/manual/vote-note.php?id=114136&amp;page=language.generators.overview&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114136">
    <a href="/manual/vote-note.php?id=114136&amp;page=language.generators.overview&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114136" title="61% like this...">
    21
    </div>
  </div>
  <a href="#114136" class="name">
  <strong class="user"><em>lubaev</em></strong></a><a class="genanchor" href="#114136"> &para;</a><div class="date" title="2014-01-15 11:46"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114136">
<div class="phpcode"><code><span class="html">
Abstract test.<br /><span class="default">&lt;?php<br /><br />$start_time</span><span class="keyword">=</span><span class="default">microtime</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">);<br /></span><span class="default">$array </span><span class="keyword">= array();<br /></span><span class="default">$result </span><span class="keyword">= </span><span class="string">''</span><span class="keyword">;<br />for(</span><span class="default">$count</span><span class="keyword">=</span><span class="default">1000000</span><span class="keyword">; </span><span class="default">$count</span><span class="keyword">--;)<br />{<br />&nbsp; </span><span class="default">$array</span><span class="keyword">[]=</span><span class="default">$count</span><span class="keyword">/</span><span class="default">2</span><span class="keyword">;<br />}<br />foreach(</span><span class="default">$array </span><span class="keyword">as </span><span class="default">$val</span><span class="keyword">)<br />{<br />&nbsp; </span><span class="default">$val </span><span class="keyword">+= </span><span class="default">145.56</span><span class="keyword">;<br />&nbsp; </span><span class="default">$result </span><span class="keyword">.= </span><span class="default">$val</span><span class="keyword">;<br />}<br /></span><span class="default">$end_time</span><span class="keyword">=</span><span class="default">microtime</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">);<br /><br />echo </span><span class="string">"time: "</span><span class="keyword">, </span><span class="default">bcsub</span><span class="keyword">(</span><span class="default">$end_time</span><span class="keyword">, </span><span class="default">$start_time</span><span class="keyword">, </span><span class="default">4</span><span class="keyword">), </span><span class="string">"\n"</span><span class="keyword">;<br />echo </span><span class="string">"memory (byte): "</span><span class="keyword">, </span><span class="default">memory_get_peak_usage</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">), </span><span class="string">"\n"</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;<br /></span><br /><span class="default">&lt;?php<br /><br />$start_time</span><span class="keyword">=</span><span class="default">microtime</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">);<br /></span><span class="default">$result </span><span class="keyword">= </span><span class="string">''</span><span class="keyword">;<br />function </span><span class="default">it</span><span class="keyword">()<br />{<br />&nbsp; for(</span><span class="default">$count</span><span class="keyword">=</span><span class="default">1000000</span><span class="keyword">; </span><span class="default">$count</span><span class="keyword">--;)<br />&nbsp; {<br />&nbsp; &nbsp; yield </span><span class="default">$count</span><span class="keyword">/</span><span class="default">2</span><span class="keyword">;<br />&nbsp; }<br />}<br />foreach(</span><span class="default">it</span><span class="keyword">() as </span><span class="default">$val</span><span class="keyword">)<br />{<br />&nbsp; </span><span class="default">$val </span><span class="keyword">+= </span><span class="default">145.56</span><span class="keyword">;<br />&nbsp; </span><span class="default">$result </span><span class="keyword">.= </span><span class="default">$val</span><span class="keyword">;<br />}<br /></span><span class="default">$end_time</span><span class="keyword">=</span><span class="default">microtime</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">);<br /><br />echo </span><span class="string">"time: "</span><span class="keyword">, </span><span class="default">bcsub</span><span class="keyword">(</span><span class="default">$end_time</span><span class="keyword">, </span><span class="default">$start_time</span><span class="keyword">, </span><span class="default">4</span><span class="keyword">), </span><span class="string">"\n"</span><span class="keyword">;<br />echo </span><span class="string">"memory (byte): "</span><span class="keyword">, </span><span class="default">memory_get_peak_usage</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">), </span><span class="string">"\n"</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;<br /></span>Result:<br />----------------------------------<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; |&nbsp; time&nbsp; | memory, mb |<br />----------------------------------<br />| not gen&nbsp; | 2.1216 | 89.25&nbsp; &nbsp; &nbsp; |<br />|---------------------------------<br />| with gen | 6.1963 | 8.75&nbsp; &nbsp; &nbsp;&nbsp; |<br />|---------------------------------<br />| diff&nbsp; &nbsp;&nbsp; | &lt; 192% | &gt; 90%&nbsp; &nbsp; &nbsp; |<br />----------------------------------</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120982">  <div class="votes">
    <div id="Vu120982">
    <a href="/manual/vote-note.php?id=120982&amp;page=language.generators.overview&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120982">
    <a href="/manual/vote-note.php?id=120982&amp;page=language.generators.overview&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120982" title="50% like this...">
    0
    </div>
  </div>
  <a href="#120982" class="name">
  <strong class="user"><em>youssefbenhssaien at gmail dot com</em></strong></a><a class="genanchor" href="#120982"> &para;</a><div class="date" title="2017-04-13 03:29"><strong>8 months ago</strong></div>
  <div class="text" id="Hcom120982">
<div class="phpcode"><code><span class="html">
A simple function to parse an ini configuration file<br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">function </span><span class="default">parse_ini</span><span class="keyword">(</span><span class="default">$file_path</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; if(!</span><span class="default">file_exists</span><span class="keyword">(</span><span class="default">$file_path</span><span class="keyword">)){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">Exception</span><span class="keyword">(</span><span class="string">"File not exists </span><span class="keyword">${</span><span class="default">file_path</span><span class="keyword">}</span><span class="string">"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$text </span><span class="keyword">= </span><span class="default">fopen</span><span class="keyword">(</span><span class="default">$file_path</span><span class="keyword">, </span><span class="string">'r'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; while(</span><span class="default">$line</span><span class="keyword">=</span><span class="default">fgets</span><span class="keyword">(</span><span class="default">$text</span><span class="keyword">)){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; list(</span><span class="default">$key</span><span class="keyword">, </span><span class="default">$param</span><span class="keyword">) = </span><span class="default">explode</span><span class="keyword">(</span><span class="string">'='</span><span class="keyword">, </span><span class="default">$line</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; yield </span><span class="default">$key </span><span class="keyword">=&gt; </span><span class="default">$param</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /></span><span class="default">?&gt;<br /></span>//Usage : parse_ini('param.ini') // returns Generator Object<br />//Usage : iterator_to_array(parse_ini('param.ini')); // returns an array</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121401">  <div class="votes">
    <div id="Vu121401">
    <a href="/manual/vote-note.php?id=121401&amp;page=language.generators.overview&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121401">
    <a href="/manual/vote-note.php?id=121401&amp;page=language.generators.overview&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121401" title="44% like this...">
    -1
    </div>
  </div>
  <a href="#121401" class="name">
  <strong class="user"><em>Aldee Mativo</em></strong></a><a class="genanchor" href="#121401"> &para;</a><div class="date" title="2017-07-19 04:34"><strong>4 months ago</strong></div>
  <div class="text" id="Hcom121401">
<div class="phpcode"><code><span class="html">
Generators can also be a good (best) alternative for hooks.<br /><br />Without generator:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">Crud <br /></span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">create</span><span class="keyword">(array </span><span class="default">$data</span><span class="keyword">, callable </span><span class="default">$preSave </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">) <br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$preSave </span><span class="keyword">&amp;&amp; </span><span class="default">$preSave</span><span class="keyword">(</span><span class="default">$data</span><span class="keyword">);<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">saveRecord</span><span class="keyword">(</span><span class="default">$data</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />Using generator:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">Crud<br /></span><span class="keyword">{<br />&nbsp; &nbsp; protected function </span><span class="default">runHook</span><span class="keyword">(</span><span class="default">$hooks</span><span class="keyword">, </span><span class="default">$key</span><span class="keyword">, &amp;</span><span class="default">$arguments</span><span class="keyword">) <br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$hooks</span><span class="keyword">) || </span><span class="default">$hooks </span><span class="keyword">= [</span><span class="default">$hooks</span><span class="keyword">];<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; isset(</span><span class="default">$hooks</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">]) &amp;&amp; </span><span class="default">$hooks</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">](</span><span class="default">$arguments</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// The good thing about this is that you can create as many hooks as you like without concerning if the caller defines it or not<br />&nbsp; &nbsp; </span><span class="keyword">}<br /><br />&nbsp; &nbsp; public function </span><span class="default">create</span><span class="keyword">(array </span><span class="default">$data</span><span class="keyword">) <br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$hooks </span><span class="keyword">= yield;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">runHook</span><span class="keyword">(</span><span class="default">$hooks</span><span class="keyword">, </span><span class="string">'preSave'</span><span class="keyword">, </span><span class="default">$data</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">saveRecord</span><span class="keyword">(</span><span class="default">$data</span><span class="keyword">);&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$crud </span><span class="keyword">= new </span><span class="default">Crud</span><span class="keyword">;<br /><br /></span><span class="comment">// this will return a \Generator instance<br /></span><span class="default">$generator </span><span class="keyword">= </span><span class="default">$crud</span><span class="keyword">-&gt;</span><span class="default">create</span><span class="keyword">([</span><span class="string">'firstname' </span><span class="keyword">=&gt; </span><span class="string">'foo'</span><span class="keyword">, </span><span class="string">'lastname' </span><span class="keyword">=&gt; </span><span class="string">'bar'</span><span class="keyword">]);<br /><br /></span><span class="comment">// this is where we define our hook(s)<br /></span><span class="default">$generator</span><span class="keyword">-&gt;</span><span class="default">send</span><span class="keyword">([<br />&nbsp; &nbsp; </span><span class="string">'preSave' </span><span class="keyword">=&gt; function(&amp;</span><span class="default">$data</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$data</span><span class="keyword">[</span><span class="string">'lastname'</span><span class="keyword">] = </span><span class="string">'baz'</span><span class="keyword">;<br />&nbsp; &nbsp; }, </span><span class="comment">// and we can have as many as we want here<br /></span><span class="keyword">]);<br /><br /></span><span class="comment">// getting the result of the "create" method call.<br /></span><span class="default">$result </span><span class="keyword">= </span><span class="default">$generator</span><span class="keyword">-&gt;</span><span class="default">getReturn</span><span class="keyword">();</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117753">  <div class="votes">
    <div id="Vu117753">
    <a href="/manual/vote-note.php?id=117753&amp;page=language.generators.overview&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117753">
    <a href="/manual/vote-note.php?id=117753&amp;page=language.generators.overview&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117753" title="19% like this...">
    -34
    </div>
  </div>
  <a href="#117753" class="name">
  <strong class="user"><em>damirchilo at outlook dot com</em></strong></a><a class="genanchor" href="#117753"> &para;</a><div class="date" title="2015-08-02 12:45"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117753">
<div class="phpcode"><code><span class="html">
You can also declare generator functions in a function scope.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">gen_n</span><span class="keyword">(</span><span class="default">$n</span><span class="keyword">){<br />&nbsp; &nbsp; function </span><span class="default">gen_t</span><span class="keyword">(</span><span class="default">$len</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; for(</span><span class="default">$i </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">; </span><span class="default">$i </span><span class="keyword">&lt; </span><span class="default">$len</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">++)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; yield </span><span class="default">$i</span><span class="keyword">; <br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; foreach(</span><span class="default">gen_t</span><span class="keyword">(</span><span class="default">$n</span><span class="keyword">) as </span><span class="default">$out</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">printf</span><span class="keyword">(</span><span class="string">"%d, "</span><span class="keyword">, </span><span class="default">$out</span><span class="keyword">);<br /><br />&nbsp; &nbsp; </span><span class="default">printf</span><span class="keyword">(</span><span class="string">"%d"</span><span class="keyword">, ++</span><span class="default">$out</span><span class="keyword">);<br />}<br /><br /></span><span class="default">gen_n</span><span class="keyword">(</span><span class="default">15</span><span class="keyword">);<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.generators.overview&amp;redirect=http://php.net/manual/en/language.generators.overview.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.generators.php">Generators</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="current">
                            <a href="language.generators.overview.php" title="Generators overview">Generators overview</a>
                        </li>
                          
                        <li class="">
                            <a href="language.generators.syntax.php" title="Generator syntax">Generator syntax</a>
                        </li>
                          
                        <li class="">
                            <a href="language.generators.comparison.php" title="Comparing generators with Iterator objects">Comparing generators with Iterator objects</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

