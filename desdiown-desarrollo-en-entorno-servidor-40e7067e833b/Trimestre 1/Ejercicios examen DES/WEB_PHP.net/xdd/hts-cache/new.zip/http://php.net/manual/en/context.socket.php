<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Socket context options - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/context.socket.php">
 <link rel="shorturl" href="http://php.net/manual/en/context.socket.php">
 <link rel="alternate" href="http://php.net/manual/en/context.socket.php" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/context.php">
 <link rel="prev" href="http://php.net/manual/en/context.php">
 <link rel="next" href="http://php.net/manual/en/context.http.php">

 <link rel="alternate" href="http://php.net/manual/en/context.socket.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/context.socket.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/context.socket.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/context.socket.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/context.socket.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/context.socket.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/context.socket.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/context.socket.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/context.socket.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/context.socket.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/context.socket.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="context.http.php">
          HTTP context options &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="context.php">
          &laquo; Context options and parameters        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='context.php'>Context options and parameters</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/context.socket.php' selected="selected">English</option>
            <option value='pt_BR/context.socket.php'>Brazilian Portuguese</option>
            <option value='zh/context.socket.php'>Chinese (Simplified)</option>
            <option value='fr/context.socket.php'>French</option>
            <option value='de/context.socket.php'>German</option>
            <option value='ja/context.socket.php'>Japanese</option>
            <option value='ro/context.socket.php'>Romanian</option>
            <option value='ru/context.socket.php'>Russian</option>
            <option value='es/context.socket.php'>Spanish</option>
            <option value='tr/context.socket.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/context.socket.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=context.socket">Report a Bug</a>
    </div>
  </div><div id="context.socket" class="refentry">
 <div class="refnamediv">
  <h1 class="refname">Socket context options</h1>
  <p class="refpurpose"><span class="refname">Socket context options</span> &mdash; <span class="dc-title">Socket context option listing</span></p>

 </div>
 
 <div class="refsect1 description" id="refsect1-context.socket-description">
  <h3 class="title">Description</h3>
  <p class="para">
   Socket context options are available for all wrappers that work over
   sockets, like <em>tcp</em>, <em>http</em> and
   <em>ftp</em>.
  </p>
 </div>

 
 <div class="refsect1 options" id="refsect1-context.socket-options">
  <h3 class="title">Options</h3>
  <p class="para">
   <dl>

    
     <dt id="context.socket.bindto"><code class="parameter">bindto</code></dt>

     <dd>

      <p class="para">
       Used to specify the IP address (either IPv4 or IPv6) and/or the
       port number that PHP will use to access the network. The syntax
       is <em>ip:port</em> for IPv4 addresses, and
       <em>[ip]:port</em> for IPv6 addresses.
       Setting the IP or the port to <em>0</em> will let the system
       choose the IP and/or port.
      </p>
      <blockquote class="note"><p><strong class="note">Note</strong>: 
       <p class="para">
        As FTP creates two socket connections during normal operation,
        the port number cannot be specified using this option.
       </p>
      </p></blockquote>
     </dd>

    
    
     <dt id="context.socket.backlog"><code class="parameter">backlog</code></dt>

     <dd>

      <p class="para">
       Used to  limit  the  number  of  outstanding  connections  in  the
       socket&#039;s  listen  queue.
      </p>
      <blockquote class="note"><p><strong class="note">Note</strong>: 
       <p class="para">
        This is only applicable to <span class="function"><a href="function.stream-socket-server.php" class="function">stream_socket_server()</a></span>.
       </p>
      </p></blockquote>
     </dd>

    
    
     <dt id="context.socket.ipv6_v6only"><code class="parameter">ipv6_v6only</code></dt>

     <dd>

      <p class="para">
       Overrides the OS default regarding mapping IPv4 into IPv6.
      </p>
      <blockquote class="note"><p><strong class="note">Note</strong>: 
       <p class="para">
        This is important in particular when trying to listen on IPv4 addresses
        separately while there exists a binding on <em>[::]</em>.
       </p>
       <p class="para">
        This is only applicable to <span class="function"><a href="function.stream-socket-server.php" class="function">stream_socket_server()</a></span>.
       </p>
      </p></blockquote>
     </dd>

    
    
     <dt id="context.socket.so_reuseport"><code class="parameter">so_reuseport</code></dt>

     <dd>

      <p class="para">
       Allows multiple bindings to a same ip:port pair, even from separate processes.
      </p>
      <blockquote class="note"><p><strong class="note">Note</strong>: 
       <p class="para">
        This is only applicable to <span class="function"><a href="function.stream-socket-server.php" class="function">stream_socket_server()</a></span>.
       </p>
      </p></blockquote>
     </dd>

    
    
     <dt id="context.socket.so_broadcast"><code class="parameter">so_broadcast</code></dt>

     <dd>

      <p class="para">
       Enables sending and receiving data to/from broadcast addresses.
      </p>
      <blockquote class="note"><p><strong class="note">Note</strong>: 
       <p class="para">
        This is only applicable to <span class="function"><a href="function.stream-socket-server.php" class="function">stream_socket_server()</a></span>.
       </p>
      </p></blockquote>
     </dd>

    
   </dl>

  </p>
 </div>

 
 <div class="refsect1 changelog" id="refsect1-context.socket-changelog">
  <h3 class="title">Changelog</h3>
  <p class="para">
   <table class="doctable informaltable">
    
     <thead>
      <tr>
       <th>Version</th>
       <th>Description</th>
      </tr>

     </thead>

     <tbody class="tbody">
      <tr>
       <td>7.0.1</td>
       <td>
        Added <code class="parameter">ipv6_v6only</code>.
       </td>
      </tr>

      <tr>
       <td>7.0.0</td>
       <td>
        Added <code class="parameter">so_broadcast</code>.
       </td>
      </tr>

      <tr>
       <td>7.0.0</td>
       <td>
        Added <code class="parameter">so_reuseport</code>.
       </td>
      </tr>

      <tr>
       <td>5.3.3</td>
       <td>
        Added <code class="parameter">backlog</code>.
       </td>
      </tr>

      <tr>
       <td>5.1.0</td>
       <td>
        Added <code class="parameter">bindto</code>.
       </td>
      </tr>

     </tbody>
    
   </table>

  </p>
 </div>

 
 <div class="refsect1 examples" id="refsect1-context.socket-examples">
  <h3 class="title">Examples</h3>
  <p class="para">
   <div class="example" id="example-335">
    <p><strong>Example #1 Basic <code class="parameter">bindto</code> usage example</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #FF8000">//&nbsp;connect&nbsp;to&nbsp;the&nbsp;internet&nbsp;using&nbsp;the&nbsp;'192.168.0.100'&nbsp;IP<br /></span><span style="color: #0000BB">$opts&nbsp;</span><span style="color: #007700">=&nbsp;array(<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'socket'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;array(<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'bindto'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'192.168.0.100:0'</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;),<br />);<br /><br /><br /></span><span style="color: #FF8000">//&nbsp;connect&nbsp;to&nbsp;the&nbsp;internet&nbsp;using&nbsp;the&nbsp;'192.168.0.100'&nbsp;IP&nbsp;and&nbsp;port&nbsp;'7000'<br /></span><span style="color: #0000BB">$opts&nbsp;</span><span style="color: #007700">=&nbsp;array(<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'socket'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;array(<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'bindto'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'192.168.0.100:7000'</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;),<br />);<br /><br /><br /></span><span style="color: #FF8000">//&nbsp;connect&nbsp;to&nbsp;the&nbsp;internet&nbsp;using&nbsp;the&nbsp;'2001:db8::1'&nbsp;IPv6&nbsp;address<br />//&nbsp;and&nbsp;port&nbsp;'7000'<br /></span><span style="color: #0000BB">$opts&nbsp;</span><span style="color: #007700">=&nbsp;array(<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'socket'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;array(<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'bindto'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'[2001:db8::1]:7000'</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;),<br />);<br /><br /><br /></span><span style="color: #FF8000">//&nbsp;connect&nbsp;to&nbsp;the&nbsp;internet&nbsp;using&nbsp;port&nbsp;'7000'<br /></span><span style="color: #0000BB">$opts&nbsp;</span><span style="color: #007700">=&nbsp;array(<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'socket'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;array(<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'bindto'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'0:7000'</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;),<br />);<br /><br /><br /></span><span style="color: #FF8000">//&nbsp;create&nbsp;the&nbsp;context...<br /></span><span style="color: #0000BB">$context&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">stream_context_create</span><span style="color: #007700">(</span><span style="color: #0000BB">$opts</span><span style="color: #007700">);<br /><br /></span><span style="color: #FF8000">//&nbsp;...and&nbsp;use&nbsp;it&nbsp;to&nbsp;fetch&nbsp;the&nbsp;data<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #0000BB">file_get_contents</span><span style="color: #007700">(</span><span style="color: #DD0000">'http://www.example.com'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">false</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$context</span><span style="color: #007700">);<br /><br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
  </p>
 </div>

 
</div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=context.socket&amp;redirect=http://php.net/manual/en/context.socket.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">1 note</span></h3>
 </div><div id="allnotes">
  <div class="note" id="118209">  <div class="votes">
    <div id="Vu118209">
    <a href="/manual/vote-note.php?id=118209&amp;page=context.socket&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118209">
    <a href="/manual/vote-note.php?id=118209&amp;page=context.socket&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118209" title="66% like this...">
    5
    </div>
  </div>
  <a href="#118209" class="name">
  <strong class="user"><em>guru at jnt-finland dot fi</em></strong></a><a class="genanchor" href="#118209"> &para;</a><div class="date" title="2015-10-26 03:54"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom118209">
<div class="phpcode"><code><span class="html">
You can set "bindto" to "0:0" to force use IPv4 instead of IPv6. And probably "[0]:0" to force use IPv6, thou this I couldn't test.</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=context.socket&amp;redirect=http://php.net/manual/en/context.socket.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="context.php">Context options and parameters</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="current">
                            <a href="context.socket.php" title="Socket context options">Socket context options</a>
                        </li>
                          
                        <li class="">
                            <a href="context.http.php" title="HTTP context options">HTTP context options</a>
                        </li>
                          
                        <li class="">
                            <a href="context.ftp.php" title="FTP context options">FTP context options</a>
                        </li>
                          
                        <li class="">
                            <a href="context.ssl.php" title="SSL context options">SSL context options</a>
                        </li>
                          
                        <li class="">
                            <a href="context.curl.php" title="CURL context options">CURL context options</a>
                        </li>
                          
                        <li class="">
                            <a href="context.phar.php" title="Phar context options">Phar context options</a>
                        </li>
                          
                        <li class="">
                            <a href="context.mongodb.php" title="MongoDB context options">MongoDB context options</a>
                        </li>
                          
                        <li class="">
                            <a href="context.params.php" title="Context parameters">Context parameters</a>
                        </li>
                          
                        <li class="">
                            <a href="context.zip.php" title="Zip context options">Zip context options</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

