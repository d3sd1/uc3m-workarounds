<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Object Interfaces - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.oop5.interfaces.php">
 <link rel="shorturl" href="http://php.net/oop5.interfaces">
 <link rel="alternate" href="http://php.net/oop5.interfaces" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.oop5.php">
 <link rel="prev" href="http://php.net/manual/en/language.oop5.abstract.php">
 <link rel="next" href="http://php.net/manual/en/language.oop5.traits.php">

 <link rel="alternate" href="http://php.net/manual/en/language.oop5.interfaces.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.oop5.interfaces.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.oop5.interfaces.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.oop5.interfaces.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.oop5.interfaces.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.oop5.interfaces.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.oop5.interfaces.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.oop5.interfaces.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.oop5.interfaces.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.oop5.interfaces.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.oop5.interfaces.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.oop5.traits.php">
          Traits &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.oop5.abstract.php">
          &laquo; Class Abstraction        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.oop5.php'>Classes and Objects</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.oop5.interfaces.php' selected="selected">English</option>
            <option value='pt_BR/language.oop5.interfaces.php'>Brazilian Portuguese</option>
            <option value='zh/language.oop5.interfaces.php'>Chinese (Simplified)</option>
            <option value='fr/language.oop5.interfaces.php'>French</option>
            <option value='de/language.oop5.interfaces.php'>German</option>
            <option value='ja/language.oop5.interfaces.php'>Japanese</option>
            <option value='ro/language.oop5.interfaces.php'>Romanian</option>
            <option value='ru/language.oop5.interfaces.php'>Russian</option>
            <option value='es/language.oop5.interfaces.php'>Spanish</option>
            <option value='tr/language.oop5.interfaces.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.oop5.interfaces.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.oop5.interfaces">Report a Bug</a>
    </div>
  </div><div id="language.oop5.interfaces" class="sect1">
  <h2 class="title">Object Interfaces</h2>
  <p class="para">
   Object interfaces allow you to create code which specifies which methods a
   class must implement, without having to define how these methods are
   handled.
  </p>
  <p class="para">
   Interfaces are defined in the same way as a class, but with the <em>interface</em>
   keyword replacing the <em>class</em> keyword and without any of the methods having
   their contents defined.
  </p>
  <p class="para">
   All methods declared in an interface must be public; this is the nature of an
   interface.
  </p>
  <p class="para">
   Note that it is possible to declare a <a href="language.oop5.decon.php#language.oop5.decon.constructor" class="link">constructor</a> in an interface,
   what can be useful in some contexts, e.g. for use by factories.
  </p>
  <div class="sect2" id="language.oop5.interfaces.implements">
   <h3 class="title"><em>implements</em></h3>
   <p class="para">
    To implement an interface, the <em>implements</em> operator is used.
    All methods in the interface must be implemented within a class; failure to do
    so will result in a fatal error. Classes may implement more than one interface
    if desired by separating each interface with a comma.
   </p>
   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <p class="para">
     Prior to PHP 5.3.9, a class could not implement two interfaces that
     specified a method with the same name, since it would cause ambiguity.
     More recent versions of PHP allow this as long as the duplicate methods
     have the same signature.
    </p>
   </p></blockquote>
   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <p class="para">
     Interfaces can be extended like classes using the <a href="language.oop5.inheritance.php" class="link">extends</a> 
     operator.
    </p>
   </p></blockquote>
   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <p class="para">
     The class implementing the interface must use the exact same method
     signatures as are defined in the interface. Not doing so will result in a
     fatal error.
     </p>
    </p></blockquote>
  </div>
  <div class="sect2" id="language.oop5.interfaces.constants">
   <h3 class="title"><em>Constants</em></h3>
   <p class="para">
    It&#039;s possible for interfaces to have constants. Interface constants works exactly 
    like <a href="language.oop5.constants.php" class="link">class constants</a> except
    they cannot be overridden by a class/interface that inherits them.
   </p>
  </div>
  <div class="sect2" id="language.oop5.interfaces.examples">
   <h3 class="title">Examples</h3>
   <div class="example" id="example-206">
    <p><strong>Example #1 Interface example</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /><br /></span><span style="color: #FF8000">//&nbsp;Declare&nbsp;the&nbsp;interface&nbsp;'iTemplate'<br /></span><span style="color: #007700">interface&nbsp;</span><span style="color: #0000BB">iTemplate<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">setVariable</span><span style="color: #007700">(</span><span style="color: #0000BB">$name</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$var</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">getHtml</span><span style="color: #007700">(</span><span style="color: #0000BB">$template</span><span style="color: #007700">);<br />}<br /><br /></span><span style="color: #FF8000">//&nbsp;Implement&nbsp;the&nbsp;interface<br />//&nbsp;This&nbsp;will&nbsp;work<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">Template&nbsp;</span><span style="color: #007700">implements&nbsp;</span><span style="color: #0000BB">iTemplate<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;private&nbsp;</span><span style="color: #0000BB">$vars&nbsp;</span><span style="color: #007700">=&nbsp;array();<br />&nbsp;&nbsp;<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">setVariable</span><span style="color: #007700">(</span><span style="color: #0000BB">$name</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$var</span><span style="color: #007700">)<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">vars</span><span style="color: #007700">[</span><span style="color: #0000BB">$name</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #0000BB">$var</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;&nbsp;<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">getHtml</span><span style="color: #007700">(</span><span style="color: #0000BB">$template</span><span style="color: #007700">)<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;foreach(</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">vars&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">$name&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #0000BB">$value</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$template&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">str_replace</span><span style="color: #007700">(</span><span style="color: #DD0000">'{'&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">$name&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">'}'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$value</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$template</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">$template</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br /></span><span style="color: #FF8000">//&nbsp;This&nbsp;will&nbsp;not&nbsp;work<br />//&nbsp;Fatal&nbsp;error:&nbsp;Class&nbsp;BadTemplate&nbsp;contains&nbsp;1&nbsp;abstract&nbsp;methods<br />//&nbsp;and&nbsp;must&nbsp;therefore&nbsp;be&nbsp;declared&nbsp;abstract&nbsp;(iTemplate::getHtml)<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">BadTemplate&nbsp;</span><span style="color: #007700">implements&nbsp;</span><span style="color: #0000BB">iTemplate<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;private&nbsp;</span><span style="color: #0000BB">$vars&nbsp;</span><span style="color: #007700">=&nbsp;array();<br />&nbsp;&nbsp;<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">setVariable</span><span style="color: #007700">(</span><span style="color: #0000BB">$name</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$var</span><span style="color: #007700">)<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">vars</span><span style="color: #007700">[</span><span style="color: #0000BB">$name</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #0000BB">$var</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
   <div class="example" id="example-207">
    <p><strong>Example #2 Extendable Interfaces</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">interface&nbsp;</span><span style="color: #0000BB">a<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">foo</span><span style="color: #007700">();<br />}<br /><br />interface&nbsp;</span><span style="color: #0000BB">b&nbsp;</span><span style="color: #007700">extends&nbsp;</span><span style="color: #0000BB">a<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">baz</span><span style="color: #007700">(</span><span style="color: #0000BB">Baz&nbsp;$baz</span><span style="color: #007700">);<br />}<br /><br /></span><span style="color: #FF8000">//&nbsp;This&nbsp;will&nbsp;work<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">c&nbsp;</span><span style="color: #007700">implements&nbsp;</span><span style="color: #0000BB">b<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">foo</span><span style="color: #007700">()<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">baz</span><span style="color: #007700">(</span><span style="color: #0000BB">Baz&nbsp;$baz</span><span style="color: #007700">)<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br /></span><span style="color: #FF8000">//&nbsp;This&nbsp;will&nbsp;not&nbsp;work&nbsp;and&nbsp;result&nbsp;in&nbsp;a&nbsp;fatal&nbsp;error<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">d&nbsp;</span><span style="color: #007700">implements&nbsp;</span><span style="color: #0000BB">b<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">foo</span><span style="color: #007700">()<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">baz</span><span style="color: #007700">(</span><span style="color: #0000BB">Foo&nbsp;$foo</span><span style="color: #007700">)<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

   </div>
   <div class="example" id="example-208">
    <p><strong>Example #3 Multiple interface inheritance</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">interface&nbsp;</span><span style="color: #0000BB">a<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">foo</span><span style="color: #007700">();<br />}<br /><br />interface&nbsp;</span><span style="color: #0000BB">b<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">bar</span><span style="color: #007700">();<br />}<br /><br />interface&nbsp;</span><span style="color: #0000BB">c&nbsp;</span><span style="color: #007700">extends&nbsp;</span><span style="color: #0000BB">a</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">b<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">baz</span><span style="color: #007700">();<br />}<br /><br />class&nbsp;</span><span style="color: #0000BB">d&nbsp;</span><span style="color: #007700">implements&nbsp;</span><span style="color: #0000BB">c<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">foo</span><span style="color: #007700">()<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">bar</span><span style="color: #007700">()<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">baz</span><span style="color: #007700">()<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

   </div>
   <div class="example" id="example-209">
    <p><strong>Example #4 Interfaces with constants</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">interface&nbsp;</span><span style="color: #0000BB">a<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;const&nbsp;</span><span style="color: #0000BB">b&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'Interface&nbsp;constant'</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #FF8000">//&nbsp;Prints:&nbsp;Interface&nbsp;constant<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #0000BB">a</span><span style="color: #007700">::</span><span style="color: #0000BB">b</span><span style="color: #007700">;<br /><br /><br /></span><span style="color: #FF8000">//&nbsp;This&nbsp;will&nbsp;however&nbsp;not&nbsp;work&nbsp;because&nbsp;it's&nbsp;not&nbsp;allowed&nbsp;to&nbsp;<br />//&nbsp;override&nbsp;constants.<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">b&nbsp;</span><span style="color: #007700">implements&nbsp;</span><span style="color: #0000BB">a<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;const&nbsp;</span><span style="color: #0000BB">b&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'Class&nbsp;constant'</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

   </div>
   <p class="para">
     An interface, together with type-hinting, provides a good way to make sure
     that a particular object contains particular methods. See
     <a href="language.operators.type.php" class="link">instanceof</a> operator and
     <a href="language.oop5.typehinting.php" class="link">type hinting</a>.
   </p>
  </div>

 </div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.oop5.interfaces&amp;redirect=http://php.net/manual/en/language.oop5.interfaces.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">48 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="107364">  <div class="votes">
    <div id="Vu107364">
    <a href="/manual/vote-note.php?id=107364&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd107364">
    <a href="/manual/vote-note.php?id=107364&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V107364" title="91% like this...">
    744
    </div>
  </div>
  <a href="#107364" class="name">
  <strong class="user"><em>dlovell2001 at yahoo dot com</em></strong></a><a class="genanchor" href="#107364"> &para;</a><div class="date" title="2012-02-03 10:40"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom107364">
<div class="phpcode"><code><span class="html">
It seems like many contributors are missing the point of using an INTERFACE. An INTERFACE is not specifically provided for abstraction. That's what a CLASS is used for. Most examples in this article of interfaces could be achieved just as easily using just classes alone. <br /><br />An INTERFACE is provided so you can describe a set of functions and then hide the final implementation of those functions in an implementing class. This allows you to change the IMPLEMENTATION of those functions without changing how you use it. <br /><br />For example: I have a database. I want to write a class that accesses the data in my database. I define an interface like this:<br /><br />interface Database {<br />function listOrders();<br />function addOrder();<br />function removeOrder();<br />...<br />}<br /><br />Then let's say we start out using a MySQL database. So we write a class to access the MySQL database:<br /><br />class MySqlDatabase implements Database {<br />function listOrders() {...<br />}<br />we write these methods as needed to get to the MySQL database tables. Then you can write your controller to use the interface as such:<br /><br />$database = new MySqlDatabase();<br />foreach ($database-&gt;listOrders() as $order) {<br /><br />Then let's say we decide to migrate to an Oracle database. We could write another class to get to the Oracle database as such:<br /><br />class OracleDatabase implements Database {<br />public function listOrders() {...<br />}<br /><br />Then - to switch our application to use the Oracle database instead of the MySQL database we only have to change ONE LINE of code:<br /><br />$database = new OracleDatabase();<br /><br />all other lines of code, such as:<br /><br />foreach ($database-&gt;listOrders() as $order) {<br /><br />will remain unchanged. The point is - the INTERFACE describes the methods that we need to access our database. It does NOT describe in any way HOW we achieve that. That's what the IMPLEMENTing class does. We can IMPLEMENT this interface as many times as we need in as many different ways as we need. We can then switch between implementations of the interface without impact to our code because the interface defines how we will use it regardless of how it actually works.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116233">  <div class="votes">
    <div id="Vu116233">
    <a href="/manual/vote-note.php?id=116233&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116233">
    <a href="/manual/vote-note.php?id=116233&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116233" title="89% like this...">
    128
    </div>
  </div>
  <a href="#116233" class="name">
  <strong class="user"><em>koalay at gmail dot com</em></strong></a><a class="genanchor" href="#116233"> &para;</a><div class="date" title="2014-11-27 04:37"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom116233">
<div class="phpcode"><code><span class="html">
Just wrote some examples of duck-typing in PHP. Sharing here.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="comment">/**<br /> * An example of duck typing in PHP<br /> */<br /><br /></span><span class="keyword">interface </span><span class="default">CanFly </span><span class="keyword">{<br />&nbsp; public function </span><span class="default">fly</span><span class="keyword">();<br />}<br /><br />interface </span><span class="default">CanSwim </span><span class="keyword">{<br />&nbsp; public function </span><span class="default">swim</span><span class="keyword">();<br />}<br /><br />class </span><span class="default">Bird </span><span class="keyword">{<br />&nbsp; public function </span><span class="default">info</span><span class="keyword">() {<br />&nbsp; &nbsp; echo </span><span class="string">"I am a </span><span class="keyword">{</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">name</span><span class="keyword">}</span><span class="string">\n"</span><span class="keyword">;<br />&nbsp; &nbsp; echo </span><span class="string">"I am an bird\n"</span><span class="keyword">;<br />&nbsp; }<br />}<br /><br /></span><span class="comment">/**<br /> * some implementations of birds<br /> */<br /></span><span class="keyword">class </span><span class="default">Dove </span><span class="keyword">extends </span><span class="default">Bird </span><span class="keyword">implements </span><span class="default">CanFly </span><span class="keyword">{<br />&nbsp; var </span><span class="default">$name </span><span class="keyword">= </span><span class="string">"Dove"</span><span class="keyword">;<br />&nbsp; public function </span><span class="default">fly</span><span class="keyword">() {<br />&nbsp; &nbsp; echo </span><span class="string">"I fly\n"</span><span class="keyword">;<br />&nbsp; } <br />}<br /><br />class </span><span class="default">Penguin </span><span class="keyword">extends </span><span class="default">Bird </span><span class="keyword">implements </span><span class="default">CanSwim </span><span class="keyword">{<br />&nbsp; var </span><span class="default">$name </span><span class="keyword">= </span><span class="string">"Penguin"</span><span class="keyword">;<br />&nbsp; public function </span><span class="default">swim</span><span class="keyword">() {<br />&nbsp; &nbsp; echo </span><span class="string">"I swim\n"</span><span class="keyword">;<br />&nbsp; } <br />}<br /><br />class </span><span class="default">Duck </span><span class="keyword">extends </span><span class="default">Bird </span><span class="keyword">implements </span><span class="default">CanFly</span><span class="keyword">, </span><span class="default">CanSwim </span><span class="keyword">{<br />&nbsp; var </span><span class="default">$name </span><span class="keyword">= </span><span class="string">"Duck"</span><span class="keyword">;<br />&nbsp; public function </span><span class="default">fly</span><span class="keyword">() {<br />&nbsp; &nbsp; echo </span><span class="string">"I fly\n"</span><span class="keyword">;<br />&nbsp; }<br />&nbsp; public function </span><span class="default">swim</span><span class="keyword">() {<br />&nbsp; &nbsp; echo </span><span class="string">"I swim\n"</span><span class="keyword">;<br />&nbsp; }<br />}<br /><br /></span><span class="comment">/**<br /> * a simple function to describe a bird<br /> */<br /></span><span class="keyword">function </span><span class="default">describe</span><span class="keyword">(</span><span class="default">$bird</span><span class="keyword">) {<br />&nbsp; if (</span><span class="default">$bird </span><span class="keyword">instanceof </span><span class="default">Bird</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$bird</span><span class="keyword">-&gt;</span><span class="default">info</span><span class="keyword">();<br />&nbsp; &nbsp; if (</span><span class="default">$bird </span><span class="keyword">instanceof </span><span class="default">CanFly</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$bird</span><span class="keyword">-&gt;</span><span class="default">fly</span><span class="keyword">();<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; if (</span><span class="default">$bird </span><span class="keyword">instanceof </span><span class="default">CanSwim</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$bird</span><span class="keyword">-&gt;</span><span class="default">swim</span><span class="keyword">();<br />&nbsp; &nbsp; }<br />&nbsp; } else {<br />&nbsp; &nbsp; die(</span><span class="string">"This is not a bird. I cannot describe it."</span><span class="keyword">);<br />&nbsp; }<br />}<br /><br /></span><span class="comment">// describe these birds please<br /></span><span class="default">describe</span><span class="keyword">(new </span><span class="default">Penguin</span><span class="keyword">);<br />echo </span><span class="string">"---\n"</span><span class="keyword">;<br /><br /></span><span class="default">describe</span><span class="keyword">(new </span><span class="default">Dove</span><span class="keyword">);<br />echo </span><span class="string">"---\n"</span><span class="keyword">;<br /><br /></span><span class="default">describe</span><span class="keyword">(new </span><span class="default">Duck</span><span class="keyword">);</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="71608">  <div class="votes">
    <div id="Vu71608">
    <a href="/manual/vote-note.php?id=71608&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd71608">
    <a href="/manual/vote-note.php?id=71608&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V71608" title="80% like this...">
    6
    </div>
  </div>
  <a href="#71608" class="name">
  <strong class="user"><em>Chris AT w3style DOT co.uk</em></strong></a><a class="genanchor" href="#71608"> &para;</a><div class="date" title="2006-12-07 05:25"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom71608">
<div class="phpcode"><code><span class="html">
Note that you can extend interfaces with other interfaces since under-the-hood they are just abstract classes:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">interface </span><span class="default">Foo </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">doFoo</span><span class="keyword">();<br />}<br /><br />interface </span><span class="default">Bar </span><span class="keyword">extends </span><span class="default">Foo </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">doBar</span><span class="keyword">();<br />}<br /><br />class </span><span class="default">Zip </span><span class="keyword">implements </span><span class="default">Bar </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">doFoo</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Foo"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public function </span><span class="default">doBar</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Bar"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$zip </span><span class="keyword">= new </span><span class="default">Zip</span><span class="keyword">();<br /></span><span class="default">$zip</span><span class="keyword">-&gt;</span><span class="default">doFoo</span><span class="keyword">();<br /></span><span class="default">$zip</span><span class="keyword">-&gt;</span><span class="default">doBar</span><span class="keyword">();<br /><br /></span><span class="default">?&gt;<br /></span><br />This is quite useful when you're using interfaces for identity more than the rigidity it places upon an API.&nbsp; You can get the same result by implementing multiple interfaces.<br /><br />An example of where I've used this in the past is with EventListener objects ala Java's Swing UI.&nbsp; Some listeners are effectively the same thing but happen at different times therefore we can keep the same API but change the naming for clarity.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="50362">  <div class="votes">
    <div id="Vu50362">
    <a href="/manual/vote-note.php?id=50362&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd50362">
    <a href="/manual/vote-note.php?id=50362&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V50362" title="74% like this...">
    34
    </div>
  </div>
  <a href="#50362" class="name">
  <strong class="user"><em>erik dot zoltan at msn dot com</em></strong></a><a class="genanchor" href="#50362"> &para;</a><div class="date" title="2005-02-25 10:43"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom50362">
<div class="phpcode"><code><span class="html">
When should you use interfaces?&nbsp; What are they good for? <br />Here are two examples.&nbsp; <br /><br />1. Interfaces are an excellent way to implement reusability.&nbsp; <br />You can create a general interface for a number of situations <br />(such as a save to/load from disk interface.)&nbsp; You can then <br />implement the interface in a variety of different ways (e.g. for <br />formats such as tab delimited ASCII, XML and a database.)&nbsp; <br />You can write code that asks the object to "save itself to <br />disk" without having to worry what that means for the object <br />in question.&nbsp; One object might save itself to the database, <br />another to an XML and you can change this behavior over <br />time without having to rewrite the calling code.&nbsp; <br /><br />This allows you to write reusable calling code that can work <br />for any number of different objects -- you don't need to know <br />what kind of object it is, as long as it obeys the common <br />interface.&nbsp; <br /><br />2. Interfaces can also promote gradual evolution.&nbsp; On a <br />recent project I had some very complicated work to do and I <br />didn't know how to implement it.&nbsp; I could think of a "basic" <br />implementation but I knew I would have to change it later.&nbsp; <br />So I created interfaces in each of these cases, and created <br />at least one "basic" implementation of the interface that <br />was "good enough for now" even though I knew it would have <br />to change later.&nbsp; <br /><br />When I came back to make the changes, I was able to create <br />some new implementations of these interfaces that added the <br />extra features I needed.&nbsp; Some of my classes still used <br />the "basic" implementations, but others needed the <br />specialized ones.&nbsp; I was able to add the new features to the <br />objects themselves without rewriting the calling code in most <br />cases.&nbsp; It was easy to evolve my code in this way because <br />the changes were mostly isolated -- they didn't spread all <br />over the place like you might expect.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="96137">  <div class="votes">
    <div id="Vu96137">
    <a href="/manual/vote-note.php?id=96137&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd96137">
    <a href="/manual/vote-note.php?id=96137&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V96137" title="73% like this...">
    12
    </div>
  </div>
  <a href="#96137" class="name">
  <strong class="user"><em>uramihsayibok, gmail, com</em></strong></a><a class="genanchor" href="#96137"> &para;</a><div class="date" title="2010-02-10 11:25"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom96137">
<div class="phpcode"><code><span class="html">
Interfaces can define static methods, but note that this won't make sense as you'll be using the class name and not polymorphism.<br /><br />...Unless you have PHP 5.3 which supports late static binding:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">interface </span><span class="default">IDoSomething </span><span class="keyword">{<br />&nbsp; &nbsp; public static function </span><span class="default">doSomething</span><span class="keyword">();<br />}<br /><br />class </span><span class="default">One </span><span class="keyword">implements </span><span class="default">IDoSomething </span><span class="keyword">{<br />&nbsp; &nbsp; public static function </span><span class="default">doSomething</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"One is doing something\n"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">Two </span><span class="keyword">extends </span><span class="default">One </span><span class="keyword">{<br />&nbsp; &nbsp; public static function </span><span class="default">doSomething</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Two is doing something\n"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />function </span><span class="default">example</span><span class="keyword">(</span><span class="default">IDoSomething $doer</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$doer</span><span class="keyword">::</span><span class="default">doSomething</span><span class="keyword">(); </span><span class="comment">// "unexpected ::" in PHP 5.2<br /></span><span class="keyword">}<br /><br /></span><span class="default">example</span><span class="keyword">(new </span><span class="default">One</span><span class="keyword">()); </span><span class="comment">// One is doing something<br /></span><span class="default">example</span><span class="keyword">(new </span><span class="default">Two</span><span class="keyword">()); </span><span class="comment">// Two is doing something<br /><br /></span><span class="default">?&gt;<br /></span><br />If you have PHP 5.2 you can still declare static methods in interfaces. While you won't be able to call them via LSB, the "implements IDoSomething" can serve as a hint/reminder to other developers by saying "this class has a ::doSomething() method".<br />Besides, you'll be upgrading to 5.3 soon, right? Right?<br /><br />(Heh. I just realized: "I do something". Unintentional, I swear!)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="57389">  <div class="votes">
    <div id="Vu57389">
    <a href="/manual/vote-note.php?id=57389&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd57389">
    <a href="/manual/vote-note.php?id=57389&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V57389" title="75% like this...">
    2
    </div>
  </div>
  <a href="#57389" class="name">
  <strong class="user"><em>darealremco at msn dot com</em></strong></a><a class="genanchor" href="#57389"> &para;</a><div class="date" title="2005-10-02 12:53"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom57389">
<div class="phpcode"><code><span class="html">
To two notes below: There is one situation where classes and interfaces can be used interchangeably. In function definitions you can define parameter types to be classes or interfaces. If this was not so then there would not be much use for interfaces at all.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="77950">  <div class="votes">
    <div id="Vu77950">
    <a href="/manual/vote-note.php?id=77950&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd77950">
    <a href="/manual/vote-note.php?id=77950&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V77950" title="73% like this...">
    16
    </div>
  </div>
  <a href="#77950" class="name">
  <strong class="user"><em>Hayley Watson</em></strong></a><a class="genanchor" href="#77950"> &para;</a><div class="date" title="2007-09-20 10:34"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom77950">
<div class="phpcode"><code><span class="html">
On an incidental note, it is not necessary for the implementation of an interface method to use the same variable names for its parameters that were used in the interface declaration.<br /><br />More significantly, your interface method declarations can include default argument values. If you do, you must specify their implementations with default arguments, too. Just like the parameter names, the default argument values do not need to be the same. In fact, there doesn't seem to be any functionality to the one in the interface declaration at all beyond the fact that it is there.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">interface </span><span class="default">isStuffed </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">getStuff</span><span class="keyword">(</span><span class="default">$something</span><span class="keyword">=</span><span class="default">17</span><span class="keyword">);<br />}<br /><br />class </span><span class="default">oof </span><span class="keyword">implements </span><span class="default">isStuffed </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">getStuff</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">=</span><span class="default">42</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$a</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$oof </span><span class="keyword">= new </span><span class="default">oof</span><span class="keyword">;<br /><br />echo </span><span class="default">$oof</span><span class="keyword">-&gt;</span><span class="default">getStuff</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span><br />Implementations that try to declare the method as getStuff(), getStuff($a), or getStuff($a,$b) will all trigger a fatal error.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="77954">  <div class="votes">
    <div id="Vu77954">
    <a href="/manual/vote-note.php?id=77954&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd77954">
    <a href="/manual/vote-note.php?id=77954&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V77954" title="72% like this...">
    10
    </div>
  </div>
  <a href="#77954" class="name">
  <strong class="user"><em>Hayley Watson</em></strong></a><a class="genanchor" href="#77954"> &para;</a><div class="date" title="2007-09-21 03:42"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom77954">
<div class="phpcode"><code><span class="html">
If it's not already obvious, it's worth noticing that the parameters in the interface's method declaration do not have to have the same names as those in any of its implementations.<br /><br />More significantly, default argument values may be supplied for interface method parameters, and they have to be if you want to use default argument values in the implemented classes:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">interface </span><span class="default">isStuffable<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">getStuffed</span><span class="keyword">(</span><span class="default">$ratio</span><span class="keyword">=</span><span class="default">0.5</span><span class="keyword">);<br />}<br /><br />class </span><span class="default">Turkey </span><span class="keyword">implements </span><span class="default">isStuffable<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">getStuffed</span><span class="keyword">(</span><span class="default">$stuffing</span><span class="keyword">=</span><span class="default">1</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// ....<br />&nbsp; &nbsp; </span><span class="keyword">}<br />}<br /></span><span class="default">?&gt;<br /></span><br />Note that not only do the parameters have different names ($ratio and $stuffing), but their default values are free to be different as well. There doesn't seem to be any purpose to the interface's default argument value except as a dummy placeholder to show that there is a default (a class implementing isStuffable will not be able to implement methods with the signatures getStuffed(), getStuffed($a), or getStuffed($a,$b)).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117679">  <div class="votes">
    <div id="Vu117679">
    <a href="/manual/vote-note.php?id=117679&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117679">
    <a href="/manual/vote-note.php?id=117679&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117679" title="68% like this...">
    6
    </div>
  </div>
  <a href="#117679" class="name">
  <strong class="user"><em>aditycse at gmail dot com</em></strong></a><a class="genanchor" href="#117679"> &para;</a><div class="date" title="2015-07-21 05:50"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117679">
<div class="phpcode"><code><span class="html">
Solution for overriding interface constants<br />//we can override interface constants by using&nbsp; abstract class<br />//if Test Class implements inter1 than we can not override inter1 interface constants<br />example:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">interface </span><span class="default">inter1 </span><span class="keyword">{<br /><br />&nbsp; &nbsp; const </span><span class="default">interface1 </span><span class="keyword">= </span><span class="string">"I am from interface 1"</span><span class="keyword">;<br /><br />&nbsp; &nbsp; function </span><span class="default">foo1</span><span class="keyword">();<br /><br />&nbsp; &nbsp; function </span><span class="default">bar1</span><span class="keyword">();<br />}<br /><br />interface </span><span class="default">inter2 </span><span class="keyword">extends </span><span class="default">inter1 </span><span class="keyword">{<br /><br />&nbsp; &nbsp; function </span><span class="default">foo2</span><span class="keyword">();<br /><br />&nbsp; &nbsp; function </span><span class="default">bar2</span><span class="keyword">();<br />}<br /><br />interface </span><span class="default">inter3 </span><span class="keyword">{<br /><br />&nbsp; &nbsp; function </span><span class="default">foo3</span><span class="keyword">();<br /><br />&nbsp; &nbsp; function </span><span class="default">bar3</span><span class="keyword">();<br />}<br /><br />interface </span><span class="default">inter4 </span><span class="keyword">{<br /><br />&nbsp; &nbsp; function </span><span class="default">foo4</span><span class="keyword">();<br /><br />&nbsp; &nbsp; function </span><span class="default">bar4</span><span class="keyword">();<br />}<br /><br />abstract class </span><span class="default">AbsClass </span><span class="keyword">implements </span><span class="default">inter2 </span><span class="keyword">{<br />&nbsp; &nbsp; <br />}<br /><br />class </span><span class="default">Test </span><span class="keyword">extends </span><span class="default">AbsClass </span><span class="keyword">implements </span><span class="default">inter3</span><span class="keyword">, </span><span class="default">inter4 </span><span class="keyword">{<br /><br />&nbsp; &nbsp; const </span><span class="default">interface1 </span><span class="keyword">= </span><span class="string">"I am from test class"</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public function </span><span class="default">foo1</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">foo2</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">foo3</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">foo4</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">bar1</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">bar2</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">bar3</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">bar4</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">display</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">inter1</span><span class="keyword">::</span><span class="default">interface1</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">PHP_EOL</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">Test</span><span class="keyword">::</span><span class="default">interface1</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />}<br /><br /></span><span class="default">$Obj </span><span class="keyword">= new </span><span class="default">Test</span><span class="keyword">();<br /></span><span class="default">$Obj</span><span class="keyword">-&gt;</span><span class="default">display</span><span class="keyword">(); </span><span class="comment">//I am from interface 1 \n I am from test class</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113793">  <div class="votes">
    <div id="Vu113793">
    <a href="/manual/vote-note.php?id=113793&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113793">
    <a href="/manual/vote-note.php?id=113793&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113793" title="68% like this...">
    12
    </div>
  </div>
  <a href="#113793" class="name">
  <strong class="user"><em>tkostantinov</em></strong></a><a class="genanchor" href="#113793"> &para;</a><div class="date" title="2013-12-02 10:58"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113793">
<div class="phpcode"><code><span class="html">
Implementation must be strict, subtypes are not allowed.<br /><br />"The class implementing the interface must use the EXACT SAME METHOD SIGNATURES as are defined in the interface. Not doing so will result in a fatal error. "<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">interface </span><span class="default">I<br /></span><span class="keyword">{<br />&nbsp; function </span><span class="default">foo</span><span class="keyword">(</span><span class="default">stdClass $arg</span><span class="keyword">);<br />}<br /><br />class </span><span class="default">Test </span><span class="keyword">extends </span><span class="default">stdClass<br /></span><span class="keyword">{<br />}<br /><br />class </span><span class="default">Implementation </span><span class="keyword">implements </span><span class="default">I<br /></span><span class="keyword">{<br />&nbsp; function </span><span class="default">foo</span><span class="keyword">(</span><span class="default">Test $arg</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span>Result:<br /><br />Fatal error: Declaration of InterfaceImplementation::foo() must be compatible with I::foo(stdClass $arg) in test.php on line XY</span>
</code></div>
  </div>
 </div>
  <div class="note" id="82346">  <div class="votes">
    <div id="Vu82346">
    <a href="/manual/vote-note.php?id=82346&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd82346">
    <a href="/manual/vote-note.php?id=82346&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V82346" title="70% like this...">
    8
    </div>
  </div>
  <a href="#82346" class="name">
  <strong class="user"><em>kaisershahid at gmail dot com</em></strong></a><a class="genanchor" href="#82346"> &para;</a><div class="date" title="2008-04-07 05:41"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom82346">
<div class="phpcode"><code><span class="html">
php at wallbash dot com's comment of "It's important to note this because it is very unexpected behavior and renders many common Interface completly useless" doesn't make sense.<br /><br />the idea of the interface is to force objects that aren't related to be reused in a common way. without them, to force that requirement, all objects that need those methods implemented would have to be descended from a base class that's known to have those methods. that's clearly not a smart idea if these objects aren't actually related.<br /><br />one example (that i'm currently working on) is a background service that pulls information down from different content providers. i have a transport and i have an import. for both, what actually happens in the background is different from provider to provider, but since i'm implementing a transport &amp; import interface, i only need to write code once, because i know exactly the what methods will be implemented to get the job done. then, i just have a config file that loads the class dynamically. i don't need something like<br /><br />if ( $provider == "some company" )<br />{<br />&nbsp;&nbsp; // use this set of code<br />}<br />elseif ( $provider == "another company" )<br />{<br />&nbsp;&nbsp; // use this other set of code<br />}<br /><br />instead, i can do:<br /><br />foreach ( $providers as $provider =&gt; $info )<br />{<br />&nbsp; &nbsp; $_transport = $info['transportObject'];<br />&nbsp; &nbsp; $transport = new $_transport();<br />&nbsp; &nbsp; $_import = $info['importObject'];<br />&nbsp; &nbsp; $import = new $_import();<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; $transport-&gt;setImporter( $import );<br />&nbsp; &nbsp; $transport-&gt;retrieve();<br />}<br /><br />it is expected behavior that when a class implements two interfaces that share one or more method names, an error is thrown, because interfaces don't relate to each other. if you want that sort of inferred behavior (i.e. A and B are different except for these shared methods), stick to [abstract] classes.<br /><br />it sucks that interface methods might collide for some common types of tasks (get(), set(), etc.), so knowing that, design your interfaces with more unique method names.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="96368">  <div class="votes">
    <div id="Vu96368">
    <a href="/manual/vote-note.php?id=96368&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd96368">
    <a href="/manual/vote-note.php?id=96368&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V96368" title="68% like this...">
    6
    </div>
  </div>
  <a href="#96368" class="name">
  <strong class="user"><em>drieick at hotmail dot com</em></strong></a><a class="genanchor" href="#96368"> &para;</a><div class="date" title="2010-02-23 09:29"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom96368">
<div class="phpcode"><code><span class="html">
I was wondering if implementing interfaces will take into account inheritance. That is, can inherited methods be used to follow an interface's structure?<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">interface </span><span class="default">Auxiliary_Platform </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">Weapon</span><span class="keyword">();<br />&nbsp; &nbsp; public function </span><span class="default">Health</span><span class="keyword">();<br />&nbsp; &nbsp; public function </span><span class="default">Shields</span><span class="keyword">();<br />}<br /><br />class </span><span class="default">T805 </span><span class="keyword">implements </span><span class="default">Auxiliary_Platform </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">Weapon</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">__CLASS__</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public function </span><span class="default">Health</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">__CLASS__ </span><span class="keyword">. </span><span class="string">"::" </span><span class="keyword">. </span><span class="default">__FUNCTION__</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public function </span><span class="default">Shields</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">__CLASS__ </span><span class="keyword">. </span><span class="string">"-&gt;" </span><span class="keyword">. </span><span class="default">__FUNCTION__</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">T806 </span><span class="keyword">extends </span><span class="default">T805 </span><span class="keyword">implements </span><span class="default">Auxiliary_Platform </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">Weapon</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">__CLASS__</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public function </span><span class="default">Shields</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">__CLASS__ </span><span class="keyword">. </span><span class="string">"-&gt;" </span><span class="keyword">. </span><span class="default">__FUNCTION__</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$T805 </span><span class="keyword">= new </span><span class="default">T805</span><span class="keyword">();<br /></span><span class="default">$T805</span><span class="keyword">-&gt;</span><span class="default">Weapon</span><span class="keyword">();<br /></span><span class="default">$T805</span><span class="keyword">-&gt;</span><span class="default">Health</span><span class="keyword">();<br /></span><span class="default">$T805</span><span class="keyword">-&gt;</span><span class="default">Shields</span><span class="keyword">();<br /><br />echo </span><span class="string">"&lt;hr /&gt;"</span><span class="keyword">;<br /><br /></span><span class="default">$T806 </span><span class="keyword">= new </span><span class="default">T806</span><span class="keyword">();<br /></span><span class="default">$T806</span><span class="keyword">-&gt;</span><span class="default">Weapon</span><span class="keyword">();<br /></span><span class="default">$T806</span><span class="keyword">-&gt;</span><span class="default">Health</span><span class="keyword">();<br /></span><span class="default">$T806</span><span class="keyword">-&gt;</span><span class="default">Shields</span><span class="keyword">();<br /><br /></span><span class="comment">/* Output:<br />string(4) "T805"<br />string(12) "T805::Health"<br />string(13) "T805-&gt;Shields"<br />&lt;hr /&gt;string(4) "T806"<br />string(12) "T805::Health"<br />string(13) "T806-&gt;Shields"<br />*/<br /><br /></span><span class="default">?&gt;<br /></span><br />Class T805 implements the interface Auxiliary_Platform. T806 does the same thing, but the method Health() is inherited from T805 (not the exact case, but you get the idea). PHP seems to be fine with this and everything still works fine. Do note that the rules for class inheritance doesn't change in this scenario.<br /><br />If the code were to be the same, but instead T805 (or T806) DOES NOT implement Auxiliary_Platform, then it'll still work. Since T805 already follows the interface, everything that inherits T805 will also be valid. I would be careful about that. Personally, I don't consider this a bug.<br /><br />This seems to work in PHP5.2.9-2, PHP5.3 and PHP5.3.1 (my current versions).<br /><br />We could also do the opposite:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">T805 </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">Weapon</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">__CLASS__</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">T806 </span><span class="keyword">extends </span><span class="default">T805 </span><span class="keyword">implements </span><span class="default">Auxiliary_Platform </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">Health</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">__CLASS__ </span><span class="keyword">. </span><span class="string">"::" </span><span class="keyword">. </span><span class="default">__FUNCTION__</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public function </span><span class="default">Shields</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">__CLASS__ </span><span class="keyword">. </span><span class="string">"-&gt;" </span><span class="keyword">. </span><span class="default">__FUNCTION__</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$T805 </span><span class="keyword">= new </span><span class="default">T805</span><span class="keyword">();<br /></span><span class="default">$T805</span><span class="keyword">-&gt;</span><span class="default">Weapon</span><span class="keyword">();<br /><br />echo </span><span class="string">"&lt;hr /&gt;"</span><span class="keyword">;<br /><br /></span><span class="default">$T806 </span><span class="keyword">= new </span><span class="default">T806</span><span class="keyword">();<br /></span><span class="default">$T806</span><span class="keyword">-&gt;</span><span class="default">Weapon</span><span class="keyword">();<br /></span><span class="default">$T806</span><span class="keyword">-&gt;</span><span class="default">Health</span><span class="keyword">();<br /></span><span class="default">$T806</span><span class="keyword">-&gt;</span><span class="default">Shields</span><span class="keyword">();<br /><br /></span><span class="comment">/* Output:<br />string(4) "T805"<br />&lt;hr /&gt;string(4) "T805"<br />string(12) "T806::Health"<br />string(13) "T806-&gt;Shields"<br />*/<br /><br /></span><span class="default">?&gt;<br /></span><br />This works as well, but the output is different. I'd be careful with this.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="85728">  <div class="votes">
    <div id="Vu85728">
    <a href="/manual/vote-note.php?id=85728&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd85728">
    <a href="/manual/vote-note.php?id=85728&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V85728" title="69% like this...">
    5
    </div>
  </div>
  <a href="#85728" class="name">
  <strong class="user"><em>secure_admin</em></strong></a><a class="genanchor" href="#85728"> &para;</a><div class="date" title="2008-09-14 02:28"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom85728">
<div class="phpcode"><code><span class="html">
In response to harryjry and mehea concerning your Weather Model. The problem is that you don't need all the things you think you need. In OOP, good class definitions get to the point rather quickly.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Weather</span><span class="keyword">{<br />&nbsp; public </span><span class="default">$time</span><span class="keyword">, </span><span class="default">$temperature</span><span class="keyword">, </span><span class="default">$humidity</span><span class="keyword">;<br /><br />&nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$tm</span><span class="keyword">, </span><span class="default">$t</span><span class="keyword">, </span><span class="default">$h</span><span class="keyword">){<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">time </span><span class="keyword">= </span><span class="default">$tm</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">temperature </span><span class="keyword">= </span><span class="default">$t</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">humidity </span><span class="keyword">= </span><span class="default">$h</span><span class="keyword">;<br />&nbsp; }<br /><br />&nbsp; public function </span><span class="default">__toString</span><span class="keyword">(){<br />&nbsp; &nbsp; return </span><span class="string">"Time: </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">time</span><span class="string">, <br />&nbsp; &nbsp; &nbsp; Temperature: </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">temperature</span><span class="string">&amp;deg;, <br />&nbsp; &nbsp; &nbsp; Humidity: </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">humidity</span><span class="string">%"</span><span class="keyword">;<br />&nbsp; }<br />}<br /><br /></span><span class="default">$forecasts </span><span class="keyword">= array(<br />&nbsp; new </span><span class="default">Weather</span><span class="keyword">(</span><span class="string">"1:00 pm"</span><span class="keyword">, </span><span class="default">65</span><span class="keyword">, </span><span class="default">42</span><span class="keyword">),<br />&nbsp; new </span><span class="default">Weather</span><span class="keyword">(</span><span class="string">"2:00 pm"</span><span class="keyword">, </span><span class="default">66</span><span class="keyword">, </span><span class="default">40</span><span class="keyword">),<br />&nbsp; new </span><span class="default">Weather</span><span class="keyword">(</span><span class="string">"3:00 pm"</span><span class="keyword">, </span><span class="default">68</span><span class="keyword">, </span><span class="default">39</span><span class="keyword">)<br />&nbsp; </span><span class="comment">// add more weather reports as desired...<br /></span><span class="keyword">);<br />echo </span><span class="string">"Forecast for Chicago, IL:&lt;br&gt;"</span><span class="keyword">;<br />foreach(</span><span class="default">$forecasts </span><span class="keyword">as </span><span class="default">$forecast</span><span class="keyword">) echo </span><span class="string">' - ' </span><span class="keyword">. </span><span class="default">$forecast </span><span class="string">'&lt;br&gt;'</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span>Forecast for Chicago, IL:<br />- Time: 1:00 pm, Temperature: 65°, Humidity: 42%<br />- Time: 2:00 pm, Temperature: 66°, Humidity: 40%<br />- Time: 3:00 pm, Temperature: 68°, Humidity: 39%<br /><br />Note: MySQL can store data like this already, but if you included constants, more variables, and other functions in the Weather class, then maybe, just maybe it could be of use.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="102755">  <div class="votes">
    <div id="Vu102755">
    <a href="/manual/vote-note.php?id=102755&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd102755">
    <a href="/manual/vote-note.php?id=102755&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V102755" title="67% like this...">
    12
    </div>
  </div>
  <a href="#102755" class="name">
  <strong class="user"><em>thanhn2001 at gmail dot com</em></strong></a><a class="genanchor" href="#102755"> &para;</a><div class="date" title="2011-03-03 01:37"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom102755">
<div class="phpcode"><code><span class="html">
PHP prevents interface a contant to be overridden by a class/interface that DIRECTLY inherits it.&nbsp; However, further inheritance allows it.&nbsp; That means that interface constants are not final as mentioned in a previous comment.&nbsp; Is this a bug or a feature?<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">interface </span><span class="default">a<br /></span><span class="keyword">{<br />&nbsp; &nbsp; const </span><span class="default">b </span><span class="keyword">= </span><span class="string">'Interface constant'</span><span class="keyword">;<br />}<br /><br /></span><span class="comment">// Prints: Interface constant<br /></span><span class="keyword">echo </span><span class="default">a</span><span class="keyword">::</span><span class="default">b</span><span class="keyword">;<br /><br />class </span><span class="default">b </span><span class="keyword">implements </span><span class="default">a<br /></span><span class="keyword">{<br />}<br /><br /></span><span class="comment">// This works!!!<br /></span><span class="keyword">class </span><span class="default">c </span><span class="keyword">extends </span><span class="default">b<br /></span><span class="keyword">{<br />&nbsp; &nbsp; const </span><span class="default">b </span><span class="keyword">= </span><span class="string">'Class constant'</span><span class="keyword">;<br />}<br /><br />echo </span><span class="default">c</span><span class="keyword">::</span><span class="default">b</span><span class="keyword">;<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114320">  <div class="votes">
    <div id="Vu114320">
    <a href="/manual/vote-note.php?id=114320&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114320">
    <a href="/manual/vote-note.php?id=114320&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114320" title="66% like this...">
    6
    </div>
  </div>
  <a href="#114320" class="name">
  <strong class="user"><em>Vasiliy Makogon</em></strong></a><a class="genanchor" href="#114320"> &para;</a><div class="date" title="2014-02-06 11:38"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114320">
<div class="phpcode"><code><span class="html">
The class implementing the interface must use the exact same method signatures as are defined in the interface. Not doing so will result in a fatal error. -- this documentation page.<br /><br />But, if you use default values in arguments in methods, fatal error is not follow:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">interface </span><span class="default">myInterface </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">();<br />}<br /><br />class </span><span class="default">concret </span><span class="keyword">implements </span><span class="default">myInterface </span><span class="keyword">{<br /><br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$arg</span><span class="keyword">=</span><span class="default">null</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">print_r</span><span class="keyword">(</span><span class="default">func_get_args</span><span class="keyword">());<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$obj </span><span class="keyword">= new </span><span class="default">concret</span><span class="keyword">(</span><span class="default">123</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />Array ( [0] =&gt; 123 )</span>
</code></div>
  </div>
 </div>
  <div class="note" id="115646">  <div class="votes">
    <div id="Vu115646">
    <a href="/manual/vote-note.php?id=115646&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115646">
    <a href="/manual/vote-note.php?id=115646&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115646" title="66% like this...">
    3
    </div>
  </div>
  <a href="#115646" class="name">
  <strong class="user"><em>marcoshoya at gmail dot com</em></strong></a><a class="genanchor" href="#115646"> &para;</a><div class="date" title="2014-08-31 08:48"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115646">
<div class="phpcode"><code><span class="html">
You can change some methods signature from interface if you pass parameters with default values. For instance:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">interface </span><span class="default">Foo </span><span class="keyword">{<br />&nbsp; public function </span><span class="default">foo</span><span class="keyword">(</span><span class="default">$foo</span><span class="keyword">);<br />}<br /><br />class </span><span class="default">Bar </span><span class="keyword">implements </span><span class="default">Foo </span><span class="keyword">{<br />&nbsp; public function </span><span class="default">foo</span><span class="keyword">(</span><span class="default">$foo</span><span class="keyword">, </span><span class="default">$bar </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">) {<br />&nbsp; &nbsp; return </span><span class="default">$foo </span><span class="keyword">. </span><span class="default">$bar</span><span class="keyword">;<br />&nbsp; }<br />}<br /><br /></span><span class="default">$bar </span><span class="keyword">= new </span><span class="default">Bar</span><span class="keyword">();<br /></span><span class="comment">// output: worksfine<br /></span><span class="keyword">echo </span><span class="default">$bar</span><span class="keyword">-&gt;</span><span class="default">foo</span><span class="keyword">(</span><span class="string">'works'</span><span class="keyword">, </span><span class="string">'fine'</span><span class="keyword">);</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="112536">  <div class="votes">
    <div id="Vu112536">
    <a href="/manual/vote-note.php?id=112536&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd112536">
    <a href="/manual/vote-note.php?id=112536&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V112536" title="66% like this...">
    7
    </div>
  </div>
  <a href="#112536" class="name">
  <strong class="user"><em>Vladimir Kornea</em></strong></a><a class="genanchor" href="#112536"> &para;</a><div class="date" title="2013-06-26 07:34"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom112536">
<div class="phpcode"><code><span class="html">
By asking your colleague to implement your interface, you are asking him to guarantee that he has implemented all the methods you need. He can implement multiple interfaces, each being a contract, so that the guy cleaning up the cruft down the road can see which methods belong to which area of concern; but since interfaces are primarily contracts rather than documentation, a class cannot implement two interfaces containing the same method since that would make the contract lose credibility through ambiguity. Thus a class can implement two interfaces with overlapping concerns only by factoring their common methods into a third interface that serves as a base for the first two, which resolves the contractual ambiguity.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="52531">  <div class="votes">
    <div id="Vu52531">
    <a href="/manual/vote-note.php?id=52531&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd52531">
    <a href="/manual/vote-note.php?id=52531&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V52531" title="68% like this...">
    6
    </div>
  </div>
  <a href="#52531" class="name">
  <strong class="user"><em>tobias_demuth at web dot de</em></strong></a><a class="genanchor" href="#52531"> &para;</a><div class="date" title="2005-05-04 02:21"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom52531">
<div class="phpcode"><code><span class="html">
The statement, that you have to implement _all_ methods of an interface has not to be taken that seriously, at least if you declare an abstract class and want to force the inheriting subclasses to implement the interface.<br />Just leave out all methods that should be implemented by the subclasses. But never write something like this:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">interface </span><span class="default">Foo </span><span class="keyword">{<br /><br />&nbsp; &nbsp; &nbsp; function </span><span class="default">bar</span><span class="keyword">();<br /><br />}<br /><br />abstract class </span><span class="default">FooBar </span><span class="keyword">implements </span><span class="default">Foo </span><span class="keyword">{<br /><br />&nbsp; &nbsp; &nbsp;&nbsp; abstract function </span><span class="default">bar</span><span class="keyword">(); </span><span class="comment">// just for making clear, that this<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; // method has to be implemented<br /><br /></span><span class="keyword">}<br /><br /></span><span class="default">?&gt;<br /></span><br />This will end up with the following error-message:<br /><br />Fatal error: Can't inherit abstract function Foo::bar() (previously declared abstract in FooBar) in path/to/file on line anylinenumber</span>
</code></div>
  </div>
 </div>
  <div class="note" id="84804">  <div class="votes">
    <div id="Vu84804">
    <a href="/manual/vote-note.php?id=84804&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd84804">
    <a href="/manual/vote-note.php?id=84804&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V84804" title="66% like this...">
    2
    </div>
  </div>
  <a href="#84804" class="name">
  <strong class="user"><em>mehea</em></strong></a><a class="genanchor" href="#84804"> &para;</a><div class="date" title="2008-07-30 11:55"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom84804">
<div class="phpcode"><code><span class="html">
While a subclass may implement an interface by extending an abstract class that implements the interface, I question whether it is good design to to do so.&nbsp; Here's what I would suggest while taking the liberty of modifying the above weather/wet model:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">interface </span><span class="default">water<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">makeItWet</span><span class="keyword">();<br />}<br /><br /> <br /></span><span class="comment">/**<br />&nbsp;&nbsp; * abstract class implements water but defines makeItWet<br />&nbsp;&nbsp; * in the most general way to allow child class to <br />&nbsp;&nbsp; * provide specificity<br />**/<br /></span><span class="keyword">abstract class </span><span class="default">weather </span><span class="keyword">implements </span><span class="default">water&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br /></span><span class="keyword">{<br />&nbsp;&nbsp; private </span><span class="default">$cloudy</span><span class="keyword">;<br />&nbsp;&nbsp; public function </span><span class="default">makeItWet</span><span class="keyword">(){}<br />&nbsp;&nbsp; abstract public function </span><span class="default">start</span><span class="keyword">();<br />&nbsp;&nbsp; abstract public function </span><span class="default">getCloudy</span><span class="keyword">();<br />&nbsp;&nbsp; abstract public function </span><span class="default">setCloudy</span><span class="keyword">();<br />}<br /><br />class </span><span class="default">rain </span><span class="keyword">extends </span><span class="default">weather&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; private </span><span class="default">$cloudy</span><span class="keyword">;&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">start</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">"Here's some weather. "</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">makeItWet</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">'it is raining cats and dogs today.'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public function </span><span class="default">getCloudy</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">cloudy</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public function </span><span class="default">setCloudy</span><span class="keyword">(</span><span class="default">$bln</span><span class="keyword">=</span><span class="default">false</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">cloudy </span><span class="keyword">= </span><span class="default">$bln</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">rain</span><span class="keyword">();<br />echo </span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">start</span><span class="keyword">();<br /></span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">setCloudy</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">);<br />if (</span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">getCloudy</span><span class="keyword">()) {<br />&nbsp; &nbsp; echo </span><span class="string">'It is a cloudy day and '</span><span class="keyword">;<br />}<br />echo </span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">makeItWet</span><span class="keyword">();<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="69467">  <div class="votes">
    <div id="Vu69467">
    <a href="/manual/vote-note.php?id=69467&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd69467">
    <a href="/manual/vote-note.php?id=69467&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V69467" title="65% like this...">
    13
    </div>
  </div>
  <a href="#69467" class="name">
  <strong class="user"><em>marasek AT telton POINT de</em></strong></a><a class="genanchor" href="#69467"> &para;</a><div class="date" title="2006-09-06 06:01"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom69467">
<div class="phpcode"><code><span class="html">
What is not mentioned in the manual is that you can use "self" to force object hinting on a method of the implementing class:<br /><br />Consider the following interface:<br /><span class="default">&lt;?php<br /></span><span class="keyword">interface </span><span class="default">Comparable<br /></span><span class="keyword">{function </span><span class="default">compare</span><span class="keyword">(</span><span class="default">self $compare</span><span class="keyword">);}<br /></span><span class="default">?&gt;<br /></span><br />Which is then implemented:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">String </span><span class="keyword">implements </span><span class="default">Comparable<br /></span><span class="keyword">{<br />&nbsp; &nbsp; private </span><span class="default">$string</span><span class="keyword">;<br />&nbsp; &nbsp; function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$string</span><span class="keyword">)<br />&nbsp; &nbsp; {</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">string </span><span class="keyword">= </span><span class="default">$string</span><span class="keyword">;}<br />&nbsp; &nbsp; function </span><span class="default">compare</span><span class="keyword">(</span><span class="default">self $compare</span><span class="keyword">)<br />&nbsp; &nbsp; {return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">string </span><span class="keyword">== </span><span class="default">$compare</span><span class="keyword">-&gt;</span><span class="default">string</span><span class="keyword">;}<br />}<br /><br />class </span><span class="default">Integer </span><span class="keyword">implements </span><span class="default">Comparable<br /></span><span class="keyword">{<br />&nbsp; &nbsp; private </span><span class="default">$integer</span><span class="keyword">;<br />&nbsp; &nbsp; function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$int</span><span class="keyword">)<br />&nbsp; &nbsp; {</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">integer </span><span class="keyword">= </span><span class="default">$int</span><span class="keyword">;}<br />&nbsp; &nbsp; function </span><span class="default">compare</span><span class="keyword">(</span><span class="default">self $compare</span><span class="keyword">)<br />&nbsp; &nbsp; {return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">integer </span><span class="keyword">== </span><span class="default">$compare</span><span class="keyword">-&gt;</span><span class="default">integer</span><span class="keyword">;}<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />Comparing Integer with String will result in a fatal error, as it is not an instance of the same class:<br /><br /><span class="default">&lt;?php<br />$first_int </span><span class="keyword">= new </span><span class="default">Integer</span><span class="keyword">(</span><span class="default">3</span><span class="keyword">);<br /></span><span class="default">$second_int </span><span class="keyword">= new </span><span class="default">Integer</span><span class="keyword">(</span><span class="default">3</span><span class="keyword">);<br /></span><span class="default">$first_string </span><span class="keyword">= new </span><span class="default">String</span><span class="keyword">(</span><span class="string">"foo"</span><span class="keyword">);<br /></span><span class="default">$second_string </span><span class="keyword">= new </span><span class="default">String</span><span class="keyword">(</span><span class="string">"bar"</span><span class="keyword">);<br /><br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$first_int</span><span class="keyword">-&gt;</span><span class="default">compare</span><span class="keyword">(</span><span class="default">$second_int</span><span class="keyword">)); </span><span class="comment">// bool(true)<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$first_string</span><span class="keyword">-&gt;</span><span class="default">compare</span><span class="keyword">(</span><span class="default">$second_string</span><span class="keyword">)); </span><span class="comment">// bool(false)<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$first_string</span><span class="keyword">-&gt;</span><span class="default">compare</span><span class="keyword">(</span><span class="default">$second_int</span><span class="keyword">)); </span><span class="comment">// Fatal Error<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="47759">  <div class="votes">
    <div id="Vu47759">
    <a href="/manual/vote-note.php?id=47759&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd47759">
    <a href="/manual/vote-note.php?id=47759&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V47759" title="66% like this...">
    2
    </div>
  </div>
  <a href="#47759" class="name">
  <strong class="user"><em>russ dot collier at gmail dot com</em></strong></a><a class="genanchor" href="#47759"> &para;</a><div class="date" title="2004-11-28 10:24"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom47759">
<div class="phpcode"><code><span class="html">
You can also specify class constants in interfaces as well (similar to specifying 'public static final' fields in Java interfaces):<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">interface </span><span class="default">FooBar<br /></span><span class="keyword">{<br /><br />&nbsp; &nbsp; const </span><span class="default">SOME_CONSTANT </span><span class="keyword">= </span><span class="string">'I am an interface constant'</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public function </span><span class="default">doStuff</span><span class="keyword">();<br /><br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />Then you can access the constant by referring to the interface name, or an implementing class, (again similar to Java) e.g.:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">Baz </span><span class="keyword">implements </span><span class="default">FooBar<br /></span><span class="keyword">{<br /><br />&nbsp; &nbsp; </span><span class="comment">//....<br /><br /></span><span class="keyword">}<br /><br />print </span><span class="default">Baz</span><span class="keyword">::</span><span class="default">SOME_CONSTANT</span><span class="keyword">;<br />print </span><span class="default">FooBar</span><span class="keyword">::</span><span class="default">SOME_CONSTANT</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;<br /></span><br />Both of the last print statements will output the same thing: the value of FooBar::SOME_CONSTANT</span>
</code></div>
  </div>
 </div>
  <div class="note" id="99381">  <div class="votes">
    <div id="Vu99381">
    <a href="/manual/vote-note.php?id=99381&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd99381">
    <a href="/manual/vote-note.php?id=99381&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V99381" title="62% like this...">
    2
    </div>
  </div>
  <a href="#99381" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#99381"> &para;</a><div class="date" title="2010-08-13 12:44"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom99381">
<div class="phpcode"><code><span class="html">
If you want to ensure implementation classes are correctly initialised (i.e. due to trickery one needs to do to work around lack of multiple inheritance), simply add&nbsp; __construct() to your interface, so risk of init being forgotten is reduced.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="106855">  <div class="votes">
    <div id="Vu106855">
    <a href="/manual/vote-note.php?id=106855&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd106855">
    <a href="/manual/vote-note.php?id=106855&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V106855" title="61% like this...">
    3
    </div>
  </div>
  <a href="#106855" class="name">
  <strong class="user"><em>julien arobase fastre point info</em></strong></a><a class="genanchor" href="#106855"> &para;</a><div class="date" title="2011-12-12 11:12"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom106855">
<div class="phpcode"><code><span class="html">
If you use namespaces and autoloading, do not forget to mention the use statement for each class used in yours arguments, before your class: <br /><br /><span class="default">&lt;?php <br /></span><span class="comment">#file : fruit/squeezable.php<br /></span><span class="keyword">namespace </span><span class="default">fruit<br /></span><span class="keyword">use </span><span class="default">Bar</span><span class="keyword">\</span><span class="default">Foo</span><span class="keyword">;<br /><br />interface </span><span class="default">squeezable </span><span class="keyword">{<br />&nbsp; public function </span><span class="default">squeeze </span><span class="keyword">(</span><span class="default">Foo $foo</span><span class="keyword">);<br />}<br /></span><span class="default">?&gt;<br /></span><br /><span class="default">&lt;?php <br /></span><span class="comment">#file: orange <br /><br /></span><span class="keyword">namespace </span><span class="default">fruit</span><span class="keyword">\</span><span class="default">citrus</span><span class="keyword">;<br /><br />class </span><span class="default">orange </span><span class="keyword">{<br />&nbsp; public function </span><span class="default">squeeze</span><span class="keyword">(</span><span class="default">Foo $foo</span><span class="keyword">);<br />}<br /></span><span class="comment">#Will throw an exception Fatal error: Declaration of "fruit\citrus\orange::squeeze must be compatible with that of fruit\squeezable() in fruit/squeezable.php<br /></span><span class="default">?&gt;<br /></span><br /><span class="default">&lt;?php <br /></span><span class="comment">#file: orange <br /><br /></span><span class="keyword">namespace </span><span class="default">fruit</span><span class="keyword">\</span><span class="default">citrus</span><span class="keyword">;<br />use </span><span class="default">Bar</span><span class="keyword">\</span><span class="default">Foo</span><span class="keyword">; </span><span class="comment">#DO NOT FORGET THIS!<br /><br /></span><span class="keyword">class </span><span class="default">orange </span><span class="keyword">{<br />&nbsp; public function </span><span class="default">squeeze </span><span class="keyword">(</span><span class="default">Foo $foo</span><span class="keyword">);<br />}<br /></span><span class="comment">#Will be correct<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="76206">  <div class="votes">
    <div id="Vu76206">
    <a href="/manual/vote-note.php?id=76206&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd76206">
    <a href="/manual/vote-note.php?id=76206&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V76206" title="62% like this...">
    2
    </div>
  </div>
  <a href="#76206" class="name">
  <strong class="user"><em>zedd at fadingtwilight dot net</em></strong></a><a class="genanchor" href="#76206"> &para;</a><div class="date" title="2007-07-04 09:42"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom76206">
<div class="phpcode"><code><span class="html">
Regarding my previous note (04-Jul-2007 9:01):<br /><br />I noticed a minor but critical mistake in my explanation. After the link to the PHP manual page on class abstraction, I stated:<br /><br />"So by definition, you may only overload non-abstract methods."<br /><br />This is incorrect. This should read:<br /><br />"So by definition, you may only override non-abstract methods."<br /><br />Sorry for any confusion.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="115273">  <div class="votes">
    <div id="Vu115273">
    <a href="/manual/vote-note.php?id=115273&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115273">
    <a href="/manual/vote-note.php?id=115273&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115273" title="60% like this...">
    2
    </div>
  </div>
  <a href="#115273" class="name">
  <strong class="user"><em>thomas tulinsky</em></strong></a><a class="genanchor" href="#115273"> &para;</a><div class="date" title="2014-06-25 09:37"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115273">
<div class="phpcode"><code><span class="html">
to dlovell2011 at yahoo dot com wrote:<br />It seems like many contributors are missing the point of using an INTERFACE. An INTERFACE is not specifically provided for abstraction. <br />...<br />An INTERFACE is provided so you can describe a set of functions and then hide the final implementation of those functions in an implementing class. This allows you to change the IMPLEMENTATION of those functions without changing how you use it. <br />--------------<br />I believe the unique thing that Interfaces provide is to support the same functions in different classes that are **not descended from a common ancestor**.&nbsp; <br />Different implementations of the same functions does not need interfaces--it can be achieved through subclasses.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="101723">  <div class="votes">
    <div id="Vu101723">
    <a href="/manual/vote-note.php?id=101723&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd101723">
    <a href="/manual/vote-note.php?id=101723&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V101723" title="60% like this...">
    2
    </div>
  </div>
  <a href="#101723" class="name">
  <strong class="user"><em>jballard at natoga dot com</em></strong></a><a class="genanchor" href="#101723"> &para;</a><div class="date" title="2011-01-06 01:33"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom101723">
<div class="phpcode"><code><span class="html">
If it isn't already obvious, you can create an object of a class above the class declaration if it does NOT implement an interface. However, when a class DOES implement an interface, PHP will throw a "class not found" error unless the instantiation declaration is _below_ the class definition.<br /><br /><span class="default">&lt;?php<br />$bar </span><span class="keyword">= new </span><span class="default">foo</span><span class="keyword">(); </span><span class="comment">// Valid<br /><br /></span><span class="keyword">class </span><span class="default">foo<br /></span><span class="keyword">{<br />&nbsp; &nbsp; <br />}<br /></span><span class="default">?&gt;<br /></span><br /><span class="default">&lt;?php<br />$bar </span><span class="keyword">= new </span><span class="default">foo</span><span class="keyword">(); </span><span class="comment">// Invalid - throws fatal error<br /><br /></span><span class="keyword">interface </span><span class="default">foo2<br /></span><span class="keyword">{<br /><br />}<br /><br />class </span><span class="default">bar </span><span class="keyword">implements </span><span class="default">foo2<br /></span><span class="keyword">{<br />&nbsp; &nbsp; <br />}<br /><br /></span><span class="default">$bar </span><span class="keyword">= new </span><span class="default">foo</span><span class="keyword">(); </span><span class="comment">// Valid, since it is below the class declaration<br /><br /></span><span class="default">?&gt;<br /></span><br />Also, @Jeffrey -- Lol? What? Is that a joke? PHP interfaces have nothing to do with connecting to "peripheral devices" or "cameras", etc. Not even in the least sense. This is a very common miscommunication with the word "interface", as interfaces in programming are not at all like interfaces in electronics or drivers, etc.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="83766">  <div class="votes">
    <div id="Vu83766">
    <a href="/manual/vote-note.php?id=83766&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd83766">
    <a href="/manual/vote-note.php?id=83766&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V83766" title="60% like this...">
    1
    </div>
  </div>
  <a href="#83766" class="name">
  <strong class="user"><em>harryjry at yahoo dot com</em></strong></a><a class="genanchor" href="#83766"> &para;</a><div class="date" title="2008-06-10 02:29"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom83766">
<div class="phpcode"><code><span class="html">
The structure I am working with has a lot of inheritance going on, but not all methods are specified in one place. I needed a way to make sure an interface would be used, but that the method(s) defined in the interface are defined somewhere.<br /><br />As such, I learned that the parent can define the interface's methods, and then the children can override that method at will without having to worry about the interface.<br /><br />To expand on nrg1981's example, the following is possible:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">interface </span><span class="default">water<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">makeItWet</span><span class="keyword">();<br />}<br /><br />class </span><span class="default">weather<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">makeItWet</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">'it may or may not be wet'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">start</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">'Here is some weather'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">rain </span><span class="keyword">extends </span><span class="default">weather </span><span class="keyword">implements </span><span class="default">water<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">makeItWet</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">'It is wet'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">thunder </span><span class="keyword">extends </span><span class="default">weather </span><span class="keyword">implements </span><span class="default">water<br /></span><span class="keyword">{<br /><br />}<br /><br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">rain</span><span class="keyword">();<br />echo </span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">start</span><span class="keyword">() . </span><span class="string">"\n"</span><span class="keyword">;<br />echo </span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">makeItWet</span><span class="keyword">() . </span><span class="string">"\n"</span><span class="keyword">;<br /><br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">thunder</span><span class="keyword">();<br />echo </span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">start</span><span class="keyword">() . </span><span class="string">"\n"</span><span class="keyword">;<br />echo </span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">makeItWet</span><span class="keyword">() . </span><span class="string">"\n"</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="72312">  <div class="votes">
    <div id="Vu72312">
    <a href="/manual/vote-note.php?id=72312&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd72312">
    <a href="/manual/vote-note.php?id=72312&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V72312" title="60% like this...">
    1
    </div>
  </div>
  <a href="#72312" class="name">
  <strong class="user"><em>Maikel</em></strong></a><a class="genanchor" href="#72312"> &para;</a><div class="date" title="2007-01-12 03:07"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom72312">
<div class="phpcode"><code><span class="html">
if you want to implement an interface and in addition to use inheritance, first it uses “extends” and then “implements” example:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">MyChildClass </span><span class="keyword">extends </span><span class="default">MyParentClass </span><span class="keyword">implements </span><span class="default">MyInterface<br /></span><span class="keyword">{<br />&nbsp;&nbsp; </span><span class="comment">// definition<br /></span><span class="keyword">}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="49218">  <div class="votes">
    <div id="Vu49218">
    <a href="/manual/vote-note.php?id=49218&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd49218">
    <a href="/manual/vote-note.php?id=49218&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V49218" title="60% like this...">
    5
    </div>
  </div>
  <a href="#49218" class="name">
  <strong class="user"><em>mat.wilmots (at) wanadoo (dot) fr</em></strong></a><a class="genanchor" href="#49218"> &para;</a><div class="date" title="2005-01-20 06:22"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom49218">
<div class="phpcode"><code><span class="html">
interfaces support multiple inheritance<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">interface </span><span class="default">SQL_Result </span><span class="keyword">extends </span><span class="default">SeekableIterator</span><span class="keyword">, </span><span class="default">Countable<br /></span><span class="keyword">{<br />&nbsp; &nbsp; </span><span class="comment">// new stuff<br /></span><span class="keyword">}<br /><br />abstract class </span><span class="default">SQL_Result_Common<br /></span><span class="keyword">{<br />&nbsp; &nbsp; </span><span class="comment">// just because that's what one would do in reality, generic implementation<br /></span><span class="keyword">}<br /><br />class </span><span class="default">SQL_Result_mysql </span><span class="keyword">extends </span><span class="default">SQL_Result_Common </span><span class="keyword">implements </span><span class="default">SQL_Result<br /></span><span class="keyword">{<br />&nbsp;&nbsp; </span><span class="comment">// actual implementation<br /></span><span class="keyword">}<br /><br /></span><span class="default">?&gt;<br /></span><br />This code raises a fatal error because SQL_Result_mysql doesn't implement the abstract methods of SeekableIterator (6) + Countable (1)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="55721">  <div class="votes">
    <div id="Vu55721">
    <a href="/manual/vote-note.php?id=55721&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd55721">
    <a href="/manual/vote-note.php?id=55721&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V55721" title="60% like this...">
    2
    </div>
  </div>
  <a href="#55721" class="name">
  <strong class="user"><em>warhog at warhog dot net</em></strong></a><a class="genanchor" href="#55721"> &para;</a><div class="date" title="2005-08-11 08:35"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom55721">
<div class="phpcode"><code><span class="html">
on the post below:<br /><br />An interface is in fact the same like an abstract class containing abstract methods, that's why interfaces share the same namespace as classes and why therefore "real" classes cannot have the same name as interfaces.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="78293">  <div class="votes">
    <div id="Vu78293">
    <a href="/manual/vote-note.php?id=78293&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd78293">
    <a href="/manual/vote-note.php?id=78293&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V78293" title="58% like this...">
    2
    </div>
  </div>
  <a href="#78293" class="name">
  <strong class="user"><em>nrg1981 {AT} hotmail {DOT} com</em></strong></a><a class="genanchor" href="#78293"> &para;</a><div class="date" title="2007-10-05 06:48"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom78293">
<div class="phpcode"><code><span class="html">
In case you would want to, a child class can implement an interface:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">interface </span><span class="default">water<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">makeItWet</span><span class="keyword">();<br />}<br /><br />class </span><span class="default">weather<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">start</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">'Here is some weather'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">rain </span><span class="keyword">extends </span><span class="default">weather </span><span class="keyword">implements </span><span class="default">water <br /></span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">makeItWet</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">'It is wet'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">rain</span><span class="keyword">();<br />echo </span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">start</span><span class="keyword">();<br />echo </span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">makeItWet</span><span class="keyword">();<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="115529">  <div class="votes">
    <div id="Vu115529">
    <a href="/manual/vote-note.php?id=115529&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115529">
    <a href="/manual/vote-note.php?id=115529&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115529" title="55% like this...">
    1
    </div>
  </div>
  <a href="#115529" class="name">
  <strong class="user"><em>williebegoode at att dot net</em></strong></a><a class="genanchor" href="#115529"> &para;</a><div class="date" title="2014-08-10 10:42"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115529">
<div class="phpcode"><code><span class="html">
In their book on Design Patterns, Erich Gamma and his associates (AKA: "The Gang of Four") use the term "interface" and "abstract class" interchangeably. In working with PHP and design patterns, the interface, while clearly a "contract" of what to include in an implementation is also a helpful guide for both re-use and making changes. As long as the implemented changes follow the interface (whether it is an interface or abstract class with abstract methods), large complex programs can be safely updated without having to re-code an entire program or module.<br /><br />In PHP coding with object interfaces (as a keyword) and "interfaces" in the more general context of use that includes both object interfaces and abstract classes, the purpose of "loose binding" (loosely bound objects) for ease of change and re-use is a helpful way to think about both uses of the&nbsp; term "interface." The focus shifts from "contractual" to "loose binding" for the purpose of cooperative development and re-use.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="112705">  <div class="votes">
    <div id="Vu112705">
    <a href="/manual/vote-note.php?id=112705&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd112705">
    <a href="/manual/vote-note.php?id=112705&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V112705" title="55% like this...">
    1
    </div>
  </div>
  <a href="#112705" class="name">
  <strong class="user"><em>Vladimir Kornea</em></strong></a><a class="genanchor" href="#112705"> &para;</a><div class="date" title="2013-07-15 10:55"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom112705">
<div class="phpcode"><code><span class="html">
By asking your colleague to implement your interface, you are asking him to guarantee that he has implemented all the methods you need. He can implement multiple interfaces, each being a contract, so that the guy cleaning the cruft down the road can see which methods belong to which area of concern; but since interfaces are primarily contracts rather than documentation, a class cannot implement two interfaces containing the same method since that would make the contract lose credibility through ambiguity. Thus a class can implement two interfaces with overlapping concerns only by factoring their common methods into a third interface that serves as a base for the first two, which resolves the contractual ambiguity.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="80202">  <div class="votes">
    <div id="Vu80202">
    <a href="/manual/vote-note.php?id=80202&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd80202">
    <a href="/manual/vote-note.php?id=80202&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V80202" title="57% like this...">
    1
    </div>
  </div>
  <a href="#80202" class="name">
  <strong class="user"><em>michael dot martinek at gmail dot com</em></strong></a><a class="genanchor" href="#80202"> &para;</a><div class="date" title="2008-01-03 08:18"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom80202">
<div class="phpcode"><code><span class="html">
In regards to what Hayley Watson is writing:<br /><br />The "interface" is a method of enforcing that anyone who implements it must include all the functions declared in the interface. This is an abstraction method, since you cannot just declare a base class and do something like "public abstract function myTest();" and later on extend that class.<br /><br />If you don't override the default value in a parameter list, it's assumed that the default value was received by time you have any control to read or relay the value on again. There should be no problem in having all or none of your parameters in an interface having a default value, as the value is "auto-filled" if not explicitly provided. <br /><br />I just came across interfaces in PHP.. but I use them quite a bit in Java and Delphi. Currently building different DB wrappers, but all must enforce common access using a base class.. and also enforce that all of specific routines are implemented.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118019">  <div class="votes">
    <div id="Vu118019">
    <a href="/manual/vote-note.php?id=118019&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118019">
    <a href="/manual/vote-note.php?id=118019&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118019" title="100% like this...">
    2
    </div>
  </div>
  <a href="#118019" class="name">
  <strong class="user"><em>naderi dot payam at gmail dot com</em></strong></a><a class="genanchor" href="#118019"> &para;</a><div class="date" title="2015-09-19 12:44"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom118019">
<div class="phpcode"><code><span class="html">
php inheritance interfaces on function/methods type declarations:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">interface </span><span class="default">iInvokable </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; function </span><span class="default">__invoke</span><span class="keyword">(</span><span class="default">$arg </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">);<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; interface </span><span class="default">iResponder </span><span class="keyword">extends </span><span class="default">iInvokable </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">/** Bind next responder */<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">function </span><span class="default">then</span><span class="keyword">(</span><span class="default">iInvokable $responder</span><span class="keyword">);<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; class </span><span class="default">Responder </span><span class="keyword">implements \</span><span class="default">iResponder </span><span class="keyword">{<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; function </span><span class="default">__invoke</span><span class="keyword">(</span><span class="default">$arg </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// TODO: Implement __invoke() method.<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">}<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">/** Bind next responder */<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">function </span><span class="default">then</span><span class="keyword">(</span><span class="default">iInvokable $responder</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// TODO: Implement then() method.<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">}<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; class </span><span class="default">OtherResponder </span><span class="keyword">implements \</span><span class="default">iResponder </span><span class="keyword">{<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; function </span><span class="default">__invoke</span><span class="keyword">(</span><span class="default">$arg </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// TODO: Implement __invoke() method.<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">}<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">/** Bind next responder */<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">function </span><span class="default">then</span><span class="keyword">(</span><span class="default">iInvokable $responder</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// TODO: Implement then() method.<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">}<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; class </span><span class="default">Invokable </span><span class="keyword">implements \</span><span class="default">iInvokable </span><span class="keyword">{<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; function </span><span class="default">__invoke</span><span class="keyword">(</span><span class="default">$arg </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// TODO: Implement __invoke() method.<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">}<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="default">$responder </span><span class="keyword">= new </span><span class="default">Responder</span><span class="keyword">();<br />&nbsp; &nbsp; </span><span class="default">$responder</span><span class="keyword">-&gt;</span><span class="default">then</span><span class="keyword">(new </span><span class="default">OtherResponder</span><span class="keyword">());<br />&nbsp; &nbsp; </span><span class="default">$responder</span><span class="keyword">-&gt;</span><span class="default">then</span><span class="keyword">(new </span><span class="default">Invokable</span><span class="keyword">());<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118153">  <div class="votes">
    <div id="Vu118153">
    <a href="/manual/vote-note.php?id=118153&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118153">
    <a href="/manual/vote-note.php?id=118153&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118153" title="no votes...">
    0
    </div>
  </div>
  <a href="#118153" class="name">
  <strong class="user"><em>naderi dot payam at gmail dot com</em></strong></a><a class="genanchor" href="#118153"> &para;</a><div class="date" title="2015-10-15 07:57"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom118153">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">interface </span><span class="default">ClassThatCanBuild<br />&nbsp; &nbsp; </span><span class="keyword">{ }<br /><br />&nbsp; &nbsp; interface </span><span class="default">SpecificClass </span><span class="keyword">extends \</span><span class="default">ClassThatCanBuild<br />&nbsp; &nbsp; </span><span class="keyword">{ }<br /><br />&nbsp; &nbsp; Class </span><span class="default">MySpecificClass </span><span class="keyword">implements \</span><span class="default">SpecificClass<br />&nbsp; &nbsp; </span><span class="keyword">{ }<br /><br />&nbsp; &nbsp; interface </span><span class="default">BuilderInterface<br />&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; function </span><span class="default">build</span><span class="keyword">(\</span><span class="default">ClassThatCanBuild $container</span><span class="keyword">);<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; function </span><span class="default">weCanHaveMethods</span><span class="keyword">();<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; interface </span><span class="default">SpecificBuilderInterface </span><span class="keyword">extends \</span><span class="default">BuilderInterface<br />&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; * (!!) this class want to allow just for build<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; *&nbsp; &nbsp; &nbsp; specific classes.<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; *&nbsp; &nbsp; &nbsp; i`m still on the rule with MySpecificClass<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; *&nbsp; &nbsp; &nbsp; because extend from ClassThatCanBuild<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; *&nbsp; &nbsp; &nbsp; but php don`t allow it at all<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; *<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; *&nbsp; &nbsp; &nbsp; "" declaration of must be compatible with<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; *&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; interface of BuilderInterface-&gt;build ""<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; *<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; * @param \MySpecificClass $container<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">function </span><span class="default">build</span><span class="keyword">(\</span><span class="default">MySpecificClass $container</span><span class="keyword">);<br />&nbsp; &nbsp; }<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116239">  <div class="votes">
    <div id="Vu116239">
    <a href="/manual/vote-note.php?id=116239&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116239">
    <a href="/manual/vote-note.php?id=116239&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116239" title="50% like this...">
    0
    </div>
  </div>
  <a href="#116239" class="name">
  <strong class="user"><em>info at abccom dot biz</em></strong></a><a class="genanchor" href="#116239"> &para;</a><div class="date" title="2014-11-28 06:25"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom116239">
<div class="phpcode"><code><span class="html">
I think interfaces ONLY help us to understand what should we do, when working on a big project not any more!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114311">  <div class="votes">
    <div id="Vu114311">
    <a href="/manual/vote-note.php?id=114311&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114311">
    <a href="/manual/vote-note.php?id=114311&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114311" title="50% like this...">
    0
    </div>
  </div>
  <a href="#114311" class="name">
  <strong class="user"><em>bombis at lacerta dot uberspace dot de</em></strong></a><a class="genanchor" href="#114311"> &para;</a><div class="date" title="2014-02-05 07:41"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114311">
<div class="phpcode"><code><span class="html">
simple example :)<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">interface </span><span class="default">testThis<br /></span><span class="keyword">{<br />public function </span><span class="default">alpha</span><span class="keyword">();<br />public function </span><span class="default">beta</span><span class="keyword">();<br />}<br /><br />trait </span><span class="default">setInterface<br /></span><span class="keyword">{<br />public&nbsp; function </span><span class="default">alpha</span><span class="keyword">()<br />{<br />echo </span><span class="default">__function__</span><span class="keyword">.</span><span class="string">" wurde implementiert"</span><span class="keyword">;<br />}<br />}<br /><br />class </span><span class="default">b<br /></span><span class="keyword">{<br />public function </span><span class="default">beta</span><span class="keyword">()<br />{<br />echo </span><span class="default">__function__</span><span class="keyword">.</span><span class="string">" wurde implementiert"</span><span class="keyword">;<br />}<br />}<br /><br />class </span><span class="default">a </span><span class="keyword">extends </span><span class="default">b </span><span class="keyword">implements </span><span class="default">testThis<br /></span><span class="keyword">{<br /><br />use </span><span class="default">setInterface</span><span class="keyword">;<br /><br /></span><span class="comment">/*<br />public&nbsp; function alpha()<br />{<br />echo __function__." wurde implementiert";<br />}<br /><br />public function beta()<br />{<br />echo __function__." wurde implementiert";<br />}<br />*/<br /><br /></span><span class="keyword">public function </span><span class="default">__construct</span><span class="keyword">()<br />{<br />echo </span><span class="string">"wat geht? &lt;br&gt;"</span><span class="keyword">;&nbsp; &nbsp; <br />}&nbsp; &nbsp; <br /><br />}<br /><br /></span><span class="default">$testInterface </span><span class="keyword">= new </span><span class="default">a</span><span class="keyword">();<br /></span><span class="default">$testInterface </span><span class="keyword">-&gt;</span><span class="default">alpha</span><span class="keyword">();<br />echo </span><span class="string">"&lt;br&gt;"</span><span class="keyword">;<br /></span><span class="default">$testInterface </span><span class="keyword">-&gt;</span><span class="default">beta</span><span class="keyword">();<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="91265">  <div class="votes">
    <div id="Vu91265">
    <a href="/manual/vote-note.php?id=91265&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd91265">
    <a href="/manual/vote-note.php?id=91265&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V91265" title="50% like this...">
    0
    </div>
  </div>
  <a href="#91265" class="name">
  <strong class="user"><em>rskret at ranphilit dot com</em></strong></a><a class="genanchor" href="#91265"> &para;</a><div class="date" title="2009-06-02 02:47"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom91265">
<div class="phpcode"><code><span class="html">
This may help understand EX.2. Below are modifiers and additions to<br />the code. Refer to EX.2 to make a complete code block(this saves comment<br />space!).<br />I found the function definition baz(Baz $baz) baffling. Lucky was <br />able to sus it out fast. Seems method baz requires just one arg and <br />that must be an instance of the class Baz. Here is a way to know how to <br />deal with that sort of arg...<br /><span class="default">&lt;?php<br /></span><span class="comment"># modify iface b...adding $num to get better understanding<br /></span><span class="keyword">interface </span><span class="default">b </span><span class="keyword">extends </span><span class="default">a<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">baz</span><span class="keyword">(</span><span class="default">Baz $baz</span><span class="keyword">,</span><span class="default">$num</span><span class="keyword">);<br />}<br /></span><span class="comment"># mod claas c <br /></span><span class="keyword">class </span><span class="default">c </span><span class="keyword">implements </span><span class="default">b<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">foo</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo</span><span class="string">'foo from class c'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public function </span><span class="default">baz</span><span class="keyword">(</span><span class="default">Baz $baz</span><span class="keyword">,</span><span class="default">$num</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">var_dump </span><span class="keyword">(</span><span class="default">$baz</span><span class="keyword">);</span><span class="comment"># object(Baz)#2 (1) { ["bb"]=&gt;&nbsp; string(3) "hot" }<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">echo </span><span class="string">'&lt;br&gt;'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">$baz</span><span class="keyword">-&gt;</span><span class="default">bb</span><span class="keyword">.</span><span class="string">" </span><span class="default">$num</span><span class="string">"</span><span class="keyword">;echo </span><span class="string">'&lt;br&gt;'</span><span class="keyword">;</span><span class="comment"># hot 6<br />&nbsp; &nbsp; </span><span class="keyword">}<br />}<br /></span><span class="comment"># add a class Baz...<br /></span><span class="keyword">class </span><span class="default">Baz<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$bb</span><span class="keyword">=</span><span class="string">'hot'</span><span class="keyword">;<br />&nbsp; &nbsp; function </span><span class="default">ebaz</span><span class="keyword">(){&nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; echo</span><span class="string">'this is BAZ'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="comment"># set instance of Baz and get some output...<br /></span><span class="default">$bazI</span><span class="keyword">=new </span><span class="default">Baz</span><span class="keyword">;<br /></span><span class="default">baz</span><span class="keyword">::</span><span class="default">ebaz</span><span class="keyword">();echo </span><span class="string">'&lt;br&gt;'</span><span class="keyword">;</span><span class="comment"># this is BAZ<br /></span><span class="default">c</span><span class="keyword">::</span><span class="default">baz</span><span class="keyword">(</span><span class="default">$bazI</span><span class="keyword">,</span><span class="default">6</span><span class="keyword">);<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="85859">  <div class="votes">
    <div id="Vu85859">
    <a href="/manual/vote-note.php?id=85859&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd85859">
    <a href="/manual/vote-note.php?id=85859&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V85859" title="50% like this...">
    0
    </div>
  </div>
  <a href="#85859" class="name">
  <strong class="user"><em>cretz</em></strong></a><a class="genanchor" href="#85859"> &para;</a><div class="date" title="2008-09-21 03:49"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom85859">
<div class="phpcode"><code><span class="html">
FYI, interfaces can define constructors, destructors, and magic methods. This can be very helpful especially in the case of constructors when instantiating an implementing class via reflection in some sort of factory. Of course, it is not recommended to do such a thing since it goes against the nature of a true interface.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="76205">  <div class="votes">
    <div id="Vu76205">
    <a href="/manual/vote-note.php?id=76205&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd76205">
    <a href="/manual/vote-note.php?id=76205&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V76205" title="50% like this...">
    0
    </div>
  </div>
  <a href="#76205" class="name">
  <strong class="user"><em>zedd at fadingtwilight dot net</em></strong></a><a class="genanchor" href="#76205"> &para;</a><div class="date" title="2007-07-04 09:01"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom76205">
<div class="phpcode"><code><span class="html">
prometheus at php-sparcle:<br /><br />Your code fails because you're effectively trying to do this:<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">abstract class </span><span class="default">IFoo<br />&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; abstract public function </span><span class="default">Foo</span><span class="keyword">();<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; abstract class </span><span class="default">IBar </span><span class="keyword">extends </span><span class="default">IFoo<br />&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Fails; abstract method IFoo::Foo() must be defined in child and must match parent's definition<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">abstract public function </span><span class="default">Foo</span><span class="keyword">(</span><span class="default">$bar</span><span class="keyword">);<br />&nbsp; &nbsp; }<br /></span><span class="default">?&gt;<br /></span><br />By definition, all methods in an interface are abstract. So the above code segment is equivalent to your interface definitions and results in the same error. Why? Let's have a look at the PHP manual. From the second paragraph on class abstraction:<br /><br />"When inheriting from an abstract class, all methods marked abstract in the parent's class declaration must be defined by the child;"<br /><br /><a href="http://www.php.net/manual/en/language.oop5.abstract.php" rel="nofollow" target="_blank">http://www.php.net/manual/en/language.oop5.abstract.php</a><br /><br />So by definition, you may only overload non-abstract methods.<br /><br />For example:<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">abstract class </span><span class="default">IFoo<br />&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; public function </span><span class="default">Foo</span><span class="keyword">()<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// do something...<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">}<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; abstract class </span><span class="default">IBar </span><span class="keyword">extends </span><span class="default">IFoo<br />&nbsp; &nbsp; </span><span class="keyword">{&nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; public function </span><span class="default">Foo</span><span class="keyword">(</span><span class="default">$bar</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// do something else...<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">}<br />&nbsp; &nbsp; }<br /></span><span class="default">?&gt;<br /></span><br />This can't be directly replicated with interfaces since you can't implement methods inside of an interface. They can only be implemented in a class or an abstract class.<br /><br />If you must use interfaces, the following accomplishes the same thing, but with two separate method names:<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">interface </span><span class="default">IFoo<br />&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; public function </span><span class="default">Foo</span><span class="keyword">();<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; interface </span><span class="default">IBar </span><span class="keyword">extends </span><span class="default">IFoo<br />&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; public function </span><span class="default">Bar</span><span class="keyword">(</span><span class="default">$bar</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; class </span><span class="default">FooBar </span><span class="keyword">implements </span><span class="default">IBar<br />&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; public function </span><span class="default">Foo</span><span class="keyword">()<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// do something...<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">}<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; public function </span><span class="default">Bar</span><span class="keyword">(</span><span class="default">$bar</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// do something else...<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">}<br />&nbsp; &nbsp; }<br /></span><span class="default">?&gt;<br /></span><br />If both methods need the same name, then you'll have to use non-abstract methods. In this case, interfaces aren't the right tool for the job. You'll want to use abstract classes (or just regular classes).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="57866">  <div class="votes">
    <div id="Vu57866">
    <a href="/manual/vote-note.php?id=57866&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd57866">
    <a href="/manual/vote-note.php?id=57866&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V57866" title="50% like this...">
    0
    </div>
  </div>
  <a href="#57866" class="name">
  <strong class="user"><em>cyrille.berliat[no spam]free.fr</em></strong></a><a class="genanchor" href="#57866"> &para;</a><div class="date" title="2005-10-17 02:29"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom57866">
<div class="phpcode"><code><span class="html">
Interfaces and Type Hinting can be used but not with Inherintance in the same time :<br /><br />&lt;?<br /><br />class AbstractClass<br />{<br />&nbsp; &nbsp; public function __ToString ( ) { return 'Here I\'m I'; }<br />}<br /><br />class DescendantClass extends AbstractClass<br />{<br /><br />}<br /><br />interface MyI<br />{<br />&nbsp; &nbsp; public function Hello ( AbstractClass $obj );<br />}<br /><br />class MyClassOne implements MyI<br />{<br />&nbsp; &nbsp; public function Hello ( AbstractClass $obj ) <br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo $obj;<br />&nbsp; &nbsp; }<br />} // Will work as Interface Satisfied<br /><br />class MyClassTwo implements MyI<br />{<br />&nbsp; &nbsp; public function Hello ( DescendantClass $obj ) <br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo $obj;<br />&nbsp; &nbsp; }<br />} // Will output a fatal error because Interfaces don't support Inherintance in TypeHinting<br /><br />//Fatal error: Declaration of MyClassTwo::hello() must be compatible with that of MyI::hello()<br /><br />?&gt;<br /><br />Something a little bit bad in PHP 5.0.4 :)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="55237">  <div class="votes">
    <div id="Vu55237">
    <a href="/manual/vote-note.php?id=55237&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd55237">
    <a href="/manual/vote-note.php?id=55237&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V55237" title="50% like this...">
    0
    </div>
  </div>
  <a href="#55237" class="name">
  <strong class="user"><em>marcus at synchromedia dot co dot uk</em></strong></a><a class="genanchor" href="#55237"> &para;</a><div class="date" title="2005-07-28 04:11"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom55237">
<div class="phpcode"><code><span class="html">
Classes and interface names share a common name space, so you can't have a class and an interface with the same name, even though the two can never be used ambiguously (i.e. there are no circumstances in which a class and an interface can be used interchangeably). e.g. this will not work:<br /><br />interface foo {<br />public function bling();<br />}<br /><br />class foo implements foo {<br />public function bling() {<br />}<br />}<br /><br />You will get a 'Cannot redeclare class' error, even though it's only been declared as a class once.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="79110">  <div class="votes">
    <div id="Vu79110">
    <a href="/manual/vote-note.php?id=79110&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd79110">
    <a href="/manual/vote-note.php?id=79110&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V79110" title="40% like this...">
    -1
    </div>
  </div>
  <a href="#79110" class="name">
  <strong class="user"><em>Docey</em></strong></a><a class="genanchor" href="#79110"> &para;</a><div class="date" title="2007-11-11 03:23"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom79110">
<div class="phpcode"><code><span class="html">
Another note about default values in interfaces is that an class must implement at least the arguments as in the interface. that is: an implementation may have more arguments but not less if these additional arguments have an default value and thus can be called as declared in the interface.<br /><br />an litte example:<br /><span class="default">&lt;?php<br /></span><span class="keyword">interface </span><span class="default">myInterface</span><span class="keyword">{<br />&nbsp; public function </span><span class="default">setStuff</span><span class="keyword">(</span><span class="default">$id</span><span class="keyword">, </span><span class="default">$name</span><span class="keyword">);<br />}<br /><br />class </span><span class="default">MyFirstClass </span><span class="keyword">implements </span><span class="default">myInterface</span><span class="keyword">{<br />&nbsp; public function </span><span class="default">setStuff</span><span class="keyword">(</span><span class="default">$id</span><span class="keyword">, </span><span class="default">$name</span><span class="keyword">);<br />}<br /><br />class </span><span class="default">MySecondClass </span><span class="keyword">implements </span><span class="default">myInterface</span><span class="keyword">{<br /> public function </span><span class="default">setStuff</span><span class="keyword">(</span><span class="default">$id</span><span class="keyword">, </span><span class="default">$name</span><span class="keyword">, </span><span class="default">$type</span><span class="keyword">); <br />}<br /><br />class </span><span class="default">myThirdClass </span><span class="keyword">implements </span><span class="default">myInterface</span><span class="keyword">{<br /> public function </span><span class="default">setStuff</span><span class="keyword">(</span><span class="default">$id</span><span class="keyword">, </span><span class="default">$name</span><span class="keyword">, </span><span class="default">$type</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">);<br />}<br /></span><span class="default">?&gt;<br /></span><br />Here mySecondClass will print an fatal error while myThirdClass is just fine because myThirdClass::setStuff($id, $name); is valid and thus fullfills the interface requirements. an interface declares as set of requirement on how methods can be called and any class implementing an interface thus agrees that is will provide these methods and that they can be called as in the interface. adding additional arguments with default values is thus allowed because it does not violate the agreement that the method can be called as in the interface.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="68773">  <div class="votes">
    <div id="Vu68773">
    <a href="/manual/vote-note.php?id=68773&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd68773">
    <a href="/manual/vote-note.php?id=68773&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V68773" title="33% like this...">
    -2
    </div>
  </div>
  <a href="#68773" class="name">
  <strong class="user"><em>vbolshov at rbc dot ru</em></strong></a><a class="genanchor" href="#68773"> &para;</a><div class="date" title="2006-08-10 02:34"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom68773">
<div class="phpcode"><code><span class="html">
Consider the following:<br />[vbolshov@localhost tmp]$ cat t.php<br /><span class="default">&lt;?php<br /><br />error_reporting</span><span class="keyword">(</span><span class="default">E_ALL </span><span class="keyword">| </span><span class="default">E_STRICT</span><span class="keyword">);<br /><br />interface </span><span class="default">i </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; function </span><span class="default">f</span><span class="keyword">(</span><span class="default">$arg</span><span class="keyword">);<br />}<br />class </span><span class="default">c </span><span class="keyword">implements </span><span class="default">i </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; function </span><span class="default">f</span><span class="keyword">(</span><span class="default">$arg</span><span class="keyword">, </span><span class="default">$arg2 </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span>[vbolshov@localhost tmp]$ php t.php<br />[vbolshov@localhost tmp]$<br /><br />PHP doesn't generate a Fatal Error in this case, although the method declaration in the class differs from that in the interface. This situation doesn't seem good to me: I'd prefer classes being strictly bound to their interfaces.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="85738">  <div class="votes">
    <div id="Vu85738">
    <a href="/manual/vote-note.php?id=85738&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd85738">
    <a href="/manual/vote-note.php?id=85738&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V85738" title="28% like this...">
    -3
    </div>
  </div>
  <a href="#85738" class="name">
  <strong class="user"><em>lazybones_senior</em></strong></a><a class="genanchor" href="#85738"> &para;</a><div class="date" title="2008-09-15 10:41"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom85738">
<div class="phpcode"><code><span class="html">
WHOA! KEEP IT SIMPLE...<br /><br />With the code below, you already get a feel at how much ground this app might cover.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">interface </span><span class="default">ElectricalDevice</span><span class="keyword">{<br />&nbsp; public function </span><span class="default">power_on</span><span class="keyword">();<br />&nbsp; public function </span><span class="default">power_off</span><span class="keyword">();<br />}<br /><br />interface </span><span class="default">FrequencyTuner</span><span class="keyword">{<br />&nbsp; public function </span><span class="default">get_frequencey</span><span class="keyword">();<br />&nbsp; public function </span><span class="default">set_frequency</span><span class="keyword">(</span><span class="default">$f</span><span class="keyword">);<br />}<br /><br />class </span><span class="default">ElectricFan </span><span class="keyword">implements </span><span class="default">ElectricalDevice</span><span class="keyword">{<br />&nbsp; </span><span class="comment">// define ElectricalDevice...<br /></span><span class="keyword">}<br /><br />class </span><span class="default">MicrowaveOven </span><span class="keyword">implements </span><span class="default">ElectricalDevice</span><span class="keyword">{<br />&nbsp; </span><span class="comment">// define ElectricalDevice...<br /></span><span class="keyword">}<br /><br />class </span><span class="default">StereoReceiver </span><span class="keyword">implements </span><span class="default">ElectricalDevice</span><span class="keyword">, </span><span class="default">FrequencyTuner</span><span class="keyword">{<br />&nbsp; </span><span class="comment">// define ElectricalDevice...<br />&nbsp; // define FrequencyTuner...<br /></span><span class="keyword">}<br /><br />class </span><span class="default">CellPhone </span><span class="keyword">implements </span><span class="default">ElectricalDevice</span><span class="keyword">, </span><span class="default">FrequencyTuner</span><span class="keyword">{<br />&nbsp; </span><span class="comment">// define ElectricalDevice...<br />&nbsp; // define FrequencyTuner...<br /></span><span class="keyword">}<br /><br /></span><span class="default">?&gt;<br /></span><br />Even those who lack imagination can fill in the blanks from here.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="84537">  <div class="votes">
    <div id="Vu84537">
    <a href="/manual/vote-note.php?id=84537&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd84537">
    <a href="/manual/vote-note.php?id=84537&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V84537" title="23% like this...">
    -7
    </div>
  </div>
  <a href="#84537" class="name">
  <strong class="user"><em>logik at centrum dot cz</em></strong></a><a class="genanchor" href="#84537"> &para;</a><div class="date" title="2008-07-17 02:17"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom84537">
<div class="phpcode"><code><span class="html">
Makes them useles a bit. I give an example:<br />I have a class that enumerate (so implements iterator) a interface that has method key() that returns key for the enumerated object.<br />I cannot implement iterator, that enumerates the objects by itself (so current() returns this), because of collision of method key(). But it's not collision - the key in the iterator and the key in the enumerated object has the same meaning and allways returns same values. <br />(Common example of this iterator is iterator, that reads from database - make a special object for each row is waste of time).<br /><br />Yes - there are workarounds - e.g. rewrite the code so current don't return this - but it's in some cases waste of processor time. <br />Or I can rename the method key in enumerated object - but why should I wrote the same method twice? It's either waste of time (if the function key is simply duplicated) or waste of time (if the renamed key calls original key).<br />Well, the right, clear way there would be to redefine interface iterator -- move the method key to the ancestor of iterator, and makes the ancestor ancestor of enumerated interface too. But it's (with built-in interfaces) impossible too.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="58147">  <div class="votes">
    <div id="Vu58147">
    <a href="/manual/vote-note.php?id=58147&amp;page=language.oop5.interfaces&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd58147">
    <a href="/manual/vote-note.php?id=58147&amp;page=language.oop5.interfaces&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V58147" title="18% like this...">
    -10
    </div>
  </div>
  <a href="#58147" class="name">
  <strong class="user"><em>spiritus.canis at gmail dot com</em></strong></a><a class="genanchor" href="#58147"> &para;</a><div class="date" title="2005-10-25 10:45"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom58147">
<div class="phpcode"><code><span class="html">
Regarding the example by cyrille.berliat:<br /><br />This is not a problem and is consistent with other languages.&nbsp; You'd just want to use inheritance like so:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">AbstractClass </span><span class="keyword">{<br />&nbsp;&nbsp; public function </span><span class="default">__ToString </span><span class="keyword">( ) { return </span><span class="string">'Here I am'</span><span class="keyword">; }<br />}<br /><br />class </span><span class="default">DescendantClass </span><span class="keyword">extends </span><span class="default">AbstractClass </span><span class="keyword">{}<br /><br />interface </span><span class="default">MyInterface </span><span class="keyword">{<br />&nbsp;&nbsp; public function </span><span class="default">Hello </span><span class="keyword">( </span><span class="default">AbstractClass $obj </span><span class="keyword">);<br />}<br /><br />class </span><span class="default">MyClassOne </span><span class="keyword">implements </span><span class="default">MyInterface </span><span class="keyword">{<br /><br />&nbsp;&nbsp; public function </span><span class="default">Hello </span><span class="keyword">( </span><span class="default">AbstractClass $obj </span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp;&nbsp; echo </span><span class="default">$obj</span><span class="keyword">;<br />&nbsp;&nbsp; }<br />} </span><span class="comment">// Will work as Interface Satisfied<br /><br /></span><span class="default">$myDC </span><span class="keyword">= new </span><span class="default">DescendantClass</span><span class="keyword">() ;<br /></span><span class="default">MyClassOne</span><span class="keyword">::</span><span class="default">Hello</span><span class="keyword">( </span><span class="default">$myDC </span><span class="keyword">) ;<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.oop5.interfaces&amp;redirect=http://php.net/manual/en/language.oop5.interfaces.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.oop5.php">Classes and Objects</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="oop5.intro.php" title="Introduction">Introduction</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.basic.php" title="The Basics">The Basics</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.properties.php" title="Properties">Properties</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.constants.php" title="Class Constants">Class Constants</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.autoload.php" title="Autoloading Classes">Autoloading Classes</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.decon.php" title="Constructors and Destructors">Constructors and Destructors</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.visibility.php" title="Visibility">Visibility</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.inheritance.php" title="Object Inheritance">Object Inheritance</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.paamayim-nekudotayim.php" title="Scope Resolution Operator (::)">Scope Resolution Operator (::)</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.static.php" title="Static Keyword">Static Keyword</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.abstract.php" title="Class Abstraction">Class Abstraction</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.oop5.interfaces.php" title="Object Interfaces">Object Interfaces</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.traits.php" title="Traits">Traits</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.anonymous.php" title="Anonymous classes">Anonymous classes</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.overloading.php" title="Overloading">Overloading</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.iterations.php" title="Object Iteration">Object Iteration</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.magic.php" title="Magic Methods">Magic Methods</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.final.php" title="Final Keyword">Final Keyword</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.cloning.php" title="Object Cloning">Object Cloning</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.object-comparison.php" title="Comparing Objects">Comparing Objects</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.typehinting.php" title="Type Hinting">Type Hinting</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.late-static-bindings.php" title="Late Static Bindings">Late Static Bindings</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.references.php" title="Objects and references">Objects and references</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.serialization.php" title="Object Serialization">Object Serialization</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.changelog.php" title="OOP Changelog">OOP Changelog</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

