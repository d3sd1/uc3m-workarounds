<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Command line usage - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/features.commandline.php">
 <link rel="shorturl" href="http://php.net/commandline">
 <link rel="alternate" href="http://php.net/commandline" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/features.php">
 <link rel="prev" href="http://php.net/manual/en/features.safe-mode.functions.php">
 <link rel="next" href="http://php.net/manual/en/features.commandline.introduction.php">

 <link rel="alternate" href="http://php.net/manual/en/features.commandline.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/features.commandline.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/features.commandline.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/features.commandline.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/features.commandline.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/features.commandline.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/features.commandline.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/features.commandline.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/features.commandline.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/features.commandline.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/features.commandline.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="features.commandline.introduction.php">
          Introduction &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="features.safe-mode.functions.php">
          &laquo; Functions restricted/disabled by safe mode        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='features.php'>Features</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/features.commandline.php' selected="selected">English</option>
            <option value='pt_BR/features.commandline.php'>Brazilian Portuguese</option>
            <option value='zh/features.commandline.php'>Chinese (Simplified)</option>
            <option value='fr/features.commandline.php'>French</option>
            <option value='de/features.commandline.php'>German</option>
            <option value='ja/features.commandline.php'>Japanese</option>
            <option value='ro/features.commandline.php'>Romanian</option>
            <option value='ru/features.commandline.php'>Russian</option>
            <option value='es/features.commandline.php'>Spanish</option>
            <option value='tr/features.commandline.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/features.commandline.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=features.commandline">Report a Bug</a>
    </div>
  </div><div id="features.commandline" class="chapter">
 <h1>Using PHP from the command line</h1>
<h2>Table of Contents</h2><ul class="chunklist chunklist_chapter"><li><a href="features.commandline.introduction.php">Introduction</a></li><li><a href="features.commandline.differences.php">Differences to other SAPIs</a></li><li><a href="features.commandline.options.php">Options</a></li><li><a href="features.commandline.usage.php">Usage</a></li><li><a href="features.commandline.io-streams.php">I/O streams</a></li><li><a href="features.commandline.interactive.php">Interactive shell</a></li><li><a href="features.commandline.webserver.php">Built-in web server</a></li><li><a href="features.commandline.ini.php">INI settings</a></li></ul>

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

 
 
 

 
 
 

  
  
</div>

<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=features.commandline&amp;redirect=http://php.net/manual/en/features.commandline.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">53 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="108883">  <div class="votes">
    <div id="Vu108883">
    <a href="/manual/vote-note.php?id=108883&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd108883">
    <a href="/manual/vote-note.php?id=108883&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V108883" title="60% like this...">
    106
    </div>
  </div>
  <a href="#108883" class="name">
  <strong class="user"><em>sep16 at psu dot edu</em></strong></a><a class="genanchor" href="#108883"> &para;</a><div class="date" title="2012-06-01 01:17"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom108883">
<div class="phpcode"><code><span class="html">
You can easily parse command line arguments into the $_GET variable by using the parse_str() function.<br /><br /><span class="default">&lt;?php<br /><br />parse_str</span><span class="keyword">(</span><span class="default">implode</span><span class="keyword">(</span><span class="string">'&amp;'</span><span class="keyword">, </span><span class="default">array_slice</span><span class="keyword">(</span><span class="default">$argv</span><span class="keyword">, </span><span class="default">1</span><span class="keyword">)), </span><span class="default">$_GET</span><span class="keyword">);<br /><br /></span><span class="default">?&gt;<br /></span><br />It behaves exactly like you'd expect with cgi-php.<br /><br />$ php -f somefile.php a=1 b[]=2 b[]=3<br /><br />This will set $_GET['a'] to '1' and $_GET['b'] to array('2', '3').<br /><br />Even better, instead of putting that line in every file, take advantage of PHP's auto_prepend_file directive.&nbsp; Put that line in its own file and set the auto_prepend_file directive in your cli-specific php.ini like so:<br /><br />auto_prepend_file = "/etc/php/cli-php5.3/local.prepend.php"<br /><br />It will be automatically prepended to any PHP file run from the command line.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="39655">  <div class="votes">
    <div id="Vu39655">
    <a href="/manual/vote-note.php?id=39655&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd39655">
    <a href="/manual/vote-note.php?id=39655&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V39655" title="66% like this...">
    7
    </div>
  </div>
  <a href="#39655" class="name">
  <strong class="user"><em>linn at backendmedia dot com</em></strong></a><a class="genanchor" href="#39655"> &para;</a><div class="date" title="2004-02-06 06:12"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom39655">
<div class="phpcode"><code><span class="html">
For those of you who want the old CGI behaviour that changes to the actual directory of the script use:<br />chdir(dirname($_SERVER['argv'][0]));<br /><br />at the beginning of your scripts.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="62162">  <div class="votes">
    <div id="Vu62162">
    <a href="/manual/vote-note.php?id=62162&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd62162">
    <a href="/manual/vote-note.php?id=62162&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V62162" title="62% like this...">
    12
    </div>
  </div>
  <a href="#62162" class="name">
  <strong class="user"><em>stromdotcom at hotmail dot com</em></strong></a><a class="genanchor" href="#62162"> &para;</a><div class="date" title="2006-02-21 10:27"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom62162">
<div class="phpcode"><code><span class="html">
Spawning php-win.exe as a child process to handle scripting in Windows applications has a few quirks (all having to do with pipes between Windows apps and console apps).<br /><br />To do this in C++:<br /><br />// We will run php.exe as a child process after creating<br />// two pipes and attaching them to stdin and stdout<br />// of the child process<br />// Define sa struct such that child inherits our handles<br /><br />SECURITY_ATTRIBUTES sa = { sizeof(SECURITY_ATTRIBUTES) };<br />sa.bInheritHandle = TRUE;<br />sa.lpSecurityDescriptor = NULL;<br /><br />// Create the handles for our two pipes (two handles per pipe, one for each end)<br />// We will have one pipe for stdin, and one for stdout, each with a READ and WRITE end<br />HANDLE hStdoutRd, hStdoutWr, hStdinRd, hStdinWr;<br /><br />// Now create the pipes, and make them inheritable<br />CreatePipe (&amp;hStdoutRd, &amp;hStdoutWr, &amp;sa, 0))<br />SetHandleInformation(hStdoutRd, HANDLE_FLAG_INHERIT, 0);<br />CreatePipe (&amp;hStdinRd, &amp;hStdinWr, &amp;sa, 0)<br />SetHandleInformation(hStdinWr, HANDLE_FLAG_INHERIT, 0);<br /><br />// Now we have two pipes, we can create the process<br />// First, fill out the usage structs<br />STARTUPINFO si = { sizeof(STARTUPINFO) };<br />PROCESS_INFORMATION pi;<br />si.dwFlags = STARTF_USESTDHANDLES;<br />si.hStdOutput = hStdoutWr;<br />si.hStdInput&nbsp; = hStdinRd;<br /><br />// And finally, create the process<br />CreateProcess (NULL, "c:\\php\\php-win.exe", NULL, NULL, TRUE, NORMAL_PRIORITY_CLASS, NULL, NULL, &amp;si, &amp;pi);<br /><br />// Close the handles we aren't using<br />CloseHandle(hStdoutWr);<br />CloseHandle(hStdinRd);<br /><br />// Now that we have the process running, we can start pushing PHP at it<br />WriteFile(hStdinWr, "<span class="default">&lt;?php </span><span class="keyword">echo </span><span class="string">'test'</span><span class="keyword">; </span><span class="default">?&gt;</span>", 9, &amp;dwWritten, NULL);<br /><br />// When we're done writing to stdin, we close that pipe<br />CloseHandle(hStdinWr);<br /><br />// Reading from stdout is only slightly more complicated<br />int i;<br /><br />std::string processed("");<br />char buf[128];<br /><br />while ( (ReadFile(hStdoutRd, buf, 128, &amp;dwRead, NULL) &amp;&amp; (dwRead != 0)) ) {<br />&nbsp; &nbsp; for (i = 0; i &lt; dwRead; i++)<br />&nbsp; &nbsp; &nbsp; &nbsp; processed += buf[i];<br />}&nbsp; &nbsp; <br /><br />// Done reading, so close this handle too<br />CloseHandle(hStdoutRd);<br /><br />A full implementation (implemented as a C++ class) is available at <a href="http://www.stromcode.com" rel="nofollow" target="_blank">http://www.stromcode.com</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="83843">  <div class="votes">
    <div id="Vu83843">
    <a href="/manual/vote-note.php?id=83843&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd83843">
    <a href="/manual/vote-note.php?id=83843&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V83843" title="57% like this...">
    12
    </div>
  </div>
  <a href="#83843" class="name">
  <strong class="user"><em>thomas dot harding at laposte dot net</em></strong></a><a class="genanchor" href="#83843"> &para;</a><div class="date" title="2008-06-14 03:08"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom83843">
<div class="phpcode"><code><span class="html">
Parsing command line: optimization is evil!<br /><br />One thing all contributors on this page forgotten is that you can suround an argv with single or double quotes. So the join coupled together with the preg_match_all will always break that :)<br /><br />Here is a proposal:<br /><br />#!/usr/bin/php<br /><span class="default">&lt;?php<br />print_r</span><span class="keyword">(</span><span class="default">arguments</span><span class="keyword">(</span><span class="default">$argv</span><span class="keyword">));<br /><br />function </span><span class="default">arguments </span><span class="keyword">( </span><span class="default">$args </span><span class="keyword">)<br />{<br />&nbsp; </span><span class="default">array_shift</span><span class="keyword">( </span><span class="default">$args </span><span class="keyword">);<br />&nbsp; </span><span class="default">$endofoptions </span><span class="keyword">= </span><span class="default">false</span><span class="keyword">;<br /><br />&nbsp; </span><span class="default">$ret </span><span class="keyword">= array<br />&nbsp; &nbsp; (<br />&nbsp; &nbsp; </span><span class="string">'commands' </span><span class="keyword">=&gt; array(),<br />&nbsp; &nbsp; </span><span class="string">'options' </span><span class="keyword">=&gt; array(),<br />&nbsp; &nbsp; </span><span class="string">'flags'&nbsp; &nbsp; </span><span class="keyword">=&gt; array(),<br />&nbsp; &nbsp; </span><span class="string">'arguments' </span><span class="keyword">=&gt; array(),<br />&nbsp; &nbsp; );<br /><br />&nbsp; while ( </span><span class="default">$arg </span><span class="keyword">= </span><span class="default">array_shift</span><span class="keyword">(</span><span class="default">$args</span><span class="keyword">) )<br />&nbsp; {<br /><br />&nbsp; &nbsp; </span><span class="comment">// if we have reached end of options,<br />&nbsp; &nbsp; //we cast all remaining argvs as arguments<br />&nbsp; &nbsp; </span><span class="keyword">if (</span><span class="default">$endofoptions</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$ret</span><span class="keyword">[</span><span class="string">'arguments'</span><span class="keyword">][] = </span><span class="default">$arg</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; continue;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">// Is it a command? (prefixed with --)<br />&nbsp; &nbsp; </span><span class="keyword">if ( </span><span class="default">substr</span><span class="keyword">( </span><span class="default">$arg</span><span class="keyword">, </span><span class="default">0</span><span class="keyword">, </span><span class="default">2 </span><span class="keyword">) === </span><span class="string">'--' </span><span class="keyword">)<br />&nbsp; &nbsp; {<br /><br />&nbsp; &nbsp; &nbsp; </span><span class="comment">// is it the end of options flag?<br />&nbsp; &nbsp; &nbsp; </span><span class="keyword">if (!isset (</span><span class="default">$arg</span><span class="keyword">[</span><span class="default">3</span><span class="keyword">]))<br />&nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$endofoptions </span><span class="keyword">= </span><span class="default">true</span><span class="keyword">;; </span><span class="comment">// end of options;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">continue;<br />&nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; </span><span class="default">$value </span><span class="keyword">= </span><span class="string">""</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$com&nbsp;&nbsp; </span><span class="keyword">= </span><span class="default">substr</span><span class="keyword">( </span><span class="default">$arg</span><span class="keyword">, </span><span class="default">2 </span><span class="keyword">);<br /><br />&nbsp; &nbsp; &nbsp; </span><span class="comment">// is it the syntax '--option=argument'?<br />&nbsp; &nbsp; &nbsp; </span><span class="keyword">if (</span><span class="default">strpos</span><span class="keyword">(</span><span class="default">$com</span><span class="keyword">,</span><span class="string">'='</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; list(</span><span class="default">$com</span><span class="keyword">,</span><span class="default">$value</span><span class="keyword">) = </span><span class="default">split</span><span class="keyword">(</span><span class="string">"="</span><span class="keyword">,</span><span class="default">$com</span><span class="keyword">,</span><span class="default">2</span><span class="keyword">);<br /><br />&nbsp; &nbsp; &nbsp; </span><span class="comment">// is the option not followed by another option but by arguments<br />&nbsp; &nbsp; &nbsp; </span><span class="keyword">elseif (</span><span class="default">strpos</span><span class="keyword">(</span><span class="default">$args</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">],</span><span class="string">'-'</span><span class="keyword">) !== </span><span class="default">0</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; while (</span><span class="default">strpos</span><span class="keyword">(</span><span class="default">$args</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">],</span><span class="string">'-'</span><span class="keyword">) !== </span><span class="default">0</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$value </span><span class="keyword">.= </span><span class="default">array_shift</span><span class="keyword">(</span><span class="default">$args</span><span class="keyword">).</span><span class="string">' '</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$value </span><span class="keyword">= </span><span class="default">rtrim</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">,</span><span class="string">' '</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; </span><span class="default">$ret</span><span class="keyword">[</span><span class="string">'options'</span><span class="keyword">][</span><span class="default">$com</span><span class="keyword">] = !empty(</span><span class="default">$value</span><span class="keyword">) ? </span><span class="default">$value </span><span class="keyword">: </span><span class="default">true</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; continue;<br /><br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">// Is it a flag or a serial of flags? (prefixed with -)<br />&nbsp; &nbsp; </span><span class="keyword">if ( </span><span class="default">substr</span><span class="keyword">( </span><span class="default">$arg</span><span class="keyword">, </span><span class="default">0</span><span class="keyword">, </span><span class="default">1 </span><span class="keyword">) === </span><span class="string">'-' </span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; for (</span><span class="default">$i </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">; isset(</span><span class="default">$arg</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">]) ; </span><span class="default">$i</span><span class="keyword">++)<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$ret</span><span class="keyword">[</span><span class="string">'flags'</span><span class="keyword">][] = </span><span class="default">$arg</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; continue;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">// finally, it is not option, nor flag, nor argument<br />&nbsp; &nbsp; </span><span class="default">$ret</span><span class="keyword">[</span><span class="string">'commands'</span><span class="keyword">][] = </span><span class="default">$arg</span><span class="keyword">;<br />&nbsp; &nbsp; continue;<br />&nbsp; }<br /><br />&nbsp; if (!</span><span class="default">count</span><span class="keyword">(</span><span class="default">$ret</span><span class="keyword">[</span><span class="string">'options'</span><span class="keyword">]) &amp;&amp; !</span><span class="default">count</span><span class="keyword">(</span><span class="default">$ret</span><span class="keyword">[</span><span class="string">'flags'</span><span class="keyword">]))<br />&nbsp; {<br />&nbsp; &nbsp; </span><span class="default">$ret</span><span class="keyword">[</span><span class="string">'arguments'</span><span class="keyword">] = </span><span class="default">array_merge</span><span class="keyword">(</span><span class="default">$ret</span><span class="keyword">[</span><span class="string">'commands'</span><span class="keyword">], </span><span class="default">$ret</span><span class="keyword">[</span><span class="string">'arguments'</span><span class="keyword">]);<br />&nbsp; &nbsp; </span><span class="default">$ret</span><span class="keyword">[</span><span class="string">'commands'</span><span class="keyword">] = array();<br />&nbsp; }<br />return </span><span class="default">$ret</span><span class="keyword">;<br />}<br /><br />exit (</span><span class="default">0</span><span class="keyword">)<br /><br /></span><span class="comment">/* vim: set expandtab tabstop=2 shiftwidth=2: */<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="24970">  <div class="votes">
    <div id="Vu24970">
    <a href="/manual/vote-note.php?id=24970&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd24970">
    <a href="/manual/vote-note.php?id=24970&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V24970" title="60% like this...">
    6
    </div>
  </div>
  <a href="#24970" class="name">
  <strong class="user"><em>jeff at noSpam[] dot genhex dot net</em></strong></a><a class="genanchor" href="#24970"> &para;</a><div class="date" title="2002-09-06 05:13"><strong>15 years ago</strong></div>
  <div class="text" id="Hcom24970">
<div class="phpcode"><code><span class="html">
You can also call the script from the command line after chmod'ing the file (ie: chmod 755 file.php).<br /><br />On your first line of the file, enter "#!/usr/bin/php" (or to wherever your php executable is located).&nbsp; If you want to suppress the PHP headers, use the line of "#!/usr/bin/php -q" for your path.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116023">  <div class="votes">
    <div id="Vu116023">
    <a href="/manual/vote-note.php?id=116023&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116023">
    <a href="/manual/vote-note.php?id=116023&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116023" title="58% like this...">
    5
    </div>
  </div>
  <a href="#116023" class="name">
  <strong class="user"><em>frankNospamwanted at. toppoint dot. de</em></strong></a><a class="genanchor" href="#116023"> &para;</a><div class="date" title="2014-10-30 03:37"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom116023">
<div class="phpcode"><code><span class="html">
Parsing commandline argument GET String without changing the PHP script (linux shell):<br />URL: index.php?a=1&amp;b=2<br />Result: output.html<br /><br />echo "" | php -R 'include("index.php");' -B 'parse_str($argv[1], $_GET);' 'a=1&amp;b=2' &gt;output.html<br /><br />(no need to change php.ini)<br /><br />You can put this <br />&nbsp; echo "" | php -R 'include("'$1'");' -B 'parse_str($argv[1], $_GET);' "$2"<br />in a bash script "php_get" to use it like this:<br />&nbsp; php_get index.php 'a=1&amp;b=2' &gt;output.html<br />or directed to text browser...<br />&nbsp; php_get index.php 'a=1&amp;b=2' |w3m -T text/html</span>
</code></div>
  </div>
 </div>
  <div class="note" id="33119">  <div class="votes">
    <div id="Vu33119">
    <a href="/manual/vote-note.php?id=33119&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd33119">
    <a href="/manual/vote-note.php?id=33119&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V33119" title="60% like this...">
    5
    </div>
  </div>
  <a href="#33119" class="name">
  <strong class="user"><em>Adam, php(at)getwebspace.com</em></strong></a><a class="genanchor" href="#33119"> &para;</a><div class="date" title="2003-06-17 04:12"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom33119">
<div class="phpcode"><code><span class="html">
Ok, I've had a heck of a time with PHP &gt; 4.3.x and whether to use CLI vs CGI. The CGI version of 4.3.2 would return (in browser):<br />---<br />No input file specified.<br />---<br /><br />And the CLI version would return:<br />---<br />500 Internal Server Error<br />---<br /><br />It appears that in CGI mode, PHP looks at the environment variable PATH_TRANSLATED to determine the script to execute and ignores command line. That is why in the absensce of this environment variable, you get "No input file specified." However, in CLI mode the HTTP headers are not printed. I believe this is intended behavior for both situations but creates a problem when you have a CGI wrapper that sends environment variables but passes the actual script name on the command line.<br /><br />By modifying my CGI wrapper to create this PATH_TRANSLATED environment variable, it solved my problem, and I was able to run the CGI build of 4.3.2</span>
</code></div>
  </div>
 </div>
  <div class="note" id="94924">  <div class="votes">
    <div id="Vu94924">
    <a href="/manual/vote-note.php?id=94924&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd94924">
    <a href="/manual/vote-note.php?id=94924&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V94924" title="56% like this...">
    10
    </div>
  </div>
  <a href="#94924" class="name">
  <strong class="user"><em>notreallyanaddress at somerandomaddr dot com</em></strong></a><a class="genanchor" href="#94924"> &para;</a><div class="date" title="2009-12-02 05:34"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom94924">
<div class="phpcode"><code><span class="html">
If you want to be interactive with the user and accept user input, all you need to do is read from stdin.&nbsp; <br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">echo </span><span class="string">"Are you sure you want to do this?&nbsp; Type 'yes' to continue: "</span><span class="keyword">;<br /></span><span class="default">$handle </span><span class="keyword">= </span><span class="default">fopen </span><span class="keyword">(</span><span class="string">"php://stdin"</span><span class="keyword">,</span><span class="string">"r"</span><span class="keyword">);<br /></span><span class="default">$line </span><span class="keyword">= </span><span class="default">fgets</span><span class="keyword">(</span><span class="default">$handle</span><span class="keyword">);<br />if(</span><span class="default">trim</span><span class="keyword">(</span><span class="default">$line</span><span class="keyword">) != </span><span class="string">'yes'</span><span class="keyword">){<br />&nbsp; &nbsp; echo </span><span class="string">"ABORTING!\n"</span><span class="keyword">;<br />&nbsp; &nbsp; exit;<br />}<br />echo </span><span class="string">"\n"</span><span class="keyword">;<br />echo </span><span class="string">"Thank you, continuing...\n"</span><span class="keyword">;<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="39576">  <div class="votes">
    <div id="Vu39576">
    <a href="/manual/vote-note.php?id=39576&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd39576">
    <a href="/manual/vote-note.php?id=39576&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V39576" title="54% like this...">
    15
    </div>
  </div>
  <a href="#39576" class="name">
  <strong class="user"><em>ben at slax0rnet dot com</em></strong></a><a class="genanchor" href="#39576"> &para;</a><div class="date" title="2004-02-02 07:34"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom39576">
<div class="phpcode"><code><span class="html">
Just a note for people trying to use interactive mode from the commandline.<br /><br />The purpose of interactive mode is to parse code snippits without actually leaving php, and it works like this:<br /><br />[root@localhost php-4.3.4]# php -a<br />Interactive mode enabled<br /><br /><span class="default">&lt;?php </span><span class="keyword">echo </span><span class="string">"hi!"</span><span class="keyword">; </span><span class="default">?&gt;<br /></span>&lt;note, here we would press CTRL-D to parse everything we've entered so far&gt;<br />hi!<br /><span class="default">&lt;?php </span><span class="keyword">exit(); </span><span class="default">?&gt;<br /></span>&lt;ctrl-d here again&gt;<br />[root@localhost php-4.3.4]#<br /><br />I noticed this somehow got ommited from the docs, hope it helps someone!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="75532">  <div class="votes">
    <div id="Vu75532">
    <a href="/manual/vote-note.php?id=75532&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd75532">
    <a href="/manual/vote-note.php?id=75532&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V75532" title="57% like this...">
    6
    </div>
  </div>
  <a href="#75532" class="name">
  <strong class="user"><em>eric dot brison at anakeen dot com</em></strong></a><a class="genanchor" href="#75532"> &para;</a><div class="date" title="2007-06-04 05:16"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom75532">
<div class="phpcode"><code><span class="html">
Just a variant of previous script to accept arguments with '=' also<br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">arguments</span><span class="keyword">(</span><span class="default">$argv</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$_ARG </span><span class="keyword">= array();<br />&nbsp; &nbsp; foreach (</span><span class="default">$argv </span><span class="keyword">as </span><span class="default">$arg</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; if (</span><span class="default">ereg</span><span class="keyword">(</span><span class="string">'--([^=]+)=(.*)'</span><span class="keyword">,</span><span class="default">$arg</span><span class="keyword">,</span><span class="default">$reg</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$_ARG</span><span class="keyword">[</span><span class="default">$reg</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]] = </span><span class="default">$reg</span><span class="keyword">[</span><span class="default">2</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; } elseif(</span><span class="default">ereg</span><span class="keyword">(</span><span class="string">'-([a-zA-Z0-9])'</span><span class="keyword">,</span><span class="default">$arg</span><span class="keyword">,</span><span class="default">$reg</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$_ARG</span><span class="keyword">[</span><span class="default">$reg</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]] = </span><span class="string">'true'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp;&nbsp; <br />&nbsp; &nbsp; }<br />&nbsp; return </span><span class="default">$_ARG</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span>$ php myscript.php --user=nobody --password=secret -p --access="host=127.0.0.1 port=456" <br />Array<br />(<br />&nbsp; &nbsp; [user] =&gt; nobody<br />&nbsp; &nbsp; [password] =&gt; secret<br />&nbsp; &nbsp; [p] =&gt; true<br />&nbsp; &nbsp; [access] =&gt; host=127.0.0.1 port=456<br />)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="32701">  <div class="votes">
    <div id="Vu32701">
    <a href="/manual/vote-note.php?id=32701&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd32701">
    <a href="/manual/vote-note.php?id=32701&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V32701" title="58% like this...">
    4
    </div>
  </div>
  <a href="#32701" class="name">
  <strong class="user"><em>monte at ispi dot net</em></strong></a><a class="genanchor" href="#32701"> &para;</a><div class="date" title="2003-06-04 03:47"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom32701">
<div class="phpcode"><code><span class="html">
I had a problem with the $argv values getting split up when they contained plus (+) signs. Be sure to use the CLI version, not CGI to get around it.<br /><br />Monte</span>
</code></div>
  </div>
 </div>
  <div class="note" id="29468">  <div class="votes">
    <div id="Vu29468">
    <a href="/manual/vote-note.php?id=29468&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd29468">
    <a href="/manual/vote-note.php?id=29468&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V29468" title="58% like this...">
    4
    </div>
  </div>
  <a href="#29468" class="name">
  <strong class="user"><em>Alexander Plakidin</em></strong></a><a class="genanchor" href="#29468"> &para;</a><div class="date" title="2003-02-14 05:34"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom29468">
<div class="phpcode"><code><span class="html">
How to change current directory in PHP script to script's directory when running it from command line using PHP 4.3.0?<br />(you'll probably need to add this to older scripts when running them under PHP 4.3.0 for backwards compatibility)<br /><br />Here's what I am using:<br />chdir(preg_replace('/\\/[^\\/]+$/',"",$PHP_SELF));<br /><br />Note: documentation says that "PHP_SELF" is not available in command-line PHP scripts. Though, it IS available. Probably this will be changed in future version, so don't rely on this line of code...<br /><br />Use $_SERVER['PHP_SELF'] instead of just $PHP_SELF if you have register_globals=Off</span>
</code></div>
  </div>
 </div>
  <div class="note" id="74088">  <div class="votes">
    <div id="Vu74088">
    <a href="/manual/vote-note.php?id=74088&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd74088">
    <a href="/manual/vote-note.php?id=74088&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V74088" title="56% like this...">
    5
    </div>
  </div>
  <a href="#74088" class="name">
  <strong class="user"><em>rob</em></strong></a><a class="genanchor" href="#74088"> &para;</a><div class="date" title="2007-03-23 11:48"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom74088">
<div class="phpcode"><code><span class="html">
i use emacs in c-mode for editing.&nbsp; in 4.3, starting a cli script like so:<br /><br />#!/usr/bin/php -q /* -*- c -*- */<br /><span class="default">&lt;?php<br /><br />told emacs to drop into c</span><span class="keyword">-</span><span class="default">mode automatically when i loaded the file </span><span class="keyword">for </span><span class="default">editing</span><span class="keyword">.&nbsp; </span><span class="default">the </span><span class="string">'-q' </span><span class="default">flag didn</span><span class="string">'t actually do anything (in the older cgi versions, it suppressed html output when the script was run) but it caused the commented mode line to be ignored by php.<br /><br />in 5.2, '</span><span class="keyword">-</span><span class="default">q</span><span class="string">' has apparently been deprecated.&nbsp; replace it with '</span><span class="keyword">--</span><span class="string">' to achieve the 4.3 invocation-with-emacs-mode-line behavior:<br /><br />#!/usr/bin/php -- /* -*- c -*- */<br />&lt;?php<br /><br />don'</span><span class="default">t go back to your 4.3 system </span><span class="keyword">and </span><span class="default">replace </span><span class="string">'-q' </span><span class="default">with </span><span class="string">'--'</span><span class="keyword">; </span><span class="default">it seems to cause php to hang waiting on STDIN</span><span class="keyword">...</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="98647">  <div class="votes">
    <div id="Vu98647">
    <a href="/manual/vote-note.php?id=98647&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd98647">
    <a href="/manual/vote-note.php?id=98647&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V98647" title="56% like this...">
    3
    </div>
  </div>
  <a href="#98647" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#98647"> &para;</a><div class="date" title="2010-06-28 07:41"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom98647">
<div class="phpcode"><code><span class="html">
Using CLI (on WIN at least), some INI paths are relative to the current working directory.&nbsp; For example, if your error_log = "php_errors.log", then php_errors.log will be created (or appended to if already exists) in whatever directory you happen to be in at the moment if you have write access there.&nbsp; Instead of having random error logs all over the place because of this behavior, you may want to set error_log to a full path, perhaps to the php.exe directory.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="54756">  <div class="votes">
    <div id="Vu54756">
    <a href="/manual/vote-note.php?id=54756&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd54756">
    <a href="/manual/vote-note.php?id=54756&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V54756" title="56% like this...">
    5
    </div>
  </div>
  <a href="#54756" class="name">
  <strong class="user"><em>docey</em></strong></a><a class="genanchor" href="#54756"> &para;</a><div class="date" title="2005-07-14 05:44"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom54756">
<div class="phpcode"><code><span class="html">
dunno if this is on linux the same but on windows evertime<br />you send somthing to the console screen php is waiting for<br />the console to return. therefor if you send a lot of small <br />short amounts of text, the console is starting to be using <br />more cpu-cycles then php and thus slowing the script.<br /><br />take a look at this sheme:<br />cpu-cycle:1 -&gt;php: print("a");<br />cpu-cycle:2 -&gt;cmd: output("a");<br />cpu-cycle:3 -&gt;php: print("b");<br />cpu-cycle:4 -&gt;cmd: output("b");<br />cpu-cycle:5 -&gt;php: print("c");<br />cpu-cycle:6 -&gt;cmd: output("c"); <br />cpu-cylce:7 -&gt;php: print("d");<br />cpu-cycle:8 -&gt;cmd: output("d"); <br />cpu-cylce:9 -&gt;php: print("e");<br />cpu-cycle:0 -&gt;cmd: output("e"); <br /><br />on the screen just appears "abcde". but if you write <br />your script this way it will be far more faster:<br />cpu-cycle:1 -&gt;php: ob_start();<br />cpu-cycle:2 -&gt;php: print("abc");<br />cpu-cycle:3 -&gt;php: print("de");<br />cpu-cycle:4 -&gt;php: $data = ob_get_contents();<br />cpu-cycle:5 -&gt;php: ob_end_clean();<br />cpu-cycle:6 -&gt;php: print($data);<br />cpu-cycle:7 -&gt;cmd: output("abcde");<br /><br />now this is just a small example but if you are writing an<br />app that is outputting a lot to the console, i.e. a text<br />based screen with frequent updates, then its much better <br />to first cach all output, and output is as one big chunk of<br />text instead of one char a the time. <br /><br />ouput buffering is ideal for this. in my script i outputted<br />almost 4000chars of info and just by caching it first, it<br />speeded up by almost 400% and dropped cpu-usage.<br /><br />because what is being displayed doesn't matter, be it 2<br />chars or 40.0000 chars, just the call to output takes a <br />great deal of time. remeber that.<br /><br />maybe someone can test if this is the same on unix-based<br />systems. it seems that the STDOUT stream just waits for <br />the console to report ready, before continueing execution.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="105568">  <div class="votes">
    <div id="Vu105568">
    <a href="/manual/vote-note.php?id=105568&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd105568">
    <a href="/manual/vote-note.php?id=105568&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V105568" title="54% like this...">
    6
    </div>
  </div>
  <a href="#105568" class="name">
  <strong class="user"><em>Kodeart</em></strong></a><a class="genanchor" href="#105568"> &para;</a><div class="date" title="2011-08-29 02:03"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom105568">
<div class="phpcode"><code><span class="html">
Check directly without calling functions:<br /><span class="default">&lt;?php<br /></span><span class="keyword">if (</span><span class="default">PHP_SAPI </span><span class="keyword">=== </span><span class="string">'cli'</span><span class="keyword">)<br />{<br />&nbsp;&nbsp; </span><span class="comment">// ...<br /></span><span class="keyword">}<br /></span><span class="default">?&gt;<br /></span><br />You can define a constant to use it elsewhere<br /><span class="default">&lt;?php<br />define</span><span class="keyword">(</span><span class="string">'ISCLI'</span><span class="keyword">, </span><span class="default">PHP_SAPI </span><span class="keyword">=== </span><span class="string">'cli'</span><span class="keyword">);<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="56928">  <div class="votes">
    <div id="Vu56928">
    <a href="/manual/vote-note.php?id=56928&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd56928">
    <a href="/manual/vote-note.php?id=56928&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V56928" title="56% like this...">
    4
    </div>
  </div>
  <a href="#56928" class="name">
  <strong class="user"><em>OverFlow636 at gmail dot com</em></strong></a><a class="genanchor" href="#56928"> &para;</a><div class="date" title="2005-09-19 12:27"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom56928">
<div class="phpcode"><code><span class="html">
I needed this, you proly wont tho.<br />puts the exicution args into $_GET<br /><span class="default">&lt;?php<br /></span><span class="keyword">if (</span><span class="default">$argv</span><span class="keyword">) {<br />&nbsp; &nbsp; foreach (</span><span class="default">$argv </span><span class="keyword">as </span><span class="default">$k</span><span class="keyword">=&gt;</span><span class="default">$v</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$k</span><span class="keyword">==</span><span class="default">0</span><span class="keyword">) continue;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$it </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">(</span><span class="string">"="</span><span class="keyword">,</span><span class="default">$argv</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp; &nbsp; if (isset(</span><span class="default">$it</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">])) </span><span class="default">$_GET</span><span class="keyword">[</span><span class="default">$it</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]] = </span><span class="default">$it</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">];<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="71154">  <div class="votes">
    <div id="Vu71154">
    <a href="/manual/vote-note.php?id=71154&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd71154">
    <a href="/manual/vote-note.php?id=71154&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V71154" title="55% like this...">
    5
    </div>
  </div>
  <a href="#71154" class="name">
  <strong class="user"><em>goalain eat gmail dont com</em></strong></a><a class="genanchor" href="#71154"> &para;</a><div class="date" title="2006-11-14 12:57"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom71154">
<div class="phpcode"><code><span class="html">
If your php script doesn't run with shebang (#!/usr/bin/php),<br />and it issues the beautifull and informative error message:<br />"Command not found."&nbsp; just dos2unix yourscript.php<br />et voila.<br /><br />If you still get the "Command not found." <br />Just try to run it as ./myscript.php , with the "./"<br />if it works - it means your current directory is not in the executable search path.<br /><br />If your php script doesn't run with shebang (#/usr/bin/php),<br />and it issues the beautifull and informative message:<br />"Invalid null command." it's probably because the "!" is missing in the the shebang line (like what's above) or something else in that area.<br /><br />\Alon</span>
</code></div>
  </div>
 </div>
  <div class="note" id="50358">  <div class="votes">
    <div id="Vu50358">
    <a href="/manual/vote-note.php?id=50358&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd50358">
    <a href="/manual/vote-note.php?id=50358&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V50358" title="56% like this...">
    3
    </div>
  </div>
  <a href="#50358" class="name">
  <strong class="user"><em>obfuscated at emailaddress dot com</em></strong></a><a class="genanchor" href="#50358"> &para;</a><div class="date" title="2005-02-25 08:15"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom50358">
<div class="phpcode"><code><span class="html">
This posting is not a php-only problem, but hopefully will save someone a few hours of headaches.&nbsp; Running on MacOS (although this could happen on any *nix I suppose), I was unable to get the script to execute without specifically envoking php from the command line:<br /><br />[macg4:valencia/jobs] tim% test.php<br />./test.php: Command not found.<br /><br />However, it worked just fine when php was envoked on the command line:<br /><br />[macg4:valencia/jobs] tim% php test.php<br />Well, here we are...&nbsp; Now what?<br /><br />Was file access mode set for executable?&nbsp; Yup.<br /><br />[macg4:valencia/jobs] tim% ls -l <br />total 16<br />-rwxr-xr-x&nbsp; 1 tim&nbsp; staff&nbsp;&nbsp; 242 Feb 24 17:23 test.php<br /><br />And you did, of course, remember to add the php command as the first line of your script, yeah?&nbsp; Of course.<br /><br />#!/usr/bin/php<br /><span class="default">&lt;?php </span><span class="keyword">print </span><span class="string">"Well, here we are...&nbsp; Now what?\n"</span><span class="keyword">; </span><span class="default">?&gt;<br /></span><br />So why dudn't it work?&nbsp; Well, like I said... on a Mac.... but I also occasionally edit the files on my Windows portable (i.e. when I'm travelling and don't have my trusty Mac available)...&nbsp; Using, say, WordPad on Windows... and BBEdit on the Mac...<br /><br />Aaahhh... in BBEdit check how the file is being saved!&nbsp; Mac?&nbsp; Unix?&nbsp; or Dos?&nbsp; Bingo.&nbsp; It had been saved as Dos format.&nbsp; Change it to Unix:<br /><br />[macg4:valencia/jobs] tim% ./test.php<br />Well, here we are...&nbsp; Now what?<br />[macg4:valencia/jobs] tim% <br /><br />NB: If you're editing your php files on multiple platforms (i.e. Windows and Linux), make sure you double check the files are saved in a Unix format...&nbsp; those \r's and \n's 'll bite cha!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="29663">  <div class="votes">
    <div id="Vu29663">
    <a href="/manual/vote-note.php?id=29663&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd29663">
    <a href="/manual/vote-note.php?id=29663&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V29663" title="56% like this...">
    3
    </div>
  </div>
  <a href="#29663" class="name">
  <strong class="user"><em>volkany at celiknet dot com</em></strong></a><a class="genanchor" href="#29663"> &para;</a><div class="date" title="2003-02-20 01:44"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom29663">
<div class="phpcode"><code><span class="html">
Here goes a very simple clrscr function for newbies...<br />function clrscr() { system("clear"); }</span>
</code></div>
  </div>
 </div>
  <div class="note" id="26201">  <div class="votes">
    <div id="Vu26201">
    <a href="/manual/vote-note.php?id=26201&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd26201">
    <a href="/manual/vote-note.php?id=26201&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V26201" title="56% like this...">
    2
    </div>
  </div>
  <a href="#26201" class="name">
  <strong class="user"><em>phpnotes at ssilk dot de</em></strong></a><a class="genanchor" href="#26201"> &para;</a><div class="date" title="2002-10-22 03:36"><strong>15 years ago</strong></div>
  <div class="text" id="Hcom26201">
<div class="phpcode"><code><span class="html">
To hand over the GET-variables in interactive mode like in HTTP-Mode (e.g. your URI is myprog.html?hugo=bla&amp;bla=hugo), you have to call<br /><br />php myprog.html '&amp;hugo=bla&amp;bla=hugo'<br /><br />(two &amp; instead of ? and &amp;!)<br /><br />There just a little difference in the $ARGC, $ARGV values, but I think this is in those cases not relevant.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="78093">  <div class="votes">
    <div id="Vu78093">
    <a href="/manual/vote-note.php?id=78093&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd78093">
    <a href="/manual/vote-note.php?id=78093&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V78093" title="54% like this...">
    2
    </div>
  </div>
  <a href="#78093" class="name">
  <strong class="user"><em>losbrutos at free dot fr</em></strong></a><a class="genanchor" href="#78093"> &para;</a><div class="date" title="2007-09-27 05:54"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom78093">
<div class="phpcode"><code><span class="html">
an another "another variant" :<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">arguments</span><span class="keyword">(</span><span class="default">$argv</span><span class="keyword">)<br />{<br />&nbsp; </span><span class="default">$_ARG </span><span class="keyword">= array();<br />&nbsp; foreach (</span><span class="default">$argv </span><span class="keyword">as </span><span class="default">$arg</span><span class="keyword">)<br />&nbsp; {<br />&nbsp; &nbsp; if (</span><span class="default">preg_match</span><span class="keyword">(</span><span class="string">'#^-{1,2}([a-zA-Z0-9]*)=?(.*)$#'</span><span class="keyword">, </span><span class="default">$arg</span><span class="keyword">, </span><span class="default">$matches</span><span class="keyword">))<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$key </span><span class="keyword">= </span><span class="default">$matches</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; switch (</span><span class="default">$matches</span><span class="keyword">[</span><span class="default">2</span><span class="keyword">])<br />&nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">''</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">'true'</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$arg </span><span class="keyword">= </span><span class="default">true</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">'false'</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$arg </span><span class="keyword">= </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; default:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$arg </span><span class="keyword">= </span><span class="default">$matches</span><span class="keyword">[</span><span class="default">2</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$_ARG</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">] = </span><span class="default">$arg</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; else<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$_ARG</span><span class="keyword">[</span><span class="string">'input'</span><span class="keyword">][] = </span><span class="default">$arg</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; }<br />&nbsp; return </span><span class="default">$_ARG</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />$php myscript.php arg1 -arg2=val2 --arg3=arg3 -arg4 --arg5 -arg6=false<br /><br />Array<br />(<br />&nbsp; &nbsp; [input] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0] =&gt; myscript.php<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [1] =&gt; arg1<br />&nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />&nbsp; &nbsp; [arg2] =&gt; val2<br />&nbsp; &nbsp; [arg3] =&gt; arg3<br />&nbsp; &nbsp; [arg4] =&gt; true<br />&nbsp; &nbsp; [arg5] =&gt; true<br />&nbsp; &nbsp; [arg5] =&gt; false<br />)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="73765">  <div class="votes">
    <div id="Vu73765">
    <a href="/manual/vote-note.php?id=73765&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd73765">
    <a href="/manual/vote-note.php?id=73765&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V73765" title="53% like this...">
    2
    </div>
  </div>
  <a href="#73765" class="name">
  <strong class="user"><em>djcassis at gmail</em></strong></a><a class="genanchor" href="#73765"> &para;</a><div class="date" title="2007-03-09 07:14"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom73765">
<div class="phpcode"><code><span class="html">
To display colored text when it is actually supported :<br /><span class="default">&lt;?php<br /></span><span class="keyword">echo </span><span class="string">"\033[31m"</span><span class="keyword">.</span><span class="default">$myvar</span><span class="keyword">; </span><span class="comment">// red foreground<br /></span><span class="keyword">echo </span><span class="string">"\033[41m"</span><span class="keyword">.</span><span class="default">$myvar</span><span class="keyword">; </span><span class="comment">// red background<br /></span><span class="default">?&gt;<br /></span><br />To reset these settings : <br /><span class="default">&lt;?php<br /></span><span class="keyword">echo </span><span class="string">"\033[0m"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />More fun :<br /><span class="default">&lt;?php<br /></span><span class="keyword">echo </span><span class="string">"\033[5;30m;\033[48mWARNING !"</span><span class="keyword">; </span><span class="comment">// black blinking text over red background<br /></span><span class="default">?&gt;<br /></span><br />More info here : <a href="http://www.tldp.org/HOWTO/Bash-Prompt-HOWTO/x329.html" rel="nofollow" target="_blank">http://www.tldp.org/HOWTO/Bash-Prompt-HOWTO/x329.html</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="113224">  <div class="votes">
    <div id="Vu113224">
    <a href="/manual/vote-note.php?id=113224&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113224">
    <a href="/manual/vote-note.php?id=113224&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113224" title="52% like this...">
    1
    </div>
  </div>
  <a href="#113224" class="name">
  <strong class="user"><em>PSIKYO at mail dot dlut dot edu dot cn</em></strong></a><a class="genanchor" href="#113224"> &para;</a><div class="date" title="2013-09-14 03:19"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113224">
<div class="phpcode"><code><span class="html">
If you edit a php file in windows, upload and run it on linux with command line method. You may encounter a running problem probably like that:<br /><br />[root@ItsCloud02 wsdl]# ./lnxcli.php<br />Extension './lnxcli.php' not present.<br /><br />Or you may encounter some other strange problem.<br />Care the enter key. In windows environment, enter key generate two binary characters '0D0A'. But in Linux, enter key generate just only a 'OA'.<br />I wish it can help someone if you are using windows to code php and run it as a command line program on linux.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="93383">  <div class="votes">
    <div id="Vu93383">
    <a href="/manual/vote-note.php?id=93383&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd93383">
    <a href="/manual/vote-note.php?id=93383&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V93383" title="52% like this...">
    1
    </div>
  </div>
  <a href="#93383" class="name">
  <strong class="user"><em>Wade</em></strong></a><a class="genanchor" href="#93383"> &para;</a><div class="date" title="2009-09-06 10:46"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom93383">
<div class="phpcode"><code><span class="html">
I've just found that the fact that the CLI does *not* change the current directory will make include() and require() calls with relative paths fail. This is because they are relative to the current directory, not to the current executing file, the documentation notwithstanding. In CGI mode, this is the same because it changes the current directory.<br /><br />One solution is to call the CGI binary rather than the CLI one. A better solutions is to use dirname(__FILE__) in your path names.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="28731">  <div class="votes">
    <div id="Vu28731">
    <a href="/manual/vote-note.php?id=28731&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd28731">
    <a href="/manual/vote-note.php?id=28731&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V28731" title="53% like this...">
    2
    </div>
  </div>
  <a href="#28731" class="name">
  <strong class="user"><em>wanna at stay dot anonynous dot com</em></strong></a><a class="genanchor" href="#28731"> &para;</a><div class="date" title="2003-01-22 09:42"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom28731">
<div class="phpcode"><code><span class="html">
TIP: If you want different versions of the configuration file&nbsp; depending on what SAPI is used,just name them php.ini (apache module), php-cli.ini (CLI) and php-cgi.ini (CGI) and dump them all in the regular configuration directory. I.e no need to compile several versions of php anymore!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="78672">  <div class="votes">
    <div id="Vu78672">
    <a href="/manual/vote-note.php?id=78672&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd78672">
    <a href="/manual/vote-note.php?id=78672&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V78672" title="52% like this...">
    1
    </div>
  </div>
  <a href="#78672" class="name">
  <strong class="user"><em>james_s2010 at NOSPAM dot hotmail dot com</em></strong></a><a class="genanchor" href="#78672"> &para;</a><div class="date" title="2007-10-22 02:11"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom78672">
<div class="phpcode"><code><span class="html">
I was looking for a way to interactively get a single character response from user. Using STDIN with fread, fgets and such will only work after pressing enter. So I came up with this instead:<br /><br />#!/usr/bin/php -q<br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">inKey</span><span class="keyword">(</span><span class="default">$vals</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$inKey </span><span class="keyword">= </span><span class="string">""</span><span class="keyword">;<br />&nbsp; &nbsp; While(!</span><span class="default">in_array</span><span class="keyword">(</span><span class="default">$inKey</span><span class="keyword">,</span><span class="default">$vals</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$inKey </span><span class="keyword">= </span><span class="default">trim</span><span class="keyword">(`</span><span class="string">read -s -n1 valu;echo \$valu</span><span class="keyword">`);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; return </span><span class="default">$inKey</span><span class="keyword">;<br />}<br />function </span><span class="default">echoAT</span><span class="keyword">(</span><span class="default">$Row</span><span class="keyword">,</span><span class="default">$Col</span><span class="keyword">,</span><span class="default">$prompt</span><span class="keyword">=</span><span class="string">""</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="comment">// Display prompt at specific screen coords<br />&nbsp; &nbsp; </span><span class="keyword">echo </span><span class="string">"\033["</span><span class="keyword">.</span><span class="default">$Row</span><span class="keyword">.</span><span class="string">";"</span><span class="keyword">.</span><span class="default">$Col</span><span class="keyword">.</span><span class="string">"H"</span><span class="keyword">.</span><span class="default">$prompt</span><span class="keyword">;<br />}<br />&nbsp; &nbsp; </span><span class="comment">// Display prompt at position 10,10<br />&nbsp; &nbsp; </span><span class="default">echoAT</span><span class="keyword">(</span><span class="default">10</span><span class="keyword">,</span><span class="default">10</span><span class="keyword">,</span><span class="string">"Opt : "</span><span class="keyword">);<br /><br />&nbsp; &nbsp; </span><span class="comment">// Define acceptable responses<br />&nbsp; &nbsp; </span><span class="default">$options </span><span class="keyword">= array(</span><span class="string">"1"</span><span class="keyword">,</span><span class="string">"2"</span><span class="keyword">,</span><span class="string">"3"</span><span class="keyword">,</span><span class="string">"4"</span><span class="keyword">,</span><span class="string">"X"</span><span class="keyword">);<br /><br />&nbsp; &nbsp; </span><span class="comment">// Get user response<br />&nbsp; &nbsp; </span><span class="default">$key </span><span class="keyword">= </span><span class="default">inKey</span><span class="keyword">(</span><span class="default">$options</span><span class="keyword">);<br /><br />&nbsp; &nbsp; </span><span class="comment">// Display user response &amp; exit<br />&nbsp; &nbsp; </span><span class="default">echoAT</span><span class="keyword">(</span><span class="default">12</span><span class="keyword">,</span><span class="default">10</span><span class="keyword">,</span><span class="string">"Pressed : </span><span class="default">$key</span><span class="string">\n"</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />Hope this helps someone.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="19167">  <div class="votes">
    <div id="Vu19167">
    <a href="/manual/vote-note.php?id=19167&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd19167">
    <a href="/manual/vote-note.php?id=19167&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V19167" title="52% like this...">
    1
    </div>
  </div>
  <a href="#19167" class="name">
  <strong class="user"><em>pyxl at jerrell dot com</em></strong></a><a class="genanchor" href="#19167"> &para;</a><div class="date" title="2002-02-18 11:52"><strong>15 years ago</strong></div>
  <div class="text" id="Hcom19167">
<div class="phpcode"><code><span class="html">
Assuming --prefix=/usr/local/php, it's better to create a symlink from /usr/bin/php or /usr/local/bin/php to target /usr/local/php/bin/php so that it's both in your path and automatically correct every time you rebuild.&nbsp; If you forgot to do that copy of the binary after a rebuild, you can do all kinds of wild goose chasing when things break.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121914">  <div class="votes">
    <div id="Vu121914">
    <a href="/manual/vote-note.php?id=121914&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121914">
    <a href="/manual/vote-note.php?id=121914&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121914" title="no votes...">
    0
    </div>
  </div>
  <a href="#121914" class="name">
  <strong class="user"><em>apmuthu at usa dot net</em></strong></a><a class="genanchor" href="#121914"> &para;</a><div class="date" title="2017-11-26 05:17"><strong>18 days ago</strong></div>
  <div class="text" id="Hcom121914">
<div class="phpcode"><code><span class="html">
Adding a pause() function to PHP waiting for any user input returning it:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">pause</span><span class="keyword">() {<br />&nbsp; &nbsp; </span><span class="default">$handle </span><span class="keyword">= </span><span class="default">fopen </span><span class="keyword">(</span><span class="string">"php://stdin"</span><span class="keyword">,</span><span class="string">"r"</span><span class="keyword">);<br />&nbsp; &nbsp; do { </span><span class="default">$line </span><span class="keyword">= </span><span class="default">fgets</span><span class="keyword">(</span><span class="default">$handle</span><span class="keyword">); } while (</span><span class="default">$line </span><span class="keyword">== </span><span class="string">''</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">fclose</span><span class="keyword">(</span><span class="default">$handle</span><span class="keyword">);<br />&nbsp; &nbsp; return </span><span class="default">$line</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="34237">  <div class="votes">
    <div id="Vu34237">
    <a href="/manual/vote-note.php?id=34237&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd34237">
    <a href="/manual/vote-note.php?id=34237&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V34237" title="52% like this...">
    1
    </div>
  </div>
  <a href="#34237" class="name">
  <strong class="user"><em>punk at studionew dot com</em></strong></a><a class="genanchor" href="#34237"> &para;</a><div class="date" title="2003-07-19 04:18"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom34237">
<div class="phpcode"><code><span class="html">
You can use this function to ask user to enter something.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">read </span><span class="keyword">(</span><span class="default">$length</span><span class="keyword">=</span><span class="string">'255'</span><span class="keyword">)<br />{<br />&nbsp;&nbsp; if (!isset (</span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">'StdinPointer'</span><span class="keyword">]))<br />&nbsp;&nbsp; {<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">'StdinPointer'</span><span class="keyword">] = </span><span class="default">fopen </span><span class="keyword">(</span><span class="string">"php://stdin"</span><span class="keyword">,</span><span class="string">"r"</span><span class="keyword">);<br />&nbsp;&nbsp; }<br />&nbsp;&nbsp; </span><span class="default">$line </span><span class="keyword">= </span><span class="default">fgets </span><span class="keyword">(</span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">'StdinPointer'</span><span class="keyword">],</span><span class="default">$length</span><span class="keyword">);<br />&nbsp;&nbsp; return </span><span class="default">trim </span><span class="keyword">(</span><span class="default">$line</span><span class="keyword">);<br />}<br /><br /></span><span class="comment">// then<br /><br /></span><span class="keyword">echo </span><span class="string">"Enter your name: "</span><span class="keyword">;<br /></span><span class="default">$name </span><span class="keyword">= </span><span class="default">read </span><span class="keyword">();<br />echo </span><span class="string">"\nHello </span><span class="default">$name</span><span class="string">! Where you came from? "</span><span class="keyword">;<br /></span><span class="default">$where </span><span class="keyword">= </span><span class="default">read </span><span class="keyword">();<br />echo </span><span class="string">"\nI see. </span><span class="default">$where</span><span class="string"> is very good place."</span><span class="keyword">;<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="31360">  <div class="votes">
    <div id="Vu31360">
    <a href="/manual/vote-note.php?id=31360&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd31360">
    <a href="/manual/vote-note.php?id=31360&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V31360" title="52% like this...">
    1
    </div>
  </div>
  <a href="#31360" class="name">
  <strong class="user"><em>Popeye at P-t-B dot com</em></strong></a><a class="genanchor" href="#31360"> &para;</a><div class="date" title="2003-04-18 08:15"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom31360">
<div class="phpcode"><code><span class="html">
In *nix systems, use the WHICH command to show the location of the php binary executable. This is the path to use as the first line in your php shell script file. (#!/path/to/php -q) And execute php from the command line with the -v switch to see what version you are running.<br /><br />example:<br /><br /># which php<br />/usr/local/bin/php<br /># php -v<br />PHP 4.3.1 (cli) (built: Mar 27 2003 14:41:51)<br />Copyright (c) 1997-2002 The PHP Group<br />Zend Engine v1.3.0, Copyright (c) 1998-2002 Zend Technologies<br /><br />In the above example, you would use: #!/usr/local/bin/php<br /><br />Also note that, if you do not have the current/default directory in your PATH (.), you will have to use ./scriptfilename to execute your script file from the command line (or you will receive a "command not found" error). Use the ENV command to show your PATH environment variable value.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="53252">  <div class="votes">
    <div id="Vu53252">
    <a href="/manual/vote-note.php?id=53252&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd53252">
    <a href="/manual/vote-note.php?id=53252&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V53252" title="51% like this...">
    1
    </div>
  </div>
  <a href="#53252" class="name">
  <strong class="user"><em>roberto dot dimas at gmail dot com</em></strong></a><a class="genanchor" href="#53252"> &para;</a><div class="date" title="2005-05-26 01:52"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom53252">
<div class="phpcode"><code><span class="html">
One of the things I like about perl and vbscripts, is the fact that I can name a file e.g. 'test.pl' and just have to type 'test, without the .pl extension' on the windows command line and the command processor knows that it is a perl file and executes it using the perl command interpreter.<br /><br />I did the same with the file extension .php3 (I will use php3 exclusivelly for command line php scripts, I'm doing this because my text editor VIM 6.3 already has the correct syntax highlighting for .php3 files ).<br /><br />I modified the PATHEXT environment variable in Windows XP, from the " 'system' control panel applet-&gt;'Advanced' tab-&gt;'Environment Variables' button-&gt; 'System variables' text area".<br /><br />Then from control panel "Folder Options" applet-&gt; 'File Types' tab, I added a new file extention (php3), using the button 'New'&nbsp; and typing php3 in the window that pops up.<br /><br />Then in the 'Details for php3 extention' area I used the 'Change' button to look for the Php.exe executable so that the php3 file extentions are associated with the php executable.<br /><br />You have to modify also the 'PATH' environment variable, pointing to the folder where the php executable is installed<br /><br />Hope this is useful to somebody</span>
</code></div>
  </div>
 </div>
  <div class="note" id="95272">  <div class="votes">
    <div id="Vu95272">
    <a href="/manual/vote-note.php?id=95272&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd95272">
    <a href="/manual/vote-note.php?id=95272&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V95272" title="50% like this...">
    0
    </div>
  </div>
  <a href="#95272" class="name">
  <strong class="user"><em>ross at golder dot org</em></strong></a><a class="genanchor" href="#95272"> &para;</a><div class="date" title="2009-12-22 10:57"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom95272">
<div class="phpcode"><code><span class="html">
Note that parsing of the shebang line may not always work as expected...<br /><br />#!/usr/bin/php -dmemory_limit=512M -dsafe_mode=Off<br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">print </span><span class="string">"memory_limit="</span><span class="keyword">.</span><span class="default">ini_get</span><span class="keyword">(</span><span class="string">"memory_limit"</span><span class="keyword">).</span><span class="string">"\n"</span><span class="keyword">;<br />print </span><span class="string">"safe_mode="</span><span class="keyword">.</span><span class="default">ini_get</span><span class="keyword">(</span><span class="string">"safe_mode"</span><span class="keyword">).</span><span class="string">"\n"</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;<br /></span><br />gives...<br /><br />$ ./test.php <br />PHP:&nbsp; Invalid configuration directive<br />memory_limit=512M -dsafe_mode<br />safe_mode=</span>
</code></div>
  </div>
 </div>
  <div class="note" id="81176">  <div class="votes">
    <div id="Vu81176">
    <a href="/manual/vote-note.php?id=81176&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd81176">
    <a href="/manual/vote-note.php?id=81176&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V81176" title="50% like this...">
    0
    </div>
  </div>
  <a href="#81176" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#81176"> &para;</a><div class="date" title="2008-02-16 09:29"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom81176">
<div class="phpcode"><code><span class="html">
I find regex and manually breaking up the arguments instead of havingon $_SERVER['argv'] to do it more flexiable this way.<br /><br />cli_test.php asdf asdf --help --dest=/var/ -asd -h --option mew arf moo -z<br /><br />&nbsp; &nbsp; Array<br />&nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; [input] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0] =&gt; asdf<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [1] =&gt; asdf<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; [commands] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [help] =&gt; 1<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [dest] =&gt; /var/<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [option] =&gt; mew arf moo<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; [flags] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0] =&gt; asd<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [1] =&gt; h<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [2] =&gt; z<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />&nbsp; &nbsp; )<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">arguments </span><span class="keyword">( </span><span class="default">$args </span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="default">array_shift</span><span class="keyword">( </span><span class="default">$args </span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$args </span><span class="keyword">= </span><span class="default">join</span><span class="keyword">( </span><span class="default">$args</span><span class="keyword">, </span><span class="string">' ' </span><span class="keyword">);<br /><br />&nbsp; &nbsp; </span><span class="default">preg_match_all</span><span class="keyword">(</span><span class="string">'/ (--\w+ (?:[= ] [^-]+ [^\s-] )? ) | (-\w+) | (\w+) /x'</span><span class="keyword">, </span><span class="default">$args</span><span class="keyword">, </span><span class="default">$match </span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$args </span><span class="keyword">= </span><span class="default">array_shift</span><span class="keyword">( </span><span class="default">$match </span><span class="keyword">);<br /><br />&nbsp; &nbsp; </span><span class="comment">/*<br />&nbsp; &nbsp; &nbsp; &nbsp; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0] =&gt; asdf<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [1] =&gt; asdf<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [2] =&gt; --help<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [3] =&gt; --dest=/var/<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [4] =&gt; -asd<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [5] =&gt; -h<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [6] =&gt; --option mew arf moo<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [7] =&gt; -z<br />&nbsp; &nbsp; &nbsp; &nbsp; )<br />&nbsp; &nbsp; */<br /><br />&nbsp; &nbsp; </span><span class="default">$ret </span><span class="keyword">= array(<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'input'&nbsp; &nbsp; </span><span class="keyword">=&gt; array(),<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'commands' </span><span class="keyword">=&gt; array(),<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'flags'&nbsp; &nbsp; </span><span class="keyword">=&gt; array()<br />&nbsp; &nbsp; );<br /><br />&nbsp; &nbsp; foreach ( </span><span class="default">$args </span><span class="keyword">as </span><span class="default">$arg </span><span class="keyword">) {<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Is it a command? (prefixed with --)<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">if ( </span><span class="default">substr</span><span class="keyword">( </span><span class="default">$arg</span><span class="keyword">, </span><span class="default">0</span><span class="keyword">, </span><span class="default">2 </span><span class="keyword">) === </span><span class="string">'--' </span><span class="keyword">) {<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$value </span><span class="keyword">= </span><span class="default">preg_split</span><span class="keyword">( </span><span class="string">'/[= ]/'</span><span class="keyword">, </span><span class="default">$arg</span><span class="keyword">, </span><span class="default">2 </span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$com&nbsp;&nbsp; </span><span class="keyword">= </span><span class="default">substr</span><span class="keyword">( </span><span class="default">array_shift</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">), </span><span class="default">2 </span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$value </span><span class="keyword">= </span><span class="default">join</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">);<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$ret</span><span class="keyword">[</span><span class="string">'commands'</span><span class="keyword">][</span><span class="default">$com</span><span class="keyword">] = !empty(</span><span class="default">$value</span><span class="keyword">) ? </span><span class="default">$value </span><span class="keyword">: </span><span class="default">true</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; continue;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Is it a flag? (prefixed with -)<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">if ( </span><span class="default">substr</span><span class="keyword">( </span><span class="default">$arg</span><span class="keyword">, </span><span class="default">0</span><span class="keyword">, </span><span class="default">1 </span><span class="keyword">) === </span><span class="string">'-' </span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$ret</span><span class="keyword">[</span><span class="string">'flags'</span><span class="keyword">][] = </span><span class="default">substr</span><span class="keyword">( </span><span class="default">$arg</span><span class="keyword">, </span><span class="default">1 </span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; continue;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$ret</span><span class="keyword">[</span><span class="string">'input'</span><span class="keyword">][] = </span><span class="default">$arg</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; continue;<br /><br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; return </span><span class="default">$ret</span><span class="keyword">;<br />}<br /><br /></span><span class="default">print_r</span><span class="keyword">( </span><span class="default">arguments</span><span class="keyword">( </span><span class="default">$argv </span><span class="keyword">) );<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="76606">  <div class="votes">
    <div id="Vu76606">
    <a href="/manual/vote-note.php?id=76606&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd76606">
    <a href="/manual/vote-note.php?id=76606&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V76606" title="50% like this...">
    0
    </div>
  </div>
  <a href="#76606" class="name">
  <strong class="user"><em>lucas dot vasconcelos at gmail dot com</em></strong></a><a class="genanchor" href="#76606"> &para;</a><div class="date" title="2007-07-22 11:04"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom76606">
<div class="phpcode"><code><span class="html">
Just another variant of previous script that group arguments doesn't starts with '-' or '--'<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">arguments</span><span class="keyword">(</span><span class="default">$argv</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$_ARG </span><span class="keyword">= array();<br />&nbsp; &nbsp; foreach (</span><span class="default">$argv </span><span class="keyword">as </span><span class="default">$arg</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; if (</span><span class="default">ereg</span><span class="keyword">(</span><span class="string">'--([^=]+)=(.*)'</span><span class="keyword">,</span><span class="default">$arg</span><span class="keyword">,</span><span class="default">$reg</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$_ARG</span><span class="keyword">[</span><span class="default">$reg</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]] = </span><span class="default">$reg</span><span class="keyword">[</span><span class="default">2</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; } elseif(</span><span class="default">ereg</span><span class="keyword">(</span><span class="string">'^-([a-zA-Z0-9])'</span><span class="keyword">,</span><span class="default">$arg</span><span class="keyword">,</span><span class="default">$reg</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$_ARG</span><span class="keyword">[</span><span class="default">$reg</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]] = </span><span class="string">'true'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$_ARG</span><span class="keyword">[</span><span class="string">'input'</span><span class="keyword">][]=</span><span class="default">$arg</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; return </span><span class="default">$_ARG</span><span class="keyword">;<br />}<br /><br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">arguments</span><span class="keyword">(</span><span class="default">$argv</span><span class="keyword">));<br /></span><span class="default">?&gt;<br /></span><br />$ php myscript.php --user=nobody /etc/apache2/*<br />Array<br />(<br />&nbsp; &nbsp; [input] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0] =&gt; myscript.php<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [1] =&gt; /etc/apache2/apache2.conf<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [2] =&gt; /etc/apache2/conf.d<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [3] =&gt; /etc/apache2/envvars<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [4] =&gt; /etc/apache2/httpd.conf<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [5] =&gt; /etc/apache2/mods-available<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [6] =&gt; /etc/apache2/mods-enabled<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [7] =&gt; /etc/apache2/ports.conf<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [8] =&gt; /etc/apache2/sites-available<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [9] =&gt; /etc/apache2/sites-enabled<br />&nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />&nbsp; &nbsp; [user] =&gt; nobody<br />)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="75985">  <div class="votes">
    <div id="Vu75985">
    <a href="/manual/vote-note.php?id=75985&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd75985">
    <a href="/manual/vote-note.php?id=75985&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V75985" title="50% like this...">
    0
    </div>
  </div>
  <a href="#75985" class="name">
  <strong class="user"><em>bluej100@gmail</em></strong></a><a class="genanchor" href="#75985"> &para;</a><div class="date" title="2007-06-25 11:02"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom75985">
<div class="phpcode"><code><span class="html">
In 5.1.2 (and others, I assume), the -f form silently drops the first argument after the script name from $_SERVER['argv']. I'd suggest avoiding it unless you need it for a special case.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="48395">  <div class="votes">
    <div id="Vu48395">
    <a href="/manual/vote-note.php?id=48395&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd48395">
    <a href="/manual/vote-note.php?id=48395&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V48395" title="47% like this...">
    -1
    </div>
  </div>
  <a href="#48395" class="name">
  <strong class="user"><em>Ben Jenkins</em></strong></a><a class="genanchor" href="#48395"> &para;</a><div class="date" title="2004-12-21 09:23"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom48395">
<div class="phpcode"><code><span class="html">
This took me all day to figure out, so I hope posting it here saves someone some time:<br />Your PHP-CLI may have a different php.ini than your apache-php.&nbsp; For example: On my Debian-based system, I discovered I have /etc/php4/apache/php.ini and /etc/php4/cli/php.ini<br />If you want MySQL support in the CLI, make sure the line <br />extension=mysql.so<br />is not commented out.<br />The differences in php.ini files may also be why some scripts will work when called through a web browser, but will not work when called via the command line.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="91343">  <div class="votes">
    <div id="Vu91343">
    <a href="/manual/vote-note.php?id=91343&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd91343">
    <a href="/manual/vote-note.php?id=91343&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V91343" title="47% like this...">
    -2
    </div>
  </div>
  <a href="#91343" class="name">
  <strong class="user"><em>coffear at gmail dot com</em></strong></a><a class="genanchor" href="#91343"> &para;</a><div class="date" title="2009-06-06 05:06"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom91343">
<div class="phpcode"><code><span class="html">
In the notes it there is an example of running 1 line of PHP using:<br /><br />php -r 'print_r(get_defined_constants());'<br /><br />This might work on a UNIX machine but unfortunately on windows it produces the following error message:<br /><br />Parse error: parse error in Command line code on line 1<br /><br />Instead of using ' (single quotes) to encompass the PHP code use " (double quotes) instead. You can safely use ' within the code itself however such as:<br /><br />php -r "echo 'hello';"</span>
</code></div>
  </div>
 </div>
  <div class="note" id="57143">  <div class="votes">
    <div id="Vu57143">
    <a href="/manual/vote-note.php?id=57143&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd57143">
    <a href="/manual/vote-note.php?id=57143&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V57143" title="47% like this...">
    -1
    </div>
  </div>
  <a href="#57143" class="name">
  <strong class="user"><em>drewish at katherinehouse dot com</em></strong></a><a class="genanchor" href="#57143"> &para;</a><div class="date" title="2005-09-25 12:08"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom57143">
<div class="phpcode"><code><span class="html">
When you're writing one line php scripts remember that 'php://stdin' is your friend. Here's a simple program I use to format PHP code for inclusion on my blog:<br /><br />UNIX:<br />&nbsp; cat test.php | php -r "print htmlentities(file_get_contents('php://stdin'));"<br /><br />DOS/Windows:<br />&nbsp; type test.php | php -r "print htmlentities(file_get_contents('php://stdin'));"</span>
</code></div>
  </div>
 </div>
  <div class="note" id="83019">  <div class="votes">
    <div id="Vu83019">
    <a href="/manual/vote-note.php?id=83019&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd83019">
    <a href="/manual/vote-note.php?id=83019&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V83019" title="46% like this...">
    -2
    </div>
  </div>
  <a href="#83019" class="name">
  <strong class="user"><em>mortals at seznam dot cz</em></strong></a><a class="genanchor" href="#83019"> &para;</a><div class="date" title="2008-05-07 01:08"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom83019">
<div class="phpcode"><code><span class="html">
If a module SAPI is chosen during configure, such as apxs, or the --disable-cgi option is used, the CLI is copied to {PREFIX}/bin/php during make install&nbsp; otherwise the CGI is placed there.<br /><br />versus<br /><br />Changed CGI install target to php-cgi and 'make install' to install CLI when CGI is selected. (changelog for 5.2.3)<br /><a href="http://www.php.net/ChangeLog-5.php#5.2.3" rel="nofollow" target="_blank">http://www.php.net/ChangeLog-5.php#5.2.3</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="24013">  <div class="votes">
    <div id="Vu24013">
    <a href="/manual/vote-note.php?id=24013&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd24013">
    <a href="/manual/vote-note.php?id=24013&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V24013" title="47% like this...">
    -1
    </div>
  </div>
  <a href="#24013" class="name">
  <strong class="user"><em>jonNO at SPAMjellybob dot co dot uk</em></strong></a><a class="genanchor" href="#24013"> &para;</a><div class="date" title="2002-08-03 09:17"><strong>15 years ago</strong></div>
  <div class="text" id="Hcom24013">
<div class="phpcode"><code><span class="html">
If you want to get the output of a command use the function shell_exec($command) - it returns a string with the output of the command.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="106303">  <div class="votes">
    <div id="Vu106303">
    <a href="/manual/vote-note.php?id=106303&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd106303">
    <a href="/manual/vote-note.php?id=106303&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V106303" title="45% like this...">
    -3
    </div>
  </div>
  <a href="#106303" class="name">
  <strong class="user"><em>me at unreal4u dot com</em></strong></a><a class="genanchor" href="#106303"> &para;</a><div class="date" title="2011-10-26 09:28"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom106303">
<div class="phpcode"><code><span class="html">
You could use the Linux way of knowing that everything went ok by dying with a numeric code: 0 if everything went ok and practically anything else if something goes terribly wrong. That way;<br /><br /><span class="default">&lt;?php </span><span class="comment">// hello.php<br /></span><span class="keyword">echo </span><span class="string">'hello'</span><span class="keyword">;<br />exit(</span><span class="default">0</span><span class="keyword">);<br /></span><span class="default">?&gt;<br />&lt;?php </span><span class="comment">// bye.php<br /></span><span class="keyword">echo </span><span class="string">'bye'</span><span class="keyword">;<br />exit(</span><span class="default">1</span><span class="keyword">);<br /></span><span class="default">?&gt;<br />&lt;?php </span><span class="comment">// hello-again.php<br /></span><span class="keyword">echo </span><span class="string">'hi world!'</span><span class="keyword">;<br />exit(</span><span class="default">0</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />calling:<br />php hello.php &amp;&amp; php bye.php &amp;&amp; php hello-again.php<br /><br />would only execute the first two scripts, the last one doesn't get executed because an error ocurred in that script.<br /><br />Greetings.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="56846">  <div class="votes">
    <div id="Vu56846">
    <a href="/manual/vote-note.php?id=56846&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd56846">
    <a href="/manual/vote-note.php?id=56846&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V56846" title="46% like this...">
    -3
    </div>
  </div>
  <a href="#56846" class="name">
  <strong class="user"><em>php at schabdach dot de</em></strong></a><a class="genanchor" href="#56846"> &para;</a><div class="date" title="2005-09-16 09:06"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom56846">
<div class="phpcode"><code><span class="html">
To pass more than 9 arguments to your php-script on Windows, you can use the 'shift'-command in a batch file. After using 'shift', %1 becomes %0, %2 becomes %1 and so on - so you can fetch argument 10 etc. <br /><br />Here's an example - hopefully ready-to-use - batch file:<br /><br />foo.bat:<br />---------<br />@echo off<br /><br />:init_arg<br />set args=<br /><br />:get_arg<br />shift<br />if "%0"=="" goto :finish_arg<br />set args=%args% %0<br />goto :get_arg<br />:finish_arg<br /><br />set php=C:\path\to\php.exe<br />set ini=C:\path\to\php.ini<br />%php% -c %ini% foo.php %args%<br />---------<br /><br />Usage on commandline:<br />foo -1 -2 -3 -4 -5 -6 -7 -8 -9 -foo -bar<br /><br />A print_r($argv) will give you all of the passed arguments.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="78804">  <div class="votes">
    <div id="Vu78804">
    <a href="/manual/vote-note.php?id=78804&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd78804">
    <a href="/manual/vote-note.php?id=78804&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V78804" title="45% like this...">
    -1
    </div>
  </div>
  <a href="#78804" class="name">
  <strong class="user"><em>earomero _{at}_ gmail.com</em></strong></a><a class="genanchor" href="#78804"> &para;</a><div class="date" title="2007-10-28 03:51"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom78804">
<div class="phpcode"><code><span class="html">
Here's &lt;losbrutos at free dot fr&gt; function modified to support unix like param syntax like &lt;B Crawford&gt; mentions:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">arguments</span><span class="keyword">(</span><span class="default">$argv</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$_ARG </span><span class="keyword">= array();<br />&nbsp; &nbsp; foreach (</span><span class="default">$argv </span><span class="keyword">as </span><span class="default">$arg</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">preg_match</span><span class="keyword">(</span><span class="string">'#^-{1,2}([a-zA-Z0-9]*)=?(.*)$#'</span><span class="keyword">, </span><span class="default">$arg</span><span class="keyword">, </span><span class="default">$matches</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$key </span><span class="keyword">= </span><span class="default">$matches</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; switch (</span><span class="default">$matches</span><span class="keyword">[</span><span class="default">2</span><span class="keyword">]) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">''</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">'true'</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$arg </span><span class="keyword">= </span><span class="default">true</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">'false'</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$arg </span><span class="keyword">= </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; default:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$arg </span><span class="keyword">= </span><span class="default">$matches</span><span class="keyword">[</span><span class="default">2</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">/* make unix like -afd == -a -f -d */&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">if(</span><span class="default">preg_match</span><span class="keyword">(</span><span class="string">"/^-([a-zA-Z0-9]+)/"</span><span class="keyword">, </span><span class="default">$matches</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">], </span><span class="default">$match</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$string </span><span class="keyword">= </span><span class="default">$match</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; for(</span><span class="default">$i</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">; </span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$string</span><span class="keyword">) &gt; </span><span class="default">$i</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">++) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$_ARG</span><span class="keyword">[</span><span class="default">$string</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">]] = </span><span class="default">true</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$_ARG</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">] = </span><span class="default">$arg</span><span class="keyword">;&nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$_ARG</span><span class="keyword">[</span><span class="string">'input'</span><span class="keyword">][] = </span><span class="default">$arg</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; return </span><span class="default">$_ARG</span><span class="keyword">;&nbsp; &nbsp; <br />}<br /></span><span class="default">?&gt;<br /></span><br />Sample:<br /><br />eromero@ditto ~/workspace/snipplets $ foxogg2mp3.php asdf asdf --help --dest=/var/ -asd -h<br />Array<br />(<br />&nbsp; &nbsp; [input] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0] =&gt; /usr/local/bin/foxogg2mp3.php<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [1] =&gt; asdf<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [2] =&gt; asdf<br />&nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />&nbsp; &nbsp; [help] =&gt; 1<br />&nbsp; &nbsp; [dest] =&gt; /var/<br />&nbsp; &nbsp; [a] =&gt; 1<br />&nbsp; &nbsp; [s] =&gt; 1<br />&nbsp; &nbsp; [d] =&gt; 1<br />&nbsp; &nbsp; [h] =&gt; 1<br />)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="51359">  <div class="votes">
    <div id="Vu51359">
    <a href="/manual/vote-note.php?id=51359&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd51359">
    <a href="/manual/vote-note.php?id=51359&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V51359" title="45% like this...">
    -2
    </div>
  </div>
  <a href="#51359" class="name">
  <strong class="user"><em>merrittd at dhcmc dot com</em></strong></a><a class="genanchor" href="#51359"> &para;</a><div class="date" title="2005-03-28 01:23"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom51359">
<div class="phpcode"><code><span class="html">
Example 43-2 shows how to create a DOS batch file to run a PHP script form the command line using: <br /><br />@c:\php\cli\php.exe script.php %1 %2 %3 %4<br /><br />Here is an updated version of the DOS batch file:<br /><br />@c:\php\cli\php.exe %~n0.php %*<br /><br />This will run a PHP file (i.e. script.php) with the same base file name (i.e. script) as the DOS batch file (i.e. script.bat) and pass all parameters (not just the first four as in example 43-2) from the DOS batch file to the PHP file.&nbsp; <br /><br />This way all you have to do is copy/rename the DOS batch file to match the name of your PHP script file without ever having to actually modify the contents of the DOS batch file to match the file name of the PHP script.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="89149">  <div class="votes">
    <div id="Vu89149">
    <a href="/manual/vote-note.php?id=89149&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd89149">
    <a href="/manual/vote-note.php?id=89149&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V89149" title="44% like this...">
    -3
    </div>
  </div>
  <a href="#89149" class="name">
  <strong class="user"><em>Willy T. Koch</em></strong></a><a class="genanchor" href="#89149"> &para;</a><div class="date" title="2009-02-24 02:11"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom89149">
<div class="phpcode"><code><span class="html">
I'm figuring out how to pipe an email to a php script with postfix. For the email user@example.com:<br /><br />I created the following line in /etc/aliases:<br />user:&nbsp; &nbsp; &nbsp; &nbsp; "|/www/file.php"<br /><br />file.php is chmod 755<br /><br />This works fine. But I wanted to test this without having to send an email every time. And this took some searching to figure out, yet it's oh-so simple:<br /><br />To pipe the file email.txt to the script, write the following in the terminal window:<br /><br />user@host: php file.php &lt; testepost.txt<br /><br />I was confused by the | in the aliases file, and didn't get what came after what, etc etc.<br /><br />Regards,<br /><br />Willy T. Koch<br />Norway</span>
</code></div>
  </div>
 </div>
  <div class="note" id="86940">  <div class="votes">
    <div id="Vu86940">
    <a href="/manual/vote-note.php?id=86940&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86940">
    <a href="/manual/vote-note.php?id=86940&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86940" title="44% like this...">
    -2
    </div>
  </div>
  <a href="#86940" class="name">
  <strong class="user"><em>patrick smith</em></strong></a><a class="genanchor" href="#86940"> &para;</a><div class="date" title="2008-11-11 07:43"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86940">
<div class="phpcode"><code><span class="html">
For command-line option definition and parsing, don't forget about the beauty of getopt().<br /><br />There's a php-native version (<a href="http://php.net/getopt" rel="nofollow" target="_blank">http://php.net/getopt</a>) and a PEAR package -- Console_GetOpt (<a href="http://pear.php.net/package/Console_Getopt" rel="nofollow" target="_blank">http://pear.php.net/package/Console_Getopt</a>).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="53373">  <div class="votes">
    <div id="Vu53373">
    <a href="/manual/vote-note.php?id=53373&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd53373">
    <a href="/manual/vote-note.php?id=53373&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V53373" title="45% like this...">
    -2
    </div>
  </div>
  <a href="#53373" class="name">
  <strong class="user"><em>linus at flowingcreativity dot net</em></strong></a><a class="genanchor" href="#53373"> &para;</a><div class="date" title="2005-05-30 07:32"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom53373">
<div class="phpcode"><code><span class="html">
If you are using Windows XP (I think this works on 2000, too) and you want to be able to right-click a .php file and run it from the command line, follow these steps:<br /><br />1. Run regedit.exe and *back up the registry.*<br />2. Open HKEY_CLASSES_ROOT and find the ".php" key.<br /><br />IF IT EXISTS:<br />------------------<br />3. Look at the "(Default)" value inside it and find the key in HKEY_CLASSES_ROOT with that name.<br />4. Open the "shell" key inside that key. Skip to 8.<br /><br />IF IT DOESN'T:<br />------------------<br />5. Add a ".php" key and set the "(Default)" value inside it to something like "phpscriptfile".<br />6. Create another key in HKEY_CLASSES_ROOT called "phpscriptfile" or whatever you chose.<br />7. Create a key inside that one called "shell".<br /><br />8. Create a key inside that one called "run".<br />9. Set the "(Default)" value inside "run" to whatever you want the menu option to be (e.g. "Run").<br />10. Create a key inside "run" called "command".<br />11. Set the "(Default)" value inside "command" to:<br /><br />cmd.exe /k C:\php\php.exe "%1"<br /><br />Make sure the path to PHP is appropriate for your installation. Why not just run it with php.exe directly? Because you (presumably) want the console window to remain open after the script ends.<br /><br />You don't need to set up a webserver for this to work. I downloaded PHP just so I could run scripts on my computer. Hope this is useful!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="71393">  <div class="votes">
    <div id="Vu71393">
    <a href="/manual/vote-note.php?id=71393&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd71393">
    <a href="/manual/vote-note.php?id=71393&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V71393" title="43% like this...">
    -2
    </div>
  </div>
  <a href="#71393" class="name">
  <strong class="user"><em>jgraef at users dot sf dot net</em></strong></a><a class="genanchor" href="#71393"> &para;</a><div class="date" title="2006-11-26 08:46"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom71393">
<div class="phpcode"><code><span class="html">
Hi,<br />This function clears the screen, like "clear screen"<br /><br /><span class="default">&lt;?php<br />&nbsp; </span><span class="keyword">function </span><span class="default">clearscreen</span><span class="keyword">(</span><span class="default">$out </span><span class="keyword">= </span><span class="default">TRUE</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$clearscreen </span><span class="keyword">= </span><span class="default">chr</span><span class="keyword">(</span><span class="default">27</span><span class="keyword">).</span><span class="string">"[H"</span><span class="keyword">.</span><span class="default">chr</span><span class="keyword">(</span><span class="default">27</span><span class="keyword">).</span><span class="string">"[2J"</span><span class="keyword">;<br />&nbsp; &nbsp; if (</span><span class="default">$out</span><span class="keyword">) print </span><span class="default">$clearscreen</span><span class="keyword">;<br />&nbsp; &nbsp; else return </span><span class="default">$clearscreen</span><span class="keyword">;<br />&nbsp; }<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="93479">  <div class="votes">
    <div id="Vu93479">
    <a href="/manual/vote-note.php?id=93479&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd93479">
    <a href="/manual/vote-note.php?id=93479&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V93479" title="41% like this...">
    -2
    </div>
  </div>
  <a href="#93479" class="name">
  <strong class="user"><em>dj dot rokx at gmail dot com</em></strong></a><a class="genanchor" href="#93479"> &para;</a><div class="date" title="2009-09-11 01:34"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom93479">
<div class="phpcode"><code><span class="html">
Use PHP as Scripting Language in Windows Vista and 7:<br /><br />ASSOC .phs=PHPScript<br />FTPYE PHPScript=[path to]\php.exe -f "%1" -- %*<br /><br />optional set PATHEXT=.phs;%PATHEXT%<br /><br />now you can execute any php-script (ext: .phs) from the shell like a .vbs or .cmd.<br /><br />"c:\testscript.phs arg1 arg2" or with the optional step "c:\testscript arg1 arg2"<br /><br />i hope this helps somebody.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="94912">  <div class="votes">
    <div id="Vu94912">
    <a href="/manual/vote-note.php?id=94912&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd94912">
    <a href="/manual/vote-note.php?id=94912&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V94912" title="41% like this...">
    -4
    </div>
  </div>
  <a href="#94912" class="name">
  <strong class="user"><em>kazink at gmail dot com</em></strong></a><a class="genanchor" href="#94912"> &para;</a><div class="date" title="2009-12-02 03:58"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom94912">
<div class="phpcode"><code><span class="html">
I had problems running php as CGI in thttpd. I have followed instructions posted by db at digitalmediacreation dot ch, but I was still getting "500 Internal Error" answer from the server. However, I had no problems running php as CLI using a simple wrapper file named index.cgi:<br /><br />#!/usr/bin/php<br /><span class="default">&lt;?php<br />&nbsp; </span><span class="keyword">require_once </span><span class="string">'index.php'</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />but i needed to pass user data through GET and POST, and this method couldn't handle it. I have spent 2 hours figuring out how to run the CGI mode properly, until I finally gave up, and done it in "manual" way. I have just added some code to the wrapper that reads GET and POST data into the proper variables:<br /><br />#!/usr/bin/php<br /><span class="default">&lt;?php<br /><br />&nbsp; </span><span class="comment">//parse the command line into the $_GET variable<br />&nbsp; </span><span class="default">parse_str</span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'QUERY_STRING'</span><span class="keyword">], </span><span class="default">$_GET</span><span class="keyword">);<br />&nbsp; <br />&nbsp; </span><span class="comment">//parse the standard input into the $_POST variable<br />&nbsp; </span><span class="keyword">if ((</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'REQUEST_METHOD'</span><span class="keyword">] === </span><span class="string">'POST'</span><span class="keyword">)<br />&nbsp;&nbsp; &amp;&amp; (</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'CONTENT_LENGTH'</span><span class="keyword">] &gt; </span><span class="default">0</span><span class="keyword">))<br />&nbsp; {<br />&nbsp; &nbsp; </span><span class="default">parse_str</span><span class="keyword">(</span><span class="default">fread</span><span class="keyword">(</span><span class="default">STDIN</span><span class="keyword">, </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'CONTENT_LENGTH'</span><span class="keyword">]), </span><span class="default">$_POST</span><span class="keyword">);<br />&nbsp; }<br /><br />&nbsp; require_once </span><span class="string">'index.php'</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />It works well for me. It may be useful if someone else have similar problem.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119901">  <div class="votes">
    <div id="Vu119901">
    <a href="/manual/vote-note.php?id=119901&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119901">
    <a href="/manual/vote-note.php?id=119901&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119901" title="33% like this...">
    -2
    </div>
  </div>
  <a href="#119901" class="name">
  <strong class="user"><em>ohcc at 163 dot com</em></strong></a><a class="genanchor" href="#119901"> &para;</a><div class="date" title="2016-09-17 06:26"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119901">
<div class="phpcode"><code><span class="html">
use " instead of ' on windows when using the cli version with -r<br /><br />php -r "echo 1" <br />-- correct<br /><br />php -r 'echo 1'<br />&nbsp; PHP Parse error:&nbsp; syntax error, unexpected ''echo' (T_ENCAPSED_AND_WHITESPACE), expecting end of file in Command line code on line 1</span>
</code></div>
  </div>
 </div>
  <div class="note" id="26175">  <div class="votes">
    <div id="Vu26175">
    <a href="/manual/vote-note.php?id=26175&amp;page=features.commandline&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd26175">
    <a href="/manual/vote-note.php?id=26175&amp;page=features.commandline&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V26175" title="36% like this...">
    -3
    </div>
  </div>
  <a href="#26175" class="name">
  <strong class="user"><em>justin at visunet dot ie</em></strong></a><a class="genanchor" href="#26175"> &para;</a><div class="date" title="2002-10-21 09:21"><strong>15 years ago</strong></div>
  <div class="text" id="Hcom26175">
<div class="phpcode"><code><span class="html">
If you are trying to set up an interactive command line script and you want to get started straight away (works on 4+ I hope). Here is some code to start you off:<br /><br /><span class="default">&lt;?php<br /><br />&nbsp; &nbsp; </span><span class="comment">// Stop the script giving time out errors..<br />&nbsp; &nbsp; </span><span class="default">set_time_limit</span><span class="keyword">(</span><span class="default">0</span><span class="keyword">);<br /><br />&nbsp; &nbsp; </span><span class="comment">// This opens standard in ready for interactive input..<br />&nbsp; &nbsp; </span><span class="default">define</span><span class="keyword">(</span><span class="string">'STDIN'</span><span class="keyword">,</span><span class="default">fopen</span><span class="keyword">(</span><span class="string">"php://stdin"</span><span class="keyword">,</span><span class="string">"r"</span><span class="keyword">));<br /><br />&nbsp; &nbsp; </span><span class="comment">// Main event loop to capture top level command..<br />&nbsp; &nbsp; </span><span class="keyword">while(!</span><span class="default">0</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Print out main menu..<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">echo </span><span class="string">"Select an option..\n\n"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"&nbsp; &nbsp; 1) Do this\n"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"&nbsp; &nbsp; 2) Do this\n"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"&nbsp; &nbsp; 3) Do this\n"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"&nbsp; &nbsp; x) Exit\n"</span><span class="keyword">;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Decide what menu option to select based on input..<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">switch(</span><span class="default">trim</span><span class="keyword">(</span><span class="default">fgets</span><span class="keyword">(</span><span class="default">STDIN</span><span class="keyword">,</span><span class="default">256</span><span class="keyword">)))<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">1</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">2</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">3</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">"x"</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; exit();<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; default: <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">// Close standard in..<br />&nbsp; &nbsp; </span><span class="default">fclose</span><span class="keyword">(</span><span class="default">STDIN</span><span class="keyword">);<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=features.commandline&amp;redirect=http://php.net/manual/en/features.commandline.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="features.php">Features</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="features.http-auth.php" title="HTTP authentication with PHP">HTTP authentication with PHP</a>
                        </li>
                          
                        <li class="">
                            <a href="features.cookies.php" title="Cookies">Cookies</a>
                        </li>
                          
                        <li class="">
                            <a href="features.sessions.php" title="Sessions">Sessions</a>
                        </li>
                          
                        <li class="">
                            <a href="features.xforms.php" title="Dealing with XForms">Dealing with XForms</a>
                        </li>
                          
                        <li class="">
                            <a href="features.file-upload.php" title="Handling file uploads">Handling file uploads</a>
                        </li>
                          
                        <li class="">
                            <a href="features.remote-files.php" title="Using remote files">Using remote files</a>
                        </li>
                          
                        <li class="">
                            <a href="features.connection-handling.php" title="Connection handling">Connection handling</a>
                        </li>
                          
                        <li class="">
                            <a href="features.persistent-connections.php" title="Persistent Database Connections">Persistent Database Connections</a>
                        </li>
                          
                        <li class="">
                            <a href="features.safe-mode.php" title="Safe Mode">Safe Mode</a>
                        </li>
                          
                        <li class="current">
                            <a href="features.commandline.php" title="Command line usage">Command line usage</a>
                        </li>
                          
                        <li class="">
                            <a href="features.gc.php" title="Garbage Collection">Garbage Collection</a>
                        </li>
                          
                        <li class="">
                            <a href="features.dtrace.php" title="DTrace Dynamic Tracing">DTrace Dynamic Tracing</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

