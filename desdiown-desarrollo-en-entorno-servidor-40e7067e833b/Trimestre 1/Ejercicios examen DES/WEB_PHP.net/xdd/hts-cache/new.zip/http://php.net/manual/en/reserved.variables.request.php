<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: $_REQUEST - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/reserved.variables.request.php">
 <link rel="shorturl" href="http://php.net/manual/en/reserved.variables.request.php">
 <link rel="alternate" href="http://php.net/manual/en/reserved.variables.request.php" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/reserved.variables.php">
 <link rel="prev" href="http://php.net/manual/en/reserved.variables.files.php">
 <link rel="next" href="http://php.net/manual/en/reserved.variables.session.php">

 <link rel="alternate" href="http://php.net/manual/en/reserved.variables.request.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/reserved.variables.request.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/reserved.variables.request.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/reserved.variables.request.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/reserved.variables.request.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/reserved.variables.request.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/reserved.variables.request.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/reserved.variables.request.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/reserved.variables.request.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/reserved.variables.request.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/reserved.variables.request.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="reserved.variables.session.php">
          $_SESSION &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="reserved.variables.files.php">
          &laquo; $_FILES        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='reserved.variables.php'>Predefined Variables</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/reserved.variables.request.php' selected="selected">English</option>
            <option value='pt_BR/reserved.variables.request.php'>Brazilian Portuguese</option>
            <option value='zh/reserved.variables.request.php'>Chinese (Simplified)</option>
            <option value='fr/reserved.variables.request.php'>French</option>
            <option value='de/reserved.variables.request.php'>German</option>
            <option value='ja/reserved.variables.request.php'>Japanese</option>
            <option value='ro/reserved.variables.request.php'>Romanian</option>
            <option value='ru/reserved.variables.request.php'>Russian</option>
            <option value='es/reserved.variables.request.php'>Spanish</option>
            <option value='tr/reserved.variables.request.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/reserved.variables.request.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=reserved.variables.request">Report a Bug</a>
    </div>
  </div><div id="reserved.variables.request" class="refentry">
 <div class="refnamediv">
  <h1 class="refname">$_REQUEST</h1>
  <p class="verinfo">(PHP 4 &gt;= 4.1.0, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">$_REQUEST</span> &mdash; <span class="dc-title">HTTP Request variables</span></p>

 </div>
 
 <div class="refsect1 description" id="refsect1-reserved.variables.request-description">
  <h3 class="title">Description</h3>
  <p class="para">
   An associative <span class="type"><a href="language.types.array.php" class="type array">array</a></span> that by default contains the contents of
   <var class="varname"><var class="varname"><a href="reserved.variables.get.php" class="classname">$_GET</a></var></var>,
   <var class="varname"><var class="varname"><a href="reserved.variables.post.php" class="classname">$_POST</a></var></var> and
   <var class="varname"><var class="varname"><a href="reserved.variables.cookies.php" class="classname">$_COOKIE</a></var></var>.
  </p>
 </div>

 

 <div class="refsect1 changelog" id="refsect1-reserved.variables.request-changelog">
  <h3 class="title">Changelog</h3>
  <p class="para">
   <table class="doctable informaltable">
    
     <thead>
      <tr>
       <th>Version</th>
       <th>Description</th>
      </tr>

     </thead>

     <tbody class="tbody">
      <tr>
       <td>5.3.0</td>
       <td>
        Introduced <a href="ini.core.php#ini.request-order" class="link">request_order</a>.
        This directive affects the contents of <var class="varname"><var class="varname">$_REQUEST</var></var>.
       </td>
      </tr>

      <tr>
       <td>4.3.0</td>
       <td>
        <var class="varname"><var class="varname"><a href="reserved.variables.files.php" class="classname">$_FILES</a></var></var> information
        was removed from <var class="varname"><var class="varname">$_REQUEST</var></var>.
       </td>
      </tr>

      <tr>
       <td>4.1.0</td>
       <td>
        Introduced <var class="varname"><var class="varname">$_REQUEST</var></var>.
       </td>
      </tr>

     </tbody>
    
   </table>

  </p>
 </div>

 
 <div class="refsect1 notes" id="refsect1-reserved.variables.request-notes">
  <h3 class="title">Notes</h3>
  <blockquote class="note"><p><strong class="note">Note</strong>: <p class="para">This is a &#039;superglobal&#039;, or
automatic global, variable. This simply means that it is available in
all scopes throughout a script. There is no need to do
<strong class="command">global $variable;</strong> to access it within functions or methods.
</p></p></blockquote>
  <blockquote class="note"><p><strong class="note">Note</strong>: 
   <p class="para">
    When running on the <a href="features.commandline.php" class="link">command line
    </a>, this will <em class="emphasis">not</em> include the 
    <a href="reserved.variables.argv.php" class="link">argv</a> and 
    <a href="reserved.variables.argc.php" class="link">argc</a> entries; these are 
    present in the <var class="varname"><var class="varname"><a href="reserved.variables.server.php" class="classname">$_SERVER</a></var></var>
    <span class="type"><a href="language.types.array.php" class="type array">array</a></span>.
   </p>
  </p></blockquote>
  <blockquote class="note"><p><strong class="note">Note</strong>: 
   <p class="para">
    The variables in <var class="varname"><var class="varname">$_REQUEST</var></var> are provided to the
    script via the GET, POST, and COOKIE input mechanisms and
    therefore could be modified by the remote user and cannot be
    trusted. The presence and order of variables listed in this array
    is defined according to the
    PHP <a href="ini.core.php#ini.variables-order" class="link">variables_order</a>
    configuration directive.
   </p>
  </p></blockquote>
 </div>


 <div class="refsect1 seealso" id="refsect1-reserved.variables.request-seealso">
  <h3 class="title">See Also</h3>
  <ul class="simplelist">
   <li class="member"><span class="function"><a href="function.import-request-variables.php" class="function" rel="rdfs-seeAlso">import_request_variables()</a> - Import GET/POST/Cookie variables into the global scope</span></li>
   <li class="member"><a href="language.variables.external.php" class="link">Handling external variables</a></li>
   <li class="member"><a href="book.filter.php" class="link">The filter extension</a></li>
  </ul>
 </div>

 
</div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=reserved.variables.request&amp;redirect=http://php.net/manual/en/reserved.variables.request.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">5 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="84527">  <div class="votes">
    <div id="Vu84527">
    <a href="/manual/vote-note.php?id=84527&amp;page=reserved.variables.request&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd84527">
    <a href="/manual/vote-note.php?id=84527&amp;page=reserved.variables.request&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V84527" title="66% like this...">
    97
    </div>
  </div>
  <a href="#84527" class="name">
  <strong class="user"><em>strata_ranger at hotmail dot com</em></strong></a><a class="genanchor" href="#84527"> &para;</a><div class="date" title="2008-07-17 08:04"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom84527">
<div class="phpcode"><code><span class="html">
Don't forget, because $_REQUEST is a different variable than $_GET and $_POST, it is treated as such in PHP -- modifying $_GET or $_POST elements at runtime will not affect the ellements in $_REQUEST, nor vice versa.<br /><br />e.g:<br /><br /><span class="default">&lt;?php<br /><br />$_GET</span><span class="keyword">[</span><span class="string">'foo'</span><span class="keyword">] = </span><span class="string">'a'</span><span class="keyword">;<br /></span><span class="default">$_POST</span><span class="keyword">[</span><span class="string">'bar'</span><span class="keyword">] = </span><span class="string">'b'</span><span class="keyword">;<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$_GET</span><span class="keyword">); </span><span class="comment">// Element 'foo' is string(1) "a"<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$_POST</span><span class="keyword">); </span><span class="comment">// Element 'bar' is string(1) "b"<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$_REQUEST</span><span class="keyword">); </span><span class="comment">// Does not contain elements 'foo' or 'bar'<br /><br /></span><span class="default">?&gt;<br /></span><br />If you want to evaluate $_GET and $_POST variables by a single token without including $_COOKIE in the mix, use&nbsp; $_SERVER['REQUEST_METHOD'] to identify the method used and set up a switch block accordingly, e.g:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">switch(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'REQUEST_METHOD'</span><span class="keyword">])<br />{<br />case </span><span class="string">'GET'</span><span class="keyword">: </span><span class="default">$the_request </span><span class="keyword">= &amp;</span><span class="default">$_GET</span><span class="keyword">; break;<br />case </span><span class="string">'POST'</span><span class="keyword">: </span><span class="default">$the_request </span><span class="keyword">= &amp;</span><span class="default">$_POST</span><span class="keyword">; break;<br />.<br />. </span><span class="comment">// Etc.<br /></span><span class="keyword">.<br />default:<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119368">  <div class="votes">
    <div id="Vu119368">
    <a href="/manual/vote-note.php?id=119368&amp;page=reserved.variables.request&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119368">
    <a href="/manual/vote-note.php?id=119368&amp;page=reserved.variables.request&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119368" title="59% like this...">
    7
    </div>
  </div>
  <a href="#119368" class="name">
  <strong class="user"><em>Luke Madhanga</em></strong></a><a class="genanchor" href="#119368"> &para;</a><div class="date" title="2016-05-22 08:45"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119368">
<div class="phpcode"><code><span class="html">
To access $_POST, $_GET, etc, use the function filter_input(TYPE, varname, filter) to ensure that your data is clean. <br /><br />Also, I was brought up to believe that modifying superglobals is a BAD idea. I stand by this belief and would recommend you do too</span>
</code></div>
  </div>
 </div>
  <div class="note" id="96696">  <div class="votes">
    <div id="Vu96696">
    <a href="/manual/vote-note.php?id=96696&amp;page=reserved.variables.request&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd96696">
    <a href="/manual/vote-note.php?id=96696&amp;page=reserved.variables.request&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V96696" title="52% like this...">
    6
    </div>
  </div>
  <a href="#96696" class="name">
  <strong class="user"><em>mike o.</em></strong></a><a class="genanchor" href="#96696"> &para;</a><div class="date" title="2010-03-11 04:31"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom96696">
<div class="phpcode"><code><span class="html">
The default php.ini on your system as of in PHP 5.3.0 may exclude cookies from $_REQUEST.&nbsp; The request_order ini directive specifies what goes in the $_REQUEST array; if that does not exist, then the variables_order directive does.&nbsp; Your distribution's php.ini may exclude cookies by default, so beware.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="94985">  <div class="votes">
    <div id="Vu94985">
    <a href="/manual/vote-note.php?id=94985&amp;page=reserved.variables.request&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd94985">
    <a href="/manual/vote-note.php?id=94985&amp;page=reserved.variables.request&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V94985" title="50% like this...">
    2
    </div>
  </div>
  <a href="#94985" class="name">
  <strong class="user"><em>John Galt</em></strong></a><a class="genanchor" href="#94985"> &para;</a><div class="date" title="2009-12-06 05:36"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom94985">
<div class="phpcode"><code><span class="html">
I wrote a function because I found it inconvenient if I needed to change a particular parameter (get) while preserving the others. For example, I want to make a hyperlink on a web page with the URL <a href="http://www.example.com/script.php?id=1&amp;blah=blah+blah&amp;page=1" rel="nofollow" target="_blank">http://www.example.com/script.php?id=1&amp;blah=blah+blah&amp;page=1</a> and change the value of "page" to 2 without getting rid of the other parameters.<br /><br /><span class="default">&lt;?php<br /> </span><span class="keyword">function </span><span class="default">add_or_change_parameter</span><span class="keyword">(</span><span class="default">$parameter</span><span class="keyword">, </span><span class="default">$value</span><span class="keyword">)<br /> {<br />&nbsp; </span><span class="default">$params </span><span class="keyword">= array();<br />&nbsp; </span><span class="default">$output </span><span class="keyword">= </span><span class="string">"?"</span><span class="keyword">;<br />&nbsp; </span><span class="default">$firstRun </span><span class="keyword">= </span><span class="default">true</span><span class="keyword">;<br />&nbsp; foreach(</span><span class="default">$_GET </span><span class="keyword">as </span><span class="default">$key</span><span class="keyword">=&gt;</span><span class="default">$val</span><span class="keyword">)<br />&nbsp; {<br />&nbsp;&nbsp; if(</span><span class="default">$key </span><span class="keyword">!= </span><span class="default">$parameter</span><span class="keyword">)<br />&nbsp;&nbsp; {<br />&nbsp; &nbsp; if(!</span><span class="default">$firstRun</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp;&nbsp; </span><span class="default">$output </span><span class="keyword">.= </span><span class="string">"&amp;"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; else<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp;&nbsp; </span><span class="default">$firstRun </span><span class="keyword">= </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; </span><span class="default">$output </span><span class="keyword">.= </span><span class="default">$key</span><span class="keyword">.</span><span class="string">"="</span><span class="keyword">.</span><span class="default">urlencode</span><span class="keyword">(</span><span class="default">$val</span><span class="keyword">);<br />&nbsp;&nbsp; }<br />&nbsp; }<br />&nbsp; if(!</span><span class="default">$firstRun</span><span class="keyword">)<br />&nbsp;&nbsp; </span><span class="default">$output </span><span class="keyword">.= </span><span class="string">"&amp;"</span><span class="keyword">;<br />&nbsp; </span><span class="default">$output </span><span class="keyword">.= </span><span class="default">$parameter</span><span class="keyword">.</span><span class="string">"="</span><span class="keyword">.</span><span class="default">urlencode</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">);<br />&nbsp; return </span><span class="default">htmlentities</span><span class="keyword">(</span><span class="default">$output</span><span class="keyword">);<br /> }<br /></span><span class="default">?&gt;<br /></span><br />Now, I can add a hyperlink to the page (<a href="http://www.example.com/script.php?id=1&amp;blah=blah+blah&amp;page=1" rel="nofollow" target="_blank">http://www.example.com/script.php?id=1&amp;blah=blah+blah&amp;page=1</a>) like this:<br />&lt;a href="<span class="default">&lt;?php </span><span class="keyword">echo </span><span class="default">add_or_change_parameter</span><span class="keyword">(</span><span class="string">"page"</span><span class="keyword">, </span><span class="string">"2"</span><span class="keyword">); </span><span class="default">?&gt;</span>"&gt;Click to go to page 2&lt;/a&gt;<br /><br />The above code will output<br />&lt;a href="?id=1&amp;amp;blah=blah+blah&amp;amp;page=2"&gt;Click to go to page 2&lt;/a&gt;<br /><br />Also, if I was setting "page" to a string rather than just "2", the value would be urlencode()'d.<br />&lt;a href="<span class="default">&lt;?php </span><span class="keyword">echo </span><span class="default">add_or_change_parameter</span><span class="keyword">(</span><span class="string">"page"</span><span class="keyword">, </span><span class="string">"banana+split!"</span><span class="keyword">); </span><span class="default">?&gt;</span>"&gt;Click to go to page banana split!&lt;/a&gt;<br />would become<br />&lt;a href="?id=1&amp;amp;blah=blah+blah&amp;amp;page=banana+split%21"&gt;Click to go to page banana split!&lt;/a&gt;<br /><br />[EDIT BY danbrown AT php DOT net: Contains a bugfix provided by (theogony AT gmail DOT com), which adds missing `echo` instructions to the HREF tags.]</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118585">  <div class="votes">
    <div id="Vu118585">
    <a href="/manual/vote-note.php?id=118585&amp;page=reserved.variables.request&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118585">
    <a href="/manual/vote-note.php?id=118585&amp;page=reserved.variables.request&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118585" title="20% like this...">
    -74
    </div>
  </div>
  <a href="#118585" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#118585"> &para;</a><div class="date" title="2016-01-03 08:54"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom118585">
<div class="phpcode"><code><span class="html">
Note you should use $_GET, $_POST and $_COOKIE seperately if you use same name or your not sure.<br />Because there are "overwrite" problems with $_REQUEST :<br /><br />Example:<br />$_GET['foo'] is a 'hello' string&nbsp;&nbsp; //from user input<br />$_POST['foo'] is a 'world' string&nbsp;&nbsp; //from user input<br /><br />Then the $_REQUEST['foo'] would be a 'world' string. The value 'hello' is overwritten.<br /><br />So don't use $_REQUEST to monitor user inputs.</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=reserved.variables.request&amp;redirect=http://php.net/manual/en/reserved.variables.request.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="reserved.variables.php">Predefined Variables</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.variables.superglobals.php" title="Superglobals">Superglobals</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.globals.php" title="$GLOBALS">$GLOBALS</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.server.php" title="$_&#8203;SERVER">$_&#8203;SERVER</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.get.php" title="$_&#8203;GET">$_&#8203;GET</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.post.php" title="$_&#8203;POST">$_&#8203;POST</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.files.php" title="$_&#8203;FILES">$_&#8203;FILES</a>
                        </li>
                          
                        <li class="current">
                            <a href="reserved.variables.request.php" title="$_&#8203;REQUEST">$_&#8203;REQUEST</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.session.php" title="$_&#8203;SESSION">$_&#8203;SESSION</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.environment.php" title="$_&#8203;ENV">$_&#8203;ENV</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.cookies.php" title="$_&#8203;COOKIE">$_&#8203;COOKIE</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.phperrormsg.php" title="$php_&#8203;errormsg">$php_&#8203;errormsg</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.httprawpostdata.php" title="$HTTP_&#8203;RAW_&#8203;POST_&#8203;DATA">$HTTP_&#8203;RAW_&#8203;POST_&#8203;DATA</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.httpresponseheader.php" title="$http_&#8203;response_&#8203;header">$http_&#8203;response_&#8203;header</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.argc.php" title="$argc">$argc</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.argv.php" title="$argv">$argv</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

