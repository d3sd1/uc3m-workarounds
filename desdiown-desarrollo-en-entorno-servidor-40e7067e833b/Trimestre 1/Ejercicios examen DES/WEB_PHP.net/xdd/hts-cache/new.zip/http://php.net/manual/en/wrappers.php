<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Supported Protocols and Wrappers - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/wrappers.php">
 <link rel="shorturl" href="http://php.net/manual/en/wrappers.php">
 <link rel="alternate" href="http://php.net/manual/en/wrappers.php" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/langref.php">
 <link rel="prev" href="http://php.net/manual/en/context.zip.php">
 <link rel="next" href="http://php.net/manual/en/wrappers.file.php">

 <link rel="alternate" href="http://php.net/manual/en/wrappers.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/wrappers.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/wrappers.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/wrappers.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/wrappers.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/wrappers.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/wrappers.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/wrappers.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/wrappers.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/wrappers.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/wrappers.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="wrappers.file.php">
          file:// &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="context.zip.php">
          &laquo; Zip context options        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/wrappers.php' selected="selected">English</option>
            <option value='pt_BR/wrappers.php'>Brazilian Portuguese</option>
            <option value='zh/wrappers.php'>Chinese (Simplified)</option>
            <option value='fr/wrappers.php'>French</option>
            <option value='de/wrappers.php'>German</option>
            <option value='ja/wrappers.php'>Japanese</option>
            <option value='ro/wrappers.php'>Romanian</option>
            <option value='ru/wrappers.php'>Russian</option>
            <option value='es/wrappers.php'>Spanish</option>
            <option value='tr/wrappers.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/wrappers.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=wrappers">Report a Bug</a>
    </div>
  </div><div id="wrappers" class="reference">
 <h1 class="title">Supported Protocols and Wrappers</h1>
 <div class="partintro">
  <p class="para">
   PHP comes with many built-in wrappers for various URL-style protocols
   for use with the filesystem functions such as <span class="function"><a href="function.fopen.php" class="function">fopen()</a></span>,
   <span class="function"><a href="function.copy.php" class="function">copy()</a></span>, <span class="function"><a href="function.file-exists.php" class="function">file_exists()</a></span> and
   <span class="function"><a href="function.filesize.php" class="function">filesize()</a></span>.
   In addition to these wrappers, it is possible to register custom wrappers
   using the <span class="function"><a href="function.stream-wrapper-register.php" class="function">stream_wrapper_register()</a></span> function.
  </p>
  <blockquote class="note"><p><strong class="note">Note</strong>: 
   <span class="simpara">
    The URL syntax used to describe a wrapper only supports the
    <em>scheme://...</em> syntax. The <em>scheme:/</em>
    and <em>scheme:</em> syntaxes are not supported.
   </span>
  </p></blockquote>
 </div>
 
 







 







 







 







 







 







 







 







 







 







 







 







 
<h2>Table of Contents</h2><ul class="chunklist chunklist_reference"><li><a href="wrappers.file.php">file://</a> — Accessing local filesystem</li><li><a href="wrappers.http.php">http://</a> — Accessing HTTP(s) URLs</li><li><a href="wrappers.ftp.php">ftp://</a> — Accessing FTP(s) URLs</li><li><a href="wrappers.php.php">php://</a> — Accessing various I/O streams</li><li><a href="wrappers.compression.php">zlib://</a> — Compression Streams</li><li><a href="wrappers.data.php">data://</a> — Data (RFC 2397)</li><li><a href="wrappers.glob.php">glob://</a> — Find pathnames matching pattern</li><li><a href="wrappers.phar.php">phar://</a> — PHP Archive</li><li><a href="wrappers.ssh2.php">ssh2://</a> — Secure Shell 2</li><li><a href="wrappers.rar.php">rar://</a> — RAR</li><li><a href="wrappers.audio.php">ogg://</a> — Audio streams</li><li><a href="wrappers.expect.php">expect://</a> — Process Interaction Streams</li></ul>
</div>

<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=wrappers&amp;redirect=http://php.net/manual/en/wrappers.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">33 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="75751">  <div class="votes">
    <div id="Vu75751">
    <a href="/manual/vote-note.php?id=75751&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd75751">
    <a href="/manual/vote-note.php?id=75751&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V75751" title="64% like this...">
    12
    </div>
  </div>
  <a href="#75751" class="name">
  <strong class="user"><em>sander at medicore dot nl</em></strong></a><a class="genanchor" href="#75751"> &para;</a><div class="date" title="2007-06-14 04:25"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom75751">
<div class="phpcode"><code><span class="html">
to create a raw tcp listener system i use the following:<br /><br />xinetd daemon with config like:<br />service test<br />{<br />&nbsp; &nbsp; &nbsp; &nbsp; disable&nbsp; &nbsp; &nbsp; = no<br />&nbsp; &nbsp; &nbsp; &nbsp; type&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; = UNLISTED<br />&nbsp; &nbsp; &nbsp; &nbsp; socket_type&nbsp; = stream<br />&nbsp; &nbsp; &nbsp; &nbsp; protocol&nbsp; &nbsp;&nbsp; = tcp<br />&nbsp; &nbsp; &nbsp; &nbsp; bind&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; = 127.0.0.1<br />&nbsp; &nbsp; &nbsp; &nbsp; port&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; = 12345<br />&nbsp; &nbsp; &nbsp; &nbsp; wait&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; = no<br />&nbsp; &nbsp; &nbsp; &nbsp; user&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; = apache<br />&nbsp; &nbsp; &nbsp; &nbsp; group&nbsp; &nbsp; &nbsp; &nbsp; = apache<br />&nbsp; &nbsp; &nbsp; &nbsp; instances&nbsp; &nbsp; = 10<br />&nbsp; &nbsp; &nbsp; &nbsp; server&nbsp; &nbsp; &nbsp;&nbsp; = /usr/local/bin/php<br />&nbsp; &nbsp; &nbsp; &nbsp; server_args&nbsp; = -n [your php file here]<br />&nbsp; &nbsp; &nbsp; &nbsp; only_from&nbsp; &nbsp; = 127.0.0.1 #gotta love the security#<br />&nbsp; &nbsp; &nbsp; &nbsp; log_type&nbsp; &nbsp;&nbsp; = FILE /var/log/phperrors.log<br />&nbsp; &nbsp; &nbsp; &nbsp; log_on_success += DURATION<br />}<br /><br />now use fgets(STDIN) to read the input. Creates connections pretty quick, works like a charm.Writing can be done using the STDOUT, or just echo. Be aware that you're completely bypassing the webserver and thus certain variables will not be available.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="83220">  <div class="votes">
    <div id="Vu83220">
    <a href="/manual/vote-note.php?id=83220&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd83220">
    <a href="/manual/vote-note.php?id=83220&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V83220" title="56% like this...">
    11
    </div>
  </div>
  <a href="#83220" class="name">
  <strong class="user"><em>gjaman at gmail dot com</em></strong></a><a class="genanchor" href="#83220"> &para;</a><div class="date" title="2008-05-15 02:15"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom83220">
<div class="phpcode"><code><span class="html">
You can decompress (gzip) a input stream by combining wrappers:<br /><br />eg:&nbsp; $x = file_get_contents("compress.zlib://php://input"); <br /><br />I used this method to decompress a gzip stream that was pushed to my webserver</span>
</code></div>
  </div>
 </div>
  <div class="note" id="111570">  <div class="votes">
    <div id="Vu111570">
    <a href="/manual/vote-note.php?id=111570&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd111570">
    <a href="/manual/vote-note.php?id=111570&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V111570" title="56% like this...">
    10
    </div>
  </div>
  <a href="#111570" class="name">
  <strong class="user"><em>fabacrans__ at __nospamhotmail__ dot __com</em></strong></a><a class="genanchor" href="#111570"> &para;</a><div class="date" title="2013-03-05 12:06"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom111570">
<div class="phpcode"><code><span class="html">
You can use "php://input" to accept and parse "PUT", "DELETE", etc. requests.<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">// Example to parse "PUT" requests <br /></span><span class="default">parse_str</span><span class="keyword">(</span><span class="default">file_get_contents</span><span class="keyword">(</span><span class="string">'php://input'</span><span class="keyword">), </span><span class="default">$_PUT</span><span class="keyword">);<br /><br /></span><span class="comment">// The result<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$_PUT</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />(very useful for Restful API)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="67950">  <div class="votes">
    <div id="Vu67950">
    <a href="/manual/vote-note.php?id=67950&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd67950">
    <a href="/manual/vote-note.php?id=67950&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V67950" title="63% like this...">
    6
    </div>
  </div>
  <a href="#67950" class="name">
  <strong class="user"><em>heitorsiller at uol dot com dot br</em></strong></a><a class="genanchor" href="#67950"> &para;</a><div class="date" title="2006-07-07 07:55"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom67950">
<div class="phpcode"><code><span class="html">
For reading a XML stream, this will work just fine:<br /><span class="default">&lt;?php<br /><br />$arq </span><span class="keyword">= </span><span class="default">file_get_contents</span><span class="keyword">(</span><span class="string">'php://input'</span><span class="keyword">);<br /><br /></span><span class="default">?&gt;<br /></span><br />Then you can parse the XML like this:<br /><br /><span class="default">&lt;?php<br /><br />$xml </span><span class="keyword">= </span><span class="default">xml_parser_create</span><span class="keyword">();<br /><br /></span><span class="default">xml_parse_into_struct</span><span class="keyword">(</span><span class="default">$xml</span><span class="keyword">, </span><span class="default">$arq</span><span class="keyword">, </span><span class="default">$vs</span><span class="keyword">);<br /><br /></span><span class="default">xml_parser_free</span><span class="keyword">(</span><span class="default">$xml</span><span class="keyword">);<br /><br /></span><span class="default">$data </span><span class="keyword">= </span><span class="string">""</span><span class="keyword">;<br /><br />foreach(</span><span class="default">$vs </span><span class="keyword">as </span><span class="default">$v</span><span class="keyword">){<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">$v</span><span class="keyword">[</span><span class="string">'level'</span><span class="keyword">] == </span><span class="default">3 </span><span class="keyword">&amp;&amp; </span><span class="default">$v</span><span class="keyword">[</span><span class="string">'type'</span><span class="keyword">] == </span><span class="string">'complete'</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$data </span><span class="keyword">.= </span><span class="string">"\n"</span><span class="keyword">.</span><span class="default">$v</span><span class="keyword">[</span><span class="string">'tag'</span><span class="keyword">].</span><span class="string">" -&gt; "</span><span class="keyword">.</span><span class="default">$v</span><span class="keyword">[</span><span class="string">'value'</span><span class="keyword">];<br />}<br /><br />echo </span><span class="default">$data</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;<br /></span><br />PS.: This is particularly useful for receiving mobile originated (MO) SMS messages from cellular phone companies.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="35009">  <div class="votes">
    <div id="Vu35009">
    <a href="/manual/vote-note.php?id=35009&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd35009">
    <a href="/manual/vote-note.php?id=35009&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V35009" title="59% like this...">
    7
    </div>
  </div>
  <a href="#35009" class="name">
  <strong class="user"><em>sam at bigwig dot net</em></strong></a><a class="genanchor" href="#35009"> &para;</a><div class="date" title="2003-08-15 08:02"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom35009">
<div class="phpcode"><code><span class="html">
[ Editor's Note: There is a way to know.&nbsp; All response headers (from both the final responding server and intermediate redirecters) can be found in $http_response_header or stream_get_meta_data() as described above. ]<br /><br />If you open an HTTP url and the server issues a Location style redirect, the redirected contents will be read but you can't find out that this has happened.<br /><br />So if you then parse the returned html and try and rationalise relative URLs you could get it wrong.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="109657">  <div class="votes">
    <div id="Vu109657">
    <a href="/manual/vote-note.php?id=109657&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd109657">
    <a href="/manual/vote-note.php?id=109657&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V109657" title="58% like this...">
    4
    </div>
  </div>
  <a href="#109657" class="name">
  <strong class="user"><em>php at rapsys dot eu</em></strong></a><a class="genanchor" href="#109657"> &para;</a><div class="date" title="2012-08-06 02:00"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom109657">
<div class="phpcode"><code><span class="html">
Here is a snippet to read compressed raw post data without enabling global variables.<br /><br />I needed it to read xml posted data submitted by ocs agent. The data was sent as Content-Type: application/x-compressed (zlib compressed data).<br /><br />It seems related to an old bug which still seems broken :<br /><a href="https://bugs.php.net/bug.php?id=49411" rel="nofollow" target="_blank">https://bugs.php.net/bug.php?id=49411</a><br /><br />The important part is the default window set to 15 instead of -15.<br /><br />Code snippet<br /><span class="default">&lt;?php<br />$data </span><span class="keyword">= </span><span class="string">''</span><span class="keyword">;<br /></span><span class="default">$fh </span><span class="keyword">= </span><span class="default">fopen</span><span class="keyword">(</span><span class="string">'php://input'</span><span class="keyword">, </span><span class="string">'rb'</span><span class="keyword">);<br /></span><span class="default">stream_filter_append</span><span class="keyword">(</span><span class="default">$fh</span><span class="keyword">, </span><span class="string">'zlib.inflate'</span><span class="keyword">, </span><span class="default">STREAM_FILTER_READ</span><span class="keyword">, array(</span><span class="string">'window'</span><span class="keyword">=&gt;</span><span class="default">15</span><span class="keyword">));<br />while(!</span><span class="default">feof</span><span class="keyword">(</span><span class="default">$fh</span><span class="keyword">)) {<br />&nbsp; &nbsp; </span><span class="default">$data </span><span class="keyword">.= </span><span class="default">fread</span><span class="keyword">(</span><span class="default">$fh</span><span class="keyword">, </span><span class="default">8192</span><span class="keyword">);<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="112027">  <div class="votes">
    <div id="Vu112027">
    <a href="/manual/vote-note.php?id=112027&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd112027">
    <a href="/manual/vote-note.php?id=112027&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V112027" title="57% like this...">
    4
    </div>
  </div>
  <a href="#112027" class="name">
  <strong class="user"><em>Justin Megawarne</em></strong></a><a class="genanchor" href="#112027"> &para;</a><div class="date" title="2013-04-23 04:42"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom112027">
<div class="phpcode"><code><span class="html">
If my understanding of the implementing code is correct, every time you open a php://memory stream, you get new storage allocated. That is to say, php://memory isn't a shared bank of memory.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118742">  <div class="votes">
    <div id="Vu118742">
    <a href="/manual/vote-note.php?id=118742&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118742">
    <a href="/manual/vote-note.php?id=118742&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118742" title="58% like this...">
    3
    </div>
  </div>
  <a href="#118742" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#118742"> &para;</a><div class="date" title="2016-01-28 08:58"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom118742">
<div class="phpcode"><code><span class="html">
Note that STDIN and similar are defined only in CLI</span>
</code></div>
  </div>
 </div>
  <div class="note" id="77169">  <div class="votes">
    <div id="Vu77169">
    <a href="/manual/vote-note.php?id=77169&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd77169">
    <a href="/manual/vote-note.php?id=77169&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V77169" title="57% like this...">
    4
    </div>
  </div>
  <a href="#77169" class="name">
  <strong class="user"><em>jerry at gii dot co dot jp</em></strong></a><a class="genanchor" href="#77169"> &para;</a><div class="date" title="2007-08-17 10:11"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom77169">
<div class="phpcode"><code><span class="html">
Not only are STDIN, STDOUT, and STDERR only allowed for CLI programs, but they are not allowed for programs that are read from STDIN. That can confuse you if you try to type in a simple test program.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="69277">  <div class="votes">
    <div id="Vu69277">
    <a href="/manual/vote-note.php?id=69277&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd69277">
    <a href="/manual/vote-note.php?id=69277&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V69277" title="57% like this...">
    4
    </div>
  </div>
  <a href="#69277" class="name">
  <strong class="user"><em>ben dot johansen at gmail dot com</em></strong></a><a class="genanchor" href="#69277"> &para;</a><div class="date" title="2006-08-29 11:02"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom69277">
<div class="phpcode"><code><span class="html">
Example of how to use the php://input to get raw post data<br /><br />//read the raw data in<br />$roughHTTPPOST = file_get_contents("php://input"); <br />//parse it into vars<br />parse_str($roughHTTPPOST);<br /><br />if you do readfile("php://input") you will get the length of the post data</span>
</code></div>
  </div>
 </div>
  <div class="note" id="105029">  <div class="votes">
    <div id="Vu105029">
    <a href="/manual/vote-note.php?id=105029&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd105029">
    <a href="/manual/vote-note.php?id=105029&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V105029" title="54% like this...">
    4
    </div>
  </div>
  <a href="#105029" class="name">
  <strong class="user"><em>leonid at shagabutdinov dot com</em></strong></a><a class="genanchor" href="#105029"> &para;</a><div class="date" title="2011-07-22 09:45"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom105029">
<div class="phpcode"><code><span class="html">
For https for windows enable this extension:<br /><br />extension=php_openssl.dll</span>
</code></div>
  </div>
 </div>
  <div class="note" id="37842">  <div class="votes">
    <div id="Vu37842">
    <a href="/manual/vote-note.php?id=37842&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd37842">
    <a href="/manual/vote-note.php?id=37842&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V37842" title="57% like this...">
    3
    </div>
  </div>
  <a href="#37842" class="name">
  <strong class="user"><em>lupti at yahoo dot com</em></strong></a><a class="genanchor" href="#37842"> &para;</a><div class="date" title="2003-11-29 02:04"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom37842">
<div class="phpcode"><code><span class="html">
I find using file_get_contents with php://input is very handy and efficient. Here is the code:<br /><br />$request = "";<br />$request = file_get_contents("php://input");<br /><br />I don't need to declare the URL filr string as "r". It automatically handles open the file with read.<br /><br />I can then use this $request string to your XMLparser as data.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="108918">  <div class="votes">
    <div id="Vu108918">
    <a href="/manual/vote-note.php?id=108918&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd108918">
    <a href="/manual/vote-note.php?id=108918&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V108918" title="54% like this...">
    3
    </div>
  </div>
  <a href="#108918" class="name">
  <strong class="user"><em>aaron dot mason+php at thats-too-much dot info</em></strong></a><a class="genanchor" href="#108918"> &para;</a><div class="date" title="2012-06-05 01:46"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom108918">
<div class="phpcode"><code><span class="html">
Be aware of code injection, folks - like anything else you take from the user, SANITISE IT FIRST.&nbsp; This cannot be stressed enough - if I had a dollar for each time I saw code where form input was taken and directly used (by myself as well, I've been stupid too) I'd probably own PHP.&nbsp; While using data from a form in a URL wrapper is asking for trouble, you can greatly minimise the trouble by making sure your inputs are sane and not likely to provide an opening for the LulzSec of the world to cause havoc.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="59151">  <div class="votes">
    <div id="Vu59151">
    <a href="/manual/vote-note.php?id=59151&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd59151">
    <a href="/manual/vote-note.php?id=59151&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V59151" title="55% like this...">
    3
    </div>
  </div>
  <a href="#59151" class="name">
  <strong class="user"><em>nyvsld at gmail dot com</em></strong></a><a class="genanchor" href="#59151"> &para;</a><div class="date" title="2005-11-27 10:28"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom59151">
<div class="phpcode"><code><span class="html">
php://stdin supports fseek() and fstat() function call, <br />while php://input doesn't.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="115688">  <div class="votes">
    <div id="Vu115688">
    <a href="/manual/vote-note.php?id=115688&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115688">
    <a href="/manual/vote-note.php?id=115688&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115688" title="55% like this...">
    2
    </div>
  </div>
  <a href="#115688" class="name">
  <strong class="user"><em>vibhavsinha91 at gmail dot com</em></strong></a><a class="genanchor" href="#115688"> &para;</a><div class="date" title="2014-09-08 10:35"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115688">
<div class="phpcode"><code><span class="html">
While writing to error stream, error_log() function comes as a shorthand to writing to php://stderr . This function also allows writing to web server log when running through a web server such as apache.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="102269">  <div class="votes">
    <div id="Vu102269">
    <a href="/manual/vote-note.php?id=102269&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd102269">
    <a href="/manual/vote-note.php?id=102269&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V102269" title="56% like this...">
    2
    </div>
  </div>
  <a href="#102269" class="name">
  <strong class="user"><em>sebastian dot krebs at kingcrunch dot de</em></strong></a><a class="genanchor" href="#102269"> &para;</a><div class="date" title="2011-02-04 04:49"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom102269">
<div class="phpcode"><code><span class="html">
The stream php://temp/maxmemory:$limit stores the data in memory unless the limit is reached. Then it will write the whole content the a temporary file and frees the memory. I didnt found a way to get at least some of the data back to memory.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="69255">  <div class="votes">
    <div id="Vu69255">
    <a href="/manual/vote-note.php?id=69255&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd69255">
    <a href="/manual/vote-note.php?id=69255&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V69255" title="54% like this...">
    3
    </div>
  </div>
  <a href="#69255" class="name">
  <strong class="user"><em>ben dot johansen at gmail dot com</em></strong></a><a class="genanchor" href="#69255"> &para;</a><div class="date" title="2006-08-29 12:33"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom69255">
<div class="phpcode"><code><span class="html">
In trying to do AJAX with PHP and Javascript, I came upon an issue where the POST argument from the following javascript could not be read in via PHP 5 using the $_REQUEST or $_POST. I finally figured out how to read in the raw data using the php://input directive.<br />&nbsp; &nbsp; <br />Javascript code:<br />=============<br />&nbsp; &nbsp; &nbsp; //create request instance&nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; xhttp = new XMLHttpRequest();<br />&nbsp; &nbsp; &nbsp; // set the event handler<br />&nbsp; &nbsp; &nbsp; xhttp.onreadystatechange = serviceReturn;<br />&nbsp; &nbsp; &nbsp; // prep the call, http method=POST, true=asynchronous call<br />&nbsp; &nbsp; &nbsp; var Args = 'number='+NbrValue;<br />&nbsp; &nbsp; &nbsp; xhttp.open("POST", "<a href="http://" rel="nofollow" target="_blank">http://</a><span class="default">&lt;?php </span><span class="keyword">echo </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'SERVER_NAME'</span><span class="keyword">] </span><span class="default">?&gt;</span>/webservices/ws_service.php", true);<br />&nbsp; &nbsp; &nbsp; // send the call with args<br />&nbsp; &nbsp; &nbsp; xhttp.send(Args);<br /><br />PHP Code:<br />&nbsp; &nbsp; //read the raw data in<br />&nbsp; &nbsp; $roughHTTPPOST = file_get_contents("php://input"); <br />&nbsp; &nbsp; //parse it into vars<br />&nbsp; &nbsp; parse_str($roughHTTPPOST);</span>
</code></div>
  </div>
 </div>
  <div class="note" id="108529">  <div class="votes">
    <div id="Vu108529">
    <a href="/manual/vote-note.php?id=108529&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd108529">
    <a href="/manual/vote-note.php?id=108529&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V108529" title="55% like this...">
    2
    </div>
  </div>
  <a href="#108529" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#108529"> &para;</a><div class="date" title="2012-05-04 07:00"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom108529">
<div class="phpcode"><code><span class="html">
For php://filter the /resource=foo part must come last. And foo needs no escaping at all.<br />php://filter/resource=foo/read=somefilter would try to open a file 'foo/read=somefilter' while php://filter/read=somefilter/resource=foo will open file 'foo' with the somefilter filter applied.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="42722">  <div class="votes">
    <div id="Vu42722">
    <a href="/manual/vote-note.php?id=42722&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd42722">
    <a href="/manual/vote-note.php?id=42722&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V42722" title="56% like this...">
    2
    </div>
  </div>
  <a href="#42722" class="name">
  <strong class="user"><em>aidan at php dot net</em></strong></a><a class="genanchor" href="#42722"> &para;</a><div class="date" title="2004-05-27 03:34"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom42722">
<div class="phpcode"><code><span class="html">
The contants:<br /><br />* STDIN<br />* STDOUT<br />* STDERR<br /><br />Were introduced in PHP 4.3.0 and are synomous with the fopen('php://stdx') result resource.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="45947">  <div class="votes">
    <div id="Vu45947">
    <a href="/manual/vote-note.php?id=45947&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd45947">
    <a href="/manual/vote-note.php?id=45947&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V45947" title="52% like this...">
    2
    </div>
  </div>
  <a href="#45947" class="name">
  <strong class="user"><em>nargy at yahoo dot com</em></strong></a><a class="genanchor" href="#45947"> &para;</a><div class="date" title="2004-09-24 03:16"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom45947">
<div class="phpcode"><code><span class="html">
When opening php://output in append mode you get an error, the way to do it:<br />$fp=fopen("php://output","w");<br />fwrite($fp,"Hello, world !&lt;BR&gt;\n");<br />fclose($fp);</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114380">  <div class="votes">
    <div id="Vu114380">
    <a href="/manual/vote-note.php?id=114380&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114380">
    <a href="/manual/vote-note.php?id=114380&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114380" title="51% like this...">
    1
    </div>
  </div>
  <a href="#114380" class="name">
  <strong class="user"><em>oliver at codeinline dot com</em></strong></a><a class="genanchor" href="#114380"> &para;</a><div class="date" title="2014-02-13 07:14"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114380">
<div class="phpcode"><code><span class="html">
A useful way to handle large file uploads is to do something like:<br /><br />copy(("php://input"),$tmpfile);<br /><br />as this avoids using lots of memory just to buffer the file content.<br /><br />The correct mime type for this should be "application/octet-stream" however if you set this or any other recognised mime type other than "multipart/form-data" on your POST then $HTTP_RAW_POST_DATA is populated and the memory is consumed anyway. <br /><br />Setting the mime type to "multipart/form-data" raises “PHP Warning:&nbsp; Missing boundary in multipart/form-data POST data in Unknown on line 0” however it seems to work without a problem.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="70739">  <div class="votes">
    <div id="Vu70739">
    <a href="/manual/vote-note.php?id=70739&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd70739">
    <a href="/manual/vote-note.php?id=70739&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V70739" title="51% like this...">
    1
    </div>
  </div>
  <a href="#70739" class="name">
  <strong class="user"><em>ben dot johansen at gmail dot com</em></strong></a><a class="genanchor" href="#70739"> &para;</a><div class="date" title="2006-10-25 02:57"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom70739">
<div class="phpcode"><code><span class="html">
followup:<br /><br />I found that if I added this line to the AJAX call, the values would show up in the $_POST<br /><br />xhttp.setRequestHeader('Content-Type',<br />'application/x-www-form-urlencoded');</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121519">  <div class="votes">
    <div id="Vu121519">
    <a href="/manual/vote-note.php?id=121519&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121519">
    <a href="/manual/vote-note.php?id=121519&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121519" title="50% like this...">
    0
    </div>
  </div>
  <a href="#121519" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#121519"> &para;</a><div class="date" title="2017-08-13 12:37"><strong>4 months ago</strong></div>
  <div class="text" id="Hcom121519">
<div class="phpcode"><code><span class="html">
If you want to filter incoming data through php://input use this:<br /><br />file_get_contents("php://filter/read=string.strip_tags/resource=php://input");<br /><br />I couldn't find any documentation to explain how to do this. All the examples I came across suggested that a full and actual URL had to be used (which didn't work for me).<br /><br />This seems to work though.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121410">  <div class="votes">
    <div id="Vu121410">
    <a href="/manual/vote-note.php?id=121410&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121410">
    <a href="/manual/vote-note.php?id=121410&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121410" title="50% like this...">
    0
    </div>
  </div>
  <a href="#121410" class="name">
  <strong class="user"><em>John Edwards</em></strong></a><a class="genanchor" href="#121410"> &para;</a><div class="date" title="2017-07-21 10:58"><strong>4 months ago</strong></div>
  <div class="text" id="Hcom121410">
<div class="phpcode"><code><span class="html">
Please note that php://input is only functional if "allow_url_include" is set to "On" in php.ini file. <br /><br />Apache generates a warning by default in the error.log as follows if allow_url_include is not set to "On":<br /><br />"PHP Warning:&nbsp; include(): Failed opening 'php://input' for inclusion (include_path='.:/usr/share/php:/usr/share/pear', ....) ...."</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118262">  <div class="votes">
    <div id="Vu118262">
    <a href="/manual/vote-note.php?id=118262&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118262">
    <a href="/manual/vote-note.php?id=118262&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118262" title="50% like this...">
    0
    </div>
  </div>
  <a href="#118262" class="name">
  <strong class="user"><em>ohcc at 163 dot com</em></strong></a><a class="genanchor" href="#118262"> &para;</a><div class="date" title="2015-11-05 06:45"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom118262">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="comment">//enable $HTTP_RAW_POST_DATA when necessary<br />&nbsp; &nbsp; </span><span class="default">ini_set</span><span class="keyword">(</span><span class="string">'always_populate_raw_post_data'</span><span class="keyword">,-</span><span class="default">1</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$HTTP_RAW_POST_DATA </span><span class="keyword">= </span><span class="default">file_get_contents</span><span class="keyword">(</span><span class="string">'php://input'</span><span class="keyword">);<br />&nbsp; &nbsp; echo </span><span class="default">$HTTP_RAW_POST_DATA</span><span class="keyword">;<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="52272">  <div class="votes">
    <div id="Vu52272">
    <a href="/manual/vote-note.php?id=52272&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd52272">
    <a href="/manual/vote-note.php?id=52272&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V52272" title="47% like this...">
    -1
    </div>
  </div>
  <a href="#52272" class="name">
  <strong class="user"><em>chris at free-source dot com</em></strong></a><a class="genanchor" href="#52272"> &para;</a><div class="date" title="2005-04-26 12:52"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom52272">
<div class="phpcode"><code><span class="html">
If you're looking for a unix based smb wrapper there isn't one built in,&nbsp; but I've had luck with <a href="http://www.zevils.com/cgi-bin/viewcvs.cgi/libsmbclient-php/" rel="nofollow" target="_blank">http://www.zevils.com/cgi-bin/viewcvs.cgi/libsmbclient-php/</a> (tarball link at the end).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="112334">  <div class="votes">
    <div id="Vu112334">
    <a href="/manual/vote-note.php?id=112334&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd112334">
    <a href="/manual/vote-note.php?id=112334&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V112334" title="47% like this...">
    -2
    </div>
  </div>
  <a href="#112334" class="name">
  <strong class="user"><em>dave at 4mation dot com dot au</em></strong></a><a class="genanchor" href="#112334"> &para;</a><div class="date" title="2013-06-03 04:46"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom112334">
<div class="phpcode"><code><span class="html">
The use of php://temp/maxmemory as a stream counts towards the memory usage of the script; you are not specifying a new memory pool by using this type of stream.<br />As noted in the documentation however, this stream type will start to write to a file after the specified maxmemory limit is exceeded. This file buffer is NOT observed by the memory limit.<br />This is handy if you want your script to have a reasonably small memory limit (eg 32MB) but but still be able to handle a huge amount of data in a stream (eg 256MB)<br /><br />The only works if you use stream functions like fputs(); if you use $buffer .= 'string'; or $buffer = $buffer . 'string'; you're calling your stream data back into PHP and this will hit the limiter.<br /><br />As a practical example:<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">// 0.5MB memory limit<br /></span><span class="default">ini_set</span><span class="keyword">(</span><span class="string">'memory_limit'</span><span class="keyword">, </span><span class="string">'0.5M'</span><span class="keyword">);<br /></span><span class="comment">// 2MB stream limit<br /></span><span class="default">$buffer </span><span class="keyword">= </span><span class="default">fopen</span><span class="keyword">(</span><span class="string">'php://temp/maxmemory:1048576'</span><span class="keyword">, </span><span class="string">'r+'</span><span class="keyword">);<br /></span><span class="default">$x </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br /></span><span class="comment">// Attempt to write 1MB to the stream<br /></span><span class="keyword">while (</span><span class="default">$x </span><span class="keyword">&lt; </span><span class="default">1</span><span class="keyword">*</span><span class="default">1024</span><span class="keyword">*</span><span class="default">1024</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">fputs</span><span class="keyword">(</span><span class="default">$buffer</span><span class="keyword">, </span><span class="string">'a'</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$x</span><span class="keyword">++;<br />}<br />echo </span><span class="string">"This will never be displayed"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />However, change fopen to use php://temp/maxmemory:1 (one byte, rather than one megabyte) and it will begin writing to the unlimited file stream immediately, avoiding memory limit errors.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114957">  <div class="votes">
    <div id="Vu114957">
    <a href="/manual/vote-note.php?id=114957&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114957">
    <a href="/manual/vote-note.php?id=114957&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114957" title="45% like this...">
    -2
    </div>
  </div>
  <a href="#114957" class="name">
  <strong class="user"><em>Chris</em></strong></a><a class="genanchor" href="#114957"> &para;</a><div class="date" title="2014-05-05 03:30"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114957">
<div class="phpcode"><code><span class="html">
If you use php://input and want to make an array of it (like $_POST), make sure you explode the string by "&amp;" then urldecode it or you could end up with blank array elements.&nbsp; E.g. <br /><br /><span class="default">&lt;?php<br />$post </span><span class="keyword">= </span><span class="default">array_map</span><span class="keyword">(</span><span class="string">'urldecode'</span><span class="keyword">, </span><span class="default">explode</span><span class="keyword">(</span><span class="string">'&amp;'</span><span class="keyword">, </span><span class="default">file_get_contents</span><span class="keyword">(</span><span class="string">"php://input"</span><span class="keyword">)));</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="112090">  <div class="votes">
    <div id="Vu112090">
    <a href="/manual/vote-note.php?id=112090&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd112090">
    <a href="/manual/vote-note.php?id=112090&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V112090" title="45% like this...">
    -2
    </div>
  </div>
  <a href="#112090" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#112090"> &para;</a><div class="date" title="2013-05-01 09:17"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom112090">
<div class="phpcode"><code><span class="html">
In PHP 5.4+ you can read multipart data via php://input if you set enable_post_data_reading to Off. <br /><br />Of course if you set it to off, the $_POST and $_FILES superglobals won't be populated at all. It's entirely up to you to parse the data now.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="107973">  <div class="votes">
    <div id="Vu107973">
    <a href="/manual/vote-note.php?id=107973&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd107973">
    <a href="/manual/vote-note.php?id=107973&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V107973" title="44% like this...">
    -3
    </div>
  </div>
  <a href="#107973" class="name">
  <strong class="user"><em>Rakesh Verma [rakeshnsony at gmail dot com]</em></strong></a><a class="genanchor" href="#107973"> &para;</a><div class="date" title="2012-03-19 10:18"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom107973">
<div class="phpcode"><code><span class="html">
/**********************************/<br />Example JSON Request:<br />{<br />&nbsp; &nbsp; "username" : "rakeshnsony",<br />&nbsp; &nbsp; "password" : "abcdefg"<br />}<br />/**********************************/<br /><span class="default">&lt;?php<br /><br /></span><span class="comment">//To access json format data<br /></span><span class="default">$requestBody </span><span class="keyword">= </span><span class="default">file_get_contents</span><span class="keyword">(</span><span class="string">'php://input'</span><span class="keyword">);<br /></span><span class="default">$requestBody </span><span class="keyword">= </span><span class="default">json_decode</span><span class="keyword">(</span><span class="default">$requestBody</span><span class="keyword">);<br /><br />echo </span><span class="string">"username is: "</span><span class="keyword">.</span><span class="default">$requestBody</span><span class="keyword">-&gt;</span><span class="default">username</span><span class="keyword">;<br /><br />echo </span><span class="string">"&lt;br /&gt;&lt;br /&gt;"</span><span class="keyword">;<br /><br />echo </span><span class="string">"password is: "</span><span class="keyword">.</span><span class="default">$requestBody</span><span class="keyword">-&gt;</span><span class="default">password</span><span class="keyword">;<br /></span><span class="comment">//</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="108703">  <div class="votes">
    <div id="Vu108703">
    <a href="/manual/vote-note.php?id=108703&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd108703">
    <a href="/manual/vote-note.php?id=108703&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V108703" title="41% like this...">
    -5
    </div>
  </div>
  <a href="#108703" class="name">
  <strong class="user"><em>Toby</em></strong></a><a class="genanchor" href="#108703"> &para;</a><div class="date" title="2012-05-18 10:12"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom108703">
<div class="phpcode"><code><span class="html">
Dangerous stuff. Had php injection attacks like:<br /><br />?-dallow_url_include%253don+-dauto_prepend_file%253dphp://input<br /><br />due to this</span>
</code></div>
  </div>
 </div>
  <div class="note" id="57142">  <div class="votes">
    <div id="Vu57142">
    <a href="/manual/vote-note.php?id=57142&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd57142">
    <a href="/manual/vote-note.php?id=57142&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V57142" title="40% like this...">
    -6
    </div>
  </div>
  <a href="#57142" class="name">
  <strong class="user"><em>drewish at katherinehouse dot com</em></strong></a><a class="genanchor" href="#57142"> &para;</a><div class="date" title="2005-09-24 11:50"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom57142">
<div class="phpcode"><code><span class="html">
Be aware that contrary to the way this makes it sound, under Apache, php://output and php://stdout don't point to the same place.<br /><br /><span class="default">&lt;?php<br />$fo </span><span class="keyword">= </span><span class="default">fopen</span><span class="keyword">(</span><span class="string">'php://output'</span><span class="keyword">, </span><span class="string">'w'</span><span class="keyword">);<br /></span><span class="default">$fs </span><span class="keyword">= </span><span class="default">fopen</span><span class="keyword">(</span><span class="string">'php://stdout'</span><span class="keyword">, </span><span class="string">'w'</span><span class="keyword">);<br /><br /></span><span class="default">fputs</span><span class="keyword">(</span><span class="default">$fo</span><span class="keyword">, </span><span class="string">"You can see this with the CLI and Apache.\n"</span><span class="keyword">);<br /></span><span class="default">fputs</span><span class="keyword">(</span><span class="default">$fs</span><span class="keyword">, </span><span class="string">"This only shows up on the CLI...\n"</span><span class="keyword">);<br /><br /></span><span class="default">fclose</span><span class="keyword">(</span><span class="default">$fo</span><span class="keyword">);<br /></span><span class="default">fclose</span><span class="keyword">(</span><span class="default">$fs</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />Using the CLI you'll see:<br />&nbsp; You can see this with the CLI and Apache.<br />&nbsp; This only shows up on the CLI...<br /><br />Using the Apache SAPI you'll see:<br />&nbsp; You can see this with the CLI and Apache.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116170">  <div class="votes">
    <div id="Vu116170">
    <a href="/manual/vote-note.php?id=116170&amp;page=wrappers&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116170">
    <a href="/manual/vote-note.php?id=116170&amp;page=wrappers&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116170" title="33% like this...">
    -5
    </div>
  </div>
  <a href="#116170" class="name">
  <strong class="user"><em>nguyenanthuan at gmail dot com</em></strong></a><a class="genanchor" href="#116170"> &para;</a><div class="date" title="2014-11-18 11:05"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom116170">
<div class="phpcode"><code><span class="html">
Each stream pointer to php://memory and php://temp has its own memory allocation, so you can open many stream pointers to store your separated values.<br /><br /><span class="default">&lt;?php<br />$fp </span><span class="keyword">= </span><span class="default">fopen</span><span class="keyword">(</span><span class="string">"php://temp"</span><span class="keyword">, </span><span class="string">"r+"</span><span class="keyword">);<br /></span><span class="default">$fp2 </span><span class="keyword">= </span><span class="default">fopen</span><span class="keyword">(</span><span class="string">"php://temp"</span><span class="keyword">, </span><span class="string">"r+"</span><span class="keyword">);<br /><br /></span><span class="default">fwrite</span><span class="keyword">(</span><span class="default">$fp</span><span class="keyword">, </span><span class="string">"line1\n"</span><span class="keyword">);<br /></span><span class="default">fwrite</span><span class="keyword">(</span><span class="default">$fp2</span><span class="keyword">, </span><span class="string">"line4\n"</span><span class="keyword">);<br /></span><span class="default">fwrite</span><span class="keyword">(</span><span class="default">$fp</span><span class="keyword">, </span><span class="string">"line2\n"</span><span class="keyword">);<br /></span><span class="default">fwrite</span><span class="keyword">(</span><span class="default">$fp2</span><span class="keyword">, </span><span class="string">"line5\n"</span><span class="keyword">);<br /></span><span class="default">fwrite</span><span class="keyword">(</span><span class="default">$fp</span><span class="keyword">, </span><span class="string">"line3\n"</span><span class="keyword">);<br /></span><span class="default">fwrite</span><span class="keyword">(</span><span class="default">$fp2</span><span class="keyword">, </span><span class="string">"line6\n"</span><span class="keyword">);<br /><br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">memory_get_usage</span><span class="keyword">());<br /><br /></span><span class="default">rewind</span><span class="keyword">(</span><span class="default">$fp</span><span class="keyword">);<br />while(!</span><span class="default">feof</span><span class="keyword">(</span><span class="default">$fp</span><span class="keyword">)) {<br />&nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">fread</span><span class="keyword">(</span><span class="default">$fp</span><span class="keyword">, </span><span class="default">1024</span><span class="keyword">));<br />}<br /></span><span class="default">fclose</span><span class="keyword">(</span><span class="default">$fp</span><span class="keyword">);<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">memory_get_usage</span><span class="keyword">());<br /><br /></span><span class="default">rewind</span><span class="keyword">(</span><span class="default">$fp2</span><span class="keyword">);<br />while(!</span><span class="default">feof</span><span class="keyword">(</span><span class="default">$fp2</span><span class="keyword">)) {<br />&nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">fread</span><span class="keyword">(</span><span class="default">$fp2</span><span class="keyword">, </span><span class="default">1024</span><span class="keyword">));<br />}<br /></span><span class="default">fclose</span><span class="keyword">(</span><span class="default">$fp2</span><span class="keyword">);<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">memory_get_usage</span><span class="keyword">());<br /></span><span class="default">?&gt;<br /></span><br />Closing their stream handles will also free the allocated memory.<br /><br />php://memory stream type is MEMORY, while php://temp stream type is STDIO FILE*.</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=wrappers&amp;redirect=http://php.net/manual/en/wrappers.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="langref.php">Language Reference</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.basic-syntax.php" title="Basic syntax">Basic syntax</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.php" title="Types">Types</a>
                        </li>
                          
                        <li class="">
                            <a href="language.variables.php" title="Variables">Variables</a>
                        </li>
                          
                        <li class="">
                            <a href="language.constants.php" title="Constants">Constants</a>
                        </li>
                          
                        <li class="">
                            <a href="language.expressions.php" title="Expressions">Expressions</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.php" title="Operators">Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.control-structures.php" title="Control Structures">Control Structures</a>
                        </li>
                          
                        <li class="">
                            <a href="language.functions.php" title="Functions">Functions</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.php" title="Classes and Objects">Classes and Objects</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.php" title="Namespaces">Namespaces</a>
                        </li>
                          
                        <li class="">
                            <a href="language.errors.php" title="Errors">Errors</a>
                        </li>
                          
                        <li class="">
                            <a href="language.exceptions.php" title="Exceptions">Exceptions</a>
                        </li>
                          
                        <li class="">
                            <a href="language.generators.php" title="Generators">Generators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.references.php" title="References Explained">References Explained</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.php" title="Predefined Variables">Predefined Variables</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.exceptions.php" title="Predefined Exceptions">Predefined Exceptions</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.interfaces.php" title="Predefined Interfaces and Classes">Predefined Interfaces and Classes</a>
                        </li>
                          
                        <li class="">
                            <a href="context.php" title="Context options and parameters">Context options and parameters</a>
                        </li>
                          
                        <li class="current">
                            <a href="wrappers.php" title="Supported Protocols and Wrappers">Supported Protocols and Wrappers</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

