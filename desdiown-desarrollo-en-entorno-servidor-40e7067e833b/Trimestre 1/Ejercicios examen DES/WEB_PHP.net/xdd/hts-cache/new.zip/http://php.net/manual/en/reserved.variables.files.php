<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: $_FILES - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/reserved.variables.files.php">
 <link rel="shorturl" href="http://php.net/manual/en/reserved.variables.files.php">
 <link rel="alternate" href="http://php.net/manual/en/reserved.variables.files.php" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/reserved.variables.php">
 <link rel="prev" href="http://php.net/manual/en/reserved.variables.post.php">
 <link rel="next" href="http://php.net/manual/en/reserved.variables.request.php">

 <link rel="alternate" href="http://php.net/manual/en/reserved.variables.files.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/reserved.variables.files.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/reserved.variables.files.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/reserved.variables.files.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/reserved.variables.files.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/reserved.variables.files.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/reserved.variables.files.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/reserved.variables.files.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/reserved.variables.files.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/reserved.variables.files.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/reserved.variables.files.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="reserved.variables.request.php">
          $_REQUEST &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="reserved.variables.post.php">
          &laquo; $_POST        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='reserved.variables.php'>Predefined Variables</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/reserved.variables.files.php' selected="selected">English</option>
            <option value='pt_BR/reserved.variables.files.php'>Brazilian Portuguese</option>
            <option value='zh/reserved.variables.files.php'>Chinese (Simplified)</option>
            <option value='fr/reserved.variables.files.php'>French</option>
            <option value='de/reserved.variables.files.php'>German</option>
            <option value='ja/reserved.variables.files.php'>Japanese</option>
            <option value='ro/reserved.variables.files.php'>Romanian</option>
            <option value='ru/reserved.variables.files.php'>Russian</option>
            <option value='es/reserved.variables.files.php'>Spanish</option>
            <option value='tr/reserved.variables.files.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/reserved.variables.files.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=reserved.variables.files">Report a Bug</a>
    </div>
  </div><div id="reserved.variables.files" class="refentry">
 <div class="refnamediv">
  <h1 class="refname">$_FILES</h1>
  <h1 class="refname">$HTTP_POST_FILES [deprecated]</h1>
  <p class="verinfo">(PHP 4 &gt;= 4.1.0, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">$_FILES</span> -- <span class="refname">$HTTP_POST_FILES [deprecated]</span> &mdash; <span class="dc-title">HTTP File Upload variables</span></p>

 </div>
 
 <div class="refsect1 description" id="refsect1-reserved.variables.files-description">
  <h3 class="title">Description</h3>
  <p class="para">
   An associative <span class="type"><a href="language.types.array.php" class="type array">array</a></span> of items uploaded to the current script
   via the HTTP POST method. The structure of this array is outlined in the
   <a href="features.file-upload.post-method.php" class="link">POST method uploads</a>
   section.
  </p>

  <p class="simpara">
   <var class="varname"><var class="varname">$HTTP_POST_FILES</var></var> contains the same initial
   information, but is not a <a href="language.variables.superglobals.php" class="link">superglobal</a>. 
   (Note that <var class="varname"><var class="varname">$HTTP_POST_FILES</var></var> and <var class="varname"><var class="varname">$_FILES</var></var>
   are different variables and that PHP handles them as such)
  </p>

 </div>

 

 <div class="refsect1 changelog" id="refsect1-reserved.variables.files-changelog">
  <h3 class="title">Changelog</h3>
  <p class="para">
   <table class="doctable informaltable">
    
     <thead>
      <tr>
       <th>Version</th>
       <th>Description</th>
      </tr>

     </thead>

     <tbody class="tbody">
      <tr>
       <td>4.1.0</td>
       <td>
        Introduced <var class="varname"><var class="varname">$_FILES</var></var> that deprecated
        <var class="varname"><var class="varname">$HTTP_POST_FILES</var></var>.
       </td>
      </tr>

     </tbody>
    
   </table>

  </p>
 </div>

 
 <div class="refsect1 notes" id="refsect1-reserved.variables.files-notes">
  <h3 class="title">Notes</h3>
  <blockquote class="note"><p><strong class="note">Note</strong>: <p class="para">This is a &#039;superglobal&#039;, or
automatic global, variable. This simply means that it is available in
all scopes throughout a script. There is no need to do
<strong class="command">global $variable;</strong> to access it within functions or methods.
</p></p></blockquote>
 </div>


 <div class="refsect1 seealso" id="refsect1-reserved.variables.files-seealso">
  <h3 class="title">See Also</h3>
  <p class="para">
   <ul class="simplelist">
    <li class="member"><span class="function"><a href="function.move-uploaded-file.php" class="function" rel="rdfs-seeAlso">move_uploaded_file()</a> - Moves an uploaded file to a new location</span></li>
    <li class="member"><a href="features.file-upload.php" class="link">Handling File Uploads</a></li>
   </ul>
  </p>
 </div>


</div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=reserved.variables.files&amp;redirect=http://php.net/manual/en/reserved.variables.files.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">27 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="116149">  <div class="votes">
    <div id="Vu116149">
    <a href="/manual/vote-note.php?id=116149&amp;page=reserved.variables.files&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116149">
    <a href="/manual/vote-note.php?id=116149&amp;page=reserved.variables.files&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116149" title="91% like this...">
    487
    </div>
  </div>
  <a href="#116149" class="name">
  <strong class="user"><em>scohen987 at gmail dot com</em></strong></a><a class="genanchor" href="#116149"> &para;</a><div class="date" title="2014-11-14 09:49"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom116149">
<div class="phpcode"><code><span class="html">
see <a href="http://php.net/manual/en/features.file-upload.post-method.php" rel="nofollow" target="_blank">http://php.net/manual/en/features.file-upload.post-method.php</a> for documentation of the $_FILES array, which is what I came to this page for in the first place.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114644">  <div class="votes">
    <div id="Vu114644">
    <a href="/manual/vote-note.php?id=114644&amp;page=reserved.variables.files&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114644">
    <a href="/manual/vote-note.php?id=114644&amp;page=reserved.variables.files&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114644" title="68% like this...">
    36
    </div>
  </div>
  <a href="#114644" class="name">
  <strong class="user"><em>brian at diamondsea dot com</em></strong></a><a class="genanchor" href="#114644"> &para;</a><div class="date" title="2014-03-16 06:11"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114644">
<div class="phpcode"><code><span class="html">
If you are looking for the $_FILES['error'] code explanations, be sure to read:<br /><br />Handling File Uploads - Error Messages Explained<br /><a href="http://www.php.net/manual/en/features.file-upload.errors.php" rel="nofollow" target="_blank">http://www.php.net/manual/en/features.file-upload.errors.php</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="89674">  <div class="votes">
    <div id="Vu89674">
    <a href="/manual/vote-note.php?id=89674&amp;page=reserved.variables.files&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd89674">
    <a href="/manual/vote-note.php?id=89674&amp;page=reserved.variables.files&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V89674" title="62% like this...">
    29
    </div>
  </div>
  <a href="#89674" class="name">
  <strong class="user"><em>dewi at dewimorgan dot com</em></strong></a><a class="genanchor" href="#89674"> &para;</a><div class="date" title="2009-03-18 10:35"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom89674">
<div class="phpcode"><code><span class="html">
The format of this array is (assuming your form has two input type=file fields named "file1", "file2", etc):<br /><br />Array<br />(<br />&nbsp; &nbsp; [file1] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [name] =&gt; MyFile.txt (comes from the browser, so treat as tainted)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [type] =&gt; text/plain&nbsp; (not sure where it gets this from - assume the browser, so treat as tainted)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [tmp_name] =&gt; /tmp/php/php1h4j1o (could be anywhere on your system, depending on your config settings, but the user has no control, so this isn't tainted)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [error] =&gt; UPLOAD_ERR_OK&nbsp; (= 0)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [size] =&gt; 123&nbsp;&nbsp; (the size in bytes)<br />&nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />&nbsp; &nbsp; [file2] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [name] =&gt; MyFile.jpg<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [type] =&gt; image/jpeg<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [tmp_name] =&gt; /tmp/php/php6hst32<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [error] =&gt; UPLOAD_ERR_OK<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [size] =&gt; 98174<br />&nbsp; &nbsp; &nbsp; &nbsp; )<br />)<br /><br />Last I checked (a while ago now admittedly), if you use array parameters in your forms (that is, form names ending in square brackets, like several file fields called "download[file1]", "download[file2]" etc), then the array format becomes... interesting.<br /><br />Array<br />(<br />&nbsp; &nbsp; [download] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [name] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [file1] =&gt; MyFile.txt<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [file2] =&gt; MyFile.jpg<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [type] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [file1] =&gt; text/plain<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [file2] =&gt; image/jpeg<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [tmp_name] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [file1] =&gt; /tmp/php/php1h4j1o<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [file2] =&gt; /tmp/php/php6hst32<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [error] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [file1] =&gt; UPLOAD_ERR_OK<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [file2] =&gt; UPLOAD_ERR_OK<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [size] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [file1] =&gt; 123<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [file2] =&gt; 98174<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; )<br />&nbsp; &nbsp; &nbsp; &nbsp; )<br />)<br /><br />So you'd need to access the error param of file1 as, eg $_Files['download']['error']['file1']</span>
</code></div>
  </div>
 </div>
  <div class="note" id="109958">  <div class="votes">
    <div id="Vu109958">
    <a href="/manual/vote-note.php?id=109958&amp;page=reserved.variables.files&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd109958">
    <a href="/manual/vote-note.php?id=109958&amp;page=reserved.variables.files&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V109958" title="59% like this...">
    52
    </div>
  </div>
  <a href="#109958" class="name">
  <strong class="user"><em>sergio_ag at terra dot com dot br</em></strong></a><a class="genanchor" href="#109958"> &para;</a><div class="date" title="2012-09-05 08:09"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom109958">
<div class="phpcode"><code><span class="html">
A nice trick to reorder the $_FILES array when you use a input name as array is:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">diverse_array</span><span class="keyword">(</span><span class="default">$vector</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$result </span><span class="keyword">= array();<br />&nbsp; &nbsp; foreach(</span><span class="default">$vector </span><span class="keyword">as </span><span class="default">$key1 </span><span class="keyword">=&gt; </span><span class="default">$value1</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach(</span><span class="default">$value1 </span><span class="keyword">as </span><span class="default">$key2 </span><span class="keyword">=&gt; </span><span class="default">$value2</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$result</span><span class="keyword">[</span><span class="default">$key2</span><span class="keyword">][</span><span class="default">$key1</span><span class="keyword">] = </span><span class="default">$value2</span><span class="keyword">;<br />&nbsp; &nbsp; return </span><span class="default">$result</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />will transform this:<br /><br />array(1) {<br />&nbsp; &nbsp; ["upload"]=&gt;array(2) {<br />&nbsp; &nbsp; &nbsp; &nbsp; ["name"]=&gt;array(2) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0]=&gt;string(9)"file0.txt"<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [1]=&gt;string(9)"file1.txt"<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; ["type"]=&gt;array(2) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0]=&gt;string(10)"text/plain"<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [1]=&gt;string(10)"text/html"<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />}<br /><br />into:<br /><br />array(1) {<br />&nbsp; &nbsp; ["upload"]=&gt;array(2) {<br />&nbsp; &nbsp; &nbsp; &nbsp; [0]=&gt;array(2) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ["name"]=&gt;string(9)"file0.txt"<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ["type"]=&gt;string(10)"text/plain"<br />&nbsp; &nbsp; &nbsp; &nbsp; },<br />&nbsp; &nbsp; &nbsp; &nbsp; [1]=&gt;array(2) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ["name"]=&gt;string(9)"file1.txt"<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ["type"]=&gt;string(10)"text/html"<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />}<br /><br />just do:<br /><br /><span class="default">&lt;?php $upload </span><span class="keyword">= </span><span class="default">diverse_array</span><span class="keyword">(</span><span class="default">$_FILES</span><span class="keyword">[</span><span class="string">"upload"</span><span class="keyword">]); </span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="109902">  <div class="votes">
    <div id="Vu109902">
    <a href="/manual/vote-note.php?id=109902&amp;page=reserved.variables.files&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd109902">
    <a href="/manual/vote-note.php?id=109902&amp;page=reserved.variables.files&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V109902" title="61% like this...">
    19
    </div>
  </div>
  <a href="#109902" class="name">
  <strong class="user"><em>sparticvs at popebp dot com</em></strong></a><a class="genanchor" href="#109902"> &para;</a><div class="date" title="2012-09-01 08:59"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom109902">
<div class="phpcode"><code><span class="html">
A note of security: Don't ever trust $_FILES["image"]["type"]. It takes whatever is sent from the browser, so don't trust this for the image type.&nbsp; I recommend using finfo_open (<a href="http://www.php.net/manual/en/function.finfo-open.php" rel="nofollow" target="_blank">http://www.php.net/manual/en/function.finfo-open.php</a>) to verify the MIME type of a file. It will parse the MAGIC in the file and return it's type...this can be trusted (you can also use the "file" program on Unix, but I would refrain from ever making a System call with your PHP code...that's just asking for problems).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="106608">  <div class="votes">
    <div id="Vu106608">
    <a href="/manual/vote-note.php?id=106608&amp;page=reserved.variables.files&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd106608">
    <a href="/manual/vote-note.php?id=106608&amp;page=reserved.variables.files&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V106608" title="58% like this...">
    13
    </div>
  </div>
  <a href="#106608" class="name">
  <strong class="user"><em>BigShark666 at gmail dot com</em></strong></a><a class="genanchor" href="#106608"> &para;</a><div class="date" title="2011-11-21 10:51"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom106608">
<div class="phpcode"><code><span class="html">
Nontypicall array comes in php after the submission.I wrote a small function to restate it to the familiar look.<br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">multiple</span><span class="keyword">(array </span><span class="default">$_files</span><span class="keyword">, </span><span class="default">$top </span><span class="keyword">= </span><span class="default">TRUE</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="default">$files </span><span class="keyword">= array();<br />&nbsp; &nbsp; foreach(</span><span class="default">$_files </span><span class="keyword">as </span><span class="default">$name</span><span class="keyword">=&gt;</span><span class="default">$file</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">$top</span><span class="keyword">) </span><span class="default">$sub_name </span><span class="keyword">= </span><span class="default">$file</span><span class="keyword">[</span><span class="string">'name'</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp; else&nbsp; &nbsp; </span><span class="default">$sub_name </span><span class="keyword">= </span><span class="default">$name</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$sub_name</span><span class="keyword">)){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; foreach(</span><span class="default">array_keys</span><span class="keyword">(</span><span class="default">$sub_name</span><span class="keyword">) as </span><span class="default">$key</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$files</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">][</span><span class="default">$key</span><span class="keyword">] = array(<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'name'&nbsp; &nbsp;&nbsp; </span><span class="keyword">=&gt; </span><span class="default">$file</span><span class="keyword">[</span><span class="string">'name'</span><span class="keyword">][</span><span class="default">$key</span><span class="keyword">],<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'type'&nbsp; &nbsp;&nbsp; </span><span class="keyword">=&gt; </span><span class="default">$file</span><span class="keyword">[</span><span class="string">'type'</span><span class="keyword">][</span><span class="default">$key</span><span class="keyword">],<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'tmp_name' </span><span class="keyword">=&gt; </span><span class="default">$file</span><span class="keyword">[</span><span class="string">'tmp_name'</span><span class="keyword">][</span><span class="default">$key</span><span class="keyword">],<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'error'&nbsp; &nbsp; </span><span class="keyword">=&gt; </span><span class="default">$file</span><span class="keyword">[</span><span class="string">'error'</span><span class="keyword">][</span><span class="default">$key</span><span class="keyword">],<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'size'&nbsp; &nbsp;&nbsp; </span><span class="keyword">=&gt; </span><span class="default">$file</span><span class="keyword">[</span><span class="string">'size'</span><span class="keyword">][</span><span class="default">$key</span><span class="keyword">],<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; );<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$files</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">] = </span><span class="default">multiple</span><span class="keyword">(</span><span class="default">$files</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">], </span><span class="default">FALSE</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }else{<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$files</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">] = </span><span class="default">$file</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; return </span><span class="default">$files</span><span class="keyword">;<br />}<br /><br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$_FILES</span><span class="keyword">);<br /></span><span class="comment">/*<br />Array<br />(<br />&nbsp; &nbsp; [image] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [name] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0] =&gt; 400.png<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; )<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [type] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0] =&gt; image/png<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; )<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [tmp_name] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0] =&gt; /tmp/php5Wx0aJ<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; )<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [error] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0] =&gt; 0<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; )<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [size] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0] =&gt; 15726<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; )<br />&nbsp; &nbsp; &nbsp; &nbsp; )<br />)<br />*/<br /></span><span class="default">$files </span><span class="keyword">= </span><span class="default">multiple</span><span class="keyword">(</span><span class="default">$_FILES</span><span class="keyword">);<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$files</span><span class="keyword">);<br /></span><span class="comment">/*<br />Array<br />(<br />&nbsp; &nbsp; [image] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [name] =&gt; 400.png<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [type] =&gt; image/png<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [tmp_name] =&gt; /tmp/php5Wx0aJ<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [error] =&gt; 0<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [size] =&gt; 15726<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; )<br />&nbsp; &nbsp; &nbsp; &nbsp; )<br />)<br />*/<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="88251">  <div class="votes">
    <div id="Vu88251">
    <a href="/manual/vote-note.php?id=88251&amp;page=reserved.variables.files&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd88251">
    <a href="/manual/vote-note.php?id=88251&amp;page=reserved.variables.files&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V88251" title="58% like this...">
    12
    </div>
  </div>
  <a href="#88251" class="name">
  <strong class="user"><em>andrewpunch at bigfoot dot com</em></strong></a><a class="genanchor" href="#88251"> &para;</a><div class="date" title="2009-01-17 12:16"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom88251">
<div class="phpcode"><code><span class="html">
If $_FILES is empty, even when uploading, try adding enctype="multipart/form-data" to the form tag and make sure you have file uploads turned on.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="109648">  <div class="votes">
    <div id="Vu109648">
    <a href="/manual/vote-note.php?id=109648&amp;page=reserved.variables.files&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd109648">
    <a href="/manual/vote-note.php?id=109648&amp;page=reserved.variables.files&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V109648" title="55% like this...">
    5
    </div>
  </div>
  <a href="#109648" class="name">
  <strong class="user"><em>tjbp</em></strong></a><a class="genanchor" href="#109648"> &para;</a><div class="date" title="2012-08-04 09:46"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom109648">
<div class="phpcode"><code><span class="html">
For quick debugging (eg. var_dump($_FILES);), these are the values of the error constants. Obviously don't use these for comparison in real code.<br /><br />UPLOAD_ERR_OK: 0<br />UPLOAD_ERR_INI_SIZE: 1<br />UPLOAD_ERR_FORM_SIZE: 2<br />UPLOAD_ERR_NO_TMP_DIR: 6<br />UPLOAD_ERR_CANT_WRITE: 7<br />UPLOAD_ERR_EXTENSION: 8<br />UPLOAD_ERR_PARTIAL: 3</span>
</code></div>
  </div>
 </div>
  <div class="note" id="91862">  <div class="votes">
    <div id="Vu91862">
    <a href="/manual/vote-note.php?id=91862&amp;page=reserved.variables.files&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd91862">
    <a href="/manual/vote-note.php?id=91862&amp;page=reserved.variables.files&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V91862" title="56% like this...">
    7
    </div>
  </div>
  <a href="#91862" class="name">
  <strong class="user"><em>calurion at gmail dot com</em></strong></a><a class="genanchor" href="#91862"> &para;</a><div class="date" title="2009-06-29 04:51"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom91862">
<div class="phpcode"><code><span class="html">
For some reason when I tried to check if $_FILES['myVarName'] was empty() or !isset() or array_key_exists(), it always came back that the file was indeed in the superglobal, even when nothing was uploaded.<br /><br />I wonder if this is a result of enctype="multipart/form-data".<br /><br />Anyways, I solved my issue by checking to make sure that $_FILES['myVarName']['size'] &gt; 0</span>
</code></div>
  </div>
 </div>
  <div class="note" id="102252">  <div class="votes">
    <div id="Vu102252">
    <a href="/manual/vote-note.php?id=102252&amp;page=reserved.variables.files&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd102252">
    <a href="/manual/vote-note.php?id=102252&amp;page=reserved.variables.files&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V102252" title="53% like this...">
    5
    </div>
  </div>
  <a href="#102252" class="name">
  <strong class="user"><em>John</em></strong></a><a class="genanchor" href="#102252"> &para;</a><div class="date" title="2011-02-03 06:14"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom102252">
<div class="phpcode"><code><span class="html">
In the past you could unconditionally call $_FILES['profile_pic'] without ever having to worry about PHP spitting an "Undefined index: profile_pic" error (so long as the page posting had a file input on it (e.g. &lt;input type="file" name="profile_pic" /&gt;)). This was the case regardless of whether or not the end user actually uploaded a file. These days, with so many people browsing the web via iPads, you have to explicitly check to see if the input isset($_FILES['profile_pic']) before calling into it, else you'll get the aforementioned error message. This is because iOS devices running Safari disable file inputs thereby causing them to be treated as if they don't exist. Time to update your scripts!<br /><br />-john</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121618">  <div class="votes">
    <div id="Vu121618">
    <a href="/manual/vote-note.php?id=121618&amp;page=reserved.variables.files&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121618">
    <a href="/manual/vote-note.php?id=121618&amp;page=reserved.variables.files&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121618" title="50% like this...">
    0
    </div>
  </div>
  <a href="#121618" class="name">
  <strong class="user"><em>tuomas dot piispanen at gmail dot com</em></strong></a><a class="genanchor" href="#121618"> &para;</a><div class="date" title="2017-09-07 10:36"><strong>3 months ago</strong></div>
  <div class="text" id="Hcom121618">
<div class="phpcode"><code><span class="html">
Here's a function that I have used to get a nice simple array of all incoming files from a page. It basically just flattens the $FILES array. This function works on many file inputs on the page and also if the inputs are '&lt;input type="file[]" multiple&gt;'. Note that this function loses the file input names (I usually process the files just by type).<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">incoming_files</span><span class="keyword">() {<br />&nbsp; &nbsp; </span><span class="default">$files </span><span class="keyword">= </span><span class="default">$_FILES</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$files2 </span><span class="keyword">= [];<br />&nbsp; &nbsp; foreach (</span><span class="default">$files </span><span class="keyword">as </span><span class="default">$input </span><span class="keyword">=&gt; </span><span class="default">$infoArr</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$filesByInput </span><span class="keyword">= [];<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach (</span><span class="default">$infoArr </span><span class="keyword">as </span><span class="default">$key </span><span class="keyword">=&gt; </span><span class="default">$valueArr</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$valueArr</span><span class="keyword">)) { </span><span class="comment">// file input "multiple"<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">foreach(</span><span class="default">$valueArr </span><span class="keyword">as </span><span class="default">$i</span><span class="keyword">=&gt;</span><span class="default">$value</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$filesByInput</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">][</span><span class="default">$key</span><span class="keyword">] = </span><span class="default">$value</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; else { </span><span class="comment">// -&gt; string, normal file input<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$filesByInput</span><span class="keyword">[] = </span><span class="default">$infoArr</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$files2 </span><span class="keyword">= </span><span class="default">array_merge</span><span class="keyword">(</span><span class="default">$files2</span><span class="keyword">,</span><span class="default">$filesByInput</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; </span><span class="default">$files3 </span><span class="keyword">= [];<br />&nbsp; &nbsp; foreach(</span><span class="default">$files2 </span><span class="keyword">as </span><span class="default">$file</span><span class="keyword">) { </span><span class="comment">// let's filter empty &amp; errors<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">if (!</span><span class="default">$file</span><span class="keyword">[</span><span class="string">'error'</span><span class="keyword">]) </span><span class="default">$files3</span><span class="keyword">[] = </span><span class="default">$file</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; return </span><span class="default">$files3</span><span class="keyword">;<br />}<br /><br /></span><span class="default">$tmpFiles </span><span class="keyword">= </span><span class="default">incoming_files</span><span class="keyword">();<br /><br /></span><span class="default">?&gt;<br /></span><br />will transform this: <br /><br />Array<br />(<br />&nbsp; &nbsp; [files1] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [name] =&gt; facepalm.jpg<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [type] =&gt; image/jpeg<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [tmp_name] =&gt; /tmp/php3zU3t5<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [error] =&gt; 0<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [size] =&gt; 31059<br />&nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />&nbsp; &nbsp; [files2] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [name] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0] =&gt; facepalm2.jpg<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [1] =&gt; facepalm3.jpg<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [type] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0] =&gt; image/jpeg<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [1] =&gt; image/jpeg<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [tmp_name] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0] =&gt; /tmp/phpJutmOS<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [1] =&gt; /tmp/php9bNI8F<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [error] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0] =&gt; 0<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [1] =&gt; 0<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [size] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0] =&gt; 78085<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [1] =&gt; 61429<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />)<br /><br />into this: <br /><br />Array<br />(<br />&nbsp; &nbsp; [0] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [name] =&gt; facepalm.jpg<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [type] =&gt; image/jpeg<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [tmp_name] =&gt; /tmp/php3zU3t5<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [error] =&gt; 0<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [size] =&gt; 31059<br />&nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />&nbsp; &nbsp; [1] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [name] =&gt; facepalm2.jpg<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [type] =&gt; image/jpeg<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [tmp_name] =&gt; /tmp/phpJutmOS<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [error] =&gt; 0<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [size] =&gt; 78085<br />&nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />&nbsp; &nbsp; [2] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [name] =&gt; facepalm3.jpg<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [type] =&gt; image/jpeg<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [tmp_name] =&gt; /tmp/php9bNI8F<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [error] =&gt; 0<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [size] =&gt; 61429<br />&nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121500">  <div class="votes">
    <div id="Vu121500">
    <a href="/manual/vote-note.php?id=121500&amp;page=reserved.variables.files&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121500">
    <a href="/manual/vote-note.php?id=121500&amp;page=reserved.variables.files&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121500" title="50% like this...">
    0
    </div>
  </div>
  <a href="#121500" class="name">
  <strong class="user"><em>mike dot reiche at tyclipso dot net</em></strong></a><a class="genanchor" href="#121500"> &para;</a><div class="date" title="2017-08-09 12:43"><strong>4 months ago</strong></div>
  <div class="text" id="Hcom121500">
<div class="phpcode"><code><span class="html">
I normalized the $_FILES array to<br /><br />[doc] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [name] =&gt; testfile.txt<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [type] =&gt; application/octet-stream<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [tmp_name] =&gt; /tmp/php6wHXmC<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [error] =&gt; 0<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [size] =&gt; 4<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [affe] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [name] =&gt; testfile.txt<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [type] =&gt; application/octet-stream<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [tmp_name] =&gt; /tmp/phpfiHK2e<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [error] =&gt; 0<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [size] =&gt; 4<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; )<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">getFiles</span><span class="keyword">() {<br />&nbsp; &nbsp; </span><span class="default">$result </span><span class="keyword">= array();<br />&nbsp; &nbsp; foreach(</span><span class="default">$_FILES </span><span class="keyword">as </span><span class="default">$name </span><span class="keyword">=&gt; </span><span class="default">$fileArray</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$fileArray</span><span class="keyword">[</span><span class="string">'name'</span><span class="keyword">])) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; foreach (</span><span class="default">$fileArray </span><span class="keyword">as </span><span class="default">$attrib </span><span class="keyword">=&gt; </span><span class="default">$list</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; foreach (</span><span class="default">$list </span><span class="keyword">as </span><span class="default">$index </span><span class="keyword">=&gt; </span><span class="default">$value</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$result</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">][</span><span class="default">$index</span><span class="keyword">][</span><span class="default">$attrib</span><span class="keyword">]=</span><span class="default">$value</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$result</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">][] = </span><span class="default">$fileArray</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; return </span><span class="default">$result</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />So yo have always the same structure, even if you post one ore more files:<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">//single file<br /></span><span class="default">$request</span><span class="keyword">-&gt;</span><span class="default">addFileFromLocalFilePath</span><span class="keyword">(</span><span class="string">'doc'</span><span class="keyword">,</span><span class="string">'testfile.txt'</span><span class="keyword">);<br /><br /></span><span class="comment">// multiple files<br /></span><span class="default">$request</span><span class="keyword">-&gt;</span><span class="default">addFileFromLocalFilePath</span><span class="keyword">(</span><span class="string">'doc[0]'</span><span class="keyword">,</span><span class="string">'testfile.txt'</span><span class="keyword">);<br /></span><span class="default">$request</span><span class="keyword">-&gt;</span><span class="default">addFileFromLocalFilePath</span><span class="keyword">(</span><span class="string">'doc[affe]'</span><span class="keyword">,</span><span class="string">'testfile.txt'</span><span class="keyword">);<br /><br />foreach (</span><span class="default">$request</span><span class="keyword">-&gt;</span><span class="default">getFiles</span><span class="keyword">() as </span><span class="default">$fieldName </span><span class="keyword">=&gt; </span><span class="default">$files</span><span class="keyword">) {<br />&nbsp; &nbsp; foreach (</span><span class="default">$files </span><span class="keyword">as </span><span class="default">$index </span><span class="keyword">=&gt; </span><span class="default">$fileArray</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">$fileArray</span><span class="keyword">[</span><span class="string">'tmp_name'</span><span class="keyword">];<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="115166">  <div class="votes">
    <div id="Vu115166">
    <a href="/manual/vote-note.php?id=115166&amp;page=reserved.variables.files&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115166">
    <a href="/manual/vote-note.php?id=115166&amp;page=reserved.variables.files&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115166" title="50% like this...">
    0
    </div>
  </div>
  <a href="#115166" class="name">
  <strong class="user"><em>Jmanuel_castillo_exe at yahoo dot com</em></strong></a><a class="genanchor" href="#115166"> &para;</a><div class="date" title="2014-06-06 04:18"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115166">
<div class="phpcode"><code><span class="html">
I spent 3 hours trying to find out why when I upload multiples file $_FILES&nbsp; return empty, I did noticed it was only when I select files that exceed 3m so I thought it was something related to the MAX_UPLOAD_SIZE that for my surprice came as default as 20m which was very confusing. Later I discovery the problem was in the POST_MAX_SIZE been 3m, so it happen that not only MAX_UPLOAD_SIZE is responsible and that is why I'd like to know there is no error message that shows the cause.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="106558">  <div class="votes">
    <div id="Vu106558">
    <a href="/manual/vote-note.php?id=106558&amp;page=reserved.variables.files&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd106558">
    <a href="/manual/vote-note.php?id=106558&amp;page=reserved.variables.files&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V106558" title="50% like this...">
    0
    </div>
  </div>
  <a href="#106558" class="name">
  <strong class="user"><em>kbolyshev at gmail dot com</em></strong></a><a class="genanchor" href="#106558"> &para;</a><div class="date" title="2011-11-18 04:39"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom106558">
<div class="phpcode"><code><span class="html">
For situation download[file1], download[file2], ..., download[fileN], try it:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="comment">/**<br /> *<br /> * @param array&nbsp; &nbsp;&nbsp; $arrayForFill<br /> * @param string&nbsp; &nbsp; $currentKey<br /> * @param mixed&nbsp; &nbsp;&nbsp; $currentMixedValue<br /> * @param string&nbsp; &nbsp; $fileDescriptionParam (name, type, tmp_name, error или size)<br /> * @return void<br /> */<br /></span><span class="keyword">function </span><span class="default">rRestructuringFilesArray</span><span class="keyword">(&amp;</span><span class="default">$arrayForFill</span><span class="keyword">, </span><span class="default">$currentKey</span><span class="keyword">, </span><span class="default">$currentMixedValue</span><span class="keyword">, </span><span class="default">$fileDescriptionParam</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; if (</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$currentMixedValue</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach (</span><span class="default">$currentMixedValue </span><span class="keyword">as </span><span class="default">$nameKey </span><span class="keyword">=&gt; </span><span class="default">$mixedValue</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">rRestructuringFilesArray</span><span class="keyword">(</span><span class="default">$arrayForFill</span><span class="keyword">[</span><span class="default">$currentKey</span><span class="keyword">],<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$nameKey</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$mixedValue</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$fileDescriptionParam</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$arrayForFill</span><span class="keyword">[</span><span class="default">$currentKey</span><span class="keyword">][</span><span class="default">$fileDescriptionParam</span><span class="keyword">] = </span><span class="default">$currentMixedValue</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$arrayForFill </span><span class="keyword">= array();<br />foreach (</span><span class="default">$_FILES </span><span class="keyword">as </span><span class="default">$firstNameKey </span><span class="keyword">=&gt; </span><span class="default">$arFileDescriptions</span><span class="keyword">) {<br />&nbsp; &nbsp; foreach (</span><span class="default">$arFileDescriptions </span><span class="keyword">as </span><span class="default">$fileDescriptionParam </span><span class="keyword">=&gt; </span><span class="default">$mixedValue</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">rRestructuringFilesArray</span><span class="keyword">(</span><span class="default">$arrayForFill</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$firstNameKey</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$_FILES</span><span class="keyword">[</span><span class="default">$firstNameKey</span><span class="keyword">][</span><span class="default">$fileDescriptionParam</span><span class="keyword">],<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$fileDescriptionParam</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">$_FILES </span><span class="keyword">= </span><span class="default">$arrayForFill</span><span class="keyword">;<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="105640">  <div class="votes">
    <div id="Vu105640">
    <a href="/manual/vote-note.php?id=105640&amp;page=reserved.variables.files&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd105640">
    <a href="/manual/vote-note.php?id=105640&amp;page=reserved.variables.files&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V105640" title="46% like this...">
    -1
    </div>
  </div>
  <a href="#105640" class="name">
  <strong class="user"><em>unca dot alby at gmail dot com</em></strong></a><a class="genanchor" href="#105640"> &para;</a><div class="date" title="2011-09-02 01:31"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom105640">
<div class="phpcode"><code><span class="html">
In checking the error code, you probably ought to check for code 4.&nbsp; I believe Code 4 means no file was uploaded, and there are many instances where that's perfectly OK.<br /><br />Such as when you have a form with multiple data items, including file and image uploads, plus whatever else.&nbsp; The user might not be adding a new upload for whatever reason, such as there may already be a file in the system from an earlier update, and the user is satisfied with that.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="104395">  <div class="votes">
    <div id="Vu104395">
    <a href="/manual/vote-note.php?id=104395&amp;page=reserved.variables.files&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd104395">
    <a href="/manual/vote-note.php?id=104395&amp;page=reserved.variables.files&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V104395" title="46% like this...">
    -2
    </div>
  </div>
  <a href="#104395" class="name">
  <strong class="user"><em>Sbastien</em></strong></a><a class="genanchor" href="#104395"> &para;</a><div class="date" title="2011-06-13 07:36"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom104395">
<div class="phpcode"><code><span class="html">
If you're uploading multiple files and you name your file inputs "upload[]" the $_FILES array will look different than the var_dump posted below. I figured I'd post what it looks like since it caused me (and still causes me) headaches!<br /><br />array(1) {<br />&nbsp; &nbsp; ["upload"]=&gt;array(5) {<br />&nbsp; &nbsp; &nbsp; &nbsp; ["name"]=&gt;array(3) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0]=&gt;string(9)"file0.txt"<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [1]=&gt;string(9)"file1.txt"<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [2]=&gt;string(9)"file2.txt"<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; ["type"]=&gt;array(3) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0]=&gt;string(10)"text/plain"<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [1]=&gt;string(10)"text/plain"<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [2]=&gt;string(10)"text/plain"<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; ["tmp_name"]=&gt;array(3) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0]=&gt;string(14)"/tmp/blablabla"<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [1]=&gt;string(14)"/tmp/phpyzZxta"<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [2]=&gt;string(14)"/tmp/phpn3nopO"<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; ["error"]=&gt;array(3) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0]=&gt;int(0)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [1]=&gt;int(0)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [2]=&gt;int(0)<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; ["size"]=&gt;array(3) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0]=&gt;int(0)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [1]=&gt;int(0)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [2]=&gt;int(0)<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />}<br /><br />(I thought the array would have looked like upload[index][name] which is not the case.)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="103522">  <div class="votes">
    <div id="Vu103522">
    <a href="/manual/vote-note.php?id=103522&amp;page=reserved.variables.files&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd103522">
    <a href="/manual/vote-note.php?id=103522&amp;page=reserved.variables.files&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V103522" title="46% like this...">
    -2
    </div>
  </div>
  <a href="#103522" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#103522"> &para;</a><div class="date" title="2011-04-18 06:23"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom103522">
<div class="phpcode"><code><span class="html">
As mentioned , you should check the error index of the upload.<br /><br />Example below suggests you have a file field named 'image'.<br /><br /><span class="default">&lt;?php<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">if(</span><span class="default">$_FILES</span><span class="keyword">[</span><span class="string">'image'</span><span class="keyword">][</span><span class="string">'error'</span><span class="keyword">] == </span><span class="default">0</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// success - move uploaded file and process stuff here<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">}else{<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// 'there was an error uploading file' stuff here....&nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="107940">  <div class="votes">
    <div id="Vu107940">
    <a href="/manual/vote-note.php?id=107940&amp;page=reserved.variables.files&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd107940">
    <a href="/manual/vote-note.php?id=107940&amp;page=reserved.variables.files&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V107940" title="42% like this...">
    -4
    </div>
  </div>
  <a href="#107940" class="name">
  <strong class="user"><em>yuriy dot nayda at gmail dot com</em></strong></a><a class="genanchor" href="#107940"> &para;</a><div class="date" title="2012-03-15 04:49"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom107940">
<div class="phpcode"><code><span class="html">
THis is an solution to convert Cyrillic and umlaut characters as file name when uplaoding files into needed encoding. Was searching for it but could not find. Thus posting this. Just like this:<br /><br />$value = mb_convert_encoding($value, "UTF-8");</span>
</code></div>
  </div>
 </div>
  <div class="note" id="108718">  <div class="votes">
    <div id="Vu108718">
    <a href="/manual/vote-note.php?id=108718&amp;page=reserved.variables.files&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd108718">
    <a href="/manual/vote-note.php?id=108718&amp;page=reserved.variables.files&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V108718" title="41% like this...">
    -4
    </div>
  </div>
  <a href="#108718" class="name">
  <strong class="user"><em>Alexandre Teles</em></strong></a><a class="genanchor" href="#108718"> &para;</a><div class="date" title="2012-05-20 04:31"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom108718">
<div class="phpcode"><code><span class="html">
You can check error index this way:<br /><br /><span class="default">&lt;?php<br /><br />$errorIndex </span><span class="keyword">= </span><span class="default">$_FILES</span><span class="keyword">[</span><span class="string">"file"</span><span class="keyword">][</span><span class="string">"error"</span><span class="keyword">];<br /><br />if (</span><span class="default">$errorIndex </span><span class="keyword">&gt; </span><span class="default">0</span><span class="keyword">) {<br />&nbsp; &nbsp; die(</span><span class="string">'We have a error. Try Again.'</span><span class="keyword">);<br />}<br /><br /></span><span class="default">processFile</span><span class="keyword">();<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="103662">  <div class="votes">
    <div id="Vu103662">
    <a href="/manual/vote-note.php?id=103662&amp;page=reserved.variables.files&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd103662">
    <a href="/manual/vote-note.php?id=103662&amp;page=reserved.variables.files&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V103662" title="41% like this...">
    -4
    </div>
  </div>
  <a href="#103662" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#103662"> &para;</a><div class="date" title="2011-04-26 02:48"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom103662">
<div class="phpcode"><code><span class="html">
Having url rewrite patterns in .htaccess file which modify your urls can affect $_FILES sometimes. Even though the php page loads and works fine, this variable may not work because of it. Therefore if you rewrite 'www.example.com' to 'example.com', make sure you use the latter one when sending POST to the php page. I'm still not sure why this happens, but its worth noting here so others don't spend time chasing ghosts.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="109283">  <div class="votes">
    <div id="Vu109283">
    <a href="/manual/vote-note.php?id=109283&amp;page=reserved.variables.files&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd109283">
    <a href="/manual/vote-note.php?id=109283&amp;page=reserved.variables.files&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V109283" title="40% like this...">
    -4
    </div>
  </div>
  <a href="#109283" class="name">
  <strong class="user"><em>seifert at alesak dot net</em></strong></a><a class="genanchor" href="#109283"> &para;</a><div class="date" title="2012-07-02 02:02"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom109283">
<div class="phpcode"><code><span class="html">
I just spent long time debugging strange behavior of one of our application on new webhosting. We have 30 file inputs on one page for upload to server. Problem was that only 20 was actually uploaded.<br /><br />Now I found there is an option max_file_uploads in php.ini limiting maximum size of $_FILES to 20 by default.<br /><br />When you have suhosin extension installed it has own option limiting same thing to 25 (suhosin.upload.max_uploads in php.ini)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118294">  <div class="votes">
    <div id="Vu118294">
    <a href="/manual/vote-note.php?id=118294&amp;page=reserved.variables.files&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118294">
    <a href="/manual/vote-note.php?id=118294&amp;page=reserved.variables.files&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118294" title="36% like this...">
    -3
    </div>
  </div>
  <a href="#118294" class="name">
  <strong class="user"><em>Jack Sleight</em></strong></a><a class="genanchor" href="#118294"> &para;</a><div class="date" title="2015-11-10 12:05"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom118294">
<div class="phpcode"><code><span class="html">
I've written this function to restructure deeply nested $_FILES arrays, so that the parameters for each file are grouped together.<br /><br />function restructure_files(array $input)<br />{<br />&nbsp; &nbsp; $output = [];<br />&nbsp; &nbsp; foreach ($input as $name =&gt; $array) {<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach ($array as $field =&gt; $value) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $pointer = &amp;$output[$name];<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (!is_array($value)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $pointer[$field] = $value;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; continue;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $stack = [&amp;$pointer];<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $iterator = new \RecursiveIteratorIterator(<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; new \RecursiveArrayIterator($value),<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; \RecursiveIteratorIterator::SELF_FIRST<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; );<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; foreach ($iterator as $key =&gt; $value) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; array_splice($stack, $iterator-&gt;getDepth() + 1);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $pointer = &amp;$stack[count($stack) - 1];<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $pointer = &amp;$pointer[$key];<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $stack[] = &amp;$pointer;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (!$iterator-&gt;hasChildren()) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $pointer[$field] = $value;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; return $output;<br />}<br /><br />Turns this:<br /><br />array (size=2)<br />&nbsp; 'one' =&gt; <br />&nbsp; &nbsp; array (size=5)<br />&nbsp; &nbsp; &nbsp; 'name' =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; array (size=1)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 'inner' =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; array (size=2)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 11 =&gt; string 'DM4C2738.jpg' (length=12)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 5 =&gt; string 'DM4C2760.jpg' (length=12)<br />&nbsp; &nbsp; &nbsp; 'type' =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; array (size=1)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 'inner' =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; array (size=2)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 11 =&gt; string 'image/jpeg' (length=10)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 5 =&gt; string 'image/jpeg' (length=10)<br />&nbsp; &nbsp; &nbsp; 'tmp_name' =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; array (size=1)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 'inner' =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; array (size=2)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 11 =&gt; string '/private/var/tmp/phploOZRb' (length=26)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 5 =&gt; string '/private/var/tmp/phpsFkmIh' (length=26)<br />&nbsp; &nbsp; &nbsp; 'error' =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; array (size=1)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 'inner' =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; array (size=2)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 11 =&gt; int 0<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 5 =&gt; int 0<br />&nbsp; &nbsp; &nbsp; 'size' =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; array (size=1)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 'inner' =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; array (size=2)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 11 =&gt; int 1031601<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 5 =&gt; int 674697<br />&nbsp; 'two' =&gt; <br />&nbsp; &nbsp; array (size=5)<br />&nbsp; &nbsp; &nbsp; 'name' =&gt; string '9ncYySC.jpg' (length=11)<br />&nbsp; &nbsp; &nbsp; 'type' =&gt; string 'image/jpeg' (length=10)<br />&nbsp; &nbsp; &nbsp; 'tmp_name' =&gt; string '/private/var/tmp/phpuG99X9' (length=26)<br />&nbsp; &nbsp; &nbsp; 'error' =&gt; int 0<br />&nbsp; &nbsp; &nbsp; 'size' =&gt; int 882422<br /><br />Into this:<br /><br />array (size=2)<br />&nbsp; 'one' =&gt; <br />&nbsp; &nbsp; array (size=1)<br />&nbsp; &nbsp; &nbsp; 'inner' =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; array (size=2)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 11 =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; array (size=5)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 'name' =&gt; string 'DM4C2738.jpg' (length=12)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 'type' =&gt; string 'image/jpeg' (length=10)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 'tmp_name' =&gt; string '/private/var/tmp/phploOZRb' (length=26)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 'error' =&gt; int 0<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 'size' =&gt; int 1031601<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 5 =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; array (size=5)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 'name' =&gt; string 'DM4C2760.jpg' (length=12)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 'type' =&gt; string 'image/jpeg' (length=10)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 'tmp_name' =&gt; string '/private/var/tmp/phpsFkmIh' (length=26)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 'error' =&gt; int 0<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 'size' =&gt; int 674697<br />&nbsp; 'two' =&gt; <br />&nbsp; &nbsp; array (size=5)<br />&nbsp; &nbsp; &nbsp; 'name' =&gt; string '9ncYySC.jpg' (length=11)<br />&nbsp; &nbsp; &nbsp; 'type' =&gt; string 'image/jpeg' (length=10)<br />&nbsp; &nbsp; &nbsp; 'tmp_name' =&gt; string '/private/var/tmp/phpuG99X9' (length=26)<br />&nbsp; &nbsp; &nbsp; 'error' =&gt; int 0<br />&nbsp; &nbsp; &nbsp; 'size' =&gt; int 882422</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114087">  <div class="votes">
    <div id="Vu114087">
    <a href="/manual/vote-note.php?id=114087&amp;page=reserved.variables.files&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114087">
    <a href="/manual/vote-note.php?id=114087&amp;page=reserved.variables.files&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114087" title="36% like this...">
    -5
    </div>
  </div>
  <a href="#114087" class="name">
  <strong class="user"><em>badandyomega at gmail dot com</em></strong></a><a class="genanchor" href="#114087"> &para;</a><div class="date" title="2014-01-10 01:27"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114087">
<div class="phpcode"><code><span class="html">
Others have posted about how the $_FILES array organizes data differently depending on whether the HTML input is a single or multiple type, so it seems to be a common enough problem.&nbsp; If for some reason you need to mix-and-match the types, or you're not sure which how many files you'll be expecting from a multiple input, this is a very useful way to reorganize the $_FILES array.&nbsp; Also, unlike some of the earlier posts, the formatting of the new array (i.e. the number of keys and values) is consistent.<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">// Reorganize $_FILES array information<br /></span><span class="default">$files </span><span class="keyword">= Array ();<br /></span><span class="default">$i </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br /><br /></span><span class="comment">// Start with all inputs in $_FILES array<br /></span><span class="keyword">foreach (</span><span class="default">$_FILES </span><span class="keyword">as </span><span class="default">$input</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="default">$j </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; foreach (</span><span class="default">$input </span><span class="keyword">as </span><span class="default">$property </span><span class="keyword">=&gt; </span><span class="default">$value</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$j </span><span class="keyword">= </span><span class="default">count</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">); </span><span class="comment">// Number of iterations<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">for (</span><span class="default">$k </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">; </span><span class="default">$k </span><span class="keyword">&lt; </span><span class="default">$j</span><span class="keyword">; ++</span><span class="default">$k</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$files</span><span class="keyword">[</span><span class="default">$i </span><span class="keyword">+ </span><span class="default">$k</span><span class="keyword">][</span><span class="default">$property</span><span class="keyword">] = </span><span class="default">$value</span><span class="keyword">[</span><span class="default">$k</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$j </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$files</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">][</span><span class="default">$property</span><span class="keyword">] = </span><span class="default">$value</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="default">$i </span><span class="keyword">+= </span><span class="default">$j</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />The results will look something like this:<br />$files = Array (<br />&nbsp;&nbsp; [0] =&gt; Array (<br />&nbsp; &nbsp; &nbsp; [name] =&gt; '' <br />&nbsp; &nbsp; &nbsp; [type] =&gt; ''<br />&nbsp; &nbsp; &nbsp; [tmp_name] =&gt; ''<br />&nbsp; &nbsp; &nbsp; [error] =&gt; 0<br />&nbsp; &nbsp; &nbsp; [size] =&gt; 0 <br />&nbsp;&nbsp; )<br />)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113424">  <div class="votes">
    <div id="Vu113424">
    <a href="/manual/vote-note.php?id=113424&amp;page=reserved.variables.files&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113424">
    <a href="/manual/vote-note.php?id=113424&amp;page=reserved.variables.files&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113424" title="36% like this...">
    -6
    </div>
  </div>
  <a href="#113424" class="name">
  <strong class="user"><em>phazei at gmail dot com</em></strong></a><a class="genanchor" href="#113424"> &para;</a><div class="date" title="2013-10-09 12:51"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113424">
<div class="phpcode"><code><span class="html">
I realize there are a number of posts here for reformating the php $_FILES array, but they don't handle all cases.&nbsp; This handles the single case, the multiple file case, and even submitting multiple file arrays.&nbsp; This way no matter what, before ever touching the files array I call this regardless of what it might be:<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * This is to fix the odd files array PHP creates when a file input has a name that's php array:<br />&nbsp; &nbsp;&nbsp; * eg: &lt;file name="model[column]" value='file1'&gt; &lt;file name="model[column2][]" value='file2'&gt;<br />&nbsp; &nbsp;&nbsp; * becomes:&nbsp; $_FILES['model']['name'][column] = file1_name.xxx<br />&nbsp; &nbsp;&nbsp; *&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; $_FILES['model']['name'][column2][0] = file2_name.xxx<br />&nbsp; &nbsp;&nbsp; *<br />&nbsp; &nbsp;&nbsp; * this changes it to:<br />&nbsp; &nbsp;&nbsp; *&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; $files['model'][column]['name'] = file1_name.xxx<br />&nbsp; &nbsp;&nbsp; *&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; $files['model'][column2][0]['name'] = file2_name.xxx<br />&nbsp; &nbsp;&nbsp; *<br />&nbsp; &nbsp;&nbsp; * This way the file data is grouped together as expected and as it does with a non-array type name attribute<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">static public function </span><span class="default">multi_file_fix</span><span class="keyword">(</span><span class="default">$files </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">)<br />&nbsp; &nbsp; {<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$files </span><span class="keyword">== </span><span class="default">null</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$files </span><span class="keyword">= (</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$_FILES</span><span class="keyword">)) ? </span><span class="default">$_FILES </span><span class="keyword">: array();<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//make there there is a file, and see if the first item is also an array<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$new_files </span><span class="keyword">= array();<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach (</span><span class="default">$files </span><span class="keyword">as </span><span class="default">$name </span><span class="keyword">=&gt; </span><span class="default">$attributes</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">reset</span><span class="keyword">(</span><span class="default">$attributes</span><span class="keyword">))) { </span><span class="comment">//check first item<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">foreach (</span><span class="default">$attributes </span><span class="keyword">as </span><span class="default">$attribute </span><span class="keyword">=&gt; </span><span class="default">$item</span><span class="keyword">) { </span><span class="comment">//array file submit, eg name="model[file]"<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">foreach (</span><span class="default">$item </span><span class="keyword">as </span><span class="default">$key </span><span class="keyword">=&gt; </span><span class="default">$value</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; foreach (</span><span class="default">$value </span><span class="keyword">as </span><span class="default">$key2 </span><span class="keyword">=&gt; </span><span class="default">$sub_val</span><span class="keyword">) { </span><span class="comment">// multi-array file submit, eg name="model[file][]"<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$new_files</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">][</span><span class="default">$key</span><span class="keyword">][</span><span class="default">$key2</span><span class="keyword">][</span><span class="default">$attribute</span><span class="keyword">] = </span><span class="default">$sub_val</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$new_files</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">][</span><span class="default">$key</span><span class="keyword">][</span><span class="default">$attribute</span><span class="keyword">] = </span><span class="default">$value</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; } else { </span><span class="comment">// regular file submit, eg name="file"<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$new_files</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">] = </span><span class="default">$attributes</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$new_files</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br /></span><span class="comment">//Usage:<br /><br /></span><span class="default">$files </span><span class="keyword">= </span><span class="default">multi_file_fix</span><span class="keyword">(</span><span class="default">$_FILES</span><span class="keyword">);<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114596">  <div class="votes">
    <div id="Vu114596">
    <a href="/manual/vote-note.php?id=114596&amp;page=reserved.variables.files&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114596">
    <a href="/manual/vote-note.php?id=114596&amp;page=reserved.variables.files&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114596" title="33% like this...">
    -10
    </div>
  </div>
  <a href="#114596" class="name">
  <strong class="user"><em>delete dot this dot and dot dots dot gt at kani dot hu</em></strong></a><a class="genanchor" href="#114596"> &para;</a><div class="date" title="2014-03-10 04:29"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114596">
<div class="phpcode"><code><span class="html">
Here is my version of $_FILES rearrange. Unlike other codes here, this working well on any depth of $_FILES.<br /><span class="default">&lt;?php<br /></span><span class="keyword">if (!empty(</span><span class="default">$_FILES</span><span class="keyword">)) {<br />&nbsp; &nbsp; function </span><span class="default">rearrange_files_array</span><span class="keyword">(array </span><span class="default">$array</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach (</span><span class="default">$array </span><span class="keyword">as &amp;</span><span class="default">$value</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$_array </span><span class="keyword">= array();<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; foreach (</span><span class="default">$value </span><span class="keyword">as </span><span class="default">$prop </span><span class="keyword">=&gt; </span><span class="default">$propval</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$propval</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">array_walk_recursive</span><span class="keyword">(</span><span class="default">$propval</span><span class="keyword">, function(&amp;</span><span class="default">$item</span><span class="keyword">, </span><span class="default">$key</span><span class="keyword">, </span><span class="default">$value</span><span class="keyword">) use(</span><span class="default">$prop</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$item </span><span class="keyword">= array(</span><span class="default">$prop </span><span class="keyword">=&gt; </span><span class="default">$item</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }, </span><span class="default">$value</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$_array </span><span class="keyword">= </span><span class="default">array_replace_recursive</span><span class="keyword">(</span><span class="default">$_array</span><span class="keyword">, </span><span class="default">$propval</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$_array</span><span class="keyword">[</span><span class="default">$prop</span><span class="keyword">] = </span><span class="default">$propval</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$value </span><span class="keyword">= </span><span class="default">$_array</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$array</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; echo </span><span class="string">'&lt;pre&gt;'</span><span class="keyword">.</span><span class="default">print_r</span><span class="keyword">(</span><span class="default">rearrange_files_array</span><span class="keyword">(</span><span class="default">$_FILES</span><span class="keyword">), </span><span class="default">true</span><span class="keyword">).</span><span class="string">'&lt;/pre&gt;'</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span>&lt;form method="post" enctype="multipart/form-data" style="clear: both;"&gt;<br />&nbsp; &nbsp; &lt;h3&gt;upload1&lt;/h3&gt;<br />&nbsp; &nbsp; &lt;div&gt;&lt;label&gt;new0&lt;/label&gt;&lt;input type="file" name="upload1[new][]" /&gt;&lt;/div&gt;<br />&nbsp; &nbsp; &lt;div&gt;&lt;label&gt;new1&lt;/label&gt;&lt;input type="file" name="upload1[new][]" /&gt;&lt;/div&gt;<br />&nbsp; &nbsp; &lt;div&gt;&lt;label&gt;update.id11&lt;/label&gt;&lt;input type="file" name="upload1[update][id11]" /&gt;&lt;/div&gt;<br />&nbsp; &nbsp; &lt;div&gt;&lt;label&gt;update.id12&lt;/label&gt;&lt;input type="file" name="upload1[update][id12]" /&gt;&lt;/div&gt;<br />&nbsp; &nbsp; &lt;hr /&gt;<br />&nbsp; &nbsp; &lt;h3&gt;upload2&lt;/h3&gt;<br />&nbsp; &nbsp; &lt;div&gt;&lt;label&gt;new0&lt;/label&gt;&lt;input type="file" name="upload2[]" /&gt;&lt;/div&gt;<br />&nbsp; &nbsp; &lt;div&gt;&lt;label&gt;new1&lt;/label&gt;&lt;input type="file" name="upload2[]" /&gt;&lt;/div&gt;<br />&nbsp; &nbsp; &lt;div&gt;&lt;label&gt;update.id21&lt;/label&gt;&lt;input type="file" name="upload2[id21]" /&gt;&lt;/div&gt;<br />&nbsp; &nbsp; &lt;div&gt;&lt;label&gt;update.id22&lt;/label&gt;&lt;input type="file" name="upload2[id22]" /&gt;&lt;/div&gt;<br />&nbsp; &nbsp; &lt;hr /&gt;<br />&nbsp; &nbsp; &lt;div&gt;&lt;label&gt;upload3&lt;/label&gt;&lt;input type="file" name="upload3" /&gt;&lt;/div&gt;<br />&nbsp; &nbsp; &lt;input type="submit" value="go" /&gt;<br />&lt;/form&gt;<br /><br />The output after empty form is posted:<br />Array<br />(<br />&nbsp; &nbsp; [upload1] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [new] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [name] =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [type] =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [tmp_name] =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [error] =&gt; 4<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [size] =&gt; 0<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; )<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [1] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [name] =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [type] =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [tmp_name] =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [error] =&gt; 4<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [size] =&gt; 0<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; )<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; )<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [update] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [id11] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [name] =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [type] =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [tmp_name] =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [error] =&gt; 4<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [size] =&gt; 0<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; )<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [id12] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [name] =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [type] =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [tmp_name] =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [error] =&gt; 4<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [size] =&gt; 0<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; )<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; )<br />&nbsp; &nbsp; &nbsp; &nbsp; )<br />&nbsp; &nbsp; [upload2] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [name] =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [type] =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [tmp_name] =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [error] =&gt; 4<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [size] =&gt; 0<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; )<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [1] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [name] =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [type] =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [tmp_name] =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [error] =&gt; 4<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [size] =&gt; 0<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; )<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [id21] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [name] =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [type] =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [tmp_name] =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [error] =&gt; 4<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [size] =&gt; 0<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; )<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [id22] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [name] =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [type] =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [tmp_name] =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [error] =&gt; 4<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [size] =&gt; 0<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; )<br />&nbsp; &nbsp; &nbsp; &nbsp; )<br />&nbsp; &nbsp; [upload3] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [name] =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [type] =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [tmp_name] =&gt; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [error] =&gt; 4<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [size] =&gt; 0<br />&nbsp; &nbsp; &nbsp; &nbsp; )<br />)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="92893">  <div class="votes">
    <div id="Vu92893">
    <a href="/manual/vote-note.php?id=92893&amp;page=reserved.variables.files&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd92893">
    <a href="/manual/vote-note.php?id=92893&amp;page=reserved.variables.files&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V92893" title="29% like this...">
    -11
    </div>
  </div>
  <a href="#92893" class="name">
  <strong class="user"><em>mwgamera at gmail dot com</em></strong></a><a class="genanchor" href="#92893"> &para;</a><div class="date" title="2009-08-13 05:40"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom92893">
<div class="phpcode"><code><span class="html">
To determine whether upload was successful you should check for error being UPLOAD_ERR_OK instead of checking the file size. When nothing is chosen to be uploaded, the key in $_FILES will still be there, but it should have error equal UPLOAD_ERR_NO_FILE.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117647">  <div class="votes">
    <div id="Vu117647">
    <a href="/manual/vote-note.php?id=117647&amp;page=reserved.variables.files&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117647">
    <a href="/manual/vote-note.php?id=117647&amp;page=reserved.variables.files&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117647" title="25% like this...">
    -8
    </div>
  </div>
  <a href="#117647" class="name">
  <strong class="user"><em>kennyp33 at gmail dot com</em></strong></a><a class="genanchor" href="#117647"> &para;</a><div class="date" title="2015-07-14 12:46"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117647">
<div class="phpcode"><code><span class="html">
If you are getting NULL values and want to see what error is being returned you can add ' 2&gt;&amp;1' to the end of your command. On a linux server this will redirect the stderr to stdout (so the string error will be output). This probably saved me a ton of time.</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=reserved.variables.files&amp;redirect=http://php.net/manual/en/reserved.variables.files.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="reserved.variables.php">Predefined Variables</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.variables.superglobals.php" title="Superglobals">Superglobals</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.globals.php" title="$GLOBALS">$GLOBALS</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.server.php" title="$_&#8203;SERVER">$_&#8203;SERVER</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.get.php" title="$_&#8203;GET">$_&#8203;GET</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.post.php" title="$_&#8203;POST">$_&#8203;POST</a>
                        </li>
                          
                        <li class="current">
                            <a href="reserved.variables.files.php" title="$_&#8203;FILES">$_&#8203;FILES</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.request.php" title="$_&#8203;REQUEST">$_&#8203;REQUEST</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.session.php" title="$_&#8203;SESSION">$_&#8203;SESSION</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.environment.php" title="$_&#8203;ENV">$_&#8203;ENV</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.cookies.php" title="$_&#8203;COOKIE">$_&#8203;COOKIE</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.phperrormsg.php" title="$php_&#8203;errormsg">$php_&#8203;errormsg</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.httprawpostdata.php" title="$HTTP_&#8203;RAW_&#8203;POST_&#8203;DATA">$HTTP_&#8203;RAW_&#8203;POST_&#8203;DATA</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.httpresponseheader.php" title="$http_&#8203;response_&#8203;header">$http_&#8203;response_&#8203;header</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.argc.php" title="$argc">$argc</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.argv.php" title="$argv">$argv</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

