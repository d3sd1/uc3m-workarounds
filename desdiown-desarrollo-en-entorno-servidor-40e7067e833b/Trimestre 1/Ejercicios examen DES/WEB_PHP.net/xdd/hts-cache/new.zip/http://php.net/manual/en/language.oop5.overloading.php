<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Overloading - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.oop5.overloading.php">
 <link rel="shorturl" href="http://php.net/oop5.overloading">
 <link rel="alternate" href="http://php.net/oop5.overloading" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.oop5.php">
 <link rel="prev" href="http://php.net/manual/en/language.oop5.anonymous.php">
 <link rel="next" href="http://php.net/manual/en/language.oop5.iterations.php">

 <link rel="alternate" href="http://php.net/manual/en/language.oop5.overloading.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.oop5.overloading.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.oop5.overloading.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.oop5.overloading.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.oop5.overloading.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.oop5.overloading.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.oop5.overloading.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.oop5.overloading.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.oop5.overloading.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.oop5.overloading.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.oop5.overloading.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.oop5.iterations.php">
          Object Iteration &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.oop5.anonymous.php">
          &laquo; Anonymous classes        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.oop5.php'>Classes and Objects</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.oop5.overloading.php' selected="selected">English</option>
            <option value='pt_BR/language.oop5.overloading.php'>Brazilian Portuguese</option>
            <option value='zh/language.oop5.overloading.php'>Chinese (Simplified)</option>
            <option value='fr/language.oop5.overloading.php'>French</option>
            <option value='de/language.oop5.overloading.php'>German</option>
            <option value='ja/language.oop5.overloading.php'>Japanese</option>
            <option value='ro/language.oop5.overloading.php'>Romanian</option>
            <option value='ru/language.oop5.overloading.php'>Russian</option>
            <option value='es/language.oop5.overloading.php'>Spanish</option>
            <option value='tr/language.oop5.overloading.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.oop5.overloading.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.oop5.overloading">Report a Bug</a>
    </div>
  </div><div id="language.oop5.overloading" class="sect1">
  <h2 class="title">Overloading</h2>

  <p class="para">
   Overloading in PHP provides means to dynamically
   "<span class="quote">create</span>" properties and methods.
   These dynamic entities are processed via magic methods
   one can establish in a class for various action types.
  </p>

  <p class="para">
   The overloading methods are invoked when interacting with
   properties or methods that have not been declared or are not
   <a href="language.oop5.visibility.php" class="link">visible</a> in
   the current scope. The rest of this section will use the terms
   "<span class="quote">inaccessible properties</span>" and "<span class="quote">inaccessible
   methods</span>" to refer to this combination of declaration
   and visibility.
  </p>

  <p class="para">
   All overloading methods must be defined as <em>public</em>.
  </p>

  <blockquote class="note"><p><strong class="note">Note</strong>: 
   <p class="para">
    None of the arguments of these magic methods can be
    <a href="functions.arguments.php#functions.arguments.by-reference" class="link">passed by
    reference</a>.
   </p>
  </p></blockquote>

  <blockquote class="note"><p><strong class="note">Note</strong>: 
   <p class="para">
    PHP&#039;s interpretation of "<span class="quote">overloading</span>" is
    different than most object oriented languages. Overloading
    traditionally provides the ability to have multiple methods
    with the same name but different quantities and types of
    arguments.
   </p>
  </p></blockquote>


  <div class="sect2" id="language.oop5.overloading.changelog">
   <h3 class="title">Changelog</h3>
   <p class="para">
    <table class="doctable informaltable">
     
      <thead>
       <tr>
        <th>Version</th>
        <th>Description</th>
       </tr>

      </thead>

      <tbody class="tbody">
       <tr>
        <td>5.3.0</td>
        <td>
         Added <a href="language.oop5.overloading.php#object.callstatic" class="link">__callStatic()</a>.
         Added warning to enforce public visibility and non-static declaration.
        </td>
       </tr>

       <tr>
        <td>5.1.0</td>
        <td>
         Added <a href="language.oop5.overloading.php#object.isset" class="link">__isset()</a> and <a href="language.oop5.overloading.php#object.unset" class="link">__unset()</a>. 
         Added support for <a href="language.oop5.overloading.php#object.get" class="link">__get()</a> for overloading of private properties.
        </td>
       </tr>

       <tr>
        <td>5.0.0</td>
        <td>
         Added <a href="language.oop5.overloading.php#object.get" class="link">__get()</a>.
        </td>
       </tr>

      </tbody>
     
    </table>

   </p>
  </div>


  <div class="sect2" id="language.oop5.overloading.members">
   <h3 class="title">Property overloading</h3>

   <div class="methodsynopsis dc-description" id="object.set">
    <span class="modifier">public</span> <span class="type"><span class="type void">void</span></span> <span class="methodname"><strong>__set</strong></span>
     ( <span class="methodparam"><span class="type">string</span> <code class="parameter">$name</code></span>
    , <span class="methodparam"><span class="type"><a href="language.pseudo-types.php#language.types.mixed" class="type mixed">mixed</a></span> <code class="parameter">$value</code></span>
    )</div>

   <div class="methodsynopsis dc-description" id="object.get">
    <span class="modifier">public</span> <span class="type"><a href="language.pseudo-types.php#language.types.mixed" class="type mixed">mixed</a></span> <span class="methodname"><strong>__get</strong></span>
     ( <span class="methodparam"><span class="type">string</span> <code class="parameter">$name</code></span>
    )</div>

   <div class="methodsynopsis dc-description" id="object.isset">
    <span class="modifier">public</span> <span class="type">bool</span> <span class="methodname"><strong>__isset</strong></span>
     ( <span class="methodparam"><span class="type">string</span> <code class="parameter">$name</code></span>
    )</div>

   <div class="methodsynopsis dc-description" id="object.unset">
    <span class="modifier">public</span> <span class="type"><span class="type void">void</span></span> <span class="methodname"><strong>__unset</strong></span>
     ( <span class="methodparam"><span class="type">string</span> <code class="parameter">$name</code></span>
    )</div>


   <p class="para">
    <a href="language.oop5.overloading.php#object.set" class="link">__set()</a> is run when writing data to
    inaccessible properties.
   </p>

   <p class="para">
    <a href="language.oop5.overloading.php#object.get" class="link">__get()</a> is utilized for reading data from
    inaccessible properties.
   </p>

   <p class="para">
    <a href="language.oop5.overloading.php#object.isset" class="link">__isset()</a> is triggered by calling
    <span class="function"><a href="function.isset.php" class="function">isset()</a></span> or <span class="function"><a href="function.empty.php" class="function">empty()</a></span>
    on inaccessible properties.
   </p>

   <p class="para">
    <a href="language.oop5.overloading.php#object.unset" class="link">__unset()</a> is invoked when
    <span class="function"><a href="function.unset.php" class="function">unset()</a></span> is used on inaccessible properties.
   </p>

   <p class="para">
    The <var class="varname"><var class="varname">$name</var></var> argument is the name of the
    property being interacted with. The <a href="language.oop5.overloading.php#object.set" class="link">__set()</a>
    method&#039;s <var class="varname"><var class="varname">$value</var></var> argument specifies the
    value the <var class="varname"><var class="varname">$name</var></var>&#039;ed property should be set
    to.
   </p>

   <p class="para">
    Property overloading only works in object context. These magic
    methods will not be triggered in static context. Therefore
    these methods should not be declared
    <a href="language.oop5.static.php" class="link">static</a>. As of PHP 
    5.3.0, a warning is issued if one of the magic overloading 
    methods is declared <em>static</em>.
   </p>

   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <p class="para">
     The return value of <a href="language.oop5.overloading.php#object.set" class="link">__set()</a> is ignored
     because of the way PHP processes the assignment operator.
     Similarly, <a href="language.oop5.overloading.php#object.get" class="link">__get()</a> is never called when
     chaining assignments together like this:
     <em><div class="cdata"><pre> $a = $obj-&gt;b = 8; </pre></div></em>
    </p>
   </p></blockquote>

   <div class="example" id="language.oop5.interfaces.examples.ex2">
    <p><strong>Example #1 
     Overloading properties via the <a href="language.oop5.overloading.php#object.get" class="link">__get()</a>,
     <a href="language.oop5.overloading.php#object.set" class="link">__set()</a>, <a href="language.oop5.overloading.php#object.isset" class="link">__isset()</a>
     and <a href="language.oop5.overloading.php#object.unset" class="link">__unset()</a> methods
    </strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">PropertyTest<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">/**&nbsp;&nbsp;Location&nbsp;for&nbsp;overloaded&nbsp;data.&nbsp;&nbsp;*/<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">private&nbsp;</span><span style="color: #0000BB">$data&nbsp;</span><span style="color: #007700">=&nbsp;array();<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">/**&nbsp;&nbsp;Overloading&nbsp;not&nbsp;used&nbsp;on&nbsp;declared&nbsp;properties.&nbsp;&nbsp;*/<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">public&nbsp;</span><span style="color: #0000BB">$declared&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">;<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">/**&nbsp;&nbsp;Overloading&nbsp;only&nbsp;used&nbsp;on&nbsp;this&nbsp;when&nbsp;accessed&nbsp;outside&nbsp;the&nbsp;class.&nbsp;&nbsp;*/<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">private&nbsp;</span><span style="color: #0000BB">$hidden&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">;<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">__set</span><span style="color: #007700">(</span><span style="color: #0000BB">$name</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$value</span><span style="color: #007700">)<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"Setting&nbsp;'</span><span style="color: #0000BB">$name</span><span style="color: #DD0000">'&nbsp;to&nbsp;'</span><span style="color: #0000BB">$value</span><span style="color: #DD0000">'\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">data</span><span style="color: #007700">[</span><span style="color: #0000BB">$name</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #0000BB">$value</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">__get</span><span style="color: #007700">(</span><span style="color: #0000BB">$name</span><span style="color: #007700">)<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"Getting&nbsp;'</span><span style="color: #0000BB">$name</span><span style="color: #DD0000">'\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(</span><span style="color: #0000BB">array_key_exists</span><span style="color: #007700">(</span><span style="color: #0000BB">$name</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">data</span><span style="color: #007700">))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">data</span><span style="color: #007700">[</span><span style="color: #0000BB">$name</span><span style="color: #007700">];<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$trace&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">debug_backtrace</span><span style="color: #007700">();<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">trigger_error</span><span style="color: #007700">(<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'Undefined&nbsp;property&nbsp;via&nbsp;__get():&nbsp;'&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">$name&nbsp;</span><span style="color: #007700">.<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'&nbsp;in&nbsp;'&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">$trace</span><span style="color: #007700">[</span><span style="color: #0000BB">0</span><span style="color: #007700">][</span><span style="color: #DD0000">'file'</span><span style="color: #007700">]&nbsp;.<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'&nbsp;on&nbsp;line&nbsp;'&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">$trace</span><span style="color: #007700">[</span><span style="color: #0000BB">0</span><span style="color: #007700">][</span><span style="color: #DD0000">'line'</span><span style="color: #007700">],<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">E_USER_NOTICE</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">null</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">/**&nbsp;&nbsp;As&nbsp;of&nbsp;PHP&nbsp;5.1.0&nbsp;&nbsp;*/<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">public&nbsp;function&nbsp;</span><span style="color: #0000BB">__isset</span><span style="color: #007700">(</span><span style="color: #0000BB">$name</span><span style="color: #007700">)<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"Is&nbsp;'</span><span style="color: #0000BB">$name</span><span style="color: #DD0000">'&nbsp;set?\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;isset(</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">data</span><span style="color: #007700">[</span><span style="color: #0000BB">$name</span><span style="color: #007700">]);<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">/**&nbsp;&nbsp;As&nbsp;of&nbsp;PHP&nbsp;5.1.0&nbsp;&nbsp;*/<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">public&nbsp;function&nbsp;</span><span style="color: #0000BB">__unset</span><span style="color: #007700">(</span><span style="color: #0000BB">$name</span><span style="color: #007700">)<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"Unsetting&nbsp;'</span><span style="color: #0000BB">$name</span><span style="color: #DD0000">'\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;unset(</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">data</span><span style="color: #007700">[</span><span style="color: #0000BB">$name</span><span style="color: #007700">]);<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">/**&nbsp;&nbsp;Not&nbsp;a&nbsp;magic&nbsp;method,&nbsp;just&nbsp;here&nbsp;for&nbsp;example.&nbsp;&nbsp;*/<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">public&nbsp;function&nbsp;</span><span style="color: #0000BB">getHidden</span><span style="color: #007700">()<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">hidden</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br /><br />echo&nbsp;</span><span style="color: #DD0000">"&lt;pre&gt;\n"</span><span style="color: #007700">;<br /><br /></span><span style="color: #0000BB">$obj&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">PropertyTest</span><span style="color: #007700">;<br /><br /></span><span style="color: #0000BB">$obj</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">a&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">;<br />echo&nbsp;</span><span style="color: #0000BB">$obj</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">a&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">"\n\n"</span><span style="color: #007700">;<br /><br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(isset(</span><span style="color: #0000BB">$obj</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">a</span><span style="color: #007700">));<br />unset(</span><span style="color: #0000BB">$obj</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">a</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(isset(</span><span style="color: #0000BB">$obj</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">a</span><span style="color: #007700">));<br />echo&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br /><br />echo&nbsp;</span><span style="color: #0000BB">$obj</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">declared&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">"\n\n"</span><span style="color: #007700">;<br /><br />echo&nbsp;</span><span style="color: #DD0000">"Let's&nbsp;experiment&nbsp;with&nbsp;the&nbsp;private&nbsp;property&nbsp;named&nbsp;'hidden':\n"</span><span style="color: #007700">;<br />echo&nbsp;</span><span style="color: #DD0000">"Privates&nbsp;are&nbsp;visible&nbsp;inside&nbsp;the&nbsp;class,&nbsp;so&nbsp;__get()&nbsp;not&nbsp;used...\n"</span><span style="color: #007700">;<br />echo&nbsp;</span><span style="color: #0000BB">$obj</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">getHidden</span><span style="color: #007700">()&nbsp;.&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br />echo&nbsp;</span><span style="color: #DD0000">"Privates&nbsp;not&nbsp;visible&nbsp;outside&nbsp;of&nbsp;class,&nbsp;so&nbsp;__get()&nbsp;is&nbsp;used...\n"</span><span style="color: #007700">;<br />echo&nbsp;</span><span style="color: #0000BB">$obj</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">hidden&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

    <div class="example-contents"><p>The above example will output:</p></div>
    <div class="example-contents screen">
<div class="cdata"><pre>
Setting &#039;a&#039; to &#039;1&#039;
Getting &#039;a&#039;
1

Is &#039;a&#039; set?
bool(true)
Unsetting &#039;a&#039;
Is &#039;a&#039; set?
bool(false)

1

Let&#039;s experiment with the private property named &#039;hidden&#039;:
Privates are visible inside the class, so __get() not used...
2
Privates not visible outside of class, so __get() is used...
Getting &#039;hidden&#039;


Notice:  Undefined property via __get(): hidden in &lt;file&gt; on line 70 in &lt;file&gt; on line 29
</pre></div>
    </div>

   </div>
  </div>

  <div class="sect2" id="language.oop5.overloading.methods">
   <h3 class="title">Method overloading</h3>

   <div class="methodsynopsis dc-description" id="object.call">
    <span class="modifier">public</span> <span class="type"><a href="language.pseudo-types.php#language.types.mixed" class="type mixed">mixed</a></span> <span class="methodname"><strong>__call</strong></span>
     ( <span class="methodparam"><span class="type">string</span> <code class="parameter">$name</code></span>
    , <span class="methodparam"><span class="type">array</span> <code class="parameter">$arguments</code></span>
    )</div>

   <div class="methodsynopsis dc-description" id="object.callstatic">
    <span class="modifier">public static</span> <span class="type"><a href="language.pseudo-types.php#language.types.mixed" class="type mixed">mixed</a></span> <span class="methodname"><strong>__callStatic</strong></span>
     ( <span class="methodparam"><span class="type">string</span> <code class="parameter">$name</code></span>
    , <span class="methodparam"><span class="type">array</span> <code class="parameter">$arguments</code></span>
    )</div>


   <p class="para">
    <a href="language.oop5.overloading.php#object.call" class="link">__call()</a> is triggered when invoking
    inaccessible methods in an object context.
   </p>

   <p class="para">
    <a href="language.oop5.overloading.php#object.callstatic" class="link">__callStatic()</a> is triggered when invoking
    inaccessible methods in a static context.
   </p>

   <p class="para">
    The <var class="varname"><var class="varname">$name</var></var> argument is the name of the
    method being called. The <var class="varname"><var class="varname">$arguments</var></var>
    argument is an enumerated array containing the parameters
    passed to the <var class="varname"><var class="varname">$name</var></var>&#039;ed method.
   </p>

   <div class="example" id="language.oop5.interfaces.examples.ex3">
    <p><strong>Example #2 
     Overloading methods via the <a href="language.oop5.overloading.php#object.call" class="link">__call()</a>
     and <a href="language.oop5.overloading.php#object.callstatic" class="link">__callStatic()</a> methods
    </strong></p>
    <div class="example-contents">
  <div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">MethodTest<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">__call</span><span style="color: #007700">(</span><span style="color: #0000BB">$name</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$arguments</span><span style="color: #007700">)<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;Note:&nbsp;value&nbsp;of&nbsp;$name&nbsp;is&nbsp;case&nbsp;sensitive.<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"Calling&nbsp;object&nbsp;method&nbsp;'</span><span style="color: #0000BB">$name</span><span style="color: #DD0000">'&nbsp;"<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">implode</span><span style="color: #007700">(</span><span style="color: #DD0000">',&nbsp;'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$arguments</span><span style="color: #007700">).&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">/**&nbsp;&nbsp;As&nbsp;of&nbsp;PHP&nbsp;5.3.0&nbsp;&nbsp;*/<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">public&nbsp;static&nbsp;function&nbsp;</span><span style="color: #0000BB">__callStatic</span><span style="color: #007700">(</span><span style="color: #0000BB">$name</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$arguments</span><span style="color: #007700">)<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;Note:&nbsp;value&nbsp;of&nbsp;$name&nbsp;is&nbsp;case&nbsp;sensitive.<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"Calling&nbsp;static&nbsp;method&nbsp;'</span><span style="color: #0000BB">$name</span><span style="color: #DD0000">'&nbsp;"<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">implode</span><span style="color: #007700">(</span><span style="color: #DD0000">',&nbsp;'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$arguments</span><span style="color: #007700">).&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br /></span><span style="color: #0000BB">$obj&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">MethodTest</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$obj</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">runTest</span><span style="color: #007700">(</span><span style="color: #DD0000">'in&nbsp;object&nbsp;context'</span><span style="color: #007700">);<br /><br /></span><span style="color: #0000BB">MethodTest</span><span style="color: #007700">::</span><span style="color: #0000BB">runTest</span><span style="color: #007700">(</span><span style="color: #DD0000">'in&nbsp;static&nbsp;context'</span><span style="color: #007700">);&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;As&nbsp;of&nbsp;PHP&nbsp;5.3.0<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

    <div class="example-contents"><p>The above example will output:</p></div>
    <div class="example-contents screen">
<div class="cdata"><pre>
Calling object method &#039;runTest&#039; in object context
Calling static method &#039;runTest&#039; in static context
</pre></div>
    </div>
   </div>

  </div>

 </div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.oop5.overloading&amp;redirect=http://php.net/manual/en/language.oop5.overloading.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">57 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="78619">  <div class="votes">
    <div id="Vu78619">
    <a href="/manual/vote-note.php?id=78619&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd78619">
    <a href="/manual/vote-note.php?id=78619&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V78619" title="90% like this...">
    894
    </div>
  </div>
  <a href="#78619" class="name">
  <strong class="user"><em>php_is_painful at world dot real</em></strong></a><a class="genanchor" href="#78619"> &para;</a><div class="date" title="2007-10-19 07:49"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom78619">
<div class="phpcode"><code><span class="html">
This is a misuse of the term overloading. This article should call this technique "interpreter hooks".</span>
</code></div>
  </div>
 </div>
  <div class="note" id="108040">  <div class="votes">
    <div id="Vu108040">
    <a href="/manual/vote-note.php?id=108040&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd108040">
    <a href="/manual/vote-note.php?id=108040&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V108040" title="82% like this...">
    152
    </div>
  </div>
  <a href="#108040" class="name">
  <strong class="user"><em>theaceofthespade at gmail dot com</em></strong></a><a class="genanchor" href="#108040"> &para;</a><div class="date" title="2012-03-23 09:35"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom108040">
<div class="phpcode"><code><span class="html">
A word of warning!&nbsp; It may seem obvious, but remember, when deciding whether to use __get, __set, and __call as a way to access the data in your class (as opposed to hard-coding getters and setters), keep in mind that this will prevent any sort of autocomplete, highlighting, or documentation that your ide mite do.<br /><br />Furthermore, it beyond personal preference when working with other people.&nbsp; Even without an ide, it can be much easier to go through and look at hardcoded member and method definitions in code, than having to sift through code and piece together the method/member names that are assembled in __get and __set.<br /><br />If you still decide to use __get and __set for everything in your class, be sure to include detailed comments and documenting, so that the people you are working with (or the people who inherit the code from you at a later date) don't have to waste time interpreting your code just to be able to use it.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119898">  <div class="votes">
    <div id="Vu119898">
    <a href="/manual/vote-note.php?id=119898&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119898">
    <a href="/manual/vote-note.php?id=119898&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119898" title="86% like this...">
    32
    </div>
  </div>
  <a href="#119898" class="name">
  <strong class="user"><em>pogregoire##live.fr</em></strong></a><a class="genanchor" href="#119898"> &para;</a><div class="date" title="2016-09-16 04:17"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119898">
<div class="phpcode"><code><span class="html">
It is important to understand that encapsulation can be very easily violated in PHP. for example :<br />class Object{<br /><br />}<br /><br />$Object = new Object();<br />$Objet-&gt;barbarianProperties&nbsp; = 'boom';<br /><br />var_dump($Objet);// object(Objet)#1 (1) { ["barbarianProperties"]=&gt; string(7) "boom" }<br /><br />Hence it is possible to add a propertie out form the class definition.<br />It is then a necessity in order to protect encapsulation to introduce __set() in the class :<br /><br />class Objet{<br />&nbsp; &nbsp; public function __set($name,$value){<br />&nbsp; &nbsp; &nbsp; &nbsp; throw new Exception ('no');<br />&nbsp; &nbsp; }<br />}</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119407">  <div class="votes">
    <div id="Vu119407">
    <a href="/manual/vote-note.php?id=119407&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119407">
    <a href="/manual/vote-note.php?id=119407&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119407" title="82% like this...">
    50
    </div>
  </div>
  <a href="#119407" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#119407"> &para;</a><div class="date" title="2016-05-29 10:13"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119407">
<div class="phpcode"><code><span class="html">
First off all, if you read this, please upvote the first comment on this list that states that “overloading” is a bad term for this behaviour. Because it REALLY is a bad name. You’re giving new definition to an already accepted IT-branch terminology.<br /><br />Second, I concur with all criticism you will read about this functionality. Just as naming it “overloading”, the functionality is also very bad practice. Please don’t use this in a production environment. To be honest, avoid to use it at all. Especially if you are a beginner at PHP. It can make your code react very unexpectedly. In which case you MIGHT be learning invalid coding!<br /><br />And last, because of __get, __set and __call the following code executes. Which is abnormal behaviour. And can cause a lot of problems/bugs.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">BadPractice </span><span class="keyword">{<br />&nbsp; </span><span class="comment">// Two real properties<br />&nbsp; </span><span class="keyword">public </span><span class="default">$DontAllowVariableNameWithTypos </span><span class="keyword">= </span><span class="default">true</span><span class="keyword">;<br />&nbsp; protected </span><span class="default">$Number </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />&nbsp; </span><span class="comment">// One private method<br />&nbsp; </span><span class="keyword">private function </span><span class="default">veryPrivateMethod</span><span class="keyword">() { }<br />&nbsp; </span><span class="comment">// And three very magic methods that will make everything look inconsistent<br />&nbsp; // with all you have ever learned about PHP.<br />&nbsp; </span><span class="keyword">public function </span><span class="default">__get</span><span class="keyword">(</span><span class="default">$n</span><span class="keyword">) {}<br />&nbsp; public function </span><span class="default">__set</span><span class="keyword">(</span><span class="default">$n</span><span class="keyword">, </span><span class="default">$v</span><span class="keyword">) {}<br />&nbsp; public function </span><span class="default">__call</span><span class="keyword">(</span><span class="default">$n</span><span class="keyword">, </span><span class="default">$v</span><span class="keyword">) {}<br />}<br /><br /></span><span class="comment">// Let's see our BadPractice in a production environment!<br /></span><span class="default">$UnexpectedBehaviour </span><span class="keyword">= new </span><span class="default">BadPractice</span><span class="keyword">;<br /><br /></span><span class="comment">// No syntax highlighting on most IDE's<br /></span><span class="default">$UnexpectedBehaviour</span><span class="keyword">-&gt;</span><span class="default">SynTaxHighlighting </span><span class="keyword">= </span><span class="default">false</span><span class="keyword">;<br /><br /></span><span class="comment">// No autocompletion on most IDE's<br /></span><span class="default">$UnexpectedBehaviour</span><span class="keyword">-&gt;</span><span class="default">AutoCompletion </span><span class="keyword">= </span><span class="default">false</span><span class="keyword">;<br /><br /></span><span class="comment">// Which will lead to problems waiting to happen<br /></span><span class="default">$UnexpectedBehaviour</span><span class="keyword">-&gt;</span><span class="default">DontAllowVariableNameWithTyphos </span><span class="keyword">= </span><span class="default">false</span><span class="keyword">; </span><span class="comment">// see if below<br /><br />// Get, Set and Call anything you want!<br /></span><span class="default">$UnexpectedBehaviour</span><span class="keyword">-&gt;</span><span class="default">EveryPosibleMethodCallAllowed</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">, </span><span class="string">'Why Not?'</span><span class="keyword">);<br /><br /></span><span class="comment">// And sure, why not use the most illegal property names you can think off<br /></span><span class="default">$UnexpectedBehaviour</span><span class="keyword">-&gt;{</span><span class="string">'100%Illegal+Names'</span><span class="keyword">} = </span><span class="string">'allowed'</span><span class="keyword">;<br /><br /></span><span class="comment">// This Very confusing syntax seems to allow access to $Number but because of<br />// the lowered visibility it goes to __set()<br /></span><span class="default">$UnexpectedBehaviour</span><span class="keyword">-&gt;</span><span class="default">Number </span><span class="keyword">= </span><span class="default">10</span><span class="keyword">;<br /><br /></span><span class="comment">// We can SEEM to increment it too! (that's really dynamic! :-) NULL++ LMAO<br /></span><span class="default">$UnexpectedBehaviour</span><span class="keyword">-&gt;</span><span class="default">Number</span><span class="keyword">++;<br /><br /></span><span class="comment">// this ofcourse outputs NULL (through __get) and not the PERHAPS expected 11<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$UnexpectedBehaviour</span><span class="keyword">-&gt;</span><span class="default">Number</span><span class="keyword">);<br /><br /></span><span class="comment">// and sure, private method calls LOOK valid now!<br />// (this goes to __call, so no fatal error)<br /></span><span class="default">$UnexpectedBehaviour</span><span class="keyword">-&gt;</span><span class="default">veryPrivateMethod</span><span class="keyword">();<br /><br /></span><span class="comment">// Because the previous was __set to false, next expression is true<br />// if we didn't had __set, the previous assignment would have failed<br />// then you would have corrected the typho and this code will not have<br />// been executed. (This can really be a BIG PAIN)<br /></span><span class="keyword">if (</span><span class="default">$UnexpectedBehaviour</span><span class="keyword">-&gt;</span><span class="default">DontAllowVariableNameWithTypos</span><span class="keyword">) {<br />&nbsp; </span><span class="comment">// if this code block would have deleted a file, or do a deletion on<br />&nbsp; // a database, you could really be VERY SAD for a long time!<br />&nbsp; </span><span class="default">$UnexpectedBehaviour</span><span class="keyword">-&gt;</span><span class="default">executeStuffYouDontWantHere</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">);<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="77843">  <div class="votes">
    <div id="Vu77843">
    <a href="/manual/vote-note.php?id=77843&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd77843">
    <a href="/manual/vote-note.php?id=77843&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V77843" title="80% like this...">
    63
    </div>
  </div>
  <a href="#77843" class="name">
  <strong class="user"><em>egingell at sisna dot com</em></strong></a><a class="genanchor" href="#77843"> &para;</a><div class="date" title="2007-09-15 05:12"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom77843">
<div class="phpcode"><code><span class="html">
Small vocabulary note: This is *not* "overloading", this is "overriding".<br /><br />Overloading: Declaring a function multiple times with a different set of parameters like this:<br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">foo</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">) {<br />&nbsp; &nbsp; return </span><span class="default">$a</span><span class="keyword">;<br />}<br /><br />function </span><span class="default">foo</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">) {<br />&nbsp; &nbsp; return </span><span class="default">$a </span><span class="keyword">+ </span><span class="default">$b</span><span class="keyword">;<br />}<br /><br />echo </span><span class="default">foo</span><span class="keyword">(</span><span class="default">5</span><span class="keyword">); </span><span class="comment">// Prints "5"<br /></span><span class="keyword">echo </span><span class="default">foo</span><span class="keyword">(</span><span class="default">5</span><span class="keyword">, </span><span class="default">2</span><span class="keyword">); </span><span class="comment">// Prints "7"<br /><br /></span><span class="default">?&gt;<br /></span><br />Overriding: Replacing the parent class's method(s) with a new method by redeclaring it like this:<br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">foo </span><span class="keyword">{<br />&nbsp; &nbsp; function new(</span><span class="default">$args</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Do something.<br />&nbsp; &nbsp; </span><span class="keyword">}<br />}<br /><br />class </span><span class="default">bar </span><span class="keyword">extends </span><span class="default">foo </span><span class="keyword">{<br />&nbsp; &nbsp; function new(</span><span class="default">$args</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Do something different.<br />&nbsp; &nbsp; </span><span class="keyword">}<br />}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117060">  <div class="votes">
    <div id="Vu117060">
    <a href="/manual/vote-note.php?id=117060&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117060">
    <a href="/manual/vote-note.php?id=117060&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117060" title="77% like this...">
    30
    </div>
  </div>
  <a href="#117060" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#117060"> &para;</a><div class="date" title="2015-04-08 03:34"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117060">
<div class="phpcode"><code><span class="html">
Using magic methods, especially __get(), __set(), and __call() will effectively disable autocomplete in most IDEs (eg.: IntelliSense) for the affected classes.<br /><br />To overcome this inconvenience, use phpDoc to let the IDE know about these magic methods and properties: @method, @property, @property-read, @property-write.<br /><br />/**<br /> * @property-read name<br /> * @property-read price<br /> */<br />class MyClass<br />{<br />&nbsp; &nbsp; private $properties = array('name' =&gt; 'IceFruit', 'price' =&gt; 2.49)<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function __get($name)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return $this-&gt;properties($name);<br />&nbsp; &nbsp; }<br />}</span>
</code></div>
  </div>
 </div>
  <div class="note" id="87785">  <div class="votes">
    <div id="Vu87785">
    <a href="/manual/vote-note.php?id=87785&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd87785">
    <a href="/manual/vote-note.php?id=87785&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V87785" title="77% like this...">
    5
    </div>
  </div>
  <a href="#87785" class="name">
  <strong class="user"><em>Ant P.</em></strong></a><a class="genanchor" href="#87785"> &para;</a><div class="date" title="2008-12-21 08:40"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom87785">
<div class="phpcode"><code><span class="html">
Be extra careful when using __call():&nbsp; if you typo a function call somewhere it won't trigger an undefined function error, but get passed to __call() instead, possibly causing all sorts of bizarre side effects.<br />In versions before 5.3 without __callStatic, static calls to nonexistent functions also fall through to __call!<br />This caused me hours of confusion, hopefully this comment will save someone else from the same.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="76259">  <div class="votes">
    <div id="Vu76259">
    <a href="/manual/vote-note.php?id=76259&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd76259">
    <a href="/manual/vote-note.php?id=76259&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V76259" title="73% like this...">
    12
    </div>
  </div>
  <a href="#76259" class="name">
  <strong class="user"><em>alexandre at nospam dot gaigalas dot net</em></strong></a><a class="genanchor" href="#76259"> &para;</a><div class="date" title="2007-07-07 10:59"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom76259">
<div class="phpcode"><code><span class="html">
PHP 5.2.1<br /><br />Its possible to call magic methods with invalid names using variable method/property names:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">foo<br /></span><span class="keyword">{<br />&nbsp; &nbsp; function </span><span class="default">__get</span><span class="keyword">(</span><span class="default">$n</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$n</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; function </span><span class="default">__call</span><span class="keyword">(</span><span class="default">$m</span><span class="keyword">, </span><span class="default">$a</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$m</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$test </span><span class="keyword">= new </span><span class="default">foo</span><span class="keyword">;<br /></span><span class="default">$varname </span><span class="keyword">= </span><span class="string">'invalid,variable+name'</span><span class="keyword">;<br /></span><span class="default">$test</span><span class="keyword">-&gt;</span><span class="default">$varname</span><span class="keyword">;<br /></span><span class="default">$test</span><span class="keyword">-&gt;</span><span class="default">$varname</span><span class="keyword">();<br /><br /></span><span class="default">?&gt;<br /></span><br />I just don't know if it is a bug or a feature :)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="60009">  <div class="votes">
    <div id="Vu60009">
    <a href="/manual/vote-note.php?id=60009&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd60009">
    <a href="/manual/vote-note.php?id=60009&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V60009" title="72% like this...">
    5
    </div>
  </div>
  <a href="#60009" class="name">
  <strong class="user"><em>PHP at jyopp dotKomm</em></strong></a><a class="genanchor" href="#60009"> &para;</a><div class="date" title="2005-12-22 11:01"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom60009">
<div class="phpcode"><code><span class="html">
Here's a useful class for logging function calls.&nbsp; It stores a sequence of calls and arguments which can then be applied to objects later.&nbsp; This can be used to script common sequences of operations, or to make "pluggable" operation sequences in header files that can be replayed on objects later.<br /><br />If it is instantiated with an object to shadow, it behaves as a mediator and executes the calls on this object as they come in, passing back the values from the execution.<br /><br />This is a very general implementation; it should be changed if error codes or exceptions need to be handled during the Replay process.<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">MethodCallLog </span><span class="keyword">{<br />&nbsp; &nbsp; private </span><span class="default">$callLog </span><span class="keyword">= array();<br />&nbsp; &nbsp; private </span><span class="default">$object</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$object </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">object </span><span class="keyword">= </span><span class="default">$object</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public function </span><span class="default">__call</span><span class="keyword">(</span><span class="default">$m</span><span class="keyword">, </span><span class="default">$a</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">callLog</span><span class="keyword">[] = array(</span><span class="default">$m</span><span class="keyword">, </span><span class="default">$a</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">object</span><span class="keyword">) return </span><span class="default">call_user_func_array</span><span class="keyword">(array(&amp;</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">object</span><span class="keyword">,</span><span class="default">$m</span><span class="keyword">),</span><span class="default">$a</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">true</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public function </span><span class="default">Replay</span><span class="keyword">(&amp;</span><span class="default">$object</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach (</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">callLog </span><span class="keyword">as </span><span class="default">$c</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">call_user_func_array</span><span class="keyword">(array(&amp;</span><span class="default">$object</span><span class="keyword">,</span><span class="default">$c</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]), </span><span class="default">$c</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public function </span><span class="default">GetEntries</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$rVal </span><span class="keyword">= array();<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach (</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">callLog </span><span class="keyword">as </span><span class="default">$c</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$rVal</span><span class="keyword">[] = </span><span class="string">"</span><span class="default">$c</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]</span><span class="string">("</span><span class="keyword">.</span><span class="default">implode</span><span class="keyword">(</span><span class="string">', '</span><span class="keyword">, </span><span class="default">$c</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]).</span><span class="string">");"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$rVal</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public function </span><span class="default">Clear</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">callLog </span><span class="keyword">= array();<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$log </span><span class="keyword">= new </span><span class="default">MethodCallLog</span><span class="keyword">();<br /></span><span class="default">$log</span><span class="keyword">-&gt;</span><span class="default">Method1</span><span class="keyword">();<br /></span><span class="default">$log</span><span class="keyword">-&gt;</span><span class="default">Method2</span><span class="keyword">(</span><span class="string">"Value"</span><span class="keyword">);<br /></span><span class="default">$log</span><span class="keyword">-&gt;</span><span class="default">Method1</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">, </span><span class="default">$c</span><span class="keyword">);<br /></span><span class="comment">// Execute these method calls on a set of objects...<br /></span><span class="keyword">foreach (</span><span class="default">$array </span><span class="keyword">as </span><span class="default">$o</span><span class="keyword">) </span><span class="default">$log</span><span class="keyword">-&gt;</span><span class="default">Replay</span><span class="keyword">(</span><span class="default">$o</span><span class="keyword">);<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="97918">  <div class="votes">
    <div id="Vu97918">
    <a href="/manual/vote-note.php?id=97918&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd97918">
    <a href="/manual/vote-note.php?id=97918&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V97918" title="70% like this...">
    22
    </div>
  </div>
  <a href="#97918" class="name">
  <strong class="user"><em>navarr at gtaero dot net</em></strong></a><a class="genanchor" href="#97918"> &para;</a><div class="date" title="2010-05-15 01:25"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom97918">
<div class="phpcode"><code><span class="html">
If you want to make it work more naturally for arrays $obj-&gt;variable[] etc you'll need to return __get by reference.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Variables<br /></span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">()<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">session_id</span><span class="keyword">() === </span><span class="string">""</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">session_start</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; public function </span><span class="default">__set</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">,</span><span class="default">$value</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">"Variables"</span><span class="keyword">][</span><span class="default">$name</span><span class="keyword">] = </span><span class="default">$value</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; public function &amp;</span><span class="default">__get</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">"Variables"</span><span class="keyword">][</span><span class="default">$name</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; public function </span><span class="default">__isset</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return isset(</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">"Variables"</span><span class="keyword">][</span><span class="default">$name</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="103478">  <div class="votes">
    <div id="Vu103478">
    <a href="/manual/vote-note.php?id=103478&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd103478">
    <a href="/manual/vote-note.php?id=103478&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V103478" title="69% like this...">
    17
    </div>
  </div>
  <a href="#103478" class="name">
  <strong class="user"><em>jan dot machala at email dot cz</em></strong></a><a class="genanchor" href="#103478"> &para;</a><div class="date" title="2011-04-15 03:47"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom103478">
<div class="phpcode"><code><span class="html">
Example of usage __call() to have implicit getters and setters<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Entity </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">__call</span><span class="keyword">(</span><span class="default">$methodName</span><span class="keyword">, </span><span class="default">$args</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">preg_match</span><span class="keyword">(</span><span class="string">'~^(set|get)([A-Z])(.*)$~'</span><span class="keyword">, </span><span class="default">$methodName</span><span class="keyword">, </span><span class="default">$matches</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$property </span><span class="keyword">= </span><span class="default">strtolower</span><span class="keyword">(</span><span class="default">$matches</span><span class="keyword">[</span><span class="default">2</span><span class="keyword">]) . </span><span class="default">$matches</span><span class="keyword">[</span><span class="default">3</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (!</span><span class="default">property_exists</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">, </span><span class="default">$property</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">MemberAccessException</span><span class="keyword">(</span><span class="string">'Property ' </span><span class="keyword">. </span><span class="default">$property </span><span class="keyword">. </span><span class="string">' not exists'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; switch(</span><span class="default">$matches</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">'set'</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">checkArguments</span><span class="keyword">(</span><span class="default">$args</span><span class="keyword">, </span><span class="default">1</span><span class="keyword">, </span><span class="default">1</span><span class="keyword">, </span><span class="default">$methodName</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">set</span><span class="keyword">(</span><span class="default">$property</span><span class="keyword">, </span><span class="default">$args</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">'get'</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">checkArguments</span><span class="keyword">(</span><span class="default">$args</span><span class="keyword">, </span><span class="default">0</span><span class="keyword">, </span><span class="default">0</span><span class="keyword">, </span><span class="default">$methodName</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">get</span><span class="keyword">(</span><span class="default">$property</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">'default'</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">MemberAccessException</span><span class="keyword">(</span><span class="string">'Method ' </span><span class="keyword">. </span><span class="default">$methodName </span><span class="keyword">. </span><span class="string">' not exists'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">get</span><span class="keyword">(</span><span class="default">$property</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$property</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">set</span><span class="keyword">(</span><span class="default">$property</span><span class="keyword">, </span><span class="default">$value</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$property </span><span class="keyword">= </span><span class="default">$value</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; protected function </span><span class="default">checkArguments</span><span class="keyword">(array </span><span class="default">$args</span><span class="keyword">, </span><span class="default">$min</span><span class="keyword">, </span><span class="default">$max</span><span class="keyword">, </span><span class="default">$methodName</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$argc </span><span class="keyword">= </span><span class="default">count</span><span class="keyword">(</span><span class="default">$args</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$argc </span><span class="keyword">&lt; </span><span class="default">$min </span><span class="keyword">|| </span><span class="default">$argc </span><span class="keyword">&gt; </span><span class="default">$max</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">MemberAccessException</span><span class="keyword">(</span><span class="string">'Method ' </span><span class="keyword">. </span><span class="default">$methodName </span><span class="keyword">. </span><span class="string">' needs minimaly ' </span><span class="keyword">. </span><span class="default">$min </span><span class="keyword">. </span><span class="string">' and maximaly ' </span><span class="keyword">. </span><span class="default">$max </span><span class="keyword">. </span><span class="string">' arguments. ' </span><span class="keyword">. </span><span class="default">$argc </span><span class="keyword">. </span><span class="string">' arguments given.'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">MemberAccessException </span><span class="keyword">extends </span><span class="default">Exception</span><span class="keyword">{}<br /><br />class </span><span class="default">Foo </span><span class="keyword">extends </span><span class="default">Entity </span><span class="keyword">{<br />&nbsp; &nbsp; protected </span><span class="default">$a</span><span class="keyword">;<br />}<br /><br /></span><span class="default">$foo </span><span class="keyword">= new </span><span class="default">Foo</span><span class="keyword">();<br /></span><span class="default">$foo</span><span class="keyword">-&gt;</span><span class="default">setA</span><span class="keyword">(</span><span class="string">'some'</span><span class="keyword">); </span><span class="comment">// outputs some<br /></span><span class="keyword">echo </span><span class="default">$foo</span><span class="keyword">-&gt;</span><span class="default">getA</span><span class="keyword">();<br /><br />class </span><span class="default">Bar </span><span class="keyword">extends </span><span class="default">Entity </span><span class="keyword">{<br />&nbsp; &nbsp; protected </span><span class="default">$a</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Custom setter.<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">setA</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (!</span><span class="default">preg_match</span><span class="keyword">(</span><span class="string">'~^[0-9a-z]+$~i'</span><span class="keyword">, </span><span class="default">$a</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">MemberAccessException</span><span class="keyword">(</span><span class="string">'A can be only alphanumerical'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">a </span><span class="keyword">= </span><span class="default">$a</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$bar </span><span class="keyword">= new </span><span class="default">Bar</span><span class="keyword">();<br /></span><span class="default">$bar</span><span class="keyword">-&gt;</span><span class="default">setA</span><span class="keyword">(</span><span class="string">'abc123'</span><span class="keyword">); </span><span class="comment">// ok<br /></span><span class="default">$bar</span><span class="keyword">-&gt;</span><span class="default">setA</span><span class="keyword">(</span><span class="string">'[]/*@...'</span><span class="keyword">); </span><span class="comment">// throws exception<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="69370">  <div class="votes">
    <div id="Vu69370">
    <a href="/manual/vote-note.php?id=69370&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd69370">
    <a href="/manual/vote-note.php?id=69370&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V69370" title="71% like this...">
    3
    </div>
  </div>
  <a href="#69370" class="name">
  <strong class="user"><em>jstubbs at work-at dot co dot jp</em></strong></a><a class="genanchor" href="#69370"> &para;</a><div class="date" title="2006-09-02 09:12"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom69370">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php $myclass</span><span class="keyword">-&gt;</span><span class="default">foo</span><span class="keyword">[</span><span class="string">'bar'</span><span class="keyword">] = </span><span class="string">'baz'</span><span class="keyword">; </span><span class="default">?&gt;<br /></span> <br />When overriding __get and __set, the above code can work (as expected) but it depends on your __get implementation rather than your __set. In fact, __set is never called with the above code. It appears that PHP (at least as of 5.1) uses a reference to whatever was returned by __get. To be more verbose, the above code is essentially identical to:<br /> <br /><span class="default">&lt;?php<br />$tmp_array </span><span class="keyword">= &amp;</span><span class="default">$myclass</span><span class="keyword">-&gt;</span><span class="default">foo</span><span class="keyword">;<br /></span><span class="default">$tmp_array</span><span class="keyword">[</span><span class="string">'bar'</span><span class="keyword">] = </span><span class="string">'baz'</span><span class="keyword">;<br />unset(</span><span class="default">$tmp_array</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />Therefore, the above won't do anything if your __get implementation resembles this:<br /><br /><span class="default">&lt;?php <br /></span><span class="keyword">function </span><span class="default">__get</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">) {<br />&nbsp; &nbsp; return </span><span class="default">array_key_exists</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">, </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">values</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; ? </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">values</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">] : </span><span class="default">null</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />You will actually need to set the value in __get and return that, as in the following code:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">__get</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">) {<br />&nbsp; &nbsp; if (!</span><span class="default">array_key_exists</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">, </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">values</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">values</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">] = </span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">values</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">];<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="76325">  <div class="votes">
    <div id="Vu76325">
    <a href="/manual/vote-note.php?id=76325&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd76325">
    <a href="/manual/vote-note.php?id=76325&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V76325" title="68% like this...">
    8
    </div>
  </div>
  <a href="#76325" class="name">
  <strong class="user"><em>Adeel Khan</em></strong></a><a class="genanchor" href="#76325"> &para;</a><div class="date" title="2007-07-10 01:18"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom76325">
<div class="phpcode"><code><span class="html">
Observe:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Foo </span><span class="keyword">{<br />&nbsp; &nbsp; function </span><span class="default">__call</span><span class="keyword">(</span><span class="default">$m</span><span class="keyword">, </span><span class="default">$a</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; die(</span><span class="default">$m</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$foo </span><span class="keyword">= new </span><span class="default">Foo</span><span class="keyword">;<br />print </span><span class="default">$foo</span><span class="keyword">-&gt;{</span><span class="string">'wow!'</span><span class="keyword">}();<br /><br /></span><span class="comment">// outputs 'wow!'<br /></span><span class="default">?&gt;<br /></span><br />This method allows you to call functions with invalid characters.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="98402">  <div class="votes">
    <div id="Vu98402">
    <a href="/manual/vote-note.php?id=98402&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd98402">
    <a href="/manual/vote-note.php?id=98402&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V98402" title="66% like this...">
    6
    </div>
  </div>
  <a href="#98402" class="name">
  <strong class="user"><em>php at lanar dot com dot au</em></strong></a><a class="genanchor" href="#98402"> &para;</a><div class="date" title="2010-06-12 05:39"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom98402">
<div class="phpcode"><code><span class="html">
Note that __isset is not called on chained checks. <br />If isset( $x-&gt;a-&gt;b ) is executed where $x is a class with __isset() declared, __isset() is not called.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">demo<br /></span><span class="keyword">{<br />&nbsp; &nbsp; var </span><span class="default">$id </span><span class="keyword">;<br />&nbsp; &nbsp; function </span><span class="default">__construct</span><span class="keyword">( </span><span class="default">$id </span><span class="keyword">= </span><span class="string">'who knows' </span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">id </span><span class="keyword">= </span><span class="default">$id </span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; function </span><span class="default">__get</span><span class="keyword">( </span><span class="default">$prop </span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"\n"</span><span class="keyword">, </span><span class="default">__FILE__</span><span class="keyword">, </span><span class="string">':'</span><span class="keyword">, </span><span class="default">__LINE__</span><span class="keyword">, </span><span class="string">' '</span><span class="keyword">, </span><span class="default">__METHOD__</span><span class="keyword">, </span><span class="string">'('</span><span class="keyword">, </span><span class="default">$prop</span><span class="keyword">, </span><span class="string">') instance '</span><span class="keyword">, </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">id </span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; return new </span><span class="default">demo</span><span class="keyword">( </span><span class="string">'autocreated' </span><span class="keyword">) ; </span><span class="comment">// return a class anyway for the demo<br />&nbsp; &nbsp; </span><span class="keyword">}<br />&nbsp; &nbsp; function </span><span class="default">__isset</span><span class="keyword">( </span><span class="default">$prop </span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"\n"</span><span class="keyword">, </span><span class="default">__FILE__</span><span class="keyword">, </span><span class="string">':'</span><span class="keyword">, </span><span class="default">__LINE__</span><span class="keyword">, </span><span class="string">' '</span><span class="keyword">, </span><span class="default">__METHOD__</span><span class="keyword">, </span><span class="string">'('</span><span class="keyword">, </span><span class="default">$prop</span><span class="keyword">, </span><span class="string">') instance '</span><span class="keyword">, </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">id </span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">FALSE </span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">$x </span><span class="keyword">= new </span><span class="default">demo</span><span class="keyword">( </span><span class="string">'demo' </span><span class="keyword">) ;<br />echo </span><span class="string">"\n"</span><span class="keyword">, </span><span class="string">'Calls __isset() on demo as expected when executing isset( $x-&gt;a )' </span><span class="keyword">;<br /></span><span class="default">$ret </span><span class="keyword">= isset( </span><span class="default">$x</span><span class="keyword">-&gt;</span><span class="default">a </span><span class="keyword">) ;<br />echo </span><span class="string">"\n"</span><span class="keyword">, </span><span class="string">'Calls __get() on demo without call to __isset()&nbsp; when executing isset( $x-&gt;a-&gt;b )' </span><span class="keyword">;<br /></span><span class="default">$ret </span><span class="keyword">= isset( </span><span class="default">$x</span><span class="keyword">-&gt;</span><span class="default">a</span><span class="keyword">-&gt;</span><span class="default">b </span><span class="keyword">) ;<br /></span><span class="default">?&gt;<br /></span><br />Outputs<br /><br />Calls __isset() on demo as expected when executing isset( $x-&gt;a )<br />C:\htdocs\test.php:31 demo::__isset(a) instance demo<br />Calls __get() on demo without call to __isset()&nbsp; when executing isset( $x-&gt;a-&gt;b )<br />C:\htdocs\test.php:26 demo::__get(a) instance demo<br />C:\htdocs\test.php:31 demo::__isset(b) instance autocreated</span>
</code></div>
  </div>
 </div>
  <div class="note" id="97571">  <div class="votes">
    <div id="Vu97571">
    <a href="/manual/vote-note.php?id=97571&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd97571">
    <a href="/manual/vote-note.php?id=97571&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V97571" title="66% like this...">
    3
    </div>
  </div>
  <a href="#97571" class="name">
  <strong class="user"><em>zzzzbov</em></strong></a><a class="genanchor" href="#97571"> &para;</a><div class="date" title="2010-04-26 12:30"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom97571">
<div class="phpcode"><code><span class="html">
I've written a brief, generic function for __get() and __set() that works well implementing accessor and mutator functions.<br /><br />This allows the programmer to use implicit accessor and mutator methods when working with attribute data.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">MyClass<br /></span><span class="keyword">{<br />&nbsp; &nbsp; private </span><span class="default">$degrees<br /><br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">__get</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$fn_name </span><span class="keyword">= </span><span class="string">'get_' </span><span class="keyword">. </span><span class="default">$name</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">method_exists</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">, </span><span class="default">$fn_name</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$fn_name</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">__set</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">, </span><span class="default">$value</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$fn_name </span><span class="keyword">= </span><span class="string">'set_' </span><span class="keyword">. </span><span class="default">$name</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">method_exists</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">, </span><span class="default">$fn_name</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$fn_name</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; private function </span><span class="default">get_degrees</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">degrees</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; private function </span><span class="default">set_degrees</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">degrees </span><span class="keyword">= </span><span class="default">$value </span><span class="keyword">% </span><span class="default">360</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$degrees </span><span class="keyword">&lt; </span><span class="default">0</span><span class="keyword">) </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">degrees </span><span class="keyword">+= </span><span class="default">360</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="61748">  <div class="votes">
    <div id="Vu61748">
    <a href="/manual/vote-note.php?id=61748&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd61748">
    <a href="/manual/vote-note.php?id=61748&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V61748" title="66% like this...">
    5
    </div>
  </div>
  <a href="#61748" class="name">
  <strong class="user"><em>derek-php at seysol dot com</em></strong></a><a class="genanchor" href="#61748"> &para;</a><div class="date" title="2006-02-10 12:08"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom61748">
<div class="phpcode"><code><span class="html">
Please note that PHP5 currently doesn't support __call return-by-reference (see PHP Bug #30959).<br /><br />Example Code:<br /><br /><span class="default">&lt;?php<br /><br />&nbsp; &nbsp; </span><span class="keyword">class </span><span class="default">test </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; public function &amp;</span><span class="default">__call</span><span class="keyword">(</span><span class="default">$method</span><span class="keyword">, </span><span class="default">$params</span><span class="keyword">) {<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Return a reference to var2<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">'var2'</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; public function &amp;</span><span class="default">actual</span><span class="keyword">() {<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Return a reference to var1<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">'var1'</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="default">$obj </span><span class="keyword">= new </span><span class="default">test</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">'var1'</span><span class="keyword">] = </span><span class="default">0</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">'var2'</span><span class="keyword">] = </span><span class="default">0</span><span class="keyword">;<br /><br />&nbsp; &nbsp; </span><span class="default">$ref1 </span><span class="keyword">=&amp; </span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">actual</span><span class="keyword">();<br />&nbsp; &nbsp; </span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">'var1'</span><span class="keyword">]++;<br /><br />&nbsp; &nbsp; echo </span><span class="string">"Actual function returns: </span><span class="default">$ref1</span><span class="string"> which should be equal to " </span><span class="keyword">. </span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">'var1'</span><span class="keyword">] . </span><span class="string">"&lt;br/&gt;\n"</span><span class="keyword">;<br /><br />&nbsp; &nbsp; </span><span class="default">$ref2 </span><span class="keyword">=&amp; </span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">overloaded</span><span class="keyword">();<br />&nbsp; &nbsp; </span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">'var2'</span><span class="keyword">]++;<br /><br />&nbsp; &nbsp; echo </span><span class="string">"Overloaded function returns: </span><span class="default">$ref2</span><span class="string"> which should be equal to " </span><span class="keyword">. </span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">'var2'</span><span class="keyword">] . </span><span class="string">"&lt;br/&gt;\n"</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="55486">  <div class="votes">
    <div id="Vu55486">
    <a href="/manual/vote-note.php?id=55486&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd55486">
    <a href="/manual/vote-note.php?id=55486&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V55486" title="66% like this...">
    5
    </div>
  </div>
  <a href="#55486" class="name">
  <strong class="user"><em>NOTE: getter cannot call getter</em></strong></a><a class="genanchor" href="#55486"> &para;</a><div class="date" title="2005-08-04 12:37"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom55486">
<div class="phpcode"><code><span class="html">
By Design (<a href="http://bugs.php.net/bug.php?id=33998" rel="nofollow" target="_blank">http://bugs.php.net/bug.php?id=33998</a>) you cannot call a getter from a getter or any function triggered by a getter:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">test<br /></span><span class="keyword">{<br />&nbsp; &nbsp; protected </span><span class="default">$_a </span><span class="keyword">= </span><span class="default">6</span><span class="keyword">;<br /><br />&nbsp; &nbsp; function </span><span class="default">__get</span><span class="keyword">(</span><span class="default">$key</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">$key </span><span class="keyword">== </span><span class="string">'stuff'</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">stuff</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; } else if(</span><span class="default">$key </span><span class="keyword">== </span><span class="string">'a'</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">_a</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; function </span><span class="default">stuff</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return array(</span><span class="string">'random' </span><span class="keyword">=&gt; </span><span class="string">'key'</span><span class="keyword">, </span><span class="string">'using_getter' </span><span class="keyword">=&gt; </span><span class="default">10 </span><span class="keyword">* </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">a</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$test </span><span class="keyword">= new </span><span class="default">test</span><span class="keyword">();<br />print </span><span class="string">'this should be 60: '</span><span class="keyword">.</span><span class="default">$test</span><span class="keyword">-&gt;</span><span class="default">stuff</span><span class="keyword">[</span><span class="string">'using_getter'</span><span class="keyword">].</span><span class="string">'&lt;br/&gt;'</span><span class="keyword">;&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="comment">// prints "this should be 60: 0"<br />// [[ Undefined property:&nbsp; test::$a ]] on /var/www/html/test.php logged.<br /></span><span class="keyword">print </span><span class="string">'this should be 6: '</span><span class="keyword">.</span><span class="default">$test</span><span class="keyword">-&gt;</span><span class="default">a</span><span class="keyword">.</span><span class="string">'&lt;br/&gt;'</span><span class="keyword">;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// prints "this should be 6: 6"<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="104110">  <div class="votes">
    <div id="Vu104110">
    <a href="/manual/vote-note.php?id=104110&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd104110">
    <a href="/manual/vote-note.php?id=104110&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V104110" title="62% like this...">
    7
    </div>
  </div>
  <a href="#104110" class="name">
  <strong class="user"><em>Daniel Smith</em></strong></a><a class="genanchor" href="#104110"> &para;</a><div class="date" title="2011-05-23 04:15"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom104110">
<div class="phpcode"><code><span class="html">
Be careful of __call in case you have a protected/private method. Doing this:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">TestMagicCallMethod </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">foo</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">__METHOD__</span><span class="keyword">.</span><span class="default">PHP_EOL</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">__call</span><span class="keyword">(</span><span class="default">$method</span><span class="keyword">, </span><span class="default">$args</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">__METHOD__</span><span class="keyword">.</span><span class="default">PHP_EOL</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">method_exists</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">, </span><span class="default">$method</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$method</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; protected function </span><span class="default">bar</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">__METHOD__</span><span class="keyword">.</span><span class="default">PHP_EOL</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; private function </span><span class="default">baz</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">__METHOD__</span><span class="keyword">.</span><span class="default">PHP_EOL</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$test&nbsp; &nbsp; </span><span class="keyword">=&nbsp; &nbsp; new </span><span class="default">TestMagicCallMethod</span><span class="keyword">();<br /></span><span class="default">$test</span><span class="keyword">-&gt;</span><span class="default">foo</span><span class="keyword">();<br /></span><span class="comment">/**<br /> * Outputs: <br /> * TestMagicCallMethod::foo<br /> */<br /><br /></span><span class="default">$test</span><span class="keyword">-&gt;</span><span class="default">bar</span><span class="keyword">();<br /></span><span class="comment">/**<br /> * Outputs: <br /> * TestMagicCallMethod::__call<br /> * TestMagicCallMethod::bar<br /> */<br /><br /></span><span class="default">$test</span><span class="keyword">-&gt;</span><span class="default">baz</span><span class="keyword">();<br /></span><span class="comment">/**<br /> * Outputs:<br /> * TestMagicCallMethod::__call<br /> * TestMagicCallMethod::baz<br /> */<br /></span><span class="default">?&gt;<br /></span><br />..is probably not what you should be doing. Always make sure that the methods you call in __call are allowed as you probably dont want all the private/protected methods to be accessed by a typo or something.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="82896">  <div class="votes">
    <div id="Vu82896">
    <a href="/manual/vote-note.php?id=82896&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd82896">
    <a href="/manual/vote-note.php?id=82896&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V82896" title="63% like this...">
    3
    </div>
  </div>
  <a href="#82896" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#82896"> &para;</a><div class="date" title="2008-04-30 01:02"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom82896">
<div class="phpcode"><code><span class="html">
This is a generic implementation to use getter, setter, issetter and unsetter for your own classes.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">abstract class </span><span class="default">properties<br /></span><span class="keyword">{<br />&nbsp; public function </span><span class="default">__get</span><span class="keyword">( </span><span class="default">$property </span><span class="keyword">)<br />&nbsp; {<br />&nbsp; &nbsp; if( ! </span><span class="default">is_callable</span><span class="keyword">( array(</span><span class="default">$this</span><span class="keyword">,</span><span class="string">'get_'</span><span class="keyword">.(string)</span><span class="default">$property</span><span class="keyword">) ) )<br />&nbsp; &nbsp; &nbsp; throw new </span><span class="default">BadPropertyException</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">, (string)</span><span class="default">$property</span><span class="keyword">);<br /><br />&nbsp; &nbsp; return </span><span class="default">call_user_func</span><span class="keyword">( array(</span><span class="default">$this</span><span class="keyword">,</span><span class="string">'get_'</span><span class="keyword">.(string)</span><span class="default">$property</span><span class="keyword">) );<br />&nbsp; }<br /><br />&nbsp; public function </span><span class="default">__set</span><span class="keyword">( </span><span class="default">$property</span><span class="keyword">, </span><span class="default">$value </span><span class="keyword">)<br />&nbsp; {<br />&nbsp; &nbsp; if( ! </span><span class="default">is_callable</span><span class="keyword">( array(</span><span class="default">$this</span><span class="keyword">,</span><span class="string">'set_'</span><span class="keyword">.(string)</span><span class="default">$property</span><span class="keyword">) ) )<br />&nbsp; &nbsp; &nbsp; throw new </span><span class="default">BadPropertyException</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">, (string)</span><span class="default">$property</span><span class="keyword">);<br /><br />&nbsp; &nbsp; </span><span class="default">call_user_func</span><span class="keyword">( array(</span><span class="default">$this</span><span class="keyword">,</span><span class="string">'set_'</span><span class="keyword">.(string)</span><span class="default">$property</span><span class="keyword">), </span><span class="default">$value </span><span class="keyword">);<br />&nbsp; }<br />&nbsp; <br />&nbsp; public function </span><span class="default">__isset</span><span class="keyword">( </span><span class="default">$property </span><span class="keyword">)<br />&nbsp; {<br />&nbsp; &nbsp; if( ! </span><span class="default">is_callable</span><span class="keyword">( array(</span><span class="default">$this</span><span class="keyword">,</span><span class="string">'isset_'</span><span class="keyword">.(string)</span><span class="default">$property</span><span class="keyword">) ) )<br />&nbsp; &nbsp; &nbsp; throw new </span><span class="default">BadPropertyException</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">, (string)</span><span class="default">$property</span><span class="keyword">);<br /><br />&nbsp; &nbsp; return </span><span class="default">call_user_func</span><span class="keyword">( array(</span><span class="default">$this</span><span class="keyword">,</span><span class="string">'isset_'</span><span class="keyword">.(string)</span><span class="default">$property</span><span class="keyword">) );<br />&nbsp; }<br /><br />&nbsp; public function </span><span class="default">__unset</span><span class="keyword">( </span><span class="default">$property </span><span class="keyword">)<br />&nbsp; {<br />&nbsp; &nbsp; if( ! </span><span class="default">is_callable</span><span class="keyword">( array(</span><span class="default">$this</span><span class="keyword">,</span><span class="string">'unset_'</span><span class="keyword">.(string)</span><span class="default">$property</span><span class="keyword">) ) )<br />&nbsp; &nbsp; &nbsp; throw new </span><span class="default">BadPropertyException</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">, (string)</span><span class="default">$property</span><span class="keyword">);<br /><br />&nbsp; &nbsp; </span><span class="default">call_user_func</span><span class="keyword">( array(</span><span class="default">$this</span><span class="keyword">,</span><span class="string">'unset_'</span><span class="keyword">.(string)</span><span class="default">$property</span><span class="keyword">) );<br />&nbsp; }<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="79864">  <div class="votes">
    <div id="Vu79864">
    <a href="/manual/vote-note.php?id=79864&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd79864">
    <a href="/manual/vote-note.php?id=79864&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V79864" title="62% like this...">
    2
    </div>
  </div>
  <a href="#79864" class="name">
  <strong class="user"><em>matthijs at yourmediafactory dot com</em></strong></a><a class="genanchor" href="#79864"> &para;</a><div class="date" title="2007-12-16 11:09"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom79864">
<div class="phpcode"><code><span class="html">
While PHP does not support true overloading natively, I have to disagree with those that state this can't be achieved trough __call. <br /><br />Yes, it's not pretty but it is definately possible to overload a member based on the type of its argument. An example:<br /><span class="default">&lt;?php <br /></span><span class="keyword">class </span><span class="default">A </span><span class="keyword">{ <br />&nbsp;&nbsp; <br />&nbsp; public function </span><span class="default">__call </span><span class="keyword">(</span><span class="default">$member</span><span class="keyword">, </span><span class="default">$arguments</span><span class="keyword">) { <br />&nbsp; &nbsp; if(</span><span class="default">is_object</span><span class="keyword">(</span><span class="default">$arguments</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">])) <br />&nbsp; &nbsp; &nbsp; </span><span class="default">$member </span><span class="keyword">= </span><span class="default">$member </span><span class="keyword">. </span><span class="string">'Object'</span><span class="keyword">; <br />&nbsp; &nbsp; if(</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$arguments</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">])) <br />&nbsp; &nbsp; &nbsp; </span><span class="default">$member </span><span class="keyword">= </span><span class="default">$member </span><span class="keyword">. </span><span class="string">'Array'</span><span class="keyword">; <br />&nbsp; &nbsp; </span><span class="default">$this </span><span class="keyword">-&gt; </span><span class="default">$member</span><span class="keyword">(</span><span class="default">$arguments</span><span class="keyword">); <br />&nbsp; } <br />&nbsp;&nbsp; <br />&nbsp; private function </span><span class="default">testArray </span><span class="keyword">() { <br />&nbsp; &nbsp; echo </span><span class="string">"Array."</span><span class="keyword">; <br />&nbsp; } <br />&nbsp;&nbsp; <br />&nbsp; private function </span><span class="default">testObject </span><span class="keyword">() { <br />&nbsp; &nbsp; echo </span><span class="string">"Object."</span><span class="keyword">; <br />&nbsp; } <br />} <br /><br />class </span><span class="default">B </span><span class="keyword">{ <br />} <br /><br /></span><span class="default">$class </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">; <br /></span><span class="default">$class </span><span class="keyword">-&gt; </span><span class="default">test</span><span class="keyword">(array()); </span><span class="comment">// echo's 'Array.' <br /></span><span class="default">$class </span><span class="keyword">-&gt; </span><span class="default">test</span><span class="keyword">(new </span><span class="default">B</span><span class="keyword">); </span><span class="comment">// echo's 'Object.' <br /></span><span class="default">?&gt;<br /></span><br />Of course, the use of this is questionable (I have never needed it myself, but then again, I only have a very minimalistic C++ &amp; JAVA background). However, using this general principle and optionally building forth on other suggestions a 'form' of overloading is definately possible, provided you have some strict naming conventions in your functions. <br /><br />It would of course become a LOT easier once PHP'd let you declare the same member several times but with different arguments, since if you combine that with the reflection class 'real' overloading comes into the grasp of a good OO programmer. Lets keep our fingers crossed!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="76622">  <div class="votes">
    <div id="Vu76622">
    <a href="/manual/vote-note.php?id=76622&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd76622">
    <a href="/manual/vote-note.php?id=76622&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V76622" title="62% like this...">
    2
    </div>
  </div>
  <a href="#76622" class="name">
  <strong class="user"><em>php at sleep is the enemy dot co dot uk</em></strong></a><a class="genanchor" href="#76622"> &para;</a><div class="date" title="2007-07-23 07:23"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom76622">
<div class="phpcode"><code><span class="html">
Just to reinforce and elaborate on what DevilDude at darkmaker dot com said way down there on 22-Sep-2004 07:57.<br /><br />The recursion detection feature can prove especially perilous when using __set. When PHP comes across a statement that would usually call __set but would lead to recursion, rather than firing off a warning or simply not executing the statement it will act as though there is no __set method defined at all. The default behaviour in this instance is to dynamically add the specified property to the object thus breaking the desired functionality of all further calls to __set or __get for that property.<br /><br />Example:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">TestClass</span><span class="keyword">{<br /><br />&nbsp; &nbsp; public </span><span class="default">$values </span><span class="keyword">= array();<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">__get</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">values</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">];<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">__set</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">, </span><span class="default">$value</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">values</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">] = </span><span class="default">$value</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">validate</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">);<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">validate</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">/*<br />&nbsp; &nbsp; &nbsp; &nbsp; __get will be called on the following line<br />&nbsp; &nbsp; &nbsp; &nbsp; but as soon as we attempt to call __set <br />&nbsp; &nbsp; &nbsp; &nbsp; again PHP will refuse and simply add a <br />&nbsp; &nbsp; &nbsp; &nbsp; property called $name to $this <br />&nbsp; &nbsp; &nbsp; &nbsp; */<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$name </span><span class="keyword">= </span><span class="default">trim</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$name</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$tc </span><span class="keyword">= new </span><span class="default">TestClass</span><span class="keyword">();<br /><br /></span><span class="default">$tc</span><span class="keyword">-&gt;</span><span class="default">foo </span><span class="keyword">= </span><span class="string">'bar'</span><span class="keyword">;<br /></span><span class="default">$tc</span><span class="keyword">-&gt;</span><span class="default">values</span><span class="keyword">[</span><span class="string">'foo'</span><span class="keyword">] = </span><span class="string">'boing'</span><span class="keyword">;<br /><br />echo </span><span class="string">'$tc-&gt;foo == ' </span><span class="keyword">. </span><span class="default">$tc</span><span class="keyword">-&gt;</span><span class="default">foo </span><span class="keyword">. </span><span class="string">'&lt;br&gt;'</span><span class="keyword">;<br />echo </span><span class="string">'$tc ' </span><span class="keyword">. (</span><span class="default">property_exists</span><span class="keyword">(</span><span class="default">$tc</span><span class="keyword">, </span><span class="string">'foo'</span><span class="keyword">) ? </span><span class="string">'now has' </span><span class="keyword">: </span><span class="string">'still does not have'</span><span class="keyword">) . </span><span class="string">' a property called "foo"&lt;br&gt;'</span><span class="keyword">;<br /><br /></span><span class="comment">/*<br />OUPUTS:<br />$tc-&gt;foo == bar<br />$tc now has a property called "foo"<br />*/<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="93939">  <div class="votes">
    <div id="Vu93939">
    <a href="/manual/vote-note.php?id=93939&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd93939">
    <a href="/manual/vote-note.php?id=93939&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V93939" title="61% like this...">
    3
    </div>
  </div>
  <a href="#93939" class="name">
  <strong class="user"><em>strata_ranger at hotmail dot com</em></strong></a><a class="genanchor" href="#93939"> &para;</a><div class="date" title="2009-10-07 09:56"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom93939">
<div class="phpcode"><code><span class="html">
Combining two things noted previously:<br /><br />1 - Unsetting an object member removes it from the object completely, subsequent uses of that member will be handled by magic methods.<br />2 - PHP will not recursively call one magic method from within itself (at least for the same $name).<br /><br />This means that if an object member has been unset(), it IS possible to re-declare that object member (as public) by creating it within your object's __set() method, like this:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Foo<br /></span><span class="keyword">{<br />&nbsp; function </span><span class="default">__set</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">, </span><span class="default">$value</span><span class="keyword">)<br />&nbsp; {<br />&nbsp; &nbsp; </span><span class="comment">// Add a new (public) member to this object.<br />&nbsp; &nbsp; // This works because __set() will not recursively call itself.<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$name</span><span class="keyword">= </span><span class="default">$value</span><span class="keyword">;<br />&nbsp; }<br />}<br /><br /></span><span class="default">$foo </span><span class="keyword">= new </span><span class="default">Foo</span><span class="keyword">();<br /><br /></span><span class="comment">// $foo has zero members at this point<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$foo</span><span class="keyword">);<br /><br /></span><span class="comment">// __set() will be called here<br /></span><span class="default">$foo</span><span class="keyword">-&gt;</span><span class="default">bar </span><span class="keyword">= </span><span class="string">'something'</span><span class="keyword">; </span><span class="comment">// Calls __set()<br /><br />// $foo now contains one member<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$foo</span><span class="keyword">);<br /><br /></span><span class="comment">// Won't call __set() because 'bar' is now declared<br /></span><span class="default">$foo</span><span class="keyword">-&gt;</span><span class="default">bar </span><span class="keyword">= </span><span class="string">'other thing'</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;<br /></span><br />Also be mindful that if you want to break a reference involving an object member without triggering magic functionality, DO NOT unset() the object member directly.&nbsp; Instead use =&amp; to bind the object member to any convenient null variable.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118578">  <div class="votes">
    <div id="Vu118578">
    <a href="/manual/vote-note.php?id=118578&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118578">
    <a href="/manual/vote-note.php?id=118578&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118578" title="60% like this...">
    1
    </div>
  </div>
  <a href="#118578" class="name">
  <strong class="user"><em>qi at weiyu dot me</em></strong></a><a class="genanchor" href="#118578"> &para;</a><div class="date" title="2015-12-31 05:59"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom118578">
<div class="phpcode"><code><span class="html">
I test those code:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">A </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; public function </span><span class="default">test </span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; static::</span><span class="default">who</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">A</span><span class="keyword">::</span><span class="default">who</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">who</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">who</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; }&nbsp;&nbsp; <br /><br />&nbsp; &nbsp; &nbsp; &nbsp; public static function </span><span class="default">__callStatic</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="string">'A static'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }&nbsp;&nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; public function </span><span class="default">__call</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="string">'A call'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }&nbsp;&nbsp; <br />}<br /><br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">;<br /></span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">test</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span><br />And the answer is <br />string(6) "A call"<br />string(6) "A call"<br />string(6) "A call"<br />string(6) "A call"<br /><br />I think it means that __call will be called before __callStatic in an instance.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114610">  <div class="votes">
    <div id="Vu114610">
    <a href="/manual/vote-note.php?id=114610&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114610">
    <a href="/manual/vote-note.php?id=114610&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114610" title="57% like this...">
    1
    </div>
  </div>
  <a href="#114610" class="name">
  <strong class="user"><em>Nehuen</em></strong></a><a class="genanchor" href="#114610"> &para;</a><div class="date" title="2014-03-12 05:43"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114610">
<div class="phpcode"><code><span class="html">
Overloading other classical typed languages ​​can be emulated in a simple way:<br /><br /><span class="default">&lt;?php<br /> </span><span class="keyword">class </span><span class="default">overload<br /> </span><span class="keyword">{<br />&nbsp; &nbsp; protected function </span><span class="default">overloaded</span><span class="keyword">(</span><span class="default">$method</span><span class="keyword">, </span><span class="default">$params</span><span class="keyword">, </span><span class="default">$type </span><span class="keyword">= </span><span class="default">false</span><span class="keyword">, </span><span class="default">$instance </span><span class="keyword">= </span><span class="default">false</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$method </span><span class="keyword">.= </span><span class="default">count</span><span class="keyword">(</span><span class="default">$params</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">$type </span><span class="keyword">&amp;&amp; </span><span class="default">$params</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; foreach(</span><span class="default">$params </span><span class="keyword">as </span><span class="default">$param</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$method </span><span class="keyword">.= </span><span class="string">'_'</span><span class="keyword">.(</span><span class="default">gettype</span><span class="keyword">(</span><span class="default">$param</span><span class="keyword">) == </span><span class="string">'object' </span><span class="keyword">? (</span><span class="default">$instance </span><span class="keyword">? </span><span class="default">get_class</span><span class="keyword">(</span><span class="default">$param</span><span class="keyword">) : </span><span class="string">'object'</span><span class="keyword">) : </span><span class="default">gettype</span><span class="keyword">(</span><span class="default">$param</span><span class="keyword">));<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">method_exists</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">, </span><span class="default">$method</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">call_user_func_array</span><span class="keyword">(array(</span><span class="default">$this</span><span class="keyword">,</span><span class="default">$method</span><span class="keyword">),</span><span class="default">$params</span><span class="keyword">);<br />&nbsp; &nbsp; }&nbsp; &nbsp; <br /> }<br /><br /> class </span><span class="default">test_overload </span><span class="keyword">extends </span><span class="default">overload<br /> </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">test_function</span><span class="keyword">() { </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">overloaded</span><span class="keyword">(</span><span class="string">'test'</span><span class="keyword">, </span><span class="default">func_get_args</span><span class="keyword">(), </span><span class="default">true</span><span class="keyword">); }&nbsp; &nbsp; <br />&nbsp; &nbsp; <br />&nbsp; &nbsp; protected function </span><span class="default">test0</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo(</span><span class="string">'&lt;br&gt;Hello, I did not pass any parameters.'</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; protected function </span><span class="default">test1_string</span><span class="keyword">(</span><span class="default">$string</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo(</span><span class="string">'&lt;br&gt;Hello, I spent this string: '</span><span class="keyword">.</span><span class="default">$string</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; protected function </span><span class="default">test1_integer</span><span class="keyword">(</span><span class="default">$integer</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo(</span><span class="string">'&lt;br&gt;Hello, I spent this integer: '</span><span class="keyword">.</span><span class="default">$integer</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; protected function </span><span class="default">test2_integer_string</span><span class="keyword">(</span><span class="default">$integer</span><span class="keyword">, </span><span class="default">$string</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo(</span><span class="string">'&lt;br&gt;Hello, I spent this integer: '</span><span class="keyword">.</span><span class="default">$integer</span><span class="keyword">.</span><span class="string">' and this string: '</span><span class="keyword">.</span><span class="default">$string</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; protected function </span><span class="default">test2_string_integer</span><span class="keyword">(</span><span class="default">$string</span><span class="keyword">, </span><span class="default">$integer</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo(</span><span class="string">'&lt;br&gt;Hello, I spent this string: '</span><span class="keyword">.</span><span class="default">$integer</span><span class="keyword">.</span><span class="string">' and this integer: '</span><span class="keyword">.</span><span class="default">$string</span><span class="keyword">);<br />&nbsp; &nbsp; }<br /> }<br /> <br /> </span><span class="default">$test </span><span class="keyword">= new </span><span class="default">test_overload</span><span class="keyword">();<br /> </span><span class="default">$test</span><span class="keyword">-&gt;</span><span class="default">test_function</span><span class="keyword">();<br /> </span><span class="default">$test</span><span class="keyword">-&gt;</span><span class="default">test_function</span><span class="keyword">(</span><span class="string">'test'</span><span class="keyword">);<br /> </span><span class="default">$test</span><span class="keyword">-&gt;</span><span class="default">test_function</span><span class="keyword">(</span><span class="default">5</span><span class="keyword">);<br /> </span><span class="default">$test</span><span class="keyword">-&gt;</span><span class="default">test_function</span><span class="keyword">(</span><span class="default">5</span><span class="keyword">, </span><span class="string">'test'</span><span class="keyword">);<br /> </span><span class="default">$test</span><span class="keyword">-&gt;</span><span class="default">test_function</span><span class="keyword">(</span><span class="string">'test'</span><span class="keyword">, </span><span class="default">5</span><span class="keyword">);<br /> </span><span class="default">$test</span><span class="keyword">-&gt;</span><span class="default">test_function</span><span class="keyword">(</span><span class="string">'2'</span><span class="keyword">);</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="58364">  <div class="votes">
    <div id="Vu58364">
    <a href="/manual/vote-note.php?id=58364&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd58364">
    <a href="/manual/vote-note.php?id=58364&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V58364" title="58% like this...">
    2
    </div>
  </div>
  <a href="#58364" class="name">
  <strong class="user"><em>seufert at gmail dot com</em></strong></a><a class="genanchor" href="#58364"> &para;</a><div class="date" title="2005-11-01 04:25"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom58364">
<div class="phpcode"><code><span class="html">
This allows you to seeminly dynamically overload objects using plugins.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">standardModule</span><span class="keyword">{}<br /><br />class </span><span class="default">standardPlugModule </span><span class="keyword">extends </span><span class="default">standardModule<br /></span><span class="keyword">{<br />&nbsp; static </span><span class="default">$plugptrs</span><span class="keyword">;<br />&nbsp; public </span><span class="default">$var</span><span class="keyword">;<br />&nbsp; static function </span><span class="default">plugAdd</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">, </span><span class="default">$mode</span><span class="keyword">, </span><span class="default">$ptr</span><span class="keyword">)<br />&nbsp; {<br />&nbsp; &nbsp; </span><span class="default">standardPlugModule</span><span class="keyword">::</span><span class="default">$plugptrs</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">] = </span><span class="default">$ptr</span><span class="keyword">;<br />&nbsp; }<br />&nbsp; function </span><span class="default">__call</span><span class="keyword">(</span><span class="default">$fname</span><span class="keyword">, </span><span class="default">$fargs</span><span class="keyword">)<br />&nbsp; { print </span><span class="string">"You called __call(</span><span class="default">$fname</span><span class="string">)\n"</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$func </span><span class="keyword">= </span><span class="default">standardPlugModule</span><span class="keyword">::</span><span class="default">$plugptrs</span><span class="keyword">[</span><span class="default">$fname</span><span class="keyword">];<br />&nbsp; &nbsp; </span><span class="default">$r </span><span class="keyword">= </span><span class="default">call_user_func_array</span><span class="keyword">(</span><span class="default">$func</span><span class="keyword">, </span><span class="default">array_merge</span><span class="keyword">(array(</span><span class="default">$this</span><span class="keyword">),</span><span class="default">$fargs</span><span class="keyword">));<br />&nbsp; &nbsp; print </span><span class="string">"Done: __call(</span><span class="default">$fname</span><span class="string">)\n"</span><span class="keyword">;<br />&nbsp; &nbsp; return </span><span class="default">$r</span><span class="keyword">;<br />&nbsp; }<br />&nbsp; function </span><span class="default">dumpplugptrs</span><span class="keyword">() {</span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">standardPlugModule</span><span class="keyword">::</span><span class="default">$plugptrs</span><span class="keyword">); }<br />}<br /><br />class </span><span class="default">a </span><span class="keyword">extends </span><span class="default">standardPlugModule<br /></span><span class="keyword">{ function </span><span class="default">text</span><span class="keyword">() { return </span><span class="string">"Text"</span><span class="keyword">; } }<br /></span><span class="comment">//Class P contained within a seperate file thats included<br /></span><span class="keyword">class </span><span class="default">p<br /></span><span class="keyword">{ static function </span><span class="default">plugin1</span><span class="keyword">(</span><span class="default">$mthis</span><span class="keyword">, </span><span class="default">$r</span><span class="keyword">)<br />&nbsp; { print </span><span class="string">"You called p::plugin1\n"</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$mthis</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$r</span><span class="keyword">);<br />&nbsp; }<br />} </span><span class="default">a</span><span class="keyword">::</span><span class="default">plugAdd</span><span class="keyword">(</span><span class="string">'callme'</span><span class="keyword">, </span><span class="default">0</span><span class="keyword">, array(</span><span class="string">'p'</span><span class="keyword">,</span><span class="string">'plugin1'</span><span class="keyword">));<br /><br /></span><span class="comment">//Class P contained within a seperate file thats included<br /></span><span class="keyword">class </span><span class="default">p2<br /></span><span class="keyword">{ static function </span><span class="default">plugin2</span><span class="keyword">(</span><span class="default">$mthis</span><span class="keyword">, </span><span class="default">$r</span><span class="keyword">)<br />&nbsp; { print </span><span class="string">"You called p2::plugin2\n"</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$mthis</span><span class="keyword">-&gt;</span><span class="default">callme</span><span class="keyword">(</span><span class="default">$r</span><span class="keyword">);<br />&nbsp; }<br />} </span><span class="default">a</span><span class="keyword">::</span><span class="default">plugAdd</span><span class="keyword">(</span><span class="string">'callme2'</span><span class="keyword">, </span><span class="default">0</span><span class="keyword">, array(</span><span class="string">'p2'</span><span class="keyword">,</span><span class="string">'plugin2'</span><span class="keyword">));<br /><br /></span><span class="default">$t </span><span class="keyword">= new </span><span class="default">a</span><span class="keyword">();<br /></span><span class="default">$testr </span><span class="keyword">= array(</span><span class="default">1</span><span class="keyword">,</span><span class="default">4</span><span class="keyword">,</span><span class="default">9</span><span class="keyword">,</span><span class="default">16</span><span class="keyword">);<br />print </span><span class="default">$t</span><span class="keyword">-&gt;</span><span class="default">text</span><span class="keyword">().</span><span class="string">"\n"</span><span class="keyword">;<br /></span><span class="default">$t</span><span class="keyword">-&gt;</span><span class="default">callme2</span><span class="keyword">(</span><span class="default">$testr</span><span class="keyword">);<br /></span><span class="comment">//$t-&gt;dumpplugptrs();<br /><br /></span><span class="default">?&gt;<br /></span><br />Will result in:<br />----------<br />Text<br />You called __call(callme2)<br />You called p2::plugin2<br />You called __call(callme)<br />You called p::plugin1<br />a Object<br />(<br />&nbsp; &nbsp; [var] =&gt; <br />)<br />Array<br />(<br />&nbsp; &nbsp; [0] =&gt; 1<br />&nbsp; &nbsp; [1] =&gt; 4<br />&nbsp; &nbsp; [2] =&gt; 9<br />&nbsp; &nbsp; [3] =&gt; 16<br />)<br />Done: __call(callme)<br />Done: __call(callme2)<br />----------<br /><br />This also clears up a fact that you can nest __call() functions, you could use this to get around the limits to __get() not being able to be called recursively.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="91326">  <div class="votes">
    <div id="Vu91326">
    <a href="/manual/vote-note.php?id=91326&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd91326">
    <a href="/manual/vote-note.php?id=91326&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V91326" title="57% like this...">
    2
    </div>
  </div>
  <a href="#91326" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#91326"> &para;</a><div class="date" title="2009-06-05 03:54"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom91326">
<div class="phpcode"><code><span class="html">
It is possible to accomplish method polymorphism via PHP's __call method:<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Example</span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">__call</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">, </span><span class="default">$arguments</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; switch(</span><span class="default">$name</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">'foo'</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; switch(</span><span class="default">count</span><span class="keyword">(</span><span class="default">$arguments</span><span class="keyword">)){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">2</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'You called "foo" with two arguments.&lt;br&gt;' </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">3</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'You called "foo" with three arguments.&lt;br&gt;' </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; default:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'Error: Invalid number of arguments to "foo."&lt;br&gt;' </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; default:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Error: Call to undefined function \"</span><span class="default">$name</span><span class="string">.\"&lt;br&gt;" </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$test </span><span class="keyword">= new </span><span class="default">Example</span><span class="keyword">;<br /></span><span class="default">$test</span><span class="keyword">-&gt;</span><span class="default">foo</span><span class="keyword">(</span><span class="string">'bar'</span><span class="keyword">, </span><span class="string">'baz'</span><span class="keyword">);<br /></span><span class="default">$test</span><span class="keyword">-&gt;</span><span class="default">foo</span><span class="keyword">(</span><span class="string">'bar'</span><span class="keyword">, </span><span class="string">'baz'</span><span class="keyword">, </span><span class="string">'fez'</span><span class="keyword">, </span><span class="string">'fap'</span><span class="keyword">);<br /></span><span class="default">$test</span><span class="keyword">-&gt;</span><span class="default">bar</span><span class="keyword">();<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="84500">  <div class="votes">
    <div id="Vu84500">
    <a href="/manual/vote-note.php?id=84500&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd84500">
    <a href="/manual/vote-note.php?id=84500&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V84500" title="57% like this...">
    1
    </div>
  </div>
  <a href="#84500" class="name">
  <strong class="user"><em>strafvollzugsbeamter at gmx dot de</em></strong></a><a class="genanchor" href="#84500"> &para;</a><div class="date" title="2008-07-16 12:57"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom84500">
<div class="phpcode"><code><span class="html">
The following works on my installation (5.2.6 / Windows):<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">G<br /></span><span class="keyword">{<br />&nbsp; &nbsp; private </span><span class="default">$_p </span><span class="keyword">= array();<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">__isset</span><span class="keyword">(</span><span class="default">$k</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return isset(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">_p</span><span class="keyword">[</span><span class="default">$k</span><span class="keyword">]);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">__get</span><span class="keyword">(</span><span class="default">$k</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$v </span><span class="keyword">= </span><span class="default">NULL</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">array_key_exists</span><span class="keyword">(</span><span class="default">$k</span><span class="keyword">, </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">_p</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$v </span><span class="keyword">= </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">_p</span><span class="keyword">[</span><span class="default">$k</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$v </span><span class="keyword">= </span><span class="default">$this</span><span class="keyword">-&gt;{</span><span class="default">$k</span><span class="keyword">} = </span><span class="default">$this</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$v</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">__set</span><span class="keyword">(</span><span class="default">$k</span><span class="keyword">, </span><span class="default">$v</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">_p</span><span class="keyword">[</span><span class="default">$k</span><span class="keyword">] = </span><span class="default">$v</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">;<br />&nbsp; &nbsp; }&nbsp; &nbsp; <br />}<br /><br /></span><span class="default">$s </span><span class="keyword">= new </span><span class="default">G</span><span class="keyword">();<br /></span><span class="default">$s</span><span class="keyword">-&gt;</span><span class="default">A</span><span class="keyword">-&gt;</span><span class="default">B</span><span class="keyword">-&gt;</span><span class="default">C </span><span class="keyword">= </span><span class="string">'FOO'</span><span class="keyword">;<br /></span><span class="default">$s</span><span class="keyword">-&gt;</span><span class="default">X</span><span class="keyword">-&gt;</span><span class="default">Y</span><span class="keyword">-&gt;</span><span class="default">Z </span><span class="keyword">= array (</span><span class="string">'BAR'</span><span class="keyword">);<br /><br />if (isset(</span><span class="default">$s</span><span class="keyword">-&gt;</span><span class="default">A</span><span class="keyword">-&gt;</span><span class="default">B</span><span class="keyword">-&gt;</span><span class="default">C</span><span class="keyword">))<br />{<br />&nbsp; &nbsp; print(</span><span class="default">$s</span><span class="keyword">-&gt;</span><span class="default">A</span><span class="keyword">-&gt;</span><span class="default">B</span><span class="keyword">-&gt;</span><span class="default">C</span><span class="keyword">);<br />}<br />else<br />{<br />&nbsp; &nbsp; print(</span><span class="string">'A-&gt;B-&gt;C is NOT set'</span><span class="keyword">);<br />}<br /><br />if (isset(</span><span class="default">$s</span><span class="keyword">-&gt;</span><span class="default">X</span><span class="keyword">-&gt;</span><span class="default">Y</span><span class="keyword">-&gt;</span><span class="default">Z</span><span class="keyword">))<br />{<br />&nbsp; &nbsp; </span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$s</span><span class="keyword">-&gt;</span><span class="default">X</span><span class="keyword">-&gt;</span><span class="default">Y</span><span class="keyword">-&gt;</span><span class="default">Z</span><span class="keyword">);<br />}<br />else<br />{<br />&nbsp; &nbsp; print(</span><span class="string">'X-&gt;Y-&gt;Z is NOT set'</span><span class="keyword">);<br />}<br /><br /></span><span class="comment">// prints: FOOArray ( [0] =&gt; BAR )<br /></span><span class="default">?&gt;<br /></span><br />... have fun and&nbsp; ...</span>
</code></div>
  </div>
 </div>
  <div class="note" id="80310">  <div class="votes">
    <div id="Vu80310">
    <a href="/manual/vote-note.php?id=80310&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd80310">
    <a href="/manual/vote-note.php?id=80310&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V80310" title="57% like this...">
    1
    </div>
  </div>
  <a href="#80310" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#80310"> &para;</a><div class="date" title="2008-01-09 07:45"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom80310">
<div class="phpcode"><code><span class="html">
It should be noted that __call will trigger only for method calls on an instantiated object, and cannot be used to 'overload' static methods.&nbsp; For example:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">TestClass </span><span class="keyword">{<br />&nbsp; function </span><span class="default">__call</span><span class="keyword">(</span><span class="default">$method</span><span class="keyword">, </span><span class="default">$args</span><span class="keyword">) {<br />&nbsp; &nbsp; echo </span><span class="string">"Method </span><span class="keyword">{</span><span class="default">$method</span><span class="keyword">}</span><span class="string"> called with args: " </span><span class="keyword">. </span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$args</span><span class="keyword">, </span><span class="default">TRUE</span><span class="keyword">);<br />&nbsp; }<br />}<br /><br /></span><span class="comment">// this will succeed<br /></span><span class="default">$obj </span><span class="keyword">= new </span><span class="default">TestClass</span><span class="keyword">();<br /></span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">method_doesnt_exist</span><span class="keyword">();<br /><br /></span><span class="comment">// this will not<br /></span><span class="default">TestClass</span><span class="keyword">::</span><span class="default">method_doesnt_exist</span><span class="keyword">();<br /><br /></span><span class="default">?&gt;<br /></span><br />It would be useful if the PHP devs would include this in a future release, but in the meantime, just be aware of that pitfall.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="105176">  <div class="votes">
    <div id="Vu105176">
    <a href="/manual/vote-note.php?id=105176&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd105176">
    <a href="/manual/vote-note.php?id=105176&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V105176" title="55% like this...">
    1
    </div>
  </div>
  <a href="#105176" class="name">
  <strong class="user"><em>dans at dansheps dot com</em></strong></a><a class="genanchor" href="#105176"> &para;</a><div class="date" title="2011-08-01 08:38"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom105176">
<div class="phpcode"><code><span class="html">
Since this was getting me for a little bit, I figure I better pipe in here...<br /><br />For nested calls to private/protected variables(probably functions too) what it does is call a __get()&nbsp; on the first object, and if you return the nested object, it then calls a __get() on the nested object because, well it is protected as well.<br /><br />EG:<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">A<br /></span><span class="keyword">{<br />protected </span><span class="default">$B<br /><br /></span><span class="keyword">public function </span><span class="default">__construct</span><span class="keyword">()<br />{<br /></span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">B </span><span class="keyword">= new </span><span class="default">B</span><span class="keyword">();<br />}<br /><br />public function </span><span class="default">__get</span><span class="keyword">(</span><span class="default">$variable</span><span class="keyword">)<br />{<br />echo </span><span class="string">"Class A::Variable " </span><span class="keyword">. </span><span class="default">$variable </span><span class="keyword">. </span><span class="string">"\n\r"</span><span class="keyword">;<br /></span><span class="default">$retval </span><span class="keyword">= </span><span class="default">$this</span><span class="keyword">-&gt;{</span><span class="default">$variable</span><span class="keyword">};<br />return </span><span class="default">$retval</span><span class="keyword">;<br />}<br />}<br /><br />class </span><span class="default">B<br /></span><span class="keyword">{<br />protected </span><span class="default">$val<br /><br /></span><span class="keyword">public function </span><span class="default">__construct</span><span class="keyword">()<br />{<br /></span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">val </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />}<br /><br />public function </span><span class="default">__get</span><span class="keyword">(</span><span class="default">$variable</span><span class="keyword">)<br />{<br />echo </span><span class="string">"Class B::Variable " </span><span class="keyword">. </span><span class="default">$variable </span><span class="keyword">. </span><span class="string">"\n\r"</span><span class="keyword">;<br /></span><span class="default">$retval </span><span class="keyword">= </span><span class="default">$this</span><span class="keyword">-&gt;{</span><span class="default">$variable</span><span class="keyword">};<br />return </span><span class="default">$retval</span><span class="keyword">;<br />}<br />}<br /><br /></span><span class="default">$A </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">();<br /><br />echo </span><span class="string">"Final Value: " </span><span class="keyword">. </span><span class="default">$A</span><span class="keyword">-&gt;</span><span class="default">B</span><span class="keyword">-&gt;</span><span class="default">val</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />That will return something like...<br /><br />Class A::Variable B<br />Class B::Variable val<br />Final Value: 1<br /><br />It seperates the calls into $A-&gt;B and $B-&gt;val<br /><br />Hope this helps someone</span>
</code></div>
  </div>
 </div>
  <div class="note" id="52453">  <div class="votes">
    <div id="Vu52453">
    <a href="/manual/vote-note.php?id=52453&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd52453">
    <a href="/manual/vote-note.php?id=52453&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V52453" title="57% like this...">
    1
    </div>
  </div>
  <a href="#52453" class="name">
  <strong class="user"><em>Marius</em></strong></a><a class="genanchor" href="#52453"> &para;</a><div class="date" title="2005-05-02 02:15"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom52453">
<div class="phpcode"><code><span class="html">
for anyone who's thinking about traversing some variable tree<br />by using __get() and __set(). i tried to do this and found one<br />problem: you can handle couple of __get() in a row by returning<br />an object which can handle consequential __get(), but you can't<br />handle __get() and __set() that way.<br />i.e. if you want to:<br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">print(</span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">val1</span><span class="keyword">-&gt;</span><span class="default">val2</span><span class="keyword">-&gt;</span><span class="default">val3</span><span class="keyword">); </span><span class="comment">// three __get() calls<br /></span><span class="default">?&gt;</span> - this will work,<br />but if you want to:<br /><span class="default">&lt;?php<br />&nbsp; &nbsp; $obj</span><span class="keyword">-&gt;</span><span class="default">val1</span><span class="keyword">-&gt;</span><span class="default">val2 </span><span class="keyword">= </span><span class="default">$val</span><span class="keyword">; </span><span class="comment">// one __get() and one __set() call<br /></span><span class="default">?&gt;</span> - this will fail with message:<br />"Fatal error: Cannot access undefined property for object with<br /> overloaded property access"<br />however if you don't mix __get() and __set() in one expression,<br />it will work:<br /><span class="default">&lt;?php<br />&nbsp; &nbsp; $obj</span><span class="keyword">-&gt;</span><span class="default">val1 </span><span class="keyword">= </span><span class="default">$val</span><span class="keyword">; </span><span class="comment">// only one __set() call<br />&nbsp; &nbsp; </span><span class="default">$val2 </span><span class="keyword">= </span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">val1</span><span class="keyword">-&gt;</span><span class="default">val2</span><span class="keyword">; </span><span class="comment">// two __get() calls<br />&nbsp; &nbsp; </span><span class="default">$val2</span><span class="keyword">-&gt;</span><span class="default">val3 </span><span class="keyword">= </span><span class="default">$val</span><span class="keyword">; </span><span class="comment">// one __set() call<br /></span><span class="default">?&gt;<br /></span><br />as you can see you can split __get() and __set() parts of<br />expression into two expressions to make it work.<br /><br />by the way, this seems like a bug to me, will have to report it.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="45905">  <div class="votes">
    <div id="Vu45905">
    <a href="/manual/vote-note.php?id=45905&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd45905">
    <a href="/manual/vote-note.php?id=45905&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V45905" title="57% like this...">
    1
    </div>
  </div>
  <a href="#45905" class="name">
  <strong class="user"><em>DevilDude at darkmaker dot com</em></strong></a><a class="genanchor" href="#45905"> &para;</a><div class="date" title="2004-09-22 07:57"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom45905">
<div class="phpcode"><code><span class="html">
Php 5 has a simple recursion system that stops you from using overloading within an overloading function, this means you cannot get an overloaded variable within the __get method, or within any functions/methods called by the _get method, you can however call __get manualy within itself to do the same thing.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="115095">  <div class="votes">
    <div id="Vu115095">
    <a href="/manual/vote-note.php?id=115095&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115095">
    <a href="/manual/vote-note.php?id=115095&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115095" title="54% like this...">
    1
    </div>
  </div>
  <a href="#115095" class="name">
  <strong class="user"><em>cavetroll3000 at gmail dot com</em></strong></a><a class="genanchor" href="#115095"> &para;</a><div class="date" title="2014-05-24 01:40"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115095">
<div class="phpcode"><code><span class="html">
If you need to also use the magic setter in your constructor, you may use this example:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">person </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; private </span><span class="default">$name</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; private </span><span class="default">$addr</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; private </span><span class="default">$city</span><span class="keyword">;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$n</span><span class="keyword">,</span><span class="default">$a</span><span class="keyword">,</span><span class="default">$c</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">__set</span><span class="keyword">(</span><span class="string">'name'</span><span class="keyword">, </span><span class="default">$n</span><span class="keyword">); </span><span class="comment">// Pushing "name" through the setter where it will be validated and sanitated.<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">addr </span><span class="keyword">= </span><span class="default">$a</span><span class="keyword">;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="comment">// Adress is not validated<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">city </span><span class="keyword">= </span><span class="default">$c</span><span class="keyword">;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="comment">// Neither is this...<br />//&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $this-&gt;__set('city',$c);&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; // But this is...<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">}<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; public function </span><span class="default">__get</span><span class="keyword">(</span><span class="default">$property</span><span class="keyword">) {if (</span><span class="default">property_exists</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">, </span><span class="default">$property</span><span class="keyword">)) {return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$property</span><span class="keyword">;}}<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; public function </span><span class="default">__set</span><span class="keyword">(</span><span class="default">$property</span><span class="keyword">, </span><span class="default">$value</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">property_exists</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">, </span><span class="default">$property</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"&lt;pre&gt;Setting </span><span class="default">$value</span><span class="string">&lt;/pre&gt;"</span><span class="keyword">;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// ... Clever code for sanitation...<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">if (</span><span class="default">$value </span><span class="keyword">== </span><span class="string">"Evil input from user"</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"&lt;pre&gt;Oh no! Bad user! Go sit in the corner!&lt;/pre&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$property </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$property </span><span class="keyword">= </span><span class="default">$value</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$cathy </span><span class="keyword">= new </span><span class="default">person</span><span class="keyword">(</span><span class="string">'Cathy'</span><span class="keyword">,</span><span class="string">'9 Dark and Twisty'</span><span class="keyword">,</span><span class="string">'Evil input from user'</span><span class="keyword">);<br /></span><span class="default">$cathy</span><span class="keyword">-&gt;</span><span class="default">name </span><span class="keyword">= </span><span class="string">"Kitty Kat"</span><span class="keyword">;<br /><br />echo </span><span class="string">"&lt;pre&gt;" </span><span class="keyword">. </span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$cathy</span><span class="keyword">,</span><span class="default">1</span><span class="keyword">) . </span><span class="string">"&lt;/pre&gt;"</span><span class="keyword">;<br />echo </span><span class="string">"&lt;pre&gt;" </span><span class="keyword">. </span><span class="default">$cathy</span><span class="keyword">-&gt;</span><span class="default">city </span><span class="keyword">. </span><span class="string">"&lt;/pre&gt;"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />This code will output:<br /><br />Setting Kitty Kat<br />person Object<br />(<br />&nbsp; &nbsp; [name:person:private] =&gt; Kitty Kat<br />&nbsp; &nbsp; [addr:person:private] =&gt; 9 Dark and Twisty<br />&nbsp; &nbsp; [city:person:private] =&gt; Evil input from user<br />)<br />Evil input from user<br /><br />So it is important to push variables from the user through the setters even in the constructor.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114196">  <div class="votes">
    <div id="Vu114196">
    <a href="/manual/vote-note.php?id=114196&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114196">
    <a href="/manual/vote-note.php?id=114196&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114196" title="54% like this...">
    1
    </div>
  </div>
  <a href="#114196" class="name">
  <strong class="user"><em>Nanhe Kumar</em></strong></a><a class="genanchor" href="#114196"> &para;</a><div class="date" title="2014-01-23 10:28"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114196">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br /></span><span class="comment">//How can implement __call function<br /></span><span class="keyword">class </span><span class="default">Student </span><span class="keyword">{<br /><br />&nbsp; &nbsp; protected </span><span class="default">$_name</span><span class="keyword">;<br />&nbsp; &nbsp; protected </span><span class="default">$_email</span><span class="keyword">;<br />&nbsp; &nbsp; <br /><br />&nbsp; &nbsp; public function </span><span class="default">__call</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">, </span><span class="default">$arguments</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$action </span><span class="keyword">= </span><span class="default">substr</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">, </span><span class="default">0</span><span class="keyword">, </span><span class="default">3</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; switch (</span><span class="default">$action</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">'get'</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$property </span><span class="keyword">= </span><span class="string">'_' </span><span class="keyword">. </span><span class="default">strtolower</span><span class="keyword">(</span><span class="default">substr</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">, </span><span class="default">3</span><span class="keyword">));<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">property_exists</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">,</span><span class="default">$property</span><span class="keyword">)){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;{</span><span class="default">$property</span><span class="keyword">};<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }else{<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Undefined Property"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">'set'</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$property </span><span class="keyword">= </span><span class="string">'_' </span><span class="keyword">. </span><span class="default">strtolower</span><span class="keyword">(</span><span class="default">substr</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">, </span><span class="default">3</span><span class="keyword">));<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">property_exists</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">,</span><span class="default">$property</span><span class="keyword">)){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;{</span><span class="default">$property</span><span class="keyword">} = </span><span class="default">$arguments</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }else{<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Undefined Property"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; default :<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">FALSE</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br />}<br /><br /></span><span class="default">$s </span><span class="keyword">= new </span><span class="default">Student</span><span class="keyword">();<br /></span><span class="default">$s</span><span class="keyword">-&gt;</span><span class="default">setNam</span><span class="keyword">(</span><span class="string">'Nanhe Kumar'</span><span class="keyword">);<br /></span><span class="default">$s</span><span class="keyword">-&gt;</span><span class="default">setEmail</span><span class="keyword">(</span><span class="string">'nanhe.kumar@gmail.com'</span><span class="keyword">);<br />echo </span><span class="default">$s</span><span class="keyword">-&gt;</span><span class="default">getName</span><span class="keyword">(); </span><span class="comment">//Nanhe Kumar<br /></span><span class="keyword">echo </span><span class="default">$s</span><span class="keyword">-&gt;</span><span class="default">getEmail</span><span class="keyword">(); </span><span class="comment">// nanhe.kumar@gmail.com<br /></span><span class="default">$s</span><span class="keyword">-&gt;</span><span class="default">setAge</span><span class="keyword">(</span><span class="default">10</span><span class="keyword">); </span><span class="comment">//Undefined Property<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="90896">  <div class="votes">
    <div id="Vu90896">
    <a href="/manual/vote-note.php?id=90896&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd90896">
    <a href="/manual/vote-note.php?id=90896&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V90896" title="55% like this...">
    2
    </div>
  </div>
  <a href="#90896" class="name">
  <strong class="user"><em>daevid at daevid dot com</em></strong></a><a class="genanchor" href="#90896"> &para;</a><div class="date" title="2009-05-14 09:16"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom90896">
<div class="phpcode"><code><span class="html">
Here's a handy little routine to suggest properties you're trying to set that don't exist. For example:<br /><br />Attempted to __get() non-existant property/variable 'operator_id' in class 'User'.<br /><br />checking for operator and suggesting the following:<br /><br />&nbsp; &nbsp; * id_operator<br />&nbsp; &nbsp; * operator_name<br />&nbsp; &nbsp; * operator_code<br /><br />enjoy.<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Suggests alternative properties should a __get() or __set() fail<br />&nbsp; &nbsp;&nbsp; *<br />&nbsp; &nbsp;&nbsp; * @param&nbsp; &nbsp;&nbsp; string $property<br />&nbsp; &nbsp;&nbsp; * @return string<br />&nbsp; &nbsp;&nbsp; * @author Daevid Vincent [daevid@daevid.com]<br />&nbsp; &nbsp;&nbsp; * @date&nbsp; &nbsp; 05/12/09<br />&nbsp; &nbsp;&nbsp; * @see&nbsp; &nbsp; &nbsp; &nbsp; __get(), __set(), __call()<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">suggest_alternative</span><span class="keyword">(</span><span class="default">$property</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$parts </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">(</span><span class="string">'_'</span><span class="keyword">,</span><span class="default">$property</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach(</span><span class="default">$parts </span><span class="keyword">as </span><span class="default">$i </span><span class="keyword">=&gt; </span><span class="default">$p</span><span class="keyword">) if (</span><span class="default">$p </span><span class="keyword">== </span><span class="string">'_' </span><span class="keyword">|| </span><span class="default">$p </span><span class="keyword">== </span><span class="string">'id'</span><span class="keyword">) unset(</span><span class="default">$parts</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">]);<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'checking for &lt;b&gt;'</span><span class="keyword">.</span><span class="default">implode</span><span class="keyword">(</span><span class="string">', '</span><span class="keyword">,</span><span class="default">$parts</span><span class="keyword">).</span><span class="string">"&lt;/b&gt; and suggesting the following:&lt;br/&gt;\n"</span><span class="keyword">;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"&lt;ul&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach(</span><span class="default">$this </span><span class="keyword">as </span><span class="default">$key </span><span class="keyword">=&gt; </span><span class="default">$value</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; foreach(</span><span class="default">$parts </span><span class="keyword">as </span><span class="default">$p</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">stripos</span><span class="keyword">(</span><span class="default">$key</span><span class="keyword">, </span><span class="default">$p</span><span class="keyword">) !== </span><span class="default">false</span><span class="keyword">) print </span><span class="string">'&lt;li&gt;'</span><span class="keyword">.</span><span class="default">$key</span><span class="keyword">.</span><span class="string">"&lt;/li&gt;\n"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"&lt;/ul&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br /></span><span class="default">just put it in your __get</span><span class="keyword">() or </span><span class="default">__set</span><span class="keyword">() </span><span class="default">like so</span><span class="keyword">:<br /><br />&nbsp; &nbsp; public function </span><span class="default">__get</span><span class="keyword">(</span><span class="default">$property</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"&lt;p&gt;&lt;font color='#ff0000'&gt;Attempted to __get() non-existant property/variable '"</span><span class="keyword">.</span><span class="default">$property</span><span class="keyword">.</span><span class="string">"' in class '"</span><span class="keyword">.</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">get_class_name</span><span class="keyword">().</span><span class="string">"'.&lt;/font&gt;&lt;p&gt;\n"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">suggest_alternative</span><span class="keyword">(</span><span class="default">$property</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; exit;<br />&nbsp; &nbsp; }<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114160">  <div class="votes">
    <div id="Vu114160">
    <a href="/manual/vote-note.php?id=114160&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114160">
    <a href="/manual/vote-note.php?id=114160&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114160" title="53% like this...">
    1
    </div>
  </div>
  <a href="#114160" class="name">
  <strong class="user"><em>Nanhe Kumar</em></strong></a><a class="genanchor" href="#114160"> &para;</a><div class="date" title="2014-01-17 10:47"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114160">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br /></span><span class="comment">//How can implement __call function you understand better<br /></span><span class="keyword">class </span><span class="default">Employee </span><span class="keyword">{<br /><br />&nbsp; &nbsp; protected </span><span class="default">$_name</span><span class="keyword">;<br />&nbsp; &nbsp; protected </span><span class="default">$_email</span><span class="keyword">;<br />&nbsp; &nbsp; protected </span><span class="default">$_compony</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public function </span><span class="default">__call</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">, </span><span class="default">$arguments</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$action </span><span class="keyword">= </span><span class="default">substr</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">, </span><span class="default">0</span><span class="keyword">, </span><span class="default">3</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; switch (</span><span class="default">$action</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">'get'</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$property </span><span class="keyword">= </span><span class="string">'_' </span><span class="keyword">. </span><span class="default">strtolower</span><span class="keyword">(</span><span class="default">substr</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">, </span><span class="default">3</span><span class="keyword">));<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">property_exists</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">,</span><span class="default">$property</span><span class="keyword">)){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;{</span><span class="default">$property</span><span class="keyword">};<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }else{<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$trace </span><span class="keyword">= </span><span class="default">debug_backtrace</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">trigger_error</span><span class="keyword">(</span><span class="string">'Undefined property&nbsp; ' </span><span class="keyword">. </span><span class="default">$name </span><span class="keyword">. </span><span class="string">' in ' </span><span class="keyword">. </span><span class="default">$trace</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">][</span><span class="string">'file'</span><span class="keyword">] . </span><span class="string">' on line ' </span><span class="keyword">. </span><span class="default">$trace</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">][</span><span class="string">'line'</span><span class="keyword">], </span><span class="default">E_USER_NOTICE</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">'set'</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$property </span><span class="keyword">= </span><span class="string">'_' </span><span class="keyword">. </span><span class="default">strtolower</span><span class="keyword">(</span><span class="default">substr</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">, </span><span class="default">3</span><span class="keyword">));<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">property_exists</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">,</span><span class="default">$property</span><span class="keyword">)){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;{</span><span class="default">$property</span><span class="keyword">} = </span><span class="default">$arguments</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }else{<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$trace </span><span class="keyword">= </span><span class="default">debug_backtrace</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">trigger_error</span><span class="keyword">(</span><span class="string">'Undefined property&nbsp; ' </span><span class="keyword">. </span><span class="default">$name </span><span class="keyword">. </span><span class="string">' in ' </span><span class="keyword">. </span><span class="default">$trace</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">][</span><span class="string">'file'</span><span class="keyword">] . </span><span class="string">' on line ' </span><span class="keyword">. </span><span class="default">$trace</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">][</span><span class="string">'line'</span><span class="keyword">], </span><span class="default">E_USER_NOTICE</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; default :<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">FALSE</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br />}<br /><br /></span><span class="default">$s </span><span class="keyword">= new </span><span class="default">Employee</span><span class="keyword">();<br /></span><span class="default">$s</span><span class="keyword">-&gt;</span><span class="default">setName</span><span class="keyword">(</span><span class="string">'Nanhe Kumar'</span><span class="keyword">);<br /></span><span class="default">$s</span><span class="keyword">-&gt;</span><span class="default">setEmail</span><span class="keyword">(</span><span class="string">'nanhe.kumar@gmail.com'</span><span class="keyword">);<br />echo </span><span class="default">$s</span><span class="keyword">-&gt;</span><span class="default">getName</span><span class="keyword">(); </span><span class="comment">//Nanhe Kumar<br /></span><span class="keyword">echo </span><span class="default">$s</span><span class="keyword">-&gt;</span><span class="default">getEmail</span><span class="keyword">(); </span><span class="comment">// nanhe.kumar@gmail.com<br /></span><span class="default">$s</span><span class="keyword">-&gt;</span><span class="default">setAge</span><span class="keyword">(</span><span class="default">10</span><span class="keyword">); </span><span class="comment">//Notice: Undefined property setAge in<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="51175">  <div class="votes">
    <div id="Vu51175">
    <a href="/manual/vote-note.php?id=51175&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd51175">
    <a href="/manual/vote-note.php?id=51175&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V51175" title="54% like this...">
    1
    </div>
  </div>
  <a href="#51175" class="name">
  <strong class="user"><em>ryo at shadowlair dot info</em></strong></a><a class="genanchor" href="#51175"> &para;</a><div class="date" title="2005-03-22 10:22"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom51175">
<div class="phpcode"><code><span class="html">
Keep in mind that when your class has a __call() function, it will be used when PHP calls some other magic functions. This can lead to unexpected errors:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">TestClass </span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$someVar</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public function </span><span class="default">__call</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">, </span><span class="default">$args</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// handle the overloaded functions we know...<br />&nbsp; &nbsp; &nbsp; &nbsp; // [...]<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; // raise an error if the function is unknown, just like PHP would<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">trigger_error</span><span class="keyword">(</span><span class="default">sprintf</span><span class="keyword">(</span><span class="string">'Call to undefined function: %s::%s().'</span><span class="keyword">, </span><span class="default">get_class</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">), </span><span class="default">$name</span><span class="keyword">), </span><span class="default">E_USER_ERROR</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$obj </span><span class="keyword">= new </span><span class="default">TestClass</span><span class="keyword">();<br /></span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">someVar </span><span class="keyword">= </span><span class="string">'some value'</span><span class="keyword">;<br /><br />echo </span><span class="default">$obj</span><span class="keyword">; </span><span class="comment">//Fatal error: Call to undefined function: TestClass::__tostring().<br /></span><span class="default">$serializedObj </span><span class="keyword">= </span><span class="default">serialize</span><span class="keyword">(</span><span class="default">$obj</span><span class="keyword">); </span><span class="comment">// Fatal error: Call to undefined function: TestClass::__sleep().<br /></span><span class="default">$unserializedObj </span><span class="keyword">= </span><span class="default">unserialize</span><span class="keyword">(</span><span class="default">$someSerializedTestClassObject</span><span class="keyword">); </span><span class="comment">// Fatal error: Call to undefined function: TestClass::__wakeup().<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121511">  <div class="votes">
    <div id="Vu121511">
    <a href="/manual/vote-note.php?id=121511&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121511">
    <a href="/manual/vote-note.php?id=121511&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121511" title="100% like this...">
    1
    </div>
  </div>
  <a href="#121511" class="name">
  <strong class="user"><em>niki_arsov at mail dot bg</em></strong></a><a class="genanchor" href="#121511"> &para;</a><div class="date" title="2017-08-11 08:32"><strong>4 months ago</strong></div>
  <div class="text" id="Hcom121511">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Overload<br /></span><span class="keyword">{<br />&nbsp; function </span><span class="default">__call</span><span class="keyword">(</span><span class="default">$function</span><span class="keyword">, </span><span class="default">$params</span><span class="keyword">)<br />&nbsp; {<br />&nbsp; &nbsp; </span><span class="default">$function </span><span class="keyword">= </span><span class="string">'_' </span><span class="keyword">. </span><span class="default">$function</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$function</span><span class="keyword">(</span><span class="default">$params</span><span class="keyword">);<br />&nbsp; }<br /><br />&nbsp; public function </span><span class="default">_show</span><span class="keyword">(</span><span class="default">$params </span><span class="keyword">)<br />&nbsp; {<br />&nbsp; &nbsp; </span><span class="default">$res </span><span class="keyword">= </span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; switch (</span><span class="default">count</span><span class="keyword">(</span><span class="default">$params</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; case </span><span class="default">0</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$res </span><span class="keyword">= </span><span class="default">sprintf</span><span class="keyword">(</span><span class="string">"method show with %d arg"</span><span class="keyword">, </span><span class="default">0</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; case </span><span class="default">1</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$res </span><span class="keyword">= </span><span class="default">sprintf</span><span class="keyword">(</span><span class="string">"method show with %d arg: %s"</span><span class="keyword">, </span><span class="default">1</span><span class="keyword">, </span><span class="default">$params</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$res </span><span class="keyword">.= </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">getType</span><span class="keyword">(</span><span class="default">$params</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; case </span><span class="default">2</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$res </span><span class="keyword">= </span><span class="default">sprintf</span><span class="keyword">(</span><span class="string">"method show with %d arg: %s, %s"</span><span class="keyword">, </span><span class="default">2</span><span class="keyword">, </span><span class="default">$params</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">], </span><span class="default">$params</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$res </span><span class="keyword">.= </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">getType</span><span class="keyword">(</span><span class="default">$params</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$res </span><span class="keyword">.= </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">getType</span><span class="keyword">(</span><span class="default">$params</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; default:<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment"># code...<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">break;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; print </span><span class="default">$res </span><span class="keyword">. </span><span class="string">"\n"</span><span class="keyword">;<br />&nbsp; }<br /><br />&nbsp; private function </span><span class="default">getType</span><span class="keyword">(</span><span class="default">$arg</span><span class="keyword">)<br />&nbsp; {<br />&nbsp; &nbsp; </span><span class="default">$res </span><span class="keyword">= </span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; switch (</span><span class="default">gettype</span><span class="keyword">(</span><span class="default">$arg</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; case </span><span class="string">'double'</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$res </span><span class="keyword">.= </span><span class="string">' - double'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; case </span><span class="string">'string'</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$res </span><span class="keyword">.= </span><span class="string">' - string'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; case </span><span class="string">'integer'</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$res </span><span class="keyword">.= </span><span class="string">' - integer'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; default:<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$res </span><span class="keyword">.= </span><span class="string">' - '</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; return </span><span class="default">$res</span><span class="keyword">;<br />&nbsp; }<br /><br />}<br /><br /></span><span class="default">$class </span><span class="keyword">= new </span><span class="default">Overload</span><span class="keyword">;<br /><br /></span><span class="default">$class</span><span class="keyword">-&gt;</span><span class="default">show</span><span class="keyword">();<br /></span><span class="default">$class</span><span class="keyword">-&gt;</span><span class="default">show</span><span class="keyword">(</span><span class="default">12</span><span class="keyword">);<br /></span><span class="default">$class</span><span class="keyword">-&gt;</span><span class="default">show</span><span class="keyword">(</span><span class="default">12.5</span><span class="keyword">);<br /></span><span class="default">$class</span><span class="keyword">-&gt;</span><span class="default">show</span><span class="keyword">(</span><span class="string">'test'</span><span class="keyword">);<br /></span><span class="default">$class</span><span class="keyword">-&gt;</span><span class="default">show</span><span class="keyword">(</span><span class="string">'test'</span><span class="keyword">, </span><span class="default">1.5</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />Will output:<br />method show with 0 arg<br />method show with 1 arg: 12 - integer<br />method show with 1 arg: 12.5 - double<br />method show with 1 arg: test - string<br />method show with 2 arg: test, 1.5 - string - double</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121510">  <div class="votes">
    <div id="Vu121510">
    <a href="/manual/vote-note.php?id=121510&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121510">
    <a href="/manual/vote-note.php?id=121510&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121510" title="no votes...">
    0
    </div>
  </div>
  <a href="#121510" class="name">
  <strong class="user"><em>niki_arsov at mail dot bg</em></strong></a><a class="genanchor" href="#121510"> &para;</a><div class="date" title="2017-08-11 08:30"><strong>4 months ago</strong></div>
  <div class="text" id="Hcom121510">
<div class="phpcode"><code><span class="html">
class Overload<br />{<br />&nbsp; function __call($function, $params)<br />&nbsp; {<br />&nbsp; &nbsp; $function = '_' . $function;<br />&nbsp; &nbsp; $this-&gt;$function($params);<br />&nbsp; }<br /><br />&nbsp; public function _show($params )<br />&nbsp; {<br />&nbsp; &nbsp; $res = '';<br />&nbsp; &nbsp; switch (count($params)) {<br />&nbsp; &nbsp; &nbsp; case 0:<br />&nbsp; &nbsp; &nbsp; &nbsp; $res = sprintf("method show with %d arg", 0);<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; case 1:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $res = sprintf("method show with %d arg: %s", 1, $params[0]);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $res .= $this-&gt;getType($params[0]);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; case 2:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $res = sprintf("method show with %d arg: %s, %s", 2, $params[0], $params[1]);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $res .= $this-&gt;getType($params[0]);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $res .= $this-&gt;getType($params[1]);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; default:<br />&nbsp; &nbsp; &nbsp; &nbsp; # code...<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; print $res . "\n";<br />&nbsp; }<br /><br />&nbsp; private function getType($arg)<br />&nbsp; {<br />&nbsp; &nbsp; $res = '';<br />&nbsp; &nbsp; switch (gettype($arg)) {<br />&nbsp; &nbsp; &nbsp; case 'double':<br />&nbsp; &nbsp; &nbsp; &nbsp; $res .= ' - double';<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; case 'string':<br />&nbsp; &nbsp; &nbsp; &nbsp; $res .= ' - string';<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; case 'integer':<br />&nbsp; &nbsp; &nbsp; &nbsp; $res .= ' - integer';<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; default:<br />&nbsp; &nbsp; &nbsp; &nbsp; $res .= ' - ';<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; return $res;<br />&nbsp; }<br /><br />}<br /><br />$class = new Overload;<br /><br />$class-&gt;show();<br />$class-&gt;show(12);<br />$class-&gt;show(12.5);<br />$class-&gt;show('test');<br />$class-&gt;show('test', 1.5);<br /><br />Output:<br />method show with 0 arg<br />method show with 1 arg: 12 - integer<br />method show with 1 arg: 12.5 - double<br />method show with 1 arg: test - string<br />method show with 2 arg: test, 1.5 - string - double</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121574">  <div class="votes">
    <div id="Vu121574">
    <a href="/manual/vote-note.php?id=121574&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121574">
    <a href="/manual/vote-note.php?id=121574&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121574" title="0% like this...">
    -2
    </div>
  </div>
  <a href="#121574" class="name">
  <strong class="user"><em>simurgrai at gmail dot com</em></strong></a><a class="genanchor" href="#121574"> &para;</a><div class="date" title="2017-08-29 09:50"><strong>3 months ago</strong></div>
  <div class="text" id="Hcom121574">
<div class="phpcode"><code><span class="html">
For silent data encapsulation in PHP<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">Class </span><span class="default">Test<br /></span><span class="keyword">{<br />&nbsp; &nbsp;&nbsp; function </span><span class="default">__set</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">, </span><span class="default">$value</span><span class="keyword">) {}<br />}<br /><br /></span><span class="default">$obj </span><span class="keyword">= new </span><span class="default">test</span><span class="keyword">();<br /></span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">prop1 </span><span class="keyword">= </span><span class="string">'foobar'</span><span class="keyword">;<br /><br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$obj</span><span class="keyword">); </span><span class="comment">// Prints Test Object ( ) <br /></span><span class="keyword">echo </span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">prop1</span><span class="keyword">; </span><span class="comment">//Give NOTICE Undefined property: Test::$prop1<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120688">  <div class="votes">
    <div id="Vu120688">
    <a href="/manual/vote-note.php?id=120688&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120688">
    <a href="/manual/vote-note.php?id=120688&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120688" title="no votes...">
    0
    </div>
  </div>
  <a href="#120688" class="name">
  <strong class="user"><em>mfdboy at 163 dot com</em></strong></a><a class="genanchor" href="#120688"> &para;</a><div class="date" title="2017-02-22 03:27"><strong>9 months ago</strong></div>
  <div class="text" id="Hcom120688">
<div class="phpcode"><code><span class="html">
class MethodTest<br />{<br />&nbsp; &nbsp; public static function __callStatic($name, $arguments)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; // Note: value of $name is case sensitive.<br />&nbsp; &nbsp; &nbsp; &nbsp; echo "Calling Non-static,private method '$name' "<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; . implode(', ', $arguments). "\n";<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function runTest($arguments){<br />&nbsp; &nbsp; &nbsp; &nbsp; //TODO<br />&nbsp; &nbsp; }<br />}<br /><br />MethodTest::runTest('in static context'); <br />if you write code like this,php will display error PHP Strict standards:&nbsp; Non-static method MethodTest::runTest() should not be called statically<br />class MethodTest<br />{<br />&nbsp; &nbsp; public static function __callStatic($name, $arguments)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; // Note: value of $name is case sensitive.<br />&nbsp; &nbsp; &nbsp; &nbsp; echo "Calling Non-static,private method '$name' "<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; . implode(', ', $arguments). "\n";<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; private function runTest($arguments){<br />&nbsp; &nbsp; &nbsp; &nbsp; //TODO<br />&nbsp; &nbsp; }<br />}<br /><br />MethodTest::runTest('in static context'); <br />but this won't<br />It means public Non-static method is not inaccessible</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120549">  <div class="votes">
    <div id="Vu120549">
    <a href="/manual/vote-note.php?id=120549&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120549">
    <a href="/manual/vote-note.php?id=120549&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120549" title="no votes...">
    0
    </div>
  </div>
  <a href="#120549" class="name">
  <strong class="user"><em>david dot bruchmann at gmail dot com</em></strong></a><a class="genanchor" href="#120549"> &para;</a><div class="date" title="2017-01-28 11:41"><strong>10 months ago</strong></div>
  <div class="text" id="Hcom120549">
<div class="phpcode"><code><span class="html">
As mentioned by "pogregoire##live.fr" you can attach properties to an object like shown in his example:<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Object</span><span class="keyword">{<br /><br />}<br /></span><span class="default">$Object </span><span class="keyword">= new </span><span class="default">Object</span><span class="keyword">();<br /></span><span class="default">$Objet</span><span class="keyword">-&gt;</span><span class="default">barbarianProperties&nbsp; </span><span class="keyword">= </span><span class="string">'boom'</span><span class="keyword">;<br /><br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$Objet</span><span class="keyword">);&nbsp; &nbsp; </span><span class="comment">// object(Objet)#1 (1) { ["barbarianProperties"]=&gt; string(7) "boom" }<br /></span><span class="default">?&gt;<br /></span>This is surly not the right way to use variables and objects but never has any influence on the object itself, the new property is only associated with the object.<br />It's not possible to inject closures like this to get protected properties or do any actions:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">abc </span><span class="keyword">{<br />&nbsp; &nbsp; protected </span><span class="default">$a </span><span class="keyword">= </span><span class="default">NULL</span><span class="keyword">;<br />&nbsp; &nbsp; protected </span><span class="default">$b </span><span class="keyword">= </span><span class="default">NULL</span><span class="keyword">;<br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">=</span><span class="default">NULL</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">=</span><span class="default">NULL</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">a </span><span class="keyword">= </span><span class="default">$a</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">b </span><span class="keyword">= </span><span class="default">$b</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">$abc </span><span class="keyword">= new </span><span class="default">abc</span><span class="keyword">(</span><span class="string">'uvw'</span><span class="keyword">,</span><span class="string">'xyz'</span><span class="keyword">);<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$abc</span><span class="keyword">);<br /><br /></span><span class="default">$abc</span><span class="keyword">-&gt;</span><span class="default">undefined </span><span class="keyword">= (function(){<br />&nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">);<br />&nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">a</span><span class="keyword">.</span><span class="string">', '</span><span class="keyword">.</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">b</span><span class="keyword">;<br />});<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$abc</span><span class="keyword">);<br />echo </span><span class="default">$abc</span><span class="keyword">-&gt;</span><span class="default">undefined</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span><br />Output:<br /><br />object(abc)#1 (2) {<br />&nbsp; &nbsp; ["def":protected]=&gt; string(3) "uvw"<br />&nbsp; &nbsp; ["ghi":protected]=&gt; string(3) "xyz"<br />}<br /><br />object(abc)#1 (3) {<br />&nbsp; &nbsp; ["def":protected]=&gt; string(3) "uvw"<br />&nbsp; &nbsp; ["ghi":protected]=&gt; string(3) "xyz"<br />&nbsp; &nbsp; ["undefined"]=&gt; object(Closure)#2 (0) { }<br />}<br /><br />Fatal error: Call to undefined method abc::undefined() in test.php</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116236">  <div class="votes">
    <div id="Vu116236">
    <a href="/manual/vote-note.php?id=116236&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116236">
    <a href="/manual/vote-note.php?id=116236&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116236" title="100% like this...">
    1
    </div>
  </div>
  <a href="#116236" class="name">
  <strong class="user"><em>gabe at fijiwebdesign dot com</em></strong></a><a class="genanchor" href="#116236"> &para;</a><div class="date" title="2014-11-27 11:33"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom116236">
<div class="phpcode"><code><span class="html">
Note that you can enable "overloading" on a class instance at runtime for an existing property by unset()ing that property. <br /><br />eg: <br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Test </span><span class="keyword">{ <br /><br />&nbsp; &nbsp; public </span><span class="default">$property1</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public function </span><span class="default">__get</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">) <br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">"Get called for " </span><span class="keyword">. </span><span class="default">get_class</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">) . </span><span class="string">"-&gt;\$</span><span class="default">$name</span><span class="string"> \n"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />}<br /></span><span class="default">?&gt;<br /></span><br />The public property $property1 can be unset() so that it can be dynamically handled via __get(). <br /><br /><span class="default">&lt;?php <br />$Test </span><span class="keyword">= new </span><span class="default">Test</span><span class="keyword">();<br />unset(</span><span class="default">$Test</span><span class="keyword">-&gt;</span><span class="default">property1</span><span class="keyword">); </span><span class="comment">// enable overloading<br /></span><span class="keyword">echo </span><span class="default">$Test</span><span class="keyword">-&gt;</span><span class="default">property1</span><span class="keyword">; </span><span class="comment">// Get called for Test-&gt;$property1<br /></span><span class="default">?&gt;<br /></span><br />Useful if you want to proxy or lazy load properties yet want to have documentation and visibility in the code and debugging compared to __get(), __isset(), __set() on non-existent inaccessible properties.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="115728">  <div class="votes">
    <div id="Vu115728">
    <a href="/manual/vote-note.php?id=115728&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115728">
    <a href="/manual/vote-note.php?id=115728&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115728" title="50% like this...">
    0
    </div>
  </div>
  <a href="#115728" class="name">
  <strong class="user"><em>cottton at i-stats dot net</em></strong></a><a class="genanchor" href="#115728"> &para;</a><div class="date" title="2014-09-13 02:58"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115728">
<div class="phpcode"><code><span class="html">
Actually you dont need __set ect imo.&nbsp; <br />You could use it to set (pre-defined) protected (and in "some" cases private) properties . But who wants that? <br />(test it by uncommenting private or protected)<br />(pastebin because long ...) =&gt; <a href="http://pastebin.com/By4gHrt5" rel="nofollow" target="_blank">http://pastebin.com/By4gHrt5</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="115245">  <div class="votes">
    <div id="Vu115245">
    <a href="/manual/vote-note.php?id=115245&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115245">
    <a href="/manual/vote-note.php?id=115245&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115245" title="50% like this...">
    0
    </div>
  </div>
  <a href="#115245" class="name">
  <strong class="user"><em>bimal at sanjaal dot com</em></strong></a><a class="genanchor" href="#115245"> &para;</a><div class="date" title="2014-06-19 09:05"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115245">
<div class="phpcode"><code><span class="html">
Use of magic functions may make your private variables behave like public ones.<br />But it becomes strict; you cannot (in fact should not) assign any properties dynamically during the runtime.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">order<br /></span><span class="keyword">{<br />&nbsp; &nbsp; private </span><span class="default">$OrderID</span><span class="keyword">=</span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; private </span><span class="default">$OrderAmount</span><span class="keyword">=</span><span class="default">0.00</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">__set</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">=</span><span class="string">''</span><span class="keyword">, </span><span class="default">$value</span><span class="keyword">=</span><span class="string">''</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">property_exists</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">, </span><span class="default">$name</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$name </span><span class="keyword">= </span><span class="default">$value</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">__get</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">=</span><span class="string">''</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$value </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">property_exists</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">, </span><span class="default">$name</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$value </span><span class="keyword">= </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$name</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$value</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$order </span><span class="keyword">= new </span><span class="default">order</span><span class="keyword">();<br /></span><span class="default">$order</span><span class="keyword">-&gt;</span><span class="default">OrderID </span><span class="keyword">= </span><span class="string">'201305062202'</span><span class="keyword">;<br /></span><span class="default">$order</span><span class="keyword">-&gt;</span><span class="default">OrderAmount </span><span class="keyword">= </span><span class="default">23.45</span><span class="keyword">;<br /></span><span class="default">$order</span><span class="keyword">-&gt;</span><span class="default">InvalidMember </span><span class="keyword">= </span><span class="string">'Missed Assignment'</span><span class="keyword">;<br /><br />echo </span><span class="string">'&lt;pre&gt;'</span><span class="keyword">, </span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$order</span><span class="keyword">, </span><span class="default">true</span><span class="keyword">), </span><span class="string">'&lt;/pre&gt;'</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;<br /></span><br />Outputs:<br />order Object<br />(<br />&nbsp; &nbsp; [OrderID:order:private] =&gt; 201305062202<br />&nbsp; &nbsp; [OrderAmount:order:private] =&gt; 23.45<br />)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="104296">  <div class="votes">
    <div id="Vu104296">
    <a href="/manual/vote-note.php?id=104296&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd104296">
    <a href="/manual/vote-note.php?id=104296&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V104296" title="50% like this...">
    0
    </div>
  </div>
  <a href="#104296" class="name">
  <strong class="user"><em>jk at jankriedner dot de</em></strong></a><a class="genanchor" href="#104296"> &para;</a><div class="date" title="2011-06-07 03:15"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom104296">
<div class="phpcode"><code><span class="html">
You should take care when using properties retrieved via __get() in functions that expect arguments to be passed by reference (e.g. mysqli_stmt_bind_param). The reference is NOT set to the property itself, but to the value returned by __get().<br />Thus, binding a property retrieved via __get() to a statement will let the statement be executed always with the value the property had when calling bind_param, not with the current value it has when calling execute().<br />E.g.:<br /><span class="default">&lt;?php<br />error_reporting</span><span class="keyword">(</span><span class="default">E_ALL</span><span class="keyword">);<br />class </span><span class="default">foo </span><span class="keyword">{<br />&nbsp; &nbsp; protected </span><span class="default">$bar</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">bar </span><span class="keyword">= </span><span class="string">"Hello World!"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public static function </span><span class="default">factory</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return new </span><span class="default">self</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public function </span><span class="default">__get</span><span class="keyword">(</span><span class="default">$property</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if(!</span><span class="default">property_exists</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">,</span><span class="default">$property</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">InvalidArgumentException</span><span class="keyword">(</span><span class="string">"Property </span><span class="keyword">{</span><span class="default">$property</span><span class="keyword">}</span><span class="string"> doesn't exist"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$property</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public function </span><span class="default">setBar</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">bar </span><span class="keyword">= </span><span class="default">$value</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">$foo </span><span class="keyword">= new </span><span class="default">foo</span><span class="keyword">();<br />echo </span><span class="default">$foo</span><span class="keyword">-&gt;</span><span class="default">bar</span><span class="keyword">;&nbsp; &nbsp; </span><span class="comment">// Ouputs: Hello World!<br /></span><span class="default">$db </span><span class="keyword">= new </span><span class="default">mysqli</span><span class="keyword">(</span><span class="string">"localhost"</span><span class="keyword">,</span><span class="string">"root"</span><span class="keyword">,</span><span class="string">""</span><span class="keyword">,</span><span class="string">"tests"</span><span class="keyword">);<br /></span><span class="default">$sql </span><span class="keyword">= </span><span class="string">"INSERT INTO foo SET bar=?"</span><span class="keyword">;<br /></span><span class="default">$res </span><span class="keyword">= </span><span class="default">$db</span><span class="keyword">-&gt;</span><span class="default">prepare</span><span class="keyword">(</span><span class="default">$sql</span><span class="keyword">);<br /></span><span class="default">$res</span><span class="keyword">-&gt;</span><span class="default">bind_param</span><span class="keyword">(</span><span class="string">"s"</span><span class="keyword">,</span><span class="default">$foo</span><span class="keyword">-&gt;</span><span class="default">bar</span><span class="keyword">);&nbsp; </span><span class="comment">// Notice: Indirect modification of overloaded property foo::$bar has no effect in /var/www/overload.php on line 24<br /></span><span class="default">$res</span><span class="keyword">-&gt;</span><span class="default">execute</span><span class="keyword">();&nbsp; </span><span class="comment">// Writes "Hello World!" to database<br /></span><span class="default">$foo</span><span class="keyword">-&gt;</span><span class="default">setBar</span><span class="keyword">(</span><span class="string">"Goodbye"</span><span class="keyword">);<br />echo </span><span class="default">$foo</span><span class="keyword">-&gt;</span><span class="default">bar</span><span class="keyword">;&nbsp;&nbsp; </span><span class="comment">// Outputs: Goodbye<br /></span><span class="default">$res</span><span class="keyword">-&gt;</span><span class="default">execute</span><span class="keyword">();&nbsp; </span><span class="comment">// Writes "Hello World!" to database<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="91927">  <div class="votes">
    <div id="Vu91927">
    <a href="/manual/vote-note.php?id=91927&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd91927">
    <a href="/manual/vote-note.php?id=91927&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V91927" title="50% like this...">
    0
    </div>
  </div>
  <a href="#91927" class="name">
  <strong class="user"><em>eric dot druid+php dot net at gmail dot com</em></strong></a><a class="genanchor" href="#91927"> &para;</a><div class="date" title="2009-07-01 04:22"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom91927">
<div class="phpcode"><code><span class="html">
I needed to know from where a member variable was set from to determine visibility. <br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">foo </span><span class="keyword">{<br />&nbsp; private </span><span class="default">$data</span><span class="keyword">;<br />&nbsp; public function </span><span class="default">__set</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">, </span><span class="default">$value</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$trace </span><span class="keyword">= </span><span class="default">debug_backtrace</span><span class="keyword">();<br />&nbsp; &nbsp; if(!isset(</span><span class="default">$trace</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]) || </span><span class="default">$trace</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">][</span><span class="string">'object'</span><span class="keyword">] != </span><span class="default">$trace</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">][</span><span class="string">'object'</span><span class="keyword">]) {<br />&nbsp; &nbsp; &nbsp; die(</span><span class="string">"Trying to set protected member '</span><span class="default">$name</span><span class="string">' from public scope."</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; </span><span class="default">$data</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">] = </span><span class="default">$value</span><span class="keyword">;<br />&nbsp; }<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="88949">  <div class="votes">
    <div id="Vu88949">
    <a href="/manual/vote-note.php?id=88949&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd88949">
    <a href="/manual/vote-note.php?id=88949&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V88949" title="50% like this...">
    0
    </div>
  </div>
  <a href="#88949" class="name">
  <strong class="user"><em>niehztog</em></strong></a><a class="genanchor" href="#88949"> &para;</a><div class="date" title="2009-02-14 10:59"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom88949">
<div class="phpcode"><code><span class="html">
If you got a parent class agregating(not inheriting) a number of child classes in an array, you can use the following to allow calling methods of the parent object on agregated child objects:<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">child </span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$holder </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public function </span><span class="default">__call</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">, </span><span class="default">$arguments</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">holder </span><span class="keyword">instanceof </span><span class="default">parentClass </span><span class="keyword">&amp;&amp; </span><span class="default">method_exists</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">holder</span><span class="keyword">, </span><span class="default">$name</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">call_user_func_array</span><span class="keyword">(array(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">holder</span><span class="keyword">, </span><span class="default">$name</span><span class="keyword">), </span><span class="default">$arguments</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">trigger_error</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">parentClass </span><span class="keyword">{<br />&nbsp; &nbsp; private </span><span class="default">$children </span><span class="keyword">= array();<br /><br />&nbsp; &nbsp; function </span><span class="default">__construct</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">children</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">] = new </span><span class="default">child</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">children</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]-&gt;</span><span class="default">holder </span><span class="keyword">= </span><span class="default">$this</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; function </span><span class="default">getChild</span><span class="keyword">(</span><span class="default">$number</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if(!isset(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">children</span><span class="keyword">[</span><span class="default">$number</span><span class="keyword">])) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">children</span><span class="keyword">[</span><span class="default">$number</span><span class="keyword">];<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; function </span><span class="default">test</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">'it works'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$parent </span><span class="keyword">= new </span><span class="default">parentClass</span><span class="keyword">();<br /></span><span class="default">$firstChild </span><span class="keyword">= </span><span class="default">$parent</span><span class="keyword">-&gt;</span><span class="default">getChild</span><span class="keyword">(</span><span class="default">0</span><span class="keyword">);<br />echo </span><span class="default">$firstChild</span><span class="keyword">-&gt;</span><span class="default">test</span><span class="keyword">(); </span><span class="comment">//should output 'it works'<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="80686">  <div class="votes">
    <div id="Vu80686">
    <a href="/manual/vote-note.php?id=80686&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd80686">
    <a href="/manual/vote-note.php?id=80686&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V80686" title="100% like this...">
    2
    </div>
  </div>
  <a href="#80686" class="name">
  <strong class="user"><em>timshaw at mail dot NOSPAMusa dot com</em></strong></a><a class="genanchor" href="#80686"> &para;</a><div class="date" title="2008-01-28 09:47"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom80686">
<div class="phpcode"><code><span class="html">
The __get overload method will be called on a declared public member of an object if that member has been unset.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">c </span><span class="keyword">{<br />&nbsp; public </span><span class="default">$p </span><span class="keyword">;<br />&nbsp; public function </span><span class="default">__get</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">) { return </span><span class="string">"__get of </span><span class="default">$name</span><span class="string">" </span><span class="keyword">; }<br />}<br /><br /></span><span class="default">$c </span><span class="keyword">= new </span><span class="default">c </span><span class="keyword">;<br />echo </span><span class="default">$c</span><span class="keyword">-&gt;</span><span class="default">p</span><span class="keyword">, </span><span class="string">"\n" </span><span class="keyword">;&nbsp; &nbsp; </span><span class="comment">// declared public member value is empty<br /></span><span class="default">$c</span><span class="keyword">-&gt;</span><span class="default">p </span><span class="keyword">= </span><span class="default">5 </span><span class="keyword">;<br />echo </span><span class="default">$c</span><span class="keyword">-&gt;</span><span class="default">p</span><span class="keyword">, </span><span class="string">"\n" </span><span class="keyword">;&nbsp; &nbsp; </span><span class="comment">// declared public member value is 5<br /></span><span class="keyword">unset(</span><span class="default">$c</span><span class="keyword">-&gt;</span><span class="default">p</span><span class="keyword">) ;<br />echo </span><span class="default">$c</span><span class="keyword">-&gt;</span><span class="default">p</span><span class="keyword">, </span><span class="string">"\n" </span><span class="keyword">;&nbsp; &nbsp; </span><span class="comment">// after unset, value is "__get of p"<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="80368">  <div class="votes">
    <div id="Vu80368">
    <a href="/manual/vote-note.php?id=80368&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd80368">
    <a href="/manual/vote-note.php?id=80368&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V80368" title="50% like this...">
    0
    </div>
  </div>
  <a href="#80368" class="name">
  <strong class="user"><em>v dot umang at gmail dot com</em></strong></a><a class="genanchor" href="#80368"> &para;</a><div class="date" title="2008-01-11 09:20"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom80368">
<div class="phpcode"><code><span class="html">
If you want to be able to overload a variable from within a class and this is your code:<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">myClass<br /></span><span class="keyword">{<br />&nbsp; &nbsp; private </span><span class="default">$data</span><span class="keyword">;<br />&nbsp; &nbsp; public function </span><span class="default">__set</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">, </span><span class="default">$val</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">data</span><span class="keyword">[</span><span class="default">$var</span><span class="keyword">] = </span><span class="default">$val</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public function </span><span class="default">__get</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">data</span><span class="keyword">[</span><span class="default">$var</span><span class="keyword">] = </span><span class="default">$val</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />There is a problem if you want to call these variables from within the class, as you you want to access data['data'] then you can't say $this-&gt;data as it will return the array $data. Therefore a simple solution is to name the array $_data. So in your __get and __set you will say $this-&gt;_data ... rather than $this-&gt;data. I.E:<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">myClass<br /></span><span class="keyword">{<br />&nbsp; &nbsp; private </span><span class="default">$_data</span><span class="keyword">;<br />&nbsp; &nbsp; public function </span><span class="default">__set</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">, </span><span class="default">$val</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">_data</span><span class="keyword">[</span><span class="default">$var</span><span class="keyword">] = </span><span class="default">$val</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public function </span><span class="default">__get</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">_data</span><span class="keyword">[</span><span class="default">$var</span><span class="keyword">] = </span><span class="default">$val</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />Umang</span>
</code></div>
  </div>
 </div>
  <div class="note" id="79960">  <div class="votes">
    <div id="Vu79960">
    <a href="/manual/vote-note.php?id=79960&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd79960">
    <a href="/manual/vote-note.php?id=79960&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V79960" title="50% like this...">
    0
    </div>
  </div>
  <a href="#79960" class="name">
  <strong class="user"><em>egingell at sisna dot com</em></strong></a><a class="genanchor" href="#79960"> &para;</a><div class="date" title="2007-12-20 07:54"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom79960">
<div class="phpcode"><code><span class="html">
The PHP devs aren't going to implement true overloading because: PHP is not strictly typed by any stretch of the imagination (0, "0", null, false, and "" are the same, for example) and unlike Java and C++, you can pass as many values as you want to a function. The extras are ignored unless you fetch them using func_get_arg(int) or func_get_args(), which is often how I "overload" a function/method, and fewer than the declared number of arguments will generate an E_WARNING, which can be suppressed by putting '@' before the function call, but the function will still run as if you had passed null where a value was expected.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">someClass </span><span class="keyword">{<br />&nbsp; &nbsp; function </span><span class="default">whatever</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$args </span><span class="keyword">= </span><span class="default">func_get_args</span><span class="keyword">();<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// public boolean whatever(boolean arg1) in Java<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">if (</span><span class="default">is_bool</span><span class="keyword">(</span><span class="default">$args</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">])) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// whatever(true);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">$args</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">];<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// public int whatever(int arg1, boolean arg2) in Java<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">} elseif(</span><span class="default">is_int</span><span class="keyword">(</span><span class="default">$args</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]) &amp;&amp; </span><span class="default">is_bool</span><span class="keyword">(</span><span class="default">$args</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">])) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// whatever(1, false)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">$args</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">];<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// public void whatever() in Java<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">echo </span><span class="string">'Usage: whatever([int], boolean)'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />// The Java version:<br />public class someClass {<br />&nbsp; &nbsp; public boolean whatever(boolean arg1) {<br />&nbsp; &nbsp; &nbsp; &nbsp; return arg1;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public int whatever(int arg1, boolean arg2) {<br />&nbsp; &nbsp; &nbsp; &nbsp; return arg1;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public void whatever() {<br />&nbsp; &nbsp; &nbsp; &nbsp; System.out.println("Usage: whatever([int], boolean)");<br />&nbsp; &nbsp; }<br />}</span>
</code></div>
  </div>
 </div>
  <div class="note" id="62288">  <div class="votes">
    <div id="Vu62288">
    <a href="/manual/vote-note.php?id=62288&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd62288">
    <a href="/manual/vote-note.php?id=62288&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V62288" title="50% like this...">
    0
    </div>
  </div>
  <a href="#62288" class="name">
  <strong class="user"><em>Sleepless</em></strong></a><a class="genanchor" href="#62288"> &para;</a><div class="date" title="2006-02-23 11:22"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom62288">
<div class="phpcode"><code><span class="html">
Yet another way of providing support for read-only properties.&nbsp; Any property that has<br />"pri_" as a prefix will NOT be returned, period, any other property will be returned <br />and if it was declared to be "protected" or "private" it will be read-only. (scope dependent of course)<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">__get</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">property_exists</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">,</span><span class="default">$var</span><span class="keyword">) &amp;&amp; (</span><span class="default">strpos</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">,</span><span class="string">"pri_"</span><span class="keyword">) !== </span><span class="default">0</span><span class="keyword">) )<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;{</span><span class="default">$var</span><span class="keyword">};<br />&nbsp; &nbsp; &nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//Do something<br /></span><span class="keyword">}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="80619">  <div class="votes">
    <div id="Vu80619">
    <a href="/manual/vote-note.php?id=80619&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd80619">
    <a href="/manual/vote-note.php?id=80619&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V80619" title="45% like this...">
    -1
    </div>
  </div>
  <a href="#80619" class="name">
  <strong class="user"><em>jj dhoT maturana aht gmail dhot com</em></strong></a><a class="genanchor" href="#80619"> &para;</a><div class="date" title="2008-01-25 04:16"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom80619">
<div class="phpcode"><code><span class="html">
There isn't some way to overload a method when it's called as a reflection method:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">TestClass </span><span class="keyword">{<br />&nbsp; function </span><span class="default">__call</span><span class="keyword">(</span><span class="default">$method</span><span class="keyword">, </span><span class="default">$args</span><span class="keyword">) {<br />&nbsp; &nbsp; echo </span><span class="string">"Method </span><span class="keyword">{</span><span class="default">$method</span><span class="keyword">}</span><span class="string"> called with args: " </span><span class="keyword">. </span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$args</span><span class="keyword">, </span><span class="default">TRUE</span><span class="keyword">);<br />&nbsp; }<br />}<br /><br /></span><span class="default">$class </span><span class="keyword">= new </span><span class="default">ReflectionClass</span><span class="keyword">(</span><span class="string">"TestClass"</span><span class="keyword">);<br /></span><span class="default">$method </span><span class="keyword">= </span><span class="default">$class</span><span class="keyword">-&gt;</span><span class="default">getMethod</span><span class="keyword">(</span><span class="string">"myMehtod"</span><span class="keyword">);<br /><br /></span><span class="comment">//Fatal error:&nbsp; Uncaught exception 'ReflectionException' with message 'Method myMethod' does not exist'<br /><br /></span><span class="default">?&gt;<br /></span><br />Juan.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="97110">  <div class="votes">
    <div id="Vu97110">
    <a href="/manual/vote-note.php?id=97110&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd97110">
    <a href="/manual/vote-note.php?id=97110&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V97110" title="44% like this...">
    -1
    </div>
  </div>
  <a href="#97110" class="name">
  <strong class="user"><em>f4bi0_ at hotmail dot com</em></strong></a><a class="genanchor" href="#97110"> &para;</a><div class="date" title="2010-04-01 01:12"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom97110">
<div class="phpcode"><code><span class="html">
TRICKY CHALLENGE: is there a way to check if $object-&gt;variable exists without automatically triggering the functionality of __get in case the variable doesn't exist?<br /><br />TRADITIONAL WAY:<br /><span class="default">&lt;?php<br /><br />$object </span><span class="keyword">= new </span><span class="default">someClass</span><span class="keyword">(); </span><span class="comment">// imagine someClass uses the Magic Method "__get"<br /><br /></span><span class="keyword">if(</span><span class="default">$object</span><span class="keyword">-&gt;</span><span class="default">variable</span><span class="keyword">){<br /> </span><span class="comment">// do something<br /><br /></span><span class="keyword">} else {<br /><br /> </span><span class="comment">// "__get" has inevitably been triggered :-(<br /><br /></span><span class="keyword">}<br /><br /></span><span class="default">?&gt;<br /></span><br />Ok, above we have the conventional way to check if a variable exists inside the object, the problem is that sometimes we DON'T WANT TO TRIGGER __GET in case the statement returns false!<br /><br />ALTERNATIVE WAY:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">if(</span><span class="default">array_key_exists</span><span class="keyword">( </span><span class="string">'variable'</span><span class="keyword">, </span><span class="default">get_object_vars</span><span class="keyword">(</span><span class="default">$object</span><span class="keyword">) ) ){<br /><br /> </span><span class="comment">// do something<br /><br /></span><span class="keyword">} else {<br /><br /> </span><span class="comment">// "__get" has no idea what is going on, i think it is still asleep :-)<br /><br /></span><span class="keyword">}<br /><br /></span><span class="default">?&gt;<br /></span><br />you can even turn this into a function or something</span>
</code></div>
  </div>
 </div>
  <div class="note" id="82220">  <div class="votes">
    <div id="Vu82220">
    <a href="/manual/vote-note.php?id=82220&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd82220">
    <a href="/manual/vote-note.php?id=82220&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V82220" title="40% like this...">
    -1
    </div>
  </div>
  <a href="#82220" class="name">
  <strong class="user"><em>nospam michael AT netkey DOT at nospam</em></strong></a><a class="genanchor" href="#82220"> &para;</a><div class="date" title="2008-04-01 10:10"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom82220">
<div class="phpcode"><code><span class="html">
you CAN write into ARRAYS by using __set and __get magic functions. <br /><br />as has been mentioned before $obj-&gt;var['key'] = 'test'; does call the __get method of $obj, and there is no way to find out, if the method has been called for setting purposes.<br /><br />the solution is quite simple: use __get to return the array by reference. then you can write into it:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">setter</span><span class="keyword">{<br />&nbsp; private </span><span class="default">$_arr </span><span class="keyword">= array();<br /><br />&nbsp; public function </span><span class="default">__set</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">, </span><span class="default">$value</span><span class="keyword">){<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">_arr</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">] = </span><span class="default">$value</span><span class="keyword">;<br />&nbsp; }<br /><br />&nbsp; public function &amp;</span><span class="default">__get</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">){<br />&nbsp; &nbsp; if (isset(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">_arr</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">])){<br />&nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">_arr</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">];<br />&nbsp; &nbsp; } else return </span><span class="default">null</span><span class="keyword">;<br />&nbsp; }<br /><br />}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="69440">  <div class="votes">
    <div id="Vu69440">
    <a href="/manual/vote-note.php?id=69440&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd69440">
    <a href="/manual/vote-note.php?id=69440&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V69440" title="37% like this...">
    -2
    </div>
  </div>
  <a href="#69440" class="name">
  <strong class="user"><em>MagicalTux at ooKoo dot org</em></strong></a><a class="genanchor" href="#69440"> &para;</a><div class="date" title="2006-09-06 02:35"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom69440">
<div class="phpcode"><code><span class="html">
Since many here probably wanted to do «real» overloading without having to think too much, here's a generic __call() function for those cases.<br /><br />Little example :<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">OverloadedClass </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; public function </span><span class="default">__call</span><span class="keyword">(</span><span class="default">$f</span><span class="keyword">, </span><span class="default">$p</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">method_exists</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">, </span><span class="default">$f</span><span class="keyword">.</span><span class="default">sizeof</span><span class="keyword">(</span><span class="default">$p</span><span class="keyword">))) return </span><span class="default">call_user_func_array</span><span class="keyword">(array(</span><span class="default">$this</span><span class="keyword">, </span><span class="default">$f</span><span class="keyword">.</span><span class="default">sizeof</span><span class="keyword">(</span><span class="default">$p</span><span class="keyword">)), </span><span class="default">$p</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// function does not exists~<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">throw new </span><span class="default">Exception</span><span class="keyword">(</span><span class="string">'Tried to call unknown method '</span><span class="keyword">.</span><span class="default">get_class</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">).</span><span class="string">'::'</span><span class="keyword">.</span><span class="default">$f</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; function </span><span class="default">Param2</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Param2(</span><span class="default">$a</span><span class="string">,</span><span class="default">$b</span><span class="string">)\n"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; function </span><span class="default">Param3</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">, </span><span class="default">$c</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Param3(</span><span class="default">$a</span><span class="string">,</span><span class="default">$b</span><span class="string">,</span><span class="default">$c</span><span class="string">)\n"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$o </span><span class="keyword">= new </span><span class="default">OverloadedClass</span><span class="keyword">();<br /></span><span class="default">$o</span><span class="keyword">-&gt;</span><span class="default">Param</span><span class="keyword">(</span><span class="default">4</span><span class="keyword">,</span><span class="default">5</span><span class="keyword">);<br /></span><span class="default">$o</span><span class="keyword">-&gt;</span><span class="default">Param</span><span class="keyword">(</span><span class="default">4</span><span class="keyword">,</span><span class="default">5</span><span class="keyword">,</span><span class="default">6</span><span class="keyword">);<br /></span><span class="default">$o</span><span class="keyword">-&gt;</span><span class="default">ParamX</span><span class="keyword">(</span><span class="default">4</span><span class="keyword">,</span><span class="default">5</span><span class="keyword">,</span><span class="default">6</span><span class="keyword">,</span><span class="default">7</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />Will output :<br />Param2(4,5)<br />Param3(4,5,6)<br /><br />Fatal error: Uncaught exception 'Exception' with message 'Tried to call unknown method OverloadedClass::ParamX' in overload.php:7<br />Stack trace:<br />#0 [internal function]: OverloadedClass-&gt;__call('ParamX', Array)<br />#1 overload.php(22): OverloadedClass-&gt;ParamX(4, 5, 6, 7)<br />#2 {main}<br />&nbsp; thrown in overload.php on line 7</span>
</code></div>
  </div>
 </div>
  <div class="note" id="68053">  <div class="votes">
    <div id="Vu68053">
    <a href="/manual/vote-note.php?id=68053&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd68053">
    <a href="/manual/vote-note.php?id=68053&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V68053" title="37% like this...">
    -2
    </div>
  </div>
  <a href="#68053" class="name">
  <strong class="user"><em>mnaul at nonsences dot angelo dot edu</em></strong></a><a class="genanchor" href="#68053"> &para;</a><div class="date" title="2006-07-11 12:58"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom68053">
<div class="phpcode"><code><span class="html">
This is just my contribution. It based off of many diffrent suggestions I've see thought the manual postings.<br />It should fit into any class and create default get and set methods for all you member variables. Hopfuly its usefull.<br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">__call</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">,</span><span class="default">$params</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; if( </span><span class="default">preg_match</span><span class="keyword">(</span><span class="string">'/(set|get)(_)?/'</span><span class="keyword">,</span><span class="default">$name</span><span class="keyword">) )<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">substr</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">,</span><span class="default">0</span><span class="keyword">,</span><span class="default">3</span><span class="keyword">)==</span><span class="string">"set"</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$name </span><span class="keyword">= </span><span class="default">preg_replace</span><span class="keyword">(</span><span class="string">'/set(_)?/'</span><span class="keyword">,</span><span class="string">''</span><span class="keyword">,</span><span class="default">$name</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">property_exists</span><span class="keyword">(</span><span class="default">__class__</span><span class="keyword">,</span><span class="default">$name</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;{</span><span class="default">$name</span><span class="keyword">}=</span><span class="default">array_pop</span><span class="keyword">(</span><span class="default">$params</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">true</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//call to class error handler<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">true</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; elseif(</span><span class="default">substr</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">,</span><span class="default">0</span><span class="keyword">,</span><span class="default">3</span><span class="keyword">)==</span><span class="string">"get"</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$name </span><span class="keyword">= </span><span class="default">preg_replace</span><span class="keyword">(</span><span class="string">'/get(_)?/'</span><span class="keyword">,</span><span class="string">''</span><span class="keyword">,</span><span class="default">$name</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">property_exists</span><span class="keyword">(</span><span class="default">__class__</span><span class="keyword">,</span><span class="default">$name</span><span class="keyword">) )<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;{</span><span class="default">$name</span><span class="keyword">};<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//call to class error handler<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//call to class error handler<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; die(</span><span class="string">"method </span><span class="default">$name</span><span class="string"> dose not exist\n"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp; }</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="77508">  <div class="votes">
    <div id="Vu77508">
    <a href="/manual/vote-note.php?id=77508&amp;page=language.oop5.overloading&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd77508">
    <a href="/manual/vote-note.php?id=77508&amp;page=language.oop5.overloading&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V77508" title="33% like this...">
    -3
    </div>
  </div>
  <a href="#77508" class="name">
  <strong class="user"><em>ac221 at sussex dot ac dot uk</em></strong></a><a class="genanchor" href="#77508"> &para;</a><div class="date" title="2007-09-01 10:07"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom77508">
<div class="phpcode"><code><span class="html">
Just Noting the interesting behavior of __set __get , when modifying objects contained in overloaded properties.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">foo </span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$propObj</span><span class="keyword">;<br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">(){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$propObj </span><span class="keyword">= new </span><span class="default">stdClass</span><span class="keyword">();<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public function </span><span class="default">__get</span><span class="keyword">(</span><span class="default">$prop</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; echo(</span><span class="string">"I'm Being Got ! \n"</span><span class="keyword">); <br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">propObj</span><span class="keyword">-&gt;</span><span class="default">$prop</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public function </span><span class="default">__set</span><span class="keyword">(</span><span class="default">$prop</span><span class="keyword">,</span><span class="default">$val</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; echo(</span><span class="string">"I'm Being Set ! \n"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">propObj</span><span class="keyword">-&gt;</span><span class="default">$prop </span><span class="keyword">= </span><span class="default">$val</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">$test </span><span class="keyword">= new </span><span class="default">foo</span><span class="keyword">();<br /></span><span class="default">$test</span><span class="keyword">-&gt;</span><span class="default">barProp </span><span class="keyword">= new </span><span class="default">stdClass</span><span class="keyword">(); </span><span class="comment">// I should invoke set<br /></span><span class="default">$test</span><span class="keyword">-&gt;</span><span class="default">barProp</span><span class="keyword">-&gt;</span><span class="default">barSubProp </span><span class="keyword">= </span><span class="string">'As Should I'</span><span class="keyword">;<br /></span><span class="default">$test</span><span class="keyword">-&gt;</span><span class="default">barProp</span><span class="keyword">-&gt;</span><span class="default">barSubProp </span><span class="keyword">= </span><span class="string">'As Should I'</span><span class="keyword">;<br /></span><span class="default">$test</span><span class="keyword">-&gt;</span><span class="default">barProp </span><span class="keyword">= new </span><span class="default">stdClass</span><span class="keyword">(); </span><span class="comment">// As should i<br /></span><span class="default">?&gt;<br /></span><br />Outputs:<br /><br />I'm Being Set !<br />I'm Being Got !<br />I'm Being Got !<br />I'm Being Set !<br /><br />Whats happening, is PHP is acquiring a reference to the object, triggering __get; Then applying the changes to the object via the reference.<br /><br />Which is the correct behaviour; objects being special creatures, with an aversion to being cloned...<br /><br />Unfortunately this will never invoke the __set handler, even though it is modifying a property within 'foo', which is slightly annoying if you wanted to keep track of changes to an objects overloaded properties.<br /><br />I guess Journaled Objects will have to wait till PHP 6 :)</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.oop5.overloading&amp;redirect=http://php.net/manual/en/language.oop5.overloading.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.oop5.php">Classes and Objects</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="oop5.intro.php" title="Introduction">Introduction</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.basic.php" title="The Basics">The Basics</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.properties.php" title="Properties">Properties</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.constants.php" title="Class Constants">Class Constants</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.autoload.php" title="Autoloading Classes">Autoloading Classes</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.decon.php" title="Constructors and Destructors">Constructors and Destructors</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.visibility.php" title="Visibility">Visibility</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.inheritance.php" title="Object Inheritance">Object Inheritance</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.paamayim-nekudotayim.php" title="Scope Resolution Operator (::)">Scope Resolution Operator (::)</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.static.php" title="Static Keyword">Static Keyword</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.abstract.php" title="Class Abstraction">Class Abstraction</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.interfaces.php" title="Object Interfaces">Object Interfaces</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.traits.php" title="Traits">Traits</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.anonymous.php" title="Anonymous classes">Anonymous classes</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.oop5.overloading.php" title="Overloading">Overloading</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.iterations.php" title="Object Iteration">Object Iteration</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.magic.php" title="Magic Methods">Magic Methods</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.final.php" title="Final Keyword">Final Keyword</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.cloning.php" title="Object Cloning">Object Cloning</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.object-comparison.php" title="Comparing Objects">Comparing Objects</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.typehinting.php" title="Type Hinting">Type Hinting</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.late-static-bindings.php" title="Late Static Bindings">Late Static Bindings</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.references.php" title="Objects and references">Objects and references</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.serialization.php" title="Object Serialization">Object Serialization</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.changelog.php" title="OOP Changelog">OOP Changelog</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

