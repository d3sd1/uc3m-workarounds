<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Defining multiple namespaces in the same file - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.namespaces.definitionmultiple.php">
 <link rel="shorturl" href="http://php.net/namespaces.definitionmultiple">
 <link rel="alternate" href="http://php.net/namespaces.definitionmultiple" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.namespaces.php">
 <link rel="prev" href="http://php.net/manual/en/language.namespaces.nested.php">
 <link rel="next" href="http://php.net/manual/en/language.namespaces.basics.php">

 <link rel="alternate" href="http://php.net/manual/en/language.namespaces.definitionmultiple.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.namespaces.definitionmultiple.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.namespaces.definitionmultiple.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.namespaces.definitionmultiple.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.namespaces.definitionmultiple.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.namespaces.definitionmultiple.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.namespaces.definitionmultiple.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.namespaces.definitionmultiple.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.namespaces.definitionmultiple.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.namespaces.definitionmultiple.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.namespaces.definitionmultiple.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.namespaces.basics.php">
          Using namespaces: Basics &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.namespaces.nested.php">
          &laquo; Declaring sub-namespaces        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.namespaces.php'>Namespaces</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.namespaces.definitionmultiple.php' selected="selected">English</option>
            <option value='pt_BR/language.namespaces.definitionmultiple.php'>Brazilian Portuguese</option>
            <option value='zh/language.namespaces.definitionmultiple.php'>Chinese (Simplified)</option>
            <option value='fr/language.namespaces.definitionmultiple.php'>French</option>
            <option value='de/language.namespaces.definitionmultiple.php'>German</option>
            <option value='ja/language.namespaces.definitionmultiple.php'>Japanese</option>
            <option value='ro/language.namespaces.definitionmultiple.php'>Romanian</option>
            <option value='ru/language.namespaces.definitionmultiple.php'>Russian</option>
            <option value='es/language.namespaces.definitionmultiple.php'>Spanish</option>
            <option value='tr/language.namespaces.definitionmultiple.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.namespaces.definitionmultiple.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.namespaces.definitionmultiple">Report a Bug</a>
    </div>
  </div><div id="language.namespaces.definitionmultiple" class="sect1">
  <h2 class="title">Defining multiple namespaces in the same file</h2>
  <p class="verinfo">(PHP 5 &gt;= 5.3.0, PHP 7)</p>
  <p class="para">
   Multiple namespaces may also be declared in the same file.  There are two allowed
   syntaxes.
  </p>
  <p class="para">
   <div class="example" id="example-246">
    <p><strong>Example #1 Declaring multiple namespaces, simple combination syntax</strong></p>
    <div class="example-contents">
     <div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">namespace&nbsp;</span><span style="color: #0000BB">MyProject</span><span style="color: #007700">;<br /><br />const&nbsp;</span><span style="color: #0000BB">CONNECT_OK&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">;<br />class&nbsp;</span><span style="color: #0000BB">Connection&nbsp;</span><span style="color: #007700">{&nbsp;</span><span style="color: #FF8000">/*&nbsp;...&nbsp;*/&nbsp;</span><span style="color: #007700">}<br />function&nbsp;</span><span style="color: #0000BB">connect</span><span style="color: #007700">()&nbsp;{&nbsp;</span><span style="color: #FF8000">/*&nbsp;...&nbsp;*/&nbsp;&nbsp;</span><span style="color: #007700">}<br /><br />namespace&nbsp;</span><span style="color: #0000BB">AnotherProject</span><span style="color: #007700">;<br /><br />const&nbsp;</span><span style="color: #0000BB">CONNECT_OK&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">;<br />class&nbsp;</span><span style="color: #0000BB">Connection&nbsp;</span><span style="color: #007700">{&nbsp;</span><span style="color: #FF8000">/*&nbsp;...&nbsp;*/&nbsp;</span><span style="color: #007700">}<br />function&nbsp;</span><span style="color: #0000BB">connect</span><span style="color: #007700">()&nbsp;{&nbsp;</span><span style="color: #FF8000">/*&nbsp;...&nbsp;*/&nbsp;&nbsp;</span><span style="color: #007700">}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
  </p>
  <p class="para">
   This syntax is not recommended for combining namespaces into a single file.
   Instead it is recommended to use the alternate bracketed syntax.
  </p>
  <p class="para">
   <div class="example" id="example-247">
    <p><strong>Example #2 Declaring multiple namespaces, bracketed syntax</strong></p>
    <div class="example-contents">
     <div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">namespace&nbsp;</span><span style="color: #0000BB">MyProject&nbsp;</span><span style="color: #007700">{<br /><br />const&nbsp;</span><span style="color: #0000BB">CONNECT_OK&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">;<br />class&nbsp;</span><span style="color: #0000BB">Connection&nbsp;</span><span style="color: #007700">{&nbsp;</span><span style="color: #FF8000">/*&nbsp;...&nbsp;*/&nbsp;</span><span style="color: #007700">}<br />function&nbsp;</span><span style="color: #0000BB">connect</span><span style="color: #007700">()&nbsp;{&nbsp;</span><span style="color: #FF8000">/*&nbsp;...&nbsp;*/&nbsp;&nbsp;</span><span style="color: #007700">}<br />}<br /><br />namespace&nbsp;</span><span style="color: #0000BB">AnotherProject&nbsp;</span><span style="color: #007700">{<br /><br />const&nbsp;</span><span style="color: #0000BB">CONNECT_OK&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">;<br />class&nbsp;</span><span style="color: #0000BB">Connection&nbsp;</span><span style="color: #007700">{&nbsp;</span><span style="color: #FF8000">/*&nbsp;...&nbsp;*/&nbsp;</span><span style="color: #007700">}<br />function&nbsp;</span><span style="color: #0000BB">connect</span><span style="color: #007700">()&nbsp;{&nbsp;</span><span style="color: #FF8000">/*&nbsp;...&nbsp;*/&nbsp;&nbsp;</span><span style="color: #007700">}<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
  </p>
  <p class="para">
   It is strongly discouraged as a coding practice to combine multiple namespaces into
   the same file.  The primary use case is to combine multiple PHP scripts into the same
   file.
  </p>
  <p class="para">
   To combine global non-namespaced code with namespaced code, only bracketed syntax is
   supported.  Global code should be
   encased in a namespace statement with no namespace name as in:
   <div class="example" id="example-248">
    <p><strong>Example #3 Declaring multiple namespaces and unnamespaced code</strong></p>
    <div class="example-contents">
     <div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">namespace&nbsp;</span><span style="color: #0000BB">MyProject&nbsp;</span><span style="color: #007700">{<br /><br />const&nbsp;</span><span style="color: #0000BB">CONNECT_OK&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">;<br />class&nbsp;</span><span style="color: #0000BB">Connection&nbsp;</span><span style="color: #007700">{&nbsp;</span><span style="color: #FF8000">/*&nbsp;...&nbsp;*/&nbsp;</span><span style="color: #007700">}<br />function&nbsp;</span><span style="color: #0000BB">connect</span><span style="color: #007700">()&nbsp;{&nbsp;</span><span style="color: #FF8000">/*&nbsp;...&nbsp;*/&nbsp;&nbsp;</span><span style="color: #007700">}<br />}<br /><br />namespace&nbsp;{&nbsp;</span><span style="color: #FF8000">//&nbsp;global&nbsp;code<br /></span><span style="color: #0000BB">session_start</span><span style="color: #007700">();<br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">MyProject</span><span style="color: #007700">\</span><span style="color: #0000BB">connect</span><span style="color: #007700">();<br />echo&nbsp;</span><span style="color: #0000BB">MyProject</span><span style="color: #007700">\</span><span style="color: #0000BB">Connection</span><span style="color: #007700">::</span><span style="color: #0000BB">start</span><span style="color: #007700">();<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
  </p>
  <p class="para">
   No PHP code may exist outside of the namespace brackets except for an opening
   declare statement.
   <div class="example" id="example-249">
    <p><strong>Example #4 Declaring multiple namespaces and unnamespaced code</strong></p>
    <div class="example-contents">
     <div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">declare(</span><span style="color: #0000BB">encoding</span><span style="color: #007700">=</span><span style="color: #DD0000">'UTF-8'</span><span style="color: #007700">);<br />namespace&nbsp;</span><span style="color: #0000BB">MyProject&nbsp;</span><span style="color: #007700">{<br /><br />const&nbsp;</span><span style="color: #0000BB">CONNECT_OK&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">;<br />class&nbsp;</span><span style="color: #0000BB">Connection&nbsp;</span><span style="color: #007700">{&nbsp;</span><span style="color: #FF8000">/*&nbsp;...&nbsp;*/&nbsp;</span><span style="color: #007700">}<br />function&nbsp;</span><span style="color: #0000BB">connect</span><span style="color: #007700">()&nbsp;{&nbsp;</span><span style="color: #FF8000">/*&nbsp;...&nbsp;*/&nbsp;&nbsp;</span><span style="color: #007700">}<br />}<br /><br />namespace&nbsp;{&nbsp;</span><span style="color: #FF8000">//&nbsp;global&nbsp;code<br /></span><span style="color: #0000BB">session_start</span><span style="color: #007700">();<br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">MyProject</span><span style="color: #007700">\</span><span style="color: #0000BB">connect</span><span style="color: #007700">();<br />echo&nbsp;</span><span style="color: #0000BB">MyProject</span><span style="color: #007700">\</span><span style="color: #0000BB">Connection</span><span style="color: #007700">::</span><span style="color: #0000BB">start</span><span style="color: #007700">();<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
  </p>
 </div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.namespaces.definitionmultiple&amp;redirect=http://php.net/manual/en/language.namespaces.definitionmultiple.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">10 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="112865">  <div class="votes">
    <div id="Vu112865">
    <a href="/manual/vote-note.php?id=112865&amp;page=language.namespaces.definitionmultiple&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd112865">
    <a href="/manual/vote-note.php?id=112865&amp;page=language.namespaces.definitionmultiple&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V112865" title="77% like this...">
    41
    </div>
  </div>
  <a href="#112865" class="name">
  <strong class="user"><em>leaksin [ at ] gmail [ dot ] com</em></strong></a><a class="genanchor" href="#112865"> &para;</a><div class="date" title="2013-07-30 10:04"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom112865">
<div class="phpcode"><code><span class="html">
using of global namespaces and multiple namespaces in one PHP file increase the complexity and decrease readability of the code.<br />Let's try not use this scheme even it's very necessary (although there is not)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117524">  <div class="votes">
    <div id="Vu117524">
    <a href="/manual/vote-note.php?id=117524&amp;page=language.namespaces.definitionmultiple&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117524">
    <a href="/manual/vote-note.php?id=117524&amp;page=language.namespaces.definitionmultiple&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117524" title="79% like this...">
    14
    </div>
  </div>
  <a href="#117524" class="name">
  <strong class="user"><em>jigar dot vy at gmail dot com</em></strong></a><a class="genanchor" href="#117524"> &para;</a><div class="date" title="2015-06-24 12:52"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117524">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br /><br /></span><span class="comment">// You cannot mix bracketed namespace declarations with unbracketed namespace declarations - will result in a Fatal error<br /><br /></span><span class="keyword">namespace </span><span class="default">a</span><span class="keyword">;<br /><br />echo </span><span class="string">"I belong to namespace a"</span><span class="keyword">;<br /><br />namespace </span><span class="default">b </span><span class="keyword">{<br />&nbsp; &nbsp; echo </span><span class="string">"I'm from namespace b"</span><span class="keyword">;<br />}</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116739">  <div class="votes">
    <div id="Vu116739">
    <a href="/manual/vote-note.php?id=116739&amp;page=language.namespaces.definitionmultiple&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116739">
    <a href="/manual/vote-note.php?id=116739&amp;page=language.namespaces.definitionmultiple&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116739" title="76% like this...">
    13
    </div>
  </div>
  <a href="#116739" class="name">
  <strong class="user"><em>Rahul Sonar</em></strong></a><a class="genanchor" href="#116739"> &para;</a><div class="date" title="2015-02-21 09:43"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom116739">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br /></span><span class="comment">//Namespace can be used in this way also<br /></span><span class="keyword">namespace </span><span class="default">MyProject </span><span class="keyword">{<br /><br />function </span><span class="default">connect</span><span class="keyword">() { echo </span><span class="string">"ONE"</span><span class="keyword">;&nbsp; }<br />&nbsp; &nbsp; </span><span class="default">Sub</span><span class="keyword">\</span><span class="default">Level</span><span class="keyword">\</span><span class="default">connect</span><span class="keyword">();<br />}<br /><br />namespace </span><span class="default">MyProject</span><span class="keyword">\</span><span class="default">Sub </span><span class="keyword">{<br />&nbsp; &nbsp; <br />function </span><span class="default">connect</span><span class="keyword">() { echo </span><span class="string">"TWO"</span><span class="keyword">;&nbsp; }<br />&nbsp; &nbsp; </span><span class="default">Level</span><span class="keyword">\</span><span class="default">connect</span><span class="keyword">();<br />}<br /><br />namespace </span><span class="default">MyProject</span><span class="keyword">\</span><span class="default">Sub</span><span class="keyword">\</span><span class="default">Level </span><span class="keyword">{<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">connect</span><span class="keyword">() { echo </span><span class="string">"THREE"</span><span class="keyword">;&nbsp; }&nbsp; &nbsp; <br />&nbsp; &nbsp; \</span><span class="default">MyProject</span><span class="keyword">\</span><span class="default">Sub</span><span class="keyword">\</span><span class="default">Level</span><span class="keyword">\</span><span class="default">connect</span><span class="keyword">(); </span><span class="comment">// OR we can use this as below<br />&nbsp; &nbsp; </span><span class="default">connect</span><span class="keyword">();<br />}</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117533">  <div class="votes">
    <div id="Vu117533">
    <a href="/manual/vote-note.php?id=117533&amp;page=language.namespaces.definitionmultiple&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117533">
    <a href="/manual/vote-note.php?id=117533&amp;page=language.namespaces.definitionmultiple&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117533" title="76% like this...">
    7
    </div>
  </div>
  <a href="#117533" class="name">
  <strong class="user"><em>Ishan Fernando</em></strong></a><a class="genanchor" href="#117533"> &para;</a><div class="date" title="2015-06-25 07:15"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117533">
<div class="phpcode"><code><span class="html">
//call same named function using namespace<br /><br />//food.php<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">namespace </span><span class="default">Food</span><span class="keyword">;<br /><br />require (</span><span class="string">'Apple.php'</span><span class="keyword">);<br />require(</span><span class="string">'Orange.php'</span><span class="keyword">);<br /><br />use </span><span class="default">Apples</span><span class="keyword">;<br />use </span><span class="default">Oranges</span><span class="keyword">;<br /><br />&nbsp; </span><span class="default">Apples</span><span class="keyword">\</span><span class="default">eat</span><span class="keyword">();<br />&nbsp; </span><span class="default">Oranges</span><span class="keyword">\</span><span class="default">eat</span><span class="keyword">();<br /> </span><span class="default">?&gt;<br /></span><br />//Apple.php<br /><span class="default">&lt;?php<br /></span><span class="keyword">namespace </span><span class="default">Apples</span><span class="keyword">;<br /><br />function </span><span class="default">eat</span><span class="keyword">()<br />{<br />&nbsp; echo </span><span class="string">"eat apple"</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />//Orange.php<br /><span class="default">&lt;?php<br /></span><span class="keyword">namespace </span><span class="default">Oranges</span><span class="keyword">;<br /><br />function </span><span class="default">eat</span><span class="keyword">()<br />{<br />&nbsp; echo </span><span class="string">"eat Orange"</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119943">  <div class="votes">
    <div id="Vu119943">
    <a href="/manual/vote-note.php?id=119943&amp;page=language.namespaces.definitionmultiple&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119943">
    <a href="/manual/vote-note.php?id=119943&amp;page=language.namespaces.definitionmultiple&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119943" title="71% like this...">
    3
    </div>
  </div>
  <a href="#119943" class="name">
  <strong class="user"><em>dominic_mayers at yahoo dot com</em></strong></a><a class="genanchor" href="#119943"> &para;</a><div class="date" title="2016-09-24 02:33"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119943">
<div class="phpcode"><code><span class="html">
If you have the habit to always use the closing PHP tag "?&gt;" in your test files, remember that with the bracketed syntax code outside the brackets, including new lines outside the PHP tags,&nbsp; is not allowed.&nbsp; In particular, even though PHP sees a new line after the closing tag&nbsp; as a part of the line and eats it, some editors, such as&nbsp; Gedit, Gvim, Vim and Nano in Ubuntu,&nbsp; will&nbsp; add yet another new line after this new line and this will create an error.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118962">  <div class="votes">
    <div id="Vu118962">
    <a href="/manual/vote-note.php?id=118962&amp;page=language.namespaces.definitionmultiple&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118962">
    <a href="/manual/vote-note.php?id=118962&amp;page=language.namespaces.definitionmultiple&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118962" title="66% like this...">
    2
    </div>
  </div>
  <a href="#118962" class="name">
  <strong class="user"><em>maycon dot rodrigues1 at gmail dot com</em></strong></a><a class="genanchor" href="#118962"> &para;</a><div class="date" title="2016-03-08 02:18"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom118962">
<div class="phpcode"><code><span class="html">
Notice it's not allowed to mix bracketed namespace with unbracketed namespace declarations.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">namespace </span><span class="default">MyTest</span><span class="keyword">;<br /><br />const </span><span class="default">TEST </span><span class="keyword">= </span><span class="default">777</span><span class="keyword">;<br /><br /></span><span class="comment">//in this way<br /></span><span class="keyword">echo \</span><span class="default">MyTest</span><span class="keyword">\</span><span class="default">TEST </span><span class="keyword">. </span><span class="string">'&lt;br /&gt;'</span><span class="keyword">;<br /><br /></span><span class="comment">//Or this way<br /></span><span class="keyword">echo </span><span class="default">TEST </span><span class="keyword">. </span><span class="string">'&lt;br /&gt;'</span><span class="keyword">;<br /><br />namespace </span><span class="default">AnotherTest </span><span class="keyword">{<br /><br />const </span><span class="default">TEST </span><span class="keyword">= </span><span class="default">555</span><span class="keyword">;<br /><br />echo \</span><span class="default">AnotherTest</span><span class="keyword">\</span><span class="default">TEST </span><span class="keyword">. </span><span class="string">'&lt;br /&gt;'</span><span class="keyword">;<br />echo \</span><span class="default">MyTest</span><span class="keyword">\</span><span class="default">TEST</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />This code will issue a fatal error, like this: Fatal error: Cannot mix bracketed namespace declarations with unbracketed namespace declarations in C:\xampp\htdocs\teste2.php on line 11.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121225">  <div class="votes">
    <div id="Vu121225">
    <a href="/manual/vote-note.php?id=121225&amp;page=language.namespaces.definitionmultiple&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121225">
    <a href="/manual/vote-note.php?id=121225&amp;page=language.namespaces.definitionmultiple&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121225" title="no votes...">
    0
    </div>
  </div>
  <a href="#121225" class="name">
  <strong class="user"><em>dauser at daexample dot com</em></strong></a><a class="genanchor" href="#121225"> &para;</a><div class="date" title="2017-06-14 11:18"><strong>5 months ago</strong></div>
  <div class="text" id="Hcom121225">
<div class="phpcode"><code><span class="html">
There are rational examples of where the ability to blend multiple namespaces into a single file is not only desirable but also absolutely necessary.&nbsp; An example of where this ability is useful is over in the very popular phpseclib library where they are PSR-4 compliant but, in order to be compliant, they have to read a directory of files to know what classes are available so that the autoloader can load the correct files.&nbsp; If they, instead, just bundled the defaults into one file using this mechanism already supported by PHP core, there would be no need to do extraneous scanning of the file system.<br /><br />That's just one legitimate use-case where strict compliance with PSRs gets in the way of good software development.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119676">  <div class="votes">
    <div id="Vu119676">
    <a href="/manual/vote-note.php?id=119676&amp;page=language.namespaces.definitionmultiple&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119676">
    <a href="/manual/vote-note.php?id=119676&amp;page=language.namespaces.definitionmultiple&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119676" title="50% like this...">
    0
    </div>
  </div>
  <a href="#119676" class="name">
  <strong class="user"><em>martin_winkel at hotmail dot com</em></strong></a><a class="genanchor" href="#119676"> &para;</a><div class="date" title="2016-08-01 08:03"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119676">
<div class="phpcode"><code><span class="html">
In addition to&nbsp; kothnok at gmail dot com<br /><br />When using namespaces with brackets, you should define the USE statements within the brackets. His example sets the global use for the file.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">namespace </span><span class="default">Space1</span><span class="keyword">;<br />use </span><span class="default">SomeNamespace</span><span class="keyword">\</span><span class="default">FunctionCollection </span><span class="keyword">as </span><span class="default">FC</span><span class="keyword">;<br />{<br />&nbsp; &nbsp;&nbsp; </span><span class="default">FC</span><span class="keyword">\</span><span class="default">hello_world</span><span class="keyword">();<br />}<br /><br />namespace </span><span class="default">Space2</span><span class="keyword">;<br />{<br />&nbsp; &nbsp;&nbsp; </span><span class="comment">// This can be used here<br />&nbsp; &nbsp;&nbsp; </span><span class="default">FC</span><span class="keyword">\</span><span class="default">hello_world</span><span class="keyword">();<br />}<br /></span><span class="default">?&gt;<br /></span><br />While the preferred method with brackets is this:<br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">namespace </span><span class="default">Space1<br /></span><span class="keyword">{<br />&nbsp; &nbsp;&nbsp; use </span><span class="default">SomeNamespace</span><span class="keyword">\</span><span class="default">FunctionCollection </span><span class="keyword">as </span><span class="default">FC</span><span class="keyword">;<br />&nbsp; &nbsp;&nbsp; </span><span class="default">FC</span><span class="keyword">\</span><span class="default">hello_world</span><span class="keyword">();<br />}<br /><br />namespace </span><span class="default">Space2</span><span class="keyword">;<br />{<br />&nbsp; &nbsp;&nbsp; </span><span class="comment">// This will not work now<br />&nbsp; &nbsp;&nbsp; </span><span class="default">FC</span><span class="keyword">\</span><span class="default">hello_world</span><span class="keyword">();<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117187">  <div class="votes">
    <div id="Vu117187">
    <a href="/manual/vote-note.php?id=117187&amp;page=language.namespaces.definitionmultiple&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117187">
    <a href="/manual/vote-note.php?id=117187&amp;page=language.namespaces.definitionmultiple&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117187" title="46% like this...">
    -1
    </div>
  </div>
  <a href="#117187" class="name">
  <strong class="user"><em>Luis Pessoa</em></strong></a><a class="genanchor" href="#117187"> &para;</a><div class="date" title="2015-04-28 05:30"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117187">
<div class="phpcode"><code><span class="html">
Be careful with include combined to namespaces:<br /><br />file b.php<br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">const </span><span class="default">WHERE_I_AM </span><span class="keyword">= </span><span class="string">'I am in B'</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">i_am_in</span><span class="keyword">() { <br />&nbsp; &nbsp; &nbsp; &nbsp; \</span><span class="default">A</span><span class="keyword">\</span><span class="default">cr_echo</span><span class="keyword">(</span><span class="default">WHERE_I_AM</span><span class="keyword">);<br />&nbsp; &nbsp; }<br /></span><span class="default">?&gt;<br /></span><br />file c.php<br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">namespace </span><span class="default">C </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; const </span><span class="default">WHERE_I_AM </span><span class="keyword">= </span><span class="string">'I am in C'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; function </span><span class="default">i_am_in</span><span class="keyword">() { <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; \</span><span class="default">A</span><span class="keyword">\</span><span class="default">cr_echo</span><span class="keyword">(</span><span class="default">WHERE_I_AM</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /></span><span class="default">?&gt;<br /></span><br />main file<br /><br /><span class="default">&lt;?php<br />&nbsp;&nbsp; <br />&nbsp; &nbsp; </span><span class="keyword">namespace </span><span class="default">A </span><span class="keyword">{<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; const </span><span class="default">CR </span><span class="keyword">= </span><span class="string">"\r\n"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; const </span><span class="default">WHERE_I_AM </span><span class="keyword">= </span><span class="string">'I am in A'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; function </span><span class="default">cr_echo</span><span class="keyword">(</span><span class="default">$msg</span><span class="keyword">) { <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">$msg </span><span class="keyword">. </span><span class="default">CR</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; function </span><span class="default">i_am_in</span><span class="keyword">() { <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">cr_echo</span><span class="keyword">(</span><span class="default">WHERE_I_AM</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; namespace </span><span class="default">B </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; require </span><span class="string">'b.php'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; namespace {<br />&nbsp; &nbsp; &nbsp; &nbsp; require </span><span class="string">'c.php'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; \</span><span class="default">A</span><span class="keyword">\</span><span class="default">i_am_in</span><span class="keyword">(); </span><span class="comment">//ok<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">\</span><span class="default">B</span><span class="keyword">\</span><span class="default">i_am_in</span><span class="keyword">(); </span><span class="comment">// fatal-error<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">\</span><span class="default">C</span><span class="keyword">\</span><span class="default">i_am_in</span><span class="keyword">(); </span><span class="comment">//ok<br />&nbsp; &nbsp; </span><span class="keyword">}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119924">  <div class="votes">
    <div id="Vu119924">
    <a href="/manual/vote-note.php?id=119924&amp;page=language.namespaces.definitionmultiple&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119924">
    <a href="/manual/vote-note.php?id=119924&amp;page=language.namespaces.definitionmultiple&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119924" title="16% like this...">
    -4
    </div>
  </div>
  <a href="#119924" class="name">
  <strong class="user"><em>dominic_mayers at yahoo dot com</em></strong></a><a class="genanchor" href="#119924"> &para;</a><div class="date" title="2016-09-20 05:26"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119924">
<div class="phpcode"><code><span class="html">
With the bracketed syntax, a simple white space after the closing "?&gt;" of the file, even a new line that is some times&nbsp; considered as the end of a line and thus a part of the line, will (at the least in some php installations) be considered as code outside the brackets and will result in an error. It's general good practice to avoid white space after the closing "?&gt;". Just pointing out that it is another case where it matters.</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.namespaces.definitionmultiple&amp;redirect=http://php.net/manual/en/language.namespaces.definitionmultiple.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.namespaces.php">Namespaces</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.namespaces.rationale.php" title="Namespaces overview">Namespaces overview</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.definition.php" title="Defining namespaces">Defining namespaces</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.nested.php" title="Declaring sub-&#8203;namespaces">Declaring sub-&#8203;namespaces</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.namespaces.definitionmultiple.php" title="Defining multiple namespaces in the same file">Defining multiple namespaces in the same file</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.basics.php" title="Using namespaces: Basics">Using namespaces: Basics</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.dynamic.php" title="Namespaces and dynamic language features">Namespaces and dynamic language features</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.nsconstants.php" title="namespace keyword and _&#8203;_&#8203;NAMESPACE_&#8203;_&#8203; constant">namespace keyword and _&#8203;_&#8203;NAMESPACE_&#8203;_&#8203; constant</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.importing.php" title="Using namespaces: Aliasing/Importing">Using namespaces: Aliasing/Importing</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.global.php" title="Global space">Global space</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.fallback.php" title="Using namespaces: fallback to global function/constant">Using namespaces: fallback to global function/constant</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.rules.php" title="Name resolution rules">Name resolution rules</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.faq.php" title="FAQ: things you need to know about namespaces">FAQ: things you need to know about namespaces</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

