<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Using namespaces: Basics - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.namespaces.basics.php">
 <link rel="shorturl" href="http://php.net/namespaces.basics">
 <link rel="alternate" href="http://php.net/namespaces.basics" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.namespaces.php">
 <link rel="prev" href="http://php.net/manual/en/language.namespaces.definitionmultiple.php">
 <link rel="next" href="http://php.net/manual/en/language.namespaces.dynamic.php">

 <link rel="alternate" href="http://php.net/manual/en/language.namespaces.basics.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.namespaces.basics.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.namespaces.basics.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.namespaces.basics.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.namespaces.basics.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.namespaces.basics.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.namespaces.basics.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.namespaces.basics.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.namespaces.basics.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.namespaces.basics.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.namespaces.basics.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.namespaces.dynamic.php">
          Namespaces and dynamic language features &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.namespaces.definitionmultiple.php">
          &laquo; Defining multiple namespaces in the same file        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.namespaces.php'>Namespaces</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.namespaces.basics.php' selected="selected">English</option>
            <option value='pt_BR/language.namespaces.basics.php'>Brazilian Portuguese</option>
            <option value='zh/language.namespaces.basics.php'>Chinese (Simplified)</option>
            <option value='fr/language.namespaces.basics.php'>French</option>
            <option value='de/language.namespaces.basics.php'>German</option>
            <option value='ja/language.namespaces.basics.php'>Japanese</option>
            <option value='ro/language.namespaces.basics.php'>Romanian</option>
            <option value='ru/language.namespaces.basics.php'>Russian</option>
            <option value='es/language.namespaces.basics.php'>Spanish</option>
            <option value='tr/language.namespaces.basics.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.namespaces.basics.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.namespaces.basics">Report a Bug</a>
    </div>
  </div><div id="language.namespaces.basics" class="sect1">
  <h2 class="title">Using namespaces: Basics</h2>
  <p class="verinfo">(PHP 5 &gt;= 5.3.0, PHP 7)</p>
  <p class="para">
   Before discussing the use of namespaces, it is important to understand how PHP
   knows which namespaced element your code is requesting.  A simple analogy can be made
   between PHP namespaces and a filesystem.  There are three ways to access a file in a
   file system:
   <ol type="1">
    <li class="listitem">
     <span class="simpara">
      Relative file name like <em>foo.txt</em>.  This resolves to
      <em>currentdirectory/foo.txt</em> where currentdirectory is the
      directory currently occupied.  So if the current directory is
      <em>/home/foo</em>, the name resolves to <em>/home/foo/foo.txt</em>.
     </span>
    </li>
    <li class="listitem">
     <span class="simpara">
      Relative path name like <em>subdirectory/foo.txt</em>.  This resolves
      to <em>currentdirectory/subdirectory/foo.txt</em>.
     </span>
    </li>
    <li class="listitem">
     <span class="simpara">
      Absolute path name like <em>/main/foo.txt</em>.  This resolves
      to <em>/main/foo.txt</em>.
     </span>
    </li>
   </ol>
   The same principle can be applied to namespaced elements in PHP.  For
   example, a class name can be referred to in three ways:
   <ol type="1">
    <li class="listitem">
     <span class="simpara">
      Unqualified name, or an unprefixed class name like
      <em>$a = new foo();</em> or
      <em>foo::staticmethod();</em>.  If the current namespace is
      <em>currentnamespace</em>, this resolves to
      <em>currentnamespace\foo</em>.  If
      the code is global, non-namespaced code, this resolves to <em>foo</em>.
     </span>
     <span class="simpara">
      One caveat: unqualified names for functions and constants will
      resolve to global functions and constants if the namespaced function or constant
      is not defined.  See <a href="language.namespaces.fallback.php" class="link">Using namespaces:
      fallback to global function/constant</a> for details.
     </span>
    </li>
    <li class="listitem">
     <span class="simpara">
      Qualified name, or a prefixed class name like
      <em>$a = new subnamespace\foo();</em> or
      <em>subnamespace\foo::staticmethod();</em>.  If the current namespace is
      <em>currentnamespace</em>, this resolves to
      <em>currentnamespace\subnamespace\foo</em>.  If
      the code is global, non-namespaced code, this resolves to <em>subnamespace\foo</em>.
     </span>
    </li>
    <li class="listitem">
     <span class="simpara">
      Fully qualified name, or a prefixed name with global prefix operator like
      <em>$a = new \currentnamespace\foo();</em> or
      <em>\currentnamespace\foo::staticmethod();</em>.  This always resolves
      to the literal name specified in the code, <em>currentnamespace\foo</em>.
     </span>
    </li>
   </ol>
  </p>
  <p class="para">
   Here is an example of the three kinds of syntax in actual code:
   <div class="informalexample">
    <p class="simpara">file1.php</p>
    <div class="example-contents">
     <div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">namespace&nbsp;</span><span style="color: #0000BB">Foo</span><span style="color: #007700">\</span><span style="color: #0000BB">Bar</span><span style="color: #007700">\</span><span style="color: #0000BB">subnamespace</span><span style="color: #007700">;<br /><br />const&nbsp;</span><span style="color: #0000BB">FOO&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">;<br />function&nbsp;</span><span style="color: #0000BB">foo</span><span style="color: #007700">()&nbsp;{}<br />class&nbsp;</span><span style="color: #0000BB">foo<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;static&nbsp;function&nbsp;</span><span style="color: #0000BB">staticmethod</span><span style="color: #007700">()&nbsp;{}<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

    <p class="simpara">file2.php</p>
    <div class="example-contents">
     <div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">namespace&nbsp;</span><span style="color: #0000BB">Foo</span><span style="color: #007700">\</span><span style="color: #0000BB">Bar</span><span style="color: #007700">;<br />include&nbsp;</span><span style="color: #DD0000">'file1.php'</span><span style="color: #007700">;<br /><br />const&nbsp;</span><span style="color: #0000BB">FOO&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">;<br />function&nbsp;</span><span style="color: #0000BB">foo</span><span style="color: #007700">()&nbsp;{}<br />class&nbsp;</span><span style="color: #0000BB">foo<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;static&nbsp;function&nbsp;</span><span style="color: #0000BB">staticmethod</span><span style="color: #007700">()&nbsp;{}<br />}<br /><br /></span><span style="color: #FF8000">/*&nbsp;Unqualified&nbsp;name&nbsp;*/<br /></span><span style="color: #0000BB">foo</span><span style="color: #007700">();&nbsp;</span><span style="color: #FF8000">//&nbsp;resolves&nbsp;to&nbsp;function&nbsp;Foo\Bar\foo<br /></span><span style="color: #0000BB">foo</span><span style="color: #007700">::</span><span style="color: #0000BB">staticmethod</span><span style="color: #007700">();&nbsp;</span><span style="color: #FF8000">//&nbsp;resolves&nbsp;to&nbsp;class&nbsp;Foo\Bar\foo,&nbsp;method&nbsp;staticmethod<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #0000BB">FOO</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;resolves&nbsp;to&nbsp;constant&nbsp;Foo\Bar\FOO<br /><br />/*&nbsp;Qualified&nbsp;name&nbsp;*/<br /></span><span style="color: #0000BB">subnamespace</span><span style="color: #007700">\</span><span style="color: #0000BB">foo</span><span style="color: #007700">();&nbsp;</span><span style="color: #FF8000">//&nbsp;resolves&nbsp;to&nbsp;function&nbsp;Foo\Bar\subnamespace\foo<br /></span><span style="color: #0000BB">subnamespace</span><span style="color: #007700">\</span><span style="color: #0000BB">foo</span><span style="color: #007700">::</span><span style="color: #0000BB">staticmethod</span><span style="color: #007700">();&nbsp;</span><span style="color: #FF8000">//&nbsp;resolves&nbsp;to&nbsp;class&nbsp;Foo\Bar\subnamespace\foo,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;method&nbsp;staticmethod<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #0000BB">subnamespace</span><span style="color: #007700">\</span><span style="color: #0000BB">FOO</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;resolves&nbsp;to&nbsp;constant&nbsp;Foo\Bar\subnamespace\FOO<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br />/*&nbsp;Fully&nbsp;qualified&nbsp;name&nbsp;*/<br /></span><span style="color: #007700">\</span><span style="color: #0000BB">Foo</span><span style="color: #007700">\</span><span style="color: #0000BB">Bar</span><span style="color: #007700">\</span><span style="color: #0000BB">foo</span><span style="color: #007700">();&nbsp;</span><span style="color: #FF8000">//&nbsp;resolves&nbsp;to&nbsp;function&nbsp;Foo\Bar\foo<br /></span><span style="color: #007700">\</span><span style="color: #0000BB">Foo</span><span style="color: #007700">\</span><span style="color: #0000BB">Bar</span><span style="color: #007700">\</span><span style="color: #0000BB">foo</span><span style="color: #007700">::</span><span style="color: #0000BB">staticmethod</span><span style="color: #007700">();&nbsp;</span><span style="color: #FF8000">//&nbsp;resolves&nbsp;to&nbsp;class&nbsp;Foo\Bar\foo,&nbsp;method&nbsp;staticmethod<br /></span><span style="color: #007700">echo&nbsp;\</span><span style="color: #0000BB">Foo</span><span style="color: #007700">\</span><span style="color: #0000BB">Bar</span><span style="color: #007700">\</span><span style="color: #0000BB">FOO</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;resolves&nbsp;to&nbsp;constant&nbsp;Foo\Bar\FOO<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
  </p>
  <p class="para">
   Note that to access any global
   class, function or constant, a fully qualified name can be used, such as
   <span class="function"><strong>\strlen()</strong></span> or <strong class="classname">\Exception</strong> or
   <em>\INI_ALL</em>.
   <div class="example" id="example-250">
    <p><strong>Example #1 Accessing global classes, functions and constants from within a namespace</strong></p>
    <div class="example-contents">
     <div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">namespace&nbsp;</span><span style="color: #0000BB">Foo</span><span style="color: #007700">;<br /><br />function&nbsp;</span><span style="color: #0000BB">strlen</span><span style="color: #007700">()&nbsp;{}<br />const&nbsp;</span><span style="color: #0000BB">INI_ALL&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">3</span><span style="color: #007700">;<br />class&nbsp;</span><span style="color: #0000BB">Exception&nbsp;</span><span style="color: #007700">{}<br /><br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;\</span><span style="color: #0000BB">strlen</span><span style="color: #007700">(</span><span style="color: #DD0000">'hi'</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;calls&nbsp;global&nbsp;function&nbsp;strlen<br /></span><span style="color: #0000BB">$b&nbsp;</span><span style="color: #007700">=&nbsp;\</span><span style="color: #0000BB">INI_ALL</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;accesses&nbsp;global&nbsp;constant&nbsp;INI_ALL<br /></span><span style="color: #0000BB">$c&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;\</span><span style="color: #0000BB">Exception</span><span style="color: #007700">(</span><span style="color: #DD0000">'error'</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;instantiates&nbsp;global&nbsp;class&nbsp;Exception<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
  </p>
 </div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.namespaces.basics&amp;redirect=http://php.net/manual/en/language.namespaces.basics.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">6 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="82088">  <div class="votes">
    <div id="Vu82088">
    <a href="/manual/vote-note.php?id=82088&amp;page=language.namespaces.basics&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd82088">
    <a href="/manual/vote-note.php?id=82088&amp;page=language.namespaces.basics&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V82088" title="81% like this...">
    138
    </div>
  </div>
  <a href="#82088" class="name">
  <strong class="user"><em>richard at richard-sumilang dot com</em></strong></a><a class="genanchor" href="#82088"> &para;</a><div class="date" title="2008-03-27 01:36"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom82088">
<div class="phpcode"><code><span class="html">
Syntax for extending classes in namespaces is still the same.<br /><br />Lets call this Object.php:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">namespace </span><span class="default">com</span><span class="keyword">\</span><span class="default">rsumilang</span><span class="keyword">\</span><span class="default">common</span><span class="keyword">;<br /><br />class </span><span class="default">Object</span><span class="keyword">{<br />&nbsp;&nbsp; </span><span class="comment">// ... code ...<br /></span><span class="keyword">}<br /><br /></span><span class="default">?&gt;<br /></span><br />And now lets create a class called String that extends object in String.php:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">String </span><span class="keyword">extends </span><span class="default">com</span><span class="keyword">\</span><span class="default">rsumilang</span><span class="keyword">\</span><span class="default">common</span><span class="keyword">\</span><span class="default">Object</span><span class="keyword">{<br />&nbsp;&nbsp; </span><span class="comment">// ... code ...<br /></span><span class="keyword">}<br /><br /></span><span class="default">?&gt;<br /></span><br />Now if you class String was defined in the same namespace as Object then you don't have to specify a full namespace path:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">namespace </span><span class="default">com</span><span class="keyword">\</span><span class="default">rsumilang</span><span class="keyword">\</span><span class="default">common</span><span class="keyword">;<br /><br />class </span><span class="default">String </span><span class="keyword">extends </span><span class="default">Object<br /></span><span class="keyword">{<br />&nbsp;&nbsp; </span><span class="comment">// ... code ...<br /></span><span class="keyword">}<br /><br /></span><span class="default">?&gt;<br /></span><br />Lastly, you can also alias a namespace name to use a shorter name for the class you are extending incase your class is in seperate namespace:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">namespace </span><span class="default">com</span><span class="keyword">\</span><span class="default">rsumilang</span><span class="keyword">\</span><span class="default">util</span><span class="keyword">;<br />use </span><span class="default">com</span><span class="keyword">\</span><span class="default">rsumlang</span><span class="keyword">\</span><span class="default">common </span><span class="keyword">as </span><span class="default">Common</span><span class="keyword">;<br /><br />class </span><span class="default">String </span><span class="keyword">extends </span><span class="default">Common</span><span class="keyword">\</span><span class="default">Object<br /></span><span class="keyword">{<br />&nbsp;&nbsp; </span><span class="comment">// ... code ...<br /></span><span class="keyword">}<br /><br /></span><span class="default">?&gt;<br /></span><br />- Richard Sumilang</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116002">  <div class="votes">
    <div id="Vu116002">
    <a href="/manual/vote-note.php?id=116002&amp;page=language.namespaces.basics&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116002">
    <a href="/manual/vote-note.php?id=116002&amp;page=language.namespaces.basics&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116002" title="79% like this...">
    59
    </div>
  </div>
  <a href="#116002" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#116002"> &para;</a><div class="date" title="2014-10-27 01:08"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom116002">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br /><br /></span><span class="keyword">namespace </span><span class="default">Foo</span><span class="keyword">;<br /><br />try {<br />&nbsp; &nbsp; </span><span class="comment">// Something awful here<br />&nbsp; &nbsp; // That will throw a new exception from SPL<br /></span><span class="keyword">} <br />catch (</span><span class="default">Exception </span><span class="keyword">as </span><span class="default">$ex</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="comment">// We will never get here<br />&nbsp; &nbsp; // This is because we are catchin Foo\Exception<br /></span><span class="keyword">}<br /></span><span class="default">?&gt;<br /></span><br />Instead use fully qualified name for the exception to catch it<br /><br /><span class="default">&lt;?php <br /><br /></span><span class="keyword">namespace </span><span class="default">Foo</span><span class="keyword">;<br /><br />try {<br />&nbsp; &nbsp; </span><span class="comment">// something awful here<br />&nbsp; &nbsp; // That will throw a new exception from SPL<br /></span><span class="keyword">} <br />catch (\</span><span class="default">Exception </span><span class="keyword">as </span><span class="default">$ex</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="comment">// Now we can get here at last<br /></span><span class="keyword">}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="106777">  <div class="votes">
    <div id="Vu106777">
    <a href="/manual/vote-note.php?id=106777&amp;page=language.namespaces.basics&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd106777">
    <a href="/manual/vote-note.php?id=106777&amp;page=language.namespaces.basics&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V106777" title="67% like this...">
    23
    </div>
  </div>
  <a href="#106777" class="name">
  <strong class="user"><em>Lukas Z</em></strong></a><a class="genanchor" href="#106777"> &para;</a><div class="date" title="2011-12-05 03:25"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom106777">
<div class="phpcode"><code><span class="html">
Well variables inside namespaces do not override others since variables are never affected by namespace but always global:<br />"Although any valid PHP code can be contained within a namespace, only four types of code are affected by namespaces: classes, interfaces, functions and constants. "<br /><br />Source: "Defining Namespaces"<br /><a href="http://www.php.net/manual/en/language.namespaces.definition.php" rel="nofollow" target="_blank">http://www.php.net/manual/en/language.namespaces.definition.php</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="107684">  <div class="votes">
    <div id="Vu107684">
    <a href="/manual/vote-note.php?id=107684&amp;page=language.namespaces.basics&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd107684">
    <a href="/manual/vote-note.php?id=107684&amp;page=language.namespaces.basics&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V107684" title="61% like this...">
    20
    </div>
  </div>
  <a href="#107684" class="name">
  <strong class="user"><em>tom at tomwardrop dot com</em></strong></a><a class="genanchor" href="#107684"> &para;</a><div class="date" title="2012-02-26 10:06"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom107684">
<div class="phpcode"><code><span class="html">
It seems the file system analogy only goes so far. One thing that's missing that would be very useful is relative navigation up the namespace chain, e.g.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">namespace </span><span class="default">MyProject </span><span class="keyword">{<br />&nbsp;&nbsp; class </span><span class="default">Person </span><span class="keyword">{}<br />}<br /><br />namespace </span><span class="default">MyProject</span><span class="keyword">\</span><span class="default">People </span><span class="keyword">{<br />&nbsp; &nbsp; class </span><span class="default">Adult </span><span class="keyword">extends ..\</span><span class="default">Person </span><span class="keyword">{}<br />}<br /></span><span class="default">?&gt;<br /></span><br />That would be really nice, especially if you had really deep namespaces. It would save you having to type out the full namespace just to reference a resource one level up.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="104411">  <div class="votes">
    <div id="Vu104411">
    <a href="/manual/vote-note.php?id=104411&amp;page=language.namespaces.basics&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd104411">
    <a href="/manual/vote-note.php?id=104411&amp;page=language.namespaces.basics&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V104411" title="54% like this...">
    5
    </div>
  </div>
  <a href="#104411" class="name">
  <strong class="user"><em>philip dot preisser at arcor dot de</em></strong></a><a class="genanchor" href="#104411"> &para;</a><div class="date" title="2011-06-14 02:34"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom104411">
<div class="phpcode"><code><span class="html">
Working with variables can overwrite equal variables in other namespaces<br /><br /><span class="default">&lt;?php </span><span class="comment">// php5 - package-version : 5.3.5-1ubuntu7.2<br /><br />&nbsp; &nbsp; </span><span class="keyword">namespace<br />&nbsp; &nbsp; </span><span class="default">main<br />&nbsp; &nbsp; </span><span class="keyword">{}<br /><br />&nbsp; &nbsp; namespace<br />&nbsp; &nbsp; </span><span class="default">main</span><span class="keyword">\</span><span class="default">sub1<br />&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$data </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; namespace<br />&nbsp; &nbsp; </span><span class="default">main</span><span class="keyword">\</span><span class="default">sub2<br />&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">$data</span><span class="keyword">;</span><span class="comment">// 1<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$data </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; namespace<br />&nbsp; &nbsp; </span><span class="default">main</span><span class="keyword">\</span><span class="default">sub1<br />&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">$data</span><span class="keyword">;</span><span class="comment">// 2<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$data </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; namespace<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">$data</span><span class="keyword">;</span><span class="comment">// 1<br />&nbsp; &nbsp; </span><span class="keyword">}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="101520">  <div class="votes">
    <div id="Vu101520">
    <a href="/manual/vote-note.php?id=101520&amp;page=language.namespaces.basics&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd101520">
    <a href="/manual/vote-note.php?id=101520&amp;page=language.namespaces.basics&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V101520" title="35% like this...">
    -22
    </div>
  </div>
  <a href="#101520" class="name">
  <strong class="user"><em>Franois Vespa</em></strong></a><a class="genanchor" href="#101520"> &para;</a><div class="date" title="2010-12-21 05:42"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom101520">
<div class="phpcode"><code><span class="html">
It seems you cannot nest a constant declaration within a if statement<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">namespace </span><span class="default">FOO</span><span class="keyword">;<br /><br />if(eval)<br />const </span><span class="default">BAR</span><span class="keyword">=</span><span class="default">true</span><span class="keyword">; <br /><br /></span><span class="comment">// will throw the following error:<br />// PHP Parse error:&nbsp; syntax error, unexpected T_CONST<br /><br />// instead use:<br /><br /></span><span class="keyword">if(eval)<br /></span><span class="default">define</span><span class="keyword">(</span><span class="string">'FOO\BAR'</span><span class="keyword">,</span><span class="default">true</span><span class="keyword">);<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.namespaces.basics&amp;redirect=http://php.net/manual/en/language.namespaces.basics.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.namespaces.php">Namespaces</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.namespaces.rationale.php" title="Namespaces overview">Namespaces overview</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.definition.php" title="Defining namespaces">Defining namespaces</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.nested.php" title="Declaring sub-&#8203;namespaces">Declaring sub-&#8203;namespaces</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.definitionmultiple.php" title="Defining multiple namespaces in the same file">Defining multiple namespaces in the same file</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.namespaces.basics.php" title="Using namespaces: Basics">Using namespaces: Basics</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.dynamic.php" title="Namespaces and dynamic language features">Namespaces and dynamic language features</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.nsconstants.php" title="namespace keyword and _&#8203;_&#8203;NAMESPACE_&#8203;_&#8203; constant">namespace keyword and _&#8203;_&#8203;NAMESPACE_&#8203;_&#8203; constant</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.importing.php" title="Using namespaces: Aliasing/Importing">Using namespaces: Aliasing/Importing</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.global.php" title="Global space">Global space</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.fallback.php" title="Using namespaces: fallback to global function/constant">Using namespaces: fallback to global function/constant</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.rules.php" title="Name resolution rules">Name resolution rules</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.faq.php" title="FAQ: things you need to know about namespaces">FAQ: things you need to know about namespaces</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

