<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Namespaces and dynamic language features - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.namespaces.dynamic.php">
 <link rel="shorturl" href="http://php.net/namespaces.dynamic">
 <link rel="alternate" href="http://php.net/namespaces.dynamic" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.namespaces.php">
 <link rel="prev" href="http://php.net/manual/en/language.namespaces.basics.php">
 <link rel="next" href="http://php.net/manual/en/language.namespaces.nsconstants.php">

 <link rel="alternate" href="http://php.net/manual/en/language.namespaces.dynamic.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.namespaces.dynamic.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.namespaces.dynamic.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.namespaces.dynamic.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.namespaces.dynamic.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.namespaces.dynamic.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.namespaces.dynamic.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.namespaces.dynamic.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.namespaces.dynamic.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.namespaces.dynamic.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.namespaces.dynamic.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.namespaces.nsconstants.php">
          namespace keyword and __NAMESPACE__ constant &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.namespaces.basics.php">
          &laquo; Using namespaces: Basics        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.namespaces.php'>Namespaces</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.namespaces.dynamic.php' selected="selected">English</option>
            <option value='pt_BR/language.namespaces.dynamic.php'>Brazilian Portuguese</option>
            <option value='zh/language.namespaces.dynamic.php'>Chinese (Simplified)</option>
            <option value='fr/language.namespaces.dynamic.php'>French</option>
            <option value='de/language.namespaces.dynamic.php'>German</option>
            <option value='ja/language.namespaces.dynamic.php'>Japanese</option>
            <option value='ro/language.namespaces.dynamic.php'>Romanian</option>
            <option value='ru/language.namespaces.dynamic.php'>Russian</option>
            <option value='es/language.namespaces.dynamic.php'>Spanish</option>
            <option value='tr/language.namespaces.dynamic.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.namespaces.dynamic.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.namespaces.dynamic">Report a Bug</a>
    </div>
  </div><div id="language.namespaces.dynamic" class="sect1">
  <h2 class="title">Namespaces and dynamic language features</h2>
  <p class="verinfo">(PHP 5 &gt;= 5.3.0, PHP 7)</p>
  <p class="para">
   PHP&#039;s implementation of namespaces is influenced by its dynamic nature as a programming
   language.  Thus, to convert code like the following example into namespaced code:
   <div class="example" id="example-251">
    <p><strong>Example #1 Dynamically accessing elements</strong></p>
    <div class="example-contents"><p>example1.php:</p></div>
    <div class="example-contents">
     <div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">classname<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;function&nbsp;</span><span style="color: #0000BB">__construct</span><span style="color: #007700">()<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #0000BB">__METHOD__</span><span style="color: #007700">,</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br />function&nbsp;</span><span style="color: #0000BB">funcname</span><span style="color: #007700">()<br />{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #0000BB">__FUNCTION__</span><span style="color: #007700">,</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br />}<br />const&nbsp;</span><span style="color: #0000BB">constname&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">"global"</span><span style="color: #007700">;<br /><br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'classname'</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$obj&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">$a</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;prints&nbsp;classname::__construct<br /></span><span style="color: #0000BB">$b&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'funcname'</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$b</span><span style="color: #007700">();&nbsp;</span><span style="color: #FF8000">//&nbsp;prints&nbsp;funcname<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #0000BB">constant</span><span style="color: #007700">(</span><span style="color: #DD0000">'constname'</span><span style="color: #007700">),&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;prints&nbsp;global<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
   One must use the fully qualified name (class name with namespace prefix).
   Note that because there is no difference between a qualified and a fully qualified Name
   inside a dynamic class name, function name, or constant name, the leading backslash is
   not necessary.
   <div class="example" id="example-252">
    <p><strong>Example #2 Dynamically accessing namespaced elements</strong></p>
    <div class="example-contents">
     <div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">namespace&nbsp;</span><span style="color: #0000BB">namespacename</span><span style="color: #007700">;<br />class&nbsp;</span><span style="color: #0000BB">classname<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;function&nbsp;</span><span style="color: #0000BB">__construct</span><span style="color: #007700">()<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #0000BB">__METHOD__</span><span style="color: #007700">,</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br />function&nbsp;</span><span style="color: #0000BB">funcname</span><span style="color: #007700">()<br />{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #0000BB">__FUNCTION__</span><span style="color: #007700">,</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br />}<br />const&nbsp;</span><span style="color: #0000BB">constname&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">"namespaced"</span><span style="color: #007700">;<br /><br /></span><span style="color: #FF8000">/*&nbsp;note&nbsp;that&nbsp;if&nbsp;using&nbsp;double&nbsp;quotes,&nbsp;"\\namespacename\\classname"&nbsp;must&nbsp;be&nbsp;used&nbsp;*/<br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'\namespacename\classname'</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$obj&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">$a</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;prints&nbsp;namespacename\classname::__construct<br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'namespacename\classname'</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$obj&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">$a</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;also&nbsp;prints&nbsp;namespacename\classname::__construct<br /></span><span style="color: #0000BB">$b&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'namespacename\funcname'</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$b</span><span style="color: #007700">();&nbsp;</span><span style="color: #FF8000">//&nbsp;prints&nbsp;namespacename\funcname<br /></span><span style="color: #0000BB">$b&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'\namespacename\funcname'</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$b</span><span style="color: #007700">();&nbsp;</span><span style="color: #FF8000">//&nbsp;also&nbsp;prints&nbsp;namespacename\funcname<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #0000BB">constant</span><span style="color: #007700">(</span><span style="color: #DD0000">'\namespacename\constname'</span><span style="color: #007700">),&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;prints&nbsp;namespaced<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #0000BB">constant</span><span style="color: #007700">(</span><span style="color: #DD0000">'namespacename\constname'</span><span style="color: #007700">),&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;also&nbsp;prints&nbsp;namespaced<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
  </p>
  <p class="para">
   Be sure to read the <a href="language.namespaces.faq.php#language.namespaces.faq.quote" class="link">note about
   escaping namespace names in strings</a>.
  </p>
 </div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.namespaces.dynamic&amp;redirect=http://php.net/manual/en/language.namespaces.dynamic.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">5 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="104762">  <div class="votes">
    <div id="Vu104762">
    <a href="/manual/vote-note.php?id=104762&amp;page=language.namespaces.dynamic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd104762">
    <a href="/manual/vote-note.php?id=104762&amp;page=language.namespaces.dynamic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V104762" title="83% like this...">
    49
    </div>
  </div>
  <a href="#104762" class="name">
  <strong class="user"><em>Alexander Kirk</em></strong></a><a class="genanchor" href="#104762"> &para;</a><div class="date" title="2011-07-06 12:57"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom104762">
<div class="phpcode"><code><span class="html">
When extending a class from another namespace that should instantiate a class from within the current namespace, you need to pass on the namespace.<br /><br /><span class="default">&lt;?php </span><span class="comment">// File1.php<br /></span><span class="keyword">namespace </span><span class="default">foo</span><span class="keyword">;<br />class </span><span class="default">A </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">factory</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return new </span><span class="default">C</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br />class </span><span class="default">C </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">tell</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"foo"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br /><span class="default">&lt;?php </span><span class="comment">// File2.php<br /></span><span class="keyword">namespace </span><span class="default">bar</span><span class="keyword">;<br />class </span><span class="default">B </span><span class="keyword">extends \</span><span class="default">foo</span><span class="keyword">\</span><span class="default">A </span><span class="keyword">{}<br />class </span><span class="default">C </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">tell</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"bar"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br /><span class="default">&lt;?php<br /></span><span class="keyword">include </span><span class="string">"File1.php"</span><span class="keyword">;<br />include </span><span class="string">"File2.php"</span><span class="keyword">;<br /></span><span class="default">$b </span><span class="keyword">= new </span><span class="default">bar</span><span class="keyword">\</span><span class="default">B</span><span class="keyword">;<br /></span><span class="default">$c </span><span class="keyword">= </span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">factory</span><span class="keyword">();<br /></span><span class="default">$c</span><span class="keyword">-&gt;</span><span class="default">tell</span><span class="keyword">(); </span><span class="comment">// "foo" but you want "bar"<br /></span><span class="default">?&gt;<br /></span><br />You need to do it like this:<br /><br />When extending a class from another namespace that should instantiate a class from within the current namespace, you need to pass on the namespace.<br /><br /><span class="default">&lt;?php </span><span class="comment">// File1.php<br /></span><span class="keyword">namespace </span><span class="default">foo</span><span class="keyword">;<br />class </span><span class="default">A </span><span class="keyword">{<br />&nbsp; &nbsp; protected </span><span class="default">$namespace </span><span class="keyword">= </span><span class="default">__NAMESPACE__</span><span class="keyword">;<br />&nbsp; &nbsp; public function </span><span class="default">factory</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$c </span><span class="keyword">= </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">namespace </span><span class="keyword">. </span><span class="string">'\C'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; return new </span><span class="default">$c</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br />class </span><span class="default">C </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">tell</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"foo"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br /><span class="default">&lt;?php </span><span class="comment">// File2.php<br /></span><span class="keyword">namespace </span><span class="default">bar</span><span class="keyword">;<br />class </span><span class="default">B </span><span class="keyword">extends \</span><span class="default">foo</span><span class="keyword">\</span><span class="default">A </span><span class="keyword">{<br />&nbsp; &nbsp; protected </span><span class="default">$namespace </span><span class="keyword">= </span><span class="default">__NAMESPACE__</span><span class="keyword">;<br />}<br />class </span><span class="default">C </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">tell</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"bar"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br /><span class="default">&lt;?php<br /></span><span class="keyword">include </span><span class="string">"File1.php"</span><span class="keyword">;<br />include </span><span class="string">"File2.php"</span><span class="keyword">;<br /></span><span class="default">$b </span><span class="keyword">= new </span><span class="default">bar</span><span class="keyword">\</span><span class="default">B</span><span class="keyword">;<br /></span><span class="default">$c </span><span class="keyword">= </span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">factory</span><span class="keyword">();<br /></span><span class="default">$c</span><span class="keyword">-&gt;</span><span class="default">tell</span><span class="keyword">(); </span><span class="comment">// "bar"<br /></span><span class="default">?&gt;<br /></span><br />(it seems that the namespace-backslashes are stripped from the source code in the preview, maybe it works in the main view. If not: fooA was written as \foo\A and barB as bar\B)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="91552">  <div class="votes">
    <div id="Vu91552">
    <a href="/manual/vote-note.php?id=91552&amp;page=language.namespaces.dynamic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd91552">
    <a href="/manual/vote-note.php?id=91552&amp;page=language.namespaces.dynamic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V91552" title="78% like this...">
    13
    </div>
  </div>
  <a href="#91552" class="name">
  <strong class="user"><em>guilhermeblanco at php dot net</em></strong></a><a class="genanchor" href="#91552"> &para;</a><div class="date" title="2009-06-16 12:04"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom91552">
<div class="phpcode"><code><span class="html">
Please be aware of FQCN (Full Qualified Class Name) point.<br />Many people will have troubles with this:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="comment">// File1.php<br /></span><span class="keyword">namespace </span><span class="default">foo</span><span class="keyword">;<br /><br />class </span><span class="default">Bar </span><span class="keyword">{ ... }<br /><br />function </span><span class="default">factory</span><span class="keyword">(</span><span class="default">$class</span><span class="keyword">) {<br />&nbsp; &nbsp; return new </span><span class="default">$class</span><span class="keyword">;<br />}<br /><br /></span><span class="comment">// File2.php<br /></span><span class="default">$bar </span><span class="keyword">= \</span><span class="default">foo</span><span class="keyword">\</span><span class="default">factory</span><span class="keyword">(</span><span class="string">'Bar'</span><span class="keyword">); </span><span class="comment">// Will try to instantiate \Bar, not \foo\Bar<br /><br /></span><span class="default">?&gt;<br /></span><br />To fix that, and also incorporate a 2 step namespace resolution, you can check for \ as first char of $class, and if not present, build manually the FQCN:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="comment">// File1.php<br /></span><span class="keyword">namespace </span><span class="default">foo</span><span class="keyword">;<br /><br />function </span><span class="default">factory</span><span class="keyword">(</span><span class="default">$class</span><span class="keyword">) {<br />&nbsp; &nbsp; if (</span><span class="default">$class</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">] != </span><span class="string">'\\'</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'-&gt;'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$class </span><span class="keyword">= </span><span class="string">'\\' </span><span class="keyword">. </span><span class="default">__NAMESPACE__ </span><span class="keyword">. </span><span class="string">'\\' </span><span class="keyword">. </span><span class="default">$class</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; return new </span><span class="default">$class</span><span class="keyword">();<br />}<br /><br /></span><span class="comment">// File2.php<br /></span><span class="default">$bar </span><span class="keyword">= \</span><span class="default">foo</span><span class="keyword">\</span><span class="default">factory</span><span class="keyword">(</span><span class="string">'Bar'</span><span class="keyword">); </span><span class="comment">// Will correctly instantiate \foo\Bar<br /><br /></span><span class="default">$bar2 </span><span class="keyword">= \</span><span class="default">foo</span><span class="keyword">\</span><span class="default">factory</span><span class="keyword">(</span><span class="string">'\anotherfoo\Bar'</span><span class="keyword">); </span><span class="comment">// Wil correctly instantiate \anotherfoo\Bar<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="112942">  <div class="votes">
    <div id="Vu112942">
    <a href="/manual/vote-note.php?id=112942&amp;page=language.namespaces.dynamic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd112942">
    <a href="/manual/vote-note.php?id=112942&amp;page=language.namespaces.dynamic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V112942" title="61% like this...">
    4
    </div>
  </div>
  <a href="#112942" class="name">
  <strong class="user"><em>akhoondi+php at gmail dot com</em></strong></a><a class="genanchor" href="#112942"> &para;</a><div class="date" title="2013-08-09 04:17"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom112942">
<div class="phpcode"><code><span class="html">
It might make it more clear if said this way: <br /><br />One must note that when using a dynamic class name, function name or constant name, the "current namespace", as in <a href="http://www.php.net/manual/en/language.namespaces.basics.php" rel="nofollow" target="_blank">http://www.php.net/manual/en/language.namespaces.basics.php</a> is global namespace.<br /><br />One situation that dynamic class names are used is in 'factory' pattern. Thus, add the desired namespace of your target class before the variable name.<br /><br />namespaced.php<br /><span class="default">&lt;?php<br /></span><span class="comment">// namespaced.php<br /></span><span class="keyword">namespace </span><span class="default">Mypackage</span><span class="keyword">;<br />class </span><span class="default">Foo </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">factory</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">, </span><span class="default">$global </span><span class="keyword">= </span><span class="default">FALSE</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$global</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$class </span><span class="keyword">= </span><span class="default">$name</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$class </span><span class="keyword">= </span><span class="string">'Mypackage\\' </span><span class="keyword">. </span><span class="default">$name</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; return new </span><span class="default">$class</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">A </span><span class="keyword">{<br />&nbsp; &nbsp; function </span><span class="default">__construct</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">__METHOD__ </span><span class="keyword">. </span><span class="string">"&lt;br /&gt;\n"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br />class </span><span class="default">B </span><span class="keyword">{<br />&nbsp; &nbsp; function </span><span class="default">__construct</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">__METHOD__ </span><span class="keyword">. </span><span class="string">"&lt;br /&gt;\n"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />global.php<br /><span class="default">&lt;?php <br /></span><span class="comment">// global.php<br /></span><span class="keyword">class </span><span class="default">A </span><span class="keyword">{<br />&nbsp; &nbsp; function </span><span class="default">__construct</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo&nbsp; </span><span class="default">__METHOD__</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />index.php<br /><span class="default">&lt;?php<br /></span><span class="comment">//&nbsp; index.php<br /></span><span class="keyword">namespace </span><span class="default">Mypackage</span><span class="keyword">;<br />include(</span><span class="string">'namespaced.php'</span><span class="keyword">);<br />include(</span><span class="string">'global.php'</span><span class="keyword">);<br />&nbsp; <br />&nbsp; </span><span class="default">$foo </span><span class="keyword">= new </span><span class="default">Foo</span><span class="keyword">();<br />&nbsp; <br />&nbsp; </span><span class="default">$a </span><span class="keyword">= </span><span class="default">$foo</span><span class="keyword">-&gt;</span><span class="default">factory</span><span class="keyword">(</span><span class="string">'A'</span><span class="keyword">);&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Mypackage\A::__construct <br />&nbsp; </span><span class="default">$b </span><span class="keyword">= </span><span class="default">$foo</span><span class="keyword">-&gt;</span><span class="default">factory</span><span class="keyword">(</span><span class="string">'B'</span><span class="keyword">);&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Mypackage\B::__construct<br />&nbsp; <br />&nbsp; </span><span class="default">$a2 </span><span class="keyword">= </span><span class="default">$foo</span><span class="keyword">-&gt;</span><span class="default">factory</span><span class="keyword">(</span><span class="string">'A'</span><span class="keyword">,</span><span class="default">TRUE</span><span class="keyword">);&nbsp; &nbsp; </span><span class="comment">// A::__construct<br />&nbsp; </span><span class="default">$b2 </span><span class="keyword">= </span><span class="default">$foo</span><span class="keyword">-&gt;</span><span class="default">factory</span><span class="keyword">(</span><span class="string">'B'</span><span class="keyword">,</span><span class="default">TRUE</span><span class="keyword">);&nbsp; &nbsp; </span><span class="comment">// Will produce : Fatal error: Class 'B' not found in ...namespaced.php on line ...<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120707">  <div class="votes">
    <div id="Vu120707">
    <a href="/manual/vote-note.php?id=120707&amp;page=language.namespaces.dynamic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120707">
    <a href="/manual/vote-note.php?id=120707&amp;page=language.namespaces.dynamic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120707" title="50% like this...">
    0
    </div>
  </div>
  <a href="#120707" class="name">
  <strong class="user"><em>m dot mannes at gmail dot com</em></strong></a><a class="genanchor" href="#120707"> &para;</a><div class="date" title="2017-02-25 06:36"><strong>9 months ago</strong></div>
  <div class="text" id="Hcom120707">
<div class="phpcode"><code><span class="html">
Case you are trying call a static method that's the way to go:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">myClass <br /></span><span class="keyword">{<br />&nbsp; &nbsp; public static function </span><span class="default">myMethod</span><span class="keyword">() <br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; return </span><span class="string">"You did it!\n"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$foo </span><span class="keyword">= </span><span class="string">"myClass"</span><span class="keyword">;<br /></span><span class="default">$bar </span><span class="keyword">= </span><span class="string">"myMethod"</span><span class="keyword">;<br /><br />echo </span><span class="default">$foo</span><span class="keyword">::</span><span class="default">$bar</span><span class="keyword">(); </span><span class="comment">// prints "You did it!";<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="92764">  <div class="votes">
    <div id="Vu92764">
    <a href="/manual/vote-note.php?id=92764&amp;page=language.namespaces.dynamic&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd92764">
    <a href="/manual/vote-note.php?id=92764&amp;page=language.namespaces.dynamic&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V92764" title="50% like this...">
    0
    </div>
  </div>
  <a href="#92764" class="name">
  <strong class="user"><em>scott at intothewild dot ca</em></strong></a><a class="genanchor" href="#92764"> &para;</a><div class="date" title="2009-08-07 03:33"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom92764">
<div class="phpcode"><code><span class="html">
as noted by guilhermeblanco at php dot net, <br /><br /><span class="default">&lt;?php<br /><br />&nbsp; </span><span class="comment">// fact.php<br /><br />&nbsp; </span><span class="keyword">namespace </span><span class="default">foo</span><span class="keyword">;<br /><br />&nbsp; class </span><span class="default">fact </span><span class="keyword">{<br /><br />&nbsp; &nbsp; public function </span><span class="default">create</span><span class="keyword">(</span><span class="default">$class</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; return new </span><span class="default">$class</span><span class="keyword">();<br />&nbsp; &nbsp; }<br />&nbsp; }<br /><br /></span><span class="default">?&gt;<br /></span><br /><span class="default">&lt;?php <br /><br />&nbsp; </span><span class="comment">// bar.php<br /><br />&nbsp; </span><span class="keyword">namespace </span><span class="default">foo</span><span class="keyword">;<br /><br />&nbsp; class </span><span class="default">bar </span><span class="keyword">{<br />&nbsp; ... <br />&nbsp; }<br /><br /></span><span class="default">?&gt;<br /></span><br /><span class="default">&lt;?php<br /><br />&nbsp; </span><span class="comment">// index.php<br /> <br />&nbsp; </span><span class="keyword">namespace </span><span class="default">foo</span><span class="keyword">;<br /><br />&nbsp; include(</span><span class="string">'fact.php'</span><span class="keyword">);<br />&nbsp; <br />&nbsp; </span><span class="default">$foofact </span><span class="keyword">= new </span><span class="default">fact</span><span class="keyword">();<br />&nbsp; </span><span class="default">$bar </span><span class="keyword">= </span><span class="default">$foofact</span><span class="keyword">-&gt;</span><span class="default">create</span><span class="keyword">(</span><span class="string">'bar'</span><span class="keyword">); </span><span class="comment">// attempts to create \bar<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; // even though foofact and<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; // bar reside in \foo<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.namespaces.dynamic&amp;redirect=http://php.net/manual/en/language.namespaces.dynamic.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.namespaces.php">Namespaces</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.namespaces.rationale.php" title="Namespaces overview">Namespaces overview</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.definition.php" title="Defining namespaces">Defining namespaces</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.nested.php" title="Declaring sub-&#8203;namespaces">Declaring sub-&#8203;namespaces</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.definitionmultiple.php" title="Defining multiple namespaces in the same file">Defining multiple namespaces in the same file</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.basics.php" title="Using namespaces: Basics">Using namespaces: Basics</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.namespaces.dynamic.php" title="Namespaces and dynamic language features">Namespaces and dynamic language features</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.nsconstants.php" title="namespace keyword and _&#8203;_&#8203;NAMESPACE_&#8203;_&#8203; constant">namespace keyword and _&#8203;_&#8203;NAMESPACE_&#8203;_&#8203; constant</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.importing.php" title="Using namespaces: Aliasing/Importing">Using namespaces: Aliasing/Importing</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.global.php" title="Global space">Global space</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.fallback.php" title="Using namespaces: fallback to global function/constant">Using namespaces: fallback to global function/constant</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.rules.php" title="Name resolution rules">Name resolution rules</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.faq.php" title="FAQ: things you need to know about namespaces">FAQ: things you need to know about namespaces</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

