<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Objects and references - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.oop5.references.php">
 <link rel="shorturl" href="http://php.net/oop5.references">
 <link rel="alternate" href="http://php.net/oop5.references" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.oop5.php">
 <link rel="prev" href="http://php.net/manual/en/language.oop5.late-static-bindings.php">
 <link rel="next" href="http://php.net/manual/en/language.oop5.serialization.php">

 <link rel="alternate" href="http://php.net/manual/en/language.oop5.references.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.oop5.references.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.oop5.references.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.oop5.references.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.oop5.references.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.oop5.references.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.oop5.references.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.oop5.references.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.oop5.references.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.oop5.references.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.oop5.references.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.oop5.serialization.php">
          Object Serialization &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.oop5.late-static-bindings.php">
          &laquo; Late Static Bindings        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.oop5.php'>Classes and Objects</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.oop5.references.php' selected="selected">English</option>
            <option value='pt_BR/language.oop5.references.php'>Brazilian Portuguese</option>
            <option value='zh/language.oop5.references.php'>Chinese (Simplified)</option>
            <option value='fr/language.oop5.references.php'>French</option>
            <option value='de/language.oop5.references.php'>German</option>
            <option value='ja/language.oop5.references.php'>Japanese</option>
            <option value='ro/language.oop5.references.php'>Romanian</option>
            <option value='ru/language.oop5.references.php'>Russian</option>
            <option value='es/language.oop5.references.php'>Spanish</option>
            <option value='tr/language.oop5.references.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.oop5.references.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.oop5.references">Report a Bug</a>
    </div>
  </div><div id="language.oop5.references" class="sect1">
  <h2 class="title">Objects and references</h2>
  <p class="para">
   One of the key-points of PHP 5 OOP that is often mentioned is that 
   &quot;objects are passed by references by default&quot;. This is not completely true. 
   This section rectifies that general thought using some examples.
  </p>

  <p class="para">
   A PHP reference is an alias, which allows two different variables to write
   to the same value. As of PHP 5, an object variable doesn&#039;t contain the object
   itself as value anymore. It only contains an object identifier which allows
   object accessors to find the actual object. When an object is sent by 
   argument, returned or assigned to another variable, the different variables
   are not aliases: they hold a copy of the identifier, which points to the same
   object.
  </p>

  <div class="example" id="example-241">
   <p><strong>Example #1 References and Objects</strong></p>
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">A&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;</span><span style="color: #0000BB">$foo&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">;<br />}&nbsp;&nbsp;<br /><br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">A</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$b&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$a</span><span style="color: #007700">;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$a&nbsp;and&nbsp;$b&nbsp;are&nbsp;copies&nbsp;of&nbsp;the&nbsp;same&nbsp;identifier<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;($a)&nbsp;=&nbsp;($b)&nbsp;=&nbsp;&lt;id&gt;<br /></span><span style="color: #0000BB">$b</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">foo&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">;<br />echo&nbsp;</span><span style="color: #0000BB">$a</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">foo</span><span style="color: #007700">.</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br /><br /><br /></span><span style="color: #0000BB">$c&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">A</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$d&nbsp;</span><span style="color: #007700">=&nbsp;&amp;</span><span style="color: #0000BB">$c</span><span style="color: #007700">;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$c&nbsp;and&nbsp;$d&nbsp;are&nbsp;references<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;($c,$d)&nbsp;=&nbsp;&lt;id&gt;<br /><br /></span><span style="color: #0000BB">$d</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">foo&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">;<br />echo&nbsp;</span><span style="color: #0000BB">$c</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">foo</span><span style="color: #007700">.</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br /><br /><br /></span><span style="color: #0000BB">$e&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">A</span><span style="color: #007700">;<br /><br />function&nbsp;</span><span style="color: #0000BB">foo</span><span style="color: #007700">(</span><span style="color: #0000BB">$obj</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;($obj)&nbsp;=&nbsp;($e)&nbsp;=&nbsp;&lt;id&gt;<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$obj</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">foo&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #0000BB">foo</span><span style="color: #007700">(</span><span style="color: #0000BB">$e</span><span style="color: #007700">);<br />echo&nbsp;</span><span style="color: #0000BB">$e</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">foo</span><span style="color: #007700">.</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br /><br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

   <div class="example-contents"><p>The above example will output:</p></div>
   <div class="example-contents screen">
<div class="cdata"><pre>
2
2
2
</pre></div>
   </div>
  </div>
 </div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.oop5.references&amp;redirect=http://php.net/manual/en/language.oop5.references.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">15 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="95522">  <div class="votes">
    <div id="Vu95522">
    <a href="/manual/vote-note.php?id=95522&amp;page=language.oop5.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd95522">
    <a href="/manual/vote-note.php?id=95522&amp;page=language.oop5.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V95522" title="80% like this...">
    202
    </div>
  </div>
  <a href="#95522" class="name">
  <strong class="user"><em>miklcct at gmail dot com</em></strong></a><a class="genanchor" href="#95522"> &para;</a><div class="date" title="2010-01-07 01:34"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom95522">
<div class="phpcode"><code><span class="html">
Notes on reference:<br />A reference is not a pointer. However, an object handle IS a pointer. Example:<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Foo </span><span class="keyword">{<br />&nbsp; private static </span><span class="default">$used</span><span class="keyword">;<br />&nbsp; private </span><span class="default">$id</span><span class="keyword">;<br />&nbsp; public function </span><span class="default">__construct</span><span class="keyword">() {<br />&nbsp; &nbsp; </span><span class="default">$id </span><span class="keyword">= </span><span class="default">$used</span><span class="keyword">++;<br />&nbsp; }<br />&nbsp; public function </span><span class="default">__clone</span><span class="keyword">() {<br />&nbsp; &nbsp; </span><span class="default">$id </span><span class="keyword">= </span><span class="default">$used</span><span class="keyword">++;<br />&nbsp; }<br />}<br /><br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">Foo</span><span class="keyword">; </span><span class="comment">// $a is a pointer pointing to Foo object 0<br /></span><span class="default">$b </span><span class="keyword">= </span><span class="default">$a</span><span class="keyword">; </span><span class="comment">// $b is a pointer pointing to Foo object 0, however, $b is a copy of $a<br /></span><span class="default">$c </span><span class="keyword">= &amp;</span><span class="default">$a</span><span class="keyword">; </span><span class="comment">// $c and $a are now references of a pointer pointing to Foo object 0<br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">Foo</span><span class="keyword">; </span><span class="comment">// $a and $c are now references of a pointer pointing to Foo object 1, $b is still a pointer pointing to Foo object 0<br /></span><span class="keyword">unset(</span><span class="default">$a</span><span class="keyword">); </span><span class="comment">// A reference with reference count 1 is automatically converted back to a value. Now $c is a pointer to Foo object 1<br /></span><span class="default">$a </span><span class="keyword">= &amp;</span><span class="default">$b</span><span class="keyword">; </span><span class="comment">// $a and $b are now references of a pointer pointing to Foo object 0<br /></span><span class="default">$a </span><span class="keyword">= </span><span class="default">NULL</span><span class="keyword">; </span><span class="comment">// $a and $b now become a reference to NULL. Foo object 0 can be garbage collected now<br /></span><span class="keyword">unset(</span><span class="default">$b</span><span class="keyword">); </span><span class="comment">// $b no longer exists and $a is now NULL<br /></span><span class="default">$a </span><span class="keyword">= clone </span><span class="default">$c</span><span class="keyword">; </span><span class="comment">// $a is now a pointer to Foo object 2, $c remains a pointer to Foo object 1<br /></span><span class="keyword">unset(</span><span class="default">$c</span><span class="keyword">); </span><span class="comment">// Foo object 1 can be garbage collected now.<br /></span><span class="default">$c </span><span class="keyword">= </span><span class="default">$a</span><span class="keyword">; </span><span class="comment">// $c and $a are pointers pointing to Foo object 2<br /></span><span class="keyword">unset(</span><span class="default">$a</span><span class="keyword">); </span><span class="comment">// Foo object 2 is still pointed by $c<br /></span><span class="default">$a </span><span class="keyword">= &amp;</span><span class="default">$c</span><span class="keyword">; </span><span class="comment">// Foo object 2 has 1 pointers pointing to it only, that pointer has 2 references: $a and $c;<br /></span><span class="keyword">const </span><span class="default">ABC </span><span class="keyword">= </span><span class="default">TRUE</span><span class="keyword">;<br />if(</span><span class="default">ABC</span><span class="keyword">) {<br />&nbsp; </span><span class="default">$a </span><span class="keyword">= </span><span class="default">NULL</span><span class="keyword">; </span><span class="comment">// Foo object 2 can be garbage collected now because $a and $c are now a reference to the same NULL value<br /></span><span class="keyword">} else {<br />&nbsp; unset(</span><span class="default">$a</span><span class="keyword">); </span><span class="comment">// Foo object 2 is still pointed to $c<br /></span><span class="keyword">}</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="101900">  <div class="votes">
    <div id="Vu101900">
    <a href="/manual/vote-note.php?id=101900&amp;page=language.oop5.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd101900">
    <a href="/manual/vote-note.php?id=101900&amp;page=language.oop5.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V101900" title="82% like this...">
    146
    </div>
  </div>
  <a href="#101900" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#101900"> &para;</a><div class="date" title="2011-01-16 08:51"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom101900">
<div class="phpcode"><code><span class="html">
There seems to be some confusion here. The distinction between pointers and references is not particularly helpful.<br />The behavior in some of the "comprehensive" examples already posted can be explained in simpler unifying terms. Hayley's code, for example, is doing EXACTLY what you should expect it should. (Using &gt;= 5.3)<br /><br />First principle:<br />A pointer stores a memory address to access an object. Any time an object is assigned, a pointer is generated. (I haven't delved TOO deeply into the Zend engine yet, but as far as I can see, this applies)<br /><br />2nd principle, and source of the most confusion:<br />Passing a variable to a function is done by default as a value pass, ie, you are working with a copy. "But objects are passed by reference!" A common misconception both here and in the Java world. I never said a copy OF WHAT. The default passing is done by value. Always. WHAT is being copied and passed, however, is the pointer. When using the "-&gt;", you will of course be accessing the same internals as the original variable in the caller function. Just using "=" will only play with copies.<br /><br />3rd principle:<br />"&amp;" automatically and permanently sets another variable name/pointer to the same memory address as something else until you decouple them. It is correct to use the term "alias" here. Think of it as joining two pointers at the hip until forcibly separated with "unset()". This functionality exists both in the same scope and when an argument is passed to a function. Often the passed argument is called a "reference," due to certain distinctions between "passing by value" and "passing by reference" that were clearer in C and C++.<br /><br />Just remember: pointers to objects, not objects themselves, are passed to functions. These pointers are COPIES of the original unless you use "&amp;" in your parameter list to actually pass the originals. Only when you dig into the internals of an object will the originals change.<br /><br />Example:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="comment">//The two are meant to be the same<br /></span><span class="default">$a </span><span class="keyword">= </span><span class="string">"Clark Kent"</span><span class="keyword">; </span><span class="comment">//a==Clark Kent<br /></span><span class="default">$b </span><span class="keyword">= &amp;</span><span class="default">$a</span><span class="keyword">; </span><span class="comment">//The two will now share the same fate.<br /><br /></span><span class="default">$b</span><span class="keyword">=</span><span class="string">"Superman"</span><span class="keyword">; </span><span class="comment">// $a=="Superman" too.<br /></span><span class="keyword">echo </span><span class="default">$a</span><span class="keyword">; <br />echo </span><span class="default">$a</span><span class="keyword">=</span><span class="string">"Clark Kent"</span><span class="keyword">; </span><span class="comment">// $b=="Clark Kent" too.<br /></span><span class="keyword">unset(</span><span class="default">$b</span><span class="keyword">); </span><span class="comment">// $b divorced from $a<br /></span><span class="default">$b</span><span class="keyword">=</span><span class="string">"Bizarro"</span><span class="keyword">;<br />echo </span><span class="default">$a</span><span class="keyword">; </span><span class="comment">// $a=="Clark Kent" still, since $b is a free agent pointer now.<br /><br />//The two are NOT meant to be the same.<br /></span><span class="default">$c</span><span class="keyword">=</span><span class="string">"King"</span><span class="keyword">;<br /></span><span class="default">$d</span><span class="keyword">=</span><span class="string">"Pretender to the Throne"</span><span class="keyword">;<br />echo </span><span class="default">$c</span><span class="keyword">.</span><span class="string">"\n"</span><span class="keyword">; </span><span class="comment">// $c=="King"<br /></span><span class="keyword">echo </span><span class="default">$d</span><span class="keyword">.</span><span class="string">"\n"</span><span class="keyword">; </span><span class="comment">// $d=="Pretender to the Throne"<br /></span><span class="default">swapByValue</span><span class="keyword">(</span><span class="default">$c</span><span class="keyword">, </span><span class="default">$d</span><span class="keyword">);<br />echo </span><span class="default">$c</span><span class="keyword">.</span><span class="string">"\n"</span><span class="keyword">; </span><span class="comment">// $c=="King"<br /></span><span class="keyword">echo </span><span class="default">$d</span><span class="keyword">.</span><span class="string">"\n"</span><span class="keyword">; </span><span class="comment">// $d=="Pretender to the Throne"<br /></span><span class="default">swapByRef</span><span class="keyword">(</span><span class="default">$c</span><span class="keyword">, </span><span class="default">$d</span><span class="keyword">);<br />echo </span><span class="default">$c</span><span class="keyword">.</span><span class="string">"\n"</span><span class="keyword">; </span><span class="comment">// $c=="Pretender to the Throne"<br /></span><span class="keyword">echo </span><span class="default">$d</span><span class="keyword">.</span><span class="string">"\n"</span><span class="keyword">; </span><span class="comment">// $d=="King"<br /><br /></span><span class="keyword">function </span><span class="default">swapByValue</span><span class="keyword">(</span><span class="default">$x</span><span class="keyword">, </span><span class="default">$y</span><span class="keyword">){<br /></span><span class="default">$temp</span><span class="keyword">=</span><span class="default">$x</span><span class="keyword">;<br /></span><span class="default">$x</span><span class="keyword">=</span><span class="default">$y</span><span class="keyword">;<br /></span><span class="default">$y</span><span class="keyword">=</span><span class="default">$temp</span><span class="keyword">;<br /></span><span class="comment">//All this beautiful work will disappear<br />//because it was done on COPIES of pointers.<br />//The originals pointers still point as they did.<br /></span><span class="keyword">}<br /><br />function </span><span class="default">swapByRef</span><span class="keyword">(&amp;</span><span class="default">$x</span><span class="keyword">, &amp;</span><span class="default">$y</span><span class="keyword">){<br /> </span><span class="default">$temp</span><span class="keyword">=</span><span class="default">$x</span><span class="keyword">;<br /> </span><span class="default">$x</span><span class="keyword">=</span><span class="default">$y</span><span class="keyword">;<br /> </span><span class="default">$y</span><span class="keyword">=</span><span class="default">$temp</span><span class="keyword">;<br /> </span><span class="comment">//Note the parameter list: now we switched 'em REAL good.<br /></span><span class="keyword">}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117353">  <div class="votes">
    <div id="Vu117353">
    <a href="/manual/vote-note.php?id=117353&amp;page=language.oop5.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117353">
    <a href="/manual/vote-note.php?id=117353&amp;page=language.oop5.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117353" title="77% like this...">
    5
    </div>
  </div>
  <a href="#117353" class="name">
  <strong class="user"><em>wassimamal121 at hotmail dot com</em></strong></a><a class="genanchor" href="#117353"> &para;</a><div class="date" title="2015-05-26 04:43"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117353">
<div class="phpcode"><code><span class="html">
The example given by PHP manual is pretty clever and simple.<br />The example begins by explaining how things go when two aliases referring to the same objects are changed, just rethink the first part of the example <br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">A </span><span class="keyword">{&nbsp; &nbsp; public </span><span class="default">$foo </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;}&nbsp; <br />function </span><span class="default">go</span><span class="keyword">(</span><span class="default">$obj</span><span class="keyword">) {&nbsp; </span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">foo </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">;}<br />function </span><span class="default">bo</span><span class="keyword">(</span><span class="default">$obj</span><span class="keyword">) {</span><span class="default">$obj</span><span class="keyword">=new </span><span class="default">A</span><span class="keyword">;}<br /><br />function </span><span class="default">chan</span><span class="keyword">(</span><span class="default">$p</span><span class="keyword">){</span><span class="default">$p</span><span class="keyword">=</span><span class="default">44</span><span class="keyword">;}<br />function </span><span class="default">chanref</span><span class="keyword">(&amp;</span><span class="default">$p</span><span class="keyword">){</span><span class="default">$p</span><span class="keyword">=</span><span class="default">44</span><span class="keyword">;} <br /><br /></span><span class="comment">/**************manipulating simple variable******************/<br /></span><span class="default">$h</span><span class="keyword">=</span><span class="default">2</span><span class="keyword">;</span><span class="default">$k</span><span class="keyword">=</span><span class="default">$h</span><span class="keyword">;</span><span class="default">$h</span><span class="keyword">=</span><span class="default">4</span><span class="keyword">; echo </span><span class="string">'$k='</span><span class="keyword">.</span><span class="default">$k</span><span class="keyword">.</span><span class="string">"&lt;br/&gt;"</span><span class="keyword">;<br /></span><span class="comment">//$k refers to a memory cell containing the value 2<br />//$k is created and referes to another cell in the RAM<br />//$k=$h implies take the content of the cell to which $h refers <br />//and put it in the cell to which $k refers to<br />//$h=4 implies change the content of the cell to which $h refers to<br />//dosn't imply changing the content of the cell to which $k refers to <br /><br /></span><span class="default">$h</span><span class="keyword">=</span><span class="default">2</span><span class="keyword">;</span><span class="default">$k</span><span class="keyword">=&amp;</span><span class="default">$h</span><span class="keyword">;</span><span class="default">$h</span><span class="keyword">=</span><span class="default">4</span><span class="keyword">; echo </span><span class="string">'$k='</span><span class="keyword">.</span><span class="default">$k</span><span class="keyword">.</span><span class="string">"&lt;br/&gt;"</span><span class="keyword">;<br /></span><span class="comment">//here $k refers to the same memory cell as $h <br /><br /></span><span class="default">$v</span><span class="keyword">=</span><span class="default">2</span><span class="keyword">;</span><span class="default">chan</span><span class="keyword">(</span><span class="default">$v</span><span class="keyword">); echo </span><span class="string">'$v='</span><span class="keyword">.</span><span class="default">$v</span><span class="keyword">.</span><span class="string">"&lt;br/&gt;"</span><span class="keyword">;<br /></span><span class="comment">//the value of $v doesn't change because the function takes <br />// as argument an alias&nbsp; refering to a value 2, in the function we <br />//change only the value to which this alias refers to<br /><br /></span><span class="default">$u</span><span class="keyword">=</span><span class="default">2</span><span class="keyword">;</span><span class="default">chanref</span><span class="keyword">(</span><span class="default">$u</span><span class="keyword">); echo </span><span class="string">'$u='</span><span class="keyword">.</span><span class="default">$u</span><span class="keyword">.</span><span class="string">"&lt;br/&gt;"</span><span class="keyword">;<br /></span><span class="comment">//here the value changes because we pass a adress of the <br />//memory cell to which $u refers to, the function is manipulating<br />//the content of this memory cell <br /><br />/***************manipaliting objects************************/<br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">;<br /></span><span class="comment">//create an object by allocating some cells in memory, $a refers <br />//to this cells<br /><br /></span><span class="default">$b </span><span class="keyword">= </span><span class="default">$a</span><span class="keyword">; <br /></span><span class="comment">//$b refers to the same cells, it's not like simple variables<br />//which are created then, we copy the content<br /><br /></span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">foo </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">;echo </span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">foo</span><span class="keyword">.</span><span class="string">"&lt;br/&gt;"</span><span class="keyword">;<br /></span><span class="comment">//you can access the same object using both $a or $b <br /><br /></span><span class="default">$c </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">;</span><span class="default">$d </span><span class="keyword">= &amp;</span><span class="default">$c</span><span class="keyword">;</span><span class="default">$d</span><span class="keyword">-&gt;</span><span class="default">foo </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">;echo </span><span class="default">$c</span><span class="keyword">-&gt;</span><span class="default">foo</span><span class="keyword">.</span><span class="string">"&lt;br/&gt;"</span><span class="keyword">;<br /></span><span class="comment">//$d and $c don't just refers to the same memory space, <br />//but they are the same<br /> <br /></span><span class="default">$e </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">;<br /></span><span class="default">go</span><span class="keyword">(</span><span class="default">$e</span><span class="keyword">);<br /></span><span class="comment">//we pass a copy of a pointer <br /></span><span class="keyword">echo </span><span class="default">$e</span><span class="keyword">-&gt;</span><span class="default">foo</span><span class="keyword">.</span><span class="string">"&lt;br/&gt;"</span><span class="keyword">;<br /></span><span class="default">bo</span><span class="keyword">(</span><span class="default">$e</span><span class="keyword">);<br />echo </span><span class="default">$e</span><span class="keyword">-&gt;</span><span class="default">foo</span><span class="keyword">.</span><span class="string">"&lt;br/&gt;"</span><span class="keyword">;<br /></span><span class="comment">//if you think it's 1 sorry I failed to explain<br />//remember you passed just a pointer, when new is called<br />//the pointer is discoupled&nbsp; <br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="91627">  <div class="votes">
    <div id="Vu91627">
    <a href="/manual/vote-note.php?id=91627&amp;page=language.oop5.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd91627">
    <a href="/manual/vote-note.php?id=91627&amp;page=language.oop5.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V91627" title="73% like this...">
    33
    </div>
  </div>
  <a href="#91627" class="name">
  <strong class="user"><em>Aaron Bond</em></strong></a><a class="genanchor" href="#91627"> &para;</a><div class="date" title="2009-06-19 06:08"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom91627">
<div class="phpcode"><code><span class="html">
I've bumped into a behavior that helped clarify the difference between objects and identifiers for me.<br /><br />When we hand off an object variable, we get an identifier to that object's value.&nbsp; This means that if I were to mutate the object from a passed variable, ALL variables originating from that instance of the object will change.&nbsp; <br /><br />HOWEVER, if I set that object variable to new instance, it replaces the identifier itself with a new identifier and leaves the old instance in tact.<br /><br />Take the following example:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">A </span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$foo </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />}&nbsp; <br /><br />class </span><span class="default">B </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">foo</span><span class="keyword">(</span><span class="default">A $bar</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$bar</span><span class="keyword">-&gt;</span><span class="default">foo </span><span class="keyword">= </span><span class="default">42</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">bar</span><span class="keyword">(</span><span class="default">A $bar</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$bar </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$f </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">;<br /></span><span class="default">$g </span><span class="keyword">= new </span><span class="default">B</span><span class="keyword">;<br />echo </span><span class="default">$f</span><span class="keyword">-&gt;</span><span class="default">foo </span><span class="keyword">. </span><span class="string">"\n"</span><span class="keyword">;<br /><br /></span><span class="default">$g</span><span class="keyword">-&gt;</span><span class="default">foo</span><span class="keyword">(</span><span class="default">$f</span><span class="keyword">);<br />echo </span><span class="default">$f</span><span class="keyword">-&gt;</span><span class="default">foo </span><span class="keyword">. </span><span class="string">"\n"</span><span class="keyword">;<br /><br /></span><span class="default">$g</span><span class="keyword">-&gt;</span><span class="default">bar</span><span class="keyword">(</span><span class="default">$f</span><span class="keyword">);<br />echo </span><span class="default">$f</span><span class="keyword">-&gt;</span><span class="default">foo </span><span class="keyword">. </span><span class="string">"\n"</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;<br /></span><br />If object variables were always references, we'd expect the following output:<br />1<br />42<br />1<br /><br />However, we get:<br />1<br />42<br />42<br /><br />The reason for this is simple.&nbsp; In the bar function of the B class, we replace the identifier you passed in, which identified the same instance of the A class as your $f variable, with a brand new A class identifier.&nbsp; Creating a new instance of A doesn't mutate $f because $f wasn't passed as a reference.<br /><br />To get the reference behavior, one would have to enter the following for class B:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">B </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">foo</span><span class="keyword">(</span><span class="default">A $bar</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$bar</span><span class="keyword">-&gt;</span><span class="default">foo </span><span class="keyword">= </span><span class="default">42</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">bar</span><span class="keyword">(</span><span class="default">A </span><span class="keyword">&amp;</span><span class="default">$bar</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$bar </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />The foo function doesn't require a reference, because it is MUTATING an object instance that $bar identifies.&nbsp; But bar will be REPLACING the object instance.&nbsp; If only an identifier is passed, the variable identifier will be overwritten but the object instance will be left in place.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="109052">  <div class="votes">
    <div id="Vu109052">
    <a href="/manual/vote-note.php?id=109052&amp;page=language.oop5.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd109052">
    <a href="/manual/vote-note.php?id=109052&amp;page=language.oop5.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V109052" title="73% like this...">
    16
    </div>
  </div>
  <a href="#109052" class="name">
  <strong class="user"><em>kristof at viewranger dot com</em></strong></a><a class="genanchor" href="#109052"> &para;</a><div class="date" title="2012-06-16 02:07"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom109052">
<div class="phpcode"><code><span class="html">
I hope this clarifies references a bit more:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">A </span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$foo </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />}&nbsp; <br /><br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">;<br /></span><span class="default">$b </span><span class="keyword">= </span><span class="default">$a</span><span class="keyword">;<br /></span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">foo </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">;<br /></span><span class="default">$a </span><span class="keyword">= </span><span class="default">NULL</span><span class="keyword">;<br />echo </span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">foo</span><span class="keyword">.</span><span class="string">"\n"</span><span class="keyword">; </span><span class="comment">// 2<br /><br /></span><span class="default">$c </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">;<br /></span><span class="default">$d </span><span class="keyword">= &amp;</span><span class="default">$c</span><span class="keyword">;<br /></span><span class="default">$c</span><span class="keyword">-&gt;</span><span class="default">foo </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">;<br /></span><span class="default">$c </span><span class="keyword">= </span><span class="default">NULL</span><span class="keyword">;<br />echo </span><span class="default">$d</span><span class="keyword">-&gt;</span><span class="default">foo</span><span class="keyword">.</span><span class="string">"\n"</span><span class="keyword">; </span><span class="comment">// Notice:&nbsp; Trying to get property of non-object...<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="92955">  <div class="votes">
    <div id="Vu92955">
    <a href="/manual/vote-note.php?id=92955&amp;page=language.oop5.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd92955">
    <a href="/manual/vote-note.php?id=92955&amp;page=language.oop5.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V92955" title="68% like this...">
    9
    </div>
  </div>
  <a href="#92955" class="name">
  <strong class="user"><em>mjung at poczta dot onet dot pl</em></strong></a><a class="genanchor" href="#92955"> &para;</a><div class="date" title="2009-08-15 10:25"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom92955">
<div class="phpcode"><code><span class="html">
Ultimate explanation to object references:<br />NOTE: wording 'points to' could be easily replaced with 'refers ' and is used loosly.<br /><span class="default">&lt;?php<br />$a1 </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">(</span><span class="default">1</span><span class="keyword">);&nbsp; </span><span class="comment">// $a1 == handle1-1 to A(1)<br /></span><span class="default">$a2 </span><span class="keyword">= </span><span class="default">$a1</span><span class="keyword">;&nbsp; &nbsp;&nbsp; </span><span class="comment">// $a2 == handle1-2 to A(1) - assigned by value (copy)<br /></span><span class="default">$a3 </span><span class="keyword">= &amp;</span><span class="default">$a1</span><span class="keyword">;&nbsp; </span><span class="comment">// $a3 points to $a1 (handle1-1)<br /></span><span class="default">$a3 </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;&nbsp; &nbsp; &nbsp; </span><span class="comment">// makes $a1==null, $a3 (still) points to $a1, $a2 == handle1-2 (same object instance A(1))<br /></span><span class="default">$a2 </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;&nbsp; &nbsp; &nbsp; </span><span class="comment">// makes $a2 == null<br /></span><span class="default">$a1 </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">(</span><span class="default">2</span><span class="keyword">); </span><span class="comment">//makes $a1 == handle2-1 to new object and $a3 (still) points to $a1 =&gt; handle2-1 (new object), so value of $a1 and $a3 is the new object and $a2 == null<br />//By reference:<br /></span><span class="default">$a4 </span><span class="keyword">= &amp;new </span><span class="default">A</span><span class="keyword">(</span><span class="default">4</span><span class="keyword">);&nbsp; </span><span class="comment">//$a4 points to handle4-1 to A(4)<br /></span><span class="default">$a5 </span><span class="keyword">= </span><span class="default">$a4</span><span class="keyword">;&nbsp;&nbsp; </span><span class="comment">// $a5 == handle4-2 to A(4) (copy)<br /></span><span class="default">$a6 </span><span class="keyword">= &amp;</span><span class="default">$a4</span><span class="keyword">;&nbsp; </span><span class="comment">//$a6 points to (handle4-1), not to $a4 (reference to reference references the referenced object handle4-1 not the reference itself)<br /><br /></span><span class="default">$a4 </span><span class="keyword">= &amp;new </span><span class="default">A</span><span class="keyword">(</span><span class="default">40</span><span class="keyword">); </span><span class="comment">// $a4 points to handle40-1, $a5 == handle4-2 and $a6 still points to handle4-1 to A(4)<br /></span><span class="default">$a6 </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;&nbsp; </span><span class="comment">// sets handle4-1 to null; $a5 == handle4-2 = A(4); $a4 points to handle40-1; $a6 points to null<br /></span><span class="default">$a6 </span><span class="keyword">=&amp;</span><span class="default">$a4</span><span class="keyword">; </span><span class="comment">// $a6 points to handle40-1<br /></span><span class="default">$a7 </span><span class="keyword">= &amp;</span><span class="default">$a6</span><span class="keyword">; </span><span class="comment">//$a7 points to handle40-1<br /></span><span class="default">$a8 </span><span class="keyword">= &amp;</span><span class="default">$a7</span><span class="keyword">; </span><span class="comment">//$a8 points to handle40-1<br /></span><span class="default">$a5 </span><span class="keyword">= </span><span class="default">$a7</span><span class="keyword">;&nbsp; </span><span class="comment">//$a5 == handle40-2 (copy)<br /></span><span class="default">$a6 </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">; </span><span class="comment">//makes handle40-1 null, all variables pointing to (hanlde40-1 ==null) are null, except ($a5 == handle40-2 = A(40))<br /></span><span class="default">?&gt;<br /></span>Hope this helps.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="86374">  <div class="votes">
    <div id="Vu86374">
    <a href="/manual/vote-note.php?id=86374&amp;page=language.oop5.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86374">
    <a href="/manual/vote-note.php?id=86374&amp;page=language.oop5.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86374" title="67% like this...">
    11
    </div>
  </div>
  <a href="#86374" class="name">
  <strong class="user"><em>Ivan Bertona</em></strong></a><a class="genanchor" href="#86374"> &para;</a><div class="date" title="2008-10-15 08:45"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86374">
<div class="phpcode"><code><span class="html">
A point that in my opinion is not stressed enough in the manual page is that in PHP5, passing an object as an argument of a function call with no use of the &amp; operator means passing BY VALUE an unique identifier for that object (intended as instance of a class), which will be stored in another variable that has function scope.<br /><br />This behaviour is the same used in Java, where indeed there is no notion of passing arguments by reference. On the other hand, in PHP you can pass a value by reference (in PHP we refer to references as "aliases"), and this poses a threat if you are not aware of what you are really doing. Please consider these two classes:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">A <br /></span><span class="keyword">{<br />&nbsp; &nbsp; function </span><span class="default">__toString</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">"Class A"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br />&nbsp; &nbsp; <br />class </span><span class="default">B<br /></span><span class="keyword">{<br />&nbsp; &nbsp; function </span><span class="default">__toString</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">"Class B"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />In the first test case we make two objects out of the classes A and B, then swap the variables using a temp one and the normal assignment operator (=).<br /><br /><span class="default">&lt;?php<br />$a </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">();<br /></span><span class="default">$b </span><span class="keyword">= new </span><span class="default">B</span><span class="keyword">();<br />&nbsp; &nbsp; <br /></span><span class="default">$temp </span><span class="keyword">= </span><span class="default">$a</span><span class="keyword">;<br /></span><span class="default">$a </span><span class="keyword">= </span><span class="default">$b</span><span class="keyword">;<br /></span><span class="default">$b </span><span class="keyword">= </span><span class="default">$temp</span><span class="keyword">;<br />&nbsp; &nbsp; <br />print(</span><span class="string">'$a: ' </span><span class="keyword">. </span><span class="default">$a </span><span class="keyword">. </span><span class="string">"\n"</span><span class="keyword">);<br />print(</span><span class="string">'$b: ' </span><span class="keyword">. </span><span class="default">$b </span><span class="keyword">. </span><span class="string">"\n"</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />As expected the script will output:<br /><br />$a: Class B<br />$b: Class A<br /><br />Now consider the following snippet. It is similar to the former but the assignment $a = &amp;$b makes $a an ALIAS of $b.<br /><br /><span class="default">&lt;?php<br />$a </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">();<br /></span><span class="default">$b </span><span class="keyword">= new </span><span class="default">B</span><span class="keyword">();<br />&nbsp; &nbsp; <br /></span><span class="default">$temp </span><span class="keyword">= </span><span class="default">$a</span><span class="keyword">;<br /></span><span class="default">$a </span><span class="keyword">= &amp;</span><span class="default">$b</span><span class="keyword">;<br /></span><span class="default">$b </span><span class="keyword">= </span><span class="default">$temp</span><span class="keyword">;<br />&nbsp; &nbsp; <br />print(</span><span class="string">'$a: ' </span><span class="keyword">. </span><span class="default">$a </span><span class="keyword">. </span><span class="string">"\n"</span><span class="keyword">);<br />print(</span><span class="string">'$b: ' </span><span class="keyword">. </span><span class="default">$b </span><span class="keyword">. </span><span class="string">"\n"</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />This script will output:<br /><br />$a: Class A<br />$b: Class A<br /><br />That is, modifying $b reflects the same assignment on $a... The two variables end pointing to the same object, and the other one is lost. To sum up is a good practice NOT using aliasing when handling PHP5 objects, unless your are really really sure of what you are doing.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="97052">  <div class="votes">
    <div id="Vu97052">
    <a href="/manual/vote-note.php?id=97052&amp;page=language.oop5.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd97052">
    <a href="/manual/vote-note.php?id=97052&amp;page=language.oop5.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V97052" title="64% like this...">
    4
    </div>
  </div>
  <a href="#97052" class="name">
  <strong class="user"><em>Hayley Watson</em></strong></a><a class="genanchor" href="#97052"> &para;</a><div class="date" title="2010-03-29 07:21"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom97052">
<div class="phpcode"><code><span class="html">
Using &amp;$this can result in some weird and counter-intuitive behaviour - it starts lying to you.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">Bar<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$prop </span><span class="keyword">= </span><span class="default">42</span><span class="keyword">;<br />}<br /><br />class </span><span class="default">Foo<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$prop </span><span class="keyword">= </span><span class="default">17</span><span class="keyword">;<br />&nbsp; &nbsp; function </span><span class="default">boom</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$bar </span><span class="keyword">= &amp;</span><span class="default">$this</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"\$bar is an alias of \$this, a Foo.\n"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'$this is a '</span><span class="keyword">, </span><span class="default">get_class</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">), </span><span class="string">'; $bar is a '</span><span class="keyword">, </span><span class="default">get_class</span><span class="keyword">(</span><span class="default">$bar</span><span class="keyword">), </span><span class="string">"\n"</span><span class="keyword">;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Are they the same object? "</span><span class="keyword">, (</span><span class="default">$bar </span><span class="keyword">=== </span><span class="default">$this </span><span class="keyword">? </span><span class="string">"Yes\n" </span><span class="keyword">: </span><span class="string">"No\n"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Are they equal? "</span><span class="keyword">, (</span><span class="default">$bar </span><span class="keyword">=== </span><span class="default">$this </span><span class="keyword">? </span><span class="string">"Yes\n" </span><span class="keyword">: </span><span class="string">"No\n"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'$this says its prop value is '</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">prop</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">' and $bar says it is '</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">$bar</span><span class="keyword">-&gt;</span><span class="default">prop</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"\n"</span><span class="keyword">;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"\n"</span><span class="keyword">;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$bar </span><span class="keyword">= new </span><span class="default">Bar</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"\$bar has been made into a new Bar.\n"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'$this is a '</span><span class="keyword">, </span><span class="default">get_class</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">), </span><span class="string">'; $bar is a '</span><span class="keyword">, </span><span class="default">get_class</span><span class="keyword">(</span><span class="default">$bar</span><span class="keyword">), </span><span class="string">"\n"</span><span class="keyword">;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Are they the same object? "</span><span class="keyword">, (</span><span class="default">$bar </span><span class="keyword">=== </span><span class="default">$this </span><span class="keyword">? </span><span class="string">"Yes\n" </span><span class="keyword">: </span><span class="string">"No\n"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Are they equal? "</span><span class="keyword">, (</span><span class="default">$bar </span><span class="keyword">=== </span><span class="default">$this </span><span class="keyword">? </span><span class="string">"Yes\n" </span><span class="keyword">: </span><span class="string">"No\n"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'$this says its prop value is '</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">prop</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">' and $bar says it is '</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">$bar</span><span class="keyword">-&gt;</span><span class="default">prop</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"\n"</span><span class="keyword">;<br /><br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$t </span><span class="keyword">= new </span><span class="default">Foo</span><span class="keyword">;<br /></span><span class="default">$t</span><span class="keyword">-&gt;</span><span class="default">boom</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span>In the above $this claims to be a Bar (in fact it claims to be the very same object that $bar is), while still having all the properties and methods of a Foo.<br /><br />Fortunately it doesn't persist beyond the method where you committed the faux pas.<br /><span class="default">&lt;?php<br /></span><span class="keyword">echo </span><span class="default">get_class</span><span class="keyword">(</span><span class="default">$t</span><span class="keyword">), </span><span class="string">"\t"</span><span class="keyword">, </span><span class="default">$t</span><span class="keyword">-&gt;</span><span class="default">prop</span><span class="keyword">;<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="106643">  <div class="votes">
    <div id="Vu106643">
    <a href="/manual/vote-note.php?id=106643&amp;page=language.oop5.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd106643">
    <a href="/manual/vote-note.php?id=106643&amp;page=language.oop5.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V106643" title="56% like this...">
    2
    </div>
  </div>
  <a href="#106643" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#106643"> &para;</a><div class="date" title="2011-11-23 07:57"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom106643">
<div class="phpcode"><code><span class="html">
this example could help:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">A </span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$testA </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />}&nbsp; <br /><br />class </span><span class="default">B </span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$testB </span><span class="keyword">= </span><span class="string">"class B"</span><span class="keyword">;<br />}&nbsp; <br /><br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">;<br /></span><span class="default">$b </span><span class="keyword">= </span><span class="default">$a</span><span class="keyword">;&nbsp; &nbsp;&nbsp; <br /></span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">testA </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">;<br /><br /></span><span class="default">$c </span><span class="keyword">= new </span><span class="default">B</span><span class="keyword">;<br /></span><span class="default">$a </span><span class="keyword">= </span><span class="default">$c</span><span class="keyword">;<br /><br /></span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">testB </span><span class="keyword">= </span><span class="string">"Changed Class B"</span><span class="keyword">;<br /><br />echo </span><span class="string">"&lt;br/&gt; object a: "</span><span class="keyword">; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">);<br />echo </span><span class="string">"&lt;br/&gt; object b: "</span><span class="keyword">; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$b</span><span class="keyword">);<br />echo </span><span class="string">"&lt;br/&gt; object c: "</span><span class="keyword">; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$c</span><span class="keyword">);<br /><br /></span><span class="comment">// by reference <br /><br /></span><span class="default">$aa </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">;<br /></span><span class="default">$bb </span><span class="keyword">= &amp;</span><span class="default">$aa</span><span class="keyword">;&nbsp; &nbsp;&nbsp; <br /></span><span class="default">$bb</span><span class="keyword">-&gt;</span><span class="default">testA </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">;<br /><br /></span><span class="default">$cc </span><span class="keyword">= new </span><span class="default">B</span><span class="keyword">;<br /></span><span class="default">$aa </span><span class="keyword">= </span><span class="default">$cc</span><span class="keyword">;<br /><br /></span><span class="default">$aa</span><span class="keyword">-&gt;</span><span class="default">testB </span><span class="keyword">= </span><span class="string">"Changed Class B"</span><span class="keyword">;<br /><br />echo </span><span class="string">"&lt;br/&gt; object aa: "</span><span class="keyword">; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$aa</span><span class="keyword">);<br />echo </span><span class="string">"&lt;br/&gt; object bb: "</span><span class="keyword">; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$bb</span><span class="keyword">);<br />echo </span><span class="string">"&lt;br/&gt; object cc: "</span><span class="keyword">; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$cc</span><span class="keyword">);<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="109737">  <div class="votes">
    <div id="Vu109737">
    <a href="/manual/vote-note.php?id=109737&amp;page=language.oop5.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd109737">
    <a href="/manual/vote-note.php?id=109737&amp;page=language.oop5.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V109737" title="52% like this...">
    1
    </div>
  </div>
  <a href="#109737" class="name">
  <strong class="user"><em>Jon Whitener</em></strong></a><a class="genanchor" href="#109737"> &para;</a><div class="date" title="2012-08-15 01:55"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom109737">
<div class="phpcode"><code><span class="html">
The use of clone may get you the behavior you expect when passing an object to a function, as shown below using DateTime objects as examples.<br /><br /><span class="default">&lt;?php<br />date_default_timezone_set</span><span class="keyword">( </span><span class="string">"America/Detroit" </span><span class="keyword">);<br /><br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">DateTime</span><span class="keyword">;<br />echo </span><span class="string">"a = " </span><span class="keyword">. </span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">format</span><span class="keyword">(</span><span class="string">'Y-m-j'</span><span class="keyword">) . </span><span class="string">"\n"</span><span class="keyword">;<br /><br /></span><span class="comment">// This might not give what you expect...<br /></span><span class="default">$b </span><span class="keyword">= </span><span class="default">upDate</span><span class="keyword">( </span><span class="default">$a </span><span class="keyword">); </span><span class="comment">// a and b both updated<br /></span><span class="keyword">echo </span><span class="string">"a = " </span><span class="keyword">. </span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">format</span><span class="keyword">(</span><span class="string">'Y-m-j'</span><span class="keyword">) . </span><span class="string">", b = " </span><span class="keyword">. </span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">format</span><span class="keyword">(</span><span class="string">'Y-m-j'</span><span class="keyword">) . </span><span class="string">"\n"</span><span class="keyword">;<br /></span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">modify</span><span class="keyword">( </span><span class="string">"+ 1 day" </span><span class="keyword">); </span><span class="comment">// a and b both modified<br /></span><span class="keyword">echo </span><span class="string">"a = " </span><span class="keyword">. </span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">format</span><span class="keyword">(</span><span class="string">'Y-m-j'</span><span class="keyword">) . </span><span class="string">", b = " </span><span class="keyword">. </span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">format</span><span class="keyword">(</span><span class="string">'Y-m-j'</span><span class="keyword">) . </span><span class="string">"\n"</span><span class="keyword">; <br /><br /></span><span class="comment">// This might be what you want...<br /></span><span class="default">$c </span><span class="keyword">= </span><span class="default">upDateClone</span><span class="keyword">( </span><span class="default">$a </span><span class="keyword">); </span><span class="comment">// only c updated, a left alone<br /></span><span class="keyword">echo </span><span class="string">"a = " </span><span class="keyword">. </span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">format</span><span class="keyword">(</span><span class="string">'Y-m-j'</span><span class="keyword">) . </span><span class="string">", c = " </span><span class="keyword">. </span><span class="default">$c</span><span class="keyword">-&gt;</span><span class="default">format</span><span class="keyword">(</span><span class="string">'Y-m-j'</span><span class="keyword">) . </span><span class="string">"\n"</span><span class="keyword">;<br /><br />function </span><span class="default">upDate</span><span class="keyword">( </span><span class="default">$datetime </span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$datetime</span><span class="keyword">-&gt;</span><span class="default">modify</span><span class="keyword">( </span><span class="string">"+ 1 day" </span><span class="keyword">);<br />&nbsp; &nbsp; return </span><span class="default">$datetime</span><span class="keyword">;<br />}<br /><br />function </span><span class="default">upDateClone</span><span class="keyword">( </span><span class="default">$datetime </span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$dt </span><span class="keyword">= clone </span><span class="default">$datetime</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$dt</span><span class="keyword">-&gt;</span><span class="default">modify</span><span class="keyword">( </span><span class="string">"+ 1 day" </span><span class="keyword">);<br />&nbsp; &nbsp; return </span><span class="default">$dt</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />The above would output something like:<br /><br />a = 2012-08-15<br />a = 2012-08-16, b = 2012-08-16<br />a = 2012-08-17, b = 2012-08-17<br />a = 2012-08-17, c = 2012-08-18</span>
</code></div>
  </div>
 </div>
  <div class="note" id="86042">  <div class="votes">
    <div id="Vu86042">
    <a href="/manual/vote-note.php?id=86042&amp;page=language.oop5.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86042">
    <a href="/manual/vote-note.php?id=86042&amp;page=language.oop5.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86042" title="44% like this...">
    -1
    </div>
  </div>
  <a href="#86042" class="name">
  <strong class="user"><em>wbcarts at juno dot com</em></strong></a><a class="genanchor" href="#86042"> &para;</a><div class="date" title="2008-09-30 01:23"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86042">
<div class="phpcode"><code><span class="html">
A BIT DILUTED... but it's alright!<br /><br />In the PHP example above, the function foo($obj), will actually create a $foo property to "any object" passed to it - which brings some confusion to me:<br />&nbsp; $obj = new stdClass();<br />&nbsp; foo($obj);&nbsp; &nbsp; // tags on a $foo property to the object<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; // why is this method here?<br />Furthermore, in OOP, it is not a good idea for "global functions" to operate on an object's properties... and it is not a good idea for your class objects to let them. To illustrate the point, the example should be:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">A </span><span class="keyword">{<br />&nbsp; protected </span><span class="default">$foo </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br /><br />&nbsp; public function </span><span class="default">getFoo</span><span class="keyword">() {<br />&nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">foo</span><span class="keyword">;<br />&nbsp; }<br /><br />&nbsp; public function </span><span class="default">setFoo</span><span class="keyword">(</span><span class="default">$val</span><span class="keyword">) {<br />&nbsp; &nbsp; if(</span><span class="default">$val </span><span class="keyword">&gt; </span><span class="default">0 </span><span class="keyword">&amp;&amp; </span><span class="default">$val </span><span class="keyword">&lt; </span><span class="default">10</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">foo </span><span class="keyword">= </span><span class="default">$val</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; }<br /><br />&nbsp; public function </span><span class="default">__toString</span><span class="keyword">() {<br />&nbsp; &nbsp; return </span><span class="string">"A [foo=</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">foo</span><span class="string">]"</span><span class="keyword">;<br />&nbsp; }<br />}<br /><br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">();<br /></span><span class="default">$b </span><span class="keyword">= </span><span class="default">$a</span><span class="keyword">;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// $a and $b are copies of the same identifier<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; // ($a) = ($b) = &lt;id&gt;<br /></span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">setFoo</span><span class="keyword">(</span><span class="default">2</span><span class="keyword">);<br />echo </span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">getFoo</span><span class="keyword">() . </span><span class="string">'&lt;br&gt;'</span><span class="keyword">;<br /><br /></span><span class="default">$c </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">();<br /></span><span class="default">$d </span><span class="keyword">= &amp;</span><span class="default">$c</span><span class="keyword">;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="comment">// $c and $d are references<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; // ($c,$d) = &lt;id&gt;<br /></span><span class="default">$d</span><span class="keyword">-&gt;</span><span class="default">setFoo</span><span class="keyword">(</span><span class="default">2</span><span class="keyword">);<br />echo </span><span class="default">$c </span><span class="keyword">. </span><span class="string">'&lt;br&gt;'</span><span class="keyword">;<br /><br /></span><span class="default">$e </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">();<br /></span><span class="default">$e</span><span class="keyword">-&gt;</span><span class="default">setFoo</span><span class="keyword">(</span><span class="default">16</span><span class="keyword">);&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="comment">// will be ignored<br /></span><span class="keyword">echo </span><span class="default">$e</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;<br /></span> - - -<br /> 2<br /> A [foo=2]<br /> A [foo=1]<br /> - - -<br />Because the global function foo() has been deleted, class A is more defined, robust and will handle all foo operations... and only for objects of type A. I can now take it for granted and see clearly that your are talking about "A" objects and their references. But it still reminds me too much of cloning and object comparisons, which to me borders on machine-like programming and not object-oriented programming, which is a totally different way to think.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="102242">  <div class="votes">
    <div id="Vu102242">
    <a href="/manual/vote-note.php?id=102242&amp;page=language.oop5.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd102242">
    <a href="/manual/vote-note.php?id=102242&amp;page=language.oop5.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V102242" title="40% like this...">
    -4
    </div>
  </div>
  <a href="#102242" class="name">
  <strong class="user"><em>Rob Marscher</em></strong></a><a class="genanchor" href="#102242"> &para;</a><div class="date" title="2011-02-03 09:33"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom102242">
<div class="phpcode"><code><span class="html">
Here's an example I created that helped me understand the difference between passing objects by reference and by value in php 5.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">A </span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$foo </span><span class="keyword">= </span><span class="string">'empty'</span><span class="keyword">;<br />}<br />class </span><span class="default">B </span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$foo </span><span class="keyword">= </span><span class="string">'empty'</span><span class="keyword">;<br />&nbsp; &nbsp; public </span><span class="default">$bar </span><span class="keyword">= </span><span class="string">'hello'</span><span class="keyword">;<br />}<br /><br />function </span><span class="default">normalAssignment</span><span class="keyword">(</span><span class="default">$obj</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">foo </span><span class="keyword">= </span><span class="string">'changed'</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$obj </span><span class="keyword">= new </span><span class="default">B</span><span class="keyword">;<br />}<br /><br />function </span><span class="default">referenceAssignment</span><span class="keyword">(&amp;</span><span class="default">$obj</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">foo </span><span class="keyword">= </span><span class="string">'changed'</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$obj </span><span class="keyword">= new </span><span class="default">B</span><span class="keyword">;<br />}<br /><br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">;<br /></span><span class="default">normalAssignment</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">);<br />echo </span><span class="default">get_class</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">), </span><span class="string">"\n"</span><span class="keyword">;<br />echo </span><span class="string">"foo = </span><span class="keyword">{</span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">foo</span><span class="keyword">}</span><span class="string">\n"</span><span class="keyword">;<br /><br /></span><span class="default">referenceAssignment</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">);<br />echo </span><span class="default">get_class</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">), </span><span class="string">"\n"</span><span class="keyword">;<br />echo </span><span class="string">"foo = </span><span class="keyword">{</span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">foo</span><span class="keyword">}</span><span class="string">\n"</span><span class="keyword">;<br />echo </span><span class="string">"bar = </span><span class="keyword">{</span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">bar</span><span class="keyword">}</span><span class="string">\n"</span><span class="keyword">;<br /><br /></span><span class="comment">/*<br />prints:<br />A<br />foo = changed<br />B<br />foo = empty<br />bar = hello<br />*/<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="112285">  <div class="votes">
    <div id="Vu112285">
    <a href="/manual/vote-note.php?id=112285&amp;page=language.oop5.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd112285">
    <a href="/manual/vote-note.php?id=112285&amp;page=language.oop5.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V112285" title="38% like this...">
    -3
    </div>
  </div>
  <a href="#112285" class="name">
  <strong class="user"><em>cesoid at gmail dot com</em></strong></a><a class="genanchor" href="#112285"> &para;</a><div class="date" title="2013-05-27 04:45"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom112285">
<div class="phpcode"><code><span class="html">
Comparing an alias to a pointer is like comparing a spoken word to the neurochemistry of the speaker. You know that the speaker can use two different words to refer to the same thing, but what's going on in their brain to make this work is something you don't want to have to think about every time they speak. (If you're programming in assembly or, less so, in C++, you're out of luck there.)<br /><br />Likewise, PHP *the language* and a given php interpretor are not the same thing, and this post and most of these comments leave that out in the explanation. An alias/reference is a part of the language, a pointer is a part of how the computer makes the reference work. You often have little guarantee that an interpreter will continue working the same way internally.<br /><br />From a functional point of view the internals of the interpreter *do* matter for optimization, but *don't* matter in terms of the end result of the program. A higher level programming language such as PHP is supposed to try to hide such details from the programmer so that they can write clearer, more manageable code, and do it quickly.<br /><br />Unfortunately, years ago, using pass-by-reference a lot actually was very useful in terms of optimizing. Fortunately, that ended years ago, so now we no longer need to perform a reference assignment and hope that we remember not to change one variable when the other one is supposed to stay the same. By the time you read this the php that is sending these words to you may be running on a server that uses some kind of new exotic technology for which the word "pointer" no longer accurately describes anything, because the server stores both the program state and instructions intermingled in non-sequential atoms bonded into molecules which work by randomly bouncing off each other at high speeds, thereby exchanging atoms and crossbreeding their instructions and information in such a way as to, in aggregate, successfully run php 5 code. But the code itself will still have references that work the same way they did before, and you will therefore not have to think about whether the machine I just described makes any sense at all.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="86050">  <div class="votes">
    <div id="Vu86050">
    <a href="/manual/vote-note.php?id=86050&amp;page=language.oop5.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86050">
    <a href="/manual/vote-note.php?id=86050&amp;page=language.oop5.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86050" title="37% like this...">
    -4
    </div>
  </div>
  <a href="#86050" class="name">
  <strong class="user"><em>lazybones_senior</em></strong></a><a class="genanchor" href="#86050"> &para;</a><div class="date" title="2008-09-30 06:57"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86050">
<div class="phpcode"><code><span class="html">
WHOA... KEEP IT SIMPLE!<br /><br />In regards to secure_admin's note: You've used OOP to simplify PHP's ability to create and use object references. Now use PHP's static keyword to simplify your OOP.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">DataModelControl </span><span class="keyword">{<br />&nbsp; protected static </span><span class="default">$data </span><span class="keyword">= </span><span class="default">256</span><span class="keyword">; </span><span class="comment">// default value; <br />&nbsp; </span><span class="keyword">protected </span><span class="default">$name</span><span class="keyword">;<br /><br />&nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$dmcName</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">name </span><span class="keyword">= </span><span class="default">$dmcName</span><span class="keyword">;<br />&nbsp; }<br /><br />&nbsp; public static function </span><span class="default">setData</span><span class="keyword">(</span><span class="default">$dmcData</span><span class="keyword">) {<br />&nbsp; &nbsp; if(</span><span class="default">is_numeric</span><span class="keyword">(</span><span class="default">$dmcData</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">$data </span><span class="keyword">= </span><span class="default">$dmcData</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; }<br /><br />&nbsp; public function </span><span class="default">__toString</span><span class="keyword">() {<br />&nbsp; &nbsp; return </span><span class="string">"DataModelControl [name=</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">name</span><span class="string">, data=" </span><span class="keyword">. </span><span class="default">self</span><span class="keyword">::</span><span class="default">$data </span><span class="keyword">. </span><span class="string">"]"</span><span class="keyword">;<br />&nbsp; }&nbsp;&nbsp; <br />}<br /><br /></span><span class="comment"># create several instances of DataModelControl...<br /></span><span class="default">$dmc1 </span><span class="keyword">= new </span><span class="default">DataModelControl</span><span class="keyword">(</span><span class="string">'dmc1'</span><span class="keyword">);<br /></span><span class="default">$dmc2 </span><span class="keyword">= new </span><span class="default">DataModelControl</span><span class="keyword">(</span><span class="string">'dmc2'</span><span class="keyword">);<br /></span><span class="default">$dmc3 </span><span class="keyword">= new </span><span class="default">DataModelControl</span><span class="keyword">(</span><span class="string">'dmc3'</span><span class="keyword">);<br />echo </span><span class="default">$dmc1 </span><span class="keyword">. </span><span class="string">'&lt;br&gt;'</span><span class="keyword">;<br />echo </span><span class="default">$dmc2 </span><span class="keyword">. </span><span class="string">'&lt;br&gt;'</span><span class="keyword">;<br />echo </span><span class="default">$dmc3 </span><span class="keyword">. </span><span class="string">'&lt;br&gt;&lt;br&gt;'</span><span class="keyword">;<br /><br /></span><span class="comment"># To change data, use any DataModelControl object...<br /></span><span class="default">$dmc2</span><span class="keyword">-&gt;</span><span class="default">setData</span><span class="keyword">(</span><span class="default">512</span><span class="keyword">);<br /></span><span class="comment"># Or, call setData() directly from the class...<br /></span><span class="default">DataModelControl</span><span class="keyword">::</span><span class="default">setData</span><span class="keyword">(</span><span class="default">1024</span><span class="keyword">);<br />echo </span><span class="default">$dmc1 </span><span class="keyword">. </span><span class="string">'&lt;br&gt;'</span><span class="keyword">;<br />echo </span><span class="default">$dmc2 </span><span class="keyword">. </span><span class="string">'&lt;br&gt;'</span><span class="keyword">;<br />echo </span><span class="default">$dmc3 </span><span class="keyword">. </span><span class="string">'&lt;br&gt;&lt;br&gt;'</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br /> DataModelControl [name=dmc1, data=256]<br /> DataModelControl [name=dmc2, data=256]<br /> DataModelControl [name=dmc3, data=256]<br /><br /> DataModelControl [name=dmc1, data=1024]<br /> DataModelControl [name=dmc2, data=1024]<br /> DataModelControl [name=dmc3, data=1024]<br /><br />... even better! Now, PHP creates one copy of $data, that is shared amongst all DataModelControl objects.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113103">  <div class="votes">
    <div id="Vu113103">
    <a href="/manual/vote-note.php?id=113103&amp;page=language.oop5.references&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113103">
    <a href="/manual/vote-note.php?id=113103&amp;page=language.oop5.references&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113103" title="28% like this...">
    -6
    </div>
  </div>
  <a href="#113103" class="name">
  <strong class="user"><em>akam at akameng dot com</em></strong></a><a class="genanchor" href="#113103"> &para;</a><div class="date" title="2013-08-29 09:30"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113103">
<div class="phpcode"><code><span class="html">
Object is being referenced even after the original object deleted, so be careful when copying objects into your array. <br /><br /><span class="default">&lt;?php<br />$result </span><span class="keyword">= </span><span class="default">json_decode</span><span class="keyword">(</span><span class="string">' {"1":1377809496,"2":1377813096}'</span><span class="keyword">);<br /></span><span class="default">$copy1</span><span class="keyword">[</span><span class="string">'object'</span><span class="keyword">] = </span><span class="default">$result</span><span class="keyword">;<br /></span><span class="default">$copy2</span><span class="keyword">[</span><span class="string">'object'</span><span class="keyword">] = </span><span class="default">$result</span><span class="keyword">;<br /><br />unset(</span><span class="default">$result</span><span class="keyword">);<br /><br /></span><span class="comment">//now lets change $copy1['object'][1] to 'test';<br /></span><span class="default">$copy1</span><span class="keyword">[</span><span class="string">'object'</span><span class="keyword">]-&gt;{</span><span class="string">"1"</span><span class="keyword">} = </span><span class="string">'test'</span><span class="keyword">;<br /><br />echo (</span><span class="default">$copy1 </span><span class="keyword">=== </span><span class="default">$copy2</span><span class="keyword">) ? </span><span class="string">"Yes" </span><span class="keyword">: </span><span class="string">"No"</span><span class="keyword">;<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$copy2</span><span class="keyword">);<br /></span><span class="comment">/*<br />Array<br />(<br />&nbsp; &nbsp; [API] =&gt; stdClass Object<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [1] =&gt; test<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [2] =&gt; 1377813096<br />&nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />)<br />*/<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.oop5.references&amp;redirect=http://php.net/manual/en/language.oop5.references.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.oop5.php">Classes and Objects</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="oop5.intro.php" title="Introduction">Introduction</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.basic.php" title="The Basics">The Basics</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.properties.php" title="Properties">Properties</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.constants.php" title="Class Constants">Class Constants</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.autoload.php" title="Autoloading Classes">Autoloading Classes</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.decon.php" title="Constructors and Destructors">Constructors and Destructors</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.visibility.php" title="Visibility">Visibility</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.inheritance.php" title="Object Inheritance">Object Inheritance</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.paamayim-nekudotayim.php" title="Scope Resolution Operator (::)">Scope Resolution Operator (::)</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.static.php" title="Static Keyword">Static Keyword</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.abstract.php" title="Class Abstraction">Class Abstraction</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.interfaces.php" title="Object Interfaces">Object Interfaces</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.traits.php" title="Traits">Traits</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.anonymous.php" title="Anonymous classes">Anonymous classes</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.overloading.php" title="Overloading">Overloading</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.iterations.php" title="Object Iteration">Object Iteration</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.magic.php" title="Magic Methods">Magic Methods</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.final.php" title="Final Keyword">Final Keyword</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.cloning.php" title="Object Cloning">Object Cloning</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.object-comparison.php" title="Comparing Objects">Comparing Objects</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.typehinting.php" title="Type Hinting">Type Hinting</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.late-static-bindings.php" title="Late Static Bindings">Late Static Bindings</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.oop5.references.php" title="Objects and references">Objects and references</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.serialization.php" title="Object Serialization">Object Serialization</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.changelog.php" title="OOP Changelog">OOP Changelog</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

