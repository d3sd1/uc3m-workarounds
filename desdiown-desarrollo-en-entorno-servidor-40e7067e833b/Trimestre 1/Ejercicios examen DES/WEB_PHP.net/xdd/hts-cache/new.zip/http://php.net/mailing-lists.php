<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Mailing Lists</title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/mailing-lists.php">
 <link rel="shorturl" href="http://php.net/mailing-lists">
 <link rel="alternate" href="http://php.net/mailing-lists" hreflang="x-default">



<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/mailing-lists.php">

</head>
<body class="help ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class=""><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class="active"><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>





<div id="layout" class="clearfix">
  <section id="layout-content">
<h1>Mailing Lists</h1>

<p>
 There are many PHP-related mailing lists available on our server.
 Most of them are archived, and all of them are available as newsgroups
 on our <a href="news://news.php.net">news server</a>. You can search
 some mailing lists right from this website from <a href="/search.php">the
 search page</a> or by using the search input box selecting the
 appropriate option on the top-right of every page.
</p>
<p>
 There is an experimental web interface for the news server at
 <a href="http://news.php.net/">http://news.php.net/</a>, and
 there are also other archives provided by
 <a href="http://marc.info/">Marc</a>.
</p>

<h2>Twitter</h2>
<p>
 The PHP team maintains an official PHP.net account on twitter,
 <a href="https://twitter.com/official_php">@official_php</a>, for those
 interested in following news and other announcements from the PHP project.
</p>

<h2>Mailing List Posting guidelines</h2>

<p>
 When posting to mailing lists or newsgroups, please keep the following in mind:
</p>

<ul>
 <li>
  Use a valid email address. Every new poster's email address
  is checked for validity through confirmation.
 </li>
 <li>
  Send plain ASCII messages, no HTML-formatted emails please.
 </li>
 <li>
  Turn on word wrapping so your entire message doesn't show up on
  a single line.
 </li>
 <li>
  Be sure to click <strong>Reply-All</strong> to reply to list. Clicking
  <strong>Reply</strong> will email the author of the message privately.
 </li>
 <li>
  No attachments please, just post a URL if you want someone to
  look at something.
 </li>
 <li>
  Don't GPG/PGP sign your messages. If you want people to be able
  to send you encrypted email, stick your key-locator in your signature
 </li>
 <li>
  Don't hijack other peoples' threads. To post on a new topic, start
  a new message, don't reply and just change the subject.
 </li>
 <li>
  Check the archives before posting a question, chances are it has
  already been asked and answered a few times.
 </li>
 <li>
  When asking a question, don't just tell us, &quot;it doesn't work&quot;.
  Tell us what you are trying to accomplish, a <strong>short</strong> code
  snippet showing how you tried to solve it, what you expected to get and
  what you got instead.
 </li>
</ul>
<p>
 And make sure you have read our
 <a href="//git.php.net/?p=php-src.git;a=blob_plain;f=README.MAILINGLIST_RULES;hb=HEAD">Mailinglist Rules</a>.
</p>

<form method="post" action="/mailing-lists.php">

<h2 id="general">General Mailing Lists</h2>

<table cellpadding="5" border="0" class="standard mailing-lists">
<tr><th>General mailing lists for PHP users</th><th>Moderated</th><th>Archive</th><th>Newsgroup</th><th>Normal</th><th>Digest</th></tr>
<tr align="center"><td align="left"><strong>Announcements</strong><br><small>Announcements of new PHP releases are sent to this very low-volume list</small></td><td>yes</td><td>n/a</td><td><a href="news://news.php.net/php.announce">yes</a> <a href="http://news.php.net/group.php?group=php.announce">http</a></td><td><input name="maillist" type="radio" value="php-announce"></td><td>n/a</td></tr>
<tr align="center"><td align="left"><strong>General user list</strong><br><small>This is a high volume list for general PHP support; ask PHP questions here</small></td><td>no</td><td><a href="http://marc.info/?l=php-general">yes</a></td><td><a href="news://news.php.net/php.general">yes</a> <a href="http://news.php.net/group.php?group=php.general">http</a></td><td><input name="maillist" type="radio" value="php-general"></td><td><input name="maillist" type="radio" value="php-general-digest"></td></tr>
<tr align="center"><td align="left"><strong>Windows PHP users list</strong><br><small>Using PHP on Microsoft Windows</small></td><td>no</td><td><a href="http://marc.info/?l=php-windows">yes</a></td><td><a href="news://news.php.net/php.windows">yes</a> <a href="http://news.php.net/group.php?group=php.windows">http</a></td><td><input name="maillist" type="radio" value="php-windows"></td><td><input name="maillist" type="radio" value="php-windows-digest"></td></tr>
<tr><th>Subject specific lists for PHP users</th><th>Moderated</th><th>Archive</th><th>Newsgroup</th><th>Normal</th><th>Digest</th></tr>
<tr align="center"><td align="left"><strong>Installation issues and problems</strong><br><small>How to install PHP with particular configurations and servers</small></td><td>no</td><td><a href="http://marc.info/?l=php-install">yes</a></td><td><a href="news://news.php.net/php.install">yes</a> <a href="http://news.php.net/group.php?group=php.install">http</a></td><td><input name="maillist" type="radio" value="php-install"></td><td><input name="maillist" type="radio" value="php-install-digest"></td></tr>
<tr align="center"><td align="left"><strong>Databases and PHP</strong><br><small>This list is for the discussion of PHP database topics</small></td><td>no</td><td><a href="http://marc.info/?l=php-db">yes</a></td><td><a href="news://news.php.net/php.db">yes</a> <a href="http://news.php.net/group.php?group=php.db">http</a></td><td><input name="maillist" type="radio" value="php-db"></td><td><input name="maillist" type="radio" value="php-db-digest"></td></tr>
<tr align="center"><td align="left"><strong>Unicode and Internationalization</strong><br><small>Unicode support, Internationalization (i18n) and localization (l10n) issues and features</small></td><td>no</td><td><a href="http://marc.info/?l=php-i18n">yes</a></td><td><a href="news://news.php.net/php.i18n">yes</a> <a href="http://news.php.net/group.php?group=php.i18n">http</a></td><td><input name="maillist" type="radio" value="php-i18n"></td><td><input name="maillist" type="radio" value="php-i18n-digest"></td></tr>
<tr align="center"><td align="left"><strong>PHP evangelism mailing list</strong><br><small>A list for people interested in promoting PHP and learning good reasons to support PHP in the enterprise</small></td><td>yes</td><td><a href="http://marc.info/?l=php-evangelism">yes</a></td><td><a href="news://news.php.net/php.evangelism">yes</a> <a href="http://news.php.net/group.php?group=php.evangelism">http</a></td><td><input name="maillist" type="radio" value="php-evangelism"></td><td><input name="maillist" type="radio" value="php-evangelism-digest"></td></tr>
<tr align="center"><td align="left"><strong>PHP SOAP list</strong><br><small>List for the SOAP developers</small></td><td>no</td><td>n/a</td><td><a href="news://news.php.net/php.soap">yes</a> <a href="http://news.php.net/group.php?group=php.soap">http</a></td><td><input name="maillist" type="radio" value="soap"></td><td>n/a</td></tr>
<tr><th>Non-English language mailing lists</th><th>Moderated</th><th>Archive</th><th>Newsgroup</th><th>Normal</th><th>Digest</th></tr>
<tr align="center"><td align="left"><strong>Spanish PHP Mailing list</strong><br><small>List for Spanish speaking people interested in PHP</small></td><td>no</td><td>n/a</td><td><a href="news://news.php.net/php.general.es">yes</a> <a href="http://news.php.net/group.php?group=php.general.es">http</a></td><td><input name="maillist" type="radio" value="php-es"></td><td>n/a</td></tr>
</table>

<h2 id="internals">Internals Mailing Lists</h2>

<table cellpadding="5" border="0" class="standard mailing-lists">
<tr><th>PHP and Zend Engine internals lists</th><th>Moderated</th><th>Archive</th><th>Newsgroup</th><th>Normal</th><th>Digest</th></tr>
<tr align="center"><td align="left"><strong>Internals list</strong><br><small>A medium volume list for those who want to help out with the development of PHP</small></td><td>no</td><td><a href="http://marc.info/?l=php-internals">yes</a></td><td><a href="news://news.php.net/php.internals">yes</a> <a href="http://news.php.net/group.php?group=php.internals">http</a></td><td><input name="maillist" type="radio" value="internals"></td><td><input name="maillist" type="radio" value="internals-digest"></td></tr>
<tr align="center"><td align="left"><strong>Windows Internals list</strong><br><small>A low volume list for those who want to help out with the development of PHP on Windows</small></td><td>no</td><td>n/a</td><td><a href="news://news.php.net/php.internals.win">yes</a> <a href="http://news.php.net/group.php?group=php.internals.win">http</a></td><td><input name="maillist" type="radio" value="internals-win"></td><td><input name="maillist" type="radio" value="internals-win-digest"></td></tr>
<tr align="center"><td align="left"><strong>Git commit list</strong><br><small>All commits to internals (php-src) and the Zend Engine are posted to this list automatically</small></td><td>yes</td><td><a href="http://marc.info/?l=php-cvs">yes</a></td><td><a href="news://news.php.net/php.cvs">yes</a> <a href="http://news.php.net/group.php?group=php.cvs">http</a></td><td><input name="maillist" type="radio" value="php-cvs"></td><td>n/a</td></tr>
<tr align="center"><td align="left"><strong>Git pull requests</strong><br><small>Pull requests from Github</small></td><td>no</td><td>n/a</td><td><a href="news://news.php.net/php.git-pulls">yes</a> <a href="http://news.php.net/group.php?group=php.git-pulls">http</a></td><td><input name="maillist" type="radio" value="git-pulls"></td><td>n/a</td></tr>
<tr align="center"><td align="left"><strong>Quality Assurance list</strong><br><small>List for the members of the PHP-QA Team</small></td><td>no</td><td><a href="http://marc.info/?l=php-qa">yes</a></td><td><a href="news://news.php.net/php.qa">yes</a> <a href="http://news.php.net/group.php?group=php.qa">http</a></td><td><input name="maillist" type="radio" value="php-qa"></td><td>n/a</td></tr>
<tr align="center"><td align="left"><strong>General bugs</strong><br><small>General bug activity are posted here</small></td><td>no</td><td>n/a</td><td><a href="news://news.php.net/php.bugs">yes</a> <a href="http://news.php.net/group.php?group=php.bugs">http</a></td><td><input name="maillist" type="radio" value="php-bugs"></td><td>n/a</td></tr>
<tr align="center"><td align="left"><strong>PHP Standardization and interoperability list</strong><br><small>Development of language standards</small></td><td>no</td><td>n/a</td><td><a href="news://news.php.net/php.standards">yes</a> <a href="http://news.php.net/group.php?group=php.standards">http</a></td><td><input name="maillist" type="radio" value="standards"></td><td>n/a</td></tr>
<tr><th>PHP internal website mailing lists</th><th>Moderated</th><th>Archive</th><th>Newsgroup</th><th>Normal</th><th>Digest</th></tr>
<tr align="center"><td align="left"><strong>PHP php.net internal infrastructure discussion</strong><br><small>List for discussing and maintaining the php.net web infrastructure.<br>
       For general PHP support questions, see "General Mailing Lists" or the <a href="/support.php">support page</a></small></td><td>no</td><td>n/a</td><td><a href="news://news.php.net/php.webmaster">yes</a> <a href="http://news.php.net/group.php?group=php.webmaster">http</a></td><td><input name="maillist" type="radio" value="php-webmaster"></td><td>n/a</td></tr>
<tr><th>PHP documentation mailing lists</th><th>Moderated</th><th>Archive</th><th>Newsgroup</th><th>Normal</th><th>Digest</th></tr>
<tr align="center"><td align="left"><strong>Documentation discussion</strong><br><small>List for discussing the PHP documentation</small></td><td>no</td><td><a href="http://marc.info/?l=phpdoc">yes</a></td><td><a href="news://news.php.net/php.doc">yes</a> <a href="http://news.php.net/group.php?group=php.doc">http</a></td><td><input name="maillist" type="radio" value="phpdoc"></td><td>n/a</td></tr>
<tr align="center"><td align="left"><strong>Documentation changes and commits</strong><br><small>Changes to the documentation are posted here</small></td><td>yes</td><td><a href="http://marc.info/?l=php-doc-cvs">yes</a></td><td><a href="news://news.php.net/php.doc.cvs">yes</a> <a href="http://news.php.net/group.php?group=php.doc.cvs">http</a></td><td><input name="maillist" type="radio" value="doc-cvs"></td><td>n/a</td></tr>
<tr align="center"><td align="left"><strong>Documentation bugs</strong><br><small>Documentation bug activity (translations, sources, and build system) are posted here</small></td><td>yes</td><td><a href="http://marc.info/?l=php-doc-bugs">yes</a></td><td><a href="news://news.php.net/php.doc.bugs">yes</a> <a href="http://news.php.net/group.php?group=php.doc.bugs">http</a></td><td><input name="maillist" type="radio" value="doc-bugs"></td><td>n/a</td></tr>
</table>

<p class="center">
 <strong>Email:</strong>
 <input type="text" name="email" size="40" value="user@example.com">
 <input type="submit" name="action" value="Subscribe">
 <input type="submit" name="action" value="Unsubscribe">
</p>

</form>

<p>
 You will be sent a confirmation mail at the address you wish to
 be subscribed or unsubscribed, and only added to the list after
 following the directions in that mail.
</p>

<p>
 <strong>Warning:</strong> The PHP users mailing list gets close to 1500-2000
 messages per month currently. Do the math. That translates to about 60
 messages per day. If your mailbox can't handle this sort of traffic you
 might want to consider subscribing to the digest list instead (two messages
 per day), using the news server, or reading the mailing list using the
 archives. 
</p>

<h2>Mailing list options</h2>

<p>
 All of the mailing lists hosted at <a
 href="http://lists.php.net/">lists.php.net</a> are managed using the <a
 href="http://untroubled.org/ezmlm/">ezmlm-idx</a> mailing list software.
 There are a variety of commands you can use to modify your subscription.
 Either send a message to <code>php-whatever-help@lists.php.net</code> (as in,
 <code>php-general-help@lists.php.net</code>) or you can view the commands for
 ezmlm <a href="http://untroubled.org/ezmlm/ezman/ezman1.html">here.</a>
</p>

    </section><!-- layout-content -->
    

  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

