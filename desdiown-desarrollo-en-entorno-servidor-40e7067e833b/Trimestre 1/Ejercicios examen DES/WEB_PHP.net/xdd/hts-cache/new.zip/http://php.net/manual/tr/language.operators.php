<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="tr">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: İşle&ccedil;ler - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/tr/language.operators.php">
 <link rel="shorturl" href="http://php.net/operators">
 <link rel="alternate" href="http://php.net/operators" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/tr/index.php">
 <link rel="index" href="http://php.net/manual/tr/langref.php">
 <link rel="prev" href="http://php.net/manual/tr/language.expressions.php">
 <link rel="next" href="http://php.net/manual/tr/language.operators.precedence.php">

 <link rel="alternate" href="http://php.net/manual/en/language.operators.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.operators.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.operators.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.operators.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.operators.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.operators.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.operators.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.operators.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.operators.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.operators.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/tr/language.operators.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.operators.precedence.php">
          İşle&ccedil; &Ouml;nceliği &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.expressions.php">
          &laquo; İfadeler        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Kılavuzu</a></li>      <li><a href='langref.php'>Dil Başvuru Kılavuzu</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.operators.php'>English</option>
            <option value='pt_BR/language.operators.php'>Brazilian Portuguese</option>
            <option value='zh/language.operators.php'>Chinese (Simplified)</option>
            <option value='fr/language.operators.php'>French</option>
            <option value='de/language.operators.php'>German</option>
            <option value='ja/language.operators.php'>Japanese</option>
            <option value='ro/language.operators.php'>Romanian</option>
            <option value='ru/language.operators.php'>Russian</option>
            <option value='es/language.operators.php'>Spanish</option>
            <option value='tr/language.operators.php' selected="selected">Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=tr/language.operators.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.operators">Report a Bug</a>
    </div>
  </div><div id="language.operators" class="chapter">
  <h1>İşleçler</h1>
<h2>İçindekiler</h2><ul class="chunklist chunklist_chapter"><li><a href="language.operators.precedence.php">İşle&ccedil; &Ouml;nceliği</a></li><li><a href="language.operators.arithmetic.php">Aritmetik İşle&ccedil;ler</a></li><li><a href="language.operators.assignment.php">Atama İşle&ccedil;leri</a></li><li><a href="language.operators.bitwise.php">Bitsel İşle&ccedil;ler</a></li><li><a href="language.operators.comparison.php">Karşılaştırma İşle&ccedil;leri</a></li><li><a href="language.operators.errorcontrol.php">Hata Denetim İşle&ccedil;leri</a></li><li><a href="language.operators.execution.php">&Ccedil;alıştırma İşleci</a></li><li><a href="language.operators.increment.php">Arttırım ve Eksiltim İşle&ccedil;leri</a></li><li><a href="language.operators.logical.php">Mantıksal İşle&ccedil;ler</a></li><li><a href="language.operators.string.php">Dizge İşle&ccedil;leri</a></li><li><a href="language.operators.array.php">Dizi İşle&ccedil;leri</a></li><li><a href="language.operators.type.php">T&uuml;r İşle&ccedil;leri</a></li></ul>

  <p class="simpara">
    Bir işleç, başka bir değer üretmek üzere bir veya daha fazla değerle
    (programcı dilinde ifadeyle) beslenen bir şeydir (yani, değerler işleçle
    birlikte bir ifade haline gelir). Bu bakımdan, bir değer döndüren
    işlevler ve benzeri oluşumlar (print gibi) ya da belirtilenden başka bir
    şey döndürmeyen (echo gibi) oluşumlar birer işleç olarak düşünülebilir.
  </p>
  <p class="para">
   Üç tür işleç vardır. İlki tek bir değerle çalışan tek terimli işleç olup
   ! (olumsuzlama işleci) veya ++ (arttırım işleci) buna birer örnektir.
   İkinci işleç grubu iki terimlilerdir; PHP&#039;nin desteklediği işleçlerin
   çoğunluğu bu grupta olup aşağıda <a href="language.operators.precedence.php" class="link">İşleç Önceliği</a> bölümünde
   liste halinde verilmişlerdir.
  </p>
  <p class="para">
   Üçüncü grupta üç terimli işleç yer alır: ?:.  Bir ifadeye bağlı olarak
   iki deyim veya çalıştırma yolunu seçmekten ziyade diğer iki ifadeden
   birini seçmek için kullanılır. İşlecin üç ifadesini parantez içinde
   belirtmek iyi bir uygulamadır.
  </p>

  

  

  

  

  

  

  

  

  

  

  
  
 </div>

<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.operators&amp;redirect=http://php.net/manual/tr/language.operators.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">13 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="43111">  <div class="votes">
    <div id="Vu43111">
    <a href="/manual/vote-note.php?id=43111&amp;page=language.operators&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd43111">
    <a href="/manual/vote-note.php?id=43111&amp;page=language.operators&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V43111" title="66% like this...">
    203
    </div>
  </div>
  <a href="#43111" class="name"><strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#43111"> &para;</a><div class="date" title="2004-06-09 05:58"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom43111">
<div class="phpcode"><code><span class="html">
of course this should be clear, but i think it has to be mentioned espacially:<br /><br />AND is not the same like &amp;&amp;<br /><br />for example:<br /><br /><span class="default">&lt;?php $a </span><span class="keyword">&amp;&amp; </span><span class="default">$b </span><span class="keyword">|| </span><span class="default">$c</span><span class="keyword">; </span><span class="default">?&gt;<br /></span>is not the same like<br /><span class="default">&lt;?php $a </span><span class="keyword">AND </span><span class="default">$b </span><span class="keyword">|| </span><span class="default">$c</span><span class="keyword">; </span><span class="default">?&gt;<br /></span><br />the first thing is<br />(a and b) or c<br /><br />the second<br />a and (b or c)<br /><br />'cause || has got a higher priority than and, but less than &amp;&amp;<br /><br />of course, using always [ &amp;&amp; and || ] or [ AND and OR ] would be okay, but than you should at least respect the following:<br /><br /><span class="default">&lt;?php $a </span><span class="keyword">= </span><span class="default">$b </span><span class="keyword">&amp;&amp; </span><span class="default">$c</span><span class="keyword">; </span><span class="default">?&gt;<br />&lt;?php $a </span><span class="keyword">= </span><span class="default">$b </span><span class="keyword">AND </span><span class="default">$c</span><span class="keyword">; </span><span class="default">?&gt;<br /></span><br />the first code will set $a to the result of the comparison $b with $c, both have to be true, while the second code line will set $a like $b and THAN - after that - compare the success of this with the value of $c<br /><br />maybe usefull for some tricky coding and helpfull to prevent bugs :D<br /><br />greetz, Warhog</span>
</code></div>
  </div>
 </div>
  <div class="note" id="12147">  <div class="votes">
    <div id="Vu12147">
    <a href="/manual/vote-note.php?id=12147&amp;page=language.operators&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd12147">
    <a href="/manual/vote-note.php?id=12147&amp;page=language.operators&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V12147" title="55% like this...">
    19
    </div>
  </div>
  <a href="#12147" class="name">
  <strong class="user"><em>yasuo_ohgaki at hotmail dot com</em></strong></a><a class="genanchor" href="#12147"> &para;</a><div class="date" title="2001-03-25 11:53"><strong>16 years ago</strong></div>
  <div class="text" id="Hcom12147">
<div class="phpcode"><code><span class="html">
Other Language books' operator precedence section usually include "(" and ")" - with exception of a Perl book that I have. (In PHP "{" and "}" should also be considered also). However, PHP Manual is not listed "(" and ")" in precedence list. It looks like "(" and ")" has higher precedence as it should be.<br /><br />Note: If you write following code, you would need "()" to get expected value.<br /><br /><span class="default">&lt;?php<br />$bar </span><span class="keyword">= </span><span class="default">true</span><span class="keyword">;<br /></span><span class="default">$str </span><span class="keyword">= </span><span class="string">"TEST"</span><span class="keyword">. (</span><span class="default">$bar </span><span class="keyword">? </span><span class="string">'true' </span><span class="keyword">: </span><span class="string">'false'</span><span class="keyword">) .</span><span class="string">"TEST"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />Without "(" and ")" you will get only "true" in $str. <br />(PHP4.0.4pl1/Apache DSO/Linux, PHP4.0.5RC1/Apache DSO/W2K Server)<br />It's due to precedence, probably.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="84862">  <div class="votes">
    <div id="Vu84862">
    <a href="/manual/vote-note.php?id=84862&amp;page=language.operators&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd84862">
    <a href="/manual/vote-note.php?id=84862&amp;page=language.operators&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V84862" title="52% like this...">
    7
    </div>
  </div>
  <a href="#84862" class="name">
  <strong class="user"><em>figroc at gmail dot com</em></strong></a><a class="genanchor" href="#84862"> &para;</a><div class="date" title="2008-08-02 03:30"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom84862">
<div class="phpcode"><code><span class="html">
The variable symbol '$' should be considered as the highest-precedence operator, so that the variable variables such as $$a[0] won't confuse the parser.&nbsp; [<a href="http://www.php.net/manual/en/language.variables.variable.php]" rel="nofollow" target="_blank">http://www.php.net/manual/en/language.variables.variable.php]</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="78911">  <div class="votes">
    <div id="Vu78911">
    <a href="/manual/vote-note.php?id=78911&amp;page=language.operators&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd78911">
    <a href="/manual/vote-note.php?id=78911&amp;page=language.operators&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V78911" title="50% like this...">
    0
    </div>
  </div>
  <a href="#78911" class="name">
  <strong class="user"><em>phpnet dot 20 dot dpnsubs at xoxy dot net</em></strong></a><a class="genanchor" href="#78911"> &para;</a><div class="date" title="2007-11-01 02:13"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom78911">
<div class="phpcode"><code><span class="html">
Note that in php the ternary operator ?: has a left associativity unlike in C and C++ where it has right associativity.<br /><br />You cannot write code like this (as you may have accustomed to in C/C++):<br /><br /><span class="default">&lt;?php<br />$a </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">;<br />echo (<br />&nbsp; &nbsp; </span><span class="default">$a </span><span class="keyword">== </span><span class="default">1 </span><span class="keyword">? </span><span class="string">'one' </span><span class="keyword">: <br />&nbsp; &nbsp; </span><span class="default">$a </span><span class="keyword">== </span><span class="default">2 </span><span class="keyword">? </span><span class="string">'two' </span><span class="keyword">: <br />&nbsp; &nbsp; </span><span class="default">$a </span><span class="keyword">== </span><span class="default">3 </span><span class="keyword">? </span><span class="string">'three' </span><span class="keyword">: <br />&nbsp; &nbsp; </span><span class="default">$a </span><span class="keyword">== </span><span class="default">4 </span><span class="keyword">? </span><span class="string">'four' </span><span class="keyword">: </span><span class="string">'other'</span><span class="keyword">);<br />echo </span><span class="string">"\n"</span><span class="keyword">;<br /></span><span class="comment">// prints 'four'<br /></span><span class="default">?&gt;<br /></span><br />You need to add brackets to get the results you want:<br /><br /><span class="default">&lt;?php<br />$a </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">;<br /><br />echo (</span><span class="default">$a </span><span class="keyword">== </span><span class="default">1 </span><span class="keyword">? </span><span class="string">'one' </span><span class="keyword">: <br />&nbsp; &nbsp; &nbsp; &nbsp; (</span><span class="default">$a </span><span class="keyword">== </span><span class="default">2 </span><span class="keyword">? </span><span class="string">'two' </span><span class="keyword">: <br />&nbsp; &nbsp; &nbsp; &nbsp; (</span><span class="default">$a </span><span class="keyword">== </span><span class="default">3 </span><span class="keyword">? </span><span class="string">'three' </span><span class="keyword">: <br />&nbsp; &nbsp; &nbsp; &nbsp; (</span><span class="default">$a </span><span class="keyword">== </span><span class="default">4 </span><span class="keyword">? </span><span class="string">'four' </span><span class="keyword">: </span><span class="string">'other'</span><span class="keyword">) ) ) );<br />echo </span><span class="string">"\n"</span><span class="keyword">;<br /></span><span class="comment">//prints 'two'<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="78358">  <div class="votes">
    <div id="Vu78358">
    <a href="/manual/vote-note.php?id=78358&amp;page=language.operators&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd78358">
    <a href="/manual/vote-note.php?id=78358&amp;page=language.operators&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V78358" title="44% like this...">
    -15
    </div>
  </div>
  <a href="#78358" class="name">
  <strong class="user"><em>janturon at email dot cz</em></strong></a><a class="genanchor" href="#78358"> &para;</a><div class="date" title="2007-10-08 06:42"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom78358">
<div class="phpcode"><code><span class="html">
This is very common problem: set one variable to another, if it is not empty. If it is, set it to something else.<br />For example: set $bar to $foo, if $foo is empty, set $bar to "undefined";<br /><br />if(!empty($foo)) $bar= $foo; else $bar= "undefined";<br /><br />OR operator can shorten it:<br /><br />$bar= @$foo or $bar= "undefined";</span>
</code></div>
  </div>
 </div>
  <div class="note" id="67997">  <div class="votes">
    <div id="Vu67997">
    <a href="/manual/vote-note.php?id=67997&amp;page=language.operators&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd67997">
    <a href="/manual/vote-note.php?id=67997&amp;page=language.operators&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V67997" title="45% like this...">
    -16
    </div>
  </div>
  <a href="#67997" class="name">
  <strong class="user"><em>golotyuk at gmail dot com</em></strong></a><a class="genanchor" href="#67997"> &para;</a><div class="date" title="2006-07-09 09:51"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom67997">
<div class="phpcode"><code><span class="html">
Simple POST and PRE incremnt sample:<br /><br /><span class="default">&lt;?php<br /><br />$b </span><span class="keyword">= </span><span class="default">5</span><span class="keyword">;<br /></span><span class="default">$a </span><span class="keyword">= ( ( ++</span><span class="default">$b </span><span class="keyword">) &gt; </span><span class="default">5 </span><span class="keyword">); </span><span class="comment">// Pre-increment test<br /></span><span class="keyword">echo (int)</span><span class="default">$a</span><span class="keyword">;<br /><br /></span><span class="default">$b </span><span class="keyword">= </span><span class="default">5</span><span class="keyword">;<br /></span><span class="default">$a </span><span class="keyword">= ( ( </span><span class="default">$b</span><span class="keyword">++ ) &gt; </span><span class="default">5 </span><span class="keyword">); </span><span class="comment">// Post-increment test<br /></span><span class="keyword">echo (int)</span><span class="default">$a</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;<br /></span><br />This will output 10, because of the difference in post- and pre-increment operations</span>
</code></div>
  </div>
 </div>
  <div class="note" id="75641">  <div class="votes">
    <div id="Vu75641">
    <a href="/manual/vote-note.php?id=75641&amp;page=language.operators&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd75641">
    <a href="/manual/vote-note.php?id=75641&amp;page=language.operators&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V75641" title="44% like this...">
    -15
    </div>
  </div>
  <a href="#75641" class="name">
  <strong class="user"><em>madcoder at gmail dot com</em></strong></a><a class="genanchor" href="#75641"> &para;</a><div class="date" title="2007-06-09 03:17"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom75641">
<div class="phpcode"><code><span class="html">
In response to mathiasrav at gmail dot com:<br /><br />The reason for that behavior is the parentheses.&nbsp; From the description:<br /><br />"Parentheses may be used to force precedence, if necessary. For instance: (1 + 5) * 3 evaluates to 18."<br /><br />So the order of operations says that even though the equality operator has higher precedence, the parentheses in your statement force the assignment operator to a higher precedence than the equality operator.<br /><br />That said, it still doesn't work the way you expect it to.&nbsp; Neither way works, for these reasons:<br /><span class="default">&lt;?php<br /></span><span class="keyword">if ( </span><span class="default">$a </span><span class="keyword">!= (</span><span class="default">$a </span><span class="keyword">= </span><span class="default">$b</span><span class="keyword">) )<br /></span><span class="default">?&gt;<br /></span><br />Order of operations says to do the parentheses first.&nbsp; So you end up with:<br /><span class="default">&lt;?php<br />$a </span><span class="keyword">= </span><span class="default">$b</span><span class="keyword">;<br />if ( </span><span class="default">$a </span><span class="keyword">!= </span><span class="default">$a </span><span class="keyword">)<br /></span><span class="default">?&gt;<br /></span><br />Which is obviously going to be false.&nbsp; Without the parentheses:<br /><span class="default">&lt;?php<br /></span><span class="keyword">if ( </span><span class="default">$a </span><span class="keyword">!= </span><span class="default">$a </span><span class="keyword">= </span><span class="default">$b </span><span class="keyword">)<br /></span><span class="default">?&gt;<br /></span><br />Order of operations says to do the inequality first, then the assignment, so you have:<br /><span class="default">&lt;?php<br /></span><span class="keyword">if ( </span><span class="default">$a </span><span class="keyword">!= </span><span class="default">$a </span><span class="keyword">);<br /></span><span class="default">$a </span><span class="keyword">= </span><span class="default">$b</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />Which again is not what you expected, and again will always be false.&nbsp; But because you are only working with values of 0 and 1, you can make use of the XOR operator:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">if ( </span><span class="default">$a </span><span class="keyword">^= </span><span class="default">$b </span><span class="keyword">)<br /></span><span class="default">?&gt;<br /></span><br />This will only be true if 1) $a is 0 and $b is 1, or 2) $a is 1 and $b is 0.&nbsp; That is precisely what you wanted, and it even does the assignment the way you expected it to.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">foreach (</span><span class="default">$ourstring </span><span class="keyword">as </span><span class="default">$c</span><span class="keyword">) {<br />&nbsp; if (</span><span class="default">$bold </span><span class="keyword">^= </span><span class="default">$c</span><span class="keyword">[</span><span class="string">'bold'</span><span class="keyword">]) </span><span class="default">$resstring </span><span class="keyword">.= </span><span class="default">bold</span><span class="keyword">;<br />&nbsp; if (</span><span class="default">$underline </span><span class="keyword">^= </span><span class="default">$c</span><span class="keyword">[</span><span class="string">'underline'</span><span class="keyword">]) </span><span class="default">$resstring </span><span class="keyword">.= </span><span class="default">underline</span><span class="keyword">;<br />&nbsp; </span><span class="default">$resstring </span><span class="keyword">.= </span><span class="default">$c</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">];<br />}<br /></span><span class="default">?&gt;<br /></span><br />That code now works and produces the output you expected.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="56433">  <div class="votes">
    <div id="Vu56433">
    <a href="/manual/vote-note.php?id=56433&amp;page=language.operators&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd56433">
    <a href="/manual/vote-note.php?id=56433&amp;page=language.operators&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V56433" title="43% like this...">
    -21
    </div>
  </div>
  <a href="#56433" class="name">
  <strong class="user"><em>rick at nomorespam dot fourfront dot ltd dot uk</em></strong></a><a class="genanchor" href="#56433"> &para;</a><div class="date" title="2005-09-02 03:51"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom56433">
<div class="phpcode"><code><span class="html">
A quick note to any C developers out there, assignment expressions are not interpreted as you may expect - take the following code ;-<br /><br /><span class="default">&lt;?php<br />$a</span><span class="keyword">=array(</span><span class="default">1</span><span class="keyword">,</span><span class="default">2</span><span class="keyword">,</span><span class="default">3</span><span class="keyword">);<br /></span><span class="default">$b</span><span class="keyword">=array(</span><span class="default">4</span><span class="keyword">,</span><span class="default">5</span><span class="keyword">,</span><span class="default">6</span><span class="keyword">);<br /></span><span class="default">$c</span><span class="keyword">=</span><span class="default">1</span><span class="keyword">;<br /><br /></span><span class="default">$a</span><span class="keyword">[</span><span class="default">$c</span><span class="keyword">++]=</span><span class="default">$b</span><span class="keyword">[</span><span class="default">$c</span><span class="keyword">++];<br /><br /></span><span class="default">print_r</span><span class="keyword">( </span><span class="default">$a </span><span class="keyword">) ;<br /></span><span class="default">?&gt;<br /></span><br />This will output;-<br />Array ( [0] =&gt; 1 [1] =&gt; 6 [2] =&gt; 3 )<br />as if the code said;-<br />$a[1]=$b[2];<br /><br />Under a C compiler the result is;-<br />Array ( [0] =&gt; 1 [1] =&gt; 5 [2] =&gt; 3 )<br />as if the code said;-<br />$a[1]=$b[1];<br /><br />It would appear that in php the increment in the left side of the assignment is processed prior to processing the right side of the assignment, whereas in C, neither increment occurs until after the assignment.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="76385">  <div class="votes">
    <div id="Vu76385">
    <a href="/manual/vote-note.php?id=76385&amp;page=language.operators&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd76385">
    <a href="/manual/vote-note.php?id=76385&amp;page=language.operators&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V76385" title="42% like this...">
    -24
    </div>
  </div>
  <a href="#76385" class="name">
  <strong class="user"><em>me at robrosenbaum dot com</em></strong></a><a class="genanchor" href="#76385"> &para;</a><div class="date" title="2007-07-12 12:16"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom76385">
<div class="phpcode"><code><span class="html">
The scope resolution operator ::, which is missing from the list above, has higher precedence than [], and lower precedence than 'new'. This means that self::$array[$var] works as expected.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="87904">  <div class="votes">
    <div id="Vu87904">
    <a href="/manual/vote-note.php?id=87904&amp;page=language.operators&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd87904">
    <a href="/manual/vote-note.php?id=87904&amp;page=language.operators&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V87904" title="41% like this...">
    -31
    </div>
  </div>
  <a href="#87904" class="name">
  <strong class="user"><em>pgarvin76+php dot net at NOSPAMgmail dot com</em></strong></a><a class="genanchor" href="#87904"> &para;</a><div class="date" title="2008-12-29 04:43"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom87904">
<div class="phpcode"><code><span class="html">
Method chaining is read left to right (left associative):<br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">Test_Method_Chain<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">One</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"One" </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">Two</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Two" </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">Three</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Three" </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$test </span><span class="keyword">= new </span><span class="default">Test_Method_Chain</span><span class="keyword">();<br /><br /></span><span class="default">$test</span><span class="keyword">-&gt;</span><span class="default">One</span><span class="keyword">()-&gt;</span><span class="default">Two</span><span class="keyword">()-&gt;</span><span class="default">Three</span><span class="keyword">();<br /><br /></span><span class="comment">/* Ouputs:<br />One<br />Two<br />Three<br />*/<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="78397">  <div class="votes">
    <div id="Vu78397">
    <a href="/manual/vote-note.php?id=78397&amp;page=language.operators&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd78397">
    <a href="/manual/vote-note.php?id=78397&amp;page=language.operators&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V78397" title="39% like this...">
    -29
    </div>
  </div>
  <a href="#78397" class="name">
  <strong class="user"><em>Gautam</em></strong></a><a class="genanchor" href="#78397"> &para;</a><div class="date" title="2007-10-10 03:22"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom78397">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br /><br />$result1 </span><span class="keyword">= </span><span class="default">7 </span><span class="keyword">+ </span><span class="default">8 </span><span class="keyword">* </span><span class="default">9</span><span class="keyword">/</span><span class="default">3 </span><span class="keyword">-</span><span class="default">4</span><span class="keyword">;<br /></span><span class="default">$result2 </span><span class="keyword">= </span><span class="default">7 </span><span class="keyword">+ </span><span class="default">8 </span><span class="keyword">* (</span><span class="default">9</span><span class="keyword">/</span><span class="default">3 </span><span class="keyword">-</span><span class="default">4</span><span class="keyword">);<br /></span><span class="default">$result3 </span><span class="keyword">=(</span><span class="default">7 </span><span class="keyword">+ </span><span class="default">8</span><span class="keyword">)* </span><span class="default">9</span><span class="keyword">/</span><span class="default">3 </span><span class="keyword">-</span><span class="default">4</span><span class="keyword">;<br /><br />echo </span><span class="string">"Result1 for 7 + 8 * 9/3 -4 = </span><span class="default">$result1</span><span class="string">&nbsp; Result2 for 7 + 8 * (9/3 -4) = </span><span class="default">$result2</span><span class="string"> and Result3 (7 + 8)* 9/3 -4 = </span><span class="default">$result3</span><span class="string"> "<br /></span><span class="comment">/*<br /> which gives results as under<br /> Result1 for 7 + 8 * 9/3 -4 = 27 Result2 for 7 + 8 * (9/3 -4) = -1 and Result3 (7 + 8)* 9/3 -4 = 41<br /> Execution Order is 1) expression in brackets 2) division 3) multiplication 4) addition and 5) subtraction <br />*/<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117461">  <div class="votes">
    <div id="Vu117461">
    <a href="/manual/vote-note.php?id=117461&amp;page=language.operators&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117461">
    <a href="/manual/vote-note.php?id=117461&amp;page=language.operators&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117461" title="36% like this...">
    -24
    </div>
  </div>
  <a href="#117461" class="name">
  <strong class="user"><em>arth dot inbox+php dot net at gmail dot com</em></strong></a><a class="genanchor" href="#117461"> &para;</a><div class="date" title="2015-06-12 02:51"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117461">
<div class="phpcode"><code><span class="html">
&amp;= operator.<br /><br />It is binary and followed expressions give different results:<br /><br />$a = $b = 1;<br />echo $a &amp;= 2;&nbsp; // 0<br />echo $a = $a &amp;&amp; 2; // 1</span>
</code></div>
  </div>
 </div>
  <div class="note" id="86566">  <div class="votes">
    <div id="Vu86566">
    <a href="/manual/vote-note.php?id=86566&amp;page=language.operators&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86566">
    <a href="/manual/vote-note.php?id=86566&amp;page=language.operators&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86566" title="32% like this...">
    -105
    </div>
  </div>
  <a href="#86566" class="name">
  <strong class="user"><em>ddascalescu at gmail dot com</em></strong></a><a class="genanchor" href="#86566"> &para;</a><div class="date" title="2008-10-23 06:53"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86566">
<div class="phpcode"><code><span class="html">
The -&gt; operator, not listed above, is called "object operator" (T_OBJECT_OPERATOR).</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.operators&amp;redirect=http://php.net/manual/tr/language.operators.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="langref.php">Dil Başvuru Kılavuzu</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.basic-syntax.php" title="Temel S&ouml;zdizimi">Temel S&ouml;zdizimi</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.php" title="T&uuml;rler">T&uuml;rler</a>
                        </li>
                          
                        <li class="">
                            <a href="language.variables.php" title="Değişkenler">Değişkenler</a>
                        </li>
                          
                        <li class="">
                            <a href="language.constants.php" title="Sabitler">Sabitler</a>
                        </li>
                          
                        <li class="">
                            <a href="language.expressions.php" title="İfadeler">İfadeler</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.operators.php" title="İşle&ccedil;ler">İşle&ccedil;ler</a>
                        </li>
                          
                        <li class="">
                            <a href="language.control-structures.php" title="Denetim Yapıları">Denetim Yapıları</a>
                        </li>
                          
                        <li class="">
                            <a href="language.functions.php" title="İşlevler">İşlevler</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.php" title="Sınıflar ve Nesneler">Sınıflar ve Nesneler</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.php" title="İsim Alanları">İsim Alanları</a>
                        </li>
                          
                        <li class="">
                            <a href="language.errors.php" title="Errors">Errors</a>
                        </li>
                          
                        <li class="">
                            <a href="language.exceptions.php" title="İstisnalar">İstisnalar</a>
                        </li>
                          
                        <li class="">
                            <a href="language.generators.php" title="Generators">Generators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.references.php" title="G&ouml;nderimlerle İlgili Herşey">G&ouml;nderimlerle İlgili Herşey</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.php" title="&Ouml;ntanımlı Değişkenler">&Ouml;ntanımlı Değişkenler</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.exceptions.php" title="&Ouml;ntanımlı İstisnalar">&Ouml;ntanımlı İstisnalar</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.interfaces.php" title="&Ouml;ntanımlı Aray&uuml;zler ve Sınıflar">&Ouml;ntanımlı Aray&uuml;zler ve Sınıflar</a>
                        </li>
                          
                        <li class="">
                            <a href="context.php" title="Bağlam se&ccedil;enekleri ve değiştirgeleri">Bağlam se&ccedil;enekleri ve değiştirgeleri</a>
                        </li>
                          
                        <li class="">
                            <a href="wrappers.php" title="Supported Protocols and Wrappers">Supported Protocols and Wrappers</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

