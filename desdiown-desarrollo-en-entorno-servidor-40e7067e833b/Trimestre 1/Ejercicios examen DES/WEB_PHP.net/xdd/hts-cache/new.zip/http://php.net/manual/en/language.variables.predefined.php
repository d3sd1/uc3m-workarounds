<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Predefined Variables - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.variables.predefined.php">
 <link rel="shorturl" href="http://php.net/variables.predefined">
 <link rel="alternate" href="http://php.net/variables.predefined" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.variables.php">
 <link rel="prev" href="http://php.net/manual/en/language.variables.basics.php">
 <link rel="next" href="http://php.net/manual/en/language.variables.scope.php">

 <link rel="alternate" href="http://php.net/manual/en/language.variables.predefined.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.variables.predefined.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.variables.predefined.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.variables.predefined.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.variables.predefined.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.variables.predefined.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.variables.predefined.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.variables.predefined.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.variables.predefined.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.variables.predefined.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.variables.predefined.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.variables.scope.php">
          Variable scope &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.variables.basics.php">
          &laquo; Basics        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.variables.php'>Variables</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.variables.predefined.php' selected="selected">English</option>
            <option value='pt_BR/language.variables.predefined.php'>Brazilian Portuguese</option>
            <option value='zh/language.variables.predefined.php'>Chinese (Simplified)</option>
            <option value='fr/language.variables.predefined.php'>French</option>
            <option value='de/language.variables.predefined.php'>German</option>
            <option value='ja/language.variables.predefined.php'>Japanese</option>
            <option value='ro/language.variables.predefined.php'>Romanian</option>
            <option value='ru/language.variables.predefined.php'>Russian</option>
            <option value='es/language.variables.predefined.php'>Spanish</option>
            <option value='tr/language.variables.predefined.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.variables.predefined.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.variables.predefined">Report a Bug</a>
    </div>
  </div><div id="language.variables.predefined" class="sect1">
   <h2 class="title">Predefined Variables</h2>
   
   <p class="simpara">
    PHP provides a large number of predefined variables to any script
    which it runs. Many of these variables, however, cannot be fully
    documented as they are dependent upon which server is running, the
    version and setup of the server, and other factors. Some of these
    variables will not be available when PHP is run on the 
    <a href="features.commandline.php" class="link">command line</a>. 
    For a listing of these variables, please see the section on 
    <a href="reserved.variables.php" class="link">Reserved Predefined Variables</a>.
   </p>

   <div class="warning"><strong class="warning">Warning</strong>
    <p class="simpara">
     In PHP 4.2.0 and later, the default value for the PHP directive <a href="ini.core.php#ini.register-globals" class="link">register_globals</a> is 
     <em class="emphasis">off</em>. This is a major change in PHP.  Having 
     register_globals <em class="emphasis">off</em> affects the set of predefined 
     variables available in the global scope.  For example, to get 
     <var class="varname"><var class="varname">DOCUMENT_ROOT</var></var> you&#039;ll use 
     <var class="varname"><var class="varname"><a href="reserved.variables.server.php" class="classname">$_SERVER['DOCUMENT_ROOT']</a></var></var> instead of 
     <var class="varname"><var class="varname">$DOCUMENT_ROOT</var></var>, or <var class="varname"><var class="varname"><a href="reserved.variables.get.php" class="classname">$_GET['id']</a></var></var> from 
     the URL <em>http://www.example.com/test.php?id=3</em> instead 
     of <var class="varname"><var class="varname">$id</var></var>, or <var class="varname"><var class="varname"><a href="reserved.variables.environment.php" class="classname">$_ENV['HOME']</a></var></var> instead of 
     <var class="varname"><var class="varname">$HOME</var></var>.
    </p>
    <p class="simpara">
     For related information on this change, read the configuration entry for 
     <a href="ini.core.php#ini.register-globals" class="link">register_globals</a>, the security 
     chapter on <a href="security.globals.php" class="link">Using Register Globals
     </a>, as well as the PHP <a href="http://www.php.net/releases/4_1_0.php" class="link external">&raquo;&nbsp;4.1.0
     </a> and <a href="http://www.php.net/releases/4_2_0.php" class="link external">&raquo;&nbsp;4.2.0</a> Release 
     Announcements.
    </p>
    <p class="simpara">
     Using the available PHP Reserved Predefined Variables, like the 
     <a href="language.variables.superglobals.php" class="link">superglobal arrays</a>, 
     is preferred.
    </p>
   </div>

   <p class="simpara">
    From version 4.1.0 onward, PHP provides an additional set of predefined arrays
    containing variables from the web server (if applicable), the
    environment, and user input. These new arrays are rather special
    in that they are automatically global--i.e., automatically
    available in every scope. For this reason, they are often known as
    &quot;superglobals&quot;. (There is no mechanism in PHP for
    user-defined superglobals.) The superglobals are listed below;
    however, for a listing of their contents and further discussion on
    PHP predefined variables and their natures, please see the section
    <a href="reserved.variables.php" class="link">Reserved Predefined Variables</a>.  
    Also, you&#039;ll notice how the older predefined variables 
    (<var class="varname"><var class="varname">$HTTP_*_VARS</var></var>) still exist.

    As of PHP 5.0.0, the long PHP
<a href="language.variables.predefined.php" class="link">predefined variable</a>
arrays may be disabled with the
<a href="ini.core.php#ini.register-long-arrays" class="link">register_long_arrays</a>
directive.
   </p>
   
   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <strong>Variable variables</strong><br />
    <p class="para">
     Superglobals cannot be used as 
     <a href="language.variables.variable.php" class="link">variable variables</a>
     inside functions or class methods.
    </p>
   </p></blockquote>

   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <p class="para">
     Even though both the superglobal and <em>HTTP_*_VARS</em> can exist at the same
     time; they are not identical, so modifying one will not change the other.
    </p>
   </p></blockquote>

   <p class="para">
    If certain variables in <a href="ini.core.php#ini.variables-order" class="link">variables_order</a> are not set, their
    appropriate PHP predefined arrays are also left empty.
   </p>
  </div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.variables.predefined&amp;redirect=http://php.net/manual/en/language.variables.predefined.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">35 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="64336">  <div class="votes">
    <div id="Vu64336">
    <a href="/manual/vote-note.php?id=64336&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd64336">
    <a href="/manual/vote-note.php?id=64336&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V64336" title="76% like this...">
    69
    </div>
  </div>
  <a href="#64336" class="name">
  <strong class="user"><em>johnphayes at gmail dot com</em></strong></a><a class="genanchor" href="#64336"> &para;</a><div class="date" title="2006-04-12 10:36"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom64336">
<div class="phpcode"><code><span class="html">
I haven't found it anywhere else in the manual, so I'll make a note of it here - PHP will automatically replace any dots ('.') in an incoming variable name with underscores ('_'). So if you have dots in your incoming variables, e.g.:<br /><br />example.com/page.php?chuck.norris=nevercries<br /><br />you can not reference them by the name used in the URI:<br />//INCORRECT<br />echo $_GET['chuck.norris'];<br /><br />instead you must use:<br />//CORRECT<br />echo $_GET['chuck_norris'];</span>
</code></div>
  </div>
 </div>
  <div class="note" id="56289">  <div class="votes">
    <div id="Vu56289">
    <a href="/manual/vote-note.php?id=56289&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd56289">
    <a href="/manual/vote-note.php?id=56289&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V56289" title="76% like this...">
    9
    </div>
  </div>
  <a href="#56289" class="name">
  <strong class="user"><em>webdesign at benking dot com</em></strong></a><a class="genanchor" href="#56289"> &para;</a><div class="date" title="2005-08-29 02:33"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom56289">
<div class="phpcode"><code><span class="html">
# this is a follow-up to kasey at cornerspeed's 14-Jun-2004 08:33 post and debabratak at softhome's 14-Mar-2003 12:59 post, minus sessions but including a safety mechanism to block unwanted variables...<br /><br /># if you are like me and do not want to have to type $_POST[some_var] to get to all your passed variable data, you can safely convert all the data to the variable names (so it is like old style php) by using a pre-defined allowed arg names list like this;<br /><br />$allowed_args = ',f_name,l_name,subject,msg,';<br /><br />foreach(array_keys($_POST) as $k) {<br />&nbsp; &nbsp; $temp = ",$k,";<br />&nbsp; &nbsp; if(strpos($allowed_args,$temp) !== false) { $$k = $_POST[$k]; }<br />}<br /><br /># then you can use the programmer friendly (less typing) vars like so;<br />echo "Hello $f_name";<br /><br /># make sure you have commas in front of and after each var name in the $allowed_args list, so strpos will never surprise you by mistakingly finding an unwanted var name within another var name</span>
</code></div>
  </div>
 </div>
  <div class="note" id="50044">  <div class="votes">
    <div id="Vu50044">
    <a href="/manual/vote-note.php?id=50044&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd50044">
    <a href="/manual/vote-note.php?id=50044&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V50044" title="73% like this...">
    11
    </div>
  </div>
  <a href="#50044" class="name"><strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#50044"> &para;</a><div class="date" title="2005-02-16 04:35"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom50044">
<div class="phpcode"><code><span class="html">
php.net uses this<br /><br />// Backward compatible array creation. After this point, the<br />// PHP 4.1.0+ arrays can be used to access variables coming<br />// from outside PHP. But it should be noted that these variables<br />// are not necessarily superglobals, so they need to be global-ed!<br />if (!isset($_SERVER))<br />{<br />&nbsp; &nbsp; $_GET&nbsp; &nbsp;&nbsp; = &amp;$HTTP_GET_VARS;<br />&nbsp; &nbsp; $_POST&nbsp; &nbsp; = &amp;$HTTP_POST_VARS;<br />&nbsp; &nbsp; $_ENV&nbsp; &nbsp;&nbsp; = &amp;$HTTP_ENV_VARS;<br />&nbsp; &nbsp; $_SERVER&nbsp; = &amp;$HTTP_SERVER_VARS;<br />&nbsp; &nbsp; $_COOKIE&nbsp; = &amp;$HTTP_COOKIE_VARS;<br />&nbsp; &nbsp; $_REQUEST = array_merge($_GET, $_POST, $_COOKIE);<br />}<br /><br />$PHP_SELF = $_SERVER['PHP_SELF'];</span>
</code></div>
  </div>
 </div>
  <div class="note" id="28614">  <div class="votes">
    <div id="Vu28614">
    <a href="/manual/vote-note.php?id=28614&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd28614">
    <a href="/manual/vote-note.php?id=28614&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V28614" title="73% like this...">
    9
    </div>
  </div>
  <a href="#28614" class="name">
  <strong class="user"><em>lopez dot on dot the dot lists at yellowspace dot net</em></strong></a><a class="genanchor" href="#28614"> &para;</a><div class="date" title="2003-01-17 06:11"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom28614">
<div class="phpcode"><code><span class="html">
- Security Issue and workaround - <br />If You use "eval()" to execute code stored in a database or elsewhere, you might find this tip useful.<br /><br />Issue:<br />By default, all superglobals are known in every function. <br />Thus, if you eval database- or dynamically generated code (let's call it "potentially unsafe code"), it can use _all_ the values stored in _any_ superglobal. <br /><br />Workaround:<br />Whenever you want to hide superglobals from use in evaluated code, wrap that eval() in an own function within which you unset() all the superglobals. The superglobals are not deleted by php in all scopes - just within that function. eg:<br /><br />function safeEval($evalcode) {<br />&nbsp; &nbsp; unset($GLOBALS);<br />&nbsp; &nbsp; unset($_ENV);<br />&nbsp; &nbsp; // unset any other superglobal...<br />&nbsp; &nbsp; return eval($evalcode);<br />}<br /><br />(This example assumes that the eval returns something with 'return')<br /><br />In addition, by defining such a function outside classes, in the global scope, you'll make sure as well that the evaluated ('unsafe') code doesn't have access to the object variables ($this-&gt; ...).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="63312">  <div class="votes">
    <div id="Vu63312">
    <a href="/manual/vote-note.php?id=63312&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd63312">
    <a href="/manual/vote-note.php?id=63312&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V63312" title="66% like this...">
    15
    </div>
  </div>
  <a href="#63312" class="name">
  <strong class="user"><em>DD32=theonly_DD32[&amp;amp;]yahoo.com.au</em></strong></a><a class="genanchor" href="#63312"> &para;</a><div class="date" title="2006-03-19 05:43"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom63312">
<div class="phpcode"><code><span class="html">
I have this function in my main files, it allows for easier SEO for some pages without having to rely on .htaccess and mod_rewrite for some things.<br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">function </span><span class="default">long_to_GET</span><span class="keyword">(){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp; &nbsp; &nbsp; * This function converts info.php/a/1/b/2/c?d=4 TO<br />&nbsp; &nbsp; &nbsp; &nbsp; * Array ( [d] =&gt; 4 [a] =&gt; 1 [b] =&gt; 2 [c] =&gt; ) <br />&nbsp; &nbsp; &nbsp; &nbsp; **/<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">if(isset(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PATH_INFO'</span><span class="keyword">]) &amp;&amp; </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PATH_INFO'</span><span class="keyword">] != </span><span class="string">''</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//Split it out.<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$tmp </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">(</span><span class="string">'/'</span><span class="keyword">,</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PATH_INFO'</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//Remove first empty item<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">unset(</span><span class="default">$tmp</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//Loop through and apend it into the $_GET superglobal.<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">for(</span><span class="default">$i</span><span class="keyword">=</span><span class="default">1</span><span class="keyword">;</span><span class="default">$i</span><span class="keyword">&lt;=</span><span class="default">count</span><span class="keyword">(</span><span class="default">$tmp</span><span class="keyword">);</span><span class="default">$i</span><span class="keyword">+=</span><span class="default">2</span><span class="keyword">){ </span><span class="default">$_GET</span><span class="keyword">[</span><span class="default">$tmp</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">]] = </span><span class="default">$tmp</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">+</span><span class="default">1</span><span class="keyword">];}<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /></span><span class="default">?&gt;<br /></span><br />Its probably not the most efficient, but it does the job rather nicely.<br /><br />DD32</span>
</code></div>
  </div>
 </div>
  <div class="note" id="23063">  <div class="votes">
    <div id="Vu23063">
    <a href="/manual/vote-note.php?id=23063&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd23063">
    <a href="/manual/vote-note.php?id=23063&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V23063" title="72% like this...">
    5
    </div>
  </div>
  <a href="#23063" class="name"><strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#23063"> &para;</a><div class="date" title="2002-07-08 01:46"><strong>15 years ago</strong></div>
  <div class="text" id="Hcom23063">
<div class="phpcode"><code><span class="html">
Wouldn't it be great if there was a variable called $_SERVER["PATH_USERHOME"]. Here is how to set it yourself:<br /><br />$path_fs = split ("/", ltrim ($_SERVER["PATH_TRANSLATED"], "/"));<br />$path_fs_rev = array_reverse ($path_fs);<br /><br />$path_http = split ("/", ltrim ($_SERVER["PHP_SELF"], "/"));<br />$path_http_rev = array_reverse ($path_http);<br /><br />$num_same = 0;<br />while ($path_fs_rev[$num_same] == $path_http_rev[$num_same]) {<br />&nbsp; &nbsp; $num_same++;<br />}<br /><br />$path_userhome = array ();<br />$numdirs_userhome = sizeof ($path_http) - $num_same;<br />echo $numdirs_userhome;<br /><br />for ($i = 0; $i &lt; $numdirs_userhome; $i++) {<br />&nbsp; &nbsp; array_push ($path_userhome, $path_http[$i]);<br />}<br /><br />$_SERVER["PATH_USERHOME"] = "/" . implode ("/", $path_userhome) . "/";<br /><br />print_r ($_SERVER["PATH_USERHOME"]);<br /><br />;) Happy programming,<br /><br />Peder</span>
</code></div>
  </div>
 </div>
  <div class="note" id="9776">  <div class="votes">
    <div id="Vu9776">
    <a href="/manual/vote-note.php?id=9776&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd9776">
    <a href="/manual/vote-note.php?id=9776&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V9776" title="61% like this...">
    11
    </div>
  </div>
  <a href="#9776" class="name">
  <strong class="user"><em>mike at dbeat dot com</em></strong></a><a class="genanchor" href="#9776"> &para;</a><div class="date" title="2000-11-22 06:30"><strong>17 years ago</strong></div>
  <div class="text" id="Hcom9776">
<div class="phpcode"><code><span class="html">
If you're running PHP as a shell script, and you want to use the argv and argc arrays to get command-line arguments, make sure you have register_argc_argv&nbsp; =&nbsp; on.&nbsp; If you're using the 'optimized' php.ini, this defaults to off.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="72829">  <div class="votes">
    <div id="Vu72829">
    <a href="/manual/vote-note.php?id=72829&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd72829">
    <a href="/manual/vote-note.php?id=72829&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V72829" title="62% like this...">
    4
    </div>
  </div>
  <a href="#72829" class="name">
  <strong class="user"><em>holger at doessing dot net</em></strong></a><a class="genanchor" href="#72829"> &para;</a><div class="date" title="2007-02-02 06:07"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom72829">
<div class="phpcode"><code><span class="html">
On the subject of permalinks and queries:<br />Say, you use an inexpensive subdomain of (e.g.) www.nice.net, thus www.very.nice.net, and that the domain owner has simply placed a frame at this particular location, linking to the actual address (ugly and subject-to-change) of your site.<br />Consequently, the actual site URI and various associated hashes and query strings are not immediately visible to the user. Sometimes this is useful, but it also makes bookmarking/permalinking impossible (the browser will only bookmark the static address in the top frame).<br />However, as far as the query strings go, there is workaround. Instead of providing users with permalinks to the actual URI (e.g. prtcl://weird.and.ugly/~very/ugly.php?stuff=here; may even be subject to change), I provide them with this: prtcl://www.very.nice.net?stuff=here.<br /><br />In brief, I then use the following code to re-populate the $_GET array:<br /><br />if (isset($_SERVER['HTTP_REFERER'])) { // If set, this page is running in a frame<br />&nbsp; &nbsp; $uri = parse_url($_SERVER['HTTP_REFERER']); // grab URI of parent frame<br />&nbsp; &nbsp; $querystring = ($uri['query']) ? $uri['query'] : false; // grab the querystring<br />&nbsp; &nbsp; if ($querystring) {<br />&nbsp; &nbsp; &nbsp; &nbsp; $vars = explode('&amp;', $querystring); // cut into individual statements<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach ($vars as $varstring) { // populate $_GET<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $var = explode('=', $varstring);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (count($var) == 2) $_GET[$var[0]] = $var[1];<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; } // no, nothing to report from the parent frame<br />} // no, not using a parent frame today...<br /><br />If the actual host address is ever changed, users entering the frame (with the nicer address) will be using the new (and ugly) URI, but this way the old query strings will be available to the new address also. The users will never again be bothered by you moving to another neighborhood.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="29386">  <div class="votes">
    <div id="Vu29386">
    <a href="/manual/vote-note.php?id=29386&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd29386">
    <a href="/manual/vote-note.php?id=29386&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V29386" title="62% like this...">
    2
    </div>
  </div>
  <a href="#29386" class="name"><strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#29386"> &para;</a><div class="date" title="2003-02-11 10:12"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom29386">
<div class="phpcode"><code><span class="html">
i just noticed that the free web server i'm running my scripts on still only knows the deprecated variable names (i.e. it uses $HTTP_POST_VARS instead of $_POST). to make scripts work both on updated servers and servers that are a bit out of date, i now use:<br /><br />$variablename=(isset($_POST["variablename"])) ? $_POST["variablename"] : $HTTP_POST_VARS["variablename"];</span>
</code></div>
  </div>
 </div>
  <div class="note" id="52857">  <div class="votes">
    <div id="Vu52857">
    <a href="/manual/vote-note.php?id=52857&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd52857">
    <a href="/manual/vote-note.php?id=52857&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V52857" title="60% like this...">
    4
    </div>
  </div>
  <a href="#52857" class="name">
  <strong class="user"><em>dompody [at] gmail [dot] com</em></strong></a><a class="genanchor" href="#52857"> &para;</a><div class="date" title="2005-05-15 05:08"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom52857">
<div class="phpcode"><code><span class="html">
To urbanheroes:<br /><br />version_compare() is only in PHP version 4.1.0 and up. This completely negates your function, since if the version is less than 4.1.0 it will generate an error anyway. The better solution is to do what is stated in the post above yours:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">if (!isset(</span><span class="default">$_SERVER</span><span class="keyword">))<br />{<br />&nbsp;&nbsp; </span><span class="default">$_GET&nbsp; &nbsp; </span><span class="keyword">= &amp;</span><span class="default">$HTTP_GET_VARS</span><span class="keyword">;<br />&nbsp;&nbsp; </span><span class="default">$_POST&nbsp; &nbsp; </span><span class="keyword">= &amp;</span><span class="default">$HTTP_POST_VARS</span><span class="keyword">;<br />&nbsp;&nbsp; </span><span class="default">$_ENV&nbsp; &nbsp; </span><span class="keyword">= &amp;</span><span class="default">$HTTP_ENV_VARS</span><span class="keyword">;<br />&nbsp;&nbsp; </span><span class="default">$_SERVER&nbsp; </span><span class="keyword">= &amp;</span><span class="default">$HTTP_SERVER_VARS</span><span class="keyword">;<br />&nbsp;&nbsp; </span><span class="default">$_COOKIE&nbsp; </span><span class="keyword">= &amp;</span><span class="default">$HTTP_COOKIE_VARS</span><span class="keyword">;<br />&nbsp;&nbsp; </span><span class="default">$_REQUEST </span><span class="keyword">= </span><span class="default">array_merge</span><span class="keyword">(</span><span class="default">$_GET</span><span class="keyword">, </span><span class="default">$_POST</span><span class="keyword">, </span><span class="default">$_COOKIE</span><span class="keyword">);<br />}<br /></span><span class="default">?&gt;<br /></span><br />Include that before everything else in your script and it will fix the flaw.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="65659">  <div class="votes">
    <div id="Vu65659">
    <a href="/manual/vote-note.php?id=65659&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd65659">
    <a href="/manual/vote-note.php?id=65659&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V65659" title="60% like this...">
    2
    </div>
  </div>
  <a href="#65659" class="name">
  <strong class="user"><em>Iñigo Medina</em></strong></a><a class="genanchor" href="#65659"> &para;</a><div class="date" title="2006-05-05 01:22"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom65659">
<div class="phpcode"><code><span class="html">
It is true. I usually write variables in this way: $chuckNorrisFilms. So one almost never finds problems.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="30678">  <div class="votes">
    <div id="Vu30678">
    <a href="/manual/vote-note.php?id=30678&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd30678">
    <a href="/manual/vote-note.php?id=30678&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V30678" title="59% like this...">
    4
    </div>
  </div>
  <a href="#30678" class="name">
  <strong class="user"><em>LouisGreen at pljg dot freeserve dot co dot uk</em></strong></a><a class="genanchor" href="#30678"> &para;</a><div class="date" title="2003-03-25 10:22"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom30678">
<div class="phpcode"><code><span class="html">
It seems that when you wish to export a varible, you can do it as return $varible, return an array(), or globalise it. If you return something, information for that varible can only travel one way when the script is running, and that is out of the function. <br /><br />function fn() {<br />&nbsp;&nbsp; $varible = "something";<br /><br />&nbsp; return $variable;<br />}<br /><br />echo fn();<br />OR<br />$newvariable = fn();<br /><br />Although if global was used, it creates a pointer to a varible, whether it existed or not, and makes whatever is created in the function linked to that global pointer. So if the pointer was global $varible, and then you set a value to $varible, it would then be accessible in the global scope. But then what if you later on in the script redefine that global to equal something else. This means that whatever is put into the global array, the information that is set in the pointer, can be set at any point (overiden). Here is an example that might make this a little clearer:<br /><br />function fn1() {<br /><br />&nbsp;&nbsp; global $varible; // Pointer to the global array<br />&nbsp;&nbsp; $varible = "something";<br />}<br /><br />fn1();<br />echo $varible; // Prints something<br />$varible = "12345";<br />echo $varible; // Prints 12345<br /><br />function fn2() {<br /><br />&nbsp;&nbsp; global $varible; // Pointer to the global array<br />&nbsp;&nbsp; echo $varible;<br />}<br /><br />fn2(); // echos $varible which contains "12345"<br /><br />Basically when accessing the global array, you can set it refer to something already defined or set it to something, (a pointer) such as varible you plan to create in the function, and later possibly over ride the pointer with something else.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="80794">  <div class="votes">
    <div id="Vu80794">
    <a href="/manual/vote-note.php?id=80794&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd80794">
    <a href="/manual/vote-note.php?id=80794&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V80794" title="57% like this...">
    2
    </div>
  </div>
  <a href="#80794" class="name">
  <strong class="user"><em>root at mantoru dot de</em></strong></a><a class="genanchor" href="#80794"> &para;</a><div class="date" title="2008-01-31 12:56"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom80794">
<div class="phpcode"><code><span class="html">
To tokie at hanmail dot net: You took that out of context -- it is merely a recommendation.<br /><br />If your variables_order setting does not contain "E", $_ENV is still useful. Every call to getenv will be "cached" in $_ENV, so you can do this:<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">// variables_order = GPCS<br /></span><span class="default">var_dump</span><span class="keyword">(isset(</span><span class="default">$_ENV</span><span class="keyword">[</span><span class="string">'PATH'</span><span class="keyword">])); </span><span class="comment">// bool(false)<br /></span><span class="default">getenv</span><span class="keyword">(</span><span class="string">'PATH'</span><span class="keyword">);<br /></span><span class="default">var_dump</span><span class="keyword">(isset(</span><span class="default">$_ENV</span><span class="keyword">[</span><span class="string">'PATH'</span><span class="keyword">])); </span><span class="comment">// bool(true)<br /></span><span class="default">?&gt;<br /></span><br />For some reason, it does not work with with own environment variables. The above example with PHP_TEST instead of PATH would fail (if it is set via putenv).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="36167">  <div class="votes">
    <div id="Vu36167">
    <a href="/manual/vote-note.php?id=36167&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd36167">
    <a href="/manual/vote-note.php?id=36167&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V36167" title="57% like this...">
    2
    </div>
  </div>
  <a href="#36167" class="name">
  <strong class="user"><em>wagner at cesnet dot cz</em></strong></a><a class="genanchor" href="#36167"> &para;</a><div class="date" title="2003-09-29 08:15"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom36167">
<div class="phpcode"><code><span class="html">
The redirected pages by response codes 301, 302, 303 change the request method always to GET, that's why $HTTP_POST_VARS are lost. It is described in Apache documentation.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="74620">  <div class="votes">
    <div id="Vu74620">
    <a href="/manual/vote-note.php?id=74620&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd74620">
    <a href="/manual/vote-note.php?id=74620&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V74620" title="54% like this...">
    2
    </div>
  </div>
  <a href="#74620" class="name">
  <strong class="user"><em>pinkgothic at gmail dot com</em></strong></a><a class="genanchor" href="#74620"> &para;</a><div class="date" title="2007-04-20 07:15"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom74620">
<div class="phpcode"><code><span class="html">
Dealing with "superglobals" and functions is not as straightforward as it may seem when you're doing plenty manipulations.<br /><br />For example:<br /><br /><span class="default">&lt;?php<br />&nbsp; </span><span class="keyword">function </span><span class="default">some_other_method</span><span class="keyword">() {<br />&nbsp; &nbsp; echo </span><span class="default">$_REQUEST</span><span class="keyword">[</span><span class="string">'id'</span><span class="keyword">];<br />&nbsp; }<br />&nbsp; function </span><span class="default">some_method</span><span class="keyword">() {<br />&nbsp; &nbsp; </span><span class="default">$_REQUEST</span><span class="keyword">[</span><span class="string">'id'</span><span class="keyword">] = </span><span class="default">440</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">some_other_method</span><span class="keyword">();<br />&nbsp; }<br /></span><span class="default">?&gt;<br /></span><br />Calling some_method() will cause a warning-level error by PHP informing you that "id" is not set in some_other_method(). However, if you instead use:<br /><br /><span class="default">&lt;?php<br />&nbsp; $_REQUEST</span><span class="keyword">[</span><span class="string">'id'</span><span class="keyword">] = </span><span class="default">0</span><span class="keyword">;<br />&nbsp; function </span><span class="default">some_other_method</span><span class="keyword">() {<br />&nbsp; &nbsp; echo </span><span class="default">$_REQUEST</span><span class="keyword">[</span><span class="string">'id'</span><span class="keyword">];<br />&nbsp; }<br />&nbsp; function </span><span class="default">some_method</span><span class="keyword">() {<br />&nbsp; &nbsp; </span><span class="default">$_REQUEST</span><span class="keyword">[</span><span class="string">'id'</span><span class="keyword">] = </span><span class="default">440</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">some_other_method</span><span class="keyword">();<br />&nbsp; }<br /></span><span class="default">?&gt;<br /></span><br />Then the script will echo 440.<br /><br />In consequence, if you manually attempt to add keys to the superglobals, those keys *aren't* automatically superglobal. The above example isn't very sensible, of course, but this can be a huge gotcha if you're juggling user data between functions and you're unwittingly being forced to work inside a function (e.g. via PHP include in TYPO3).<br /><br />Unfortunately, global $_REQUEST['id'] won't save you, either - it causes a parse error - nor will a global $_REQUEST change anything after you've set the keys... consequently making it hard to conviniently 'hack' outdated scripts by making them believe they're still running in a different environment.<br /><br />The only "solution" to this issue is to use parameters.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="68765">  <div class="votes">
    <div id="Vu68765">
    <a href="/manual/vote-note.php?id=68765&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd68765">
    <a href="/manual/vote-note.php?id=68765&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V68765" title="53% like this...">
    1
    </div>
  </div>
  <a href="#68765" class="name">
  <strong class="user"><em>yarco dot w at gmail dot com</em></strong></a><a class="genanchor" href="#68765"> &para;</a><div class="date" title="2006-08-09 07:13"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom68765">
<div class="phpcode"><code><span class="html">
And you should know<br /><br />$_POST is not a reference of $HTTP_POST_VARS<br /><br />So, if you change $_POST, there are no change to $HTTP_POST_VARS.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="30278">  <div class="votes">
    <div id="Vu30278">
    <a href="/manual/vote-note.php?id=30278&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd30278">
    <a href="/manual/vote-note.php?id=30278&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V30278" title="53% like this...">
    2
    </div>
  </div>
  <a href="#30278" class="name">
  <strong class="user"><em>LouisGreen at pljg dot freeserve dot co dot uk</em></strong></a><a class="genanchor" href="#30278"> &para;</a><div class="date" title="2003-03-12 02:36"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom30278">
<div class="phpcode"><code><span class="html">
If you require access to Predefined Variables in different PHP/ servers versions and don't wish to mess about with how you access them, this little snippet of code might help you:<br /><br />function fn_http_vars_access() {<br /><br />&nbsp;&nbsp; global $GET_VARS, $POST_VARS, $COOKIE_VARS, $SESSION_VARS, $SERVER_VARS, $ENV_VARS;<br /><br />&nbsp;&nbsp; $parser_version = phpversion();<br /><br />&nbsp;&nbsp; if ($parser_version &lt;= "4.1.0") { <br />&nbsp; &nbsp; &nbsp; $GET_VARS&nbsp; &nbsp; &nbsp; = $GET_VARS;<br />&nbsp; &nbsp; &nbsp; $POST_VARS&nbsp; &nbsp;&nbsp; = $POST_VARS;<br />&nbsp; &nbsp; &nbsp; $COOKIE_VARS&nbsp;&nbsp; = $COOKIE_VARS;<br />&nbsp; &nbsp; &nbsp; $SESSION_VARS&nbsp; = $HTTP_SESSION_VARS;<br />&nbsp; &nbsp; &nbsp; $SERVER_VARS&nbsp;&nbsp; = $HTTP_SERVER_VARS;<br />&nbsp; &nbsp; &nbsp; $ENV_VARS&nbsp; &nbsp; &nbsp; = $HTTP_ENV_VARS;<br />&nbsp;&nbsp; }<br />&nbsp;&nbsp; if ($parser_version &gt;= "4.1.0") { <br />&nbsp; &nbsp; &nbsp; $GET_VARS&nbsp; &nbsp; &nbsp; = $_GET;<br />&nbsp; &nbsp; &nbsp; $POST_VARS&nbsp; &nbsp;&nbsp; = $_POST;<br />&nbsp; &nbsp; &nbsp; $COOKIE_VARS&nbsp;&nbsp; = $_COOKIE;<br />&nbsp; &nbsp; &nbsp; $SESSION_VARS&nbsp; = $_SESSION;<br />&nbsp; &nbsp; &nbsp; $SERVER_VARS&nbsp;&nbsp; = $_SERVER;<br />&nbsp; &nbsp; &nbsp; $ENV_VARS&nbsp; &nbsp; &nbsp; = $_ENV;<br />&nbsp;&nbsp; }<br />}<br /><br />fn_http_vars_access();</span>
</code></div>
  </div>
 </div>
  <div class="note" id="63708">  <div class="votes">
    <div id="Vu63708">
    <a href="/manual/vote-note.php?id=63708&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd63708">
    <a href="/manual/vote-note.php?id=63708&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V63708" title="50% like this...">
    0
    </div>
  </div>
  <a href="#63708" class="name">
  <strong class="user"><em>jk at ricochetsolutions dot com</em></strong></a><a class="genanchor" href="#63708"> &para;</a><div class="date" title="2006-03-28 01:41"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom63708">
<div class="phpcode"><code><span class="html">
here is a one line snippet to do the same as DD32's func<br /><br />@preg_replace(<br />&nbsp;&nbsp; "/(?i)([a-z0-9_]+)\/([a-z0-9_]+)\/?/e", <br />&nbsp;&nbsp; '$_GET[\'$1\'] = "$2";', <br />&nbsp;&nbsp; ((isset($_SERVER['PATH_INFO'])) ? $_SERVER['PATH_INFO'] : '')<br />);<br /><br />may be faster, it may not ;o</span>
</code></div>
  </div>
 </div>
  <div class="note" id="52304">  <div class="votes">
    <div id="Vu52304">
    <a href="/manual/vote-note.php?id=52304&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd52304">
    <a href="/manual/vote-note.php?id=52304&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V52304" title="50% like this...">
    0
    </div>
  </div>
  <a href="#52304" class="name">
  <strong class="user"><em>myfirstname dot barros at gmail dot com</em></strong></a><a class="genanchor" href="#52304"> &para;</a><div class="date" title="2005-04-27 07:10"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom52304">
<div class="phpcode"><code><span class="html">
vars in $_REQUEST are *not* a reference to the respective $_POST and $_GET and $_COOKIE ones.<br /><br />Consider:<br /><a href="http://site.com/index.php?avar=abc" rel="nofollow" target="_blank">http://site.com/index.php?avar=abc</a><br /><br />index.php:<br /><span class="default">&lt;?php<br />$_GET</span><span class="keyword">[</span><span class="string">'avar'</span><span class="keyword">] = </span><span class="string">'b'</span><span class="keyword">;<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$_GET</span><span class="keyword">); print(</span><span class="string">'&lt;br&gt;'</span><span class="keyword">);<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$_REQUEST</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />output:<br />Array ( [avar] =&gt; 'b' )<br />Array ( [avar] =&gt; 'abc' )</span>
</code></div>
  </div>
 </div>
  <div class="note" id="41656">  <div class="votes">
    <div id="Vu41656">
    <a href="/manual/vote-note.php?id=41656&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd41656">
    <a href="/manual/vote-note.php?id=41656&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V41656" title="50% like this...">
    0
    </div>
  </div>
  <a href="#41656" class="name">
  <strong class="user"><em>marcbender_AT_mail_DOT_com</em></strong></a><a class="genanchor" href="#41656"> &para;</a><div class="date" title="2004-04-18 02:23"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom41656">
<div class="phpcode"><code><span class="html">
-Security issue-<br /><br />In response to lopez at yellowspace,<br /><br />You provided a method for executing potentially unsafe code:<br /><br />&gt; function safeEval($evalcode) {<br />&gt;&nbsp; &nbsp; unset($GLOBALS);<br />&gt;&nbsp; &nbsp; unset($_ENV);<br />&gt;&nbsp; &nbsp; // unset any other superglobal...<br />&gt;&nbsp; &nbsp; return eval($evalcode);<br />&gt; }<br /><br />Your method, though clever, won't work.&nbsp; The problem is the way that PHP handles function scope.&nbsp; If $evalcode contains a function declaration, and runs that function, the "unset"s will be effectively useless inside the body of that function.<br /><br />Try running the above code with $evalcode set as follows:<br /><br /><span class="default">&lt;?php<br />$evalcode</span><span class="keyword">=</span><span class="string">'f();<br />function f() {<br />&nbsp;&nbsp; $GLOBALS["_SERVER"] = "compromised";<br />}'</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />Then print $_SERVER and see what you get.<br /><br />Another problem is that the "global" directive will always grant access to global variables.&nbsp; Try this one:<br /><br /><span class="default">&lt;?php<br />$evalcode</span><span class="keyword">=</span><span class="string">'global $a;<br />$a = "compromised";'</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />$a will of course be changed at the global level.&nbsp; I don't know if it's supposed to work this way, but on my system (PHP 4.3.4) you can do the same to any superglobal by importing it using "global".<br /><br />As far as I can tell, there is NO way to execute potentially unsafe code without a lot of risk.&nbsp; With the sloppy way that PHP deals with function scope etc., there isn't much hope that it ever will be.&nbsp; What we'd need is (at least):<br />&nbsp; - a way to disable the "global" directive (restrictive eval).<br />&nbsp; - a way to shut off any write-access to superglobals within untrusted functions.<br /><br />The first wouldn't be too hard to implement.&nbsp; The second, on the other hand, is practically impossible IMHO.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="52283">  <div class="votes">
    <div id="Vu52283">
    <a href="/manual/vote-note.php?id=52283&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd52283">
    <a href="/manual/vote-note.php?id=52283&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V52283" title="45% like this...">
    -1
    </div>
  </div>
  <a href="#52283" class="name">
  <strong class="user"><em>sendoshin[at]noodleroni[dot]com</em></strong></a><a class="genanchor" href="#52283"> &para;</a><div class="date" title="2005-04-26 05:58"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom52283">
<div class="phpcode"><code><span class="html">
There is one way to safely execute PHP code files without running the risk of compromising your own code.&nbsp; A prior note pointed out that the code being evaluated would still have access to globals using the global keyword.&nbsp; While this is a valid point, there's one other approach to be looked at - one which actually gives you much more ability than just unsetting some variable references.&nbsp; It's known as code parsing.<br /><br />The specifics would be different and much more complex in a deployed site, but here's an extremely strip-down example of how to restrict access to global variables:<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">while (</span><span class="default">$x </span><span class="keyword">= </span><span class="default">stristr </span><span class="keyword">(</span><span class="default">$code_to_eval</span><span class="keyword">, </span><span class="string">"global"</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$temp </span><span class="keyword">= </span><span class="default">substr </span><span class="keyword">(</span><span class="default">$code_to_eval</span><span class="keyword">, </span><span class="default">1</span><span class="keyword">, </span><span class="default">$x</span><span class="keyword">-</span><span class="default">1</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$temp </span><span class="keyword">.= </span><span class="default">substr </span><span class="keyword">(</span><span class="default">$code_to_eval</span><span class="keyword">, </span><span class="default">stristr </span><span class="keyword">(</span><span class="default">$code_to_eval</span><span class="keyword">, </span><span class="string">";"</span><span class="keyword">, </span><span class="default">$x</span><span class="keyword">) + </span><span class="default">1</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$code_to_eval </span><span class="keyword">= </span><span class="default">$temp</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; </span><span class="default">$ret_val </span><span class="keyword">= eval (</span><span class="default">$code_to_eval</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />Of course, that's just a rudimentary example, and a deployment version would have much more checking involved, but parsing the file before you eval it lets you remove any code you don't want to let run, thus making it as safe as your parsing rules.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="42270">  <div class="votes">
    <div id="Vu42270">
    <a href="/manual/vote-note.php?id=42270&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd42270">
    <a href="/manual/vote-note.php?id=42270&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V42270" title="45% like this...">
    -1
    </div>
  </div>
  <a href="#42270" class="name">
  <strong class="user"><em>bryan at nolifeline dot com</em></strong></a><a class="genanchor" href="#42270"> &para;</a><div class="date" title="2004-05-10 12:07"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom42270">
<div class="phpcode"><code><span class="html">
to marcbender at mail dot com<br /><br />unset the globals<br /><br />use a preg_replace ( pattern: |\;[^\;]*$i[^\;]*\;|Uis, replacement: ";", where $i is the name of any function/variable you wish to prevent access to.) on the code-to-be-evaled.&nbsp; ideas are "global", "fopen", "mysql_connect", etc.&nbsp; You know, anything that you wouldn't want to give a hyperactive 13 year old access to.<br /><br />execute the code.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="62735">  <div class="votes">
    <div id="Vu62735">
    <a href="/manual/vote-note.php?id=62735&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd62735">
    <a href="/manual/vote-note.php?id=62735&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V62735" title="44% like this...">
    -1
    </div>
  </div>
  <a href="#62735" class="name"><strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#62735"> &para;</a><div class="date" title="2006-03-08 05:51"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom62735">
<div class="phpcode"><code><span class="html">
there is a difference to the scope of eg. java: variables that are defined inside a block are also defined outside of&nbsp; the brackets.<br /><br />eg. this works:<br /><br />if {true}<br />{<br />&nbsp; $a = 'it works';<br />}<br /><br />echo $a;</span>
</code></div>
  </div>
 </div>
  <div class="note" id="56717">  <div class="votes">
    <div id="Vu56717">
    <a href="/manual/vote-note.php?id=56717&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd56717">
    <a href="/manual/vote-note.php?id=56717&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V56717" title="44% like this...">
    -1
    </div>
  </div>
  <a href="#56717" class="name">
  <strong class="user"><em>Graeme Jefferis</em></strong></a><a class="genanchor" href="#56717"> &para;</a><div class="date" title="2005-09-13 04:06"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom56717">
<div class="phpcode"><code><span class="html">
I find this sort of thing consistently useful for dealing with superglobals in safety and comfort.<br /><span class="default">&lt;?php<br /></span><span class="keyword">foreach (</span><span class="default">$_POST </span><span class="keyword">as </span><span class="default">$key </span><span class="keyword">=&gt; </span><span class="default">$value</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; &nbsp; &nbsp; switch (</span><span class="default">$key</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">"submitted_var_1"</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">"submitted_var_2"</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">"submitted_var_3"</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $</span><span class="default">$key </span><span class="keyword">= </span><span class="default">$value</span><span class="keyword">; break;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">"dangerous_var"</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$value </span><span class="keyword">= </span><span class="default">do_something_special_with</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $</span><span class="default">$key </span><span class="keyword">= </span><span class="default">$value</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="56689">  <div class="votes">
    <div id="Vu56689">
    <a href="/manual/vote-note.php?id=56689&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd56689">
    <a href="/manual/vote-note.php?id=56689&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V56689" title="44% like this...">
    -1
    </div>
  </div>
  <a href="#56689" class="name">
  <strong class="user"><em>Nicole King</em></strong></a><a class="genanchor" href="#56689"> &para;</a><div class="date" title="2005-09-12 11:01"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom56689">
<div class="phpcode"><code><span class="html">
There seems to a maximum size of key that you can use for the $_SESSION array on php5. If you exceed this length, which seems to be around 72 characters, the value is stored in the array, but is not serialised and restored later in the session (ie. when a subsquent page is processed). The same restriction *might* apply to other system-defined arrays.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="51757">  <div class="votes">
    <div id="Vu51757">
    <a href="/manual/vote-note.php?id=51757&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd51757">
    <a href="/manual/vote-note.php?id=51757&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V51757" title="44% like this...">
    -1
    </div>
  </div>
  <a href="#51757" class="name">
  <strong class="user"><em>lanny at freemail dot hu</em></strong></a><a class="genanchor" href="#51757"> &para;</a><div class="date" title="2005-04-10 02:32"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom51757">
<div class="phpcode"><code><span class="html">
From PHP 5.0.3 long predefined arrays such HTTP_GET_VARS got disabled by default. For backward compatibility you can enable them in php.ini:<br /><br />register_long_arrays = On<br /><br />I sugget a big WARNING up there like that one with the resister_globals. <br /><br />Anyway.. I cannot understand why they do such tings all the time.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="35627">  <div class="votes">
    <div id="Vu35627">
    <a href="/manual/vote-note.php?id=35627&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd35627">
    <a href="/manual/vote-note.php?id=35627&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V35627" title="44% like this...">
    -1
    </div>
  </div>
  <a href="#35627" class="name">
  <strong class="user"><em>joker at vip dot hr</em></strong></a><a class="genanchor" href="#35627"> &para;</a><div class="date" title="2003-09-08 07:42"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom35627">
<div class="phpcode"><code><span class="html">
If anyone of you have a problem with uploading files with globals off here is the solution... just add this to the top of the code:<br /><br />reset ($_FILES);<br />while (list ($key, $val) = each ($_FILES)) {<br />&nbsp; &nbsp; ${$key}=$_FILES[$key]['tmp_name'];<br />&nbsp; &nbsp; while (list ($key1, $val1) = each ($val)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; ${$key."_".$key1}=$_FILES[$key][$key1];<br />&nbsp; &nbsp; }<br />}<br /><br />&nbsp;&nbsp; Daniel</span>
</code></div>
  </div>
 </div>
  <div class="note" id="31772">  <div class="votes">
    <div id="Vu31772">
    <a href="/manual/vote-note.php?id=31772&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd31772">
    <a href="/manual/vote-note.php?id=31772&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V31772" title="42% like this...">
    -1
    </div>
  </div>
  <a href="#31772" class="name">
  <strong class="user"><em>alexsp at olywa dot net</em></strong></a><a class="genanchor" href="#31772"> &para;</a><div class="date" title="2003-05-02 07:26"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom31772">
<div class="phpcode"><code><span class="html">
For those of us who don't have the luxery of upgrading to the latest version of PHP on all of the servers we use but want to use the same variable names that are used in the latest version for super global arrays here's a snippet of code that will help:<br />&nbsp; &nbsp; // Makes available those super global arrays that are made available<br />&nbsp; &nbsp; // in versions of PHP after v4.1.0.<br />&nbsp; &nbsp; if (isset ($HTTP_SERVER_VARS))<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; $_SERVER = &amp;$HTTP_SERVER_VARS;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; if (isset ($HTTP_GET_VARS))<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; $_GET = &amp;$HTTP_GET_VARS;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; if (isset ($HTTP_POST_VARS))<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; $_POST = &amp;$HTTP_POST_VARS;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; if (isset ($HTTP_COOKIE_VARS))<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; $_COOKIE = &amp;$HTTP_COOKIE_VARS;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; if (isset ($HTTP_POST_FILES))<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; $_FILES = &amp;$HTTP_POST_FILES;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; if (isset ($HTTP_ENV_VARS))<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; $_ENV = &amp;$HTTP_ENV_VARS;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; if (isset ($HTTP_SESSION_VARS))<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; $_SESSION = &amp;$HTTP_SESSION_VARS;<br />&nbsp; &nbsp; }<br />The only downfall to this is that there's no way to make them super global. Chances are, though, if you're using a lot of global arrays in your code you should consider a code redesign!&nbsp; :)&nbsp; Hope this helps.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="30484">  <div class="votes">
    <div id="Vu30484">
    <a href="/manual/vote-note.php?id=30484&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd30484">
    <a href="/manual/vote-note.php?id=30484&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V30484" title="42% like this...">
    -1
    </div>
  </div>
  <a href="#30484" class="name">
  <strong class="user"><em>Good Liam</em></strong></a><a class="genanchor" href="#30484"> &para;</a><div class="date" title="2003-03-19 09:18"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom30484">
<div class="phpcode"><code><span class="html">
Warning:<br />If you use dynamic variables in a local scope, the variable doesn't "know" when it should be a superglobal.&nbsp; An example will help elucidate this:<br /><br />function Example($Variable_Name='_POST') {<br />&nbsp; &nbsp; print_r($$Variable_Name);<br />} // End Example<br /><br />This would print out<br /><br />NULL<br /><br />To use a dynamic variable to reference a superglobal, you have to declare the value (not the name) as a global:<br /><br />function WorkingExample($Variable_Name='_POST') {<br />&nbsp; &nbsp; global $$Variable_Name;<br />&nbsp; &nbsp; print_r($$Variable_Name);<br />} // End WorkingExample()<br /><br />This would print out the contents of your $_POST variable.<br /><br />This threw me when I first tried it, but it makes sense, in a way.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="43228">  <div class="votes">
    <div id="Vu43228">
    <a href="/manual/vote-note.php?id=43228&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd43228">
    <a href="/manual/vote-note.php?id=43228&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V43228" title="41% like this...">
    -2
    </div>
  </div>
  <a href="#43228" class="name">
  <strong class="user"><em>kasey at cornerspeed dowt com</em></strong></a><a class="genanchor" href="#43228"> &para;</a><div class="date" title="2004-06-14 05:33"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom43228">
<div class="phpcode"><code><span class="html">
I have a few points to note to (debabratak at softhome dot net).&nbsp; Firstly, extracting all your variables from the global variable arrays is rather cumbersome and possibly unsafe.&nbsp; This causes longer run times, and wastes more memory.&nbsp; Then, your script is starting the session before it parses the superglobals.&nbsp; Bad things can happen because of this:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="comment">// user sent a GET header with key = secret_access, val = true, so<br /><br /></span><span class="keyword">echo </span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">"secret_access"</span><span class="keyword">]; </span><span class="comment">// output: true<br /></span><span class="keyword">echo </span><span class="default">$secret_access</span><span class="keyword">; </span><span class="comment">// output:<br /><br /></span><span class="default">session_start</span><span class="keyword">();<br /><br /></span><span class="comment">// in previous logic, you set session variable $secret_access = false<br /><br /></span><span class="keyword">echo </span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">"secret_access"</span><span class="keyword">]; </span><span class="comment">// output: false<br /></span><span class="keyword">echo </span><span class="default">$secret_access</span><span class="keyword">; </span><span class="comment">// output: false<br /><br /></span><span class="default">extract_globals</span><span class="keyword">();&nbsp; </span><span class="comment">// Globals put into "normal" variables<br /><br /></span><span class="keyword">echo </span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">"secret_access"</span><span class="keyword">]; </span><span class="comment">// output: true<br /></span><span class="keyword">echo </span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">"secret_access"</span><span class="keyword">]; </span><span class="comment">// output: false<br /></span><span class="keyword">echo </span><span class="default">$secret_access</span><span class="keyword">; </span><span class="comment">// output: true<br /><br />// VARIABLES ARE COMPROMISED!<br />// DO NOT USE $secret_access !<br />// USE $_SESSION["secret_access"] instead !!!<br /><br /></span><span class="default">?&gt;<br /></span><br />Secondly, I would like to point out the fact that all $_POST, $_GET, and $_COOKIE variables are intrinsically unsafe anyway.&nbsp; Users can create their own scripts in the language of their choosing (PHP, ASP, JSP, etc.) that generate those headers to send to your PHP program via socket connections.&nbsp; PHP cannot determine that these headers are any less valid than the ones sent by a web browser, so it parses them and places them in the $_POST, $_GET, or $_COOKIE variables.<br /><br />The best practice is to use $_SESSION variables to validate the user before making any decisions based on form data.&nbsp; e.g.:<br /><br /><span class="default">&lt;?php<br />session_start</span><span class="keyword">();<br />if (isset(</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">"valid"</span><span class="keyword">]))<br />{<br />&nbsp; &nbsp; </span><span class="comment">// all your program decisions and database interactions can go here<br />&nbsp; &nbsp; </span><span class="keyword">if (isset(</span><span class="default">$_POST</span><span class="keyword">[</span><span class="string">"button_name"</span><span class="keyword">]))<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; ...<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; ...<br />}<br />elseif (isset(</span><span class="default">$_POST</span><span class="keyword">[</span><span class="string">"submit_login"</span><span class="keyword">]))<br />{<br />&nbsp; &nbsp; if ((</span><span class="default">$_POST</span><span class="keyword">[</span><span class="string">"username"</span><span class="keyword">] == </span><span class="string">"foo"</span><span class="keyword">) AND (</span><span class="default">$_POST</span><span class="keyword">[</span><span class="string">"password"</span><span class="keyword">] == </span><span class="string">"bar"</span><span class="keyword">))<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">"valid"</span><span class="keyword">] = </span><span class="default">true</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; ...<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; else<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">session_unset</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">session_destroy</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$error_msg </span><span class="keyword">= </span><span class="string">"Invalid username or password"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$result_page </span><span class="keyword">= </span><span class="string">"login.php"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br />elseif (isset(</span><span class="default">$logoff</span><span class="keyword">))<br />{<br />&nbsp; &nbsp; </span><span class="default">session_unset</span><span class="keyword">();<br />&nbsp; &nbsp; </span><span class="default">session_destroy</span><span class="keyword">();<br />&nbsp; &nbsp; </span><span class="default">$success_msg </span><span class="keyword">= </span><span class="string">"You have logged off successfully"</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$result_page </span><span class="keyword">= </span><span class="string">"login.php"</span><span class="keyword">;<br />}<br />else<br />{<br />&nbsp; &nbsp; </span><span class="default">session_unset</span><span class="keyword">();<br />&nbsp; &nbsp; </span><span class="default">session_destroy</span><span class="keyword">();<br />&nbsp; &nbsp; </span><span class="default">$result_page </span><span class="keyword">= </span><span class="string">"login.php"</span><span class="keyword">;<br />}<br />require (</span><span class="default">$result_page</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />Session variables are orders of magnitude harder to compromise than POST, GET, and COOKIE data, since the server keeps track of session id's, and the session id is unique to each client and somewhat randomly generated.&nbsp; If security is an ultimate concern, then you need to use SSL in case your traffic can be sniffed (since the session cookie is passed plain text to the client).<br /><br />In summary, extracting out all the superglobals to normal variable names is not a good idea for reasons of security and ambiguity, not to mention wasted CPU cycles.&nbsp; For private applications (ones that you don't want just anyone to be able to access), the only ways you can prevent malicious access is to 1) use sessions to ensure that the user is valid (for that page), and 2) use SSL-encryption to prevent session-hijacking.<br /><br />Kasey<br /><br />in reply to:<br />--------------------------------------------------------------<br /> debabratak at softhome dot net<br />14-Mar-2003 12:59<br />After having register_globals = off, I am using the following piece of code to get all the variables created for me. I have put this code in a separate file and just make it require_once() on top of every page.<br /><br />session_start();<br />$ArrayList = array("_GET", "_POST", "_SESSION", "_COOKIE", "_SERVER");<br />foreach($ArrayList as $gblArray)<br />{<br />&nbsp;&nbsp; $keys = array_keys($$gblArray);<br />&nbsp;&nbsp; foreach($keys as $key)<br />&nbsp;&nbsp; {<br />&nbsp; &nbsp; &nbsp;&nbsp; $$key = trim(${$gblArray}[$key]);<br />&nbsp;&nbsp; }<br />}<br /><br />This pulls out all the possible variables for me, including the predefined variables, so I can keep coding the old style. Note that, this code does not handle the $_FILE.<br /><br />Hope this helps someone.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="31724">  <div class="votes">
    <div id="Vu31724">
    <a href="/manual/vote-note.php?id=31724&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd31724">
    <a href="/manual/vote-note.php?id=31724&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V31724" title="41% like this...">
    -2
    </div>
  </div>
  <a href="#31724" class="name"><strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#31724"> &para;</a><div class="date" title="2003-05-01 09:06"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom31724">
<div class="phpcode"><code><span class="html">
In reply to destes at ix dot netcom dot com dot nospam:<br /><br />It's possible for a HTTP client to spoof HTTP_X_FORWARDED_FOR, and set it to a fake IP number.&nbsp; It's more secure to use this code and log BOTH the ip and the proxy ip.<br /><br />if ($_SERVER["HTTP_X_FORWARDED_FOR"]) {<br />&nbsp;&nbsp; if ($_SERVER["HTTP_CLIENT_IP"]) {<br />&nbsp; &nbsp; $proxy = $_SERVER["HTTP_CLIENT_IP"];<br />&nbsp; } else {<br />&nbsp; &nbsp; $proxy = $_SERVER["REMOTE_ADDR"];<br />&nbsp; }<br />&nbsp; $ip = $_SERVER["HTTP_X_FORWARDED_FOR"];<br />} else {<br />&nbsp; if ($_SERVER["HTTP_CLIENT_IP"]) {<br />&nbsp; &nbsp; $ip = $_SERVER["HTTP_CLIENT_IP"];<br />&nbsp; } else {<br />&nbsp; &nbsp; $ip = $_SERVER["REMOTE_ADDR"];<br />&nbsp; }<br />}<br /><br />echo "Your IP $ip&lt;BR&gt;\n";<br />if (isset($proxy)) {<br />&nbsp; echo "Your proxy IP is $proxy&lt;BR&gt;\n";<br />}</span>
</code></div>
  </div>
 </div>
  <div class="note" id="21952">  <div class="votes">
    <div id="Vu21952">
    <a href="/manual/vote-note.php?id=21952&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd21952">
    <a href="/manual/vote-note.php?id=21952&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V21952" title="38% like this...">
    -3
    </div>
  </div>
  <a href="#21952" class="name">
  <strong class="user"><em>juancri at TAGnet dot org</em></strong></a><a class="genanchor" href="#21952"> &para;</a><div class="date" title="2002-05-31 08:52"><strong>15 years ago</strong></div>
  <div class="text" id="Hcom21952">
<div class="phpcode"><code><span class="html">
If you try this:<br /><br />&lt;FORM action="hola"&gt;<br />&nbsp; ....<br />&lt;/FORM&gt;<br /><br />and hola is a directory, you have to write the final slash (/) because the page is redirected from hola to hola/ and you'll lost the POST variables.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="14246">  <div class="votes">
    <div id="Vu14246">
    <a href="/manual/vote-note.php?id=14246&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd14246">
    <a href="/manual/vote-note.php?id=14246&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V14246" title="33% like this...">
    -1
    </div>
  </div>
  <a href="#14246" class="name">
  <strong class="user"><em>rick@independence,netI</em></strong></a><a class="genanchor" href="#14246"> &para;</a><div class="date" title="2001-07-23 06:13"><strong>16 years ago</strong></div>
  <div class="text" id="Hcom14246">
<div class="phpcode"><code><span class="html">
It should be noted that $HTTP_RAW_POST_DATA only exists if the encoding type of the data is -not- the default of application/x-www.form-urlencoded, and so, to accessing raw post data from an HTTP form requires setting enctype= in your HTML.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="36878">  <div class="votes">
    <div id="Vu36878">
    <a href="/manual/vote-note.php?id=36878&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd36878">
    <a href="/manual/vote-note.php?id=36878&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V36878" title="33% like this...">
    -3
    </div>
  </div>
  <a href="#36878" class="name">
  <strong class="user"><em>mark at pitchpipe dot org</em></strong></a><a class="genanchor" href="#36878"> &para;</a><div class="date" title="2003-10-25 10:21"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom36878">
<div class="phpcode"><code><span class="html">
I had always mistakenly assumed that superglobal $_COOKIE (while preferred) was identical to the outdated $HTTP_COOKIE_VARS.&nbsp; However, if you assign:<br /><br />$_COOKIE['destroyWorld'] = "true";<br />if (isset($HTTP_COOKIE_VARS['destroyWorld'])) {<br />&nbsp;&nbsp; $temp =&amp; new Armeggedon();<br />&nbsp;&nbsp; $temp-&gt;pushRedButton();<br /> }<br /><br />then the world will be safe forever.&nbsp; Might throw off a newbie, or someone like me who was updating really old code bit-by-bit.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="76062">  <div class="votes">
    <div id="Vu76062">
    <a href="/manual/vote-note.php?id=76062&amp;page=language.variables.predefined&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd76062">
    <a href="/manual/vote-note.php?id=76062&amp;page=language.variables.predefined&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V76062" title="30% like this...">
    -4
    </div>
  </div>
  <a href="#76062" class="name">
  <strong class="user"><em>fabrizio at bibivu dot com</em></strong></a><a class="genanchor" href="#76062"> &para;</a><div class="date" title="2007-06-28 07:05"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom76062">
<div class="phpcode"><code><span class="html">
theonly_DD32, I refined your function a little bit<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">function </span><span class="default">long_to_GET</span><span class="keyword">(</span><span class="default">$PATH_INFO</span><span class="keyword">=</span><span class="string">''</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp; &nbsp; &nbsp; * This function converts info.php/a/1/b/2/c?d=4 TO<br />&nbsp; &nbsp; &nbsp; &nbsp; * array ( [d] =&gt; 4 [a] =&gt; 1 [b] =&gt; 2 [c] =&gt; array ( [d] =&gt; 4 ) )<br />&nbsp; &nbsp; &nbsp; &nbsp; * got this function from <a href="http://php.net/GLOBALS" rel="nofollow" target="_blank">http://php.net/GLOBALS</a><br />&nbsp; &nbsp; &nbsp; &nbsp; **/<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">if(</span><span class="default">$PATH_INFO</span><span class="keyword">==</span><span class="string">'' </span><span class="keyword">&amp;&amp; isset(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PATH_INFO'</span><span class="keyword">]) &amp;&amp; </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PATH_INFO'</span><span class="keyword">] != </span><span class="string">''</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$PATH_INFO </span><span class="keyword">= </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PATH_INFO'</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">$PATH_INFO </span><span class="keyword">!= </span><span class="string">''</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//Split it out.<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$tmp </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">(</span><span class="string">'/'</span><span class="keyword">,</span><span class="default">$PATH_INFO</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//Remove first empty item<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">unset(</span><span class="default">$tmp</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//Loop through and apend it into the $_GET superglobal.<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">for(</span><span class="default">$i</span><span class="keyword">=</span><span class="default">1</span><span class="keyword">;</span><span class="default">$i</span><span class="keyword">&lt;=</span><span class="default">count</span><span class="keyword">(</span><span class="default">$tmp</span><span class="keyword">);</span><span class="default">$i</span><span class="keyword">+=</span><span class="default">2</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">strpos</span><span class="keyword">(</span><span class="default">$tmp</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">],</span><span class="string">'?'</span><span class="keyword">)!==</span><span class="default">false</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$tmp1 </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">(</span><span class="string">'?'</span><span class="keyword">,</span><span class="default">$tmp</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">parse_str</span><span class="keyword">(isset(</span><span class="default">$tmp1</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">])?</span><span class="default">$tmp1</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]:</span><span class="string">''</span><span class="keyword">,</span><span class="default">$_GET</span><span class="keyword">[</span><span class="default">$tmp1</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]]);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$i</span><span class="keyword">--;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$_GET</span><span class="keyword">[</span><span class="default">$tmp</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">]] = isset(</span><span class="default">$tmp</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">+</span><span class="default">1</span><span class="keyword">])?</span><span class="default">$tmp</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">+</span><span class="default">1</span><span class="keyword">]:</span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.variables.predefined&amp;redirect=http://php.net/manual/en/language.variables.predefined.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.variables.php">Variables</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.variables.basics.php" title="Basics">Basics</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.variables.predefined.php" title="Predefined Variables">Predefined Variables</a>
                        </li>
                          
                        <li class="">
                            <a href="language.variables.scope.php" title="Variable scope">Variable scope</a>
                        </li>
                          
                        <li class="">
                            <a href="language.variables.variable.php" title="Variable variables">Variable variables</a>
                        </li>
                          
                        <li class="">
                            <a href="language.variables.external.php" title="Variables From External Sources">Variables From External Sources</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

