<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: PHP 7 ChangeLog</title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/ChangeLog-7.php">
 <link rel="shorturl" href="http://php.net/ChangeLog-7">
 <link rel="alternate" href="http://php.net/ChangeLog-7" hreflang="x-default">



<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1476869406&amp;f=/styles/changelog.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/ChangeLog-7.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>





<div id="layout" class="clearfix">
  <section id="layout-content">

<h1>PHP 7 ChangeLog</h1>

<section class="version" id="7.2.0"><!-- {{{ 7.2.0 -->
<h3>Version 7.2.0</h3>
<b><time class='releasedate' datetime='2017-11-30'>30 Nov 2017</time></b>
<ul><li>BCMath:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/46564">#46564</a> (bcmod truncates fractionals).</li>
</ul></li>
<li>CLI:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74849">#74849</a> (Process is started as interactive shell in PhpStorm).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74979">#74979</a> (Interactive shell opening instead of script execution with -f flag).</li>
</ul></li>
<li>CLI server:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/60471">#60471</a> (Random "Invalid request (unexpected EOF)" using a router script).</li>
</ul></li>
<li>Core:
<ul>
  <li>Added ZEND_COUNT, ZEND_GET_CLASS, ZEND_GET_CALLED_CLASS, ZEND_GET_TYPE, ZEND_FUNC_NUM_ARGS, ZEND_FUNC_GET_ARGS instructions, to implement corresponding builtin functions.</li>
  <li>"Countable" interface is moved from SPL to Core.</li>
  <li>Added ZEND_IN_ARRAY instruction, implementing optimized in_array() builtin function, through hash lookup in flipped array.</li>
  <li>Removed IS_TYPE_IMMUTABLE (it's the same as COPYABLE &amp; !REFCOUNTED).</li>
  <li>Removed the sql.safe_mode directive.</li>
  <li>Removed support for Netware.</li>
  <li>Renamed ReflectionClass::isIterateable() to ReflectionClass::isIterable() (alias original name for BC).</li>
  <li>Fixed bug <a href="http://bugs.php.net/54535">#54535</a> (WSA cleanup executes before MSHUTDOWN).</li>
  <li>Implemented FR <a href="http://bugs.php.net/69791">#69791</a> (Disallow mail header injections by extra headers) (Yasuo)</li>
  <li>Implemented FR <a href="http://bugs.php.net/49806">#49806</a> (proc_nice() for Windows).</li>
  <li>Fix pthreads detection when cross-compiling (ffontaine)</li>
  <li>Fixed memory leaks caused by exceptions thrown from destructors. (Bob, Dmitry).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73215">#73215</a> (uniqid() should use better random source).</li>
  <li>Implemented FR <a href="http://bugs.php.net/72768">#72768</a> (Add ENABLE_VIRTUAL_TERMINAL_PROCESSING flag for php.exe).</li>
  <li>Implemented "Convert numeric keys in object/array casts" RFC, fixes bugs <a href="http://bugs.php.net/53838">#53838</a>, <a href="http://bugs.php.net/61655">#61655</a>, <a href="http://bugs.php.net/66173">#66173</a>, <a href="http://bugs.php.net/70925">#70925</a>, <a href="http://bugs.php.net/72254">#72254</a>, etc.</li>
  <li>Implemented "Deprecate and Remove Bareword (Unquoted) Strings" RFC.</li>
  <li>Raised minimum supported Windows versions to Windows 7/Server 2008 R2.</li>
  <li>Implemented minor optimization in array_keys/array_values().</li>
  <li>Added PHP_OS_FAMILY constant to determine on which OS we are.</li>
  <li>Fixed bug <a href="http://bugs.php.net/73987">#73987</a> (Method compatibility check looks to original definition and not parent).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73991">#73991</a> (JSON_OBJECT_AS_ARRAY not respected).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74053">#74053</a> (Corrupted class entries on shutdown when a destructor spawns another object).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73971">#73971</a> (Filename got limited to MAX_PATH on Win32 when scan directory).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72359">#72359</a>, bug <a href="http://bugs.php.net/72451">#72451</a>, bug <a href="http://bugs.php.net/73706">#73706</a>, bug <a href="http://bugs.php.net/71115">#71115</a> and others related to interned strings handling in TS builds.</li>
  <li>Implemented "Trailing Commas In List Syntax" RFC for group use lists only.</li>
  <li>Fixed bug <a href="http://bugs.php.net/74269">#74269</a> (It's possible to override trait property with different loosely-equal value).</li>
  <li>Fixed bug <a href="http://bugs.php.net/61970">#61970</a> (Restraining __construct() access level in subclass gives a fatal error).</li>
  <li>Fixed bug <a href="http://bugs.php.net/63384">#63384</a> (Cannot override an abstract method with an abstract method).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74607">#74607</a> (Traits enforce different inheritance rules).</li>
  <li>Fixed misparsing of abstract unix domain socket names.</li>
  <li>Change PHP_OS_FAMILY value from "OSX" to "Darwin".</li>
  <li>Allow loading PHP/Zend extensions by name in ini files (extension=&lt;name&gt;).</li>
  <li>Added object type annotation.</li>
  <li>Fixed bug <a href="http://bugs.php.net/74815">#74815</a> (crash with a combination of INI entries at startup).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74836">#74836</a> (isset on zero-prefixed numeric indexes in array broken).</li>
  <li>Added new VM instuctions ISSET_ISEMPTY_CV and UNSET_CV. Previously they were implemented as ISSET_ISEMPTY_VAR and UNSET_VAR variants with ZEND_QUICK_SET flag.</li>
  <li>Fixed bug <a href="http://bugs.php.net/49649">#49649</a> (unserialize() doesn't handle changes in property visibility).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74866">#74866</a> (extension_dir = "./ext" now use current directory for base).</li>
  <li>Implemented FR <a href="http://bugs.php.net/74963">#74963</a> (Improved error message on fetching property of non-object).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75142">#75142</a> (buildcheck.sh check for autoconf version needs to be updated for v2.64).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74878">#74878</a> (Data race in ZTS builds).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75515">#75515</a> ("stream_copy_to_stream" doesn't stream anymore).</li>
</ul></li>
<li>cURL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75093">#75093</a> (OpenSSL support not detected).</li>
  <li>Better fix for <a href="http://bugs.php.net/74125">#74125</a> (use pkg-config instead of curl-config).</li>
</ul></li>
<li>Date:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/55407">#55407</a> (Impossible to prototype DateTime::createFromFormat).</li>
  <li>Implemented FR <a href="http://bugs.php.net/71520">#71520</a> (Adding the DateTime constants to the DateTimeInterface interface).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75149">#75149</a> (redefinition of typedefs ttinfo and t1info).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75222">#75222</a> (DateInterval microseconds property always 0).</li>
</ul></li>
<li>Dba:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72885">#72885</a> (flatfile: dba_fetch() fails to read replaced entry).</li>
</ul></li>
<li>DOM:
<ul>
  <li>Implemented FR <a href="http://bugs.php.net/74837">#74837</a> (Implement Countable for DomNodeList and DOMNamedNodeMap).</li>
</ul></li>
<li>EXIF:
<ul>
  <li>Added support for vendor specific tags for the following formats: Samsung, DJI, Panasonic, Sony, Pentax, Minolta, Sigma/Foveon, AGFA, Kyocera, Ricoh &amp; Epson.</li>
  <li>Fixed bug <a href="http://bugs.php.net/72682">#72682</a> (exif_read_data() fails to read all data for some images).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71534">#71534</a> (Type confusion in exif_read_data() leading to heap overflow in debug mode).</li>
  <li>Fixed bug <a href="http://bugs.php.net/68547">#68547</a> (Exif Header component value check error).</li>
  <li>Fixed bug <a href="http://bugs.php.net/66443">#66443</a> (Corrupt EXIF header: maximum directory nesting level reached for some cameras).</li>
  <li>Fixed Redhat bug #1362571 (PHP not returning full results for exif_read_data function).</li>
  <li>Implemented FR <a href="http://bugs.php.net/65187">#65187</a> (exif_read_data/thumbnail: add support for stream resource).</li>
  <li>Deprecated the read_exif_data() alias.</li>
  <li>Fixed bug <a href="http://bugs.php.net/74428">#74428</a> (exif_read_data(): "Illegal IFD size" warning occurs with correct exif format).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72819">#72819</a> (EXIF thumbnails not read anymore).</li>
  <li>Fixed bug <a href="http://bugs.php.net/62523">#62523</a> (php crashes with segfault when exif_read_data called).</li>
  <li>Fixed bug <a href="http://bugs.php.net/50660">#50660</a> (exif_read_data(): Illegal IFD offset (works fine with other exif readers).</li>
</ul></li>
<li>Fileinfo:
<ul>
  <li>Upgrade bundled libmagic to 5.31.</li>
</ul></li>
<li>FPM:
<ul>
  <li>Configuration to limit fpm slow log trace callers.</li>
  <li>Fixed bug <a href="http://bugs.php.net/75212">#75212</a> (php_value acts like php_admin_value).</li>
</ul></li>
<li>FTP:
<ul>
  <li>Implement MLSD for structured listing of directories.</li>
  <li>Added ftp_append() function.</li>
</ul></li>
<li>GD:
<ul>
  <li>Implemented imageresolution as getter and setter (Christoph)</li>
  <li>Fixed bug <a href="http://bugs.php.net/74744">#74744</a> (gd.h: stdarg.h include missing for va_list use in gdErrorMethod).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75111">#75111</a> (Memory disclosure or DoS via crafted .bmp image).</li>
</ul></li>
<li>GMP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70896">#70896</a> (gmp_fact() silently ignores non-integer input).</li>
</ul></li>
<li>Hash:
<ul>
  <li>Changed HashContext from resource to object.</li>
  <li>Disallowed usage of non-cryptographic hash functions with HMAC and PBKDF2.</li>
  <li>Fixed bug <a href="http://bugs.php.net/75284">#75284</a> (sha3 is not supported on bigendian machine).</li>
</ul></li>
<li>IMAP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72324">#72324</a> (imap_mailboxmsginfo() return wrong size).</li>
</ul></li>
<li>Intl:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/63790">#63790</a> (test using Spoofchecker which may be unavailable).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75378">#75378</a> ([REGRESSION] IntlDateFormatter::parse() does not change $position argument).</li>
</ul></li>
<li>JSON:
<ul>
  <li>Add JSON_INVALID_UTF8_IGNORE and JSON_INVALID_UTF8_SUBSTITUTE options for json_encode and json_decode to ignore or replace invalid UTF-8 byte sequences - it addresses request <a href="http://bugs.php.net/65082">#65082</a>.</li>
  <li>Fixed bug <a href="http://bugs.php.net/75185">#75185</a> (Buffer overflow in json_decode() with JSON_INVALID_UTF8_IGNORE or JSON_INVALID).</li>
  <li>Fixed bug <a href="http://bugs.php.net/68567">#68567</a> (JSON_PARTIAL_OUTPUT_ON_ERROR can result in JSON with null key).</li>
</ul></li>
<li>LDAP:
<ul>
  <li>Implemented FR <a href="http://bugs.php.net/69445">#69445</a> (Support for LDAP EXOP operations)</li>
  <li>Fixed support for LDAP_OPT_SERVER_CONTROLS and LDAP_OPT_CLIENT_CONTROLS in ldap_get_option</li>
  <li>Fixed passing an empty array to ldap_set_option for client or server controls.</li>
</ul></li>
<li>Mbstring:
<ul>
  <li>Implemented FR <a href="http://bugs.php.net/66024">#66024</a> (mb_chr() and mb_ord()).</li>
  <li>Implemented FR <a href="http://bugs.php.net/65081">#65081</a> (mb_scrub()).</li>
  <li>Implemented FR <a href="http://bugs.php.net/69086">#69086</a> (enhancement for mb_convert_encoding() that handles multibyte replacement char nicely).</li>
  <li>Added array input support to mb_convert_encoding().</li>
  <li>Added array input support to mb_check_encoding().</li>
  <li>Fixed bug <a href="http://bugs.php.net/69079">#69079</a> (enhancement for mb_substitute_character).</li>
  <li>Update to oniguruma version 6.3.0.</li>
  <li>Fixed bug <a href="http://bugs.php.net/69267">#69267</a> (mb_strtolower fails on titlecase characters).</li>
</ul></li>
<li>Mcrypt:
<ul>
  <li>The deprecated mcrypt extension has been moved to PECL.</li>
</ul></li>
<li>Opcache:
<ul>
  <li>Added global optimisation passes based on data flow analysis using Single Static Assignment (SSA) form: Sparse Conditional Constant Propagation (SCCP), Dead Code Elimination (DCE), and removal of unused local variables (Nikita, Dmitry)</li>
  <li>Fixed incorect constant conditional jump elimination.</li>
  <li>Fixed bug <a href="http://bugs.php.net/75230">#75230</a> (Invalid opcode 49/1/8 using opcache).</li>
  <li>Fixed bug (assertion fails with extended info generated).</li>
  <li>Fixed bug (Phi sources removel).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75370">#75370</a> (Webserver hangs on valid PHP text).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75357">#75357</a> (segfault loading WordPress wp-admin).</li>
</ul></li>
<li>OpenSSL:
<ul>
  <li>Use TLS_ANY for default ssl:// and tls:// negotiation.</li>
  <li>Fix leak in openssl_spki_new().</li>
  <li>Added openssl_pkcs7_read() and pk7 parameter to openssl_pkcs7_verify().</li>
  <li>Add ssl security_level stream option to support OpenSSL security levels. (Jakub Zelenka).</li>
  <li>Allow setting SNI cert and private key in separate files.</li>
  <li>Fixed bug <a href="http://bugs.php.net/74903">#74903</a> (openssl_pkcs7_encrypt() uses different EOL than before).</li>
  <li>Automatically load OpenSSL configuration file.</li>
</ul></li>
<li>PCRE:
<ul>
  <li>Added support for PCRE JIT fast path API.</li>
  <li>Fixed bug <a href="http://bugs.php.net/61780">#61780</a> (Inconsistent PCRE captures in match results).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74873">#74873</a> (Minor BC break: PCRE_JIT changes output of preg_match()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75089">#75089</a> (preg_grep() is not reporting PREG_BAD_UTF8_ERROR after first input string).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75223">#75223</a> (PCRE JIT broken in 7.2).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75285">#75285</a> (Broken build when system libpcre don't have jit support).</li>
</ul></li>
<li>phar:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74196">#74196</a> (phar does not correctly handle names containing dots).</li>
</ul></li>
<li>PDO:
<ul>
  <li>Add "Sent SQL" to debug dump for emulated prepares.</li>
  <li>Add parameter types for national character set strings.</li>
</ul></li>
<li>PDO_DBlib:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73234">#73234</a> (Emulated statements let value dictate parameter type).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73396">#73396</a> (bigint columns are returned as strings).</li>
  <li>Expose DB-Library version as \PDO::DBLIB_ATTR_VERSION attribute on \PDO instance.</li>
  <li>Add test coverage for bug <a href="http://bugs.php.net/72969">#72969</a>.</li>
</ul></li>
<li>PDO_OCI:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74537">#74537</a> (Align --with-pdo-oci configure option with --with-oci8 syntax).</li>
</ul></li>
<li>PDO_Sqlite:
<ul>
  <li>Switch to sqlite3_prepare_v2() and sqlite3_close_v2() functions (rasmus)</li>
</ul></li>
<li>PHPDBG:
<ul>
  <li>Added extended_value to opcode dump output.</li>
</ul></li>
<li>Session:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73461">#73461</a> (Prohibit session save handler recursion).</li>
  <li>PR #2233 Removed register_globals related code and "!" can be used as $_SESSION key name.</li>
  <li>Improved bug <a href="http://bugs.php.net/73100">#73100</a> fix. 'user' save handler can only be set by session_set_save_handler()</li>
  <li>Fixed bug <a href="http://bugs.php.net/74514">#74514</a> (5 session functions incorrectly warn when calling in read-only/getter mode).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74936">#74936</a> (session_cache_expire/cache_limiter/save_path() trigger a warning in read mode).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74941">#74941</a> (session fails to start after having headers sent).</li>
</ul></li>
<li>Sodium:
<ul>
  <li>New cryptographic extension</li>
  <li>Added missing bindings for libsodium &gt; 1.0.13.</li>
</ul></li>
<li>SPL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71412">#71412</a> (Incorrect arginfo for ArrayIterator::__construct).</li>
  <li>Added spl_object_id().</li>
</ul></li>
<li>SQLite3:
<ul>
  <li>Implement writing to blobs.</li>
  <li>Update to Sqlite 3.20.1.</li>
</ul></li>
<li>Standard:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/69442">#69442</a> (closing of fd incorrect when PTS enabled).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74300">#74300</a> (unserialize accepts two plus/minus signs for float number exponent part).</li>
  <li>Compatibility with libargon2 versions 20161029 and 20160821.</li>
  <li>Fixed bug <a href="http://bugs.php.net/74737">#74737</a> (mysqli_get_client_info reflection info).</li>
  <li>Add support for extension name as argument to dl().</li>
  <li>Fixed bug <a href="http://bugs.php.net/74851">#74851</a> (uniqid() without more_entropy performs badly).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74103">#74103</a> (heap-use-after-free when unserializing invalid array size).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75054">#75054</a> (A Denial of Service Vulnerability was found when performing deserialization).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75170">#75170</a> (mt_rand() bias on 64-bit machines).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75221">#75221</a> (Argon2i always throws NUL at the end).</li>
</ul></li>
<li>Streams:
<ul>
  <li>Default ssl/single_dh_use and ssl/honor_cipher_order to true.</li>
</ul></li>
<li>XML:
<ul>
  <li>Moved utf8_encode() and utf8_decode() to the Standard extension.</li>
</ul></li>
<li>XMLRPC:
<ul>
  <li>Use Zend MM for allocation in bundled libxmlrpc (Joe)</li>
</ul></li>
<li>ZIP:
<ul>
  <li>Add support for encrypted archives.</li>
  <li>Use of bundled libzip is deprecated, --with-libzip option is recommended.</li>
  <li>Fixed bug <a href="http://bugs.php.net/73803">#73803</a> (Reflection of ZipArchive does not show public properties).</li>
  <li>ZipArchive implements countable, added ZipArchive::count() method.</li>
  <li>Fix segfault in php_stream_context_get_option call.</li>
  <li>Fixed bug <a href="http://bugs.php.net/75143">#75143</a> (new method setEncryptionName() seems not to exist in ZipArchive).</li>
</ul></li>
<li>zlib:
<ul>
  <li>Expose inflate_get_status() and inflate_get_read_len() functions.</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.1.12"><!-- {{{ 7.1.12 -->
<h3>Version 7.1.12</h3>
<b><time class='releasedate' datetime='2017-11-23'>23 Nov 2017</time></b>
<ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75420">#75420</a> (Crash when modifing property name in __isset for BP_VAR_IS).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75368">#75368</a> (mmap/munmap trashing on unlucky allocations).</li>
</ul></li>
<li>CLI:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75287">#75287</a> (Builtin webserver crash after chdir in a shutdown function).</li>
</ul></li>
<li>Enchant:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/53070">#53070</a> (enchant_broker_get_path crashes if no path is set).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75365">#75365</a> (Enchant still reports version 1.1.0).</li>
</ul></li>
<li>Exif:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75301">#75301</a> (Exif extension has built in revision version).</li>
</ul></li>
<li>GD:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/65148">#65148</a> (imagerotate may alter image dimensions).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75437">#75437</a> (Wrong reflection on imagewebp).</li>
</ul></li>
<li>intl:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75317">#75317</a> (UConverter::setDestinationEncoding changes source instead of destination).</li>
</ul></li>
<li>interbase:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75453">#75453</a> (Incorrect reflection for ibase_[p]connect).</li>
</ul></li>
<li>Mysqli:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75434">#75434</a> (Wrong reflection for mysqli_fetch_all function).</li>
</ul></li>
<li>OCI8:
<ul>
  <li>Fixed valgrind issue.</li>
</ul></li>
<li>OpenSSL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75363">#75363</a> (openssl_x509_parse leaks memory).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75307">#75307</a> (Wrong reflection for openssl_open function).</li>
</ul></li>
<li>Opcache:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75373">#75373</a> (Warning Internal error: wrong size calculation).</li>
</ul></li>
<li>PGSQL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75419">#75419</a> (Default link incorrectly cleared/linked by pg_close()).</li>
</ul></li>
<li>SOAP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75464">#75464</a> (Wrong reflection on SoapClient::__setSoapHeaders).</li>
</ul></li>
<li>Zlib:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75299">#75299</a> (Wrong reflection on inflate_init and inflate_add).</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.0.26"><!-- {{{ 7.0.26 -->
<h3>Version 7.0.26</h3>
<b><time class='releasedate' datetime='2017-11-23'>23 Nov 2017</time></b>
<ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75420">#75420</a> (Crash when modifing property name in __isset for BP_VAR_IS).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75368">#75368</a> (mmap/munmap trashing on unlucky allocations).</li>
</ul></li>
<li>CLI:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75287">#75287</a> (Builtin webserver crash after chdir in a shutdown function).</li>
</ul></li>
<li>Enchant:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/53070">#53070</a> (enchant_broker_get_path crashes if no path is set).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75365">#75365</a> (Enchant still reports version 1.1.0).</li>
</ul></li>
<li>Exif:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75301">#75301</a> (Exif extension has built in revision version).</li>
</ul></li>
<li>GD:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/65148">#65148</a> (imagerotate may alter image dimensions).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75437">#75437</a> (Wrong reflection on imagewebp).</li>
</ul></li>
<li>intl:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75317">#75317</a> (UConverter::setDestinationEncoding changes source instead of destination).</li>
</ul></li>
<li>interbase:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75453">#75453</a> (Incorrect reflection for ibase_[p]connect).</li>
</ul></li>
<li>Mysqli:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75434">#75434</a> (Wrong reflection for mysqli_fetch_all function).</li>
</ul></li>
<li>OCI8:
<ul>
  <li>Fixed valgrind issue.</li>
</ul></li>
<li>Opcache:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75373">#75373</a> (Warning Internal error: wrong size calculation).</li>
</ul></li>
<li>OpenSSL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75363">#75363</a> (openssl_x509_parse leaks memory).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75307">#75307</a> (Wrong reflection for openssl_open function).</li>
</ul></li>
<li>PGSQL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75419">#75419</a> (Default link incorrectly cleared/linked by pg_close()).</li>
</ul></li>
<li>SOAP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75464">#75464</a> (Wrong reflection on SoapClient::__setSoapHeaders).</li>
</ul></li>
<li>Zlib:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75299">#75299</a> (Wrong reflection on inflate_init and inflate_add).</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.1.11"><!-- {{{ 7.1.11 -->
<h3>Version 7.1.11</h3>
<b><time class='releasedate' datetime='2017-10-26'>26 Oct 2017</time></b>
<ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75241">#75241</a> (Null pointer dereference in zend_mm_alloc_small()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75236">#75236</a> (infinite loop when printing an error-message).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75252">#75252</a> (Incorrect token formatting on two parse errors in one request).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75220">#75220</a> (Segfault when calling is_callable on parent).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75290">#75290</a> (debug info of Closures of internal functions contain garbage argument names).</li>
</ul></li>
<li>Date:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75055">#75055</a> (Out-Of-Bounds Read in timelib_meridian()).</li>
</ul></li>
<li>Apache2Handler:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75311">#75311</a> (error: 'zend_hash_key' has no member named 'arKey' in apache2handler).</li>
</ul></li>
<li>Hash:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75303">#75303</a> (sha3 hangs on bigendian).</li>
</ul></li>
<li>Intl:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75318">#75318</a> (The parameter of UConverter::getAliases() is not optional).</li>
</ul></li>
<li>litespeed:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75248">#75248</a> (Binary directory doesn't get created when building only litespeed SAPI).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75251">#75251</a> (Missing program prefix and suffix).</li>
</ul></li>
<li>mcrypt:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72535">#72535</a> (arcfour encryption stream filter crashes php).</li>
</ul></li>
<li>MySQLi:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75018">#75018</a> (Data corruption when reading fields of bit type).</li>
</ul></li>
<li>OCI8:
<ul>
  <li>Fixed incorrect reference counting.</li>
</ul></li>
<li>Opcache:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75255">#75255</a> (Request hangs and not finish).</li>
</ul></li>
<li>PCRE:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75207">#75207</a> (applied upstream patch for CVE-2016-1283).</li>
</ul></li>
<li>PDO_mysql:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75177">#75177</a> (Type 'bit' is fetched as unexpected string).</li>
</ul></li>
<li>SPL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73629">#73629</a> (SplDoublyLinkedList::setIteratorMode masks intern flags).</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.0.25"><!-- {{{ 7.0.25 -->
<h3>Version 7.0.25</h3>
<b><time class='releasedate' datetime='2017-10-26'>26 Oct 2017</time></b>
<ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75241">#75241</a> (Null pointer dereference in zend_mm_alloc_small()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75236">#75236</a> (infinite loop when printing an error-message).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75252">#75252</a> (Incorrect token formatting on two parse errors in one request).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75220">#75220</a> (Segfault when calling is_callable on parent).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75290">#75290</a> (debug info of Closures of internal functions contain garbage argument names).</li>
</ul></li>
<li>Apache2Handler:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75311">#75311</a> (error: 'zend_hash_key' has no member named 'arKey' in apache2handler).</li>
</ul></li>
<li>Date:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75055">#75055</a> (Out-Of-Bounds Read in timelib_meridian()).</li>
</ul></li>
<li>Intl:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75318">#75318</a> (The parameter of UConverter::getAliases() is not optional).</li>
</ul></li>
<li>mcrypt:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72535">#72535</a> (arcfour encryption stream filter crashes php).</li>
</ul></li>
<li>OCI8:
<ul>
  <li>Fixed incorrect reference counting.</li>
</ul></li>
<li>PCRE:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75207">#75207</a> (applied upstream patch for CVE-2016-1283).</li>
</ul></li>
<li>litespeed:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75248">#75248</a> (Binary directory doesn't get created when building only litespeed SAPI).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75251">#75251</a> (Missing program prefix and suffix).</li>
</ul></li>
<li>SPL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73629">#73629</a> (SplDoublyLinkedList::setIteratorMode masks intern flags).</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.1.10"><!-- {{{ 7.1.10 -->
<h3>Version 7.1.10</h3>
<b><time class='releasedate' datetime='2017-09-28'>28 Sep 2017</time></b>
<ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75042">#75042</a> (run-tests.php issues with EXTENSION block).</li>
</ul></li>
<li>BCMath:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/44995">#44995</a> (bcpowmod() fails if scale != 0).</li>
  <li>Fixed bug <a href="http://bugs.php.net/46781">#46781</a> (BC math handles minus zero incorrectly).</li>
  <li>Fixed bug <a href="http://bugs.php.net/54598">#54598</a> (bcpowmod() may return 1 if modulus is 1).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75178">#75178</a> (bcpowmod() misbehaves for non-integer base or modulus).</li>
</ul></li>
<li>CLI server:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70470">#70470</a> (Built-in server truncates headers spanning over TCP packets).</li>
</ul></li>
<li>CURL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75093">#75093</a> (OpenSSL support not detected).</li>
</ul></li>
<li>GD:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75124">#75124</a> (gdImageGrayScale() may produce colors).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75139">#75139</a> (libgd/gd_interpolation.c:1786: suspicious if ?).</li>
</ul></li>
<li>Gettext:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73730">#73730</a> (textdomain(null) throws in strict mode).</li>
</ul></li>
<li>Intl:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75090">#75090</a> (IntlGregorianCalendar doesn't have constants from parent class).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75193">#75193</a> (segfault in collator_convert_object_to_string).</li>
</ul></li>
<li>PDO_OCI:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74631">#74631</a> (PDO_PCO with PHP-FPM: OCI environment initialized before PHP-FPM sets it up).</li>
</ul></li>
<li>SPL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75155">#75155</a> (AppendIterator::append() is broken when appending another AppendIterator).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75173">#75173</a> (incorrect behavior of AppendIterator::append in foreach loop).</li>
</ul></li>
<li>Standard:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75152">#75152</a> (signed integer overflow in parse_iv).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75097">#75097</a> (gethostname fails if your host name is 64 chars long).</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.0.24"><!-- {{{ 7.0.24 -->
<h3>Version 7.0.24</h3>
<b><time class='releasedate' datetime='2017-09-28'>28 Sep 2017</time></b>
<ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75042">#75042</a> (run-tests.php issues with EXTENSION block).</li>
</ul></li>
<li>BCMath:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/44995">#44995</a> (bcpowmod() fails if scale != 0).</li>
  <li>Fixed bug <a href="http://bugs.php.net/46781">#46781</a> (BC math handles minus zero incorrectly).</li>
  <li>Fixed bug <a href="http://bugs.php.net/54598">#54598</a> (bcpowmod() may return 1 if modulus is 1).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75178">#75178</a> (bcpowmod() misbehaves for non-integer base or modulus).</li>
</ul></li>
<li>CLI server:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70470">#70470</a> (Built-in server truncates headers spanning over TCP packets).</li>
</ul></li>
<li>CURL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75093">#75093</a> (OpenSSL support not detected).</li>
</ul></li>
<li>GD:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75124">#75124</a> (gdImageGrayScale() may produce colors).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75139">#75139</a> (libgd/gd_interpolation.c:1786: suspicious if ?).</li>
</ul></li>
<li>Gettext:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73730">#73730</a> (textdomain(null) throws in strict mode).</li>
</ul></li>
<li>Intl:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75090">#75090</a> (IntlGregorianCalendar doesn't have constants from parent class).</li>
</ul></li>
<li>PDO_OCI:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74631">#74631</a> (PDO_PCO with PHP-FPM: OCI environment initialized before PHP-FPM sets it up).</li>
</ul></li>
<li>SPL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75173">#75173</a> (incorrect behavior of AppendIterator::append in foreach loop).</li>
</ul></li>
<li>Standard:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75097">#75097</a> (gethostname fails if your host name is 64 chars long).</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.1.9"><!-- {{{ 7.1.9 -->
<h3>Version 7.1.9</h3>
<b><time class='releasedate' datetime='2017-08-31'>31 Aug 2017</time></b>
<ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74947">#74947</a> (Segfault in scanner on INF number).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74954">#74954</a> (null deref and segfault in zend_generator_resume()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74725">#74725</a> (html_errors=1 breaks unhandled exceptions).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75063">#75063</a> (Main CWD initialized with wrong codepage).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75349">#75349</a> (NAN comparison).</li>
</ul></li>
<li>cURL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74125">#74125</a> (Fixed finding CURL on systems with multiarch support).</li>
</ul></li>
<li>Date:
<ul>
  <li>Fixed bug #75002 (Null Pointer Dereference in timelib_time_clone).</li>
</ul></li>
<li>Intl:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74993">#74993</a> (Wrong reflection on some locale_* functions).</li>
</ul></li>
<li>Mbstring:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71606">#71606</a> (Segmentation fault mb_strcut with HTML-ENTITIES encoding).</li>
  <li>Fixed bug <a href="http://bugs.php.net/62934">#62934</a> (mb_convert_kana() does not convert iteration marks).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75001">#75001</a> (Wrong reflection on mb_eregi_replace).</li>
</ul></li>
<li>MySQLi:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74968">#74968</a> (PHP crashes when calling mysqli_result::fetch_object with an abstract class).</li>
</ul></li>
<li>OCI8:
<ul>
  <li>Expose oci_unregister_taf_callback() (Tianfang Yang)</li>
</ul></li>
<li>Opcache:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74980">#74980</a> (Narrowing occurred during type inference).</li>
</ul></li>
<li>phar:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74991">#74991</a> (include_path has a 4096 char limit in some cases).</li>
</ul></li>
<li>Reflection:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74949">#74949</a> (null pointer dereference in _function_string).</li>
</ul></li>
<li>Session:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74892">#74892</a> (Url Rewriting (trans_sid) not working on urls that start with "#").</li>
  <li>Fixed bug <a href="http://bugs.php.net/74833">#74833</a> (SID constant created with wrong module number).</li>
</ul></li>
<li>SimpleXML:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74950">#74950</a> (nullpointer deref in simplexml_element_getDocNamespaces).</li>
</ul></li>
<li>SPL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75049">#75049</a> (spl_autoload_unregister can't handle spl_autoload_functions results).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74669">#74669</a> (Unserialize ArrayIterator broken).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74977">#74977</a> (Appending AppendIterator leads to segfault).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75015">#75015</a> (Crash in recursive iterator destructors).</li>
</ul></li>
<li>Standard:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75075">#75075</a> (unpack with X* causes infinity loop).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74103">#74103</a> (heap-use-after-free when unserializing invalid array size).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75054">#75054</a> (A Denial of Service Vulnerability was found when performing deserialization).</li>
</ul></li>
<li>WDDX:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73793">#73793</a> (WDDX uses wrong decimal seperator).</li>
</ul></li>
<li>XMLRPC:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74975">#74975</a> (Incorrect xmlrpc serialization for classes with declared properties).</li>
</ul></li>
</ul>
<!-- }}} --></section>


<section class="version" id="7.0.23"><!-- {{{ 7.0.23 -->
<h3>Version 7.0.23</h3>
<b><time class='releasedate' datetime='2017-08-31'>31 Aug 2017</time></b>
<ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74947">#74947</a> (Segfault in scanner on INF number).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74954">#74954</a> (null deref and segfault in zend_generator_resume()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74725">#74725</a> (html_errors=1 breaks unhandled exceptions).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75349">#75349</a> (NAN comparison).</li>
</ul></li>
<li>cURL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74125">#74125</a> (Fixed finding CURL on systems with multiarch support).</li>
</ul></li>
<li>Date:
<ul>
<li>Fixed bug <a href="http://bugs.php.net/75002">#75002</a> (Null Pointer Dereference in timelib_time_clone).</li>
</ul></li>
<li>Intl:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74993">#74993</a> (Wrong reflection on some locale_* functions).</li>
</ul></li>
<li>Mbstring:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71606">#71606</a> (Segmentation fault mb_strcut with HTML-ENTITIES encoding).</li>
  <li>Fixed bug <a href="http://bugs.php.net/62934">#62934</a> (mb_convert_kana() does not convert iteration marks).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75001">#75001</a> (Wrong reflection on mb_eregi_replace).</li>
</ul></li>
<li>MySQLi:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74968">#74968</a> (PHP crashes when calling mysqli_result::fetch_object with an abstract class).</li>
</ul></li>
<li>OCI8:
<ul>
  <li>Expose oci_unregister_taf_callback() (Tianfang Yang)</li>
</ul></li>
<li>phar:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74991">#74991</a> (include_path has a 4096 char limit in some cases).</li>
</ul></li>
<li>Reflection:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74949">#74949</a> (null pointer dereference in _function_string).</li>
</ul></li>
<li>Session:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74833">#74833</a> (SID constant created with wrong module number).</li>
</ul></li>
<li>SimpleXML:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74950">#74950</a> (nullpointer deref in simplexml_element_getDocNamespaces).</li>
</ul></li>
<li>SPL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75049">#75049</a> (spl_autoload_unregister can't handle spl_autoload_functions results).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74669">#74669</a> (Unserialize ArrayIterator broken).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75015">#75015</a> (Crash in recursive iterator destructors).</li>
</ul></li>
<li>Standard:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/75075">#75075</a> (unpack with X* causes infinity loop).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74103">#74103</a> (heap-use-after-free when unserializing invalid array size).</li>
  <li>Fixed bug <a href="http://bugs.php.net/75054">#75054</a> (A Denial of Service Vulnerability was found when performing deserialization).</li>
</ul></li>
<li>WDDX:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73793">#73793</a> (WDDX uses wrong decimal seperator).</li>
</ul></li>
<li>XMLRPC:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74975">#74975</a> (Incorrect xmlrpc serialization for classes with declared properties).</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.1.8"><!-- {{{ 7.1.8 -->
<h3>Version 7.1.8</h3>
<b><time class='releasedate' datetime='2017-08-03'>03 Aug 2017</time></b>
<ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74832">#74832</a> (Loading PHP extension with already registered function name leads to a crash).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74780">#74780</a> (parse_url() broken when query string contains colon).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74761">#74761</a> (Unary operator expected error on some systems).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73900">#73900</a> (Use After Free in unserialize() SplFixedArray).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74923">#74923</a> (Crash when crawling through network share).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74913">#74913</a> (fixed incorrect poll.h include).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74906">#74906</a> (fixed incorrect errno.h include).</li>
</ul></li>
<li>Date:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74852">#74852</a> (property_exists returns true on unknown DateInterval property).</li>
</ul></li>
<li>OCI8:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74625">#74625</a> (Integer overflow in oci_bind_array_by_name).</li>
</ul></li>
<li>Opcache:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74623">#74623</a> (Infinite loop in type inference when using HTMLPurifier).</li>
</ul></li>
<li>OpenSSL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74798">#74798</a> (pkcs7_en/decrypt does not work if \x0a is used in content).</li>
  <li>Added OPENSSL_DONT_ZERO_PAD_KEY constant to prevent key padding and fix bug #71917 (openssl_open() returns junk on envelope &lt; 16 bytes) and bug #72362 (OpenSSL Blowfish encryption is incorrect for short keys).</li>
</ul></li>
<li>PDO:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/69356">#69356</a> (PDOStatement::debugDumpParams() truncates query).</li>
</ul></li>
<li>SPL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73471">#73471</a> (PHP freezes with AppendIterator).</li>
</ul></li>
<li>SQLite3:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74883">#74883</a> (SQLite3::__construct() produces "out of memory" exception with invalid flags).</li>
</ul></li>
<li>Wddx:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73173">#73173</a> (huge memleak when wddx_unserialize).</li>
</ul></li>
<li>zlib:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73944">#73944</a> (dictionary option of inflate_init() does not work).</li>
</ul></li>
</ul>
<!-- }}} --></section>


<section class="version" id="7.0.22"><!-- {{{ 7.0.22 -->
<h3>Version 7.0.22</h3>
<b><time class='releasedate' datetime='2017-08-03'>03 Aug 2017</time></b>
<ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74832">#74832</a> (Loading PHP extension with already registered function name leads to a crash).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74780">#74780</a> (parse_url() borken when query string contains colon).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74761">#74761</a> (Unary operator expected error on some systems).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73900">#73900</a> (Use After Free in unserialize() SplFixedArray).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74913">#74913</a> (fixed incorrect poll.h include).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74906">#74906</a> (fixed incorrect errno.h include).</li>
</ul></li>
<li>Date:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74852">#74852</a> (property_exists returns true on unknown DateInterval property).</li>
</ul></li>
<li>OCI8:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74625">#74625</a> (Integer overflow in oci_bind_array_by_name).</li>
</ul></li>
<li>Opcache:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74840">#74840</a> (Opcache overwrites argument of GENERATOR_RETURN within finally).</li>
</ul></li>
<li>PDO:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/69356">#69356</a> (PDOStatement::debugDumpParams() truncates query).</li>
</ul></li>
<li>SPL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73471">#73471</a> (PHP freezes with AppendIterator).</li>
</ul></li>
<li>SQLite3:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74883">#74883</a> (SQLite3::__construct() produces "out of memory" exception with invalid flags).</li>
</ul></li>
<li>Wddx:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73173">#73173</a> (huge memleak when wddx_unserialize).</li>
</ul></li>
<li>zlib:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73944">#73944</a> (dictionary option of inflate_init() does not work).</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.1.7"><!-- {{{ 7.1.7 -->
<h3>Version 7.1.7</h3>
<b><time class='releasedate' datetime='2017-07-06'>06 Jul 2017</time></b>
<ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74738">#74738</a> (Multiple [PATH=] and [HOST=] sections not properly parsed).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74658">#74658</a> (Undefined constants in array properties result in broken properties).</li>
  <li>Fixed misparsing of abstract unix domain socket names.</li>
  <li>Fixed bug <a href="http://bugs.php.net/74603">#74603</a> (PHP INI Parsing Stack Buffer Overflow Vulnerability).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74101">#74101</a>, bug #74614 (Unserialize Heap Use-After-Free (READ: 1) in zval_get_type).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74111">#74111</a> (Heap buffer overread (READ: 1) finish_nested_data from unserialize).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74819">#74819</a> (wddx_deserialize() heap out-of-bound read via php_parse_date()).</li>
</ul></li>
<li>Date:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74639">#74639</a> (implement clone for DatePeriod and DateInterval).</li>
</ul></li>
<li>DOM:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/69373">#69373</a> (References to deleted XPath query results).</li>
</ul></li>
<li>GD:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74435">#74435</a> (Buffer over-read into uninitialized memory). (CVE-2017-7890)</li>
</ul></li>
<li>Intl:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73473">#73473</a> (Stack Buffer Overflow in msgfmt_parse_message).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74705">#74705</a> (Wrong reflection on Collator::getSortKey and collator_get_sort_key).</li>
</ul></li>
<li>Mbstring:
<ul>
  <li>Add oniguruma upstream fix (CVE-2017-9224, CVE-2017-9226, CVE-2017-9227, CVE-2017-9228, CVE-2017-9229)</li>
</ul></li>
<li>OCI8:
<ul>
  <li>Add TAF callback (PR #2459).</li>
</ul></li>
<li>Opcache:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74663">#74663</a> (Segfault with opcache.memory_protect and validate_timestamp).</li>
  <li>Revert opcache.enable_cli to default disabled.</li>
</ul></li>
<li>OpenSSL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74720">#74720</a> (pkcs7_en/decrypt does not work if \x1a is used in content).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74651">#74651</a> (negative-size-param (-1) in memcpy in zif_openssl_seal()).</li>
</ul></li>
<li>PDO_OCI:
<ul>
  <li>Support Instant Client 12.2 in --with-pdo-oci configure option.</li>
</ul></li>
<li>Reflection:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74673">#74673</a> (Segfault when cast Reflection object to string with undefined constant).</li>
</ul></li>
<li>SPL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74478">#74478</a> (null coalescing operator failing with SplFixedArray).</li>
</ul></li>
<li>FTP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74598">#74598</a> (ftp:// wrapper ignores context arg).</li>
</ul></li>
<li>PHAR:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74386">#74386</a> (Phar::__construct reflection incorrect).</li>
</ul></li>
<li>SOAP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74679">#74679</a> (Incorrect conversion array with WSDL_CACHE_MEMORY).</li>
</ul></li>
<li>Streams:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74556">#74556</a> (stream_socket_get_name() returns '\0').</li>
</ul></li>
</ul>
<!-- }}} --></section>


<section class="version" id="7.0.21"><!-- {{{ 7.0.21 -->
<h3>Version 7.0.21</h3>
<b><time class='releasedate' datetime='2017-07-06'>06 Jul 2017</time></b>
<ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74738">#74738</a> (Multiple [PATH=] and [HOST=] sections not properly parsed).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74658">#74658</a> (Undefined constants in array properties result in broken properties).</li>
  <li>Fixed misparsing of abstract unix domain socket names.</li>
  <li>Fixed bug <a href="http://bugs.php.net/74101">#74101</a>, bug #74614 (Unserialize Heap Use-After-Free (READ: 1) in zval_get_type).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74111">#74111</a> (Heap buffer overread (READ: 1) finish_nested_data from unserialize).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74603">#74603</a> (PHP INI Parsing Stack Buffer Overflow Vulnerability).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74819">#74819</a> (wddx_deserialize() heap out-of-bound read via php_parse_date()).</li>
</ul></li>
<li>DOM:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/69373">#69373</a> (References to deleted XPath query results).</li>
</ul></li>
<li>GD:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74435">#74435</a> (Buffer over-read into uninitialized memory). (CVE-2017-7890)</li>
</ul></li>
<li>Intl:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73473">#73473</a> (Stack Buffer Overflow in msgfmt_parse_message).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74705">#74705</a> (Wrong reflection on Collator::getSortKey and collator_get_sort_key).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73634">#73634</a> (grapheme_strpos illegal memory access).</li>
</ul></li>
<li>Mbstring:
<ul>
  <li>Add oniguruma upstream fix (CVE-2017-9224, CVE-2017-9226, CVE-2017-9227, CVE-2017-9228, CVE-2017-9229)</li>
</ul></li>
<li>OCI8:
<ul>
  <li>Add TAF callback (PR #2459).</li>
</ul></li>
<li>Opcache:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74663">#74663</a> (Segfault with opcache.memory_protect and validate_timestamp).</li>
</ul></li>
<li>OpenSSL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74651">#74651</a> (negative-size-param (-1) in memcpy in zif_openssl_seal()).</li>
</ul></li>
<li>PCRE:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74087">#74087</a> (Segmentation fault in PHP7.1.1(compiled using the bundled PCRE library)).</li>
</ul></li>
<li>PDO_OCI:
<ul>
  <li>Support Instant Client 12.2 in --with-pdo-oci configure option.</li>
</ul></li>
<li>Reflection:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74673">#74673</a> (Segfault when cast Reflection object to string with undefined constant).</li>
</ul></li>
<li>SPL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74478">#74478</a> (null coalescing operator failing with SplFixedArray).</li>
</ul></li>
<li>Standard:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74708">#74708</a> (Invalid Reflection signatures for random_bytes and random_int).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73648">#73648</a> (Heap buffer overflow in substr).</li>
</ul></li>
<li>FTP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74598">#74598</a> (ftp:// wrapper ignores context arg).</li>
</ul></li>
<li>PHAR:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74386">#74386</a> (Phar::__construct reflection incorrect).</li>
</ul></li>
<li>SOAP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74679">#74679</a> (Incorrect conversion array with WSDL_CACHE_MEMORY).</li>
</ul></li>
<li>Streams:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74556">#74556</a> (stream_socket_get_name() returns '\0').</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.1.6"><!-- {{{ 7.1.6 -->
<h3>Version 7.1.6</h3>
<b><time class='releasedate' datetime='2017-06-07'>07 Jun 2017</time></b>
<ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74600">#74600</a> (crash (SIGSEGV) in _zend_hash_add_or_update_i).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74546">#74546</a> (SIGILL in ZEND_FETCH_CLASS_CONSTANT_SPEC_CONST_CONST).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74589">#74589</a> (__DIR__ wrong for unicode character).</li>
</ul></li>
<li>intl:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74468">#74468</a> (wrong reflection on Collator::sortWithSortKeys).</li>
</ul></li>
<li>MySQLi:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74547">#74547</a> (mysqli::change_user() doesn't accept null as $database argument w/strict_types).</li>
</ul></li>
<li>Opcache:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74596">#74596</a> (SIGSEGV with opcache.revalidate_path enabled).</li>
</ul></li>
<li>phar:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/51918">#51918</a> (Phar::webPhar() does not handle requests sent through PUT and DELETE method).</li>
</ul></li>
<li>Readline:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74490">#74490</a> (readline() moves the cursor to the beginning of the line).</li>
</ul></li>
<li>Standard:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74510">#74510</a> (win32/sendmail.c anchors CC header but not BCC).</li>
</ul></li>
<li>xmlreader:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74457">#74457</a> (Wrong reflection on XMLReader::expand).</li>
</ul></li>
</ul>
<!-- }}} --></section>


<section class="version" id="7.0.20"><!-- {{{ 7.0.20 -->
<h3>Version 7.0.20</h3>
<b><time class='releasedate' datetime='2017-06-08'>08 Jun 2017</time></b>
<ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74600">#74600</a> (crash (SIGSEGV) in _zend_hash_add_or_update_i).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74546">#74546</a> (SIGILL in ZEND_FETCH_CLASS_CONSTANT_SPEC_CONST_CONST).</li>
</ul></li>
<li>intl:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74468">#74468</a> (wrong reflection on Collator::sortWithSortKeys).</li>
</ul></li>
<li>MySQLi:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74547">#74547</a> (mysqli::change_user() doesn't accept null as $database argument w/strict_types).</li>
</ul></li>
<li>Opcache:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74596">#74596</a> (SIGSEGV with opcache.revalidate_path enabled).</li>
</ul></li>
<li>phar:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/51918">#51918</a> (Phar::webPhar() does not handle requests sent through PUT and DELETE method).</li>
</ul></li>
<li>Standard:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74510">#74510</a> (win32/sendmail.c anchors CC header but not BCC).</li>
</ul></li>
<li>xmlreader:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74457">#74457</a> (Wrong reflection on XMLReader::expand).</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.1.5"><!-- {{{ 7.1.5 -->
<h3>Version 7.1.5</h3>
<b><time class='releasedate' datetime='2017-05-11'>11 May 2017</time></b>
<ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74408">#74408</a> (Endless loop bypassing execution time limit).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74353">#74353</a> (Segfault when killing within bash script trap code).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74340">#74340</a> (Magic function __get has different behavior in php 7.1.x).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74188">#74188</a> (Null coalescing operator fails for undeclared static class properties).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74444">#74444</a> (multiple catch freezes in some cases).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74410">#74410</a> (stream_select() is broken on Windows Nanoserver).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74337">#74337</a> (php-cgi.exe crash on facebook callback).</li>
</ul></li>
<li>Date:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74404">#74404</a> (Wrong reflection on DateTimeZone::getTransitions).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74080">#74080</a> (add constant for RFC7231 format datetime).</li>
</ul></li>
<li>DOM:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74416">#74416</a> (Wrong reflection on DOMNode::cloneNode).</li>
</ul></li>
<li>Fileinfo:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74379">#74379</a> (syntax error compile error in libmagic/apprentice.c).</li>
</ul></li>
<li>GD:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74343">#74343</a> (compile fails on solaris 11 with system gd2 library).</li>
</ul></li>
<li>MySQLnd:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74376">#74376</a> (Invalid free of persistent results on error/connection loss).</li>
</ul></li>
<li>Intl:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/65683">#65683</a> (Intl does not support DateTimeImmutable).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74298">#74298</a> (IntlDateFormatter-&gt;format() doesn't return microseconds/fractions).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74433">#74433</a> (wrong reflection for Normalizer methods).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74439">#74439</a> (wrong reflection for Locale methods).</li>
</ul></li>
<li>Opcache:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74456">#74456</a> (Segmentation error while running a script in CLI mode).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74431">#74431</a> (foreach infinite loop).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74442">#74442</a> (Opcached version produces a nested array).</li>
</ul></li>
<li>OpenSSL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73833">#73833</a> (null character not allowed in openssl_pkey_get_private).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73711">#73711</a> (Segfault in openssl_pkey_new when generating DSA or DH key).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74341">#74341</a> (openssl_x509_parse fails to parse ASN.1 UTCTime without seconds).</li>
</ul></li>
<li>phar:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74383">#74383</a> (phar method parameters reflection correction).</li>
</ul></li>
<li>Readline:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74489">#74489</a> (readline() immediately returns false in interactive console mode).</li>
</ul></li>
<li>Standard:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72071">#72071</a> (setcookie allows max-age to be negative).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74361">#74361</a> (Compaction in array_rand() violates COW).</li>
</ul></li>
<li>Streams:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74429">#74429</a> (Remote socket URI with unique persistence identifier broken).</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.0.19"><!-- {{{ 7.0.19 -->
<h3>Version 7.0.19</h3>
<b><time class='releasedate' datetime='2017-05-11'>11 May 2017</time></b>
<ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74188">#74188</a> (Null coalescing operator fails for undeclared static class properties).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74408">#74408</a> (Endless loop bypassing execution time limit).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74410">#74410</a> (stream_select() is broken on Windows Nanoserver).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74337">#74337</a> (php-cgi.exe crash on facebook callback).</li>
  <li>Patch for bug <a href="http://bugs.php.net/74216">#74216</a> was reverted.</li>
</ul></li>
<li>Date:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74404">#74404</a> (Wrong reflection on DateTimeZone::getTransitions).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74080">#74080</a> (add constant for RFC7231 format datetime).</li>
</ul></li>
<li>DOM:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74416">#74416</a> (Wrong reflection on DOMNode::cloneNode).</li>
</ul></li>
<li>Fileinfo:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74379">#74379</a> (syntax error compile error in libmagic/apprentice.c).</li>
</ul></li>
<li>GD:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74343">#74343</a> (compile fails on solaris 11 with system gd2 library).</li>
</ul></li>
<li>intl:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74433">#74433</a> (wrong reflection for Normalizer methods).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74439">#74439</a> (wrong reflection for Locale methods).</li>
</ul></li>
<li>MySQLi:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74432">#74432</a> (mysqli_connect adding ":3306" to $host if $port parameter not given).</li>
</ul></li>
<li>MySQLnd:
<ul>
  <li>Added support for MySQL 8.0 types.</li>
  <li>Fixed bug <a href="http://bugs.php.net/74376">#74376</a> (Invalid free of persistent results on error/connection loss).</li>
</ul></li>
<li>OpenSSL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73833">#73833</a> (null character not allowed in openssl_pkey_get_private).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73711">#73711</a> (Segfault in openssl_pkey_new when generating DSA or DH key).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74341">#74341</a> (openssl_x509_parse fails to parse ASN.1 UTCTime without seconds).</li>
  <li>Added OpenSSL 1.1.0 support.</li>
</ul></li>
<li>phar:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74383">#74383</a> (phar method parameters reflection correction).</li>
</ul></li>
<li>Standard:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74409">#74409</a> (Reflection information for ini_get_all() is incomplete).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72071">#72071</a> (setcookie allows max-age to be negative).</li>
</ul></li>
<li>Streams:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74429">#74429</a> (Remote socket URI with unique persistence identifier broken).</li>
</ul></li>
<li>SQLite3:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74413">#74413</a> (incorrect reflection for SQLite3::enableExceptions).</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.1.4"><!-- {{{ 7.1.4 -->
<h3>Version 7.1.4</h3>
<b><time class='releasedate' datetime='2017-04-13'>13 Apr 2017</time></b>
<ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74149">#74149</a> (static embed SAPI linkage error).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73370">#73370</a> (falsely exits with "Out of Memory" when using USE_ZEND_ALLOC=0).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73960">#73960</a> (Leak with instance method calling static method with referenced return).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69676">#69676</a> (Resolution of self::FOO in class constants not correct).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74265">#74265</a> (Build problems after 7.0.17 release: undefined reference to `isfinite').</li>
  <li>Fixed bug <a href="http://bugs.php.net/74302">#74302</a> (yield fromLABEL is over-greedy).</li>
</ul></li>
<li>Apache:
<ul>
  <li>Reverted patch for bug #61471, fixes bug #74318.</li>
</ul></li>
<li>Date:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72096">#72096</a> (Swatch time value incorrect for dates before 1970).</li>
</ul></li>
<li>DOM:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74004">#74004</a> (LIBXML_NOWARNING flag ingnored on loadHTML*).</li>
</ul></li>
<li>iconv:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74230">#74230</a> (iconv fails to fail on surrogates).</li>
</ul></li>
<li>Opcache:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74250">#74250</a> (OPcache compilation performance regression in PHP 5.6/7 with huge classes).</li>
</ul></li>
<li>OpenSSL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72333">#72333</a> (fwrite() on non-blocking SSL sockets doesn't work).</li>
</ul></li>
<li>PDO MySQL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71003">#71003</a> (Expose MYSQLI_CLIENT_SSL_DONT_VERIFY_SERVER_CERT to PDO interface).</li>
</ul></li>
<li>SPL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74058">#74058</a> (ArrayObject can not notice changes).</li>
</ul></li>
<li>SQLite:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74217">#74217</a> (Allow creation of deterministic sqlite functions).</li>
</ul></li>
<li>Streams:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74216">#74216</a> (Correctly fail on invalid IP address ports).</li>
</ul></li>
<li>zlib:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74240">#74240</a> (deflate_add can allocate too much memory).</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.0.18"><!-- {{{ 7.0.18 -->
<h3>Version 7.0.18</h3>
<b><time class='releasedate' datetime='2017-04-13'>13 Apr 2017</time></b>
<ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73370">#73370</a> (falsely exits with "Out of Memory" when using USE_ZEND_ALLOC=0).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73960">#73960</a> (Leak with instance method calling static method with referenced return).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74265">#74265</a> (Build problems after 7.0.17 release: undefined reference to `isfinite').</li>
  <li>Fixed bug <a href="http://bugs.php.net/74302">#74302</a> (yield fromLABEL is over-greedy).</li>
</ul></li>
<li>Apache:
<ul>
  <li>Reverted patch for bug #61471, fixes bug #74318.</li>
</ul></li>
<li>Date:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72096">#72096</a> (Swatch time value incorrect for dates before 1970).</li>
</ul></li>
<li>DOM:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74004">#74004</a> (LIBXML_NOWARNING flag ingnored on loadHTML*).</li>
</ul></li>
<li>iconv:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74230">#74230</a> (iconv fails to fail on surrogates).</li>
</ul></li>
<li>OpenSSL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72333">#72333</a> (fwrite() on non-blocking SSL sockets doesn't work).</li>
</ul></li>
<li>PDO MySQL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71003">#71003</a> (Expose MYSQLI_CLIENT_SSL_DONT_VERIFY_SERVER_CERT to PDO interface).</li>
</ul></li>
<li>Streams:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74216">#74216</a> (Correctly fail on invalid IP address ports).</li>
</ul></li>
<li>Zlib:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74240">#74240</a> (deflate_add can allocate too much memory).</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.1.3"><!-- {{{ 7.1.3 -->
<h3>Version 7.1.3</h3>
<b><time class='releasedate' datetime='2017-03-16'>16 Mar 2017</time></b>
<ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74157">#74157</a> (Segfault with nested generators).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74164">#74164</a> (PHP hangs when an invalid value is dynamically passed to typehinted by-ref arg).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74093">#74093</a> (Maximum execution time of n+2 seconds exceed not written in error_log).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73989">#73989</a> (PHP 7.1 Segfaults within Symfony test suite).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74084">#74084</a> (Out of bound read - zend_mm_alloc_small).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73807">#73807</a> (Performance problem with processing large post request).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73998">#73998</a> (array_key_exists fails on arrays created by get_object_vars).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73954">#73954</a> (NAN check fails on Alpine Linux with musl).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73677">#73677</a> (Generating phar.phar core dump with gcc ASAN enabled build).</li>
</ul></li>
<li>Apache:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/61471">#61471</a> (Incomplete POST does not timeout but is passed to PHP).</li>
</ul></li>
<li>Date:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73837">#73837</a> ("new DateTime()" sometimes returns 1 second ago value).</li>
</ul></li>
<li>FPM:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/69860">#69860</a> (php-fpm process accounting is broken with keepalive).</li>
</ul></li>
<li>Hash:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73127">#73127</a> (gost-crypto hash incorrect if input data contains long 0xFF sequence).</li>
</ul></li>
<li>GD:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74031">#74031</a> (ReflectionFunction for imagepng is missing last two parameters).</li>
</ul></li>
<li>Mysqlnd:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74021">#74021</a> (fetch_array broken data. Data more then MEDIUMBLOB).</li>
</ul></li>
<li>Opcache:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74019">#74019</a> (Segfault with list).</li>
</ul></li>
<li>OpenSSL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74022">#74022</a> (PHP Fast CGI crashes when reading from a pfx file).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74099">#74099</a> (Memory leak with openssl_encrypt()).</li>
</ul></li>
<li>Standard:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74005">#74005</a> (mail.add_x_header causes RFC-breaking lone line feed).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74041">#74041</a> (substr_count with length=0 broken).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73118">#73118</a> (is_callable callable name reports misleading value for anonymous classes).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74105">#74105</a> (PHP on Linux should use /dev/urandom when getrandom is not available).</li>
</ul></li>
<li>Streams:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73496">#73496</a> (Invalid memory access in zend_inline_hash_func).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74090">#74090</a> (stream_get_contents maxlength&gt;-1 returns empty string).</li>
</ul></li>
</ul>
<!-- }}} --></section>


<section class="version" id="7.0.17"><!-- {{{ 7.0.17 -->
<h3>Version 7.0.17</h3>
<b><time class='releasedate' datetime='2017-03-16'>16 Mar 2017</time></b>
<ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73989">#73989</a> (PHP 7.1 Segfaults within Symfony test suite).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74084">#74084</a> (Out of bound read - zend_mm_alloc_small).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73807">#73807</a> (Performance problem with processing large post request).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73998">#73998</a> (array_key_exists fails on arrays created by get_object_vars).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73954">#73954</a> (NAN check fails on Alpine Linux with musl).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74039">#74039</a> (is_infinite(-INF) returns false).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73677">#73677</a> (Generating phar.phar core dump with gcc ASAN enabled build).</li>
</ul></li>
<li>Apache:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/61471">#61471</a> (Incomplete POST does not timeout but is passed to PHP).</li>
</ul></li>
<li>Date:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72719">#72719</a> (Relative datetime format ignores weekday on sundays only).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73294">#73294</a> (DateTime wrong when date string is negative).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73489">#73489</a> (wrong timestamp when call setTimeZone multi times with UTC offset).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73858">#73858</a> (first/last day of' flag is not being reset).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73942">#73942</a> ($date-&gt;modify('Friday this week') doesn't return a Friday if $date is a Sunday).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74057">#74057</a> (wrong day when using "this week" in strtotime).</li>
</ul></li>
<li>FPM:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/69860">#69860</a> (php-fpm process accounting is broken with keepalive).</li>
</ul></li>
<li>Hash:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73127">#73127</a> (gost-crypto hash incorrect if input data contains long 0xFF sequence).</li>
</ul></li>
<li>GD:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74031">#74031</a> (ReflectionFunction for imagepng is missing last two parameters).</li>
</ul></li>
<li>Mysqlnd:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74021">#74021</a> (fetch_array broken data. Data more then MEDIUMBLOB).</li>
</ul></li>
<li>Opcache:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74152">#74152</a> (if statement says true to a null variable).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74019">#74019</a> (Segfault with list).</li>
</ul></li>
<li>OpenSSL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74022">#74022</a> (PHP Fast CGI crashes when reading from a pfx file).</li>
</ul></li>
<li>Standard:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/74148">#74148</a> (ReflectionFunction incorrectly reports the number of arguments).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74005">#74005</a> (mail.add_x_header causes RFC-breaking lone line feed).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73118">#73118</a> (is_callable callable name reports misleading value for anonymous classes).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74105">#74105</a> (PHP on Linux should use /dev/urandom when getrandom is not available).</li>
</ul></li>
<li>Streams:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73496">#73496</a> (Invalid memory access in zend_inline_hash_func).</li>
  <li>Fixed bug <a href="http://bugs.php.net/74090">#74090</a> (stream_get_contents maxlength&gt;-1 returns empty string).</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.1.2"><!-- {{{ 7.1.2 -->
<h3>Version 7.1.2</h3>
<b><time class='releasedate' datetime='2017-02-16'>16 Feb 2017</time></b>
<ul><li>Core:
<ul>
  <li>Improved GENERATOR_CREATE opcode handler.</li>
  <li>Fixed bug <a href="http://bugs.php.net/73877">#73877</a> (readlink() returns garbage for UTF-8 paths).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73876">#73876</a> (Crash when exporting **= in expansion of assign op).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73962">#73962</a> (bug with symlink related to cyrillic directory).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73969">#73969</a> (segfault in debug_print_backtrace).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73994">#73994</a> (arginfo incorrect for unpack).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73973">#73973</a> (assertion error in debug_zval_dump).</li>
</ul></li>
<li>DOM:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/54382">#54382</a> (getAttributeNodeNS doesn't get xmlns* attributes).</li>
</ul></li>
<li>DTrace:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73965">#73965</a> (DTrace reported as enabled when disabled).</li>
</ul></li>
<li>FCGI:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73904">#73904</a> (php-cgi fails to load -c specified php.ini file).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72898">#72898</a> (PHP_FCGI_CHILDREN is not included in phpinfo()).</li>
</ul></li>
<li>FPM:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/69865">#69865</a> (php-fpm does not close stderr when using syslog).</li>
</ul></li>
<li>GD:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73968">#73968</a> (Premature failing of XBM reading).</li>
</ul></li>
<li>GMP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/69993">#69993</a> (test for gmp.h needs to test machine includes).</li>
</ul></li>
<li>Hash:
<ul>
  <li>Added hash_hkdf() function.</li>
  <li>Fixed bug <a href="http://bugs.php.net/73961">#73961</a> (environmental build dependency in hash sha3 source).</li>
</ul></li>
<li>Intl:
<ul>
  <li>Fix bug #73956 (Link use CC instead of CXX).</li>
</ul></li>
<li>LDAP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73933">#73933</a> (error/segfault with ldap_mod_replace and opcache).</li>
</ul></li>
<li>MySQLi:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73949">#73949</a> (leak in mysqli_fetch_object).</li>
</ul></li>
<li>Mysqlnd:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/69899">#69899</a> (segfault on close() after free_result() with mysqlnd).</li>
</ul></li>
<li>Opcache:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73983">#73983</a> (crash on finish work with phar in cli + opcache).</li>
</ul></li>
<li>OpenSSL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71519">#71519</a> (add serial hex to return value array).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73692">#73692</a> (Compile ext/openssl with openssl 1.1.0 on Win).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73978">#73978</a> (openssl_decrypt triggers bug in PDO).</li>
</ul></li>
<li>PDO_Firebird:
<ul>
  <li>Implemented FR <a href="http://bugs.php.net/72583">#72583</a> (All data are fetched as strings).</li>
</ul></li>
<li>PDO_PgSQL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73959">#73959</a> (lastInsertId fails to throw an exception for wrong sequence name).</li>
</ul></li>
<li>Phar:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70417">#70417</a> (PharData::compress() doesn't close temp file).</li>
</ul></li>
<li>posix:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71219">#71219</a> (configure script incorrectly checks for ttyname_r).</li>
</ul></li>
<li>Session:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/69582">#69582</a> (session not readable by root in CLI).</li>
</ul></li>
<li>SPL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73896">#73896</a> (spl_autoload() crashes when calls magic _call()).</li>
</ul></li>
<li>Standard:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/69442">#69442</a> (closing of fd incorrect when PTS enabled).</li>
  <li>Fixed bug <a href="http://bugs.php.net/47021">#47021</a> (SoapClient stumbles over WSDL delivered with "Transfer-Encoding: chunked").</li>
  <li>Fixed bug <a href="http://bugs.php.net/72974">#72974</a> (imap is undefined service on AIX).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72979">#72979</a> (money_format stores wrong length AIX).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73374">#73374</a> (intval() with base 0 should detect binary).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69061">#69061</a> (mail.log = syslog contains double information).</li>
</ul></li>
<li>ZIP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70103">#70103</a> (ZipArchive::addGlob ignores remove_all_path option).</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.0.16"><!-- {{{ 7.0.16 -->
<h3>Version 7.0.16</h3>
<b><time class='releasedate' datetime='2017-02-16'>16 Feb 2017</time></b>
<ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73916">#73916</a> (zend_print_flat_zval_r doesn't consider reference).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73876">#73876</a> (Crash when exporting **= in expansion of assign op).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73969">#73969</a> (segfault in debug_print_backtrace).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73973">#73973</a> (assertion error in debug_zval_dump).</li>
</ul></li>
<li>DOM:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/54382">#54382</a> (getAttributeNodeNS doesn't get xmlns* attributes).</li>
</ul></li>
<li>DTrace:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73965">#73965</a> (DTrace reported as enabled when disabled).</li>
</ul></li>
<li>FPM:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/67583">#67583</a> (double fastcgi_end_request on max_children limit).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69865">#69865</a> (php-fpm does not close stderr when using syslog).</li>
</ul></li>
<li>GD:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73968">#73968</a> (Premature failing of XBM reading).</li>
</ul></li>
<li>GMP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/69993">#69993</a> (test for gmp.h needs to test machine includes).</li>
</ul></li>
<li>Intl:
<ul>
<li>Fixed bug <a href="http://bugs.php.net/73956">#73956</a> (Link use CC instead of CXX).</li>
</ul></li>
<li>LDAP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73933">#73933</a> (error/segfault with ldap_mod_replace and opcache).</li>
</ul></li>
<li>MySQLi:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73949">#73949</a> (leak in mysqli_fetch_object).</li>
</ul></li>
<li>Mysqlnd:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/69899">#69899</a> (segfault on close() after free_result() with mysqlnd).</li>
</ul></li>
<li>Opcache:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73983">#73983</a> (crash on finish work with phar in cli + opcache).</li>
</ul></li>
<li>OpenSSL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71519">#71519</a> (add serial hex to return value array).</li>
</ul></li>
<li>PDO_Firebird:
<ul>
  <li>Implemented FR <a href="http://bugs.php.net/72583">#72583</a> (All data are fetched as strings).</li>
</ul></li>
<li>PDO_PgSQL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73959">#73959</a> (lastInsertId fails to throw an exception for wrong sequence name).</li>
</ul></li>
<li>Phar:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70417">#70417</a> (PharData::compress() doesn't close temp file).</li>
</ul></li>
<li>posix:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71219">#71219</a> (configure script incorrectly checks for ttyname_r).</li>
</ul></li>
<li>Session:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/69582">#69582</a> (session not readable by root in CLI).</li>
</ul></li>
<li>SPL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73896">#73896</a> (spl_autoload() crashes when calls magic _call()).</li>
</ul></li>
<li>Standard:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/69442">#69442</a> (closing of fd incorrect when PTS enabled).</li>
  <li>Fixed bug <a href="http://bugs.php.net/47021">#47021</a> (SoapClient stumbles over WSDL delivered with "Transfer-Encoding: chunked").</li>
  <li>Fixed bug <a href="http://bugs.php.net/72974">#72974</a> (imap is undefined service on AIX).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72979">#72979</a> (money_format stores wrong length AIX).</li>
</ul></li>
<li>ZIP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70103">#70103</a> (ZipArchive::addGlob ignores remove_all_path option).</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.0.15"><!-- {{{ 7.0.15 -->
<h3>Version 7.0.15</h3>
<b><time class='releasedate' datetime='2017-01-19'>19 Jan 2017</time></b>
<ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73792">#73792</a> (invalid foreach loop hangs script).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73663">#73663</a> ("Invalid opcode 65/16/8" occurs with a variable created with list()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73585">#73585</a> (Logging of "Internal Zend error - Missing class information" missing class name).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73753">#73753</a> (unserialized array pointer not advancing).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73825">#73825</a> (Heap out of bounds read on unserialize in finish_nested_data()). (CVE-2016-10161)</li>
  <li>Fixed bug <a href="http://bugs.php.net/73831">#73831</a> (NULL Pointer Dereference while unserialize php object). (CVE-2016-10162)</li>
  <li>Fixed bug <a href="http://bugs.php.net/73832">#73832</a> (Use of uninitialized memory in unserialize()). (CVE-2017-5340)</li>
  <li>Fixed bug <a href="http://bugs.php.net/73092">#73092</a> (Unserialize use-after-free when resizing object's properties hash table). (CVE-2016-7479)</li>
  <li>Fixed bug <a href="http://bugs.php.net/69425">#69425</a> (Use After Free in unserialize()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72731">#72731</a> (Type Confusion in Object Deserialization).</li>
</ul></li>
<li>COM:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73679">#73679</a> (DOTNET read access violation using invalid codepage).</li>
</ul></li>
<li>DOM:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/67474">#67474</a> (getElementsByTagNameNS filter on default ns).</li>
</ul></li>
<li>EXIF:
<ul>
<li>Fixed bug <a href="http://bugs.php.net/73737">#73737</a> (FPE when parsing a tag format). (CVE-2016-10158)</li>
</ul></li>
<li>GD:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73869">#73869</a> (Signed Integer Overflow gd_io.c). (CVE-2016-10168)</li>
  <li>Fixed bug <a href="http://bugs.php.net/73868">#73868</a> (DOS vulnerability in gdImageCreateFromGd2Ctx()). (CVE-2016-10167)</li>
</ul></li>
<li>GMP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70513">#70513</a> (GMP Deserialization Type Confusion Vulnerability).</li>
</ul></li>
<li>Mysqli:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73462">#73462</a> (Persistent connections don't set $connect_errno).</li>
</ul></li>
<li>Mysqlnd:
<ul>
  <li>Fixed issue with decoding BIT columns when having more than one rows in the result set. 7.0+ problem.</li>
  <li>Fixed bug <a href="http://bugs.php.net/73800">#73800</a> (sporadic segfault with MYSQLI_OPT_INT_AND_FLOAT_NATIVE).</li>
</ul></li>
<li>PCRE:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73612">#73612</a> (preg_*() may leak memory).</li>
</ul></li>
<li>PDO_Firebird:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72931">#72931</a> (PDO_FIREBIRD with Firebird 3.0 not work on returning statement).</li>
</ul></li>
<li>Phar:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73773">#73773</a> (Seg fault when loading hostile phar).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73768">#73768</a> (Memory corruption when loading hostile phar). (CVE-2016-10160)</li>
  <li>Fixed bug <a href="http://bugs.php.net/73764">#73764</a> (Crash while loading hostile phar archive). (CVE-2016-10159)</li>
</ul></li>
<li>Phpdbg:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73615">#73615</a> (phpdbg without option never load .phpdbginit at startup).</li>
  <li>Fixed issue getting executable lines from custom wrappers.</li>
  <li>Fixed bug <a href="http://bugs.php.net/73704">#73704</a> (phpdbg shows the wrong line in files with shebang).</li>
</ul></li>
<li>Reflection:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/46103">#46103</a> (ReflectionObject memory leak).</li>
</ul></li>
<li>Streams:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73586">#73586</a> (php_user_filter::$stream is not set to the stream the filter is working on).</li>
</ul></li>
<li>SQLite3:
<ul>
<li>Reverted fix for <a href="http://bugs.php.net/73530">#73530</a> (Unsetting result set may reset other result set).</li>
</ul></li>
<li>Standard:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73594">#73594</a> (dns_get_record does not populate $additional out parameter).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70213">#70213</a> (Unserialize context shared on double class lookup).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73154">#73154</a> (serialize object with __sleep function crash).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70490">#70490</a> (get_browser function is very slow).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73265">#73265</a> (Loading browscap.ini at startup causes high memory usage).</li>
  <li>Fixed bug <a href="http://bugs.php.net/31875">#31875</a> (get_defined_functions additional param to exclude disabled functions).</li>
</ul></li>
<li>Zlib:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73373">#73373</a> (deflate_add does not verify that output was not truncated).</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.1.1"><!-- {{{ 7.1.1 -->
<h3>Version 7.1.1</h3>
<b><time class='releasedate' datetime='2017-01-19'>19 Jan 2017</time></b>
<ul>
	<li>
	Core
	<ul>
		<li>Fixed bug <a href="http://bugs.php.net/73792">#73792</a> (invalid foreach loop hangs script).</li>
		<li>Fixed bug <a href="http://bugs.php.net/73686">#73686</a> (Adding settype()ed values to ArrayObject results in references).</li>
		<li>Fixed bug <a href="http://bugs.php.net/73663">#73663</a> ("Invalid opcode 65/16/8" occurs with a variable created with list()).</li>
		<li>Fixed bug <a href="http://bugs.php.net/73727">#73727</a> (ZEND_MM_BITSET_LEN is "undefined symbol" in zend_bitset.h).</li>
		<li>Fixed bug <a href="http://bugs.php.net/73753">#73753</a> (unserialized array pointer not advancing).</li>
		<li>Fixed bug <a href="http://bugs.php.net/73783">#73783</a> (SIG_IGN doesn't work when Zend Signals is enabled).</li>
		<li>Fixed bug <a href="http://bugs.php.net/73825">#73825</a> (Heap out of bounds read on unserialize in finish_nested_data()). (CVE-2016-10161)</li>
		<li>Fixed bug <a href="http://bugs.php.net/73831">#73831</a> (NULL Pointer Dereference while unserialize php object). (CVE-2016-10162)</li>
		<li>Fixed bug <a href="http://bugs.php.net/73832">#73832</a> (Use of uninitialized memory in unserialize()). (CVE-2017-5340)</li>
	</ul>
	</li>
	<li>
	CLI
	<ul>
		<li>Fixed bug <a href="http://bugs.php.net/72555">#72555</a> (CLI output(japanese) on Windows).</li>
	</ul>
	</li>
	<li>
	COM
	<ul>
		<li>Fixed bug <a href="http://bugs.php.net/73679">#73679</a> (DOTNET read access violation using invalid codepage).</li>
	</ul>
	</li>
	<li>
	DOM
	<ul>
		<li>Fixed bug <a href="http://bugs.php.net/67474">#67474</a> (getElementsByTagNameNS filter on default ns).</li>
	</ul>
	</li>
	<li>
	EXIF
	<ul>
		<li>Fixed bug <a href="http://bugs.php.net/73737">#73737</a> (FPE when parsing a tag format). (CVE-2016-10158)</li>
	</ul>
	</li>
	<li>
	GD
	<ul>
		<li>Fixed bug <a href="http://bugs.php.net/73869">#73869</a> (Signed Integer Overflow gd_io.c). (CVE-2016-10168)</li>
		<li>Fixed bug <a href="http://bugs.php.net/73868">#73868</a> (DOS vulnerability in gdImageCreateFromGd2Ctx()). (CVE-2016-10167)</li>
	</ul>
	</li>
	<li>
	mbstring
	<ul>
		<li>Fixed bug <a href="http://bugs.php.net/73646">#73646</a> (mb_ereg_search_init null pointer dereference).</li>
	</ul>
	</li>
	<li>
	MySQLi
	<ul>
		<li>Fixed bug <a href="http://bugs.php.net/73462">#73462</a> (Persistent connections don't set $connect_errno).</li>
	</ul>
	</li>
	<li>
	mysqlnd
	<ul>
		<li>Optimized handling of BIT fields - less memory copies and lower memory usage.</li>
		<li>Fixed bug <a href="http://bugs.php.net/73800">#73800</a> (sporadic segfault with MYSQLI_OPT_INT_AND_FLOAT_NATIVE).</li>
	</ul>
	</li>
	<li>
	opcache
	<ul>
		<li>Fixed bug <a href="http://bugs.php.net/73789">#73789</a> (Strange behavior of class constants in switch/case block).</li>
		<li>Fixed bug <a href="http://bugs.php.net/73746">#73746</a> (Method that returns string returns UNKNOWN:0 instead).</li>
		<li>Fixed bug <a href="http://bugs.php.net/73654">#73654</a> (Segmentation fault in zend_call_function).</li>
		<li>Fixed bug <a href="http://bugs.php.net/73668">#73668</a> ("SIGFPE Arithmetic exception" in opcache when divide by minus 1).</li>
		<li>Fixed bug <a href="http://bugs.php.net/73847">#73847</a> (Recursion when a variable is redefined as array).</li>
	</ul>
	</li>
	<li>
	PDO Firebird
	<ul>
		<li>Fixed bug <a href="http://bugs.php.net/72931">#72931</a> (PDO_FIREBIRD with Firebird 3.0 not work on returning statement).</li>
	</ul>
	</li>
	<li>Phar:
	<ul>
		<li>Fixed bug <a href="http://bugs.php.net/73773">#73773</a> (Seg fault when loading hostile phar).</li>
		<li>Fixed bug <a href="http://bugs.php.net/73768">#73768</a> (Memory corruption when loading hostile phar). (CVE-2016-10160)</li>
		<li>Fixed bug <a href="http://bugs.php.net/73764">#73764</a> (Crash while loading hostile phar archive). (CVE-2016-10159)</li>
	</ul></li>
	<li>
	phpdbg
	<ul>
		<li>Fixed bug <a href="http://bugs.php.net/73794">#73794</a> (Crash (out of memory) when using run and # command separator).</li>
		<li>Fixed bug <a href="http://bugs.php.net/73704">#73704</a> (phpdbg shows the wrong line in files with shebang).</li>
	</ul>
	</li>
	<li>
	SQLite3
	<ul>
		<li>Reverted fix for Fixed bug <a href="http://bugs.php.net/73530">#73530</a> (Unsetting result set may reset other result set).</li>
	</ul>
	</li>
	<li>
	Standard
	<ul>
		<li>Fixed bug <a href="http://bugs.php.net/73594">#73594</a> (dns_get_record does not populate $additional out parameter).</li>
		<li>Fixed bug <a href="http://bugs.php.net/70213">#70213</a> (Unserialize context shared on double class lookup).</li>
		<li>Fixed bug <a href="http://bugs.php.net/73154">#73154</a> (serialize object with __sleep function crash).</li>
		<li>Fixed bug <a href="http://bugs.php.net/70490">#70490</a> (get_browser function is very slow).</li>
		<li>Fixed bug <a href="http://bugs.php.net/73265">#73265</a> (Loading browscap.ini at startup causes high memory usage).</li>
		<li>(add subject to mail log).</li>
		<li>Fixed bug <a href="http://bugs.php.net/31875">#31875</a> (get_defined_functions additional param to exclude disabled functions).</li>
	</ul>
	</li>
	<li>
	zlib
	<ul>
		<li>Fixed bug <a href="http://bugs.php.net/73373">#73373</a> (deflate_add does not verify that output was not truncated).</li>
	</ul>
	</li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.0.14"><!-- {{{ 7.0.14 -->
<h3>Version 7.0.14</h3>
<b><time class='releasedate' datetime='2016-12-08'>08 Dec 2016</time></b>
<ul><li>Core:
<ul>
  <li>Fixed memory leak(null coalescing operator with Spl hash).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72736">#72736</a> (Slow performance when fetching large dataset with mysqli / PDO).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72978">#72978</a> (Use After Free Vulnerability in unserialize()). (CVE-2016-9936)</li>
</ul></li>
<li>Calendar:
<ul>
  <li>(Fix integer overflows).</li>
</ul></li>
<li>Date:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/69587">#69587</a> (DateInterval properties and isset).</li>
</ul></li>
<li>DTrace:
<ul>
  <li>Disabled PHP call tracing by default (it makes significant overhead). This may be enabled again using envirionment variable USE_ZEND_DTRACE=1.</li>
</ul></li>
<li>JSON:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73526">#73526</a> (php_json_encode depth issue).</li>
</ul></li>
<li>Mysqlnd:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/64526">#64526</a> (Add missing mysqlnd.* parameters to php.ini-*).</li>
</ul></li>
<li>ODBC:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73448">#73448</a> (odbc_errormsg returns trash, always 513 bytes).</li>
</ul></li>
<li>Opcache:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/69090">#69090</a> (check cached files permissions).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73546">#73546</a> (Logging for opcache has an empty file name).</li>
</ul></li>
<li>PCRE:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73483">#73483</a> (Segmentation fault on pcre_replace_callback).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73392">#73392</a> (A use-after-free in zend allocator management).</li>
</ul></li>
<li>PDO_Firebird:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73087">#73087</a>, <a href="http://bugs.php.net/61183">#61183</a>, <a href="http://bugs.php.net/71494">#71494</a> (Memory corruption in bindParam).</li>
</ul></li>
<li>Phar:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73580">#73580</a> (Phar::isValidPharFilename illegal memory access).</li>
</ul></li>
<li>Postgres:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73498">#73498</a> (Incorrect SQL generated for pg_copy_to()).</li>
</ul></li>
<li>Soap:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73538">#73538</a> (SoapClient::__setSoapHeaders doesn't overwrite SOAP headers).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73452">#73452</a> (Segfault (Regression for <a href="http://bugs.php.net/69152">#69152</a>)).</li>
</ul></li>
<li>SPL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73423">#73423</a> (Reproducible crash with GDB backtrace).</li>
</ul></li>
<li>SQLite3:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73530">#73530</a> (Unsetting result set may reset other result set).</li>
</ul></li>
<li>Standard:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73297">#73297</a> (HTTP stream wrapper should ignore HTTP 100 Continue).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73645">#73645</a> (version_compare illegal write access).</li>
</ul></li>
<li>Wddx:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73631">#73631</a> (Invalid read when wddx decodes empty boolean element). (CVE-2016-9935)</li>
</ul></li>
<li>XML:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72135">#72135</a> (malformed XML causes fault).</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.1.0"><!-- {{{ 7.1.0 -->
<h3>Version 7.1.0</h3>
<b><time class='releasedate' datetime='2016-12-01'>01 Dec 2016</time></b>
<ul><li>Core:
  <ul>
    <li>Added nullable types.</li>
    <li>Added DFA optimization framework based on e-SSA form.</li>
    <li>Added specialized opcode handlers (e.g. ZEND_ADD_LONG_NO_OVERFLOW).</li>
    <li>Added [] = as alternative construct to list() =.</li>
    <li>Added void return type.</li>
    <li>Added support for negative string offsets in string offset syntax and various string functions.</li>
    <li>Added a form of the list() construct where keys can be specified.</li>
    <li>Implemented safe execution timeout handling, that prevents random crashes after "Maximum execution time exceeded" error.</li>
    <li>Implemented the RFC `Support Class Constant Visibility`.</li>
    <li>Implemented the RFC `Catching multiple exception types`.</li>
    <li>Implemented logging to syslog with dynamic error levels.</li>
    <li>Implemented FR <a href="http://bugs.php.net/72614">#72614</a> (Support "nmake test" on building extensions by phpize).</li>
    <li>Implemented RFC: Iterable.</li>
    <li>Implemented RFC: Closure::fromCallable (Danack)</li>
    <li>Implemented RFC: Replace "Missing argument" warning with "\ArgumentCountError" exception.</li>
    <li>Implemented RFC: Fix inconsistent behavior of $this variable.</li>
    <li>Fixed bug <a href="http://bugs.php.net/73585">#73585</a> (Logging of "Internal Zend error - Missing class information" missing class name).</li>
    <li>Fixed memory leak(null coalescing operator with Spl hash).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72736">#72736</a> (Slow performance when fetching large dataset with mysqli / PDO).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72978">#72978</a> (Use After Free Vulnerability in unserialize()). (CVE-2016-9936)</li>
    <li>Fixed bug <a href="http://bugs.php.net/72482">#72482</a> (Ilegal write/read access caused by gdImageAALine overflow).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72696">#72696</a> (imagefilltoborder stackoverflow on truecolor images). (CVE-2016-9933)</li>
    <li>Fixed bug <a href="http://bugs.php.net/73350">#73350</a> (Exception::__toString() cause circular references).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73329">#73329</a> ((Float)"Nano" == NAN).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73288">#73288</a> (Segfault in __clone &gt; Exception.toString &gt; __get).</li>
    <li>Fixed for #73240 (Write out of bounds at number_format).</li>
    <li>Fix pthreads detection when cross-compiling (ffontaine)</li>
    <li>Fixed bug <a href="http://bugs.php.net/73337">#73337</a> (try/catch not working with two exceptions inside a same operation).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73156">#73156</a> (segfault on undefined function).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73163">#73163</a> (PHP hangs if error handler throws while accessing undef const in default value).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73172">#73172</a> (parse error: Invalid numeric literal).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73181">#73181</a> (parse_str() without a second argument leads to crash).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73025">#73025</a> (Heap Buffer Overflow in virtual_popen of zend_virtual_cwd.c).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73058">#73058</a> (crypt broken when salt is 'too' long).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72944">#72944</a> (Null pointer deref in zval_delref_p).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72943">#72943</a> (assign_dim on string doesn't reset hval).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72598">#72598</a> (Reference is lost after array_slice()).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72703">#72703</a> (Out of bounds global memory read in BF_crypt triggered by password_verify).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72813">#72813</a> (Segfault with __get returned by ref).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72767">#72767</a> (PHP Segfaults when trying to expand an infinite operator).</li>
    <li>TypeError messages for arg_info type checks will now say "must be ... or null" where the parameter or return type accepts null.</li>
    <li>Fixed bug <a href="http://bugs.php.net/72857">#72857</a> (stream_socket_recvfrom read access violation).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72663">#72663</a> (Create an Unexpected Object and Don't Invoke __wakeup() in Deserialization).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72681">#72681</a> (PHP Session Data Injection Vulnerability).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72742">#72742</a> (memory allocator fails to realloc small block to large one).</li>
    <li>Fixed URL rewriter. It would not rewrite '//example.com/' URL unconditionally. URL rewrite target hosts whitelist is implemented.</li>
    <li>Fixed bug <a href="http://bugs.php.net/72641">#72641</a> (phpize (on Windows) ignores PHP_PREFIX).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72683">#72683</a> (getmxrr broken).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72629">#72629</a> (Caught exception assignment to variables ignores references).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72594">#72594</a> (Calling an earlier instance of an included anonymous class fatals).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72581">#72581</a> (previous property undefined in Exception after deserialization).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72543">#72543</a> (Different references behavior comparing to PHP 5).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72347">#72347</a> (VERIFY_RETURN type casts visible in finally).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72216">#72216</a> (Return by reference with finally is not memory safe).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72215">#72215</a> (Wrong return value if var modified in finally).</li>
    <li>Fixed bug <a href="http://bugs.php.net/71818">#71818</a> (Memory leak when array altered in destructor).</li>
    <li>Fixed bug <a href="http://bugs.php.net/71539">#71539</a> (Memory error on $arr[$a] =&amp; $arr[$b] if RHS rehashes).</li>
    <li>Added new constant PHP_FD_SETSIZE.</li>
    <li>Added optind parameter to getopt().</li>
    <li>Added PHP to SAPI error severity mapping for logs.</li>
    <li>Fixed bug <a href="http://bugs.php.net/71911">#71911</a> (Unable to set --enable-debug on building extensions by phpize on Windows).</li>
    <li>Fixed bug <a href="http://bugs.php.net/29368">#29368</a> (The destructor is called when an exception is thrown from the constructor).</li>
    <li>Implemented RFC: RNG Fixes.</li>
    <li>Implemented email validation as per RFC 6531.</li>
    <li>Fixed bug <a href="http://bugs.php.net/72513">#72513</a> (Stack-based buffer overflow vulnerability in virtual_file_ex).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72573">#72573</a> (HTTP_PROXY is improperly trusted by some PHP libraries and applications).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72523">#72523</a> (dtrace issue with reflection (failed test)).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72508">#72508</a> (strange references after recursive function call and "switch" statement).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72441">#72441</a> (Segmentation fault: RFC list_keys).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72395">#72395</a> (list() regression).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72373">#72373</a> (TypeError after Generator function w/declared return type finishes).</li>
    <li>Fixed bug <a href="http://bugs.php.net/69489">#69489</a> (tempnam() should raise notice if falling back to temp dir).</li>
    <li>Fixed UTF-8 and long path support on Windows.</li>
    <li>Fixed bug <a href="http://bugs.php.net/53432">#53432</a> (Assignment via string index access on an empty string converts to array).</li>
    <li>Fixed bug <a href="http://bugs.php.net/62210">#62210</a> (Exceptions can leak temporary variables).</li>
    <li>Fixed bug <a href="http://bugs.php.net/62814">#62814</a> (It is possible to stiffen child class members visibility).</li>
    <li>Fixed bug <a href="http://bugs.php.net/69989">#69989</a> (Generators don't participate in cycle GC).</li>
    <li>Fixed bug <a href="http://bugs.php.net/70228">#70228</a> (Memleak if return in finally block).</li>
    <li>Fixed bug <a href="http://bugs.php.net/71266">#71266</a> (Missing separation of properties HT in foreach etc).</li>
    <li>Fixed bug <a href="http://bugs.php.net/71604">#71604</a> (Aborted Generators continue after nested finally).</li>
    <li>Fixed bug <a href="http://bugs.php.net/71572">#71572</a> (String offset assignment from an empty string inserts null byte).</li>
    <li>Fixed bug <a href="http://bugs.php.net/71897">#71897</a> (ASCII 0x7F Delete control character permitted in identifiers).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72188">#72188</a> (Nested try/finally blocks losing return value).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72213">#72213</a> (Finally leaks on nested exceptions).</li>
    <li>Fixed bug <a href="http://bugs.php.net/47517">#47517</a> (php-cgi.exe missing UAC manifest).</li>
    <li>Change statement and fcall extension handlers to accept frame.</li>
    <li>Number operators taking numeric strings now emit E_NOTICEs or E_WARNINGs when given malformed numeric strings.</li>
    <li>(int), intval() where $base is 10 or unspecified, settype(), decbin(), decoct(), dechex(), integer operators and other conversions now always respect scientific notation in numeric strings.</li>
    <li>Raise a compile-time warning on octal escape sequence overflow.</li>
  </ul></li>
<li>Apache2handler:
  <ul>
    <li>Enable per-module logging in Apache 2.4+.</li>
  </ul></li>
<li>BCmath:
  <ul>
    <li>Fix bug #73190 (memcpy negative parameter _bc_new_num_ex).</li>
  </ul></li>
<li>Bz2:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/72837">#72837</a> (integer overflow in bzdecompress caused heap corruption).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72613">#72613</a> (Inadequate error handling in bzread()).</li>
  </ul></li>
<li>Calendar:
  <ul>
    <li>Fix integer overflows (Joshua Rogers)</li>
    <li>Fixed bug <a href="http://bugs.php.net/67976">#67976</a> (cal_days_month() fails for final month of the French calendar).</li>
    <li>Fixed bug <a href="http://bugs.php.net/71894">#71894</a> (AddressSanitizer: global-buffer-overflow in zif_cal_from_jd).</li>
  </ul></li>
<li>CLI Server:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/73360">#73360</a> (Unable to work in root with unicode chars).</li>
    <li>Fixed bug <a href="http://bugs.php.net/71276">#71276</a> (Built-in webserver does not send Date header).</li>
  </ul></li>
<li>COM:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/73126">#73126</a> (Cannot pass parameter 1 by reference).</li>
    <li>Fixed bug <a href="http://bugs.php.net/69579">#69579</a> (Invalid free in extension trait).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72922">#72922</a> (COM called from PHP does not return out parameters).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72569">#72569</a> (DOTNET/COM array parameters broke in PHP7).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72498">#72498</a> (variant_date_from_timestamp null dereference).</li>
  </ul></li>
<li>Curl:
  <ul>
    <li>Implement support for handling HTTP/2 Server Push.</li>
    <li>Add curl_multi_errno(), curl_share_errno() and curl_share_strerror() functions.</li>
    <li>Fixed bug <a href="http://bugs.php.net/72674">#72674</a> (Heap overflow in curl_escape).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72541">#72541</a> (size_t overflow lead to heap corruption). (Stas).</li>
    <li>Fixed bug <a href="http://bugs.php.net/71709">#71709</a> (curl_setopt segfault with empty CURLOPT_HTTPHEADER).</li>
    <li>Fixed bug <a href="http://bugs.php.net/71929">#71929</a> (CURLINFO_CERTINFO data parsing error).</li>
  </ul></li>
<li>Date:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/69587">#69587</a> (DateInterval properties and isset).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73426">#73426</a> (createFromFormat with 'z' format char results in incorrect time).</li>
    <li>Fixed bug <a href="http://bugs.php.net/45554">#45554</a> (Inconsistent behavior of the u format char).</li>
    <li>Fixed bug <a href="http://bugs.php.net/48225">#48225</a> (DateTime parser doesn't set microseconds for "now").</li>
    <li>Fixed bug <a href="http://bugs.php.net/52514">#52514</a> (microseconds are missing in DateTime class).</li>
    <li>Fixed bug <a href="http://bugs.php.net/52519">#52519</a> (microseconds in DateInterval are missing).</li>
    <li>Fixed bug <a href="http://bugs.php.net/60089">#60089</a> (DateTime::createFromFormat() U after u nukes microtime).</li>
    <li>Fixed bug <a href="http://bugs.php.net/64887">#64887</a> (Allow DateTime modification with subsecond items).</li>
    <li>Fixed bug <a href="http://bugs.php.net/68506">#68506</a> (General DateTime improvments needed for microseconds to become useful).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73109">#73109</a> (timelib_meridian doesn't parse dots correctly).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73247">#73247</a> (DateTime constructor does not initialise microseconds property).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73147">#73147</a> (Use After Free in PHP7 unserialize()).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73189">#73189</a> (Memcpy negative size parameter php_resolve_path).</li>
    <li>Fixed bug <a href="http://bugs.php.net/66836">#66836</a> (DateTime::createFromFormat 'U' with pre 1970 dates fails parsing).</li>
    <li>Invalid serialization data for a DateTime or DatePeriod object will now throw an instance of Error from __wakeup() or __set_state() instead of resulting in a fatal error.</li>
    <li>Timezone initialization failure from serialized data will now throw an instance of Error from __wakeup() or __set_state() instead of resulting in a fatal error.</li>
    <li>Export date_get_interface_ce() for extension use.</li>
    <li>Fixed bug <a href="http://bugs.php.net/63740">#63740</a> (strtotime seems to use both sunday and monday as start of week).</li>
  </ul></li>
<li>Dba:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/70825">#70825</a> (Cannot fetch multiple values with group in ini file).</li>
    <li>Data modification functions (e.g.: dba_insert()) now throw an instance of Error instead of triggering a catchable fatal error if the key is does not contain exactly two elements.</li>
  </ul></li>
<li>DOM:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/73150">#73150</a> (missing NULL check in dom_document_save_html).</li>
    <li>Fixed bug <a href="http://bugs.php.net/66502">#66502</a> (DOM document dangling reference).</li>
    <li>Invalid schema or RelaxNG validation contexts will throw an instance of Error instead of resulting in a fatal error.</li>
    <li>Attempting to register a node class that does not extend the appropriate base class will now throw an instance of Error instead of resulting in a fatal error.</li>
    <li>Attempting to read an invalid or write to a readonly property will throw an instance of Error instead of resulting in a fatal error.</li>
  </ul></li>
<li>DTrace:
  <ul>
    <li>Disabled PHP call tracing by default (it makes significant overhead). This may be enabled again using envirionment variable USE_ZEND_DTRACE=1.</li>
  </ul></li>
<li>EXIF:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/72735">#72735</a> (Samsung picture thumb not read (zero size)).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72627">#72627</a> (Memory Leakage In exif_process_IFD_in_TIFF).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72603">#72603</a> (Out of bound read in exif_process_IFD_in_MAKERNOTE).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72618">#72618</a> (NULL Pointer Dereference in exif_process_user_comment).</li>
  </ul></li>
<li>Filter:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/72972">#72972</a> (Bad filter for the flags FILTER_FLAG_NO_RES_RANGE and FILTER_FLAG_NO_PRIV_RANGE).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73054">#73054</a> (default option ignored when object passed to int filter).</li>
    <li>Fixed bug <a href="http://bugs.php.net/71745">#71745</a> (FILTER_FLAG_NO_RES_RANGE does not cover whole 127.0.0.0/8 range).</li>
  </ul></li>
<li>FPM:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/72575">#72575</a> (using --allow-to-run-as-root should ignore missing user).</li>
  </ul></li>
<li>FTP:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/70195">#70195</a> (Cannot upload file using ftp_put to FTPES with require_ssl_reuse).</li>
    <li>Implemented FR <a href="http://bugs.php.net/55651">#55651</a> (Option to ignore the returned FTP PASV address).</li>
  </ul></li>
<li>GD:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/73213">#73213</a> (Integer overflow in imageline() with antialiasing).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73272">#73272</a> (imagescale() is not affected by, but affects imagesetinterpolation()).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73279">#73279</a> (Integer overflow in gdImageScaleBilinearPalette()).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73280">#73280</a> (Stack Buffer Overflow in GD dynamicGetbuf).</li>
    <li>Fixed bug <a href="http://bugs.php.net/50194">#50194</a> (imagettftext broken on transparent background w/o alphablending).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73003">#73003</a> (Integer Overflow in gdImageWebpCtx of gd_webp.c).</li>
    <li>Fixed bug <a href="http://bugs.php.net/53504">#53504</a> (imagettfbbox gives incorrect values for bounding box).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73157">#73157</a> (imagegd2() ignores 3rd param if 4 are given).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73155">#73155</a> (imagegd2() writes wrong chunk sizes on boundaries).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73159">#73159</a> (imagegd2(): unrecognized formats may result in corrupted files).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73161">#73161</a> (imagecreatefromgd2() may leak memory).</li>
    <li>Fixed bug <a href="http://bugs.php.net/67325">#67325</a> (imagetruecolortopalette: white is duplicated in palette).</li>
    <li>Fixed bug <a href="http://bugs.php.net/66005">#66005</a> (imagecopy does not support 1bit transparency on truecolor images).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72913">#72913</a> (imagecopy() loses single-color transparency on palette images).</li>
    <li>Fixed bug <a href="http://bugs.php.net/68716">#68716</a> (possible resource leaks in _php_image_convert()).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72709">#72709</a> (imagesetstyle() causes OOB read for empty $styles).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72697">#72697</a> (select_colors write out-of-bounds).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72730">#72730</a> (imagegammacorrect allows arbitrary write access).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72596">#72596</a> (imagetypes function won't advertise WEBP support).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72604">#72604</a> (imagearc() ignores thickness for full arcs).</li>
    <li>Fixed bug <a href="http://bugs.php.net/70315">#70315</a> (500 Server Error but page is fully rendered).</li>
    <li>Fixed bug <a href="http://bugs.php.net/43828">#43828</a> (broken transparency of imagearc for truecolor in blendingmode).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72512">#72512</a> (gdImageTrueColorToPaletteBody allows arbitrary write/read access).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72519">#72519</a> (imagegif/output out-of-bounds access).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72558">#72558</a> (Integer overflow error within _gdContributionsAlloc()).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72482">#72482</a> (Ilegal write/read access caused by gdImageAALine overflow).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72494">#72494</a> (imagecropauto out-of-bounds access).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72404">#72404</a> (imagecreatefromjpeg fails on selfie).</li>
    <li>Fixed bug <a href="http://bugs.php.net/43475">#43475</a> (Thick styled lines have scrambled patterns).</li>
    <li>Fixed bug <a href="http://bugs.php.net/53640">#53640</a> (XBM images require width to be multiple of 8).</li>
    <li>Fixed bug <a href="http://bugs.php.net/64641">#64641</a> (imagefilledpolygon doesn't draw horizontal line).</li>
  </ul></li>
<li>Hash:
  <ul>
    <li>Added SHA3 fixed mode algorithms (224, 256, 384, and 512 bit).</li>
    <li>Added SHA512/256 and SHA512/224 algorithms.</li>
  </ul></li>
<li>iconv:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/72320">#72320</a> (iconv_substr returns false for empty strings).</li>
  </ul></li>
<li>IMAP:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/73418">#73418</a> (Integer Overflow in "_php_imap_mail" leads to crash).</li>
    <li>An email address longer than 16385 bytes will throw an instance of Error instead of resulting in a fatal error.</li>
  </ul></li>
<li>Interbase:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/73512">#73512</a> (Fails to find firebird headers as don't use fb_config output).</li>
  </ul></li>
<li>Intl:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/73007">#73007</a> (add locale length check).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73218">#73218</a> (add mitigation for ICU int overflow).</li>
    <li>Fixed bug <a href="http://bugs.php.net/65732">#65732</a> (grapheme_*() is not Unicode compliant on CR LF sequence).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73007">#73007</a> (add locale length check).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72639">#72639</a> (Segfault when instantiating class that extends IntlCalendar and adds a property).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72658">#72658</a> (Locale::lookup() / locale_lookup() hangs if no match found).</li>
    <li>Partially fixed #72506 (idn_to_ascii for UTS #46 incorrect for long domain names).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72533">#72533</a> (locale_accept_from_http out-of-bounds access).</li>
    <li>Failure to call the parent constructor in a class extending Collator before invoking the parent methods will throw an instance of Error instead of resulting in a recoverable fatal error.</li>
    <li>Cloning a Transliterator object may will now throw an instance of Error instead of resulting in a fatal error if cloning the internal transliterator fails.</li>
    <li>Added IntlTimeZone::getWindowsID() and IntlTimeZone::getIDForWindowsID().</li>
    <li>Fixed bug <a href="http://bugs.php.net/69374">#69374</a> (IntlDateFormatter formatObject returns wrong utf8 value).</li>
    <li>Fixed bug <a href="http://bugs.php.net/69398">#69398</a> (IntlDateFormatter formatObject returns wrong value when time style is NONE).</li>
  </ul></li>
<li>JSON:
  <ul>
    <li>Introduced encoder struct instead of global which fixes bugs #66025 and #73254 related to pretty print indentation.</li>
    <li>Fixed bug <a href="http://bugs.php.net/73113">#73113</a> (Segfault with throwing JsonSerializable).</li>
    <li>Implemented earlier return when json_encode fails, fixes bugs #68992 (Stacking exceptions thrown by JsonSerializable) and #70275 (On recursion error, json_encode can eat up all system memory).</li>
    <li>Implemented FR <a href="http://bugs.php.net/46600">#46600</a> ("_empty_" key in objects).</li>
    <li>Exported JSON parser API including json_parser_method that can be used for implementing custom logic when parsing JSON.</li>
    <li>Escaped U+2028 and U+2029 when JSON_UNESCAPED_UNICODE is supplied as json_encode options and added JSON_UNESCAPED_LINE_TERMINATORS to restore the previous behaviour.</li>
  </ul></li>
<li>LDAP:
  <ul>
    <li>Providing an unknown modification type to ldap_batch_modify() will now throw an instance of Error instead of resulting in a fatal error.</li>
  </ul></li>
<li>Mbstring:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/73532">#73532</a> (Null pointer dereference in mb_eregi).</li>
    <li>Fixed bug <a href="http://bugs.php.net/66964">#66964</a> (mb_convert_variables() cannot detect recursion).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72992">#72992</a> (mbstring.internal_encoding doesn't inherit default_charset).</li>
    <li>Fixed bug <a href="http://bugs.php.net/66797">#66797</a> (mb_substr only takes 32-bit signed integer).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72711">#72711</a> (`mb_ereg` does not clear the `$regs` parameter on failure).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72691">#72691</a> (mb_ereg_search raises a warning if a match zero-width).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72693">#72693</a> (mb_ereg_search increments search position when a match zero-width).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72694">#72694</a> (mb_ereg_search_setpos does not accept a string's last position).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72710">#72710</a> (`mb_ereg` causes buffer overflow on regexp compile error).</li>
    <li>Deprecated mb_ereg_replace() eval option.</li>
    <li>Fixed bug <a href="http://bugs.php.net/69151">#69151</a> (mb_ereg should reject ill-formed byte sequence).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72405">#72405</a> (mb_ereg_replace - mbc_to_code (oniguruma) - oob read access).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72399">#72399</a> (Use-After-Free in MBString (search_re)).</li>
    <li>mb_ereg() and mb_eregi() will now throw an instance of ParseError if an invalid PHP expression is provided and the 'e' option is used.</li>
  </ul></li>
<li>Mcrypt:
  <ul>
    <li>Deprecated ext/mcrypt.</li>
    <li>Fixed bug <a href="http://bugs.php.net/72782">#72782</a> (Heap Overflow due to integer overflows).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72551">#72551</a>, bug #72552 (In correct casting from size_t to int lead to heap overflow in mdecrypt_generic).</li>
    <li>mcrypt_encrypt() and mcrypt_decrypt() will throw an instance of Error instead of resulting in a fatal error if mcrypt cannot be initialized.</li>
  </ul></li>
<li>Mysqli:
  <ul>
    <li>Attempting to read an invalid or write to a readonly property will throw an instance of Error instead of resulting in a fatal error.</li>
  </ul></li>
<li>Mysqlnd:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/64526">#64526</a> (Add missing mysqlnd.* parameters to php.ini-*).</li>
    <li>Fixed bug <a href="http://bugs.php.net/71863">#71863</a> (Segfault when EXPLAIN with "Unknown column" error when using MariaDB).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72701">#72701</a> (mysqli_get_host_info() wrong output).</li>
  </ul></li>
<li>OCI8:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/71148">#71148</a> (Bind reference overwritten on PHP 7).</li>
    <li>Fixed invalid handle error with Implicit Result Sets.</li>
    <li>Fixed bug <a href="http://bugs.php.net/72524">#72524</a> (Binding null values triggers ORA-24816 error).</li>
  </ul></li>
<li>ODBC:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/73448">#73448</a> (odbc_errormsg returns trash, always 513 bytes).</li>
  </ul></li>
<li>Opcache:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/73583">#73583</a> (Segfaults when conditionally declared class and function have the same name).</li>
    <li>Fixed bug <a href="http://bugs.php.net/69090">#69090</a> (check cached files permissions)</li>
    <li>Fixed bug <a href="http://bugs.php.net/72982">#72982</a> (Memory leak in zend_accel_blacklist_update_regexp() function).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72949">#72949</a> (Typo in opcache error message).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72762">#72762</a> (Infinite loop while parsing a file with opcache enabled).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72590">#72590</a> (Opcache restart with kill_all_lockers does not work).</li>
  </ul></li>
<li>OpenSSL:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/73478">#73478</a> (openssl_pkey_new() generates wrong pub/priv keys with Diffie Hellman).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73276">#73276</a> (crash in openssl_random_pseudo_bytes function).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73072">#73072</a> (Invalid path SNI_server_certs causes segfault).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72360">#72360</a> (ext/openssl build failure with OpenSSL 1.1.0).</li>
    <li>Bumped a minimal version to 1.0.1.</li>
    <li>Dropped support for SSL2.</li>
    <li>Implemented FR <a href="http://bugs.php.net/61204">#61204</a> (Add elliptic curve support for OpenSSL).</li>
    <li>Implemented FR <a href="http://bugs.php.net/67304">#67304</a> (Added AEAD support [CCM and GCM modes] to openssl_encrypt and openssl_decrypt).</li>
    <li>Implemented error storing to the global queue and cleaning up the OpenSSL error queue (resolves bugs #68276 and #69882).</li>
  </ul></li>
<li>Pcntl:
  <ul>
    <li>Implemented asynchronous signal handling without TICKS.</li>
    <li>Added pcntl_signal_get_handler() that returns the current signal handler for a particular signal. Addresses FR <a href="http://bugs.php.net/72409">#72409</a>.</li>
    <li>Add signinfo to pcntl_signal() handler args (Bishop Bettini, David Walker)</li>
  </ul></li>
<li>PCRE:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/73483">#73483</a> (Segmentation fault on pcre_replace_callback).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73612">#73612</a> (preg_*() may leak memory).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73392">#73392</a> (A use-after-free in zend allocator management).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73121">#73121</a> (Bundled PCRE doesn't compile because JIT isn't supported on s390).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72688">#72688</a> (preg_match missing group names in matches).</li>
    <li>Downgraded to PCRE 8.38.</li>
    <li>Fixed bug <a href="http://bugs.php.net/72476">#72476</a> (Memleak in jit_stack).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72463">#72463</a> (mail fails with invalid argument).</li>
    <li>Upgraded to PCRE 8.39.</li>
  </ul></li>
<li>PDO:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/72788">#72788</a> (Invalid memory access when using persistent PDO connection).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72791">#72791</a> (Memory leak in PDO persistent connection handling).</li>
    <li>Fixed bug <a href="http://bugs.php.net/60665">#60665</a> (call to empty() on NULL result using PDO::FETCH_LAZY returns false).</li>
  </ul></li>
<li>PDO_DBlib:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/72414">#72414</a> (Never quote values as raw binary data).</li>
    <li>Allow \PDO::setAttribute() to set query timeouts.</li>
    <li>Handle SQLDECIMAL/SQLNUMERIC types, which are used by later TDS versions.</li>
    <li>Add common PDO test suite.</li>
    <li>Free error and message strings when cleaning up PDO instances.</li>
    <li>Fixed bug <a href="http://bugs.php.net/67130">#67130</a> (\PDOStatement::nextRowset() should succeed when all rows in current rowset haven't been fetched).</li>
    <li>Ignore potentially misleading dberr values.</li>
    <li>Implemented stringify 'uniqueidentifier' fields.</li>
  </ul></li>
<li>PDO_Firebird:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/73087">#73087</a>, <a href="http://bugs.php.net/61183">#61183</a>, <a href="http://bugs.php.net/71494">#71494</a> (Memory corruption in bindParam).</li>
    <li>Fixed bug <a href="http://bugs.php.net/60052">#60052</a> (Integer returned as a 64bit integer on X86_64).</li>
  </ul></li>
<li>PDO_pgsql:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/70313">#70313</a> (PDO statement fails to throw exception).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72570">#72570</a> (Segmentation fault when binding parameters on a query without placeholders).</li>
    <li>Implemented FR <a href="http://bugs.php.net/72633">#72633</a> (Postgres PDO lastInsertId() should work without specifying a sequence).</li>
  </ul></li>
<li>Phar:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/72928">#72928</a> (Out of bound when verify signature of zip phar in phar_parse_zipfile).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73035">#73035</a> (Out of bound when verify signature of tar phar in phar_parse_tarfile).</li>
  </ul></li>
<li>phpdbg:
  <ul>
    <li>Added generator command for inspection of currently alive generators.</li>
  </ul></li>
<li>Postgres:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/73498">#73498</a> (Incorrect SQL generated for pg_copy_to()).</li>
    <li>Implemented FR <a href="http://bugs.php.net/31021">#31021</a> (pg_last_notice() is needed to get all notice messages).</li>
    <li>Implemented FR <a href="http://bugs.php.net/48532">#48532</a> (Allow pg_fetch_all() to index numerically).</li>
  </ul></li>
<li>Readline:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/72538">#72538</a> (readline_redisplay crashes php).</li>
  </ul></li>
<li>Reflection:
  <ul>
    <li>Undo backwards compatiblity break in ReflectionType-&gt;__toString() and deprecate via documentation instead.</li>
    <li>Reverted prepending \ for class names.</li>
    <li>Implemented request #38992 (invoke() and invokeArgs() static method calls should match). (cmb).</li>
    <li>Add ReflectionNamedType::getName(). This method should be used instead of ReflectionType::__toString()</li>
    <li>Prepend \ for class names and ? for nullable types returned from ReflectionType::__toString().</li>
    <li>Fixed bug <a href="http://bugs.php.net/72661">#72661</a> (ReflectionType::__toString crashes with iterable).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72222">#72222</a> (ReflectionClass::export doesn't handle array constants).</li>
    <li>Failure to retrieve a reflection object or retrieve an object property will now throw an instance of Error instead of resulting in a fatal error.</li>
    <li>Fix #72209 (ReflectionProperty::getValue() doesn't fail if object doesn't match type).</li>
  </ul></li>
<li>Session:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/73273">#73273</a> (session_unset() empties values from all variables in which is $_session stored).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73100">#73100</a> (session_destroy null dereference in ps_files_path_create).</li>
    <li>Fixed bug <a href="http://bugs.php.net/68015">#68015</a> (Session does not report invalid uid for files save handler).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72940">#72940</a> (SID always return "name=ID", even if session cookie exist).</li>
    <li>Implemented session_gc() (Yasuo) https://wiki.php.net/rfc/session-create-id</li>
    <li>Implemented session_create_id() (Yasuo) https://wiki.php.net/rfc/session-gc</li>
    <li>Implemented RFC: Session ID without hashing. (Yasuo) https://wiki.php.net/rfc/session-id-without-hashing</li>
    <li>Fixed bug <a href="http://bugs.php.net/72531">#72531</a> (ps_files_cleanup_dir Buffer overflow).</li>
    <li>Custom session handlers that do not return strings for session IDs will now throw an instance of Error instead of resulting in a fatal error when a function is called that must generate a session ID.</li>
    <li>An invalid setting for session.hash_function will throw an instance of Error instead of resulting in a fatal error when a session ID is created.</li>
    <li>Fixed bug <a href="http://bugs.php.net/72562">#72562</a> (Use After Free in unserialize() with Unexpected Session Deserialization).</li>
    <li>Improved fix for bug #68063 (Empty session IDs do still start sessions).</li>
    <li>Fixed bug <a href="http://bugs.php.net/71038">#71038</a> (session_start() returns TRUE on failure). Session save handlers must return 'string' always for successful read. i.e. Non-existing session read must return empty string. PHP 7.0 is made not to tolerate buggy return value.</li>
    <li>Fixed bug <a href="http://bugs.php.net/71394">#71394</a> (session_regenerate_id() must close opened session on errors).</li>
  </ul></li>
<li>SimpleXML:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/73293">#73293</a> (NULL pointer dereference in SimpleXMLElement::asXML()).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72971">#72971</a> (SimpleXML isset/unset do not respect namespace).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72957">#72957</a> (Null coalescing operator doesn't behave as expected with SimpleXMLElement).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72588">#72588</a> (Using global var doesn't work while accessing SimpleXML element).</li>
    <li>Creating an unnamed or duplicate attribute will throw an instance of Error instead of resulting in a fatal error.</li>
  </ul></li>
<li>SNMP:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/72708">#72708</a> (php_snmp_parse_oid integer overflow in memory allocation).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72479">#72479</a> (Use After Free Vulnerability in SNMP with GC and unserialize()).</li>
  </ul></li>
<li>Soap:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/73538">#73538</a> (SoapClient::__setSoapHeaders doesn't overwrite SOAP headers).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73452">#73452</a> (Segfault (Regression for #69152)).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73037">#73037</a> (SoapServer reports Bad Request when gzipped).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73237">#73237</a> (Nested object in "any" element overwrites other fields).</li>
    <li>Fixed bug <a href="http://bugs.php.net/69137">#69137</a> (Peer verification fails when using a proxy with SoapClient).</li>
    <li>Fixed bug <a href="http://bugs.php.net/71711">#71711</a> (Soap Server Member variables reference bug).</li>
    <li>Fixed bug <a href="http://bugs.php.net/71996">#71996</a> (Using references in arrays doesn't work like expected).</li>
  </ul></li>
<li>SPL:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/73423">#73423</a> (Reproducible crash with GDB backtrace).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72888">#72888</a> (Segfault on clone on splFileObject).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73029">#73029</a> (Missing type check when unserializing SplArray).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72646">#72646</a> (SplFileObject::getCsvControl does not return the escape character).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72684">#72684</a> (AppendIterator segfault with closed generator).</li>
    <li>Attempting to clone an SplDirectory object will throw an instance of Error instead of resulting in a fatal error.</li>
    <li>Calling ArrayIterator::append() when iterating over an object will throw an instance of Error instead of resulting in a fatal error.</li>
    <li>Fixed bug <a href="http://bugs.php.net/55701">#55701</a> (GlobIterator throws LogicException).</li>
  </ul></li>
<li>SQLite3:
  <ul>
    <li>Update to SQLite 3.15.1.</li>
    <li>Fixed bug <a href="http://bugs.php.net/73530">#73530</a> (Unsetting result set may reset other result set).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73333">#73333</a> (2147483647 is fetched as string).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72668">#72668</a> (Spurious warning when exception is thrown in user defined function).</li>
    <li>Implemented FR <a href="http://bugs.php.net/72653">#72653</a> (SQLite should allow opening with empty filename).</li>
    <li>Fixed bug <a href="http://bugs.php.net/70628">#70628</a> (Clearing bindings on an SQLite3 statement doesn't work).</li>
    <li>Implemented FR <a href="http://bugs.php.net/71159">#71159</a> (Upgraded bundled SQLite lib to 3.9.2).</li>
  </ul></li>
<li>Standard:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/73297">#73297</a> (HTTP stream wrapper should ignore HTTP 100 Continue).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73303">#73303</a> (Scope not inherited by eval in assert()).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73192">#73192</a> (parse_url return wrong hostname).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73203">#73203</a> (passing additional_parameters causes mail to fail).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73203">#73203</a> (passing additional_parameters causes mail to fail).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72920">#72920</a> (Accessing a private constant using constant() creates an exception AND warning).</li>
    <li>Fixed bug <a href="http://bugs.php.net/65550">#65550</a> (get_browser() incorrectly parses entries with "+" sign).</li>
    <li>Fixed bug <a href="http://bugs.php.net/71882">#71882</a> (Negative ftruncate() on php://memory exhausts memory).</li>
    <li>Fixed bug <a href="http://bugs.php.net/55451">#55451</a> (substr_compare NULL length interpreted as 0).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72278">#72278</a> (getimagesize returning FALSE on valid jpg).</li>
    <li>Fixed bug <a href="http://bugs.php.net/61967">#61967</a> (unset array item in array_walk_recursive cause inconsistent array).</li>
    <li>Fixed bug <a href="http://bugs.php.net/62607">#62607</a> (array_walk_recursive move internal pointer).</li>
    <li>Fixed bug <a href="http://bugs.php.net/69068">#69068</a> (Exchanging array during array_walk -&gt; memory errors).</li>
    <li>Fixed bug <a href="http://bugs.php.net/70713">#70713</a> (Use After Free Vulnerability in array_walk()/ array_walk_recursive()).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72622">#72622</a> (array_walk + array_replace_recursive create references from nothing).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72330">#72330</a> (CSV fields incorrectly split if escape char followed by UTF chars).</li>
    <li>Implemented RFC: More precise float values.</li>
    <li>array_multisort now uses zend_sort instead zend_qsort.</li>
    <li>Fixed bug <a href="http://bugs.php.net/72505">#72505</a> (readfile() mangles files larger than 2G).</li>
    <li>assert() will throw a ParseError when evaluating a string given as the first argument if the PHP code is invalid instead of resulting in a catchable fatal error.</li>
    <li>Calling forward_static_call() outside of a class scope will now throw an instance of Error instead of resulting in a fatal error.</li>
    <li>Added is_iterable() function.</li>
    <li>Fixed bug <a href="http://bugs.php.net/72306">#72306</a> (Heap overflow through proc_open and $env parameter).</li>
    <li>Fixed bug <a href="http://bugs.php.net/71100">#71100</a> (long2ip() doesn't accept integers in strict mode).</li>
    <li>Implemented FR <a href="http://bugs.php.net/55716">#55716</a> (Add an option to pass a custom stream context to get_headers()).</li>
    <li>Additional validation for parse_url() for login/pass components).</li>
    <li>Implemented FR <a href="http://bugs.php.net/69359">#69359</a> (Provide a way to fetch the current environment variables).</li>
    <li>unpack() function accepts an additional optional argument $offset.</li>
    <li>Implemented #51879 stream context socket option tcp_nodelay (Joe)</li>
  </ul></li>
<li>Streams:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/73586">#73586</a> (php_user_filter::$stream is not set to the stream the filter is working on).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72853">#72853</a> (stream_set_blocking doesn't work).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72743">#72743</a> (Out-of-bound read in php_stream_filter_create).</li>
    <li>Implemented FR <a href="http://bugs.php.net/27814">#27814</a> (Multiple small packets send for HTTP request).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72764">#72764</a> (ftps:// opendir wrapper data channel encryption fails with IIS FTP 7.5, 8.5).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72810">#72810</a> (Missing SKIP_ONLINE_TESTS checks).</li>
    <li>Fixed bug <a href="http://bugs.php.net/41021">#41021</a> (Problems with the ftps wrapper).</li>
    <li>Fixed bug <a href="http://bugs.php.net/54431">#54431</a> (opendir() does not work with ftps:// wrapper).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72667">#72667</a> (opendir() with ftp:// attempts to open data stream for non-existent directories).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72771">#72771</a> (ftps:// wrapper is vulnerable to protocol downgrade attack).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72534">#72534</a> (stream_socket_get_name crashes).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72439">#72439</a> (Stream socket with remote address leads to a segmentation fault).</li>
  </ul></li>
<li>sysvshm:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/72858">#72858</a> (shm_attach null dereference).</li>
  </ul></li>
<li>Tidy:
  <ul>
    <li>Implemented support for libtidy 5.0.0 and above.</li>
    <li>Creating a tidyNode manually will now throw an instance of Error instead of resulting in a fatal error.</li>
  </ul></li>
<li>Wddx:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/73331">#73331</a> (NULL Pointer Dereference in WDDX Packet Deserialization with PDORow). (CVE-2016-9934)</li>
    <li>Fixed bug <a href="http://bugs.php.net/72142">#72142</a> (WDDX Packet Injection Vulnerability in wddx_serialize_value()).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72749">#72749</a> (wddx_deserialize allows illegal memory access).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72750">#72750</a> (wddx_deserialize null dereference).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72790">#72790</a> (wddx_deserialize null dereference with invalid xml).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72799">#72799</a> (wddx_deserialize null dereference in php_wddx_pop_element).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72860">#72860</a> (wddx_deserialize use-after-free).</li>
    <li>Fixed bug <a href="http://bugs.php.net/73065">#73065</a> (Out-Of-Bounds Read in php_wddx_push_element).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72564">#72564</a> (boolean always deserialized as "true").</li>
    <li>A circular reference when serializing will now throw an instance of Error instead of resulting in a fatal error.</li>
  </ul></li>
<li>XML:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/72135">#72135</a> (malformed XML causes fault).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72714">#72714</a> (_xml_startElementHandler() segmentation fault).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72085">#72085</a> (SEGV on unknown address zif_xml_parse).</li>
  </ul></li>
<li>XMLRPC:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/72647">#72647</a> (xmlrpc_encode() unexpected output after referencing array elements).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72606">#72606</a> (heap-buffer-overflow (write) simplestring_addn simplestring.c).</li>
    <li>A circular reference when serializing will now throw an instance of Error instead of resulting in a fatal error.</li>
  </ul></li>
<li>Zip:
  <ul>
    <li>Fixed bug <a href="http://bugs.php.net/68302">#68302</a> (impossible to compile php with zip support).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72660">#72660</a> (NULL Pointer dereference in zend_virtual_cwd).</li>
    <li>Fixed bug <a href="http://bugs.php.net/72520">#72520</a> (Stack-based buffer overflow vulnerability in php_stream_zip_opener).</li>
    <li>ZipArchive::addGlob() will throw an instance of Error instead of resulting in a fatal error if glob support is not available.</li>
  </ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.0.13"><!-- {{{ 7.0.13 -->
<h3>Version 7.0.13</h3>
<b><time class='releasedate' datetime='2016-11-10'>10 Nov 2016</time></b>
<ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73350">#73350</a> (Exception::__toString() cause circular references).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73181">#73181</a> (parse_str() without a second argument leads to crash).</li>
  <li>Fixed bug <a href="http://bugs.php.net/66773">#66773</a> (Autoload with Opcache allows importing conflicting class name to namespace).</li>
  <li>Fixed bug <a href="http://bugs.php.net/66862">#66862</a> ((Sub-)Namespaces unexpected behaviour).</li>
  <li>Fix pthreads detection when cross-compiling.</li>
  <li>Fixed bug <a href="http://bugs.php.net/73337">#73337</a> (try/catch not working with two exceptions inside a same operation).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73338">#73338</a> (Exception thrown from error handler causes valgrind warnings (and crashes)).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73329">#73329</a> ((Float)"Nano" == NAN).</li>
</ul></li>
<li>GD:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73213">#73213</a> (Integer overflow in imageline() with antialiasing).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73272">#73272</a> (imagescale() is not affected by, but affects imagesetinterpolation()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73279">#73279</a> (Integer overflow in gdImageScaleBilinearPalette()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73280">#73280</a> (Stack Buffer Overflow in GD dynamicGetbuf).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72482">#72482</a> (Ilegal write/read access caused by gdImageAALine overflow).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72696">#72696</a> (imagefilltoborder stackoverflow on truecolor images). (CVE-2016-9933)</li>
</ul></li>
<li>IMAP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73418">#73418</a> (Integer Overflow in "_php_imap_mail" leads to crash).</li>
</ul></li>
<li>OCI8:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71148">#71148</a> (Bind reference overwritten on PHP 7).</li>
</ul></li>
<li>phpdbg:
<ul>
  <li>Properly allow for stdin input from a file.</li>
  <li>Add -s command line option / stdin command for reading script from stdin.</li>
  <li>Ignore non-executable opcodes in line mode of phpdbg_end_oplog().</li>
  <li>Fixed bug <a href="http://bugs.php.net/70776">#70776</a> (Simple SIGINT does not have any effect with -rr).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71234">#71234</a> (INI files are loaded even invoked as -n --version).</li>
</ul></li>
<li>Session:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73273">#73273</a> (session_unset() empties values from all variables in which is $_session stored).</li>
</ul></li>
<li>SOAP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73037">#73037</a> (SoapServer reports Bad Request when gzipped).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73237">#73237</a> (Nested object in "any" element overwrites other fields).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69137">#69137</a> (Peer verification fails when using a proxy with SoapClient)</li>
</ul></li>
<li>SQLite3:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73333">#73333</a> (2147483647 is fetched as string).</li>
</ul></li>
<li>Standard:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73203">#73203</a> (passing additional_parameters causes mail to fail).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71241">#71241</a> (array_replace_recursive sometimes mutates its parameters).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73192">#73192</a> (parse_url return wrong hostname).</li>
</ul></li>
<li>Wddx:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73331">#73331</a> (NULL Pointer Dereference in WDDX Packet Deserialization with PDORow). (CVE-2016-9934)</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.0.12"><!-- {{{ 7.0.12 -->
<h3>Version 7.0.12</h3>
<time class='releasedate' datetime='2016-10-13'>13 Oct 2016</time><ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73025">#73025</a> (Heap Buffer Overflow in virtual_popen of zend_virtual_cwd.c).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72703">#72703</a> (Out of bounds global memory read in BF_crypt triggered by password_verify).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73058">#73058</a> (crypt broken when salt is 'too' long).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69579">#69579</a> (Invalid free in extension trait).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73156">#73156</a> (segfault on undefined function).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73163">#73163</a> (PHP hangs if error handler throws while accessing undef const in default value).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73172">#73172</a> (parse error: Invalid numeric literal).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73240">#73240</a> (Write out of bounds at number_format).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73147">#73147</a> (Use After Free in PHP7 unserialize()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73189">#73189</a> (Memcpy negative size parameter php_resolve_path).</li>
</ul></li>
<li>BCmath:
<ul>
<li>Fixed bug <a href="http://bugs.php.net/73190">#73190</a> (memcpy negative parameter _bc_new_num_ex).</li>
</ul></li>
<li>COM:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73126">#73126</a> (Cannot pass parameter 1 by reference).</li>
</ul></li>
<li>Date:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73091">#73091</a> (Unserializing DateInterval object may lead to __toString invocation).</li>
</ul></li>
<li>DOM:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73150">#73150</a> (missing NULL check in dom_document_save_html).</li>
</ul></li>
<li>Filter:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72972">#72972</a> (Bad filter for the flags FILTER_FLAG_NO_RES_RANGE and FILTER_FLAG_NO_PRIV_RANGE).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73054">#73054</a> (default option ignored when object passed to int filter).</li>
</ul></li>
<li>GD:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/67325">#67325</a> (imagetruecolortopalette: white is duplicated in palette).</li>
  <li>Fixed bug <a href="http://bugs.php.net/50194">#50194</a> (imagettftext broken on transparent background w/o alphablending).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73003">#73003</a> (Integer Overflow in gdImageWebpCtx of gd_webp.c).</li>
  <li>Fixed bug <a href="http://bugs.php.net/53504">#53504</a> (imagettfbbox gives incorrect values for bounding box).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73157">#73157</a> (imagegd2() ignores 3rd param if 4 are given).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73155">#73155</a> (imagegd2() writes wrong chunk sizes on boundaries).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73159">#73159</a> (imagegd2(): unrecognized formats may result in corrupted files).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73161">#73161</a> (imagecreatefromgd2() may leak memory).</li>
</ul></li>
<li>Intl:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73218">#73218</a> (add mitigation for ICU int overflow).</li>
</ul></li>
<li>Mbstring:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/66797">#66797</a> (mb_substr only takes 32-bit signed integer).</li>
  <li>Fixed bug <a href="http://bugs.php.net/66964">#66964</a> (mb_convert_variables() cannot detect recursion).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72992">#72992</a> (mbstring.internal_encoding doesn't inherit default_charset).</li>
</ul></li>
<li>Mysqlnd:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72489">#72489</a> (PHP Crashes When Modifying Array Containing MySQLi Result Data).</li>
</ul></li>
<li>Opcache:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72982">#72982</a> (Memory leak in zend_accel_blacklist_update_regexp() function).</li>
</ul></li>
<li>OpenSSL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73072">#73072</a> (Invalid path SNI_server_certs causes segfault).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73276">#73276</a> (crash in openssl_random_pseudo_bytes function).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73275">#73275</a> (crash in openssl_encrypt function).</li>
</ul></li>
<li>PCRE:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73121">#73121</a> (Bundled PCRE doesn't compile because JIT isn't supported on s390).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73174">#73174</a> (heap overflow in php_pcre_replace_impl).</li>
</ul></li>
<li>PDO_DBlib:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72414">#72414</a> (Never quote values as raw binary data).</li>
  <li>Allow \PDO::setAttribute() to set query timeouts.</li>
  <li>Handle SQLDECIMAL/SQLNUMERIC types, which are used by later TDS versions.</li>
  <li>Add common PDO test suite.</li>
  <li>Free error and message strings when cleaning up PDO instances.</li>
  <li>Fixed bug <a href="http://bugs.php.net/67130">#67130</a> (\PDOStatement::nextRowset() should succeed when all rows in current rowset haven't been fetched).</li>
  <li>Ignore potentially misleading dberr values.</li>
</ul></li>
<li>phpdbg:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72996">#72996</a> (phpdbg_prompt.c undefined reference to DL_LOAD).</li>
  <li>Fixed next command not stopping when leaving function.</li>
</ul></li>
<li>Session:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/68015">#68015</a> (Session does not report invalid uid for files save handler).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73100">#73100</a> (session_destroy null dereference in ps_files_path_create).</li>
</ul></li>
<li>SimpleXML:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73293">#73293</a> (NULL pointer dereference in SimpleXMLElement::asXML()).</li>
</ul></li>
<li>SOAP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71711">#71711</a> (Soap Server Member variables reference bug).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71996">#71996</a> (Using references in arrays doesn't work like expected).</li>
</ul></li>
<li>SPL:
<ul>
<li>Fixed bug <a href="http://bugs.php.net/73257">#73257</a>, Fixed bug <a href="http://bugs.php.net/73258">#73258</a> (SplObjectStorage unserialize allows use of non-object as key).</li>
</ul></li>
<li>SQLite3:
<ul>
  <li>Updated bundled SQLite3 to 3.14.2.</li>
</ul></li>
<li>Zip:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70752">#70752</a> (Depacking with wrong password leaves 0 length files).</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.0.11"><!-- {{{ 7.0.11 -->
<h3>Version 7.0.11</h3>
<time class='releasedate' datetime='2016-09-15'>15 Sep 2016</time><ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72944">#72944</a> (Null pointer deref in zval_delref_p).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72943">#72943</a> (assign_dim on string doesn't reset hval).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72911">#72911</a> (Memleak in zend_binary_assign_op_obj_helper).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72813">#72813</a> (Segfault with __get returned by ref).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72767">#72767</a> (PHP Segfaults when trying to expand an infinite operator).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72854">#72854</a> (PHP Crashes on duplicate destructor call).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72857">#72857</a> (stream_socket_recvfrom read access violation).</li>
</ul></li>
<li>COM:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72922">#72922</a> (COM called from PHP does not return out parameters).</li>
</ul></li>
<li>Dba:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70825">#70825</a> (Cannot fetch multiple values with group in ini file).</li>
</ul></li>
<li>FTP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70195">#70195</a> (Cannot upload file using ftp_put to FTPES with require_ssl_reuse).</li>
</ul></li>
<li>GD:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72709">#72709</a> (imagesetstyle() causes OOB read for empty $styles).</li>
  <li>Fixed bug <a href="http://bugs.php.net/66005">#66005</a> (imagecopy does not support 1bit transparency on truecolor images).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72913">#72913</a> (imagecopy() loses single-color transparency on palette images).</li>
  <li>Fixed bug <a href="http://bugs.php.net/68716">#68716</a> (possible resource leaks in _php_image_convert()).</li>
</ul></li>
<li>iconv:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72320">#72320</a> (iconv_substr returns false for empty strings).</li>
</ul></li>
<li>IMAP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72852">#72852</a> (imap_mail null dereference).</li>
</ul></li>
<li>Intl:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/65732">#65732</a> (grapheme_*() is not Unicode compliant on CR LF sequence).</li>
  <li>Fixed bug <a href="http://bugs.php.net/73007">#73007</a> (add locale length check). (CVE-2016-7416)</li>
</ul></li>
<li>Mysqlnd:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72293">#72293</a> (Heap overflow in mysqlnd related to BIT fields). (CVE-2016-7412)</li>
</ul></li>
<li>OCI8:
<ul>
  <li>Fixed invalid handle error with Implicit Result Sets.</li>
  <li>Fixed bug <a href="http://bugs.php.net/72524">#72524</a> (Binding null values triggers ORA-24816 error).</li>
</ul></li>
<li>Opcache:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72949">#72949</a> (Typo in opcache error message).</li>
</ul></li>
<li>PDO:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72788">#72788</a> (Invalid memory access when using persistent PDO connection).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72791">#72791</a> (Memory leak in PDO persistent connection handling).</li>
  <li>Fixed bug <a href="http://bugs.php.net/60665">#60665</a> (call to empty() on NULL result using PDO::FETCH_LAZY returns false).</li>
</ul></li>
<li>PDO_DBlib:
<ul>
  <li>Implemented stringify 'uniqueidentifier' fields.</li>
</ul></li>
<li>PDO_pgsql:
<ul>
  <li>Implemented FR <a href="http://bugs.php.net/72633">#72633</a> (Postgres PDO lastInsertId() should work without specifying a sequence).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72759">#72759</a> (Regression in pgo_pgsql).</li>
</ul></li>
<li>Phar:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72928">#72928</a> (Out of bound when verify signature of zip phar in phar_parse_zipfile). (CVE-2016-7414)</li>
  <li>Fixed bug <a href="http://bugs.php.net/73035">#73035</a> (Out of bound when verify signature of tar phar in phar_parse_tarfile).</li>
</ul></li>
<li>Reflection:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72846">#72846</a> (getConstant for a array constant with constant values returns NULL/NFC/UKNOWN).</li>
</ul></li>
<li>Session:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72724">#72724</a> (PHP7: session-uploadprogress kills httpd).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72940">#72940</a> (SID always return "name=ID", even if session cookie exist).</li>
</ul></li>
<li>SimpleXML:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72971">#72971</a> (SimpleXML isset/unset do not respect namespace).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72957">#72957</a> (Null coalescing operator doesn't behave as expected with SimpleXMLElement).</li>
</ul></li>
<li>SPL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/73029">#73029</a> (Missing type check when unserializing SplArray). (CVE-2016-7417)</li>
</ul></li>
<li>Standard:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/55451">#55451</a> (substr_compare NULL length interpreted as 0).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72278">#72278</a> (getimagesize returning FALSE on valid jpg).</li>
  <li>Fixed bug <a href="http://bugs.php.net/65550">#65550</a> (get_browser() incorrectly parses entries with "+" sign).</li>
</ul></li>
<li>Streams:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72853">#72853</a> (stream_set_blocking doesn't work).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72764">#72764</a> (ftps:// opendir wrapper data channel encryption fails with IIS FTP 7.5, 8.5).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71882">#71882</a> (Negative ftruncate() on php://memory exhausts memory).</li>
</ul></li>
<li>SQLite3:
<ul>
<li>Downgraded bundled SQLite to 3.8.10.2, see <a href="http://bugs.php.net/73068">#73068</a></li>
</ul></li>
<li>Sysvshm:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72858">#72858</a> (shm_attach null dereference).</li>
</ul></li>
<li>Wddx:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72860">#72860</a> (wddx_deserialize use-after-free). (CVE-2016-7413)</li>
  <li>Fixed bug <a href="http://bugs.php.net/73065">#73065</a> (Out-Of-Bounds Read in php_wddx_push_element). (CVE-2016-7418)</li>
</ul></li>
<li>XML:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72085">#72085</a> (SEGV on unknown address zif_xml_parse).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72714">#72714</a> (_xml_startElementHandler() segmentation fault).</li>
</ul></li>
<li>ZIP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/68302">#68302</a> (impossible to compile php with zip support).</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.0.10"><!-- {{{ 7.0.10 -->
<h3>Version 7.0.10</h3>
<time class='releasedate' datetime='2016-08-18'>18 Aug 2016</time><ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72629">#72629</a> (Caught exception assignment to variables ignores references).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72594">#72594</a> (Calling an earlier instance of an included anonymous class fatals).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72581">#72581</a> (previous property undefined in Exception after deserialization).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72496">#72496</a> (Cannot declare public method with signature incompatible with parent private method).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72024">#72024</a> (microtime() leaks memory).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71911">#71911</a> (Unable to set --enable-debug on building extensions by phpize on Windows).</li>
  <li>Fixed bug causing ClosedGeneratorException being thrown into the calling code instead of the Generator yielding from.</li>
  <li>Implemented FR <a href="http://bugs.php.net/72614">#72614</a> (Support "nmake test" on building extensions by phpize).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72641">#72641</a> (phpize (on Windows) ignores PHP_PREFIX).</li>
  <li>Fixed potential segfault in object storage freeing in shutdown sequence.</li>
  <li>Fixed bug <a href="http://bugs.php.net/72663">#72663</a> (Create an Unexpected Object and Don't Invoke __wakeup() in Deserialization). (CVE-2016-7124)</li>
  <li>Fixed bug <a href="http://bugs.php.net/72681">#72681</a> (PHP Session Data Injection Vulnerability). (CVE-2016-7125)</li>
  <li>Fixed bug <a href="http://bugs.php.net/72683">#72683</a> (getmxrr broken).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72742">#72742</a> (memory allocator fails to realloc small block to large one). (CVE-2016-7133)</li>
</ul></li>
<li>Bz2:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72837">#72837</a> (integer overflow in bzdecompress caused heap corruption).</li>
</ul></li>
<li>Calendar:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/67976">#67976</a> (cal_days_month() fails for final month of the French calendar).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71894">#71894</a> (AddressSanitizer: global-buffer-overflow in zif_cal_from_jd).</li>
</ul></li>
<li>COM:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72569">#72569</a> (DOTNET/COM array parameters broke in PHP7).</li>
</ul></li>
<li>CURL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71709">#71709</a> (curl_setopt segfault with empty CURLOPT_HTTPHEADER).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71929">#71929</a> (CURLINFO_CERTINFO data parsing error).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72674">#72674</a> (Heap overflow in curl_escape). (CVE-2016-7134)</li>
</ul></li>
<li>DOM:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/66502">#66502</a> (DOM document dangling reference).</li>
</ul></li>
<li>EXIF:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72735">#72735</a> (Samsung picture thumb not read (zero size)).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72627">#72627</a> (Memory Leakage In exif_process_IFD_in_TIFF). (CVE-2016-7128)</li>
</ul></li>
<li>Filter:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71745">#71745</a> (FILTER_FLAG_NO_RES_RANGE does not cover whole 127.0.0.0/8 range).</li>
</ul></li>
<li>FPM:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72575">#72575</a> (using --allow-to-run-as-root should ignore missing user).</li>
</ul></li>
<li>GD:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72596">#72596</a> (imagetypes function won't advertise WEBP support).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72604">#72604</a> (imagearc() ignores thickness for full arcs).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70315">#70315</a> (500 Server Error but page is fully rendered).</li>
  <li>Fixed bug <a href="http://bugs.php.net/43828">#43828</a> (broken transparency of imagearc for truecolor in blendingmode).</li>
  <li>Fixed bug <a href="http://bugs.php.net/66555">#66555</a> (Always false condition in ext/gd/libgd/gdkanji.c).</li>
  <li>Fixed bug <a href="http://bugs.php.net/68712">#68712</a> (suspicious if-else statements).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72697">#72697</a> (select_colors write out-of-bounds). (CVE-2016-7126)</li>
  <li>Fixed bug <a href="http://bugs.php.net/72730">#72730</a> (imagegammacorrect allows arbitrary write access). (CVE-2016-7127)</li>
  <li>Fixed bug <a href="http://bugs.php.net/72494">#72494</a> (imagecropauto out-of-bounds access)</li>
</ul></li>
<li>Intl:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72639">#72639</a> (Segfault when instantiating class that extends IntlCalendar and adds a property).</li>
  <li>Partially fixed Fixed bug <a href="http://bugs.php.net/72506">#72506</a> (idn_to_ascii for UTS #46 incorrect for long domain names).</li>
</ul></li>
<li>mbstring:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72691">#72691</a> (mb_ereg_search raises a warning if a match zero-width).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72693">#72693</a> (mb_ereg_search increments search position when a match zero-width).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72694">#72694</a> (mb_ereg_search_setpos does not accept a string's last position).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72710">#72710</a> (`mb_ereg` causes buffer overflow on regexp compile error).</li>
</ul></li>
<li>Mcrypt:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72782">#72782</a> (Heap Overflow due to integer overflows).</li>
</ul></li>
<li>Opcache:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72590">#72590</a> (Opcache restart with kill_all_lockers does not work).</li>
</ul></li>
<li>PCRE:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72688">#72688</a> (preg_match missing group names in matches).</li>
</ul></li>
<li>PDO_pgsql:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70313">#70313</a> (PDO statement fails to throw exception).</li>
</ul></li>
<li>Reflection:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72222">#72222</a> (ReflectionClass::export doesn't handle array constants).</li>
</ul></li>
<li>SimpleXML:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72588">#72588</a> (Using global var doesn't work while accessing SimpleXML element).</li>
</ul></li>
<li>SNMP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72708">#72708</a> (php_snmp_parse_oid integer overflow in memory allocation).</li>
</ul></li>
<li>SPL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/55701">#55701</a> (GlobIterator throws LogicException).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72646">#72646</a> (SplFileObject::getCsvControl does not return the escape character).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72684">#72684</a> (AppendIterator segfault with closed generator).</li>
</ul></li>
<li>SQLite3:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72668">#72668</a> (Spurious warning when exception is thrown in user defined function).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72571">#72571</a> (SQLite3::bindValue, SQLite3::bindParam crash).</li>
  <li>Implemented FR <a href="http://bugs.php.net/72653">#72653</a> (SQLite should allow opening with empty filename).</li>
  <li>Updated to SQLite3 3.13.0.</li>
</ul></li>
<li>Standard:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72622">#72622</a> (array_walk + array_replace_recursive create references from nothing).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72152">#72152</a> (base64_decode $strict fails to detect null byte).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72263">#72263</a> (base64_decode skips a character after padding in strict mode).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72264">#72264</a> (base64_decode $strict fails with whitespace between padding).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72330">#72330</a> (CSV fields incorrectly split if escape char followed by UTF chars).</li>
</ul></li>
<li>Streams:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/41021">#41021</a> (Problems with the ftps wrapper).</li>
  <li>Fixed bug <a href="http://bugs.php.net/54431">#54431</a> (opendir() does not work with ftps:// wrapper).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72667">#72667</a> (opendir() with ftp:// attempts to open data stream for non-existent directories).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72771">#72771</a> (ftps:// wrapper is vulnerable to protocol downgrade attack).</li>
</ul></li>
<li>XMLRPC:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72647">#72647</a> (xmlrpc_encode() unexpected output after referencing array elements).</li>
</ul></li>
<li>Wddx:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72564">#72564</a> (boolean always deserialized as "true").</li>
  <li>Fixed bug <a href="http://bugs.php.net/72142">#72142</a> (WDDX Packet Injection Vulnerability in wddx_serialize_value()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72749">#72749</a> (wddx_deserialize allows illegal memory access). (CVE-2016-7129)</li>
  <li>Fixed bug <a href="http://bugs.php.net/72750">#72750</a> (wddx_deserialize null dereference). (CVE-2016-7130)</li>
  <li>Fixed bug <a href="http://bugs.php.net/72790">#72790</a> (wddx_deserialize null dereference with invalid xml). (CVE-2016-7131)</li>
  <li>Fixed bug <a href="http://bugs.php.net/72799">#72799</a> (wddx_deserialize null dereference in php_wddx_pop_element). (CVE-2016-7132)</li>
</ul></li>
<li>Zip:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72660">#72660</a> (NULL Pointer dereference in zend_virtual_cwd).</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.0.9"><!-- {{{ 7.0.9 -->
<h3>Version 7.0.9</h3>
<time class='releasedate' datetime='2016-07-21'>21 Jul 2016</time><ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72508">#72508</a> (strange references after recursive function call and "switch" statement).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72513">#72513</a> (Stack-based buffer overflow vulnerability in virtual_file_ex). (CVE-2016-6289)</li>
  <li>Fixed bug <a href="http://bugs.php.net/72573">#72573</a> (HTTP_PROXY is improperly trusted by some PHP libraries and applications). (CVE-2016-5385)</li>
</ul></li>
<li>bz2:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72613">#72613</a> (Inadequate error handling in bzread()). (CVE-2016-5399)</li>
</ul></li>
<li>CLI:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72484">#72484</a> (SCRIPT_FILENAME shows wrong path if the user specify router.php).</li>
</ul></li>
<li>COM:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72498">#72498</a> (variant_date_from_timestamp null dereference).</li>
</ul></li>
<li>Curl:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72541">#72541</a> (size_t overflow lead to heap corruption).</li>
</ul></li>
<li>Date:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/66836">#66836</a> (DateTime::createFromFormat 'U' with pre 1970 dates fails parsing).</li>
</ul></li>
<li>Exif:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72603">#72603</a> (Out of bound read in exif_process_IFD_in_MAKERNOTE). (CVE-2016-6291)</li>
  <li>Fixed bug <a href="http://bugs.php.net/72618">#72618</a> (NULL Pointer Dereference in exif_process_user_comment). (CVE-2016-6292)</li>
</ul></li>
<li>GD:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/43475">#43475</a> (Thick styled lines have scrambled patterns).</li>
  <li>Fixed bug <a href="http://bugs.php.net/53640">#53640</a> (XBM images require width to be multiple of 8).</li>
  <li>Fixed bug <a href="http://bugs.php.net/64641">#64641</a> (imagefilledpolygon doesn't draw horizontal line).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72512">#72512</a> (gdImageTrueColorToPaletteBody allows arbitrary write/read access).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72519">#72519</a> (imagegif/output out-of-bounds access).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72558">#72558</a> (Integer overflow error within _gdContributionsAlloc()). (CVE-2016-6207)</li>
  <li>Fixed bug <a href="http://bugs.php.net/72482">#72482</a> (Ilegal write/read access caused by gdImageAALine overflow).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72494">#72494</a> (imagecropauto out-of-bounds access).</li>
</ul></li>
<li>Intl:
<ul>

  <li>Fixed bug <a href="http://bugs.php.net/72533">#72533</a> (locale_accept_from_http out-of-bounds access). (CVE-2016-6294)</li>
</ul></li>
<li>Mbstring:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72405">#72405</a> (mb_ereg_replace - mbc_to_code (oniguruma) - oob read access).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72399">#72399</a> (Use-After-Free in MBString (search_re)).</li>
</ul></li>
<li>mcrypt:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72551">#72551</a>, bug <a href="http://bugs.php.net/72552">#72552</a> (Incorrect casting from size_t to int lead to heap overflow in mdecrypt_generic).</li>
</ul></li>
<li>PDO_pgsql:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72570">#72570</a> (Segmentation fault when binding parameters on a query without placeholders).</li>
</ul></li>
<li>PCRE:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72476">#72476</a> (Memleak in jit_stack).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72463">#72463</a> (mail fails with invalid argument).</li>
</ul></li>
<li>Readline:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72538">#72538</a> (readline_redisplay crashes php).</li>
</ul></li>
<li>Standard:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72505">#72505</a> (readfile() mangles files larger than 2G).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72306">#72306</a> (Heap overflow through proc_open and $env parameter).</li>
</ul></li>
<li>Session:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72531">#72531</a> (ps_files_cleanup_dir Buffer overflow).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72562">#72562</a> (Use After Free in unserialize() with Unexpected Session Deserialization).</li>
</ul></li>
<li>SNMP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72479">#72479</a> (Use After Free Vulnerability in SNMP with GC and unserialize()). (CVE-2016-6295)</li>
</ul></li>
<li>Streams:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72439">#72439</a> (Stream socket with remote address leads to a segmentation fault).</li>
</ul></li>
<li>XMLRPC:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72606">#72606</a> (heap-buffer-overflow (write) simplestring_addn simplestring.c). (CVE-2016-6296)</li>
</ul></li>
<li>Zip:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72520">#72520</a> (Stack-based buffer overflow vulnerability in php_stream_zip_opener). (CVE-2016-6297)</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.0.8"><!-- {{{ 7.0.8 -->
<h3>Version 7.0.8</h3>
<time class='releasedate' datetime='2016-06-23'>23 Jun 2016</time><ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72218">#72218</a> (If host name cannot be resolved then PHP 7 crashes).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72221">#72221</a> (segfault, past-the-end access).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72268">#72268</a> (Integer Overflow in nl2br()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72275">#72275</a> (Integer Overflow in json_encode()/json_decode()/ json_utf8_to_utf16()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72400">#72400</a> (Integer Overflow in addcslashes/addslashes).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72403">#72403</a> (Integer Overflow in Length of String-typed ZVAL).</li>
</ul></li>
<li>Date:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/63740">#63740</a> (strtotime seems to use both sunday and monday as start of week).</li>
</ul></li>
<li>FPM:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72308">#72308</a> (fastcgi_finish_request and logging environment variables).</li>
</ul></li>
<li>GD:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72298">#72298</a> (pass2_no_dither out-of-bounds access).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72337">#72337</a> (invalid dimensions can lead to crash).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72339">#72339</a> (Integer Overflow in _gd2GetHeader() resulting in heap overflow). (CVE-2016-5766)</li>
  <li>Fixed bug <a href="http://bugs.php.net/72407">#72407</a> (NULL Pointer Dereference at _gdScaleVert).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72446">#72446</a> (Integer Overflow in gdImagePaletteToTrueColor() resulting in heap overflow). (CVE-2016-5767)</li>
</ul></li>
<li>Intl:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70484">#70484</a> (selectordinal doesn't work with named parameters).</li>
</ul></li>
<li>mbstring:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72402">#72402</a> (_php_mb_regex_ereg_replace_exec - double free). (CVE-2016-5768)</li>
</ul></li>
<li>mcrypt:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72455">#72455</a> (Heap Overflow due to integer overflows). (CVE-2016-5769)</li>
</ul></li>
<li>OpenSSL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72140">#72140</a> (segfault after calling ERR_free_strings()).</li>
</ul></li>
<li>PCRE:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72143">#72143</a> (preg_replace uses int instead of size_t).</li>
</ul></li>
<li>PDO_pgsql:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71573">#71573</a> (Segfault (core dumped) if paramno beyond bound).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72294">#72294</a> (Segmentation fault/invalid pointer in connection with pgsql_stmt_dtor).</li>
</ul></li>
<li>Phar:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72321">#72321</a> (invalid free in phar_extract_file()). (CVE-2016-4473)</li>
</ul></li>
<li>Phpdbg:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72284">#72284</a> (phpdbg fatal errors with coverage).</li>
</ul></li>
<li>Postgres:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72195">#72195</a> (pg_pconnect/pg_connect cause use-after-free).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72197">#72197</a> (pg_lo_create arbitrary read).</li>
</ul></li>
<li>Standard:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72017">#72017</a> (range() with float step produces unexpected result).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72193">#72193</a> (dns_get_record returns array containing elements of type 'unknown').</li>
  <li>Fixed bug <a href="http://bugs.php.net/72229">#72229</a> (Wrong reference when serialize/unserialize an object).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72300">#72300</a> (ignore_user_abort(false) has no effect).</li>
</ul></li>
<li>WDDX:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72340">#72340</a> (Double Free Courruption in wddx_deserialize). (CVE-2016-5772)</li>
</ul></li>
<li>XML:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72206">#72206</a> (xml_parser_create/xml_parser_free leaks mem).</li>
</ul></li>
<li>XMLRPC:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72155">#72155</a> (use-after-free caused by get_zval_xmlrpc_type).</li>
</ul></li>
<li>Zip:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72258">#72258</a> (ZipArchive converts filenames to unrecoverable form).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72434">#72434</a> (ZipArchive class Use After Free Vulnerability in PHP's GC algorithm and unserialize). (CVE-2016-5773)</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.0.7"><!-- {{{ 7.0.7 -->
<h3>Version 7.0.7</h3>
<time class='releasedate' datetime='2016-05-26'>26 May 2016</time><ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72162">#72162</a> (use-after-free - error_reporting).</li>
  <li>Add compiler option to disable special case function calls.</li>
  <li>Fixed bug <a href="http://bugs.php.net/72101">#72101</a> (crash on complex code).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72100">#72100</a> (implode() inserts garbage into resulting string when joins very big integer).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72057">#72057</a> (PHP Hangs when using custom error handler and typehint).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72038">#72038</a> (Function calls with values to a by-ref parameter don't always throw a notice).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71737">#71737</a> (Memory leak in closure with parameter named $this).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72059">#72059</a> (?? is not allowed on constant expressions).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72159">#72159</a> (Imported Class Overrides Local Class Name).</li>
</ul></li>
<li>Curl:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/68658">#68658</a> (Define CURLE_SSL_CACERT_BADFILE).</li>
</ul></li>
<li>DBA:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72157">#72157</a> (use-after-free caused by dba_open).</li>
</ul></li>
<li>GD:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72227">#72227</a> (imagescale out-of-bounds read). (CVE-2013-7456)</li>
</ul></li>
<li>Intl:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/64524">#64524</a> (Add intl.use_exceptions to php.ini-*).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72241">#72241</a> (get_icu_value_internal out-of-bounds read). (CVE-2016-5093)</li>
</ul></li>
<li>JSON:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72069">#72069</a> (Behavior \JsonSerializable different from json_encode).</li>
</ul></li>
<li>Mbstring:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72164">#72164</a> (Null Pointer Dereference - mb_ereg_replace).</li>
</ul></li>
<li>OCI8:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71600">#71600</a> (oci_fetch_all segfaults when selecting more than eight columns).</li>
</ul></li>
<li>Opcache:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72014">#72014</a> (Including a file with anonymous classes multiple times leads to fatal error).</li>
</ul></li>
<li>OpenSSL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72165">#72165</a> (Null pointer dereference - openssl_csr_new).</li>
</ul></li>
<li>PCNTL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72154">#72154</a> (pcntl_wait/pcntl_waitpid array internal structure overwrite).</li>
</ul></li>
<li>POSIX:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72133">#72133</a> (php_posix_group_to_array crashes if gr_passwd is NULL).</li>
</ul></li>
<li>Postgres:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72028">#72028</a> (pg_query_params(): NULL converts to empty string).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71062">#71062</a> (pg_convert() doesn't accept ISO 8601 for datatype timestamp).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72151">#72151</a> (mysqli_fetch_object changed behaviour). Patch to <a href="http://bugs.php.net/71820">#71820</a> is reverted.</li>
</ul></li>
<li>Reflection:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72174">#72174</a> (ReflectionProperty#getValue() causes __isset call).</li>
</ul></li>
<li>Session:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71972">#71972</a> (Cyclic references causing session_start(): Failed to decode session object).</li>
</ul></li>
<li>Sockets:
<ul>
  <li>Added socket_export_stream() function for getting a stream compatible resource from a socket resource.</li>
</ul></li>
<li>SPL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72051">#72051</a> (The reference in CallbackFilterIterator doesn't work as expected).</li>
</ul></li>
<li>SQLite3:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/68849">#68849</a> (bindValue is not using the right data type).</li>
</ul></li>
<li>Standard:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72075">#72075</a> (Referencing socket resources breaks stream_select).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72031">#72031</a> (array_column() against an array of objects discards all values matching null).</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.0.6"><!-- {{{ 7.0.6 -->
<h3>Version 7.0.6</h3>
<time class='releasedate' datetime='2016-04-28'>28 Apr 2016</time><ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71930">#71930</a> (_zval_dtor_func: Assertion `(arr)-&gt;gc.refcount &lt;= 1' failed).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71922">#71922</a> (Crash on assert(new class{})).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71914">#71914</a> (Reference is lost in "switch").</li>
  <li>Fixed bug <a href="http://bugs.php.net/71871">#71871</a> (Interfaces allow final and abstract functions).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71859">#71859</a> (zend_objects_store_call_destructors operates on realloced memory, crashing).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71841">#71841</a> (EG(error_zval) is not handled well).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71750">#71750</a> (Multiple Heap Overflows in php_raw_url_encode/ php_url_encode).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71731">#71731</a> (Null coalescing operator and ArrayAccess).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71609">#71609</a> (Segmentation fault on ZTS with gethostbyname).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71414">#71414</a> (Inheritance, traits and interfaces).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71359">#71359</a> (Null coalescing operator and magic).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71334">#71334</a> (Cannot access array keys while uksort()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69659">#69659</a> (ArrayAccess, isset() and the offsetExists method).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69537">#69537</a> (__debugInfo with empty string for key gives error).</li>
  <li>Fixed bug <a href="http://bugs.php.net/62059">#62059</a> (ArrayObject and isset are not friends).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71980">#71980</a> (Decorated/Nested Generator is Uncloseable in Finally).</li>
</ul></li>
<li>BCmath:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72093">#72093</a> (bcpowmod accepts negative scale and corrupts _one_ definition). (CVE-2016-4537, CVE-2016-4538)</li>
</ul></li>
<li>Curl:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71831">#71831</a> (CURLOPT_NOPROXY applied as long instead of string).</li>
</ul></li>
<li>Date:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71889">#71889</a> (DateInterval::format Segmentation fault).</li>
</ul></li>
<li>EXIF:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72094">#72094</a> (Out of bounds heap read access in exif header processing). (CVE-2016-4542, CVE-2016-4543, CVE-2016-4544)</li>
</ul></li>
<li>GD:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71912">#71912</a> (libgd: signedness vulnerability). (CVE-2016-3074)</li>
</ul></li>
<li>Intl:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71516">#71516</a> (IntlDateFormatter looses locale if pattern is set via constructor).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70455">#70455</a> (Missing constant: IntlChar::NO_NUMERIC_VALUE).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70451">#70451</a>, #70452 (Inconsistencies in return values of IntlChar methods).</li>
  <li>Fixed bug <a href="http://bugs.php.net/68893">#68893</a> (Stackoverflow in datefmt_create).</li>
  <li>Fixed bug <a href="http://bugs.php.net/66289">#66289</a> (Locale::lookup incorrectly returns en or en_US if locale is empty).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70484">#70484</a> (selectordinal doesn't work with named parameters).</li>
  <li>Fixed bug <a href="http://bugs.php.net/72061">#72061</a> (Out-of-bounds reads in zif_grapheme_stripos with negative offset). (CVE-2016-4540, CVE-2016-4541)</li>
</ul></li>
<li>ODBC:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/63171">#63171</a> (Script hangs after max_execution_time).</li>
</ul></li>
<li>Opcache:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71843">#71843</a> (null ptr deref ZEND_RETURN_SPEC_CONST_HANDLER).</li>
</ul></li>
<li>PDO:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/52098">#52098</a> (Own PDOStatement implementation ignore __call()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71447">#71447</a> (Quotes inside comments not properly handled).</li>
</ul></li>
<li>PDO_DBlib:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71943">#71943</a> (dblib_handle_quoter needs to allocate an extra byte).</li>
  <li>Add DBLIB-specific attributes for controlling timeouts.</li>
</ul></li>
<li>PDO_pgsql:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/62498">#62498</a> (pdo_pgsql inefficient when getColumnMeta() is used).</li>
</ul></li>
<li>Postgres:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71820">#71820</a> (pg_fetch_object binds parameters before call constructor).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71998">#71998</a> (Function pg_insert does not insert when column type = inet).</li>
</ul></li>
<li>SOAP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71986">#71986</a> (Nested foreach assign-by-reference creates broken variables).</li>
</ul></li>
<li>SPL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71838">#71838</a> (Deserializing serialized SPLObjectStorage-Object can't access properties in PHP).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71735">#71735</a> (Double-free in SplDoublyLinkedList::offsetSet).</li>
  <li>Fixed bug <a href="http://bugs.php.net/67582">#67582</a> (Cloned SplObjectStorage with overwritten getHash fails offsetExists()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/52339">#52339</a> (SPL autoloader breaks class_exists()).</li>
</ul></li>
<li>Standard:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72116">#72116</a> (array_fill optimization breaks implementation).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71995">#71995</a> (Returning the same var twice from __sleep() produces broken serialized data).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71940">#71940</a> (Unserialize crushes on restore object reference).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71969">#71969</a> (str_replace returns an incorrect resulting array after a foreach by reference).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71891">#71891</a> (header_register_callback() and register_shutdown_function()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71884">#71884</a> (Null pointer deref (segfault) in stream_context_get_default).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71840">#71840</a> (Unserialize accepts wrongly data).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71837">#71837</a> (Wrong arrays behaviour).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71827">#71827</a> (substr_replace bug, string length).</li>
  <li>Fixed bug <a href="http://bugs.php.net/67512">#67512</a> (php_crypt() crashes if crypt_r() does not exist or _REENTRANT is not defined).</li>
</ul></li>
<li>XML:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/72099">#72099</a> (xml_parse_into_struct segmentation fault). (CVE-2016-4539)</li>
</ul></li>
<li>Zip:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71923">#71923</a> (integer overflow in ZipArchive::getFrom*). (CVE-2016-3078)</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.0.5"><!-- {{{ 7.0.5 -->
<h3>Version 7.0.5</h3>
<time class='releasedate' datetime='2016-03-31'>31 Mar 2016</time><ul><li>Core:
<ul>
  <li>Huge pages disabled by default.</li>
  <li>Added ability to enable huge pages in Zend Memory Manager through the environment variable USE_ZEND_ALLOC_HUGE_PAGES=1.</li>
  <li>Fixed bug <a href="http://bugs.php.net/71756">#71756</a> (Call-by-reference widens scope to uninvolved functions when used in switch).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71729">#71729</a> (Possible crash in zend_bin_strtod, zend_oct_strtod, zend_hex_strtod).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71695">#71695</a> (Global variables are reserved before execution).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71629">#71629</a> (Out-of-bounds access in php_url_decode in context php_stream_url_wrap_rfc2397).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71622">#71622</a> (Strings used in pass-as-reference cannot be used to invoke C::$callable()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71596">#71596</a> (Segmentation fault on ZTS with date function (setlocale)).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71535">#71535</a> (Integer overflow in zend_mm_alloc_heap()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71470">#71470</a> (Leaked 1 hashtable iterators).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71575">#71575</a> (ISO C does not allow extra &lsquo;;&rsquo; outside of a function).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71724">#71724</a> (yield from does not count EOLs).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71767">#71767</a> (ReflectionMethod::getDocComment returns the wrong comment).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71806">#71806</a> (php_strip_whitespace() fails on some numerical values).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71624">#71624</a> (`php -R` (PHP_MODE_PROCESS_STDIN) is broken).</li>
</ul></li>
<li>CLI Server:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/69953">#69953</a> (Support MKCALENDAR request method).</li>
</ul></li>
<li>Curl:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71694">#71694</a> (Support constant CURLM_ADDED_ALREADY).</li>
</ul></li>
<li>Date:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71635">#71635</a> (DatePeriod::getEndDate segfault).</li>
</ul></li>
<li>Fileinfo:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71527">#71527</a> (Buffer over-write in finfo_open with malformed magic file). (CVE-2015-8865)</li>
</ul></li>
<li>libxml:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71536">#71536</a> (Access Violation crashes php-cgi.exe).</li>
</ul></li>
<li>mbstring:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71906">#71906</a> (AddressSanitizer: negative-size-param (-1) in mbfl_strcut). (CVE-2016-4073)</li>
</ul></li>
<li>ODBC:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/47803">#47803</a>, #69526 (Executing prepared statements is succesfull only for the first two statements).</li>
</ul></li>
<li>PCRE:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71659">#71659</a> (segmentation fault in pcre running twig tests).</li>
</ul></li>
<li>PDO_DBlib:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/54648">#54648</a> (PDO::MSSQL forces format of datetime fields).</li>
</ul></li>
<li>Phar:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71625">#71625</a> (Crash in php7.dll with bad phar filename).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71317">#71317</a> (PharData fails to open specific file).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71860">#71860</a> (Invalid memory write in phar on filename with \0 in name). (CVE-2016-4072)</li>
</ul></li>
<li>phpdbg:
<ul>
  <li>Fixed crash when advancing (except step) inside an internal function.</li>
</ul></li>
<li>Session:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71683">#71683</a> (Null pointer dereference in zend_hash_str_find_bucket).</li>
</ul></li>
<li>SNMP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71704">#71704</a> (php_snmp_error() Format String Vulnerability). (CVE-2016-4071)</li>
</ul></li>
<li>SPL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71617">#71617</a> (private properties lost when unserializing ArrayObject).</li>
</ul></li>
<li>Standard:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71660">#71660</a> (array_column behaves incorrectly after foreach by reference).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71798">#71798</a> (Integer Overflow in php_raw_url_encode). (CVE-2016-4070)</li>
</ul></li>
<li>Zip:
<ul>
  <li>Update bundled libzip to 1.1.2.</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.0.4"><!-- {{{ 7.0.4 -->
<h3>Version 7.0.4</h3>
<time class='releasedate' datetime='2016-03-03'>03 Mar 2016</time><ul><li>Core:
<ul>
  <li>Fixed bug (Low probability segfault in zend_arena).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71441">#71441</a> (Typehinted Generator with return in try/finally crashes).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71442">#71442</a> (forward_static_call crash).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71443">#71443</a> (Segfault using built-in webserver with intl using symfony).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71449">#71449</a> (An integer overflow bug in php_implode()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71450">#71450</a> (An integer overflow bug in php_str_to_str_ex()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71474">#71474</a> (Crash because of VM stack corruption on Magento2).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71485">#71485</a> (Return typehint on internal func causes Fatal error when it throws exception).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71529">#71529</a> (Variable references on array elements don't work when using count).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71601">#71601</a> (finally block not executed after yield from).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71637">#71637</a> (Multiple Heap Overflow due to integer overflows in xml/filter_url/addcslashes). (CVE-2016-4344, CVE-2016-4345, CVE-2016-4346)</li>
</ul></li>
<li>CLI server:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71559">#71559</a> (Built-in HTTP server, we can download file in web by bug).</li>
</ul></li>
<li>CURL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71523">#71523</a> (Copied handle with new option CURLOPT_HTTPHEADER crashes while curl_multi_exec).</li>
  <li>Fixed memory leak in curl_getinfo().</li>
</ul></li>
<li>Date:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71525">#71525</a> (Calls to date_modify will mutate timelib_rel_time, causing date_date_set issues).</li>
</ul></li>
<li>Fileinfo:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71434">#71434</a> (finfo throws notice for specific python file).</li>
</ul></li>
<li>FPM:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/62172">#62172</a> (FPM not working with Apache httpd 2.4 balancer/fcgi setup).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71269">#71269</a> (php-fpm dumped core).</li>
</ul></li>
<li>Opcache:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71584">#71584</a> (Possible use-after-free of ZCG(cwd) in Zend Opcache).</li>
</ul></li>
<li>PCRE:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71537">#71537</a> (PCRE segfault from Opcache).</li>
</ul></li>
<li>phpdbg:
<ul>
  <li>Fixed inherited functions from unspecified files being included in phpdbg_get_executable().</li>
</ul></li>
<li>SOAP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71610">#71610</a> (Type Confusion Vulnerability - SOAP / make_http_soap_request()). (CVE-2016-3185)</li>
</ul></li>
<li>Standard:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71603">#71603</a> (compact() maintains references in php7).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70720">#70720</a> (strip_tags improper php code parsing).</li>
</ul></li>
<li>XMLRPC:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71501">#71501</a> (xmlrpc_encode_request ignores encoding option).</li>
</ul></li>
<li>Zip:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71561">#71561</a> (NULL pointer dereference in Zip::ExtractTo).</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.0.3"><!-- {{{ 7.0.3 -->
<h3>Version 7.0.3</h3>
<time class='releasedate' datetime='2016-02-04'>04 Feb 2016</time><ul><li>Core:
<ul>
  <li>Added support for new HTTP 451 code.</li>
  <li>Fixed bug <a href="http://bugs.php.net/71039">#71039</a> (exec functions ignore length but look for NULL termination).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71089">#71089</a> (No check to duplicate zend_extension).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71201">#71201</a> (round() segfault on 64-bit builds).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71221">#71221</a> (Null pointer deref (segfault) in get_defined_vars via ob_start).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71248">#71248</a> (Wrong interface is enforced).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71273">#71273</a> (A wrong ext directory setup in php.ini leads to crash).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71275">#71275</a> (Bad method called on cloning an object having a trait).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71297">#71297</a> (Memory leak with consecutive yield from).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71300">#71300</a> (Segfault in zend_fetch_string_offset).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71314">#71314</a> (var_export(INF) prints INF.0).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71323">#71323</a> (Output of stream_get_meta_data can be falsified by its input).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71336">#71336</a> (Wrong is_ref on properties as exposed via get_object_vars()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71459">#71459</a> (Integer overflow in iptcembed()).</li>
</ul></li>
<li>Apache2handler:
<ul>
  <li>Fix &gt;2G Content-Length headers in apache2handler.</li>
</ul></li>
<li>CURL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71227">#71227</a> (Can't compile php_curl statically).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71225">#71225</a> (curl_setopt() fails to set CURLOPT_POSTFIELDS with reference to CURLFile).</li>
</ul></li>
<li>GD:
<ul>
  <li>Improved fix for bug <a href="http://bugs.php.net/70976">#70976</a>.</li>
</ul></li>
<li>Interbase:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71305">#71305</a> (Crash when optional resource is omitted).</li>
</ul></li>
<li>LDAP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71249">#71249</a> (ldap_mod_replace/ldap_mod_add store value as string "Array").</li>
</ul></li>
<li>mbstring:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71397">#71397</a> (mb_send_mail segmentation fault).</li>
</ul></li>
<li>OpenSSL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71475">#71475</a> (openssl_seal() uninitialized memory usage).</li>
</ul></li>
<li>PCRE:
<ul>
  <li>Upgraded bundled PCRE library to 8.38. (CVE-2015-8383, CVE-2015-8386, CVE-2015-8387, CVE-2015-8389, CVE-2015-8390, CVE-2015-8391, CVE-2015-8393, CVE-2015-8394)</li>
</ul></li>
<li>Phar:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71354">#71354</a> (Heap corruption in tar/zip/phar parser). (CVE-2016-4342)</li>
  <li>Fixed bug <a href="http://bugs.php.net/71331">#71331</a> (Uninitialized pointer in phar_make_dirstream()). (CVE-2016-4343)</li>
  <li>Fixed bug <a href="http://bugs.php.net/71391">#71391</a> (NULL Pointer Dereference in phar_tar_setupmetadata()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71488">#71488</a> (Stack overflow when decompressing tar archives). (CVE-2016-2554)</li>
</ul></li>
<li>SOAP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70979">#70979</a> (crash with bad soap request).</li>
</ul></li>
<li>SPL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71204">#71204</a> (segfault if clean spl_autoload_funcs while autoloading).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71202">#71202</a> (Autoload function registered by another not activated immediately).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71311">#71311</a> (Use-after-free vulnerability in SPL(ArrayObject, unserialize)).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71313">#71313</a> (Use-after-free vulnerability in SPL(SplObjectStorage, unserialize)).</li>
</ul></li>
<li>Standard:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71287">#71287</a> (Error message contains hexadecimal instead of decimal number).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71264">#71264</a> (file_put_contents() returns unexpected value when filesystem runs full).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71245">#71245</a> (file_get_contents() ignores "header" context option if it's a reference).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71220">#71220</a> (Null pointer deref (segfault) in compact via ob_start).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71190">#71190</a> (substr_replace converts integers in original $search array to strings).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71188">#71188</a> (str_replace converts integers in original $search array to strings).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71132">#71132</a>, <a href="http://bugs.php.net/71197">#71197</a> (range() segfaults).</li>
</ul></li>
<li>WDDX:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71335">#71335</a> (Type Confusion in WDDX Packet Deserialization).</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.0.2"><!-- {{{ 7.0.2 -->
<h3>Version 7.0.2</h3>
<time class='releasedate' datetime='2016-01-07'>07 Jan 2016</time><ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71165">#71165</a> (-DGC_BENCH=1 doesn't work on PHP7).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71163">#71163</a> (Segmentation Fault: cleanup_unfinished_calls).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71109">#71109</a> (ZEND_MOD_CONFLICTS("xdebug") doesn't work).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71092">#71092</a> (Segmentation fault with return type hinting).</li>
  <li>Fixed bug memleak in header_register_callback.</li>
  <li>Fixed bug <a href="http://bugs.php.net/71067">#71067</a> (Local object in class method stays in memory for each call).</li>
  <li>Fixed bug <a href="http://bugs.php.net/66909">#66909</a> (configure fails utf8_to_mutf7 test).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70781">#70781</a> (Extension tests fail on dynamic ext dependency).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71089">#71089</a> (No check to duplicate zend_extension).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71086">#71086</a> (Invalid numeric literal parse error within highlight_string() function).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71154">#71154</a> (Incorrect HT iterator invalidation causes iterator reuse).</li>
  <li>Fixed bug <a href="http://bugs.php.net/52355">#52355</a> (Negating zero does not produce negative zero).</li>
  <li>Fixed bug <a href="http://bugs.php.net/66179">#66179</a> (var_export() exports float as integer).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70804">#70804</a> (Unary add on negative zero produces positive zero).</li>
</ul></li>
<li>CURL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71144">#71144</a> (Sementation fault when using cURL with ZTS).</li>
</ul></li>
<li>DBA:
<ul>
  <li>Fixed key leak with invalid resource.</li>
</ul></li>
<li>Filter:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71063">#71063</a> (filter_input(INPUT_ENV, ..) does not work).</li>
</ul></li>
<li>FTP:
<ul>
  <li>Implemented FR <a href="http://bugs.php.net/55651">#55651</a> (Option to ignore the returned FTP PASV address).</li>
</ul></li>
<li>FPM:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70755">#70755</a> (fpm_log.c memory leak and buffer overflow). (CVE-2016-5114)</li>
</ul></li>
<li>GD:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70976">#70976</a> (Memory Read via gdImageRotateInterpolated Array Index Out of Bounds). (CVE-2016-1903)</li>
</ul></li>
<li>Mbstring:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71066">#71066</a> (mb_send_mail: Program terminated with signal SIGSEGV, Segmentation fault).</li>
</ul></li>
<li>Opcache:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71127">#71127</a> (Define in auto_prepend_file is overwrite).</li>
</ul></li>
<li>PCRE:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71178">#71178</a> (preg_replace with arrays creates [0] in replace array if not already set).</li>
</ul></li>
<li>Readline:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71094">#71094</a> (readline_completion_function corrupts static array on second TAB).</li>
</ul></li>
<li>Session:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71122">#71122</a> (Session GC may not remove obsolete session data).</li>
</ul></li>
<li>SPL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71077">#71077</a> (ReflectionMethod for ArrayObject constructor returns wrong number of parameters).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71153">#71153</a> (Performance Degradation in ArrayIterator with large arrays).</li>
</ul></li>
<li>Standard:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71270">#71270</a> (Heap BufferOver Flow in escapeshell functions). (CVE-2016-1904)</li>
</ul></li>
<li>WDDX:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70661">#70661</a> (Use After Free Vulnerability in WDDX Packet Deserialization).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70741">#70741</a> (Session WDDX Packet Deserialization Type Confusion Vulnerability).</li>
</ul></li>
<li>XMLRPC:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70728">#70728</a> (Type Confusion Vulnerability in PHP_to_XMLRPC_worker).</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.0.1"><!-- {{{ 7.0.1 -->
<h3>Version 7.0.1</h3>
<time class='releasedate' datetime='2015-12-17'>17 Dec 2015</time><ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71105">#71105</a> (Format String Vulnerability in Class Name Error Message). (CVE-2015-8617)</li>
  <li>Fixed bug <a href="http://bugs.php.net/70831">#70831</a> (Compile fails on system with 160 CPUs).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71006">#71006</a> (symbol referencing errors on Sparc/Solaris).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70997">#70997</a> (When using parentClass:: instead of parent::, static context changed).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70970">#70970</a> (Segfault when combining error handler with output buffering).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70967">#70967</a> (Weird error handling for __toString when Error is thrown).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70958">#70958</a> (Invalid opcode while using ::class as trait method paramater default value).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70944">#70944</a> (try{ } finally{} can create infinite chains of exceptions).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70931">#70931</a> (Two errors messages are in conflict).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70904">#70904</a> (yield from incorrectly marks valid generator as finished).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70899">#70899</a> (buildconf failure in extensions).</li>
  <li>Fixed bug <a href="http://bugs.php.net/61751">#61751</a> (SAPI build problem on AIX: Undefined symbol: php_register_internal_extensions).</li>
  <li>Fixed \int (or generally every scalar type name with leading backslash) to not be accepted as type name.</li>
  <li>Fixed exception not being thrown immediately into a generator yielding from an array.</li>
  <li>Fixed bug <a href="http://bugs.php.net/70987">#70987</a> (static::class within Closure::call() causes segfault).</li>
  <li>Fixed bug <a href="http://bugs.php.net/71013">#71013</a> (Incorrect exception handler with yield from).</li>
  <li>Fixed double free in error condition of format printer.</li>
</ul></li>
<li>CLI server:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71005">#71005</a> (Segfault in php_cli_server_dispatch_router()).</li>
</ul></li>
<li>Intl:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71020">#71020</a> (Use after free in Collator::sortWithSortKeys). (CVE-2015-8616)</li>
</ul></li>
<li>Mysqlnd:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/68077">#68077</a> (LOAD DATA LOCAL INFILE / open_basedir restriction).</li>
  <li>Fixed bug <a href="http://bugs.php.net/68344">#68344</a> (MySQLi does not provide way to disable peer certificate validation) by introducing MYSQLI_CLIENT_SSL_DONT_VERIFY_SERVER_CERT connection flag.</li>
</ul></li>
<li>OCI8:
<ul>
  <li>Fixed LOB implementation size_t/zend_long mismatch reported by gcov.</li>
</ul></li>
<li>Opcache:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71024">#71024</a> (Unable to use PHP 7.0 x64 side-by-side with PHP 5.6 x32 on the same server).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70991">#70991</a> (zend_file_cache.c:710: error: array type has incomplete element type).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70977">#70977</a> (Segmentation fault with opcache.huge_code_pages=1).</li>
</ul></li>
<li>PDO_Firebird:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/60052">#60052</a> (Integer returned as a 64bit integer on X64_86).</li>
</ul></li>
<li>Phpdbg:
<ul>
  <li>Fixed stderr being written to stdout.</li>
</ul></li>
<li>Reflection:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71018">#71018</a> (ReflectionProperty::setValue() behavior changed).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70982">#70982</a> (setStaticPropertyValue behaviors inconsistently with 5.6).</li>
</ul></li>
<li>Soap:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70993">#70993</a> (Array key references break argument processing).</li>
</ul></li>
<li>SPL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71028">#71028</a> (Undefined index with ArrayIterator).</li>
</ul></li>
<li>SQLite3:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/71049">#71049</a> (SQLite3Stmt::execute() releases bound parameter instead of internal buffer).</li>
</ul></li>
<li>Standard:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70999">#70999</a> (php_random_bytes: called object is not a function).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70960">#70960</a> (ReflectionFunction for array_unique returns wrong number of parameters).</li>
</ul></li>
<li>Streams/Socket:
<ul>
  <li>Add IPV6_V6ONLY constant / make it usable in stream contexts.</li>
</ul></li>
</ul>
<!-- }}} --></section>

<section class="version" id="7.0.0"><!-- {{{ 7.0.0 -->
<h3>Version 7.0.0</h3>
<time class='releasedate' datetime='2015-12-03'>03 Dec 2015</time><ul><li>Core:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70947">#70947</a> (INI parser segfault with INI_SCANNER_TYPED).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70914">#70914</a> (zend_throw_or_error() format string vulnerability).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70912">#70912</a> (Null ptr dereference instantiating class with invalid array property).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70895">#70895</a>, <a href="http://bugs.php.net/70898">#70898</a> (null ptr deref and segfault with crafted calable).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70249">#70249</a> (Segmentation fault while running PHPUnit tests on phpBB 3.2-dev).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70805">#70805</a> (Segmentation faults whilst running Drupal 8 test suite).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70842">#70842</a> (Persistent Stream Segmentation Fault).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70862">#70862</a> (Several functions do not check return code of php_stream_copy_to_mem()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70863">#70863</a> (Incorect logic to increment_function for proxy objects).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70323">#70323</a> (Regression in zend_fetch_debug_backtrace() can cause segfaults).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70873">#70873</a> (Regression on private static properties access).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70748">#70748</a> (Segfault in ini_lex () at Zend/zend_ini_scanner.l).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70689">#70689</a> (Exception handler does not work as expected).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70430">#70430</a> (Stack buffer overflow in zend_language_parser()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70782">#70782</a> (null ptr deref and segfault (zend_get_class_fetch_type)).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70785">#70785</a> (Infinite loop due to exception during identical comparison).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70630">#70630</a> (Closure::call/bind() crash with ReflectionFunction-&gt; getClosure()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70662">#70662</a> (Duplicate array key via undefined index error handler).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70681">#70681</a> (Segfault when binding $this of internal instance method to null).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70685">#70685</a> (Segfault for getClosure() internal method rebind with invalid $this).</li>
  <li>Added zend_internal_function.reserved[] fields.</li>
  <li>Fixed bug <a href="http://bugs.php.net/70557">#70557</a> (Memleak on return type verifying failed).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70555">#70555</a> (fun_get_arg() on unsetted vars return UNKNOW).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70548">#70548</a> (Redundant information printed in case of uncaught engine exception).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70547">#70547</a> (unsetting function variables corrupts backtrace).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70528">#70528</a> (assert() with instanceof adds apostrophes around class name).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70481">#70481</a> (Memory leak in auto_global_copy_ctor() in ZTS build).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70431">#70431</a> (Memory leak in php_ini.c).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70478">#70478</a> (**= does no longer work).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70398">#70398</a> (SIGSEGV, Segmentation fault zend_ast_destroy_ex).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70332">#70332</a> (Wrong behavior while returning reference on object).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70300">#70300</a> (Syntactical inconsistency with new group use syntax).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70321">#70321</a> (Magic getter breaks reference to array property).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70187">#70187</a> (Notice: unserialize(): Unexpected end of serialized data).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70145">#70145</a> (From field incorrectly parsed from headers).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70370">#70370</a> (Bundled libtool.m4 doesn't handle FreeBSD 10 when building extensions).</li>
  <li>Fixed bug causing exception traces with anon classes to be truncated.</li>
  <li>Fixed bug <a href="http://bugs.php.net/70397">#70397</a> (Segmentation fault when using Closure::call and yield).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70299">#70299</a> (Memleak while assigning object offsetGet result).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70288">#70288</a> (Apache crash related to ZEND_SEND_REF).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70262">#70262</a> (Accessing array crashes PHP 7.0beta3).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70258">#70258</a> (Segfault if do_resize fails to allocated memory).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70253">#70253</a> (segfault at _efree () in zend_alloc.c:1389).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70240">#70240</a> (Segfault when doing unset($var());).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70223">#70223</a> (Incrementing value returned by magic getter).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70215">#70215</a> (Segfault when __invoke is static).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70207">#70207</a> (Finally is broken with opcache).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70173">#70173</a> (ZVAL_COPY_VALUE_EX broken for 32bit Solaris Sparc).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69487">#69487</a> (SAPI may truncate POST data).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70198">#70198</a> (Checking liveness does not work as expected).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70241">#70241</a>, <a href="http://bugs.php.net/70293">#70293</a> (Skipped assertions affect Generator returns).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70239">#70239</a> (Creating a huge array doesn't result in exhausted, but segfault).</li>
  <li>Fixed "finally" issues.</li>
  <li>Fixed bug <a href="http://bugs.php.net/70098">#70098</a> (Real memory usage doesn't decrease).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70159">#70159</a> (__CLASS__ is lost in closures).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70156">#70156</a> (Segfault in zend_find_alias_name).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70124">#70124</a> (null ptr deref / seg fault in ZEND_HANDLE_EXCEPTION).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70117">#70117</a> (Unexpected return type error).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70106">#70106</a> (Inheritance by anonymous class).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69674">#69674</a> (SIGSEGV array.c:953).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70164">#70164</a> (__COMPILER_HALT_OFFSET__ under namespace is not defined).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70108">#70108</a> (sometimes empty $_SERVER['QUERY_STRING']).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70179">#70179</a> ($this refcount issue).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69896">#69896</a> ('asm' operand has impossible constraints).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70183">#70183</a> (null pointer deref (segfault) in zend_eval_const_expr).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70182">#70182</a> (Segfault in ZEND_ASSIGN_DIV_SPEC_CV_UNUSED_HANDLER).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69793">#69793</a> (Remotely triggerable stack exhaustion via recursive method calls).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69892">#69892</a> (Different arrays compare indentical due to integer key truncation).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70121">#70121</a> (unserialize() could lead to unexpected methods execution / NULL pointer deref).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70089">#70089</a> (segfault at ZEND_FETCH_DIM_W_SPEC_VAR_CONST_HANDLER ()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70057">#70057</a> (Build failure on 32-bit Mac OS X 10.6.8: recursive inlining).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70012">#70012</a> (Exception lost with nested finally block).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69996">#69996</a> (Changing the property of a cloned object affects the original).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70083">#70083</a> (Use after free with assign by ref to overloaded objects).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70006">#70006</a> (cli - function with default arg = STDOUT crash output).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69521">#69521</a> (Segfault in gc_collect_cycles()).</li>
  <li>Improved zend_string API.</li>
  <li>Fixed bug <a href="http://bugs.php.net/69955">#69955</a> (Segfault when trying to combine [] and assign-op on ArrayAccess object).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69957">#69957</a> (Different ways of handling div/mod/intdiv).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69900">#69900</a> (Too long timeout on pipes).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69872">#69872</a> (uninitialised value in strtr with array).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69868">#69868</a> (Invalid read of size 1 in zend_compile_short_circuiting).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69849">#69849</a> (Broken output of apache_request_headers).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69840">#69840</a> (iconv_substr() doesn't work with UTF-16BE).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69823">#69823</a> (PHP 7.0.0alpha1 segmentation fault when exactly 33 extensions are loaded).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69805">#69805</a> (null ptr deref and seg fault in zend_resolve_class_name).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69802">#69802</a> (Reflection on Closure::__invoke borks type hint class name).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69761">#69761</a> (Serialization of anonymous classes should be prevented).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69551">#69551</a> (parse_ini_file() and parse_ini_string() segmentation fault).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69781">#69781</a> (phpinfo() reports Professional Editions of Windows 7/8/8.1/10 as "Business").</li>
  <li>Fixed bug <a href="http://bugs.php.net/69835">#69835</a> (phpinfo() does not report many Windows SKUs).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69889">#69889</a> (Null coalesce operator doesn't work for string offsets).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69891">#69891</a> (Unexpected array comparison result).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69892">#69892</a> (Different arrays compare indentical due to integer key truncation).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69893">#69893</a> (Strict comparison between integer and empty string keys crashes).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69767">#69767</a> (Default parameter value with wrong type segfaults).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69756">#69756</a> (Fatal error: Nesting level too deep - recursive dependency ? with ===).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69758">#69758</a> (Item added to array not being removed by array_pop/shift ).</li>
  <li>Fixed bug <a href="http://bugs.php.net/68475">#68475</a> (Add support for $callable() sytnax with 'Class::method').</li>
  <li>Fixed bug <a href="http://bugs.php.net/69485">#69485</a> (Double free on zend_list_dtor).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69427">#69427</a> (Segfault on magic method __call of private method in superclass).</li>
  <li>Improved __call() and __callStatic() magic method handling. Now they are called in a stackless way using ZEND_CALL_TRAMPOLINE opcode, without additional stack frame.</li>
  <li>Optimized strings concatenation.</li>
  <li>Fixed weird operators behavior. Division by zero now emits warning and returns +/-INF, modulo by zero and intdid() throws an exception, shifts by negative offset throw exceptions. Compile-time evaluation of division by zero is disabled.</li>
  <li>Fixed bug <a href="http://bugs.php.net/69371">#69371</a> (Hash table collision leads to inaccessible array keys).</li>
  <li>Fixed bug <a href="http://bugs.php.net/68933">#68933</a> (Invalid read of size 8 in zend_std_read_property).</li>
  <li>Fixed bug <a href="http://bugs.php.net/68252">#68252</a> (segfault in Zend/zend_hash.c in function _zend_hash_del_el).</li>
  <li>Fixed bug <a href="http://bugs.php.net/65598">#65598</a> (Closure executed via static autoload incorrectly marked as static).</li>
  <li>Fixed bug <a href="http://bugs.php.net/66811">#66811</a> (Cannot access static::class in lambda, writen outside of a class).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69568">#69568</a> (call a private function in closure failed).</li>
  <li>Added PHP_INT_MIN constant.</li>
  <li>Added Closure::call() method.</li>
  <li>Fixed bug <a href="http://bugs.php.net/67959">#67959</a> (Segfault when calling phpversion('spl')).</li>
  <li>Implemented the RFC `Catchable "Call to a member function bar() on a non-object"`.</li>
  <li>Added options parameter for unserialize allowing to specify acceptable classes (https://wiki.php.net/rfc/secure_unserialize).</li>
  <li>Fixed bug <a href="http://bugs.php.net/63734">#63734</a> (Garbage collector can free zvals that are still referenced).</li>
  <li>Removed ZEND_ACC_FINAL_CLASS, promoting ZEND_ACC_FINAL as final class modifier.</li>
  <li>is_long() &amp; is_integer() is now an alias of is_int().</li>
  <li>Implemented FR <a href="http://bugs.php.net/55467">#55467</a> (phpinfo: PHP Variables with $ and single quotes).</li>
  <li>Added ?? operator.</li>
  <li>Added &lt;=&gt; operator.</li>
  <li>Added \u{xxxxx} Unicode Codepoint Escape Syntax.</li>
  <li>Fixed oversight where define() did not support arrays yet const syntax did.</li>
  <li>Use "integer" and "float" instead of "long" and "double" in ZPP, type hint and conversion error messages.</li>
  <li>Implemented FR <a href="http://bugs.php.net/55428">#55428</a> (E_RECOVERABLE_ERROR when output buffering in output buffering handler).</li>
  <li>Removed scoped calls of non-static methods from an incompatible $this context.</li>
  <li>Removed support for #-style comments in ini files.</li>
  <li>Removed support for assigning the result of new by reference.</li>
  <li>Invalid octal literals in source code now produce compile errors, fixes PHPSadness #31.</li>
  <li>Removed dl() function on fpm-fcgi.</li>
  <li>Removed support for hexadecimal numeric strings.</li>
  <li>Removed obsolete extensions and SAPIs. See the full list in UPGRADING.</li>
  <li>Added NULL byte protection to exec, system and passthru.</li>
  <li>Added error_clear_last() function.</li>
  <li>Fixed bug <a href="http://bugs.php.net/68797">#68797</a> (Number 2.2250738585072012e-308 converted incorrectly).</li>
  <li>Improved zend_qsort(using hybrid sorting algo) for better performance, and also renamed zend_qsort to zend_sort.</li>
  <li>Added stable sorting algo zend_insert_sort.</li>
  <li>Improved zend_memnchr(using sunday algo) for better performance.</li>
  <li>Implemented the RFC `Scalar Type Decalarations v0.5`.</li>
  <li>Implemented the RFC `Group Use Declarations`.</li>
  <li>Implemented the RFC `Continue Output Buffering`.</li>
  <li>Implemented the RFC `Constructor behaviour of internal classes`.</li>
  <li>Implemented the RFC `Fix "foreach" behavior`.</li>
  <li>Implemented the RFC `Generator Delegation`.</li>
  <li>Implemented the RFC `Anonymous Class Support`.</li>
  <li>Implemented the RFC `Context Sensitive Lexer`.</li>
  <li>Fixed bug <a href="http://bugs.php.net/69511">#69511</a> (Off-by-one buffer overflow in php_sys_readlink).</li>
</ul></li>
<li>CLI server:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/68291">#68291</a> (404 on urls with '+').</li>
  <li>Fixed bug <a href="http://bugs.php.net/66606">#66606</a> (Sets HTTP_CONTENT_TYPE but not CONTENT_TYPE).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70264">#70264</a> (CLI server directory traversal).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69655">#69655</a> (php -S changes MKCALENDAR request method to MKCOL).</li>
  <li>Fixed bug <a href="http://bugs.php.net/64878">#64878</a> (304 responses return Content-Type header).</li>
  <li>Refactor MIME type handling to use a hash table instead of linear search.</li>
  <li>Update the MIME type list from the one shipped by Apache HTTPD.</li>
  <li>Added support for SEARCH WebDav method.</li>
</ul></li>
<li>COM:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/69939">#69939</a> (Casting object to bool returns false).</li>
</ul></li>
<li>Curl:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70330">#70330</a> (Segmentation Fault with multiple "curl_copy_handle").</li>
  <li>Fixed bug <a href="http://bugs.php.net/70163">#70163</a> (curl_setopt_array() type confusion).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70065">#70065</a> (curl_getinfo() returns corrupted values).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69831">#69831</a> (Segmentation fault in curl_getinfo).</li>
  <li>Fixed bug <a href="http://bugs.php.net/68937">#68937</a> (Segfault in curl_multi_exec).</li>
  <li>Removed support for unsafe file uploads.</li>
</ul></li>
<li>Date:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70245">#70245</a> (strtotime does not emit warning when 2nd parameter is object or string).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70266">#70266</a> (DateInterval::__construct.interval_spec is not supposed to be optional).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70277">#70277</a> (new DateTimeZone($foo) is ignoring text after null byte).</li>
  <li>Fixed day_of_week function as it could sometimes return negative values internally.</li>
  <li>Removed $is_dst parameter from mktime() and gmmktime().</li>
  <li>Removed date.timezone warning (https://wiki.php.net/rfc/date.timezone_warning_removal).</li>
  <li>Added "v" DateTime format modifier to get the 3-digit version of fraction of seconds.</li>
  <li>Implemented FR <a href="http://bugs.php.net/69089">#69089</a> (Added DateTime::RFC3339_EXTENDED to output in RFC3339 Extended format which includes fraction of seconds).</li>
</ul></li>
<li>DBA:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/62490">#62490</a> (dba_delete returns true on missing item (inifile)).</li>
  <li>Fixed bug <a href="http://bugs.php.net/68711">#68711</a> (useless comparisons).</li>
</ul></li>
<li>DOM:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70558">#70558</a> ("Couldn't fetch" error in DOMDocument::registerNodeClass()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70001">#70001</a> (Assigning to DOMNode::textContent does additional entity encoding).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69846">#69846</a> (Segmenation fault (access violation) when iterating over DOMNodeList).</li>
  <li>Made DOMNode::textContent writeable.</li>
</ul></li>
<li>EXIF:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70385">#70385</a> (Buffer over-read in exif_read_data with TIFF IFD tag byte value of 32 bytes).</li>
</ul></li>
<li>Fileinfo:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/66242">#66242</a> (libmagic: don't assume char is signed).</li>
</ul></li>
<li>Filter:
<ul>
  <li>New FILTER_VALIDATE_DOMAIN and better RFC conformance for FILTER_VALIDATE_URL.</li>
  <li>Fixed bug <a href="http://bugs.php.net/67167">#67167</a> 	(Wrong return value from FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE).</li>
</ul></li>
<li>FPM:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70538">#70538</a> ("php-fpm -i" crashes).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70279">#70279</a> (HTTP Authorization Header is sometimes passed to newer reqeusts).</li>
  <li>Fixed bug <a href="http://bugs.php.net/68945">#68945</a> (Unknown admin values segfault pools).</li>
  <li>Fixed bug <a href="http://bugs.php.net/65933">#65933</a> (Cannot specify config lines longer than 1024 bytes).</li>
  <li>Implemented FR <a href="http://bugs.php.net/67106">#67106</a> (Split main fpm config).</li>
</ul></li>
<li>FTP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/69082">#69082</a> (FTPS support on Windows).</li>
</ul></li>
<li>GD:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/53156">#53156</a> (imagerectangle problem with point ordering).</li>
  <li>Fixed bug <a href="http://bugs.php.net/66387">#66387</a> (Stack overflow with imagefilltoborder). (CVE-2015-8874)</li>
  <li>Fixed bug <a href="http://bugs.php.net/70102">#70102</a> (imagecreatefromwebm() shifts colors).</li>
  <li>Fixed bug <a href="http://bugs.php.net/66590">#66590</a> (imagewebp() doesn't pad to even length).</li>
  <li>Fixed bug <a href="http://bugs.php.net/66882">#66882</a> (imagerotate by -90 degrees truncates image by 1px).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70064">#70064</a> (imagescale(..., IMG_BICUBIC) leaks memory).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69024">#69024</a> (imagescale segfault with palette based image).</li>
  <li>Fixed bug <a href="http://bugs.php.net/53154">#53154</a> (Zero-height rectangle has whiskers).</li>
  <li>Fixed bug <a href="http://bugs.php.net/67447">#67447</a> (imagecrop() add a black line when cropping).</li>
  <li>Fixed bug <a href="http://bugs.php.net/68714">#68714</a> (copy 'n paste error).</li>
  <li>Fixed bug <a href="http://bugs.php.net/66339">#66339</a> (PHP segfaults in imagexbm).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70047">#70047</a> (gd_info() doesn't report WebP support).</li>
  <li>Replace libvpx with libwebp for bundled libgd.</li>
  <li>Fixed bug <a href="http://bugs.php.net/61221">#61221</a> (imagegammacorrect function loses alpha channel).</li>
  <li>Made fontFetch's path parser thread-safe.</li>
  <li>Removed T1Lib support.</li>
</ul></li>
<li>GMP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70284">#70284</a> (Use after free vulnerability in unserialize() with GMP).</li>
</ul></li>
<li>hash:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70312">#70312</a> (HAVAL gives wrong hashes in specific cases).</li>
</ul></li>
<li>IMAP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70158">#70158</a> (Building with static imap fails).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69998">#69998</a> (curl multi leaking memory).</li>
</ul></li>
<li>Intl:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70453">#70453</a> (IntlChar::foldCase() incorrect arguments and missing constants).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70454">#70454</a> (IntlChar::forDigit second parameter should be optional).</li>
  <li>Removed deprecated aliases datefmt_set_timezone_id() and IntlDateFormatter::setTimeZoneID().</li>
</ul></li>
<li>JSON:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/62010">#62010</a> (json_decode produces invalid byte-sequences).</li>
  <li>Fixed bug <a href="http://bugs.php.net/68546">#68546</a> (json_decode() Fatal error: Cannot access property started with '\0').</li>
  <li>Replace non-free JSON parser with a parser from Jsond extension, fixes <a href="http://bugs.php.net/63520">#63520</a> (JSON extension includes a problematic license statement).</li>
  <li>Fixed bug <a href="http://bugs.php.net/68938">#68938</a> (json_decode() decodes empty string without error).</li>
</ul></li>
<li>LDAP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/47222">#47222</a> (Implement LDAP_OPT_DIAGNOSTIC_MESSAGE).</li>
</ul></li>
<li>LiteSpeed:
<ul>
  <li>Updated LiteSpeed SAPI code from V5.5 to V6.6.</li>
</ul></li>
<li>libxml:
<ul>
  <li>Fixed handling of big lines in error messages with libxml &gt;= 2.9.0.</li>
</ul></li>
<li>Mcrypt:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70625">#70625</a> (mcrypt_encrypt() won't return data when no IV was specified under RC4).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69833">#69833</a> (mcrypt fd caching not working).</li>
  <li>Fixed possible read after end of buffer and use after free.</li>
  <li>Removed mcrypt_generic_end() alias.</li>
  <li>Removed mcrypt_ecb(), mcrypt_cbc(), mcrypt_cfb(), mcrypt_ofb().</li>
</ul></li>
<li>Mysqli:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/32490">#32490</a> (constructor of mysqli has wrong name).</li>
</ul></li>
<li>Mysqlnd:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70949">#70949</a> (SQL Result Sets With NULL Can Cause Fatal Memory Errors).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70384">#70384</a> (mysqli_real_query():Unknown type 245 sent by the server).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70456">#70456</a> (mysqlnd doesn't activate TCP keep-alive when connecting to a server).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70572">#70572</a> segfault in mysqlnd_connect.</li>
  <li>Fixed bug <a href="http://bugs.php.net/69796">#69796</a> (mysqli_stmt::fetch doesn't assign null values to bound variables).</li>
</ul></li>
<li>OCI8:
<ul>
  <li>Fixed memory leak with LOBs.</li>
  <li>Fixed bug <a href="http://bugs.php.net/68298">#68298</a> (OCI int overflow).</li>
  <li>Corrected oci8 hash destructors to prevent segfaults, and a few other fixes.</li>
</ul></li>
<li>ODBC:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/69975">#69975</a> (PHP segfaults when accessing nvarchar(max) defined columns. (CVE-2015-8879)</li>
</ul></li>
<li>Opcache:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70656">#70656</a> (require() statement broken after opcache_reset() or a few hours of use).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70843">#70843</a> (Segmentation fault on MacOSX with opcache.file_cache_only=1).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70724">#70724</a> (Undefined Symbols from opcache.so on Mac OS X 10.10).</li>
  <li>Fixed compatibility with Windows 10 (see also bug <a href="http://bugs.php.net/70652">#70652</a>).</li>
  <li>Attmpt to fix "Unable to reattach to base address" problem.</li>
  <li>Fixed bug <a href="http://bugs.php.net/70423">#70423</a> (Warning Internal error: wrong size calculation).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70237">#70237</a> (Empty while and do-while segmentation fault with opcode on CLI enabled).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70111">#70111</a> (Segfault when a function uses both an explicit return type and an explicit cast).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70058">#70058</a> (Build fails when building for i386).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70022">#70022</a> (Crash with opcache using opcache.file_cache_only=1).</li>
  <li>Removed opcache.load_comments configuration directive. Now doc comments loading costs nothing and always enabled.</li>
  <li>Fixed bug <a href="http://bugs.php.net/69838">#69838</a> (Wrong size calculation for function table).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69688">#69688</a> (segfault with eval and opcache fast shutdown).</li>
  <li>Added experimental (disabled by default) file based opcode cache.</li>
  <li>Fixed bug with try blocks being removed when extended_info opcode generation is turned on.</li>
  <li>Fixed bug <a href="http://bugs.php.net/68644">#68644</a> (strlen incorrect : mbstring + func_overload=2 +UTF-8 + Opcache).</li>
</ul></li>
<li>OpenSSL:
<ul>
  <li>Require at least OpenSSL version 0.9.8.</li>
  <li>Fixed bug <a href="http://bugs.php.net/68312">#68312</a> (Lookup for openssl.cnf causes a message box).</li>
  <li>Fixed bug <a href="http://bugs.php.net/55259">#55259</a> (openssl extension does not get the DH parameters from DH key resource).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70395">#70395</a> (Missing ARG_INFO for openssl_seal()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/60632">#60632</a> (openssl_seal fails with AES).</li>
  <li>Implemented FR <a href="http://bugs.php.net/70438">#70438</a> (Add IV parameter for openssl_seal and openssl_open).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70014">#70014</a> (openssl_random_pseudo_bytes() is not cryptographically secure). (CVE-2015-8867)</li>
  <li>Fixed bug <a href="http://bugs.php.net/69882">#69882</a> (OpenSSL error "key values mismatch" after openssl_pkcs12_read with extra cert).</li>
  <li>Added "alpn_protocols" SSL context option allowing encrypted client/server streams to negotiate alternative protocols using the ALPN TLS extension when built against OpenSSL 1.0.2 or newer. Negotiated protocol information is accessible through stream_get_meta_data() output.</li>
  <li>Removed "CN_match" and "SNI_server_name" SSL context options. Use automatic detection or the "peer_name" option instead.</li>
</ul></li>
<li>Pcntl:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70386">#70386</a> (Can't compile on NetBSD because of missing WCONTINUED and WIFCONTINUED).</li>
  <li>Fixed bug <a href="http://bugs.php.net/60509">#60509</a> (pcntl_signal doesn't decrease ref-count of old handler when setting SIG_DFL).</li>
  <li>Implemented FR <a href="http://bugs.php.net/68505">#68505</a> (Added wifcontinued and wcontinued).</li>
  <li>Added rusage support to pcntl_wait() and pcntl_waitpid().</li>
</ul></li>
<li>PCRE:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70232">#70232</a> (Incorrect bump-along behavior with \K and empty string match).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70345">#70345</a> (Multiple vulnerabilities related to PCRE functions).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70232">#70232</a> (Incorrect bump-along behavior with \K and empty string match).</li>
  <li>Fixed bug <a href="http://bugs.php.net/53823">#53823</a> (preg_replace: * qualifier on unicode replace garbles the string).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69864">#69864</a> (Segfault in preg_replace_callback).</li>
  <li>Removed support for the /e (PREG_REPLACE_EVAL) modifier.</li>
</ul></li>
<li>PDO:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70861">#70861</a> (Segmentation fault in pdo_parse_params() during Drupal 8 test suite).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70389">#70389</a> (PDO constructor changes unrelated variables).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70272">#70272</a> (Segfault in pdo_mysql).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70221">#70221</a> (persistent sqlite connection + custom function segfaults).</li>
  <li>Fixed bug <a href="http://bugs.php.net/59450">#59450</a> (./configure fails with "Cannot find php_pdo_driver.h").</li>
</ul></li>
<li>PDO_DBlib:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/69757">#69757</a> (Segmentation fault on nextRowset).</li>
</ul></li>
<li>PDO_mysql:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/68424">#68424</a> (Add new PDO mysql connection attr to control multi statements option).</li>
</ul></li>
<li>PDO_OCI:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70308">#70308</a> (PDO::ATTR_PREFETCH is ignored).</li>
</ul></li>
<li>PDO_pgsql:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/69752">#69752</a> (PDOStatement::execute() leaks memory with DML Statements when closeCuror() is u).</li>
  <li>Removed PGSQL_ATTR_DISABLE_NATIVE_PREPARED_STATEMENT attribute in favor of ATTR_EMULATE_PREPARES).</li>
</ul></li>
<li>Phar:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/69720">#69720</a> (Null pointer dereference in phar_get_fp_offset()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70433">#70433</a> (Uninitialized pointer in phar_make_dirstream when zip entry filename is "/").</li>
  <li>Improved fix for bug <a href="http://bugs.php.net/69441">#69441</a>.</li>
  <li>Fixed bug <a href="http://bugs.php.net/70019">#70019</a> (Files extracted from archive may be placed outside of destination directory).</li>
</ul></li>
<li>Phpdbg:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70614">#70614</a> (incorrect exit code in -rr mode with Exceptions).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70532">#70532</a> (phpdbg must respect set_exception_handler).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70531">#70531</a> (Run and quit mode (-qrr) should not fallback to interactive mode).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70533">#70533</a> (Help overview (-h) does not rpint anything under Windows).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70449">#70449</a> (PHP won't compile on 10.4 and 10.5 because of missing constants).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70214">#70214</a> (FASYNC not defined, needs sys/file.h include).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70138">#70138</a> (Segfault when displaying memory leaks).</li>
</ul></li>
<li>Reflection:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70650">#70650</a> (Wrong docblock assignment).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70674">#70674</a> (ReflectionFunction::getClosure() leaks memory when used for internal functions).</li>
  <li>Fixed bug causing bogus traces for ReflectionGenerator::getTrace().</li>
  <li>Fixed inheritance chain of Reflector interface.</li>
  <li>Added ReflectionGenerator class.</li>
  <li>Added reflection support for return types and type declarations.</li>
</ul></li>
<li>Session:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70876">#70876</a> (Segmentation fault when regenerating session id with strict mode).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70529">#70529</a> (Session read causes "String is not zero-terminated" error).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70013">#70013</a> (Reference to $_SESSION is lost after a call to session_regenerate_id()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69952">#69952</a> (Data integrity issues accessing superglobals by reference).</li>
  <li>Fixed bug <a href="http://bugs.php.net/67694">#67694</a> (Regression in session_regenerate_id()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/68941">#68941</a> (mod_files.sh is a bash-script).</li>
</ul></li>
<li>SOAP:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70940">#70940</a> (Segfault in soap / type_to_string).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70900">#70900</a> (SoapClient systematic out of memory error).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70875">#70875</a> (Segmentation fault if wsdl has no targetNamespace attribute).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70715">#70715</a> (Segmentation fault inside soap client).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70709">#70709</a> (SOAP Client generates Segfault).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70388">#70388</a> (SOAP serialize_function_call() type confusion / RCE).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70081">#70081</a> (SoapClient info leak / null pointer dereference via multiple type confusions).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70079">#70079</a> (Segmentation fault after more than 100 SoapClient calls).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70032">#70032</a> (make_http_soap_request calls zend_hash_get_current_key_ex(,,,NULL).</li>
  <li>Fixed bug <a href="http://bugs.php.net/68361">#68361</a> (Segmentation fault on SoapClient::__getTypes).</li>
</ul></li>
<li>SPL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70959">#70959</a> (ArrayObject unserialize does not restore protected fields).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70853">#70853</a> (SplFixedArray throws exception when using ref variable as index).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70868">#70868</a> (PCRE JIT and pattern reuse segfault).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70730">#70730</a> (Incorrect ArrayObject serialization if unset is called in serialize()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70573">#70573</a> (Cloning SplPriorityQueue leads to memory leaks).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70303">#70303</a> (Incorrect constructor reflection for ArrayObject).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70068">#70068</a> (Dangling pointer in the unserialization of ArrayObject items).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70166">#70166</a> (Use After Free Vulnerability in unserialize() with SPLArrayObject).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70168">#70168</a> (Use After Free Vulnerability in unserialize() with SplObjectStorage).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70169">#70169</a> (Use After Free Vulnerability in unserialize() with SplDoublyLinkedList).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70053">#70053</a> (MutlitpleIterator array-keys incompatible change in PHP 7).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69970">#69970</a> (Use-after-free vulnerability in spl_recursive_it_move_forward_ex()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69845">#69845</a> (ArrayObject with ARRAY_AS_PROPS broken).</li>
  <li>Changed ArrayIterator implementation using zend_hash_iterator_... API. Allowed modification of iterated ArrayObject using the same behavior as proposed in `Fix "foreach" behavior`. Removed "Array was modified outside object and internal position is no longer valid" hack.</li>
  <li>Implemented FR <a href="http://bugs.php.net/67886">#67886</a> (SplPriorityQueue/SplHeap doesn't expose extractFlags nor curruption state).</li>
  <li>Fixed bug <a href="http://bugs.php.net/66405">#66405</a> (RecursiveDirectoryIterator::CURRENT_AS_PATHNAME breaks the RecursiveIterator).</li>
</ul></li>
<li>SQLite3:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70571">#70571</a> (Memory leak in sqlite3_do_callback).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69972">#69972</a> (Use-after-free vulnerability in sqlite3SafetyCheckSickOrOk()).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69897">#69897</a> (segfault when manually constructing SQLite3Result).</li>
  <li>Fixed bug <a href="http://bugs.php.net/68260">#68260</a> (SQLite3Result::fetchArray declares wrong required_num_args).</li>
</ul></li>
<li>Standard:
<ul>
  <li>Fixed count on symbol tables.</li>
  <li>Fixed bug <a href="http://bugs.php.net/70963">#70963</a> (Unserialize shows UNKNOWN in result).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70910">#70910</a> (extract() breaks variable references).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70808">#70808</a> (array_merge_recursive corrupts memory of unset items).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70667">#70667</a> (strtr() causes invalid writes and a crashes).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70668">#70668</a> (array_keys() doesn't respect references when $strict is true).</li>
  <li>Implemented the RFC `Random Functions Throwing Exceptions in PHP 7`.</li>
  <li>Fixed bug <a href="http://bugs.php.net/70487">#70487</a> (pack('x') produces an error).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70342">#70342</a> (changing configuration with ignore_user_abort(true) isn't working).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70295">#70295</a> (Segmentation fault with setrawcookie).</li>
  <li>Fixed bug <a href="http://bugs.php.net/67131">#67131</a> (setcookie() conditional for empty values not met).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70365">#70365</a> (Use-after-free vulnerability in unserialize() with SplObjectStorage).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70366">#70366</a> (Use-after-free vulnerability in unserialize() with SplDoublyLinkedList).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70250">#70250</a> (extract() turns array elements to references).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70211">#70211</a> (php 7 ZEND_HASH_IF_FULL_DO_RESIZE use after free).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70208">#70208</a> (Assert breaking access on objects).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70140">#70140</a> (str_ireplace/php_string_tolower - Arbitrary Code Execution).</li>
  <li>Implemented FR <a href="http://bugs.php.net/70112">#70112</a> (Allow "dirname" to go up various times).</li>
  <li>Fixed bug <a href="http://bugs.php.net/36365">#36365</a> (scandir duplicates file name at every 65535th file).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70096">#70096</a> (Repeated iptcembed() adds superfluous FF bytes).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70018">#70018</a> (exec does not strip all whitespace).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69983">#69983</a> (get_browser fails with user agent of null).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69976">#69976</a> (Unable to parse "all" urls with colon char).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69768">#69768</a> (escapeshell*() doesn't cater to !).</li>
  <li>Fixed bug <a href="http://bugs.php.net/62922">#62922</a> (Truncating entire string should result in string).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69723">#69723</a> (Passing parameters by reference and array_column).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69523">#69523</a> (Cookie name cannot be empty).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69325">#69325</a> (php_copy_file_ex does not pass the argument).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69299">#69299</a> (Regression in array_filter's $flag argument in PHP 7).</li>
  <li>Removed call_user_method() and call_user_method_array() functions.</li>
  <li>Fixed user session handlers (See rfc:session.user.return-value).</li>
  <li>Added intdiv() function.</li>
  <li>Improved precision of log() function for base 2 and 10.</li>
  <li>Remove string category support in setlocale().</li>
  <li>Remove set_magic_quotes_runtime() and its alias magic_quotes_runtime().</li>
  <li>Fixed bug <a href="http://bugs.php.net/65272">#65272</a> (flock() out parameter not set correctly in windows).</li>
  <li>Added preg_replace_callback_array function.</li>
  <li>Deprecated salt option to password_hash.</li>
  <li>Fixed bug <a href="http://bugs.php.net/69686">#69686</a> (password_verify reports back error on PHP7 will null string).</li>
  <li>Added Windows support for getrusage().</li>
  <li>Removed hardcoded limit on number of pipes in proc_open().</li>
</ul></li>
<li>Streams:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70361">#70361</a> (HTTP stream wrapper doesn't close keep-alive connections).</li>
  <li>Fixed bug <a href="http://bugs.php.net/68532">#68532</a> (convert.base64-encode omits padding bytes).</li>
  <li>Removed set_socket_blocking() in favor of its alias stream_set_blocking().</li>
</ul></li>
<li>Tokenizer:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/69430">#69430</a> (token_get_all has new irrecoverable errors).</li>
</ul></li>
<li>XMLReader:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70309">#70309</a> (XmlReader read generates extra output).</li>
</ul></li>
<li>XMLRPC:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70526">#70526</a> (xmlrpc_set_type returns false on success).</li>
</ul></li>
<li>XSL:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70678">#70678</a> (PHP7 returns true when false is expected).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70535">#70535</a> (XSLT: free(): invalid pointer).</li>
  <li>Fixed bug <a href="http://bugs.php.net/69782">#69782</a> (NULL pointer dereference).</li>
  <li>Fixed bug <a href="http://bugs.php.net/64776">#64776</a> (The XSLT extension is not thread safe).</li>
  <li>Removed xsl.security_prefs ini option.</li>
</ul></li>
<li>Zlib:
<ul>
  <li>Added deflate_init(), deflate_add(), inflate_init(), inflate_add() functions allowing incremental/streaming compression/decompression.</li>
</ul></li>
<li>Zip:
<ul>
  <li>Fixed bug <a href="http://bugs.php.net/70322">#70322</a> (ZipArchive::close() doesn't indicate errors).</li>
  <li>Fixed bug <a href="http://bugs.php.net/70350">#70350</a> (ZipArchive::extractTo allows for directory traversal when creating directories). (CVE-2014-9767)</li>
  <li>Added ZipArchive::setCompressionName and ZipArchive::setCompressionIndex methods.</li>
  <li>Update bundled libzip to 1.0.1.</li>
  <li>Fixed bug <a href="http://bugs.php.net/67161">#67161</a> (ZipArchive::getStream() returns NULL for certain file).</li>
</ul></li>
</ul>
<!-- }}} --></section>

    </section><!-- layout-content -->
    

  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

