<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Exceptions - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.exceptions.php">
 <link rel="shorturl" href="http://php.net/exceptions">
 <link rel="alternate" href="http://php.net/exceptions" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/langref.php">
 <link rel="prev" href="http://php.net/manual/en/language.errors.php7.php">
 <link rel="next" href="http://php.net/manual/en/language.exceptions.extending.php">

 <link rel="alternate" href="http://php.net/manual/en/language.exceptions.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.exceptions.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.exceptions.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.exceptions.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.exceptions.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.exceptions.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.exceptions.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.exceptions.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.exceptions.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.exceptions.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.exceptions.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.exceptions.extending.php">
          Extending Exceptions &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.errors.php7.php">
          &laquo; Errors in PHP 7        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.exceptions.php' selected="selected">English</option>
            <option value='pt_BR/language.exceptions.php'>Brazilian Portuguese</option>
            <option value='zh/language.exceptions.php'>Chinese (Simplified)</option>
            <option value='fr/language.exceptions.php'>French</option>
            <option value='de/language.exceptions.php'>German</option>
            <option value='ja/language.exceptions.php'>Japanese</option>
            <option value='ro/language.exceptions.php'>Romanian</option>
            <option value='ru/language.exceptions.php'>Russian</option>
            <option value='es/language.exceptions.php'>Spanish</option>
            <option value='tr/language.exceptions.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.exceptions.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.exceptions">Report a Bug</a>
    </div>
  </div><div id="language.exceptions" class="chapter">
  <h1>Exceptions</h1>
<h2>Table of Contents</h2><ul class="chunklist chunklist_chapter"><li><a href="language.exceptions.extending.php">Extending Exceptions</a></li></ul>

   
  

  <div class="simplesect">
   <p class="para">
    PHP 5 has an exception model similar to that of other programming
    languages.  An exception can be <a href="language.exceptions.php" class="link"><em>throw</em></a>n, and caught (&quot;<a href="language.exceptions.php#language.exceptions.catch" class="link"><em>catch</em></a>ed&quot;) within
    PHP. Code may be surrounded in a <a href="language.exceptions.php" class="link"><em>try</em></a> block, to facilitate the catching
    of potential exceptions. Each <a href="language.exceptions.php" class="link"><em>try</em></a> must have at least one corresponding
    <a href="language.exceptions.php#language.exceptions.catch" class="link"><em>catch</em></a> or <a href="language.exceptions.php#language.exceptions.finally" class="link"><em>finally</em></a> block.
   </p>

   <p class="para">
    The thrown object must be an instance of the
    <a href="class.exception.php" class="classname">Exception</a> class or a subclass of
    <a href="class.exception.php" class="classname">Exception</a>. Trying to throw an object that is not
    will result in a PHP Fatal Error.
   </p>
  </div>

  <div class="simplesect">
   <h3 class="title"><em>catch</em></h3>
   <p class="para">
    Multiple <a href="language.exceptions.php#language.exceptions.catch" class="link"><em>catch</em></a> blocks can be used to catch different classes of
    exceptions. Normal execution (when no exception is thrown within the <a href="language.exceptions.php" class="link"><em>try</em></a>
    block) will continue after that last <a href="language.exceptions.php#language.exceptions.catch" class="link"><em>catch</em></a> block defined in sequence.
    Exceptions can be <a href="language.exceptions.php" class="link"><em>throw</em></a>n (or re-thrown) within a <a href="language.exceptions.php#language.exceptions.catch" class="link"><em>catch</em></a> block.
   </p>
   <p class="para">
    When an exception is thrown, code following the statement will not be
    executed, and PHP will attempt to find the first matching <a href="language.exceptions.php#language.exceptions.catch" class="link"><em>catch</em></a> block.
    If an exception is not caught, a PHP Fatal Error will be issued with an
    &quot;<em>Uncaught Exception ...</em>&quot; message, unless a handler has
    been defined with <span class="function"><a href="function.set-exception-handler.php" class="function">set_exception_handler()</a></span>.
   </p>
   <p class="para">
    In PHP 7.1 and later, a <a href="language.exceptions.php#language.exceptions.catch" class="link"><em>catch</em></a> block may specify multiple exceptions
    using the pipe (<em>|</em>) character. This is useful for when
    different exceptions from different class hierarchies are handled the
    same.
   </p>
  </div>

  <div class="simplesect">
   <h3 class="title"><em>finally</em></h3>
   <p class="para">
    In PHP 5.5 and later, a <a href="language.exceptions.php#language.exceptions.finally" class="link"><em>finally</em></a> block may also be specified after or
    instead of <a href="language.exceptions.php#language.exceptions.catch" class="link"><em>catch</em></a> blocks. Code within the <a href="language.exceptions.php#language.exceptions.finally" class="link"><em>finally</em></a> block will always be
    executed after the <a href="language.exceptions.php" class="link"><em>try</em></a> and <a href="language.exceptions.php#language.exceptions.catch" class="link"><em>catch</em></a> blocks, regardless of whether an
    exception has been thrown, and before normal execution resumes.
   </p>
  </div>

  <div class="simplesect">
   <h3 class="title">Notes</h3>

   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <p class="para">
     Internal PHP functions mainly use
     <a href="errorfunc.configuration.php#ini.error-reporting" class="link">Error reporting</a>, only modern
     <a href="language.oop5.php" class="link">Object oriented</a>
     extensions use exceptions. However, errors can be simply translated to
     exceptions with <a href="class.errorexception.php" class="link">ErrorException</a>.
    </p>
   </p></blockquote>
   <div class="tip"><strong class="tip">Tip</strong>
    <p class="para">
     The <a href="intro.spl.php" class="link">Standard PHP Library (SPL)</a> provides
     a good number of <a href="spl.exceptions.php" class="link">built-in
     exceptions</a>.
    </p>
   </div>
  </div>

  <div class="simplesect">
   <h3 class="title">Examples</h3>

   <div class="example" id="example-280">
    <p><strong>Example #3 Throwing an Exception</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">inverse</span><span style="color: #007700">(</span><span style="color: #0000BB">$x</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(!</span><span style="color: #0000BB">$x</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;throw&nbsp;new&nbsp;</span><span style="color: #0000BB">Exception</span><span style="color: #007700">(</span><span style="color: #DD0000">'Division&nbsp;by&nbsp;zero.'</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">/</span><span style="color: #0000BB">$x</span><span style="color: #007700">;<br />}<br /><br />try&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #0000BB">inverse</span><span style="color: #007700">(</span><span style="color: #0000BB">5</span><span style="color: #007700">)&nbsp;.&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #0000BB">inverse</span><span style="color: #007700">(</span><span style="color: #0000BB">0</span><span style="color: #007700">)&nbsp;.&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br />}&nbsp;catch&nbsp;(</span><span style="color: #0000BB">Exception&nbsp;$e</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">'Caught&nbsp;exception:&nbsp;'</span><span style="color: #007700">,&nbsp;&nbsp;</span><span style="color: #0000BB">$e</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">getMessage</span><span style="color: #007700">(),&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #FF8000">//&nbsp;Continue&nbsp;execution<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"Hello&nbsp;World\n"</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

    <div class="example-contents"><p>The above example will output:</p></div>
    <div class="example-contents screen">
<div class="cdata"><pre>
0.2
Caught exception: Division by zero.
Hello World
</pre></div>
    </div>
   </div>
   <div class="example" id="example-281">
    <p><strong>Example #4 Exception handling with a <em>finally</em> block</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">inverse</span><span style="color: #007700">(</span><span style="color: #0000BB">$x</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(!</span><span style="color: #0000BB">$x</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;throw&nbsp;new&nbsp;</span><span style="color: #0000BB">Exception</span><span style="color: #007700">(</span><span style="color: #DD0000">'Division&nbsp;by&nbsp;zero.'</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">/</span><span style="color: #0000BB">$x</span><span style="color: #007700">;<br />}<br /><br />try&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #0000BB">inverse</span><span style="color: #007700">(</span><span style="color: #0000BB">5</span><span style="color: #007700">)&nbsp;.&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br />}&nbsp;catch&nbsp;(</span><span style="color: #0000BB">Exception&nbsp;$e</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">'Caught&nbsp;exception:&nbsp;'</span><span style="color: #007700">,&nbsp;&nbsp;</span><span style="color: #0000BB">$e</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">getMessage</span><span style="color: #007700">(),&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br />}&nbsp;</span><span style="color: #0000BB">finally&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"First&nbsp;finally.\n"</span><span style="color: #007700">;<br />}<br /><br />try&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #0000BB">inverse</span><span style="color: #007700">(</span><span style="color: #0000BB">0</span><span style="color: #007700">)&nbsp;.&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br />}&nbsp;catch&nbsp;(</span><span style="color: #0000BB">Exception&nbsp;$e</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">'Caught&nbsp;exception:&nbsp;'</span><span style="color: #007700">,&nbsp;&nbsp;</span><span style="color: #0000BB">$e</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">getMessage</span><span style="color: #007700">(),&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br />}&nbsp;</span><span style="color: #0000BB">finally&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"Second&nbsp;finally.\n"</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #FF8000">//&nbsp;Continue&nbsp;execution<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"Hello&nbsp;World\n"</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

    <div class="example-contents"><p>The above example will output:</p></div>
    <div class="example-contents screen">
<div class="cdata"><pre>
0.2
First finally.
Caught exception: Division by zero.
Second finally.
Hello World
</pre></div>
    </div>
   </div>
   <div class="example" id="example-282">
    <p><strong>Example #5 Nested Exception</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /><br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">MyException&nbsp;</span><span style="color: #007700">extends&nbsp;</span><span style="color: #0000BB">Exception&nbsp;</span><span style="color: #007700">{&nbsp;}<br /><br />class&nbsp;</span><span style="color: #0000BB">Test&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">testing</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;try&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;try&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;throw&nbsp;new&nbsp;</span><span style="color: #0000BB">MyException</span><span style="color: #007700">(</span><span style="color: #DD0000">'foo!'</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}&nbsp;catch&nbsp;(</span><span style="color: #0000BB">MyException&nbsp;$e</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;rethrow&nbsp;it<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">throw&nbsp;</span><span style="color: #0000BB">$e</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}&nbsp;catch&nbsp;(</span><span style="color: #0000BB">Exception&nbsp;$e</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$e</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">getMessage</span><span style="color: #007700">());<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br /></span><span style="color: #0000BB">$foo&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">Test</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$foo</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">testing</span><span style="color: #007700">();<br /><br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

    <div class="example-contents"><p>The above example will output:</p></div>
    <div class="example-contents screen">
<div class="cdata"><pre>
string(4) &quot;foo!&quot;
</pre></div>
    </div>
   </div>
   <div class="example" id="example-283">
    <p><strong>Example #6 Multi catch exception handling</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /><br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">MyException&nbsp;</span><span style="color: #007700">extends&nbsp;</span><span style="color: #0000BB">Exception&nbsp;</span><span style="color: #007700">{&nbsp;}<br /><br />class&nbsp;</span><span style="color: #0000BB">MyOtherException&nbsp;</span><span style="color: #007700">extends&nbsp;</span><span style="color: #0000BB">Exception&nbsp;</span><span style="color: #007700">{&nbsp;}<br /><br />class&nbsp;</span><span style="color: #0000BB">Test&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">testing</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;try&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;throw&nbsp;new&nbsp;</span><span style="color: #0000BB">MyException</span><span style="color: #007700">();<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}&nbsp;catch&nbsp;(</span><span style="color: #0000BB">MyException&nbsp;</span><span style="color: #007700">|&nbsp;</span><span style="color: #0000BB">MyOtherException&nbsp;$e</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">get_class</span><span style="color: #007700">(</span><span style="color: #0000BB">$e</span><span style="color: #007700">));<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br /></span><span style="color: #0000BB">$foo&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">Test</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$foo</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">testing</span><span style="color: #007700">();<br /><br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

    <div class="example-contents"><p>The above example will output:</p></div>
    <div class="example-contents screen">
<div class="cdata"><pre>
string(11) &quot;MyException&quot;
</pre></div>
    </div>
   </div>
  </div>

 </div>

<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.exceptions&amp;redirect=http://php.net/manual/en/language.exceptions.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">30 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="97963">  <div class="votes">
    <div id="Vu97963">
    <a href="/manual/vote-note.php?id=97963&amp;page=language.exceptions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd97963">
    <a href="/manual/vote-note.php?id=97963&amp;page=language.exceptions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V97963" title="77% like this...">
    195
    </div>
  </div>
  <a href="#97963" class="name">
  <strong class="user"><em>zmunoz at gmail dot com</em></strong></a><a class="genanchor" href="#97963"> &para;</a><div class="date" title="2010-05-18 01:05"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom97963">
<div class="phpcode"><code><span class="html">
When catching an exception inside a namespace it is important that you escape to the global space:<br /><br /><span class="default">&lt;?php<br /> </span><span class="keyword">namespace </span><span class="default">SomeNamespace</span><span class="keyword">;<br /><br /> class </span><span class="default">SomeClass </span><span class="keyword">{<br /><br />&nbsp; function </span><span class="default">SomeFunction</span><span class="keyword">() {<br />&nbsp;&nbsp; try {<br />&nbsp; &nbsp; throw new </span><span class="default">Exception</span><span class="keyword">(</span><span class="string">'Some Error Message'</span><span class="keyword">);<br />&nbsp;&nbsp; } catch (\</span><span class="default">Exception $e</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$e</span><span class="keyword">-&gt;</span><span class="default">getMessage</span><span class="keyword">());<br />&nbsp;&nbsp; }<br />&nbsp; }<br /><br /> }<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119726">  <div class="votes">
    <div id="Vu119726">
    <a href="/manual/vote-note.php?id=119726&amp;page=language.exceptions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119726">
    <a href="/manual/vote-note.php?id=119726&amp;page=language.exceptions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119726" title="76% like this...">
    25
    </div>
  </div>
  <a href="#119726" class="name">
  <strong class="user"><em>ohcc at 163 dot com</em></strong></a><a class="genanchor" href="#119726"> &para;</a><div class="date" title="2016-08-11 09:25"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119726">
<div class="phpcode"><code><span class="html">
If a TRY has a FINALLY, a RETURN either in the TRY or a CATCH won't terminate the script. Code in the same block after the RETURN will not be executed, and the RETURN itself will be "copied" to the bottom of the FINALLY block to be executed.<br /><br />a RETURN in the FINALLY block will override value(s) returned from the TRY or a CATCH block.<br /><br />An EXIT or a DIE always terminate the script after themselves.<br /><br />code 1<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">function </span><span class="default">foo</span><span class="keyword">(){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$bar </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; try{<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">Exception</span><span class="keyword">(</span><span class="string">'I am Wu Xiancheng.'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }catch(</span><span class="default">Exception $e</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$bar</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$bar</span><span class="keyword">--; </span><span class="comment">// this line will be ignored<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">}finally{<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$bar</span><span class="keyword">++;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; echo </span><span class="default">foo</span><span class="keyword">(); </span><span class="comment">// 2<br /></span><span class="default">?&gt;<br /></span><br />code 2<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">function </span><span class="default">foo</span><span class="keyword">(){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$bar </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; try{<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">Exception</span><span class="keyword">(</span><span class="string">'I am Wu Xiancheng.'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }catch(</span><span class="default">Exception $e</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$bar</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$bar</span><span class="keyword">--; </span><span class="comment">// this line will be ignored<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">}finally{<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$bar</span><span class="keyword">++;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$bar</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; echo </span><span class="default">foo</span><span class="keyword">(); </span><span class="comment">//2 <br /></span><span class="default">?&gt;<br /></span><br />code 3<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">function </span><span class="default">foo</span><span class="keyword">(){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$bar </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; try{<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">Exception</span><span class="keyword">(</span><span class="string">'I am Wu Xiancheng.'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }catch(</span><span class="default">Exception $e</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$bar</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$bar</span><span class="keyword">--; </span><span class="comment">// this line will be ignored<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">}finally{<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">100</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; echo </span><span class="default">foo</span><span class="keyword">(); </span><span class="comment">//100<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121339">  <div class="votes">
    <div id="Vu121339">
    <a href="/manual/vote-note.php?id=121339&amp;page=language.exceptions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121339">
    <a href="/manual/vote-note.php?id=121339&amp;page=language.exceptions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121339" title="80% like this...">
    3
    </div>
  </div>
  <a href="#121339" class="name">
  <strong class="user"><em>jenshausdorf at gmail dot com</em></strong></a><a class="genanchor" href="#121339"> &para;</a><div class="date" title="2017-07-08 09:10"><strong>5 months ago</strong></div>
  <div class="text" id="Hcom121339">
<div class="phpcode"><code><span class="html">
Please don't do something like this:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">try {<br />&nbsp; &nbsp; </span><span class="comment">// experimental stuff to check whether something works<br /></span><span class="keyword">} catch(\</span><span class="default">Throwable $e</span><span class="keyword">) {<br />&nbsp; &nbsp; return </span><span class="default">false</span><span class="keyword">;<br />} finally {<br />&nbsp; &nbsp; return </span><span class="default">true</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />Well, it is allowed syntax, it is bad practice, because once it hits the exception block, finally won't be called(because it exits the scope). Finally was invented to prevent duplicated code after one operation, regardless whether it was successful(for example closing the connection to a server). This way, you don't have any duplicated code. So you don't need to use this structure.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121228">  <div class="votes">
    <div id="Vu121228">
    <a href="/manual/vote-note.php?id=121228&amp;page=language.exceptions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121228">
    <a href="/manual/vote-note.php?id=121228&amp;page=language.exceptions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121228" title="80% like this...">
    3
    </div>
  </div>
  <a href="#121228" class="name">
  <strong class="user"><em>christof+php[AT]insypro.com</em></strong></a><a class="genanchor" href="#121228"> &para;</a><div class="date" title="2017-06-15 10:12"><strong>5 months ago</strong></div>
  <div class="text" id="Hcom121228">
<div class="phpcode"><code><span class="html">
In case your E_WARNING type of errors aren't catchable with try/catch you can change them to another type of error like this:<br /><br /><span class="default">&lt;?php <br />&nbsp; &nbsp; set_error_handler</span><span class="keyword">(function(</span><span class="default">$errno</span><span class="keyword">, </span><span class="default">$errstr</span><span class="keyword">, </span><span class="default">$errfile</span><span class="keyword">, </span><span class="default">$errline</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">$errno </span><span class="keyword">=== </span><span class="default">E_WARNING</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// make it more serious than a warning so it can be caught<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">trigger_error</span><span class="keyword">(</span><span class="default">$errstr</span><span class="keyword">, </span><span class="default">E_ERROR</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">true</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// fallback to default php error handler<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; });<br /><br />&nbsp; &nbsp; try {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// code that might result in a E_WARNING<br />&nbsp; &nbsp; </span><span class="keyword">} catch(</span><span class="default">Exception $e</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// code to handle the E_WARNING (it's actually changed to E_ERROR at this point)<br />&nbsp; &nbsp; </span><span class="keyword">} finally {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">restore_error_handler</span><span class="keyword">();<br />&nbsp; &nbsp; }<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="91159">  <div class="votes">
    <div id="Vu91159">
    <a href="/manual/vote-note.php?id=91159&amp;page=language.exceptions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd91159">
    <a href="/manual/vote-note.php?id=91159&amp;page=language.exceptions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V91159" title="68% like this...">
    68
    </div>
  </div>
  <a href="#91159" class="name">
  <strong class="user"><em>ask at nilpo dot com</em></strong></a><a class="genanchor" href="#91159"> &para;</a><div class="date" title="2009-05-27 12:19"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom91159">
<div class="phpcode"><code><span class="html">
If you intend on creating a lot of custom exceptions, you may find this code useful.&nbsp; I've created an interface and an abstract exception class that ensures that all parts of the built-in Exception class are preserved in child classes.&nbsp; It also properly pushes all information back to the parent constructor ensuring that nothing is lost.&nbsp; This allows you to quickly create new exceptions on the fly.&nbsp; It also overrides the default __toString method with a more thorough one.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">interface </span><span class="default">IException<br /></span><span class="keyword">{<br />&nbsp; &nbsp; </span><span class="comment">/* Protected methods inherited from Exception class */<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">getMessage</span><span class="keyword">();&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="comment">// Exception message <br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">getCode</span><span class="keyword">();&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// User-defined Exception code<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">getFile</span><span class="keyword">();&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Source filename<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">getLine</span><span class="keyword">();&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Source line<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">getTrace</span><span class="keyword">();&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="comment">// An array of the backtrace()<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">getTraceAsString</span><span class="keyword">();&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="comment">// Formated string of trace<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; /* Overrideable methods inherited from Exception class */<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">__toString</span><span class="keyword">();&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="comment">// formated string for display<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$message </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">, </span><span class="default">$code </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">);<br />}<br /><br />abstract class </span><span class="default">CustomException </span><span class="keyword">extends </span><span class="default">Exception </span><span class="keyword">implements </span><span class="default">IException<br /></span><span class="keyword">{<br />&nbsp; &nbsp; protected </span><span class="default">$message </span><span class="keyword">= </span><span class="string">'Unknown exception'</span><span class="keyword">;&nbsp; &nbsp;&nbsp; </span><span class="comment">// Exception message<br />&nbsp; &nbsp; </span><span class="keyword">private&nbsp;&nbsp; </span><span class="default">$string</span><span class="keyword">;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Unknown<br />&nbsp; &nbsp; </span><span class="keyword">protected </span><span class="default">$code&nbsp; &nbsp; </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="comment">// User-defined exception code<br />&nbsp; &nbsp; </span><span class="keyword">protected </span><span class="default">$file</span><span class="keyword">;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Source filename of exception<br />&nbsp; &nbsp; </span><span class="keyword">protected </span><span class="default">$line</span><span class="keyword">;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Source line of exception<br />&nbsp; &nbsp; </span><span class="keyword">private&nbsp;&nbsp; </span><span class="default">$trace</span><span class="keyword">;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="comment">// Unknown<br /><br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$message </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">, </span><span class="default">$code </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (!</span><span class="default">$message</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">$this</span><span class="keyword">(</span><span class="string">'Unknown '</span><span class="keyword">. </span><span class="default">get_class</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">));<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">parent</span><span class="keyword">::</span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$message</span><span class="keyword">, </span><span class="default">$code</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">__toString</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">get_class</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">) . </span><span class="string">" '</span><span class="keyword">{</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">message</span><span class="keyword">}</span><span class="string">' in </span><span class="keyword">{</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">file</span><span class="keyword">}</span><span class="string">(</span><span class="keyword">{</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">line</span><span class="keyword">}</span><span class="string">)\n"<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">. </span><span class="string">"</span><span class="keyword">{</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">getTraceAsString</span><span class="keyword">()}</span><span class="string">"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />Now you can create new exceptions in one line:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">TestException </span><span class="keyword">extends </span><span class="default">CustomException </span><span class="keyword">{}<br /></span><span class="default">?&gt;<br /></span><br />Here's a test that shows that all information is properly preserved throughout the backtrace.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">exceptionTest</span><span class="keyword">()<br />{<br />&nbsp; &nbsp; try {<br />&nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">TestException</span><span class="keyword">();<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; catch (</span><span class="default">TestException $e</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Caught TestException ('</span><span class="keyword">{</span><span class="default">$e</span><span class="keyword">-&gt;</span><span class="default">getMessage</span><span class="keyword">()}</span><span class="string">')\n</span><span class="keyword">{</span><span class="default">$e</span><span class="keyword">}</span><span class="string">\n"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; catch (</span><span class="default">Exception $e</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Caught Exception ('</span><span class="keyword">{</span><span class="default">$e</span><span class="keyword">-&gt;</span><span class="default">getMessage</span><span class="keyword">()}</span><span class="string">')\n</span><span class="keyword">{</span><span class="default">$e</span><span class="keyword">}</span><span class="string">\n"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />echo </span><span class="string">'&lt;pre&gt;' </span><span class="keyword">. </span><span class="default">exceptionTest</span><span class="keyword">() . </span><span class="string">'&lt;/pre&gt;'</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />Here's a sample output:<br /><br />Caught TestException ('Unknown TestException')<br />TestException 'Unknown TestException' in C:\xampp\htdocs\CustomException\CustomException.php(31)<br />#0 C:\xampp\htdocs\CustomException\ExceptionTest.php(19): CustomException-&gt;__construct()<br />#1 C:\xampp\htdocs\CustomException\ExceptionTest.php(43): exceptionTest()<br />#2 {main}</span>
</code></div>
  </div>
 </div>
  <div class="note" id="103819">  <div class="votes">
    <div id="Vu103819">
    <a href="/manual/vote-note.php?id=103819&amp;page=language.exceptions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd103819">
    <a href="/manual/vote-note.php?id=103819&amp;page=language.exceptions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V103819" title="63% like this...">
    70
    </div>
  </div>
  <a href="#103819" class="name">
  <strong class="user"><em>Johan</em></strong></a><a class="genanchor" href="#103819"> &para;</a><div class="date" title="2011-05-05 01:18"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom103819">
<div class="phpcode"><code><span class="html">
Custom error handling on entire pages can avoid half rendered pages for the users:<br /><br /><span class="default">&lt;?php<br />ob_start</span><span class="keyword">();<br />try {<br />&nbsp; &nbsp; </span><span class="comment">/*contains all page logic <br />&nbsp; &nbsp; and throws error if needed*/<br />&nbsp; &nbsp; </span><span class="keyword">...<br />} catch (</span><span class="default">Exception $e</span><span class="keyword">) {<br />&nbsp; </span><span class="default">ob_end_clean</span><span class="keyword">();<br />&nbsp; </span><span class="default">displayErrorPage</span><span class="keyword">(</span><span class="default">$e</span><span class="keyword">-&gt;</span><span class="default">getMessage</span><span class="keyword">());<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118056">  <div class="votes">
    <div id="Vu118056">
    <a href="/manual/vote-note.php?id=118056&amp;page=language.exceptions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118056">
    <a href="/manual/vote-note.php?id=118056&amp;page=language.exceptions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118056" title="68% like this...">
    14
    </div>
  </div>
  <a href="#118056" class="name">
  <strong class="user"><em>hweidmann at online dot de</em></strong></a><a class="genanchor" href="#118056"> &para;</a><div class="date" title="2015-09-26 08:20"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom118056">
<div class="phpcode"><code><span class="html">
catch doesn't check for the existence of the Exception class, so avoid typo.<br /><br /><span class="default">&lt;?php<br />&nbsp;&nbsp; </span><span class="keyword">class </span><span class="default">MyException </span><span class="keyword">extends </span><span class="default">Exception<br />&nbsp;&nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; ...<br />&nbsp;&nbsp; }<br /><br />&nbsp;&nbsp; try<br />&nbsp;&nbsp; {<br />&nbsp; &nbsp; &nbsp; throw new </span><span class="default">MyException</span><span class="keyword">(...);<br />&nbsp;&nbsp; }<br />&nbsp;&nbsp; catch (</span><span class="default">MuException $e</span><span class="keyword">) </span><span class="comment">// &lt;--- typo<br />&nbsp;&nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; ...<br />&nbsp;&nbsp; }<br /></span><span class="default">?&gt;</span> <br /><br />You WON'T get<br />&nbsp;&nbsp; Fatal error: Class MuException could not be loaded ...<br /><br />You WILL get<br />&nbsp;&nbsp; Fatal error: Uncaught exception 'MyException' ...</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114207">  <div class="votes">
    <div id="Vu114207">
    <a href="/manual/vote-note.php?id=114207&amp;page=language.exceptions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114207">
    <a href="/manual/vote-note.php?id=114207&amp;page=language.exceptions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114207" title="65% like this...">
    27
    </div>
  </div>
  <a href="#114207" class="name">
  <strong class="user"><em>php at marcuspope dot com</em></strong></a><a class="genanchor" href="#114207"> &para;</a><div class="date" title="2014-01-24 05:42"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114207">
<div class="phpcode"><code><span class="html">
Using a return statement inside a finally block will override any other return statement or thrown exception from the try block and all defined catch blocks.&nbsp;&nbsp; Code execution in the parent stack will continue as if the exception was never thrown.&nbsp; <br /><br />Frankly this is a good design decision because it means I can optionally dismiss all thrown exceptions from 1 or more catch blocks in one place, without having to nest my whole try block inside an additional (and otherwise needless) try/catch block.<br /><br />This is the same behavior as Java, whereas C# throws a compile time error when a return statement exists inside a finally block.&nbsp; So I figured it was worth pointing out to PHP devs who may not have any exposure to finally blocks or how other languages do it.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">asdf</span><span class="keyword">()<br />{<br />&nbsp; &nbsp; try {<br />&nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">Exception</span><span class="keyword">(</span><span class="string">'error'</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; catch(</span><span class="default">Exception $e</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"An error occurred"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; throw </span><span class="default">$e</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; finally {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//This overrides the exception as if it were never thrown<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">return </span><span class="string">"\nException erased"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />try {<br />&nbsp; &nbsp; echo </span><span class="default">asdf</span><span class="keyword">();<br />}<br />catch(</span><span class="default">Exception $e</span><span class="keyword">) {<br />&nbsp; &nbsp; echo </span><span class="string">"\nResult: " </span><span class="keyword">. </span><span class="default">$e</span><span class="keyword">-&gt;</span><span class="default">getMessage</span><span class="keyword">();<br />}<br /></span><span class="default">?&gt;<br /></span><br />The output from above will look like this:<br /><br />&nbsp; &nbsp; An error occurred<br />&nbsp; &nbsp; Exception erased<br /><br />Without the return statement in the finally block it would look like this:<br /><br />&nbsp; &nbsp; An error occurred<br />&nbsp; &nbsp; Result: error</span>
</code></div>
  </div>
 </div>
  <div class="note" id="86476">  <div class="votes">
    <div id="Vu86476">
    <a href="/manual/vote-note.php?id=86476&amp;page=language.exceptions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86476">
    <a href="/manual/vote-note.php?id=86476&amp;page=language.exceptions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86476" title="64% like this...">
    14
    </div>
  </div>
  <a href="#86476" class="name">
  <strong class="user"><em>Shot (Piotr Szotkowski)</em></strong></a><a class="genanchor" href="#86476"> &para;</a><div class="date" title="2008-10-21 12:13"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86476">
<div class="phpcode"><code><span class="html">
‘Normal execution (when no exception is thrown within the try block, *or when a catch matching the thrown exception’s class is not present*) will continue after that last catch block defined in sequence.’<br /><br />‘If an exception is not caught, a PHP Fatal Error will be issued with an “Uncaught Exception …” message, unless a handler has been defined with set_exception_handler().’<br /><br />These two sentences seem a bit contradicting about what happens ‘when a catch matching the thrown exception’s class is not present’ (and the second sentence is actually correct).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="68697">  <div class="votes">
    <div id="Vu68697">
    <a href="/manual/vote-note.php?id=68697&amp;page=language.exceptions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd68697">
    <a href="/manual/vote-note.php?id=68697&amp;page=language.exceptions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V68697" title="63% like this...">
    18
    </div>
  </div>
  <a href="#68697" class="name">
  <strong class="user"><em>jazfresh at hotmail.com</em></strong></a><a class="genanchor" href="#68697"> &para;</a><div class="date" title="2006-08-07 10:18"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom68697">
<div class="phpcode"><code><span class="html">
Sometimes you want a single catch() to catch multiple types of Exception. In a language like Python, you can specify multiple types in a catch(), but in PHP you can only specify one. This can be annoying when you want handle many different Exceptions with the same catch() block.<br /><br />However, you can replicate the functionality somewhat, because catch(&lt;classname&gt; $var) will match the given &lt;classname&gt; *or any of it's sub-classes*.<br /><br />For example:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">DisplayException </span><span class="keyword">extends </span><span class="default">Exception </span><span class="keyword">{};<br />class </span><span class="default">FileException </span><span class="keyword">extends </span><span class="default">Exception </span><span class="keyword">{};<br />class </span><span class="default">AccessControl </span><span class="keyword">extends </span><span class="default">FileException </span><span class="keyword">{}; </span><span class="comment">// Sub-class of FileException<br /></span><span class="keyword">class </span><span class="default">IOError </span><span class="keyword">extends </span><span class="default">FileException </span><span class="keyword">{}; </span><span class="comment">// Sub-class of FileException<br /><br /></span><span class="keyword">try {<br />&nbsp; if(!</span><span class="default">is_readable</span><span class="keyword">(</span><span class="default">$somefile</span><span class="keyword">))<br />&nbsp; &nbsp;&nbsp; throw new </span><span class="default">IOError</span><span class="keyword">(</span><span class="string">"File is not readable!"</span><span class="keyword">);<br />&nbsp; if(!</span><span class="default">user_has_access_to_file</span><span class="keyword">(</span><span class="default">$someuser</span><span class="keyword">, </span><span class="default">$somefile</span><span class="keyword">))<br />&nbsp; &nbsp;&nbsp; throw new </span><span class="default">AccessControl</span><span class="keyword">(</span><span class="string">"Permission denied!"</span><span class="keyword">);<br />&nbsp; if(!</span><span class="default">display_file</span><span class="keyword">(</span><span class="default">$somefile</span><span class="keyword">))<br />&nbsp; &nbsp;&nbsp; throw new </span><span class="default">DisplayException</span><span class="keyword">(</span><span class="string">"Couldn't display file!"</span><span class="keyword">);<br /><br />} catch (</span><span class="default">FileException $e</span><span class="keyword">) {<br />&nbsp; </span><span class="comment">// This block will catch FileException, AccessControl or IOError exceptions, but not Exceptions or DisplayExceptions.<br />&nbsp; </span><span class="keyword">echo </span><span class="string">"File error: "</span><span class="keyword">.</span><span class="default">$e</span><span class="keyword">-&gt;</span><span class="default">getMessage</span><span class="keyword">();<br />&nbsp; exit(</span><span class="default">1</span><span class="keyword">);<br />}<br /></span><span class="default">?&gt;<br /></span><br />Corollary: If you want to catch *any* exception, no matter what the type, just use "catch(Exception $var)", because all exceptions are sub-classes of the built-in Exception.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113328">  <div class="votes">
    <div id="Vu113328">
    <a href="/manual/vote-note.php?id=113328&amp;page=language.exceptions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113328">
    <a href="/manual/vote-note.php?id=113328&amp;page=language.exceptions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113328" title="60% like this...">
    11
    </div>
  </div>
  <a href="#113328" class="name">
  <strong class="user"><em>jim at anderos dot com</em></strong></a><a class="genanchor" href="#113328"> &para;</a><div class="date" title="2013-09-27 05:22"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113328">
<div class="phpcode"><code><span class="html">
If you are using a namespace, you must indicate the global namespace when using Exceptions.<br /><span class="default">&lt;?php<br /></span><span class="keyword">namespace </span><span class="default">alpha</span><span class="keyword">;<br />function </span><span class="default">foo</span><span class="keyword">(){<br />&nbsp; &nbsp; throw new \</span><span class="default">Exception</span><span class="keyword">(</span><span class="string">"Something is wrong!"</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="comment">// throw new Exception(""); will fail<br /></span><span class="keyword">}<br /><br />try {<br />&nbsp; &nbsp; </span><span class="default">foo</span><span class="keyword">();<br />} catch( \</span><span class="default">Exception $e </span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="comment">// catch( Exception $e ) will give no warning, but will not catch Exception<br />&nbsp; &nbsp; </span><span class="keyword">echo </span><span class="string">"ERROR: </span><span class="default">$e</span><span class="string">"</span><span class="keyword">;<br />}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="112507">  <div class="votes">
    <div id="Vu112507">
    <a href="/manual/vote-note.php?id=112507&amp;page=language.exceptions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd112507">
    <a href="/manual/vote-note.php?id=112507&amp;page=language.exceptions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V112507" title="59% like this...">
    15
    </div>
  </div>
  <a href="#112507" class="name">
  <strong class="user"><em>Edu</em></strong></a><a class="genanchor" href="#112507"> &para;</a><div class="date" title="2013-06-24 06:13"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom112507">
<div class="phpcode"><code><span class="html">
The "finally" block can change the exception that has been throw by the catch block.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">try{<br />&nbsp; &nbsp; &nbsp; &nbsp; try {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw new \</span><span class="default">Exception</span><span class="keyword">(</span><span class="string">"Hello"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; } catch(\</span><span class="default">Exception $e</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">$e</span><span class="keyword">-&gt;</span><span class="default">getMessage</span><span class="keyword">().</span><span class="string">" catch in\n"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw </span><span class="default">$e</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; } finally {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">$e</span><span class="keyword">-&gt;</span><span class="default">getMessage</span><span class="keyword">().</span><span class="string">" finally \n"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw new \</span><span class="default">Exception</span><span class="keyword">(</span><span class="string">"Bye"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />} catch (\</span><span class="default">Exception $e</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">$e</span><span class="keyword">-&gt;</span><span class="default">getMessage</span><span class="keyword">().</span><span class="string">" catch out\n"</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />The output is:<br /><br />Hello catch in<br />Hello finally <br />Bye catch out</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118280">  <div class="votes">
    <div id="Vu118280">
    <a href="/manual/vote-note.php?id=118280&amp;page=language.exceptions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118280">
    <a href="/manual/vote-note.php?id=118280&amp;page=language.exceptions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118280" title="60% like this...">
    6
    </div>
  </div>
  <a href="#118280" class="name">
  <strong class="user"><em>ohcc at 163 dot com</em></strong></a><a class="genanchor" href="#118280"> &para;</a><div class="date" title="2015-11-07 05:40"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom118280">
<div class="phpcode"><code><span class="html">
Type declarations will trigger Uncaught TypeError when a different type is passed. And it cannot be caught with the Exception class.<br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">function </span><span class="default">xc</span><span class="keyword">(array </span><span class="default">$a</span><span class="keyword">){&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; }&nbsp; &nbsp; <br />&nbsp; &nbsp; try{<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">xc</span><span class="keyword">(</span><span class="default">4</span><span class="keyword">);<br />&nbsp; &nbsp; }catch (</span><span class="default">Exception $e</span><span class="keyword">){ </span><span class="comment">// failed to catch it<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">echo </span><span class="default">$e</span><span class="keyword">-&gt;</span><span class="default">getMessage</span><span class="keyword">();<br />&nbsp; &nbsp; }<br /></span><span class="default">?&gt;<br /></span><br />You should use TypeError instead for PHP 7+,<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">function </span><span class="default">xc</span><span class="keyword">(array </span><span class="default">$a</span><span class="keyword">){&nbsp; &nbsp; <br />&nbsp; &nbsp; }&nbsp; &nbsp; <br />&nbsp; &nbsp; try{<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">xc</span><span class="keyword">(</span><span class="default">4</span><span class="keyword">);<br />&nbsp; &nbsp; }catch (</span><span class="default">TypeError $e</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">$e</span><span class="keyword">-&gt;</span><span class="default">getMessage</span><span class="keyword">();<br />&nbsp; &nbsp; }<br /></span><span class="default">?&gt;<br /></span><br />In php version prior to 7.0, you should translate Catchable fatal errors to an exception and then catch it.<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">function </span><span class="default">exceptionErrorHandler</span><span class="keyword">(</span><span class="default">$errNumber</span><span class="keyword">, </span><span class="default">$errStr</span><span class="keyword">, </span><span class="default">$errFile</span><span class="keyword">, </span><span class="default">$errLine </span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">ErrorException</span><span class="keyword">(</span><span class="default">$errStr</span><span class="keyword">, </span><span class="default">0</span><span class="keyword">, </span><span class="default">$errNumber</span><span class="keyword">, </span><span class="default">$errFile</span><span class="keyword">, </span><span class="default">$errLine</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; </span><span class="default">set_error_handler</span><span class="keyword">(</span><span class="string">'exceptionErrorHandler'</span><span class="keyword">);<br />&nbsp; &nbsp; function </span><span class="default">s</span><span class="keyword">(array </span><span class="default">$a</span><span class="keyword">){&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; try{<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">s</span><span class="keyword">(</span><span class="default">4</span><span class="keyword">);<br />&nbsp; &nbsp; }catch (</span><span class="default">Exception $e</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">$e</span><span class="keyword">-&gt;</span><span class="default">getMessage</span><span class="keyword">();<br />&nbsp; &nbsp; }<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="112527">  <div class="votes">
    <div id="Vu112527">
    <a href="/manual/vote-note.php?id=112527&amp;page=language.exceptions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd112527">
    <a href="/manual/vote-note.php?id=112527&amp;page=language.exceptions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V112527" title="58% like this...">
    13
    </div>
  </div>
  <a href="#112527" class="name">
  <strong class="user"><em>sander at rotorsolutions dot nl</em></strong></a><a class="genanchor" href="#112527"> &para;</a><div class="date" title="2013-06-26 02:05"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom112527">
<div class="phpcode"><code><span class="html">
Just an example why finally blocks are usefull (5.5)<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="comment">//without catch<br /></span><span class="keyword">function </span><span class="default">example</span><span class="keyword">() {<br />&nbsp; try {<br />&nbsp; &nbsp; </span><span class="comment">//do something that throws an exeption<br />&nbsp; </span><span class="keyword">}<br />&nbsp; finally {<br />&nbsp; &nbsp; </span><span class="comment">//this code will be executed even when the exception is executed<br />&nbsp; </span><span class="keyword">}<br />}<br /><br />function </span><span class="default">example2</span><span class="keyword">() {<br />&nbsp; try {<br />&nbsp; &nbsp;&nbsp; </span><span class="comment">//open sql connection check user as example<br />&nbsp; &nbsp;&nbsp; </span><span class="keyword">if(</span><span class="default">condition</span><span class="keyword">) { <br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp;&nbsp; }<br />&nbsp; }<br />&nbsp; finally {<br />&nbsp; &nbsp; </span><span class="comment">//close the sql connection, this will be executed even if the return is called.<br />&nbsp; </span><span class="keyword">}<br />}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116273">  <div class="votes">
    <div id="Vu116273">
    <a href="/manual/vote-note.php?id=116273&amp;page=language.exceptions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116273">
    <a href="/manual/vote-note.php?id=116273&amp;page=language.exceptions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116273" title="58% like this...">
    5
    </div>
  </div>
  <a href="#116273" class="name">
  <strong class="user"><em>Tom Polomsk</em></strong></a><a class="genanchor" href="#116273"> &para;</a><div class="date" title="2014-12-04 01:45"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom116273">
<div class="phpcode"><code><span class="html">
Contrary to the documentation it is possible in PHP 5.5 and higher use only try-finally blocks without any catch block.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="115240">  <div class="votes">
    <div id="Vu115240">
    <a href="/manual/vote-note.php?id=115240&amp;page=language.exceptions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115240">
    <a href="/manual/vote-note.php?id=115240&amp;page=language.exceptions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115240" title="58% like this...">
    6
    </div>
  </div>
  <a href="#115240" class="name">
  <strong class="user"><em>telefoontoestel at nospam dot org</em></strong></a><a class="genanchor" href="#115240"> &para;</a><div class="date" title="2014-06-18 12:34"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115240">
<div class="phpcode"><code><span class="html">
When using finally keep in mind that when a exit/die statement is used in the catch block it will NOT go through the finally block. <br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">try {<br />&nbsp; &nbsp; echo </span><span class="string">"try block&lt;br /&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; throw new </span><span class="default">Exception</span><span class="keyword">(</span><span class="string">"test"</span><span class="keyword">);<br />} catch (</span><span class="default">Exception $ex</span><span class="keyword">) {<br />&nbsp; &nbsp; echo </span><span class="string">"catch block&lt;br /&gt;"</span><span class="keyword">;<br />} finally {<br />&nbsp; &nbsp; echo </span><span class="string">"finally block&lt;br /&gt;"</span><span class="keyword">;<br />}<br /><br /></span><span class="comment">// try block<br />// catch block<br />// finally block<br /></span><span class="default">?&gt;<br /></span><br /><span class="default">&lt;?php<br /></span><span class="keyword">try {<br />&nbsp; &nbsp; echo </span><span class="string">"try block&lt;br /&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; throw new </span><span class="default">Exception</span><span class="keyword">(</span><span class="string">"test"</span><span class="keyword">);<br />} catch (</span><span class="default">Exception $ex</span><span class="keyword">) {<br />&nbsp; &nbsp; echo </span><span class="string">"catch block&lt;br /&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; exit(</span><span class="default">1</span><span class="keyword">);<br />} finally {<br />&nbsp; &nbsp; echo </span><span class="string">"finally block&lt;br /&gt;"</span><span class="keyword">;<br />}<br /><br /></span><span class="comment">// try block<br />// catch block<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117029">  <div class="votes">
    <div id="Vu117029">
    <a href="/manual/vote-note.php?id=117029&amp;page=language.exceptions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117029">
    <a href="/manual/vote-note.php?id=117029&amp;page=language.exceptions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117029" title="57% like this...">
    5
    </div>
  </div>
  <a href="#117029" class="name">
  <strong class="user"><em>Simo</em></strong></a><a class="genanchor" href="#117029"> &para;</a><div class="date" title="2015-04-04 02:47"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117029">
<div class="phpcode"><code><span class="html">
#3 is not a good example. inverse("0a") would not be caught since (bool) "0a" returns true, yet 1/"0a" casts the string to integer zero and attempts to perform the calculation.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113368">  <div class="votes">
    <div id="Vu113368">
    <a href="/manual/vote-note.php?id=113368&amp;page=language.exceptions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113368">
    <a href="/manual/vote-note.php?id=113368&amp;page=language.exceptions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113368" title="56% like this...">
    6
    </div>
  </div>
  <a href="#113368" class="name">
  <strong class="user"><em>cyrus+php at boadway dot ca</em></strong></a><a class="genanchor" href="#113368"> &para;</a><div class="date" title="2013-10-02 02:50"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113368">
<div class="phpcode"><code><span class="html">
There's some inconsistent behaviour associated with PHP 5.5.3's finally and return statements. If a method returns a variable in a try block (e.g. return $foo;), and finally modifies that variable, the /modified/ value is returned. However, if the try block has a return that has to be evaluated in-line (e.g. return $foo+0;), finally's changes to $foo will /not/ affect the return value.<br /><br />[code]<br />function returnVariable(){<br />&nbsp; &nbsp; $foo = 1;<br />&nbsp; &nbsp; try{<br />&nbsp; &nbsp; &nbsp; &nbsp; return $foo;<br />&nbsp; &nbsp; } finally {<br />&nbsp; &nbsp; &nbsp; &nbsp; $foo++;<br />&nbsp; &nbsp; }<br />}<br /><br />function returnVariablePlusZero(){<br />&nbsp; &nbsp; $foo = 1;<br />&nbsp; &nbsp; try{<br />&nbsp; &nbsp; &nbsp; &nbsp; return $foo + 0;<br />&nbsp; &nbsp; } finally {<br />&nbsp; &nbsp; &nbsp; &nbsp; $foo++;<br />&nbsp; &nbsp; }<br />}<br /><br />$test1 = returnVariable(); // returns 2, not the correct value of 1.<br />$test2 = returnVariablePlusZero(); // returns correct value of 1, but inconsistent with $test1.<br />[/code]<br /><br />It looks like it's trying to be efficient by not allocating additional memory for the return value when it thinks it doesn't have to, but the spec is that finally is run after try is completed execution, and that includes the evaluation of the return expression.<br /><br />One could argue (weakly) that the first method should be the correct result, but at least the two methods should be consistent.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="81960">  <div class="votes">
    <div id="Vu81960">
    <a href="/manual/vote-note.php?id=81960&amp;page=language.exceptions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd81960">
    <a href="/manual/vote-note.php?id=81960&amp;page=language.exceptions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V81960" title="56% like this...">
    11
    </div>
  </div>
  <a href="#81960" class="name">
  <strong class="user"><em>michael dot ochs at gmx dot net</em></strong></a><a class="genanchor" href="#81960"> &para;</a><div class="date" title="2008-03-21 03:44"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom81960">
<div class="phpcode"><code><span class="html">
Actually it isn't possible to do:<br /><span class="default">&lt;?php<br />someFunction</span><span class="keyword">() OR throw new </span><span class="default">Exception</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span><br />This leads to a T_THROW Syntax Error. If you want to use this kind of exceptions, you can do the following:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">throwException</span><span class="keyword">(</span><span class="default">$message </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">,</span><span class="default">$code </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">) {<br />&nbsp; &nbsp; throw new </span><span class="default">Exception</span><span class="keyword">(</span><span class="default">$message</span><span class="keyword">,</span><span class="default">$code</span><span class="keyword">);<br />}<br /><br /></span><span class="default">someFunction</span><span class="keyword">() OR </span><span class="default">throwException</span><span class="keyword">();<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="112529">  <div class="votes">
    <div id="Vu112529">
    <a href="/manual/vote-note.php?id=112529&amp;page=language.exceptions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd112529">
    <a href="/manual/vote-note.php?id=112529&amp;page=language.exceptions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V112529" title="54% like this...">
    4
    </div>
  </div>
  <a href="#112529" class="name">
  <strong class="user"><em>sander at rotorsolutions dot nl</em></strong></a><a class="genanchor" href="#112529"> &para;</a><div class="date" title="2013-06-26 02:08"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom112529">
<div class="phpcode"><code><span class="html">
Just an example why finally blocks are usefull (5.5)<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="comment">//without catch<br /></span><span class="keyword">function </span><span class="default">example</span><span class="keyword">() {<br />&nbsp; try {<br />&nbsp; &nbsp; </span><span class="comment">//do something that throws an exeption<br />&nbsp; </span><span class="keyword">}<br />&nbsp; finally {<br />&nbsp; &nbsp; </span><span class="comment">//this code will be executed even when the exception is executed<br />&nbsp; </span><span class="keyword">}<br />}<br /><br />function </span><span class="default">example2</span><span class="keyword">() {<br />&nbsp; try {<br />&nbsp; &nbsp;&nbsp; </span><span class="comment">//open sql connection check user as example<br />&nbsp; &nbsp;&nbsp; </span><span class="keyword">if(</span><span class="default">condition</span><span class="keyword">) { <br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp;&nbsp; }<br />&nbsp; }<br />&nbsp; finally {<br />&nbsp; &nbsp; </span><span class="comment">//close the sql connection, this will be executed even if the return is called.<br />&nbsp; </span><span class="keyword">}<br />}</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121673">  <div class="votes">
    <div id="Vu121673">
    <a href="/manual/vote-note.php?id=121673&amp;page=language.exceptions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121673">
    <a href="/manual/vote-note.php?id=121673&amp;page=language.exceptions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121673" title="100% like this...">
    1
    </div>
  </div>
  <a href="#121673" class="name">
  <strong class="user"><em>daviddlowe dot flimm at gmail dot com</em></strong></a><a class="genanchor" href="#121673"> &para;</a><div class="date" title="2017-09-22 01:13"><strong>2 months ago</strong></div>
  <div class="text" id="Hcom121673">
<div class="phpcode"><code><span class="html">
Starting in PHP 7, the classes Exception and Error both implement the Throwable interface. This means, if you want to catch both Error instances and Exception instances, you should catch Throwable objects, like this:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">try {<br />&nbsp; &nbsp; throw new </span><span class="default">Error</span><span class="keyword">( </span><span class="string">"foobar" </span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="comment">// or:<br />&nbsp; &nbsp; // throw new Exception( "foobar" );<br /></span><span class="keyword">}<br />catch (</span><span class="default">Throwable $e</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">var_export</span><span class="keyword">( </span><span class="default">$e </span><span class="keyword">);<br />}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121843">  <div class="votes">
    <div id="Vu121843">
    <a href="/manual/vote-note.php?id=121843&amp;page=language.exceptions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121843">
    <a href="/manual/vote-note.php?id=121843&amp;page=language.exceptions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121843" title="no votes...">
    0
    </div>
  </div>
  <a href="#121843" class="name">
  <strong class="user"><em>jake at NOSPAM dot qzdesign dot co dot uk</em></strong></a><a class="genanchor" href="#121843"> &para;</a><div class="date" title="2017-11-08 12:03"><strong>1 month ago</strong></div>
  <div class="text" id="Hcom121843">
<div class="phpcode"><code><span class="html">
Don't forget if your source file is in a namespace you will need to<br /><span class="default">&lt;?php<br /></span><span class="keyword">use </span><span class="default">Throwable</span><span class="keyword">; </span><span class="comment">// PHP 7<br /></span><span class="keyword">use </span><span class="default">Exception</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span>or type the fully qualified class name (prefixed with `\`) as in<br /><span class="default">&lt;?php<br /></span><span class="keyword">try {<br />&nbsp; </span><span class="comment">// ...<br /></span><span class="keyword">} catch(\</span><span class="default">Throwable $e</span><span class="keyword">) {<br />&nbsp; </span><span class="comment">// PHP 7<br /></span><span class="keyword">} catch(\</span><span class="default">Exception $e</span><span class="keyword">) {<br />&nbsp; </span><span class="comment">// PHP 5<br /></span><span class="keyword">}<br /></span><span class="default">?&gt;<br /></span>otherwise you will only ever catch exceptions of the possibly non-existent classes `\YourNamespace\Throwable` and `\YourNamespace\Exception`!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="106696">  <div class="votes">
    <div id="Vu106696">
    <a href="/manual/vote-note.php?id=106696&amp;page=language.exceptions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd106696">
    <a href="/manual/vote-note.php?id=106696&amp;page=language.exceptions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V106696" title="51% like this...">
    1
    </div>
  </div>
  <a href="#106696" class="name">
  <strong class="user"><em>Sawsan</em></strong></a><a class="genanchor" href="#106696"> &para;</a><div class="date" title="2011-11-28 09:36"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom106696">
<div class="phpcode"><code><span class="html">
the following is an example of a re-thrown exception and the using of getPrevious function:<br /><br /><span class="default">&lt;?php<br /><br />$name </span><span class="keyword">= </span><span class="string">"Name"</span><span class="keyword">;<br /><br /></span><span class="comment">//check if the name contains only letters, and does not contain the word name<br /><br /></span><span class="keyword">try<br />&nbsp;&nbsp; {<br />&nbsp;&nbsp; try<br />&nbsp; &nbsp;&nbsp; {<br />&nbsp; &nbsp; &nbsp; if (</span><span class="default">preg_match</span><span class="keyword">(</span><span class="string">'/[^a-z]/i'</span><span class="keyword">, </span><span class="default">$name</span><span class="keyword">)) <br />&nbsp; &nbsp; &nbsp;&nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; throw new </span><span class="default">Exception</span><span class="keyword">(</span><span class="string">"</span><span class="default">$name</span><span class="string"> contains character other than a-z A-Z"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp;&nbsp; }&nbsp;&nbsp; <br />&nbsp; &nbsp; &nbsp;&nbsp; if(</span><span class="default">strpos</span><span class="keyword">(</span><span class="default">strtolower</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">), </span><span class="string">'name'</span><span class="keyword">) !== </span><span class="default">FALSE</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp;&nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">Exception</span><span class="keyword">(</span><span class="string">"</span><span class="default">$name</span><span class="string"> contains the word name"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp;&nbsp; }<br />&nbsp; &nbsp; &nbsp;&nbsp; echo </span><span class="string">"The Name is valid"</span><span class="keyword">;<br />&nbsp; &nbsp;&nbsp; }<br />&nbsp;&nbsp; catch(</span><span class="default">Exception $e</span><span class="keyword">)<br />&nbsp; &nbsp;&nbsp; {<br />&nbsp; &nbsp;&nbsp; throw new </span><span class="default">Exception</span><span class="keyword">(</span><span class="string">"insert name again"</span><span class="keyword">,</span><span class="default">0</span><span class="keyword">,</span><span class="default">$e</span><span class="keyword">);<br />&nbsp; &nbsp;&nbsp; }<br />&nbsp;&nbsp; }<br /> <br />catch (</span><span class="default">Exception $e</span><span class="keyword">)<br />&nbsp;&nbsp; {<br />&nbsp;&nbsp; if (</span><span class="default">$e</span><span class="keyword">-&gt;</span><span class="default">getPrevious</span><span class="keyword">())<br />&nbsp;&nbsp; {<br />&nbsp; &nbsp; echo </span><span class="string">"The Previous Exception is: "</span><span class="keyword">.</span><span class="default">$e</span><span class="keyword">-&gt;</span><span class="default">getPrevious</span><span class="keyword">()-&gt;</span><span class="default">getMessage</span><span class="keyword">().</span><span class="string">"&lt;br/&gt;"</span><span class="keyword">;<br />&nbsp;&nbsp; }<br />&nbsp;&nbsp; echo </span><span class="string">"The Exception is: "</span><span class="keyword">.</span><span class="default">$e</span><span class="keyword">-&gt;</span><span class="default">getMessage</span><span class="keyword">().</span><span class="string">"&lt;br/&gt;"</span><span class="keyword">;<br />&nbsp;&nbsp; }<br /><br /> </span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119147">  <div class="votes">
    <div id="Vu119147">
    <a href="/manual/vote-note.php?id=119147&amp;page=language.exceptions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119147">
    <a href="/manual/vote-note.php?id=119147&amp;page=language.exceptions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119147" title="50% like this...">
    0
    </div>
  </div>
  <a href="#119147" class="name">
  <strong class="user"><em>Mohammad Hossein Darvishanpour</em></strong></a><a class="genanchor" href="#119147"> &para;</a><div class="date" title="2016-04-11 07:05"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119147">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">Test_Extention</span><span class="keyword">(</span><span class="default">$var1</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; if(</span><span class="default">$var1 </span><span class="keyword">== </span><span class="default">false</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">Exception</span><span class="keyword">(</span><span class="string">'Invalid !'</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}</span><span class="comment">//end function<br /><br /></span><span class="keyword">try<br />{<br />&nbsp; &nbsp; </span><span class="default">Test_Extention</span><span class="keyword">(</span><span class="default">false</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">printf</span><span class="keyword">(</span><span class="string">"%s"</span><span class="keyword">,</span><span class="string">"Valid"</span><span class="keyword">);<br />}<br /><br />catch(</span><span class="default">Exception $e</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="default">printf</span><span class="keyword">(</span><span class="string">"%s"</span><span class="keyword">,</span><span class="string">"Message : " </span><span class="keyword">. </span><span class="default">$e</span><span class="keyword">-&gt;</span><span class="default">getMessage</span><span class="keyword">());<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="72567">  <div class="votes">
    <div id="Vu72567">
    <a href="/manual/vote-note.php?id=72567&amp;page=language.exceptions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd72567">
    <a href="/manual/vote-note.php?id=72567&amp;page=language.exceptions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V72567" title="51% like this...">
    1
    </div>
  </div>
  <a href="#72567" class="name">
  <strong class="user"><em>jon at hackcraft dot net</em></strong></a><a class="genanchor" href="#72567"> &para;</a><div class="date" title="2007-01-24 09:52"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom72567">
<div class="phpcode"><code><span class="html">
Further to dexen at google dot me dot up with "use destructors to perform a cleanup in case of exception". The fact that PHP5 has destructors, exception handling, and predictable garbage collection (if there's a single reference in scope and the scope is left then the destructor is called immediately) allows for the use of the RAII idiom.<br /><br /><a href="http://en.wikipedia.org/wiki/Resource_Acquisition_Is_Initialization" rel="nofollow" target="_blank">http://en.wikipedia.org/wiki/Resource_Acquisition_Is_Initialization</a> and my own <a href="http://www.hackcraft.net/RAII/" rel="nofollow" target="_blank">http://www.hackcraft.net/RAII/</a> describe this.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="65203">  <div class="votes">
    <div id="Vu65203">
    <a href="/manual/vote-note.php?id=65203&amp;page=language.exceptions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd65203">
    <a href="/manual/vote-note.php?id=65203&amp;page=language.exceptions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V65203" title="50% like this...">
    0
    </div>
  </div>
  <a href="#65203" class="name">
  <strong class="user"><em>fjoggen at gmail dot com</em></strong></a><a class="genanchor" href="#65203"> &para;</a><div class="date" title="2006-04-26 01:58"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom65203">
<div class="phpcode"><code><span class="html">
This code will turn php errors into exceptions:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">exceptions_error_handler</span><span class="keyword">(</span><span class="default">$severity</span><span class="keyword">, </span><span class="default">$message</span><span class="keyword">, </span><span class="default">$filename</span><span class="keyword">, </span><span class="default">$lineno</span><span class="keyword">) { <br />&nbsp; &nbsp; throw new </span><span class="default">ErrorException</span><span class="keyword">(</span><span class="default">$message</span><span class="keyword">, </span><span class="default">0</span><span class="keyword">, </span><span class="default">$severity</span><span class="keyword">, </span><span class="default">$filename</span><span class="keyword">, </span><span class="default">$lineno</span><span class="keyword">); <br />}<br /><br /></span><span class="default">set_error_handler</span><span class="keyword">(</span><span class="string">'exceptions_error_handler'</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />However since <span class="default">&lt;?php set_error_handler</span><span class="keyword">()</span><span class="default">?&gt;</span> doesn't work with fatal errors, you will not be able to throw them as Exceptions.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="79577">  <div class="votes">
    <div id="Vu79577">
    <a href="/manual/vote-note.php?id=79577&amp;page=language.exceptions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd79577">
    <a href="/manual/vote-note.php?id=79577&amp;page=language.exceptions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V79577" title="46% like this...">
    -3
    </div>
  </div>
  <a href="#79577" class="name">
  <strong class="user"><em>omnibus at omnibus dot edu dot pl</em></strong></a><a class="genanchor" href="#79577"> &para;</a><div class="date" title="2007-12-04 03:11"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom79577">
<div class="phpcode"><code><span class="html">
Just to be more precise in what Frank found:<br />Catch the exceptions always in order from the bottom to the top of the Exception and subclasses class hierarchy. If you have class MyException extending Exception and class My2Exception extending MyException always catch My2Exception before MyException.<br /><br />Hope this helps</span>
</code></div>
  </div>
 </div>
  <div class="note" id="105102">  <div class="votes">
    <div id="Vu105102">
    <a href="/manual/vote-note.php?id=105102&amp;page=language.exceptions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd105102">
    <a href="/manual/vote-note.php?id=105102&amp;page=language.exceptions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V105102" title="45% like this...">
    -4
    </div>
  </div>
  <a href="#105102" class="name">
  <strong class="user"><em>alex dowgailenko [at] g mail . com</em></strong></a><a class="genanchor" href="#105102"> &para;</a><div class="date" title="2011-07-27 12:20"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom105102">
<div class="phpcode"><code><span class="html">
If you use the set_error_handler() to throw exceptions of errors, you may encounter issues with __autoload() functionality saying that your class doesn't exist and that's it.<br /><br />If you do this:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">MyException </span><span class="keyword">extends </span><span class="default">Exception<br /></span><span class="keyword">{<br />}<br /><br />class </span><span class="default">Tester<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">foobar</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; try<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">helloWorld</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; } catch (</span><span class="default">MyException $e</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">Exception</span><span class="keyword">(</span><span class="string">'Problem in foobar'</span><span class="keyword">,</span><span class="default">0</span><span class="keyword">,</span><span class="default">$e</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; protected function </span><span class="default">helloWorld</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">MyException</span><span class="keyword">(</span><span class="string">'Problem in helloWorld()'</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$tester </span><span class="keyword">= new </span><span class="default">Tester</span><span class="keyword">;<br />try<br />{<br />&nbsp; &nbsp; </span><span class="default">$tester</span><span class="keyword">-&gt;</span><span class="default">foobar</span><span class="keyword">();<br />} catch (</span><span class="default">Exception $e</span><span class="keyword">) {<br />&nbsp; &nbsp; echo </span><span class="default">$e</span><span class="keyword">-&gt;</span><span class="default">getTraceAsString</span><span class="keyword">();<br />}<br /></span><span class="default">?&gt;<br /></span><br />The trace will only show $tester-&gt;foobar() and not the call made to $tester-&gt;helloWorld().<br /><br />In other words, if you pass a previous exception to a new one, the previous exception's stack trace is taken into account in the new exception.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="115257">  <div class="votes">
    <div id="Vu115257">
    <a href="/manual/vote-note.php?id=115257&amp;page=language.exceptions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115257">
    <a href="/manual/vote-note.php?id=115257&amp;page=language.exceptions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115257" title="44% like this...">
    -4
    </div>
  </div>
  <a href="#115257" class="name">
  <strong class="user"><em>Hayley Watson</em></strong></a><a class="genanchor" href="#115257"> &para;</a><div class="date" title="2014-06-23 06:58"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115257">
<div class="phpcode"><code><span class="html">
Remember that Exceptions are also objects and can be handled as such; they can be constructed in and returned as values from functions, passed as arguments to other functions, and examined before being thrown. You don't have to throw it as soon as you have constructed it (the stack trace will of course reflect the moment the Exception was constructed, not the moment it was thrown).<br /><br />You might, for example, want to collect additional information to include in YourException but you don't want to clutter up the YourException class or the code containing the "throw" statement by collecting the information there. Or you might want to do something (such as logging) with each Exception that is thrown from a certain region (catch it, pass it to the logging function, then rethrow it).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="78591">  <div class="votes">
    <div id="Vu78591">
    <a href="/manual/vote-note.php?id=78591&amp;page=language.exceptions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd78591">
    <a href="/manual/vote-note.php?id=78591&amp;page=language.exceptions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V78591" title="33% like this...">
    -17
    </div>
  </div>
  <a href="#78591" class="name">
  <strong class="user"><em>hartym dot dont dot like dot spam at gmail dot com</em></strong></a><a class="genanchor" href="#78591"> &para;</a><div class="date" title="2007-10-18 04:41"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom78591">
<div class="phpcode"><code><span class="html">
@serenity: of course you need to throw exception within the try block, catch will not watch fatal errors, nor less important errors but only exceptions that are instanceof the exception type you're giving. Of course by within the try block, i mean within every functions call happening in try block.<br /><br />For example, to nicely handle old mysql errors, you can do something like this:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">try<br />{<br />&nbsp; </span><span class="default">$connection </span><span class="keyword">= </span><span class="default">mysql_connect</span><span class="keyword">(...);<br />&nbsp; if (</span><span class="default">$connection </span><span class="keyword">=== </span><span class="default">false</span><span class="keyword">)<br />&nbsp; {<br />&nbsp; &nbsp; throw new </span><span class="default">Exception</span><span class="keyword">(</span><span class="string">'Cannot connect do mysql'</span><span class="keyword">);<br />&nbsp; }<br /><br />&nbsp;&nbsp; </span><span class="comment">/* ... do whatever you need with database, that may mail and throw exceptions too ... */<br /><br />&nbsp;&nbsp; </span><span class="default">mysql_close</span><span class="keyword">(</span><span class="default">$connection</span><span class="keyword">);<br />}<br />catch (</span><span class="default">Exception $e</span><span class="keyword">)<br />{<br />&nbsp;&nbsp; </span><span class="comment">/* ... add logging stuff there if you need ... */<br /><br />&nbsp; </span><span class="keyword">echo </span><span class="string">"This page cannot be displayed"</span><span class="keyword">;<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />By doing so, you're aiming at the don't repeat yourself (D.R.Y) concept, by managing error handling at only one place for the whole.</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.exceptions&amp;redirect=http://php.net/manual/en/language.exceptions.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="langref.php">Language Reference</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.basic-syntax.php" title="Basic syntax">Basic syntax</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.php" title="Types">Types</a>
                        </li>
                          
                        <li class="">
                            <a href="language.variables.php" title="Variables">Variables</a>
                        </li>
                          
                        <li class="">
                            <a href="language.constants.php" title="Constants">Constants</a>
                        </li>
                          
                        <li class="">
                            <a href="language.expressions.php" title="Expressions">Expressions</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.php" title="Operators">Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.control-structures.php" title="Control Structures">Control Structures</a>
                        </li>
                          
                        <li class="">
                            <a href="language.functions.php" title="Functions">Functions</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.php" title="Classes and Objects">Classes and Objects</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.php" title="Namespaces">Namespaces</a>
                        </li>
                          
                        <li class="">
                            <a href="language.errors.php" title="Errors">Errors</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.exceptions.php" title="Exceptions">Exceptions</a>
                        </li>
                          
                        <li class="">
                            <a href="language.generators.php" title="Generators">Generators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.references.php" title="References Explained">References Explained</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.php" title="Predefined Variables">Predefined Variables</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.exceptions.php" title="Predefined Exceptions">Predefined Exceptions</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.interfaces.php" title="Predefined Interfaces and Classes">Predefined Interfaces and Classes</a>
                        </li>
                          
                        <li class="">
                            <a href="context.php" title="Context options and parameters">Context options and parameters</a>
                        </li>
                          
                        <li class="">
                            <a href="wrappers.php" title="Supported Protocols and Wrappers">Supported Protocols and Wrappers</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

