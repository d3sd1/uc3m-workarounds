<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Using namespaces: Aliasing/Importing - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.namespaces.importing.php">
 <link rel="shorturl" href="http://php.net/namespaces.importing">
 <link rel="alternate" href="http://php.net/namespaces.importing" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.namespaces.php">
 <link rel="prev" href="http://php.net/manual/en/language.namespaces.nsconstants.php">
 <link rel="next" href="http://php.net/manual/en/language.namespaces.global.php">

 <link rel="alternate" href="http://php.net/manual/en/language.namespaces.importing.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.namespaces.importing.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.namespaces.importing.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.namespaces.importing.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.namespaces.importing.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.namespaces.importing.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.namespaces.importing.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.namespaces.importing.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.namespaces.importing.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.namespaces.importing.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.namespaces.importing.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.namespaces.global.php">
          Global space &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.namespaces.nsconstants.php">
          &laquo; namespace keyword and __NAMESPACE__ constant        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.namespaces.php'>Namespaces</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.namespaces.importing.php' selected="selected">English</option>
            <option value='pt_BR/language.namespaces.importing.php'>Brazilian Portuguese</option>
            <option value='zh/language.namespaces.importing.php'>Chinese (Simplified)</option>
            <option value='fr/language.namespaces.importing.php'>French</option>
            <option value='de/language.namespaces.importing.php'>German</option>
            <option value='ja/language.namespaces.importing.php'>Japanese</option>
            <option value='ro/language.namespaces.importing.php'>Romanian</option>
            <option value='ru/language.namespaces.importing.php'>Russian</option>
            <option value='es/language.namespaces.importing.php'>Spanish</option>
            <option value='tr/language.namespaces.importing.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.namespaces.importing.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.namespaces.importing">Report a Bug</a>
    </div>
  </div><div id="language.namespaces.importing" class="sect1">
  <h2 class="title">Using namespaces: Aliasing/Importing</h2>
  <p class="verinfo">(PHP 5 &gt;= 5.3.0, PHP 7)</p>
  <p class="para">
   The ability to refer to an external fully qualified name with an alias, or importing,
   is an important feature of namespaces.  This is similar to the
   ability of unix-based filesystems to create symbolic links to a file or to a directory.
  </p>
  <p class="para">
   All versions of PHP that support namespaces support three kinds of aliasing
   or importing: aliasing a class name, aliasing an interface name, and
   aliasing a namespace name. PHP 5.6+ also allows aliasing or importing
   function and constant names.
  </p>
  <p class="para">
   In PHP, aliasing is accomplished with the <em>use</em> operator.  Here
   is an example showing all 5 kinds of importing:
   <div class="example" id="example-258">
    <p><strong>Example #1 importing/aliasing with the use operator</strong></p>
    <div class="example-contents">
     <div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">namespace&nbsp;</span><span style="color: #0000BB">foo</span><span style="color: #007700">;<br />use&nbsp;</span><span style="color: #0000BB">My</span><span style="color: #007700">\</span><span style="color: #0000BB">Full</span><span style="color: #007700">\</span><span style="color: #0000BB">Classname&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">Another</span><span style="color: #007700">;<br /><br /></span><span style="color: #FF8000">//&nbsp;this&nbsp;is&nbsp;the&nbsp;same&nbsp;as&nbsp;use&nbsp;My\Full\NSname&nbsp;as&nbsp;NSname<br /></span><span style="color: #007700">use&nbsp;</span><span style="color: #0000BB">My</span><span style="color: #007700">\</span><span style="color: #0000BB">Full</span><span style="color: #007700">\</span><span style="color: #0000BB">NSname</span><span style="color: #007700">;<br /><br /></span><span style="color: #FF8000">//&nbsp;importing&nbsp;a&nbsp;global&nbsp;class<br /></span><span style="color: #007700">use&nbsp;</span><span style="color: #0000BB">ArrayObject</span><span style="color: #007700">;<br /><br /></span><span style="color: #FF8000">//&nbsp;importing&nbsp;a&nbsp;function&nbsp;(PHP&nbsp;5.6+)<br /></span><span style="color: #007700">use&nbsp;function&nbsp;</span><span style="color: #0000BB">My</span><span style="color: #007700">\</span><span style="color: #0000BB">Full</span><span style="color: #007700">\</span><span style="color: #0000BB">functionName</span><span style="color: #007700">;<br /><br /></span><span style="color: #FF8000">//&nbsp;aliasing&nbsp;a&nbsp;function&nbsp;(PHP&nbsp;5.6+)<br /></span><span style="color: #007700">use&nbsp;function&nbsp;</span><span style="color: #0000BB">My</span><span style="color: #007700">\</span><span style="color: #0000BB">Full</span><span style="color: #007700">\</span><span style="color: #0000BB">functionName&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">func</span><span style="color: #007700">;<br /><br /></span><span style="color: #FF8000">//&nbsp;importing&nbsp;a&nbsp;constant&nbsp;(PHP&nbsp;5.6+)<br /></span><span style="color: #007700">use&nbsp;const&nbsp;</span><span style="color: #0000BB">My</span><span style="color: #007700">\</span><span style="color: #0000BB">Full</span><span style="color: #007700">\</span><span style="color: #0000BB">CONSTANT</span><span style="color: #007700">;<br /><br /></span><span style="color: #0000BB">$obj&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;namespace\</span><span style="color: #0000BB">Another</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;instantiates&nbsp;object&nbsp;of&nbsp;class&nbsp;foo\Another<br /></span><span style="color: #0000BB">$obj&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">Another</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;instantiates&nbsp;object&nbsp;of&nbsp;class&nbsp;My\Full\Classname<br /></span><span style="color: #0000BB">NSname</span><span style="color: #007700">\</span><span style="color: #0000BB">subns</span><span style="color: #007700">\</span><span style="color: #0000BB">func</span><span style="color: #007700">();&nbsp;</span><span style="color: #FF8000">//&nbsp;calls&nbsp;function&nbsp;My\Full\NSname\subns\func<br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">ArrayObject</span><span style="color: #007700">(array(</span><span style="color: #0000BB">1</span><span style="color: #007700">));&nbsp;</span><span style="color: #FF8000">//&nbsp;instantiates&nbsp;object&nbsp;of&nbsp;class&nbsp;ArrayObject<br />//&nbsp;without&nbsp;the&nbsp;"use&nbsp;ArrayObject"&nbsp;we&nbsp;would&nbsp;instantiate&nbsp;an&nbsp;object&nbsp;of&nbsp;class&nbsp;foo\ArrayObject<br /></span><span style="color: #0000BB">func</span><span style="color: #007700">();&nbsp;</span><span style="color: #FF8000">//&nbsp;calls&nbsp;function&nbsp;My\Full\functionName<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #0000BB">CONSTANT</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;echoes&nbsp;the&nbsp;value&nbsp;of&nbsp;My\Full\CONSTANT<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
   Note that for namespaced names (fully qualified namespace names containing
   namespace separator, such as <em>Foo\Bar</em> as opposed to global names that
   do not, such as <em>FooBar</em>), the leading backslash is unnecessary and not
   recommended, as import names
   must be fully qualified, and are not processed relative to the current namespace.
  </p>
  <p class="para">
   PHP additionally supports a convenience shortcut to place multiple use statements
   on the same line
   <div class="example" id="example-259">
    <p><strong>Example #2 importing/aliasing with the use operator, multiple use statements combined</strong></p>
    <div class="example-contents">
     <div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">use&nbsp;</span><span style="color: #0000BB">My</span><span style="color: #007700">\</span><span style="color: #0000BB">Full</span><span style="color: #007700">\</span><span style="color: #0000BB">Classname&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">Another</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">My</span><span style="color: #007700">\</span><span style="color: #0000BB">Full</span><span style="color: #007700">\</span><span style="color: #0000BB">NSname</span><span style="color: #007700">;<br /><br /></span><span style="color: #0000BB">$obj&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">Another</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;instantiates&nbsp;object&nbsp;of&nbsp;class&nbsp;My\Full\Classname<br /></span><span style="color: #0000BB">NSname</span><span style="color: #007700">\</span><span style="color: #0000BB">subns</span><span style="color: #007700">\</span><span style="color: #0000BB">func</span><span style="color: #007700">();&nbsp;</span><span style="color: #FF8000">//&nbsp;calls&nbsp;function&nbsp;My\Full\NSname\subns\func<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
  </p>
  <p class="para">
   Importing is performed at compile-time, and so does not affect dynamic class, function
   or constant names.
   <div class="example" id="example-260">
    <p><strong>Example #3 Importing and dynamic names</strong></p>
    <div class="example-contents">
     <div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">use&nbsp;</span><span style="color: #0000BB">My</span><span style="color: #007700">\</span><span style="color: #0000BB">Full</span><span style="color: #007700">\</span><span style="color: #0000BB">Classname&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">Another</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">My</span><span style="color: #007700">\</span><span style="color: #0000BB">Full</span><span style="color: #007700">\</span><span style="color: #0000BB">NSname</span><span style="color: #007700">;<br /><br /></span><span style="color: #0000BB">$obj&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">Another</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;instantiates&nbsp;object&nbsp;of&nbsp;class&nbsp;My\Full\Classname<br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'Another'</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$obj&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">$a</span><span style="color: #007700">;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;instantiates&nbsp;object&nbsp;of&nbsp;class&nbsp;Another<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
  </p>
  <p class="para">
   In addition, importing only affects unqualified and qualified names.  Fully qualified
   names are absolute, and unaffected by imports.
   <div class="example" id="example-261">
    <p><strong>Example #4 Importing and fully qualified names</strong></p>
    <div class="example-contents">
     <div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">use&nbsp;</span><span style="color: #0000BB">My</span><span style="color: #007700">\</span><span style="color: #0000BB">Full</span><span style="color: #007700">\</span><span style="color: #0000BB">Classname&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">Another</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">My</span><span style="color: #007700">\</span><span style="color: #0000BB">Full</span><span style="color: #007700">\</span><span style="color: #0000BB">NSname</span><span style="color: #007700">;<br /><br /></span><span style="color: #0000BB">$obj&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">Another</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;instantiates&nbsp;object&nbsp;of&nbsp;class&nbsp;My\Full\Classname<br /></span><span style="color: #0000BB">$obj&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;\</span><span style="color: #0000BB">Another</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;instantiates&nbsp;object&nbsp;of&nbsp;class&nbsp;Another<br /></span><span style="color: #0000BB">$obj&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">Another</span><span style="color: #007700">\</span><span style="color: #0000BB">thing</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;instantiates&nbsp;object&nbsp;of&nbsp;class&nbsp;My\Full\Classname\thing<br /></span><span style="color: #0000BB">$obj&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;\</span><span style="color: #0000BB">Another</span><span style="color: #007700">\</span><span style="color: #0000BB">thing</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;instantiates&nbsp;object&nbsp;of&nbsp;class&nbsp;Another\thing<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
  </p>
  <div class="sect2" id="language.namespaces.importing.scope">
   <h3 class="title">Scoping rules for importing</h3>
   <p class="para">
    The <em>use</em> keyword must be declared in the 
    outermost scope of a file (the global scope) or inside namespace 
    declarations. This is because the importing is done at compile 
    time and not runtime, so it cannot be block scoped. The following 
    example will show an illegal use of the <em>use</em> 
    keyword:
   </p>
   <p class="para">
    <div class="example" id="example-262">
     <p><strong>Example #5 Illegal importing rule</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">namespace&nbsp;</span><span style="color: #0000BB">Languages</span><span style="color: #007700">;<br /><br />function&nbsp;</span><span style="color: #0000BB">toGreenlandic</span><span style="color: #007700">()<br />{<br />&nbsp;&nbsp;&nbsp;&nbsp;use&nbsp;</span><span style="color: #0000BB">Languages</span><span style="color: #007700">\</span><span style="color: #0000BB">Danish</span><span style="color: #007700">;<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;...<br /></span><span style="color: #007700">}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>
   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <p class="para">
     Importing rules are per file basis, meaning included files will 
     <em class="emphasis">NOT</em> inherit the parent file&#039;s importing rules.
    </p>
   </p></blockquote>
  </div>
  <div class="sect2" id="language.namespaces.importing.group">
   <h3 class="title">Group <em>use</em> declarations</h3>
   <p class="para">
    From PHP 7.0 onwards, classes, functions and constants being imported from
    the same <a href="language.namespaces.definition.php" class="link"><em>namespace</em></a> can be grouped together in a single <a href="language.namespaces.importing.php" class="link"><em>use</em></a>
    statement.
   </p>
   <div class="informalexample">
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /><br /></span><span style="color: #FF8000">//&nbsp;Pre&nbsp;PHP&nbsp;7&nbsp;code<br /></span><span style="color: #007700">use&nbsp;</span><span style="color: #0000BB">some</span><span style="color: #007700">\namespace\</span><span style="color: #0000BB">ClassA</span><span style="color: #007700">;<br />use&nbsp;</span><span style="color: #0000BB">some</span><span style="color: #007700">\namespace\</span><span style="color: #0000BB">ClassB</span><span style="color: #007700">;<br />use&nbsp;</span><span style="color: #0000BB">some</span><span style="color: #007700">\namespace\</span><span style="color: #0000BB">ClassC&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">C</span><span style="color: #007700">;<br /><br />use&nbsp;function&nbsp;</span><span style="color: #0000BB">some</span><span style="color: #007700">\namespace\</span><span style="color: #0000BB">fn_a</span><span style="color: #007700">;<br />use&nbsp;function&nbsp;</span><span style="color: #0000BB">some</span><span style="color: #007700">\namespace\</span><span style="color: #0000BB">fn_b</span><span style="color: #007700">;<br />use&nbsp;function&nbsp;</span><span style="color: #0000BB">some</span><span style="color: #007700">\namespace\</span><span style="color: #0000BB">fn_c</span><span style="color: #007700">;<br /><br />use&nbsp;const&nbsp;</span><span style="color: #0000BB">some</span><span style="color: #007700">\namespace\</span><span style="color: #0000BB">ConstA</span><span style="color: #007700">;<br />use&nbsp;const&nbsp;</span><span style="color: #0000BB">some</span><span style="color: #007700">\namespace\</span><span style="color: #0000BB">ConstB</span><span style="color: #007700">;<br />use&nbsp;const&nbsp;</span><span style="color: #0000BB">some</span><span style="color: #007700">\namespace\</span><span style="color: #0000BB">ConstC</span><span style="color: #007700">;<br /><br /></span><span style="color: #FF8000">//&nbsp;PHP&nbsp;7+&nbsp;code<br /></span><span style="color: #007700">use&nbsp;</span><span style="color: #0000BB">some</span><span style="color: #007700">\namespace\{</span><span style="color: #0000BB">ClassA</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">ClassB</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">ClassC&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">C</span><span style="color: #007700">};<br />use&nbsp;function&nbsp;</span><span style="color: #0000BB">some</span><span style="color: #007700">\namespace\{</span><span style="color: #0000BB">fn_a</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">fn_b</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">fn_c</span><span style="color: #007700">};<br />use&nbsp;const&nbsp;</span><span style="color: #0000BB">some</span><span style="color: #007700">\namespace\{</span><span style="color: #0000BB">ConstA</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">ConstB</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">ConstC</span><span style="color: #007700">};</span>
</span>
</code></div>
    </div>

   </div>
  </div>
 </div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.namespaces.importing&amp;redirect=http://php.net/manual/en/language.namespaces.importing.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">20 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="119919">  <div class="votes">
    <div id="Vu119919">
    <a href="/manual/vote-note.php?id=119919&amp;page=language.namespaces.importing&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119919">
    <a href="/manual/vote-note.php?id=119919&amp;page=language.namespaces.importing&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119919" title="96% like this...">
    31
    </div>
  </div>
  <a href="#119919" class="name">
  <strong class="user"><em>dominic_mayers at yahoo dot com</em></strong></a><a class="genanchor" href="#119919"> &para;</a><div class="date" title="2016-09-20 10:50"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119919">
<div class="phpcode"><code><span class="html">
The keyword "use" has been recycled for three distinct applications: <br />1- to import/alias classes, traits, constants, etc. in namespaces, <br />2- to insert traits in classes, <br />3- to inherit variables in closures. <br />This page is only about the first application: importing/aliasing. Traits can be inserted in classes, but this is different from importing a trait in a namespace, which cannot be done in a block scope, as pointed out in example 5. This can be confusing, especially since all searches for the keyword "use" are directed to the documentation here on importing/aliasing.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="111874">  <div class="votes">
    <div id="Vu111874">
    <a href="/manual/vote-note.php?id=111874&amp;page=language.namespaces.importing&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd111874">
    <a href="/manual/vote-note.php?id=111874&amp;page=language.namespaces.importing&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V111874" title="78% like this...">
    59
    </div>
  </div>
  <a href="#111874" class="name">
  <strong class="user"><em>k at webnfo dot com</em></strong></a><a class="genanchor" href="#111874"> &para;</a><div class="date" title="2013-04-07 01:32"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom111874">
<div class="phpcode"><code><span class="html">
Note that you can not alias global namespace:<br /><br />use \ as test;<br /><br />echo test\strlen('');<br /><br />won't work.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114265">  <div class="votes">
    <div id="Vu114265">
    <a href="/manual/vote-note.php?id=114265&amp;page=language.namespaces.importing&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114265">
    <a href="/manual/vote-note.php?id=114265&amp;page=language.namespaces.importing&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114265" title="77% like this...">
    45
    </div>
  </div>
  <a href="#114265" class="name">
  <strong class="user"><em>anon</em></strong></a><a class="genanchor" href="#114265"> &para;</a><div class="date" title="2014-01-30 09:08"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114265">
<div class="phpcode"><code><span class="html">
The <span class="default">&lt;?php </span><span class="keyword">use </span><span class="default">?&gt;</span> statement does not load the class file. You have to do this with the <span class="default">&lt;?php </span><span class="keyword">require </span><span class="default">?&gt;</span> statement or by using an autoload function.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119091">  <div class="votes">
    <div id="Vu119091">
    <a href="/manual/vote-note.php?id=119091&amp;page=language.namespaces.importing&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119091">
    <a href="/manual/vote-note.php?id=119091&amp;page=language.namespaces.importing&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119091" title="81% like this...">
    10
    </div>
  </div>
  <a href="#119091" class="name">
  <strong class="user"><em>me at ruslanbes dot com</em></strong></a><a class="genanchor" href="#119091"> &para;</a><div class="date" title="2016-03-31 07:34"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119091">
<div class="phpcode"><code><span class="html">
Note the code `use ns1\c1` may refer to importing class `c1` from namespace `ns1` as well as importing whole namespace `ns1\c1` or even import both of them in one line. Example:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">namespace </span><span class="default">ns1</span><span class="keyword">;<br /><br />class </span><span class="default">c1</span><span class="keyword">{}<br /><br />namespace </span><span class="default">ns1</span><span class="keyword">\</span><span class="default">c1</span><span class="keyword">;<br /><br />class </span><span class="default">c11</span><span class="keyword">{}<br /><br />namespace </span><span class="default">main</span><span class="keyword">;<br /><br />use </span><span class="default">ns1</span><span class="keyword">\</span><span class="default">c1</span><span class="keyword">;<br /><br /></span><span class="default">$c1 </span><span class="keyword">= new </span><span class="default">c1</span><span class="keyword">();<br /></span><span class="default">$c11 </span><span class="keyword">= new </span><span class="default">c1</span><span class="keyword">\</span><span class="default">c11</span><span class="keyword">();<br /><br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$c1</span><span class="keyword">); </span><span class="comment">// object(ns1\c1)#1 (0) { }<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$c11</span><span class="keyword">); </span><span class="comment">// object(ns1\c1\c11)#2 (0) { }</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121045">  <div class="votes">
    <div id="Vu121045">
    <a href="/manual/vote-note.php?id=121045&amp;page=language.namespaces.importing&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121045">
    <a href="/manual/vote-note.php?id=121045&amp;page=language.namespaces.importing&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121045" title="80% like this...">
    6
    </div>
  </div>
  <a href="#121045" class="name">
  <strong class="user"><em>xzero at elite7hackers dot net</em></strong></a><a class="genanchor" href="#121045"> &para;</a><div class="date" title="2017-05-04 11:13"><strong>7 months ago</strong></div>
  <div class="text" id="Hcom121045">
<div class="phpcode"><code><span class="html">
I couldn't find answer to this question so I tested myself. <br />I think it's worth noting:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">use </span><span class="default">ExistingNamespace</span><span class="keyword">\</span><span class="default">NonExsistingClass</span><span class="keyword">;<br />use </span><span class="default">ExistingNamespace</span><span class="keyword">\</span><span class="default">NonExsistingClass </span><span class="keyword">as </span><span class="default">whatever</span><span class="keyword">;<br />use </span><span class="default">NonExistingNamespace</span><span class="keyword">\</span><span class="default">NonExsistingClass</span><span class="keyword">;<br />use </span><span class="default">NonExistingNamespace</span><span class="keyword">\</span><span class="default">NonExsistingClass </span><span class="keyword">as </span><span class="default">whatever</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />None of above will actually cause errors unless you actually try to use class you tried to import. <br /><br /><span class="default">&lt;?php<br /></span><span class="comment">// And this code will issue standard PHP error for non existing class.<br /></span><span class="keyword">use </span><span class="default">ExistingNamespace</span><span class="keyword">\</span><span class="default">NonExsistingClass </span><span class="keyword">as </span><span class="default">whatever</span><span class="keyword">;<br /></span><span class="default">$whatever </span><span class="keyword">= new </span><span class="default">whatever</span><span class="keyword">();<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="111634">  <div class="votes">
    <div id="Vu111634">
    <a href="/manual/vote-note.php?id=111634&amp;page=language.namespaces.importing&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd111634">
    <a href="/manual/vote-note.php?id=111634&amp;page=language.namespaces.importing&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V111634" title="67% like this...">
    21
    </div>
  </div>
  <a href="#111634" class="name">
  <strong class="user"><em>cl</em></strong></a><a class="genanchor" href="#111634"> &para;</a><div class="date" title="2013-03-11 12:59"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom111634">
<div class="phpcode"><code><span class="html">
Something that is not immediately obvious, particular with PHP 5.3, is that namespace resolutions within an import are not resolved recursively.&nbsp; i.e.: if you alias an import and then use that alias in another import then this latter import will not be fully resolved with the former import.<br /><br />For example:<br />use \Controllers as C;<br />use C\First;<br />use C\Last;<br /><br />Both the First and Last namespaces are NOT resolved as \Controllers\First or \Controllers\Last as one might intend.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="110978">  <div class="votes">
    <div id="Vu110978">
    <a href="/manual/vote-note.php?id=110978&amp;page=language.namespaces.importing&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd110978">
    <a href="/manual/vote-note.php?id=110978&amp;page=language.namespaces.importing&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V110978" title="66% like this...">
    22
    </div>
  </div>
  <a href="#110978" class="name">
  <strong class="user"><em>x at d dot a dot r dot k dot REMOVEDOTSANDTHIS dot gray dot org</em></strong></a><a class="genanchor" href="#110978"> &para;</a><div class="date" title="2013-01-02 05:13"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom110978">
<div class="phpcode"><code><span class="html">
You are allowed to "use" the same resource multiple times as long as it is imported under a different alias at each invocation.<br /><br />For example:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">use </span><span class="default">Lend</span><span class="keyword">;<br />use </span><span class="default">Lend</span><span class="keyword">\</span><span class="default">l1</span><span class="keyword">;<br />use </span><span class="default">Lend</span><span class="keyword">\</span><span class="default">l1 </span><span class="keyword">as </span><span class="default">l3</span><span class="keyword">;<br />use </span><span class="default">Lend</span><span class="keyword">\</span><span class="default">l2</span><span class="keyword">;<br />use </span><span class="default">Lend</span><span class="keyword">\</span><span class="default">l1</span><span class="keyword">\</span><span class="default">Keller</span><span class="keyword">;<br />use </span><span class="default">Lend</span><span class="keyword">\</span><span class="default">l1</span><span class="keyword">\</span><span class="default">Keller </span><span class="keyword">as </span><span class="default">Stellar</span><span class="keyword">;<br />use </span><span class="default">Lend</span><span class="keyword">\</span><span class="default">l1</span><span class="keyword">\</span><span class="default">Keller </span><span class="keyword">as </span><span class="default">Zellar</span><span class="keyword">;<br />use </span><span class="default">Lend</span><span class="keyword">\</span><span class="default">l2</span><span class="keyword">\</span><span class="default">Keller </span><span class="keyword">as </span><span class="default">Dellar</span><span class="keyword">;<br /><br />...<br /><br /></span><span class="default">?&gt;<br /></span><br />In the above example, "Keller", "Stellar", and "Zellar" are all references to "\Lend\l1\Keller", as are "Lend\l1\Keller", "l1\Keller", and "l3\Keller".</span>
</code></div>
  </div>
 </div>
  <div class="note" id="105394">  <div class="votes">
    <div id="Vu105394">
    <a href="/manual/vote-note.php?id=105394&amp;page=language.namespaces.importing&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd105394">
    <a href="/manual/vote-note.php?id=105394&amp;page=language.namespaces.importing&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V105394" title="65% like this...">
    23
    </div>
  </div>
  <a href="#105394" class="name">
  <strong class="user"><em>c dot 1 at smithies dot org</em></strong></a><a class="genanchor" href="#105394"> &para;</a><div class="date" title="2011-08-14 03:26"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom105394">
<div class="phpcode"><code><span class="html">
If you are testing your code at the CLI, note that namespace aliases do not work!<br /><br />(Before I go on, all the backslashes in this example are changed to percent signs because I cannot get sensible results to display in the posting preview otherwise. Please mentally translate all percent signs henceforth as backslashes.)<br /><br />Suppose you have a class you want to test in myclass.php:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">namespace </span><span class="default">my</span><span class="keyword">%</span><span class="default">space</span><span class="keyword">;<br />class </span><span class="default">myclass </span><span class="keyword">{<br /> </span><span class="comment">// ...<br /></span><span class="keyword">}<br /></span><span class="default">?&gt;<br /></span><br />and you then go into the CLI to test it. You would like to think that this would work, as you type it line by line:<br /><br />require 'myclass.php';<br />use my%space%myclass; // should set 'myclass' as alias for 'my%space%myclass'<br />$x = new myclass; // FATAL ERROR<br /><br />I believe that this is because aliases are only resolved at compile time, whereas the CLI simply evaluates statements; so use statements are ineffective in the CLI.<br /><br />If you put your test code into test.php:<br /><span class="default">&lt;?php<br /></span><span class="keyword">require </span><span class="string">'myclass.php'</span><span class="keyword">;<br />use </span><span class="default">my</span><span class="keyword">%</span><span class="default">space</span><span class="keyword">%</span><span class="default">myclass</span><span class="keyword">;<br /></span><span class="default">$x </span><span class="keyword">= new </span><span class="default">myclass</span><span class="keyword">;<br /></span><span class="comment">//...<br /></span><span class="default">?&gt;<br /></span>it will work fine.<br /><br />I hope this reduces the number of prematurely bald people.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120644">  <div class="votes">
    <div id="Vu120644">
    <a href="/manual/vote-note.php?id=120644&amp;page=language.namespaces.importing&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120644">
    <a href="/manual/vote-note.php?id=120644&amp;page=language.namespaces.importing&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120644" title="69% like this...">
    5
    </div>
  </div>
  <a href="#120644" class="name">
  <strong class="user"><em>ZhangLiang</em></strong></a><a class="genanchor" href="#120644"> &para;</a><div class="date" title="2017-02-15 06:16"><strong>9 months ago</strong></div>
  <div class="text" id="Hcom120644">
<div class="phpcode"><code><span class="html">
In Chinese,there is an error in translation:<br />// 如果不使用 "use \ArrayObject" ，则实例化一个 foo\ArrayObject 对象<br />it should be<br />// 如果不使用 "use ArrayObject" ，则实例化一个 foo\ArrayObject 对象<br /><br />/*********************************************/<br />中文下翻译有错误<br />// 如果不使用 "use \ArrayObject" ，则实例化一个 foo\ArrayObject 对象<br />这句话应该是<br />// 如果不使用 "use ArrayObject" ，则实例化一个 foo\ArrayObject 对象</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119970">  <div class="votes">
    <div id="Vu119970">
    <a href="/manual/vote-note.php?id=119970&amp;page=language.namespaces.importing&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119970">
    <a href="/manual/vote-note.php?id=119970&amp;page=language.namespaces.importing&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119970" title="58% like this...">
    2
    </div>
  </div>
  <a href="#119970" class="name">
  <strong class="user"><em>ultimater at gmail dot com</em></strong></a><a class="genanchor" href="#119970"> &para;</a><div class="date" title="2016-09-30 10:53"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119970">
<div class="phpcode"><code><span class="html">
Note that "use" importing/aliasing only applies to the current namespace block.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">namespace </span><span class="default">SuperCoolLibrary<br /></span><span class="keyword">{<br />&nbsp; &nbsp; class </span><span class="default">Meta<br />&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; static public function </span><span class="default">getVersion</span><span class="keyword">()<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">'2.7.1'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />}<br /><br />namespace<br />{<br />&nbsp; &nbsp; use </span><span class="default">SuperCoolLibrary</span><span class="keyword">\</span><span class="default">Meta</span><span class="keyword">;<br />&nbsp; &nbsp; echo </span><span class="default">Meta</span><span class="keyword">::</span><span class="default">getVersion</span><span class="keyword">();</span><span class="comment">//outputs 2.7.1<br /></span><span class="keyword">}<br /><br />namespace<br />{<br />&nbsp; &nbsp; echo </span><span class="default">Meta</span><span class="keyword">::</span><span class="default">getVersion</span><span class="keyword">();</span><span class="comment">//fatal error<br /></span><span class="keyword">}<br /><br /></span><span class="default">?&gt;<br /></span><br />To get the expected behavior, you'd use:<br />class_alias('SuperCoolLibrary\Meta','Meta');</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116852">  <div class="votes">
    <div id="Vu116852">
    <a href="/manual/vote-note.php?id=116852&amp;page=language.namespaces.importing&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116852">
    <a href="/manual/vote-note.php?id=116852&amp;page=language.namespaces.importing&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116852" title="57% like this...">
    3
    </div>
  </div>
  <a href="#116852" class="name">
  <strong class="user"><em>kelerest123 at gmail dot com</em></strong></a><a class="genanchor" href="#116852"> &para;</a><div class="date" title="2015-03-10 05:50"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom116852">
<div class="phpcode"><code><span class="html">
For the fifth example (example #5):<br /><br />When in block scope, it is not an illegal use of use keyword, because it is used for sharing things with traits.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="111835">  <div class="votes">
    <div id="Vu111835">
    <a href="/manual/vote-note.php?id=111835&amp;page=language.namespaces.importing&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd111835">
    <a href="/manual/vote-note.php?id=111835&amp;page=language.namespaces.importing&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V111835" title="54% like this...">
    3
    </div>
  </div>
  <a href="#111835" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#111835"> &para;</a><div class="date" title="2013-04-03 10:02"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom111835">
<div class="phpcode"><code><span class="html">
The last example on this page shows a possibly incorrect attempt of aliasing, but it is totally correct to import a trait \Languages\Languages\Danish.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="101199">  <div class="votes">
    <div id="Vu101199">
    <a href="/manual/vote-note.php?id=101199&amp;page=language.namespaces.importing&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd101199">
    <a href="/manual/vote-note.php?id=101199&amp;page=language.namespaces.importing&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V101199" title="52% like this...">
    2
    </div>
  </div>
  <a href="#101199" class="name">
  <strong class="user"><em>thinice at gmail.com</em></strong></a><a class="genanchor" href="#101199"> &para;</a><div class="date" title="2010-12-01 10:07"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom101199">
<div class="phpcode"><code><span class="html">
Because imports happen at compile time, there's no polymorphism potential by embedding the use keyword in a conditonal.<br /><br />e.g.:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">if (</span><span class="default">$objType </span><span class="keyword">== </span><span class="string">'canine'</span><span class="keyword">) {<br />&nbsp; use </span><span class="default">Animal</span><span class="keyword">\</span><span class="default">Canine </span><span class="keyword">as </span><span class="default">Beast</span><span class="keyword">;<br />}<br />if (</span><span class="default">$objType </span><span class="keyword">== </span><span class="string">'bovine'</span><span class="keyword">) {<br />&nbsp; use </span><span class="default">Animal</span><span class="keyword">\</span><span class="default">Bovine </span><span class="keyword">as </span><span class="default">Beast</span><span class="keyword">;<br />}<br /><br /></span><span class="default">$oBeast </span><span class="keyword">= new </span><span class="default">Beast</span><span class="keyword">;<br /></span><span class="default">$oBeast</span><span class="keyword">-&gt;</span><span class="default">feed</span><span class="keyword">();<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121785">  <div class="votes">
    <div id="Vu121785">
    <a href="/manual/vote-note.php?id=121785&amp;page=language.namespaces.importing&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121785">
    <a href="/manual/vote-note.php?id=121785&amp;page=language.namespaces.importing&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121785" title="50% like this...">
    0
    </div>
  </div>
  <a href="#121785" class="name">
  <strong class="user"><em>Mawia HL</em></strong></a><a class="genanchor" href="#121785"> &para;</a><div class="date" title="2017-10-21 05:03"><strong>1 month ago</strong></div>
  <div class="text" id="Hcom121785">
<div class="phpcode"><code><span class="html">
Here is a handy way of importing classes, functions and conts using a single use keyword:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">use </span><span class="default">Mizo</span><span class="keyword">\</span><span class="default">Web</span><span class="keyword">\ {<br />&nbsp;&nbsp; </span><span class="default">Php</span><span class="keyword">\</span><span class="default">WebSite</span><span class="keyword">,<br />&nbsp;&nbsp; </span><span class="default">Php</span><span class="keyword">\</span><span class="default">KeyWord</span><span class="keyword">,<br />&nbsp;&nbsp; </span><span class="default">Php</span><span class="keyword">\</span><span class="default">UnicodePrint</span><span class="keyword">,<br />&nbsp;&nbsp; </span><span class="default">JS</span><span class="keyword">\</span><span class="default">JavaScript</span><span class="keyword">, <br />&nbsp;&nbsp; function </span><span class="default">JS</span><span class="keyword">\</span><span class="default">printTotal</span><span class="keyword">, <br />&nbsp;&nbsp; function </span><span class="default">JS</span><span class="keyword">\</span><span class="default">printList</span><span class="keyword">, <br />&nbsp;&nbsp; const </span><span class="default">JS</span><span class="keyword">\</span><span class="default">BUAIKUM</span><span class="keyword">, <br />&nbsp;&nbsp; const </span><span class="default">JS</span><span class="keyword">\</span><span class="default">MAUTAM<br /></span><span class="keyword">};<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="98908">  <div class="votes">
    <div id="Vu98908">
    <a href="/manual/vote-note.php?id=98908&amp;page=language.namespaces.importing&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd98908">
    <a href="/manual/vote-note.php?id=98908&amp;page=language.namespaces.importing&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V98908" title="48% like this...">
    -2
    </div>
  </div>
  <a href="#98908" class="name">
  <strong class="user"><em>nsdhami at live dot jp</em></strong></a><a class="genanchor" href="#98908"> &para;</a><div class="date" title="2010-07-15 02:01"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom98908">
<div class="phpcode"><code><span class="html">
The "use" keyword can not be declared inside the function or method. It should be declared as global, after the "namespace" as:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">namespace </span><span class="default">mydir</span><span class="keyword">;<br /><br /></span><span class="comment">// works perfectly<br /></span><span class="keyword">use </span><span class="default">mydir</span><span class="keyword">/</span><span class="default">subdir</span><span class="keyword">/</span><span class="default">Class1 </span><span class="keyword">as </span><span class="default">Class1</span><span class="keyword">;<br /><br />function </span><span class="default">fun1</span><span class="keyword">()<br />{<br />&nbsp; &nbsp; </span><span class="comment">// Parse error: syntax error, unexpected T_USE<br />&nbsp; &nbsp; </span><span class="keyword">use </span><span class="default">mydir</span><span class="keyword">/</span><span class="default">subdir</span><span class="keyword">/</span><span class="default">Class1 </span><span class="keyword">as </span><span class="default">Class1</span><span class="keyword">;<br />}<br /><br />class </span><span class="default">Class2<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">fun2</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Parse error: syntax error, unexpected T_USE<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">use </span><span class="default">mydir</span><span class="keyword">/</span><span class="default">subdir</span><span class="keyword">/</span><span class="default">Class1 </span><span class="keyword">as </span><span class="default">Class1</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117334">  <div class="votes">
    <div id="Vu117334">
    <a href="/manual/vote-note.php?id=117334&amp;page=language.namespaces.importing&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117334">
    <a href="/manual/vote-note.php?id=117334&amp;page=language.namespaces.importing&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117334" title="43% like this...">
    -3
    </div>
  </div>
  <a href="#117334" class="name">
  <strong class="user"><em>sernuzh at gmail dot com</em></strong></a><a class="genanchor" href="#117334"> &para;</a><div class="date" title="2015-05-23 07:18"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117334">
<div class="phpcode"><code><span class="html">
You'll get here the <br />Fatal error: Cannot declare class others\name because the name is already in use<br />So you can't get two classes &lt;name&gt; inside one namespace<br /><span class="default">&lt;?php<br /></span><span class="keyword">namespace </span><span class="default">my </span><span class="keyword">{<br />class </span><span class="default">name </span><span class="keyword">{<br />public function </span><span class="default">__construct</span><span class="keyword">(){<br />echo </span><span class="string">'my_namespace_object'</span><span class="keyword">;<br />}<br />}<br />}<br />namespace </span><span class="default">others</span><span class="keyword">{<br />use </span><span class="default">my</span><span class="keyword">\</span><span class="default">name</span><span class="keyword">;<br />class </span><span class="default">name </span><span class="keyword">{<br />public function </span><span class="default">__construct</span><span class="keyword">(){<br />echo </span><span class="string">'others_namespace_object'</span><span class="keyword">;<br />}<br />}<br /></span><span class="default">$newObject </span><span class="keyword">= new </span><span class="default">name</span><span class="keyword">();<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="108625">  <div class="votes">
    <div id="Vu108625">
    <a href="/manual/vote-note.php?id=108625&amp;page=language.namespaces.importing&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd108625">
    <a href="/manual/vote-note.php?id=108625&amp;page=language.namespaces.importing&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V108625" title="44% like this...">
    -5
    </div>
  </div>
  <a href="#108625" class="name">
  <strong class="user"><em>samuel dot roze at gmail dot com</em></strong></a><a class="genanchor" href="#108625"> &para;</a><div class="date" title="2012-05-11 01:34"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom108625">
<div class="phpcode"><code><span class="html">
(All the backslashes in namespaces are slashes because I can't figure out how to post backslashes here.)<br /><br />You can have the same "use" for a class and a namespace. For example, if you have these files:<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">// foo/bar.php<br /></span><span class="keyword">namespace </span><span class="default">foo</span><span class="keyword">;<br /><br />class </span><span class="default">bar<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">__toString </span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">'foo\bar\__toString()'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br /><span class="default">&lt;?php<br /></span><span class="comment">// foo/bar/MyClass.php<br /></span><span class="keyword">namespace </span><span class="default">foo</span><span class="keyword">/</span><span class="default">bar</span><span class="keyword">;<br /><br />class </span><span class="default">MyClass<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">__toString </span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">'foo\bar\MyClass\__toString()'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />In another namespace, you can do:<br /><span class="default">&lt;?php<br /></span><span class="keyword">namespace </span><span class="default">another</span><span class="keyword">;<br />require_once </span><span class="string">'foo/bar.php'</span><span class="keyword">;<br />require_once </span><span class="string">'foo/bar/MyClass.php'</span><span class="keyword">;<br /><br />use </span><span class="default">foo</span><span class="keyword">/</span><span class="default">bar</span><span class="keyword">;<br /><br /></span><span class="default">$bar </span><span class="keyword">= new </span><span class="default">bar</span><span class="keyword">();<br />echo </span><span class="default">$bar</span><span class="keyword">.</span><span class="string">"\n"</span><span class="keyword">;<br /><br /></span><span class="default">$class </span><span class="keyword">= new </span><span class="default">bar</span><span class="keyword">/</span><span class="default">MyClass</span><span class="keyword">();<br />echo </span><span class="default">$class</span><span class="keyword">.</span><span class="string">"\n"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />And it will makes the following output:<br />foo\bar\__toString()<br />foo\bar\MyClass\__toString()</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119920">  <div class="votes">
    <div id="Vu119920">
    <a href="/manual/vote-note.php?id=119920&amp;page=language.namespaces.importing&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119920">
    <a href="/manual/vote-note.php?id=119920&amp;page=language.namespaces.importing&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119920" title="20% like this...">
    -3
    </div>
  </div>
  <a href="#119920" class="name">
  <strong class="user"><em>dominic_mayers at yahoo dot com</em></strong></a><a class="genanchor" href="#119920"> &para;</a><div class="date" title="2016-09-20 11:18"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119920">
<div class="phpcode"><code><span class="html">
To clarify the distinction between inserting a trait in a class and importing a trait in a namespace, here is an example where we first import and then insert a trait. <br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">namespace </span><span class="default">ns1</span><span class="keyword">;<br />trait </span><span class="default">T </span><span class="keyword">{<br />&nbsp; static </span><span class="default">$a </span><span class="keyword">= </span><span class="string">"In T"</span><span class="keyword">;<br />}<br /><br />namespace </span><span class="default">ns2</span><span class="keyword">;<br />use </span><span class="default">ns1</span><span class="keyword">\</span><span class="default">T</span><span class="keyword">; </span><span class="comment">// Importing the name of trait ns1\T&nbsp; in the namespace ns2<br /></span><span class="keyword">class </span><span class="default">C </span><span class="keyword">{ <br />&nbsp; use </span><span class="default">T</span><span class="keyword">; </span><span class="comment">// Inserting trait T in the class C, making use of the imported name. <br /></span><span class="keyword">}&nbsp; <br /><br />namespace </span><span class="default">main</span><span class="keyword">;<br />use </span><span class="default">ns2</span><span class="keyword">\</span><span class="default">C</span><span class="keyword">;<br />echo </span><span class="default">C</span><span class="keyword">::</span><span class="default">$a</span><span class="keyword">; </span><span class="comment">// In T;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="101792">  <div class="votes">
    <div id="Vu101792">
    <a href="/manual/vote-note.php?id=101792&amp;page=language.namespaces.importing&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd101792">
    <a href="/manual/vote-note.php?id=101792&amp;page=language.namespaces.importing&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V101792" title="30% like this...">
    -24
    </div>
  </div>
  <a href="#101792" class="name">
  <strong class="user"><em>Jan Tvrdk</em></strong></a><a class="genanchor" href="#101792"> &para;</a><div class="date" title="2011-01-11 06:26"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom101792">
<div class="phpcode"><code><span class="html">
Importing and aliasing an interface name is also supported.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116707">  <div class="votes">
    <div id="Vu116707">
    <a href="/manual/vote-note.php?id=116707&amp;page=language.namespaces.importing&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116707">
    <a href="/manual/vote-note.php?id=116707&amp;page=language.namespaces.importing&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116707" title="16% like this...">
    -33
    </div>
  </div>
  <a href="#116707" class="name">
  <strong class="user"><em>Dr. Gianluigi &amp;#34;Zane&amp;#34; Zanettini</em></strong></a><a class="genanchor" href="#116707"> &para;</a><div class="date" title="2015-02-13 01:33"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom116707">
<div class="phpcode"><code><span class="html">
I was attempting to use something like this:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">use </span><span class="default">$my_variable_namespace<br />?&gt;<br /></span><br />This is not supported. I did this instead:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">if(..)<br />&nbsp; &nbsp; use </span><span class="default">My</span><span class="keyword">\</span><span class="default">First</span><span class="keyword">\Namespace;<br />else<br />&nbsp; &nbsp; use </span><span class="default">My</span><span class="keyword">\</span><span class="default">Other</span><span class="keyword">\Namespace;<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.namespaces.importing&amp;redirect=http://php.net/manual/en/language.namespaces.importing.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.namespaces.php">Namespaces</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.namespaces.rationale.php" title="Namespaces overview">Namespaces overview</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.definition.php" title="Defining namespaces">Defining namespaces</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.nested.php" title="Declaring sub-&#8203;namespaces">Declaring sub-&#8203;namespaces</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.definitionmultiple.php" title="Defining multiple namespaces in the same file">Defining multiple namespaces in the same file</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.basics.php" title="Using namespaces: Basics">Using namespaces: Basics</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.dynamic.php" title="Namespaces and dynamic language features">Namespaces and dynamic language features</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.nsconstants.php" title="namespace keyword and _&#8203;_&#8203;NAMESPACE_&#8203;_&#8203; constant">namespace keyword and _&#8203;_&#8203;NAMESPACE_&#8203;_&#8203; constant</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.namespaces.importing.php" title="Using namespaces: Aliasing/Importing">Using namespaces: Aliasing/Importing</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.global.php" title="Global space">Global space</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.fallback.php" title="Using namespaces: fallback to global function/constant">Using namespaces: fallback to global function/constant</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.rules.php" title="Name resolution rules">Name resolution rules</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.faq.php" title="FAQ: things you need to know about namespaces">FAQ: things you need to know about namespaces</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

