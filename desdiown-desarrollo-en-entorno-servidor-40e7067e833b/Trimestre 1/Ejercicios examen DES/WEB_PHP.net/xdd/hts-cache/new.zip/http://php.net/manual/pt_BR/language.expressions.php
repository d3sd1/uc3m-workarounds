<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="pt_BR">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Express&otilde;es - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/pt_BR/language.expressions.php">
 <link rel="shorturl" href="http://php.net/expressions">
 <link rel="alternate" href="http://php.net/expressions" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/pt_BR/index.php">
 <link rel="index" href="http://php.net/manual/pt_BR/langref.php">
 <link rel="prev" href="http://php.net/manual/pt_BR/language.constants.predefined.php">
 <link rel="next" href="http://php.net/manual/pt_BR/language.operators.php">

 <link rel="alternate" href="http://php.net/manual/en/language.expressions.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.expressions.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.expressions.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.expressions.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.expressions.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.expressions.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.expressions.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.expressions.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.expressions.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.expressions.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/pt_BR/language.expressions.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.operators.php">
          Operadores &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.constants.predefined.php">
          &laquo; Constantes M&aacute;gicas        </a>
      </div>
          <ul>
            <li><a href='index.php'>Manual do PHP</a></li>      <li><a href='langref.php'>Refer&ecirc;ncia da Linguagem</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.expressions.php'>English</option>
            <option value='pt_BR/language.expressions.php' selected="selected">Brazilian Portuguese</option>
            <option value='zh/language.expressions.php'>Chinese (Simplified)</option>
            <option value='fr/language.expressions.php'>French</option>
            <option value='de/language.expressions.php'>German</option>
            <option value='ja/language.expressions.php'>Japanese</option>
            <option value='ro/language.expressions.php'>Romanian</option>
            <option value='ru/language.expressions.php'>Russian</option>
            <option value='es/language.expressions.php'>Spanish</option>
            <option value='tr/language.expressions.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=pt_BR/language.expressions.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.expressions">Report a Bug</a>
    </div>
  </div><div id="language.expressions" class="chapter">
   <h1>Expressões</h1>

   <p class="simpara">
    Expressões são as peças de construção mais importantes do PHP. No PHP,
    quase tudo o que você escreve são expressões. A maneira mais simples e ainda
    mais precisa de definir uma expressão é &quot;tudo o que tem um
    valor&quot;.
   </p>
   <p class="simpara">
    As formas mais básicas de expressões são constantes e variáveis.
    Quando você digita &quot;<var class="varname"><var class="varname">$a</var></var> = 5&quot;, você está atribuindo &#039;5&#039; dentro de
    <var class="varname"><var class="varname">$a</var></var>. &#039;5&#039; obviamente
    tem o valor 5, ou em outras palavras &#039;5&#039; é uma expressão com o
    valor de 5 (nesse caso &#039;5&#039; é uma constante inteira).
   </p>
   <p class="simpara">
    Depois desta atribuição, você pode esperar que o valor de <var class="varname"><var class="varname">$a</var></var> seja 5
    também, assim se você escrever <var class="varname"><var class="varname">$b</var></var> = <var class="varname"><var class="varname">$a</var></var>, você pode esperar que <var class="varname"><var class="varname">$b</var></var> se comporte
    da mesma forma que se você escrevesse <var class="varname"><var class="varname">$b</var></var> = 5. Em outras palavras, <var class="varname"><var class="varname">$a</var></var> é uma expressão com
    valor 5 também. Se tudo funcionou bem isto é
    exatamente o que acontecerá.
   </p>
   <p class="para">
    Exemplos ligeiramente mais complexos para expressões são as funções. Por exemplo,
    considere a seguinte função:
    <div class="informalexample">
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">foo&nbsp;</span><span style="color: #007700">()<br />{<br />&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">5</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>
   <p class="simpara">
    Assumindo que você está familiarizado com o conceito de funções (se não estiver,
    dê uma olhada no capítulo sobre <a href="language.functions.php" class="link">functions</a>), você pode assumir que digitar
    <em>$c = foo()</em> é essencialmente a mesma coisa que escrever
    <em>$c = 5</em>, e você está certo. Funções são expressões com o valor
    igual ao seu valor de retorno. Como foo() retorna 5, o valor da expressão
    &#039;foo()&#039; é 5. Geralmente, as funções não retornam apenas um valor estático, mas
    computam algo.
   </p>
   <p class="simpara">
    Claro, valores em PHP não tem que ser inteiros, e muito comumente
    eles não são. o PHP suporta quatro tipos de valores escalares: valores <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span>
    (inteiros), valores de ponto flutuante (<span class="type"><a href="language.types.float.php" class="type float">float</a></span>), valores <span class="type"><a href="language.types.string.php" class="type string">string</a></span>
    (caracteres) e valores <span class="type"><a href="language.types.boolean.php" class="type boolean">boolean</a></span> (booleano) (valores escalares são valores que
    você não pode partir em peças menores, diferentemente de matrizes, por exemplo). O PHP também
    suporta dois tipos compostos (não escalar): matrizes e objetos. Cada um desses
    valores podem ser definidos em uma variável ou retornados de uma função.
   </p>
   <p class="simpara">
    O PHP leva as expressões muito além, da mesma maneira que muitas outras linguagens
    fazem. O PHP é uma linguagem orientada a expressões, no
    sentido de que quase tudo são expressões. Considere o
    exemplo com o qual já lidamos, &#039;<var class="varname"><var class="varname">$a</var></var> = 5&#039;. É fácil ver que
    há dois valores envolvidos aqui, o valor da constante inteira
    &#039;5&#039;, e o valor de <var class="varname"><var class="varname">$a</var></var> que está sendo atualizado para 5
    também. Mas a verdade é que há um valor adicional envolvido
    aqui, e que é o próprio valor da atribuição. A
    própria atribuição é avaliada com o valor atribuído, neste caso 5.
    Na prática, significa que &#039;<var class="varname"><var class="varname">$a</var></var> = 5&#039;, independente do que faça,
    é uma expressão com o valor 5. Portanto, escrever algo como
    &#039;<var class="varname"><var class="varname">$b</var></var> = (<var class="varname"><var class="varname">$a</var></var> = 5)&#039; é como escrever
    &#039;<var class="varname"><var class="varname">$a</var></var> = 5; <var class="varname"><var class="varname">$b</var></var> = 5;&#039; (um ponto-e-vírgula
    marca o fim do comando). Como atribuições são analisadas
    da direita para a esquerda, você também pode escrever &#039;<var class="varname"><var class="varname">$b</var></var> = <var class="varname"><var class="varname">$a</var></var> = 5&#039;.
   </p>
   <p class="simpara">
    Outro bom exemplo de orientação de expressão é o pré e
    o pós-incremento e decremento. Usuários de PHP 2 e muitas outras
    linguagens podem estar familiarizados com a notação de <em>variable++</em> e
    <em>variable--</em>. Este são <a href="language.operators.increment.php" class="link">
    operadores de incremento e decrimento</a>. Em PHP, como em C, há
    dois tipos de incremento - pré-incremento e pós-incremento.
    Tanto o pré-incremento quanto o pós-incremento, essencialmente, incrementam
    as variáveis, e o efeito sobre a variável é idêntico. A
    diferença é com o valor da expressão de incremento.
    O pré-incremento, que é escrito &#039;++<var class="varname"><var class="varname">$variable</var></var>&#039;, é avaliado
    como o valor de incremento (o PHP incrementa a variável antes
    de ler seu valor, por isso o nome pré-incremento). O pós-incremento, que é
    escrito &#039;<var class="varname"><var class="varname">$variable</var></var>++&#039; é avaliado como o valor original da
    variável, antes de ser incrementada (o PHP incrementa a variável
    depois de ler seu valor, por isso o nome &#039;pós-incremento&#039;).
   </p>
   <p class="simpara">
    Um tipo muito comum de expressões são expressões de <a href="language.operators.comparison.php" class="link">comparação</a>.
    Estas expressões avaliam para ser <strong><code>FALSE</code></strong> ou <strong><code>TRUE</code></strong>. O PHP
    suporta &gt; (maior que), &gt;= (maior ou igual a), == (igual),
    != (diferente), &lt; (menor que) and &lt;= (menor ou igual a).
    A linguagem também suporta um conjunto de operador de equivalencia estrita: ===
    (igual a e do mesmo tipo) and !== (diferente de ou não do mesmo tipo).
    Estas expressões são mais comumente usada dentro de execução condicional
    como comandos <em>if</em>.
   </p>
   <p class="simpara">
    O último exemplo de expressões com que nós vamos lidar aqui são as expressões combinadas
    operador-atribuição. Você já sabe que se você
    quer incrementar <var class="varname"><var class="varname">$a</var></var> de 1, você só precisa escrever
    &#039;<var class="varname"><var class="varname">$a</var></var>++&#039; ou &#039;++<var class="varname"><var class="varname">$a</var></var>&#039;.
    Mas e se você quiser somar mais que um a ele, por exemplo 3?
    Você poderia escrever &#039;<var class="varname"><var class="varname">$a</var></var>++&#039; várias vezes, mas esta
    obviamente não é uma forma muito eficiente ou confortável. Uma prática muito
    mais comum é escrever &#039;<var class="varname"><var class="varname">$a</var></var> =
    <var class="varname"><var class="varname">$a</var></var> + 3&#039;. &#039;<var class="varname"><var class="varname">$a</var></var> + 3&#039; é avaliada
    como o valor de <var class="varname"><var class="varname">$a</var></var> mais 3, e é atribuído de volta
    a <var class="varname"><var class="varname">$a</var></var>, que resulta em incrementar <var class="varname"><var class="varname">$a</var></var>
    em 3. Em PHP, como em várias outras linguagens como o C você pode escrever isto
    de uma forma mais curta, que com o tempo se torna mais limpa e rápida de se
    entender. Somar 3 ao valor corrente de <var class="varname"><var class="varname">$a</var></var>
    pode ser escrito &#039;<var class="varname"><var class="varname">$a</var></var> +=3&#039;. Isto significa exatamente
    &quot;pegue o valor de <var class="varname"><var class="varname">$a</var></var>, some 3 a ele, e atribua-o
    de volta a <var class="varname"><var class="varname">$a</var></var>.&quot; Além de ser mais curto e mais
    limpo, isto também resulta em execução mais rápida. O valor de
    &#039;<var class="varname"><var class="varname">$a</var></var> += 3&#039;, como o valor de uma atribuição regular, é
    o valor atribuído. Note que NÃO é 3, mas o valor combinado de
    <var class="varname"><var class="varname">$a</var></var> mais 3 (este é o valor que
    é atribuído a <var class="varname"><var class="varname">$a</var></var>). Qualquer operador de dois parâmetros pode ser usado
    neste modo operador-atribuição, por exemplo &#039;<var class="varname"><var class="varname">$a</var></var> -= 5&#039;
    (subtrai 5 do valor de <var class="varname"><var class="varname">$a</var></var>), &#039;<var class="varname"><var class="varname">$b</var></var> *= 7&#039;
    (multiplica o valor de <var class="varname"><var class="varname">$b</var></var> por 7), etc.
   </p>
   <p class="para">
    Há mais uma expressão que podem parecer estranha se você não a viu em outras linguagens,
    o operador condicional ternário:
   </p>
   <p class="para">
    <div class="informalexample">
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$primeira&nbsp;</span><span style="color: #007700">?&nbsp;</span><span style="color: #0000BB">$segunda&nbsp;</span><span style="color: #007700">:&nbsp;</span><span style="color: #0000BB">$terceira<br />?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>
   <p class="para">
    Se o valor da primeira sub-expressão é verdadeiro (<strong><code>TRUE</code></strong>, não-zero), então
    a segunda sub-expressão é avaliada, e este é o resultado da
    expressão condicional. Caso contrário, a terceira sub-expressão é
    avaliada e este é o valor.
   </p>
   <p class="para">
    O seguinte exemplo deve ajudá-lo a entender um pouco melhor pré e
    pós-incremento e expressões em geral:
   </p>
   <p class="para">
    <div class="informalexample">
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">double</span><span style="color: #007700">(</span><span style="color: #0000BB">$i</span><span style="color: #007700">)<br />{<br />&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">$i</span><span style="color: #007700">*</span><span style="color: #0000BB">2</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">$b&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">5</span><span style="color: #007700">;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">/*&nbsp;atribui&nbsp;o&nbsp;valor&nbsp;cinco&nbsp;às&nbsp;variáveis&nbsp;$a&nbsp;e&nbsp;$b&nbsp;*/<br /></span><span style="color: #0000BB">$c&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$a</span><span style="color: #007700">++;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">/*&nbsp;pós-incremento,&nbsp;atribui&nbsp;o&nbsp;valor&nbsp;original&nbsp;de&nbsp;$a<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(5)&nbsp;para&nbsp;$c&nbsp;*/<br /></span><span style="color: #0000BB">$e&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$d&nbsp;</span><span style="color: #007700">=&nbsp;++</span><span style="color: #0000BB">$b</span><span style="color: #007700">;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">/*&nbsp;pré-incremento,&nbsp;atribui&nbsp;o&nbsp;valor&nbsp;incrementado&nbsp;de<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$b&nbsp;(6)&nbsp;a&nbsp;$d&nbsp;e&nbsp;$e&nbsp;*/<br /><br />/*&nbsp;neste&nbsp;ponto,&nbsp;tanto&nbsp;$d&nbsp;quanto&nbsp;$e&nbsp;são&nbsp;iguais&nbsp;a&nbsp;6&nbsp;*/<br /><br /></span><span style="color: #0000BB">$f&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">double</span><span style="color: #007700">(</span><span style="color: #0000BB">$d</span><span style="color: #007700">++);&nbsp;&nbsp;</span><span style="color: #FF8000">/*&nbsp;atribui&nbsp;o&nbsp;dobro&nbsp;do&nbsp;valor&nbsp;de&nbsp;$d&nbsp;antes<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;do&nbsp;incremento,&nbsp;2*6&nbsp;=&nbsp;12&nbsp;a&nbsp;$f&nbsp;*/<br /></span><span style="color: #0000BB">$g&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">double</span><span style="color: #007700">(++</span><span style="color: #0000BB">$e</span><span style="color: #007700">);&nbsp;&nbsp;</span><span style="color: #FF8000">/*&nbsp;atribui&nbsp;o&nbsp;dobro&nbsp;do&nbsp;valor&nbsp;de&nbsp;$e&nbsp;depois<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;do&nbsp;incremento,&nbsp;2*7&nbsp;=&nbsp;14&nbsp;a&nbsp;$g&nbsp;*/<br /></span><span style="color: #0000BB">$h&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$g&nbsp;</span><span style="color: #007700">+=&nbsp;</span><span style="color: #0000BB">10</span><span style="color: #007700">;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">/*&nbsp;primeiro,&nbsp;$g&nbsp;é&nbsp;incrementado&nbsp;de&nbsp;10&nbsp;e&nbsp;termina&nbsp;com&nbsp;o<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;valor&nbsp;24.&nbsp;o&nbsp;valor&nbsp;da&nbsp;atribuição&nbsp;(24)&nbsp;é<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;então&nbsp;atribuído&nbsp;a&nbsp;$h,&nbsp;e&nbsp;$h&nbsp;termina&nbsp;com&nbsp;o&nbsp;valor<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;24&nbsp;também.&nbsp;*/<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>
   <p class="simpara">
    Algumas expressões podem ser consideradas instruções. Neste
    caso, uma instrução na forma &#039;<em>expr ;</em>&#039; ou seja, uma
    expressão seguida de um ponto e vírgula. Em <em>&#039;$b = $a = 5;&#039;</em>,
    <em>&#039;$a = 5&#039;</em> é uma expressão válida, mas não é um comando
    por si só. <em>&#039;$b = $a = 5;&#039;</em> porém é um comando válido.
   </p>
   <p class="simpara">
    Uma última coisa que vale mencionar é o valor-verdade de expressões.
    Em muitos eventos, principalmente em instruções condicionais e loops, você não
    está interessado no valor específico da expressão, mas somente se ela
    significa <strong><code>TRUE</code></strong> ou <strong><code>FALSE</code></strong> (o PHP não tem um tipo booleano dedicado).

    

    As constantes <strong><code>TRUE</code></strong> e <strong><code>FALSE</code></strong> (insensitivas ao caso) são seus dois
    valores booleanos possíveis. As vezes uma expressão é
    automaticamente convertida para um booleano. Veja a
    <a href="language.types.type-juggling.php#language.types.typecasting" class="link">seção sobre
    type-casting</a> para detalhes de como isso é feito.
   </p>
   <p class="simpara">
    O PHP fornece uma implementação completa e poderosa de expressões, e a completa
    documentação dela vai além do escopo deste manual. Os exemplos acima devem dar a
    você uma boa idéia sobre o que são as expressões e como você pode construir
    expressões úteis. Através do restante do manual nós escreveremos
    <var class="varname"><var class="varname">expr</var></var> ou <var class="varname"><var class="varname">expressao</var></var>
    para indicar qualquer expressão PHP válida.
   </p>
  </div>

<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.expressions&amp;redirect=http://php.net/manual/pt_BR/language.expressions.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">21 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="11883">  <div class="votes">
    <div id="Vu11883">
    <a href="/manual/vote-note.php?id=11883&amp;page=language.expressions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd11883">
    <a href="/manual/vote-note.php?id=11883&amp;page=language.expressions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V11883" title="67% like this...">
    25
    </div>
  </div>
  <a href="#11883" class="name">
  <strong class="user"><em>yasuo_ohgaki at hotmail dot com</em></strong></a><a class="genanchor" href="#11883"> &para;</a><div class="date" title="2001-03-11 11:14"><strong>16 years ago</strong></div>
  <div class="text" id="Hcom11883">
<div class="phpcode"><code><span class="html">
Manual defines "expression is anything that has value", Therefore, parser will give error for following code.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">(</span><span class="default">$val</span><span class="keyword">) ? echo(</span><span class="string">'true'</span><span class="keyword">) : echo(</span><span class="string">'false'</span><span class="keyword">);<br /></span><span class="default">Note</span><span class="keyword">: </span><span class="string">"? : " </span><span class="default">operator has this syntax&nbsp; </span><span class="string">"expr ? expr : expr;"<br /></span><span class="default">?&gt;<br /></span><br />since echo does not have(return) value and ?: expects expression(value).<br /><br />However, if function/language constructs that have/return value, such as include(), parser compiles code.<br /><br />Note: User defined functions always have/return value without explicit return statement (returns NULL if there is no return statement). Therefore, user defined functions are always valid expressions. <br />[It may be useful to have VOID as new type to prevent programmer to use function as RVALUE by mistake]<br /><br />For example,<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">(</span><span class="default">$val</span><span class="keyword">) ? include(</span><span class="string">'true.inc'</span><span class="keyword">) : include(</span><span class="string">'false.inc'</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />is valid, since "include" returns value.<br /><br />The fact "echo" does not return value(="echo" is not a expression), is less obvious to me. <br /><br />Print() and Echo() is NOT identical since print() has/returns value and can be a valid expression.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="90327">  <div class="votes">
    <div id="Vu90327">
    <a href="/manual/vote-note.php?id=90327&amp;page=language.expressions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd90327">
    <a href="/manual/vote-note.php?id=90327&amp;page=language.expressions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V90327" title="60% like this...">
    26
    </div>
  </div>
  <a href="#90327" class="name">
  <strong class="user"><em>Magnus Deininger, dma05 at web dot de</em></strong></a><a class="genanchor" href="#90327"> &para;</a><div class="date" title="2009-04-16 08:04"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom90327">
<div class="phpcode"><code><span class="html">
Note that even though PHP borrows large portions of its syntax from C, the ',' is treated quite differently. It's not possible to create combined expressions in PHP using the comma-operator that C has, except in for() loops.<br /><br />Example (parse error):<br /><br /><span class="default">&lt;?php<br /><br />$a </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">, </span><span class="default">$b </span><span class="keyword">= </span><span class="default">4</span><span class="keyword">;<br /><br />echo </span><span class="default">$a</span><span class="keyword">.</span><span class="string">"\n"</span><span class="keyword">;<br />echo </span><span class="default">$b</span><span class="keyword">.</span><span class="string">"\n"</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;<br /></span><br />Example (works):<br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">for (</span><span class="default">$a </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">, </span><span class="default">$b </span><span class="keyword">= </span><span class="default">4</span><span class="keyword">; </span><span class="default">$a </span><span class="keyword">&lt; </span><span class="default">3</span><span class="keyword">; </span><span class="default">$a</span><span class="keyword">++)<br />{<br />&nbsp; echo </span><span class="default">$a</span><span class="keyword">.</span><span class="string">"\n"</span><span class="keyword">;<br />&nbsp; echo </span><span class="default">$b</span><span class="keyword">.</span><span class="string">"\n"</span><span class="keyword">;<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />This is because PHP doesn't actually have a proper comma-operator, it's only supported as syntactic sugar in for() loop headers. In C, it would have been perfectly legitimate to have this:<br /><br />int f()<br />{<br />&nbsp; int a, b;<br />&nbsp; a = 2, b = 4;<br /><br />&nbsp; return a;<br />}<br /><br />or even this:<br /><br />int g()<br />{<br />&nbsp; int a, b;<br />&nbsp; a = (2, b = 4);<br /><br />&nbsp; return a;<br />}<br /><br />In f(), a would have been set to 2, and b would have been set to 4.<br />In g(), (2, b = 4) would be a single expression which evaluates to 4, so both a and b would have been set to 4.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="21750">  <div class="votes">
    <div id="Vu21750">
    <a href="/manual/vote-note.php?id=21750&amp;page=language.expressions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd21750">
    <a href="/manual/vote-note.php?id=21750&amp;page=language.expressions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V21750" title="60% like this...">
    16
    </div>
  </div>
  <a href="#21750" class="name">
  <strong class="user"><em>Mattias at mail dot ee</em></strong></a><a class="genanchor" href="#21750"> &para;</a><div class="date" title="2002-05-25 03:29"><strong>15 years ago</strong></div>
  <div class="text" id="Hcom21750">
<div class="phpcode"><code><span class="html">
A note about the short-circuit behaviour of the boolean operators.<br /><br />1. if (func1() || func2())<br />Now, if func1() returns true, func2() isn't run, since the expression<br />will be true anyway.<br /><br />2. if (func1() &amp;&amp; func2())<br />Now, if func1() returns false, func2() isn't run, since the expression<br />will be false anyway.<br /><br />The reason for this behaviour comes probably from the programming<br />language C, on which PHP seems to be based on. There the<br />short-circuiting can be a very useful tool. For example:<br /><br />int * myarray = a_func_to_set_myarray(); // init the array<br />if (myarray != NULL &amp;&amp; myarray[0] != 4321) // check<br />&nbsp; &nbsp; myarray[0] = 1234;<br /><br />Now, the pointer myarray is checked for being not null, then the<br />contents of the array is validated. This is important, because if<br />you try to access an array whose address is invalid, the program<br />will crash and die a horrible death. But thanks to the short<br />circuiting, if myarray == NULL then myarray[0] won't be accessed,<br />and the program will work fine.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="77291">  <div class="votes">
    <div id="Vu77291">
    <a href="/manual/vote-note.php?id=77291&amp;page=language.expressions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd77291">
    <a href="/manual/vote-note.php?id=77291&amp;page=language.expressions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V77291" title="62% like this...">
    12
    </div>
  </div>
  <a href="#77291" class="name">
  <strong class="user"><em>winks716</em></strong></a><a class="genanchor" href="#77291"> &para;</a><div class="date" title="2007-08-23 01:42"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom77291">
<div class="phpcode"><code><span class="html">
reply to egonfreeman at gmail dot com<br />04-Apr-2007 07:45 <br /><br />the second example u mentioned as follow:<br />=====================================<br /><br />$n = 3;<br />$n * $n++<br /><br />from 3 * 3 into 3 * 4. Post- operations operate on a variable after it has been 'checked', but it doesn't necessarily state that it should happen AFTER an evaluation is over (on the contrary, as a matter of fact).<br /><br />===========================================<br /><br />everything works correctly but one sentence should be modified:<br /><br />"from 3 * 3 into 3 * 4"&nbsp; should be "from 3 * 3 into 4 * 3"<br /><br />best regards~ :)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="112682">  <div class="votes">
    <div id="Vu112682">
    <a href="/manual/vote-note.php?id=112682&amp;page=language.expressions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd112682">
    <a href="/manual/vote-note.php?id=112682&amp;page=language.expressions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V112682" title="60% like this...">
    10
    </div>
  </div>
  <a href="#112682" class="name">
  <strong class="user"><em>chriswarbo at gmail dot com</em></strong></a><a class="genanchor" href="#112682"> &para;</a><div class="date" title="2013-07-12 11:06"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom112682">
<div class="phpcode"><code><span class="html">
Note that there is a difference between a function and a function call, and both<br />are expressions. PHP has two kinds of function, "named functions" and "anonymous<br />functions". Here's an example with both:<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">// A named function. Its name is "double".<br /></span><span class="keyword">function </span><span class="default">double</span><span class="keyword">(</span><span class="default">$x</span><span class="keyword">) {<br />&nbsp; return </span><span class="default">2 </span><span class="keyword">* </span><span class="default">$x</span><span class="keyword">;<br />}<br /><br /></span><span class="comment">// An anonymous function. It has no name, in the same way that the string<br />// "hello" has no name. Since it is an expression, we can give it a temporary<br />// name by assigning it to the variable $triple.<br /></span><span class="default">$triple </span><span class="keyword">= function(</span><span class="default">$x</span><span class="keyword">) {<br />&nbsp; return </span><span class="default">3 </span><span class="keyword">* </span><span class="default">$x</span><span class="keyword">;<br />};<br /></span><span class="default">?&gt;<br /></span><br />We can "call" (or "run") both kinds of function. A "function call" is an<br />expression with the value of whatever the function returns. For example:<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">// The easiest way to run a function is to put () after its name, containing its<br />// arguments (if any)<br /></span><span class="default">$my_numbers </span><span class="keyword">= array(</span><span class="default">double</span><span class="keyword">(</span><span class="default">5</span><span class="keyword">), </span><span class="default">$triple</span><span class="keyword">(</span><span class="default">5</span><span class="keyword">));<br /></span><span class="default">?&gt;<br /></span><br />$my_numbers is now an array containing 10 and 15, which are the return values of<br />double and $triple when applied to the number 5.<br /><br />Importantly, if we *don't* call a function, ie. we don't put () after its name,<br />then we still get expressions. For example:<br /><br /><span class="default">&lt;?php<br />$my_functions </span><span class="keyword">= array(</span><span class="string">'double'</span><span class="keyword">, </span><span class="default">$triple</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />$my_functions is now an array containing these two functions. Notice that named<br />functions are more awkward than anonymous functions. PHP treats them differently<br />because it didn't use to have anonymous functions, and the way named functions<br />were implemented didn't work for anonymous functions when they were eventually<br />added.<br /><br />This means that instead of using a named function literally, like we can with<br />anonymous functions, we have to use a string containing its name instead. PHP<br />makes sure that these strings will be treated as functions when it's<br />appropriate. For example:<br /><br /><span class="default">&lt;?php<br />$temp&nbsp; &nbsp; &nbsp; </span><span class="keyword">= </span><span class="string">'double'</span><span class="keyword">;<br /></span><span class="default">$my_number </span><span class="keyword">= </span><span class="default">$temp</span><span class="keyword">(</span><span class="default">5</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />$my_number will be 10, since PHP has spotted that we're treating a string as if<br />it were a function, so it has looked up that named function for us.<br /><br />Unfortunately PHP's parser is very quirky; rather than looking for generic<br />patterns like "x(y)" and seeing if "x" is a function, it has lots of<br />special-cases like "$x(y)". This makes code like "'double'(5)" invalid, so we<br />have to do tricks like using temporary variables. There is another way around<br />this restriction though, and that is to pass our functions to the<br />"call_user_func" or "call_user_func_array" functions when we want to call them.<br />For example:<br /><br /><span class="default">&lt;?php<br />$my_numbers </span><span class="keyword">= array(</span><span class="default">call_user_func</span><span class="keyword">(</span><span class="string">'double'</span><span class="keyword">, </span><span class="default">5</span><span class="keyword">), </span><span class="default">call_user_func</span><span class="keyword">(</span><span class="default">$triple</span><span class="keyword">, </span><span class="default">5</span><span class="keyword">));<br /></span><span class="default">?&gt;<br /></span><br />$my_numbers contains 10 and 15 because "call_user_func" called our functions for<br />us. This is possible because the string 'double' and the anonymous function<br />$triple are expressions. Note that we can even use this technique to call an<br />anonymous function without ever giving it a name:<br /><br /><span class="default">&lt;?php<br />$my_number </span><span class="keyword">= </span><span class="default">call_user_func</span><span class="keyword">(function(</span><span class="default">$x</span><span class="keyword">) { return </span><span class="default">4 </span><span class="keyword">* </span><span class="default">$x</span><span class="keyword">; }, </span><span class="default">5</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />$my_number is now 20, since "call_user_func" called the anonymous function,<br />which quadruples its argument, with the value 5.<br /><br />Passing functions around as expressions like this is very useful whenever we<br />need to use a 'callback'. Great examples of this are array_map and array_reduce.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120459">  <div class="votes">
    <div id="Vu120459">
    <a href="/manual/vote-note.php?id=120459&amp;page=language.expressions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120459">
    <a href="/manual/vote-note.php?id=120459&amp;page=language.expressions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120459" title="66% like this...">
    1
    </div>
  </div>
  <a href="#120459" class="name">
  <strong class="user"><em>Bichis Paul</em></strong></a><a class="genanchor" href="#120459"> &para;</a><div class="date" title="2017-01-12 03:10"><strong>11 months ago</strong></div>
  <div class="text" id="Hcom120459">
<div class="phpcode"><code><span class="html">
Regarding 12345alex at gmx dot net's example:<br /><br />I think you miss the identical equal documentation line from: <a href="http://php.net/manual/en/language.operators.comparison.php" rel="nofollow" target="_blank">http://php.net/manual/en/language.operators.comparison.php</a> <br /><br />$a == $b&nbsp; &nbsp;&nbsp; Equal&nbsp; &nbsp;&nbsp; TRUE if $a is equal to $b after type juggling.<br />$a === $b&nbsp; &nbsp;&nbsp; Identical&nbsp; &nbsp;&nbsp; TRUE if $a is equal to $b, and they are of the same type. <br /><br />Try: <br />print array() === NULL ? "True" : "False";<br /><br />Check this:<br />var_dump(is_null(array()));</span>
</code></div>
  </div>
 </div>
  <div class="note" id="9801">  <div class="votes">
    <div id="Vu9801">
    <a href="/manual/vote-note.php?id=9801&amp;page=language.expressions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd9801">
    <a href="/manual/vote-note.php?id=9801&amp;page=language.expressions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V9801" title="60% like this...">
    7
    </div>
  </div>
  <a href="#9801" class="name">
  <strong class="user"><em>anthony at n dot o dot s dot p dot a dot m dot trams dot com</em></strong></a><a class="genanchor" href="#9801"> &para;</a><div class="date" title="2000-11-24 11:01"><strong>17 years ago</strong></div>
  <div class="text" id="Hcom9801">
<div class="phpcode"><code><span class="html">
The ternary conditional operator is a useful way of avoiding inconvenient if statements.&nbsp; They can even be used in the middle of a string concatenation, if you use parentheses.&nbsp; <br /><br />Example:<br /><br />if ( $wakka ) {<br />&nbsp; $string = 'foo' ;<br />} else {<br />&nbsp; $string = 'bar' ;<br />}<br /><br />The above can be expressed like the following:<br /><br />$string = $wakka ? 'foo' : 'bar' ;<br /><br />If $wakka is true, $string is assigned 'foo', and if it's false, $string is assigned 'bar'.<br /><br />To do the same in a concatenation, try:<br /><br />$string = $otherString . ( $wakka ? 'foo' : 'bar' ) ;</span>
</code></div>
  </div>
 </div>
  <div class="note" id="78636">  <div class="votes">
    <div id="Vu78636">
    <a href="/manual/vote-note.php?id=78636&amp;page=language.expressions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd78636">
    <a href="/manual/vote-note.php?id=78636&amp;page=language.expressions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V78636" title="60% like this...">
    5
    </div>
  </div>
  <a href="#78636" class="name">
  <strong class="user"><em>petruzanauticoyahoo?com!ar</em></strong></a><a class="genanchor" href="#78636"> &para;</a><div class="date" title="2007-10-20 08:41"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom78636">
<div class="phpcode"><code><span class="html">
Regarding the ternary operator, I would rather say that the best option is to enclose all the expression in parantheses, to avoid errors and improve clarity:<br /><br /><span class="default">&lt;?php<br />&nbsp;&nbsp; </span><span class="keyword">print ( </span><span class="default">$a </span><span class="keyword">&gt; </span><span class="default">1 </span><span class="keyword">? </span><span class="string">"many" </span><span class="keyword">: </span><span class="string">"just one" </span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />PS: for php, C++, and any other language that has it.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="24119">  <div class="votes">
    <div id="Vu24119">
    <a href="/manual/vote-note.php?id=24119&amp;page=language.expressions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd24119">
    <a href="/manual/vote-note.php?id=24119&amp;page=language.expressions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V24119" title="58% like this...">
    5
    </div>
  </div>
  <a href="#24119" class="name">
  <strong class="user"><em>oliver at hankeln-online dot de</em></strong></a><a class="genanchor" href="#24119"> &para;</a><div class="date" title="2002-08-07 06:06"><strong>15 years ago</strong></div>
  <div class="text" id="Hcom24119">
<div class="phpcode"><code><span class="html">
The short-circuiting IS a feature. It is also available in C, so I suppose the developers won�t remove it in future PHP versions.<br /><br />It is rather nice to write:<br /><br />$file=fopen("foo","r") or die("Error!");<br /><br />Greets,<br />Oliver</span>
</code></div>
  </div>
 </div>
  <div class="note" id="81849">  <div class="votes">
    <div id="Vu81849">
    <a href="/manual/vote-note.php?id=81849&amp;page=language.expressions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd81849">
    <a href="/manual/vote-note.php?id=81849&amp;page=language.expressions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V81849" title="56% like this...">
    4
    </div>
  </div>
  <a href="#81849" class="name">
  <strong class="user"><em>denzoo at gmail dot com</em></strong></a><a class="genanchor" href="#81849"> &para;</a><div class="date" title="2008-03-16 04:52"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom81849">
<div class="phpcode"><code><span class="html">
To jvm at jvmyers dot com:<br />Your first two if statements just check if there's anything in the string, if you wish to actually execute the code in your string you need eval().</span>
</code></div>
  </div>
 </div>
  <div class="note" id="73261">  <div class="votes">
    <div id="Vu73261">
    <a href="/manual/vote-note.php?id=73261&amp;page=language.expressions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd73261">
    <a href="/manual/vote-note.php?id=73261&amp;page=language.expressions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V73261" title="55% like this...">
    5
    </div>
  </div>
  <a href="#73261" class="name">
  <strong class="user"><em>shawnster</em></strong></a><a class="genanchor" href="#73261"> &para;</a><div class="date" title="2007-02-14 04:56"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom73261">
<div class="phpcode"><code><span class="html">
An easy fix (although intuitively tough to do...) is to reverse the comparison.<br /><br />if (5 == $a) {}<br /><br />If you forget the second '=', you'll get a parse error for trying to assign a value to a non-variable.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="72692">  <div class="votes">
    <div id="Vu72692">
    <a href="/manual/vote-note.php?id=72692&amp;page=language.expressions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd72692">
    <a href="/manual/vote-note.php?id=72692&amp;page=language.expressions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V72692" title="52% like this...">
    2
    </div>
  </div>
  <a href="#72692" class="name">
  <strong class="user"><em>nabil_kadimi at hotmail dot com</em></strong></a><a class="genanchor" href="#72692"> &para;</a><div class="date" title="2007-01-29 07:46"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom72692">
<div class="phpcode"><code><span class="html">
Attention! php will not warn you if you write (1) When you mean (2)<br /><br />(1)<br />&lt;?<br />if($a=0) <br />&nbsp; &nbsp; echo "condition is true";<br />else <br />&nbsp; &nbsp; echo "condition is false";<br />//output: condition is false<br />?&gt;<br /><br />(2)<br />&lt;?<br />if($a==0) <br />&nbsp; &nbsp; echo "condition is true";<br />else <br />&nbsp; &nbsp; echo "condition is false";<br />//output: condition is true<br />?&gt;</span>
</code></div>
  </div>
 </div>
  <div class="note" id="81363">  <div class="votes">
    <div id="Vu81363">
    <a href="/manual/vote-note.php?id=81363&amp;page=language.expressions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd81363">
    <a href="/manual/vote-note.php?id=81363&amp;page=language.expressions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V81363" title="47% like this...">
    -2
    </div>
  </div>
  <a href="#81363" class="name">
  <strong class="user"><em>jvm at jvmyers dot com</em></strong></a><a class="genanchor" href="#81363"> &para;</a><div class="date" title="2008-02-24 12:20"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom81363">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br /></span><span class="comment">// Compound booleans expressed as string args in an 'if' statement don't work as expected:<br />//<br />//&nbsp; &nbsp; Context:<br />//&nbsp; &nbsp; &nbsp; &nbsp; 1.&nbsp; I generate an array of counters<br />//&nbsp; &nbsp; &nbsp; &nbsp; 2.&nbsp; I dynamically generate a compound boolean based on selected counters in the array<br />//&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Note: since the real array is sparse, I must use the 'empty' operator<br />//&nbsp; &nbsp; &nbsp; &nbsp; 3.&nbsp; When I submit the compound boolean as the expression of an 'if' statement, <br />//&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; the 'if' appears to resolve ONLY the first element of the compound boolean.<br />//&nbsp; &nbsp; Conclusion: appears to be a short-circuiting issue<br /><br /></span><span class="default">$aArray </span><span class="keyword">= array(</span><span class="default">1</span><span class="keyword">,</span><span class="default">0</span><span class="keyword">);<br /><br /></span><span class="comment">// Case 1: 'if' expression passed as string:<br /><br /></span><span class="default">$sCondition </span><span class="keyword">= </span><span class="string">"!empty(</span><span class="default">$aArray</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]</span><span class="string">) &amp;&amp; !empty(</span><span class="default">$aArray</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]</span><span class="string">)"</span><span class="keyword">;<br />if (</span><span class="default">$sCondition</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; echo </span><span class="string">"1. Conditions met&lt;br /&gt;"</span><span class="keyword">;<br />}<br />else<br />{<br />&nbsp; &nbsp; echo </span><span class="string">"1. Conditions not met&lt;br /&gt;"</span><span class="keyword">;<br />}<br /><br /></span><span class="comment">// Case 1 output:&nbsp; "1. Conditions met"<br /><br />// Case 2: same as Case 1, but using catenation operator<br /><br /></span><span class="keyword">if (</span><span class="string">""</span><span class="keyword">.</span><span class="default">$sCondition</span><span class="keyword">.</span><span class="string">""</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; echo </span><span class="string">"2. Conditions met&lt;br /&gt;"</span><span class="keyword">;<br />}<br />else<br />{<br />&nbsp; &nbsp; echo </span><span class="string">"2. Conditions not met&lt;br /&gt;"</span><span class="keyword">;<br />}<br /><br /></span><span class="comment">// Case 2 output:&nbsp; "2. Conditions met"<br /><br />// Case 3: same 'if' expression but passed in context:<br /><br /></span><span class="keyword">if (!empty(</span><span class="default">$aArray</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]) &amp;&amp; !empty(</span><span class="default">$aArray</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]))<br />{<br />&nbsp; &nbsp; echo </span><span class="string">"3. Conditions met&lt;br /&gt;"</span><span class="keyword">;<br />}<br />else<br />{<br />&nbsp; &nbsp; echo </span><span class="string">"3. Conditions not met&lt;br /&gt;"</span><span class="keyword">;<br />}<br /><br /></span><span class="comment">// Case 3 output:&nbsp; "3. Conditions not met"<br /><br />// jvm@jvmyers.com<br /></span><span class="default">?&gt;<br /></span><br />PS: the bug folks say this "does not imply a bug in PHP itself."&nbsp; Sure bugs me!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="74308">  <div class="votes">
    <div id="Vu74308">
    <a href="/manual/vote-note.php?id=74308&amp;page=language.expressions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd74308">
    <a href="/manual/vote-note.php?id=74308&amp;page=language.expressions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V74308" title="46% like this...">
    -2
    </div>
  </div>
  <a href="#74308" class="name">
  <strong class="user"><em>egonfreeman at gmail dot com</em></strong></a><a class="genanchor" href="#74308"> &para;</a><div class="date" title="2007-04-04 07:45"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom74308">
<div class="phpcode"><code><span class="html">
It is worthy to mention that:<br /><br />$n = 3;<br />$n * --$n<br /><br />WILL RETURN 4 instead of 6.<br /><br />It can be a hard to spot "error", because in our human thought process this really isn't an error at all! But you have to remember that PHP (as it is with many other high-level languages) evaluates its statements RIGHT-TO-LEFT, and therefore "--$n" comes BEFORE multiplying, so - in the end - it's really "2 * 2", not "3 * 2".<br /><br />It is also worthy to mention that the same behavior will change:<br /><br />$n = 3;<br />$n * $n++<br /><br />from 3 * 3 into 3 * 4. Post- operations operate on a variable after it has been 'checked', but it doesn't necessarily state that it should happen AFTER an evaluation is over (on the contrary, as a matter of fact).<br /><br />So, if you ever find yourself on a 'wild goose chase' for a bug in that "impossible-to-break, so-very-simple" piece of code that uses pre-/post-'s, remember this post. :)<br /><br />(just thought I'd check it out - turns out I was right :P)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="60899">  <div class="votes">
    <div id="Vu60899">
    <a href="/manual/vote-note.php?id=60899&amp;page=language.expressions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd60899">
    <a href="/manual/vote-note.php?id=60899&amp;page=language.expressions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V60899" title="43% like this...">
    -3
    </div>
  </div>
  <a href="#60899" class="name">
  <strong class="user"><em>richard at phase4 dot ie</em></strong></a><a class="genanchor" href="#60899"> &para;</a><div class="date" title="2006-01-19 12:00"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom60899">
<div class="phpcode"><code><span class="html">
Follow up on Martin K. There are no hard and fast rules regarding operator precedence. Newbies should definitely learn them, but if their use results in code that is not easy to read you should use parentheses. The two important things are that it works properly AND is maintainable by you and others.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="53404">  <div class="votes">
    <div id="Vu53404">
    <a href="/manual/vote-note.php?id=53404&amp;page=language.expressions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd53404">
    <a href="/manual/vote-note.php?id=53404&amp;page=language.expressions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V53404" title="41% like this...">
    -4
    </div>
  </div>
  <a href="#53404" class="name"><strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#53404"> &para;</a><div class="date" title="2005-05-31 12:07"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom53404">
<div class="phpcode"><code><span class="html">
I don't see why it is necessary here to explain pre- and post- incrementing.<br /><br />This is something that will confuse new users of PHP, even longer time programmers will sometimes miss a the fine details of a construct like that.<br /><br />If something has a side-effect it should be on a line of it's own, or at least be an expression of it's own and not part of an assignment, condition or whatever.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="49666">  <div class="votes">
    <div id="Vu49666">
    <a href="/manual/vote-note.php?id=49666&amp;page=language.expressions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd49666">
    <a href="/manual/vote-note.php?id=49666&amp;page=language.expressions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V49666" title="41% like this...">
    -5
    </div>
  </div>
  <a href="#49666" class="name">
  <strong class="user"><em>tom at darlingpet dot com</em></strong></a><a class="genanchor" href="#49666"> &para;</a><div class="date" title="2005-02-04 02:13"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom49666">
<div class="phpcode"><code><span class="html">
Something I've noticed with ternary expressions is if you do something like :<br /><br /><span class="default">&lt;?= $var</span><span class="keyword">==</span><span class="string">"something" </span><span class="keyword">? </span><span class="string">"is something" </span><span class="keyword">: </span><span class="string">"not something"</span><span class="keyword">; </span><span class="default">?&gt;<br /></span><br />It will give wacky results sometimes...<br /><br />So be sure to enclose the ternary expression in parenthesis when ever necessary (such as having multiple expressions or nested ternary expressions)<br /><br />The above could look like:<br /><br /><span class="default">&lt;?= </span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">==</span><span class="string">"something"</span><span class="keyword">) ? </span><span class="string">"is something" </span><span class="keyword">: </span><span class="string">"not something"</span><span class="keyword">; </span><span class="default">?&gt;<br /></span><br />It's also a good idea to use parenthesis when using something SIMILAR to:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">echo (</span><span class="default">trim</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">)==</span><span class="string">""</span><span class="keyword">) ? </span><span class="string">"empty" </span><span class="keyword">: </span><span class="string">"not empty"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />In some cases other than the <span class="default">&lt;?= ?&gt;</span> example, not placing the entire expression in appropriate parenthesis might yield undesirable results as well.. but I'm not quite sure.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="107687">  <div class="votes">
    <div id="Vu107687">
    <a href="/manual/vote-note.php?id=107687&amp;page=language.expressions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd107687">
    <a href="/manual/vote-note.php?id=107687&amp;page=language.expressions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V107687" title="39% like this...">
    -6
    </div>
  </div>
  <a href="#107687" class="name">
  <strong class="user"><em>antickon at gmail dot com</em></strong></a><a class="genanchor" href="#107687"> &para;</a><div class="date" title="2012-02-26 07:29"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom107687">
<div class="phpcode"><code><span class="html">
evaluation order of subexpressions is not strictly defined for all operators<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">a</span><span class="keyword">() {echo </span><span class="string">'a'</span><span class="keyword">;}<br />function </span><span class="default">b</span><span class="keyword">() {echo </span><span class="string">'b'</span><span class="keyword">;}<br /></span><span class="default">a</span><span class="keyword">() == </span><span class="default">b</span><span class="keyword">(); </span><span class="comment">// outputs "ab", ie evaluates left-to-right<br /><br /></span><span class="default">$a </span><span class="keyword">= </span><span class="default">3</span><span class="keyword">;<br /></span><span class="default">var_dump</span><span class="keyword">( </span><span class="default">$a </span><span class="keyword">== </span><span class="default">$a </span><span class="keyword">= </span><span class="default">4 </span><span class="keyword">); </span><span class="comment">// outputs bool(true), ie evaluates right-to-left<br /></span><span class="default">?&gt;<br /></span><br />this is not a bug: "we [php developers] make no guarantee about the order of evaluation".<br />See <a href="https://bugs.php.net/bug.php?id=61188" rel="nofollow" target="_blank">https://bugs.php.net/bug.php?id=61188</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="76571">  <div class="votes">
    <div id="Vu76571">
    <a href="/manual/vote-note.php?id=76571&amp;page=language.expressions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd76571">
    <a href="/manual/vote-note.php?id=76571&amp;page=language.expressions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V76571" title="33% like this...">
    -13
    </div>
  </div>
  <a href="#76571" class="name">
  <strong class="user"><em>george dot langley at shaw dot ca</em></strong></a><a class="genanchor" href="#76571"> &para;</a><div class="date" title="2007-07-20 11:01"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom76571">
<div class="phpcode"><code><span class="html">
Here's a quick example of Pre and Post-incrementation, in case anyone does feel confused (ref anonymous poster 31 May 2005)<br /><br /><span class="default">&lt;?PHP<br /></span><span class="keyword">echo </span><span class="string">"Using Pre-increment ++\$a:&lt;br&gt;"</span><span class="keyword">;<br /></span><span class="default">$a </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />echo </span><span class="string">"\$a = </span><span class="default">$a</span><span class="string">&lt;br&gt;"</span><span class="keyword">;<br /></span><span class="default">$b </span><span class="keyword">= ++</span><span class="default">$a</span><span class="keyword">;<br />echo </span><span class="string">"\$b = ++\$a, so \$b = </span><span class="default">$b</span><span class="string"> and \$a = </span><span class="default">$a</span><span class="string">&lt;br&gt;"</span><span class="keyword">;<br />echo </span><span class="string">"&lt;br&gt;"</span><span class="keyword">;<br />echo </span><span class="string">"Using Post-increment \$a++:&lt;br&gt;"</span><span class="keyword">;<br /></span><span class="default">$a </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />echo </span><span class="string">"\$a = </span><span class="default">$a</span><span class="string">&lt;br&gt;"</span><span class="keyword">;<br /></span><span class="default">$b </span><span class="keyword">= </span><span class="default">$a</span><span class="keyword">++;<br />echo </span><span class="string">"\$b = \$a++, so \$b = </span><span class="default">$b</span><span class="string"> and \$a = </span><span class="default">$a</span><span class="string">&lt;br&gt;"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />HTH</span>
</code></div>
  </div>
 </div>
  <div class="note" id="57998">  <div class="votes">
    <div id="Vu57998">
    <a href="/manual/vote-note.php?id=57998&amp;page=language.expressions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd57998">
    <a href="/manual/vote-note.php?id=57998&amp;page=language.expressions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V57998" title="31% like this...">
    -14
    </div>
  </div>
  <a href="#57998" class="name">
  <strong class="user"><em>Martin K</em></strong></a><a class="genanchor" href="#57998"> &para;</a><div class="date" title="2005-10-20 06:28"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom57998">
<div class="phpcode"><code><span class="html">
At 04-Feb-2005 05:13, tom at darlingpet dot com said:<br />&gt; It's also a good idea to use parenthesis when using something SIMILAR to:<br />&gt; <br />&gt; <span class="default">&lt;?php<br /></span><span class="keyword">&gt; echo (</span><span class="default">trim</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">)==</span><span class="string">""</span><span class="keyword">) ? </span><span class="string">"empty" </span><span class="keyword">: </span><span class="string">"not empty"</span><span class="keyword">;<br />&gt; </span><span class="default">?&gt;<br /></span><br />No, it's a BAD idea.<br /><br />All the short-circuiting operators, including the ternary conditional operator, have LOWER precedence than the comparison operators, so they almost NEVER need parentheses around their subexpressions.<br /><br />Inserting the parentheses suggested above does not change the meaning of the code, but their use misleads inexperienced programmers to expect that things like this will work in a similar manner:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">my_print</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">) { print(</span><span class="default">$a</span><span class="keyword">); }<br /></span><span class="default">my_print </span><span class="keyword">(</span><span class="default">trim</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">)==</span><span class="string">""</span><span class="keyword">) ? </span><span class="string">"empty" </span><span class="keyword">: </span><span class="string">"not empty"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />when of course it doesn't.<br /><br />Rather than worrying that code doesn't work as expected, simply learn the precedence rules (<a href="http://www.php.net/manual/en/language.operators.php" rel="nofollow" target="_blank">http://www.php.net/manual/en/language.operators.php</a>) so that one expects the right things.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="55815">  <div class="votes">
    <div id="Vu55815">
    <a href="/manual/vote-note.php?id=55815&amp;page=language.expressions&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd55815">
    <a href="/manual/vote-note.php?id=55815&amp;page=language.expressions&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V55815" title="30% like this...">
    -14
    </div>
  </div>
  <a href="#55815" class="name">
  <strong class="user"><em>12345alex at gmx dot net</em></strong></a><a class="genanchor" href="#55815"> &para;</a><div class="date" title="2005-08-14 07:00"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom55815">
<div class="phpcode"><code><span class="html">
this code:<br />&nbsp; &nbsp; print array() == NULL ? "True" : "False";<br />&nbsp; &nbsp; print " (" . (array() == NULL) . ")\n";<br /><br />&nbsp; &nbsp; $arr = array();<br />&nbsp; &nbsp; print array() == $arr ? "True" : "False";<br />&nbsp; &nbsp; print " (" . (array() == $arr) . ")\n";<br /><br />&nbsp; &nbsp; print count(array()) . "\n";<br />&nbsp; &nbsp; print count(NULL) . "\n";<br /><br />will output (on php4 and php5):<br />&nbsp; &nbsp; True (1)<br />&nbsp; &nbsp; True (1)<br />&nbsp; &nbsp; 0<br />&nbsp; &nbsp; 0<br /><br />so to decide wether i have NULL or an empty array i will also have to use gettype(). this seems some kind of weird for me, although if is this is a bug, somebody should have noticed it before.<br /><br />alex</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.expressions&amp;redirect=http://php.net/manual/pt_BR/language.expressions.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="langref.php">Refer&ecirc;ncia da Linguagem</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.basic-syntax.php" title="Sintaxe B&aacute;sica">Sintaxe B&aacute;sica</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.php" title="Tipos">Tipos</a>
                        </li>
                          
                        <li class="">
                            <a href="language.variables.php" title="Vari&aacute;veis">Vari&aacute;veis</a>
                        </li>
                          
                        <li class="">
                            <a href="language.constants.php" title="Constantes">Constantes</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.expressions.php" title="Express&otilde;es">Express&otilde;es</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.php" title="Operadores">Operadores</a>
                        </li>
                          
                        <li class="">
                            <a href="language.control-structures.php" title="Estruturas de Controle">Estruturas de Controle</a>
                        </li>
                          
                        <li class="">
                            <a href="language.functions.php" title="Fun&ccedil;&otilde;es">Fun&ccedil;&otilde;es</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.php" title="Classes e Objetos">Classes e Objetos</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.php" title="Namespaces">Namespaces</a>
                        </li>
                          
                        <li class="">
                            <a href="language.errors.php" title="Erros">Erros</a>
                        </li>
                          
                        <li class="">
                            <a href="language.exceptions.php" title="Exce&ccedil;&otilde;es">Exce&ccedil;&otilde;es</a>
                        </li>
                          
                        <li class="">
                            <a href="language.generators.php" title="Generators">Generators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.references.php" title="Refer&ecirc;ncias">Refer&ecirc;ncias</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.php" title="Vari&aacute;veis pr&eacute;-&#8203;definidas">Vari&aacute;veis pr&eacute;-&#8203;definidas</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.exceptions.php" title="Exce&ccedil;&otilde;es pr&eacute;-&#8203;definidas">Exce&ccedil;&otilde;es pr&eacute;-&#8203;definidas</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.interfaces.php" title="Interfaces e Classes pr&eacute;-&#8203;definidas">Interfaces e Classes pr&eacute;-&#8203;definidas</a>
                        </li>
                          
                        <li class="">
                            <a href="context.php" title="Op&ccedil;&otilde;es e par&acirc;metros de contexto">Op&ccedil;&otilde;es e par&acirc;metros de contexto</a>
                        </li>
                          
                        <li class="">
                            <a href="wrappers.php" title="Protocolos e Wrappers suportados">Protocolos e Wrappers suportados</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

