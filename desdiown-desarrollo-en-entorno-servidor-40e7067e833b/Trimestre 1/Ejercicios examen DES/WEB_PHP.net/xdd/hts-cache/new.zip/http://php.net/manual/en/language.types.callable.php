<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Callbacks / Callables - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.types.callable.php">
 <link rel="shorturl" href="http://php.net/types.callable">
 <link rel="alternate" href="http://php.net/types.callable" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.types.php">
 <link rel="prev" href="http://php.net/manual/en/language.types.null.php">
 <link rel="next" href="http://php.net/manual/en/language.pseudo-types.php">

 <link rel="alternate" href="http://php.net/manual/en/language.types.callable.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.types.callable.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.types.callable.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.types.callable.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.types.callable.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.types.callable.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.types.callable.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.types.callable.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.types.callable.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.types.callable.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.types.callable.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.pseudo-types.php">
          Pseudo-types and variables used in this documentation &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.types.null.php">
          &laquo; NULL        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.types.php'>Types</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.types.callable.php' selected="selected">English</option>
            <option value='pt_BR/language.types.callable.php'>Brazilian Portuguese</option>
            <option value='zh/language.types.callable.php'>Chinese (Simplified)</option>
            <option value='fr/language.types.callable.php'>French</option>
            <option value='de/language.types.callable.php'>German</option>
            <option value='ja/language.types.callable.php'>Japanese</option>
            <option value='ro/language.types.callable.php'>Romanian</option>
            <option value='ru/language.types.callable.php'>Russian</option>
            <option value='es/language.types.callable.php'>Spanish</option>
            <option value='tr/language.types.callable.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.types.callable.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.types.callable">Report a Bug</a>
    </div>
  </div><div id="language.types.callable" class="sect1">
 <h2 class="title">Callbacks / Callables</h2>

 <p class="para">
  Callbacks can be denoted by <span class="type"><a href="language.types.callable.php" class="type callable">callable</a></span> type hint as of PHP 5.4.
  This documentation used <span class="type"><a href="language.pseudo-types.php#language.types.callback" class="type callback">callback</a></span> type information for the same
  purpose.
 </p>

 <p class="para">
  Some functions like <span class="function"><a href="function.call-user-func.php" class="function">call_user_func()</a></span> or
  <span class="function"><a href="function.usort.php" class="function">usort()</a></span> accept user-defined callback functions as a
  parameter. Callback functions can not only be simple functions, but also
  <span class="type"><a href="language.types.object.php" class="type object">object</a></span> methods, including static class methods.
 </p>

 <div class="sect2" id="language.types.callable.passing">
  <h3 class="title">Passing</h3>

  <p class="para">
   A PHP function is passed by its name as a <span class="type"><a href="language.types.string.php" class="type string">string</a></span>. Any built-in
   or user-defined function can be used, except language constructs such as:
   <span class="function"><a href="function.array.php" class="function">array()</a></span>, <span class="function"><a href="function.echo.php" class="function">echo</a></span>,
   <span class="function"><a href="function.empty.php" class="function">empty()</a></span>, <span class="function"><a href="function.eval.php" class="function">eval()</a></span>,
   <span class="function"><a href="function.exit.php" class="function">exit()</a></span>, <span class="function"><a href="function.isset.php" class="function">isset()</a></span>,
   <span class="function"><a href="function.list.php" class="function">list()</a></span>, <span class="function"><a href="function.print.php" class="function">print</a></span> or
   <span class="function"><a href="function.unset.php" class="function">unset()</a></span>.
  </p>

  <p class="para">
   A method of an instantiated <span class="type"><a href="language.types.object.php" class="type object">object</a></span> is passed as an
   <span class="type"><a href="language.types.array.php" class="type array">array</a></span> containing an <span class="type"><a href="language.types.object.php" class="type object">object</a></span> at index 0 and the
   method name at index 1. Accessing protected and private methods from
   within a class is allowed.
  </p>

  <p class="para">
   Static class methods can also be passed without instantiating an
   <span class="type"><a href="language.types.object.php" class="type object">object</a></span> of that class by passing the class name instead of an
   <span class="type"><a href="language.types.object.php" class="type object">object</a></span> at index 0.
   As of PHP 5.2.3, it is also possible to pass
   <em>&#039;ClassName::methodName&#039;</em>.
  </p>

  <p class="para">
   Apart from common user-defined function,
   <a href="functions.anonymous.php" class="link">anonymous functions</a> can also be
   passed to a callback parameter.
  </p>

  <p class="para">
   <div class="example" id="example-75">
    <p><strong>Example #1 
     Callback function examples
    </strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /><br /></span><span style="color: #FF8000">//&nbsp;An&nbsp;example&nbsp;callback&nbsp;function<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">my_callback_function</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">'hello&nbsp;world!'</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #FF8000">//&nbsp;An&nbsp;example&nbsp;callback&nbsp;method<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">MyClass&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;static&nbsp;function&nbsp;</span><span style="color: #0000BB">myCallbackMethod</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">'Hello&nbsp;World!'</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br /></span><span style="color: #FF8000">//&nbsp;Type&nbsp;1:&nbsp;Simple&nbsp;callback<br /></span><span style="color: #0000BB">call_user_func</span><span style="color: #007700">(</span><span style="color: #DD0000">'my_callback_function'</span><span style="color: #007700">);<br /><br /></span><span style="color: #FF8000">//&nbsp;Type&nbsp;2:&nbsp;Static&nbsp;class&nbsp;method&nbsp;call<br /></span><span style="color: #0000BB">call_user_func</span><span style="color: #007700">(array(</span><span style="color: #DD0000">'MyClass'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'myCallbackMethod'</span><span style="color: #007700">));<br /><br /></span><span style="color: #FF8000">//&nbsp;Type&nbsp;3:&nbsp;Object&nbsp;method&nbsp;call<br /></span><span style="color: #0000BB">$obj&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">MyClass</span><span style="color: #007700">();<br /></span><span style="color: #0000BB">call_user_func</span><span style="color: #007700">(array(</span><span style="color: #0000BB">$obj</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'myCallbackMethod'</span><span style="color: #007700">));<br /><br /></span><span style="color: #FF8000">//&nbsp;Type&nbsp;4:&nbsp;Static&nbsp;class&nbsp;method&nbsp;call&nbsp;(As&nbsp;of&nbsp;PHP&nbsp;5.2.3)<br /></span><span style="color: #0000BB">call_user_func</span><span style="color: #007700">(</span><span style="color: #DD0000">'MyClass::myCallbackMethod'</span><span style="color: #007700">);<br /><br /></span><span style="color: #FF8000">//&nbsp;Type&nbsp;5:&nbsp;Relative&nbsp;static&nbsp;class&nbsp;method&nbsp;call&nbsp;(As&nbsp;of&nbsp;PHP&nbsp;5.3.0)<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">A&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;static&nbsp;function&nbsp;</span><span style="color: #0000BB">who</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"A\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br />class&nbsp;</span><span style="color: #0000BB">B&nbsp;</span><span style="color: #007700">extends&nbsp;</span><span style="color: #0000BB">A&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;static&nbsp;function&nbsp;</span><span style="color: #0000BB">who</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"B\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br /></span><span style="color: #0000BB">call_user_func</span><span style="color: #007700">(array(</span><span style="color: #DD0000">'B'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'parent::who'</span><span style="color: #007700">));&nbsp;</span><span style="color: #FF8000">//&nbsp;A<br /><br />//&nbsp;Type&nbsp;6:&nbsp;Objects&nbsp;implementing&nbsp;__invoke&nbsp;can&nbsp;be&nbsp;used&nbsp;as&nbsp;callables&nbsp;(since&nbsp;PHP&nbsp;5.3)<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">C&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">__invoke</span><span style="color: #007700">(</span><span style="color: #0000BB">$name</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">'Hello&nbsp;'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$name</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br /></span><span style="color: #0000BB">$c&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">C</span><span style="color: #007700">();<br /></span><span style="color: #0000BB">call_user_func</span><span style="color: #007700">(</span><span style="color: #0000BB">$c</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'PHP!'</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
  </p>
  <p class="para">
   <div class="example" id="example-76">
    <p><strong>Example #2 
     Callback example using a Closure
    </strong></p>
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #FF8000">//&nbsp;Our&nbsp;closure<br /></span><span style="color: #0000BB">$double&nbsp;</span><span style="color: #007700">=&nbsp;function(</span><span style="color: #0000BB">$a</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">*&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">;<br />};<br /><br /></span><span style="color: #FF8000">//&nbsp;This&nbsp;is&nbsp;our&nbsp;range&nbsp;of&nbsp;numbers<br /></span><span style="color: #0000BB">$numbers&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">range</span><span style="color: #007700">(</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">5</span><span style="color: #007700">);<br /><br /></span><span style="color: #FF8000">//&nbsp;Use&nbsp;the&nbsp;closure&nbsp;as&nbsp;a&nbsp;callback&nbsp;here&nbsp;to<br />//&nbsp;double&nbsp;the&nbsp;size&nbsp;of&nbsp;each&nbsp;element&nbsp;in&nbsp;our<br />//&nbsp;range<br /></span><span style="color: #0000BB">$new_numbers&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">array_map</span><span style="color: #007700">(</span><span style="color: #0000BB">$double</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$numbers</span><span style="color: #007700">);<br /><br />print&nbsp;</span><span style="color: #0000BB">implode</span><span style="color: #007700">(</span><span style="color: #DD0000">'&nbsp;'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$new_numbers</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

    <div class="example-contents"><p>The above example will output:</p></div>
    <div class="example-contents screen">
<div class="cdata"><pre>
2 4 6 8 10
</pre></div>
    </div>
   </div>
  </p>

  <blockquote class="note"><p><strong class="note">Note</strong>: <p class="para">Callbacks registered
with functions such as <span class="function"><a href="function.call-user-func.php" class="function">call_user_func()</a></span> and <span class="function"><a href="function.call-user-func-array.php" class="function">call_user_func_array()</a></span> will not be
called if there is an uncaught exception thrown in a previous callback.</p></p></blockquote>
 </div>

</div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.types.callable&amp;redirect=http://php.net/manual/en/language.types.callable.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">12 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="116640">  <div class="votes">
    <div id="Vu116640">
    <a href="/manual/vote-note.php?id=116640&amp;page=language.types.callable&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116640">
    <a href="/manual/vote-note.php?id=116640&amp;page=language.types.callable&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116640" title="87% like this...">
    192
    </div>
  </div>
  <a href="#116640" class="name">
  <strong class="user"><em>edanschwartz at gmail dot com</em></strong></a><a class="genanchor" href="#116640"> &para;</a><div class="date" title="2015-02-02 06:13"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom116640">
<div class="phpcode"><code><span class="html">
You can use 'self::methodName' as a callable, but this is dangerous. Consider this example:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Foo </span><span class="keyword">{<br />&nbsp; &nbsp; public static function </span><span class="default">doAwesomeThings</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">FunctionCaller</span><span class="keyword">::</span><span class="default">callIt</span><span class="keyword">(</span><span class="string">'self::someAwesomeMethod'</span><span class="keyword">);<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public static function </span><span class="default">someAwesomeMethod</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// fantastic code goes here.<br />&nbsp; &nbsp; </span><span class="keyword">}<br />}<br /><br />class </span><span class="default">FunctionCaller </span><span class="keyword">{<br />&nbsp; &nbsp; public static function </span><span class="default">callIt</span><span class="keyword">(callable </span><span class="default">$func</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">call_user_func</span><span class="keyword">(</span><span class="default">$func</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">Foo</span><span class="keyword">::</span><span class="default">doAwesomeThings</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span><br />This results in an error:<br />Warning: class 'FunctionCaller' does not have a method 'someAwesomeMethod'.<br /><br />For this reason you should always use the full class name:<br /><span class="default">&lt;?php<br />FunctionCaller</span><span class="keyword">::</span><span class="default">callIt</span><span class="keyword">(</span><span class="string">'Foo::someAwesomeMethod'</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />I believe this is because there is no way for FunctionCaller to know that the string 'self' at one point referred to to `Foo`.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="110084">  <div class="votes">
    <div id="Vu110084">
    <a href="/manual/vote-note.php?id=110084&amp;page=language.types.callable&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd110084">
    <a href="/manual/vote-note.php?id=110084&amp;page=language.types.callable&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V110084" title="86% like this...">
    193
    </div>
  </div>
  <a href="#110084" class="name">
  <strong class="user"><em>steve at mrclay dot org</em></strong></a><a class="genanchor" href="#110084"> &para;</a><div class="date" title="2012-09-17 09:00"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom110084">
<div class="phpcode"><code><span class="html">
Performance note: The callable type hint, like is_callable(), will trigger an autoload of the class if the value looks like a static method callback.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="109073">  <div class="votes">
    <div id="Vu109073">
    <a href="/manual/vote-note.php?id=109073&amp;page=language.types.callable&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd109073">
    <a href="/manual/vote-note.php?id=109073&amp;page=language.types.callable&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V109073" title="83% like this...">
    201
    </div>
  </div>
  <a href="#109073" class="name">
  <strong class="user"><em>andrewbessa at gmail dot com</em></strong></a><a class="genanchor" href="#109073"> &para;</a><div class="date" title="2012-06-19 03:16"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom109073">
<div class="phpcode"><code><span class="html">
You can also use the $this variable to specify a callback:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">MyClass </span><span class="keyword">{<br /><br />&nbsp; &nbsp; public </span><span class="default">$property </span><span class="keyword">= </span><span class="string">'Hello World!'</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public function </span><span class="default">MyMethod</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">call_user_func</span><span class="keyword">(array(</span><span class="default">$this</span><span class="keyword">, </span><span class="string">'myCallbackMethod'</span><span class="keyword">));<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">MyCallbackMethod</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">property</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113447">  <div class="votes">
    <div id="Vu113447">
    <a href="/manual/vote-note.php?id=113447&amp;page=language.types.callable&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113447">
    <a href="/manual/vote-note.php?id=113447&amp;page=language.types.callable&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113447" title="87% like this...">
    178
    </div>
  </div>
  <a href="#113447" class="name">
  <strong class="user"><em>computrius at gmail dot com</em></strong></a><a class="genanchor" href="#113447"> &para;</a><div class="date" title="2013-10-11 04:38"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113447">
<div class="phpcode"><code><span class="html">
When specifying a call back in array notation (ie. array($this, "myfunc") ) the method can be private if called from inside the class, but if you call it from outside you'll get a warning:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">mc </span><span class="keyword">{<br />&nbsp;&nbsp; public function </span><span class="default">go</span><span class="keyword">(array </span><span class="default">$arr</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">array_walk</span><span class="keyword">(</span><span class="default">$arr</span><span class="keyword">, array(</span><span class="default">$this</span><span class="keyword">, </span><span class="string">"walkIt"</span><span class="keyword">));<br />&nbsp;&nbsp; }<br /><br />&nbsp;&nbsp; private function </span><span class="default">walkIt</span><span class="keyword">(</span><span class="default">$val</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp;&nbsp; echo </span><span class="default">$val </span><span class="keyword">. </span><span class="string">"&lt;br /&gt;"</span><span class="keyword">;<br />&nbsp;&nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">export</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return array(</span><span class="default">$this</span><span class="keyword">, </span><span class="string">'walkIt'</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$data </span><span class="keyword">= array(</span><span class="default">1</span><span class="keyword">,</span><span class="default">2</span><span class="keyword">,</span><span class="default">3</span><span class="keyword">,</span><span class="default">4</span><span class="keyword">);<br /><br /></span><span class="default">$m </span><span class="keyword">= new </span><span class="default">mc</span><span class="keyword">;<br /></span><span class="default">$m</span><span class="keyword">-&gt;</span><span class="default">go</span><span class="keyword">(</span><span class="default">$data</span><span class="keyword">); </span><span class="comment">// valid<br /><br /></span><span class="default">array_walk</span><span class="keyword">(</span><span class="default">$data</span><span class="keyword">, </span><span class="default">$m</span><span class="keyword">-&gt;</span><span class="default">export</span><span class="keyword">()); </span><span class="comment">// will generate warning<br /><br /></span><span class="default">?&gt;<br /></span><br />Output:<br />1&lt;br /&gt;2&lt;br /&gt;3&lt;br /&gt;4&lt;br /&gt;<br />Warning: array_walk() expects parameter 2 to be a valid callback, cannot access private method mc::walkIt() in /in/tfh7f on line 22</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117260">  <div class="votes">
    <div id="Vu117260">
    <a href="/manual/vote-note.php?id=117260&amp;page=language.types.callable&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117260">
    <a href="/manual/vote-note.php?id=117260&amp;page=language.types.callable&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117260" title="89% like this...">
    162
    </div>
  </div>
  <a href="#117260" class="name">
  <strong class="user"><em>Riikka K</em></strong></a><a class="genanchor" href="#117260"> &para;</a><div class="date" title="2015-05-11 01:36"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117260">
<div class="phpcode"><code><span class="html">
A note on differences when calling callbacks as "variable functions" without the use of call_user_func() (e.g. "<span class="default">&lt;?php $callback </span><span class="keyword">= </span><span class="string">'printf'</span><span class="keyword">; </span><span class="default">$callback</span><span class="keyword">(</span><span class="string">'Hello World!'</span><span class="keyword">) </span><span class="default">?&gt;</span>"):<br /><br />- Using the name of a function as string has worked since at least 4.3.0<br />- Calling anonymous functions and invokable objects has worked since 5.3.0<br />- Using the array structure [$object, 'method'] has worked since 5.4.0<br /><br />Note, however, that the following are not supported when calling callbacks as variable functions, even though they are supported by call_user_func():<br /><br />- Calling static class methods via strings such as 'foo::doStuff'<br />- Calling parent method using the [$object, 'parent::method'] array structure<br /><br />All of these cases are correctly recognized as callbacks by the 'callable' type hint, however. Thus, the following code will produce an error "Fatal error: Call to undefined function foo::doStuff() in /tmp/code.php on line 4":<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">foo </span><span class="keyword">{<br />&nbsp; &nbsp; static function </span><span class="default">callIt</span><span class="keyword">(callable </span><span class="default">$callback</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$callback</span><span class="keyword">();<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; static function </span><span class="default">doStuff</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Hello World!"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">foo</span><span class="keyword">::</span><span class="default">callIt</span><span class="keyword">(</span><span class="string">'foo::doStuff'</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />The code would work fine, if we replaced the '$callback()' with 'call_user_func($callback)' or if we used the array ['foo', 'doStuff'] as the callback instead.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114861">  <div class="votes">
    <div id="Vu114861">
    <a href="/manual/vote-note.php?id=114861&amp;page=language.types.callable&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114861">
    <a href="/manual/vote-note.php?id=114861&amp;page=language.types.callable&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114861" title="85% like this...">
    154
    </div>
  </div>
  <a href="#114861" class="name">
  <strong class="user"><em>Yzmir Ramirez</em></strong></a><a class="genanchor" href="#114861"> &para;</a><div class="date" title="2014-04-15 11:40"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114861">
<div class="phpcode"><code><span class="html">
&gt; As of PHP 5.2.3, it is also possible to pass 'ClassName::methodName'<br /><br />You can also use 'self::methodName'.&nbsp; This works in PHP 5.2.12 for me.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="112341">  <div class="votes">
    <div id="Vu112341">
    <a href="/manual/vote-note.php?id=112341&amp;page=language.types.callable&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd112341">
    <a href="/manual/vote-note.php?id=112341&amp;page=language.types.callable&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V112341" title="83% like this...">
    165
    </div>
  </div>
  <a href="#112341" class="name">
  <strong class="user"><em>metamarkers at gmail dot com</em></strong></a><a class="genanchor" href="#112341"> &para;</a><div class="date" title="2013-06-03 07:34"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom112341">
<div class="phpcode"><code><span class="html">
you can pass an object as a callable if its class defines the __invoke() magic method..</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118032">  <div class="votes">
    <div id="Vu118032">
    <a href="/manual/vote-note.php?id=118032&amp;page=language.types.callable&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118032">
    <a href="/manual/vote-note.php?id=118032&amp;page=language.types.callable&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118032" title="89% like this...">
    66
    </div>
  </div>
  <a href="#118032" class="name">
  <strong class="user"><em>mariano dot REMOVE dot perez dot rodriguez at gmail dot com</em></strong></a><a class="genanchor" href="#118032"> &para;</a><div class="date" title="2015-09-21 07:45"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom118032">
<div class="phpcode"><code><span class="html">
I needed a function that would determine the type of callable being passed, and, eventually,<br />normalized it to some extent. Here's what I came up with:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="comment">/**<br /> * The callable types and normalizations are given in the table below:<br /> *<br /> *&nbsp; Callable&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; | Normalization&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; | Type<br /> * ---------------------------------+---------------------------------+--------------<br /> *&nbsp; function (...) use (...) {...}&nbsp; | function (...) use (...) {...}&nbsp; | 'closure'<br /> *&nbsp; $object&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; | $object&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; | 'invocable'<br /> *&nbsp; "function"&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; | "function"&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; | 'function'<br /> *&nbsp; "class::method"&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; | ["class", "method"]&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; | 'static'<br /> *&nbsp; ["class", "parent::method"]&nbsp; &nbsp;&nbsp; | ["parent of class", "method"]&nbsp;&nbsp; | 'static'<br /> *&nbsp; ["class", "self::method"]&nbsp; &nbsp; &nbsp;&nbsp; | ["class", "method"]&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; | 'static'<br /> *&nbsp; ["class", "method"]&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; | ["class", "method"]&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; | 'static'<br /> *&nbsp; [$object, "parent::method"]&nbsp; &nbsp;&nbsp; | [$object, "parent::method"]&nbsp; &nbsp;&nbsp; | 'object'<br /> *&nbsp; [$object, "self::method"]&nbsp; &nbsp; &nbsp;&nbsp; | [$object, "method"]&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; | 'object'<br /> *&nbsp; [$object, "method"]&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; | [$object, "method"]&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; | 'object'<br /> * ---------------------------------+---------------------------------+--------------<br /> *&nbsp; other callable&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; | idem&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; | 'unknown'<br /> * ---------------------------------+---------------------------------+--------------<br /> *&nbsp; not a callable&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; | null&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; | false<br /> *<br /> * If the "strict" parameter is set to true, additional checks are<br /> * performed, in particular:<br /> *&nbsp; - when a callable string of the form "class::method" or a callable array<br /> *&nbsp; &nbsp; of the form ["class", "method"] is given, the method must be a static one,<br /> *&nbsp; - when a callable array of the form [$object, "method"] is given, the<br /> *&nbsp; &nbsp; method must be a non-static one.<br /> *<br /> */<br /></span><span class="keyword">function </span><span class="default">callableType</span><span class="keyword">(</span><span class="default">$callable</span><span class="keyword">, </span><span class="default">$strict </span><span class="keyword">= </span><span class="default">true</span><span class="keyword">, callable&amp; </span><span class="default">$norm </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">) {<br />&nbsp; if (!</span><span class="default">is_callable</span><span class="keyword">(</span><span class="default">$callable</span><span class="keyword">)) {<br />&nbsp; &nbsp; switch (</span><span class="default">true</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; case </span><span class="default">is_object</span><span class="keyword">(</span><span class="default">$callable</span><span class="keyword">):<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$norm </span><span class="keyword">= </span><span class="default">$callable</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">'Closure' </span><span class="keyword">=== </span><span class="default">get_class</span><span class="keyword">(</span><span class="default">$callable</span><span class="keyword">) ? </span><span class="string">'closure' </span><span class="keyword">: </span><span class="string">'invocable'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; case </span><span class="default">is_string</span><span class="keyword">(</span><span class="default">$callable</span><span class="keyword">):<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$m&nbsp; &nbsp; </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">preg_match</span><span class="keyword">(</span><span class="string">'~^(?&lt;class&gt;[a-z_][a-z0-9_]*)::(?&lt;method&gt;[a-z_][a-z0-9_]*)$~i'</span><span class="keyword">, </span><span class="default">$callable</span><span class="keyword">, </span><span class="default">$m</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; list(</span><span class="default">$left</span><span class="keyword">, </span><span class="default">$right</span><span class="keyword">) = [</span><span class="default">$m</span><span class="keyword">[</span><span class="string">'class'</span><span class="keyword">], </span><span class="default">$m</span><span class="keyword">[</span><span class="string">'method'</span><span class="keyword">]];<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (!</span><span class="default">$strict </span><span class="keyword">|| (new \</span><span class="default">ReflectionMethod</span><span class="keyword">(</span><span class="default">$left</span><span class="keyword">, </span><span class="default">$right</span><span class="keyword">))-&gt;</span><span class="default">isStatic</span><span class="keyword">()) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$norm </span><span class="keyword">= [</span><span class="default">$left</span><span class="keyword">, </span><span class="default">$right</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">'static'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$norm </span><span class="keyword">= </span><span class="default">$callable</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">'function'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; case </span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$callable</span><span class="keyword">):<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$m </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">preg_match</span><span class="keyword">(</span><span class="string">'~^(:?(?&lt;reference&gt;self|parent)::)?(?&lt;method&gt;[a-z_][a-z0-9_]*)$~i'</span><span class="keyword">, </span><span class="default">$callable</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">], </span><span class="default">$m</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">is_string</span><span class="keyword">(</span><span class="default">$callable</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">])) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="string">'parent' </span><span class="keyword">=== </span><span class="default">strtolower</span><span class="keyword">(</span><span class="default">$m</span><span class="keyword">[</span><span class="string">'reference'</span><span class="keyword">])) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; list(</span><span class="default">$left</span><span class="keyword">, </span><span class="default">$right</span><span class="keyword">) = [</span><span class="default">get_parent_class</span><span class="keyword">(</span><span class="default">$callable</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]), </span><span class="default">$m</span><span class="keyword">[</span><span class="string">'method'</span><span class="keyword">]];<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; list(</span><span class="default">$left</span><span class="keyword">, </span><span class="default">$right</span><span class="keyword">) = [</span><span class="default">$callable</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">], </span><span class="default">$m</span><span class="keyword">[</span><span class="string">'method'</span><span class="keyword">]];<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (!</span><span class="default">$strict </span><span class="keyword">|| (new \</span><span class="default">ReflectionMethod</span><span class="keyword">(</span><span class="default">$left</span><span class="keyword">, </span><span class="default">$right</span><span class="keyword">))-&gt;</span><span class="default">isStatic</span><span class="keyword">()) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$norm </span><span class="keyword">= [</span><span class="default">$left</span><span class="keyword">, </span><span class="default">$right</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">'static'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="string">'self' </span><span class="keyword">=== </span><span class="default">strtolower</span><span class="keyword">(</span><span class="default">$m</span><span class="keyword">[</span><span class="string">'reference'</span><span class="keyword">])) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; list(</span><span class="default">$left</span><span class="keyword">, </span><span class="default">$right</span><span class="keyword">) = [</span><span class="default">$callable</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">], </span><span class="default">$m</span><span class="keyword">[</span><span class="string">'method'</span><span class="keyword">]];<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; list(</span><span class="default">$left</span><span class="keyword">, </span><span class="default">$right</span><span class="keyword">) = </span><span class="default">$callable</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (!</span><span class="default">$strict </span><span class="keyword">|| !(new \</span><span class="default">ReflectionMethod</span><span class="keyword">(</span><span class="default">$left</span><span class="keyword">, </span><span class="default">$right</span><span class="keyword">))-&gt;</span><span class="default">isStatic</span><span class="keyword">()) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$norm </span><span class="keyword">= [</span><span class="default">$left</span><span class="keyword">, </span><span class="default">$right</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">'object'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; </span><span class="default">$norm </span><span class="keyword">= </span><span class="default">$callable</span><span class="keyword">;<br />&nbsp; &nbsp; return </span><span class="string">'unknown'</span><span class="keyword">;<br />&nbsp; }<br />&nbsp; </span><span class="default">$norm </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br />&nbsp; return </span><span class="default">false</span><span class="keyword">;<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />Hope someone else finds it useful.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121634">  <div class="votes">
    <div id="Vu121634">
    <a href="/manual/vote-note.php?id=121634&amp;page=language.types.callable&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121634">
    <a href="/manual/vote-note.php?id=121634&amp;page=language.types.callable&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121634" title="66% like this...">
    1
    </div>
  </div>
  <a href="#121634" class="name">
  <strong class="user"><em>Daniel Klein</em></strong></a><a class="genanchor" href="#121634"> &para;</a><div class="date" title="2017-09-13 07:26"><strong>3 months ago</strong></div>
  <div class="text" id="Hcom121634">
<div class="phpcode"><code><span class="html">
You can use "self::method_name", "static::method_name" and "parent::method_name" in callables:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">StaticCallable </span><span class="keyword">{<br />&nbsp; &nbsp; public static function </span><span class="default">foo</span><span class="keyword">(</span><span class="default">$values</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">array_map</span><span class="keyword">(</span><span class="string">'self::bar'</span><span class="keyword">, </span><span class="default">$values</span><span class="keyword">);<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public static function </span><span class="default">bar</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">"</span><span class="keyword">{</span><span class="default">$value</span><span class="keyword">}</span><span class="string">: 42"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public static function </span><span class="default">baz</span><span class="keyword">(</span><span class="default">$values</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">array_map</span><span class="keyword">(</span><span class="string">'static::qux'</span><span class="keyword">, </span><span class="default">$values</span><span class="keyword">);<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public static function </span><span class="default">qux</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">"</span><span class="keyword">{</span><span class="default">$value</span><span class="keyword">}</span><span class="string">: 123"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">StaticExtension </span><span class="keyword">extends </span><span class="default">StaticCallable </span><span class="keyword">{<br />&nbsp; &nbsp; public static function </span><span class="default">bar</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">"</span><span class="keyword">{</span><span class="default">$value</span><span class="keyword">}</span><span class="string">: Marvin the Paranoid Android"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public static function </span><span class="default">qux</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">"</span><span class="keyword">{</span><span class="default">$value</span><span class="keyword">}</span><span class="string">: Zaphod Beeblebrox"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">StaticCallable</span><span class="keyword">::</span><span class="default">foo</span><span class="keyword">([</span><span class="default">1</span><span class="keyword">, </span><span class="default">2</span><span class="keyword">, </span><span class="default">3</span><span class="keyword">]));<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">StaticExtension</span><span class="keyword">::</span><span class="default">foo</span><span class="keyword">([</span><span class="default">1</span><span class="keyword">, </span><span class="default">2</span><span class="keyword">, </span><span class="default">3</span><span class="keyword">]));<br /><br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">StaticCallable</span><span class="keyword">::</span><span class="default">baz</span><span class="keyword">([</span><span class="default">1</span><span class="keyword">, </span><span class="default">2</span><span class="keyword">, </span><span class="default">3</span><span class="keyword">]));<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">StaticExtension</span><span class="keyword">::</span><span class="default">baz</span><span class="keyword">([</span><span class="default">1</span><span class="keyword">, </span><span class="default">2</span><span class="keyword">, </span><span class="default">3</span><span class="keyword">]));<br /></span><span class="default">?&gt;<br /></span><br />Results:<br />Array<br />(<br />&nbsp; &nbsp; [0] =&gt; 1: 42<br />&nbsp; &nbsp; [1] =&gt; 2: 42<br />&nbsp; &nbsp; [2] =&gt; 3: 42<br />)<br />Array<br />(<br />&nbsp; &nbsp; [0] =&gt; 1: 42<br />&nbsp; &nbsp; [1] =&gt; 2: 42<br />&nbsp; &nbsp; [2] =&gt; 3: 42<br />)<br />Array<br />(<br />&nbsp; &nbsp; [0] =&gt; 1: 123<br />&nbsp; &nbsp; [1] =&gt; 2: 123<br />&nbsp; &nbsp; [2] =&gt; 3: 123<br />)<br />Array<br />(<br />&nbsp; &nbsp; [0] =&gt; 1: Zaphod Beeblebrox<br />&nbsp; &nbsp; [1] =&gt; 2: Zaphod Beeblebrox<br />&nbsp; &nbsp; [2] =&gt; 3: Zaphod Beeblebrox<br />)<br /><br />"self::" uses the same class as the called method, "static::" uses the same class as the called class, and "parent::" (not shown) uses the parent class, or generates a warning if there is no parent.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119166">  <div class="votes">
    <div id="Vu119166">
    <a href="/manual/vote-note.php?id=119166&amp;page=language.types.callable&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119166">
    <a href="/manual/vote-note.php?id=119166&amp;page=language.types.callable&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119166" title="62% like this...">
    4
    </div>
  </div>
  <a href="#119166" class="name">
  <strong class="user"><em>bradyn at NOSPAM dot bradynpoulsen dot com</em></strong></a><a class="genanchor" href="#119166"> &para;</a><div class="date" title="2016-04-14 01:22"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119166">
<div class="phpcode"><code><span class="html">
When trying to make a callable from a function name located in a namespace, you MUST give the fully qualified function name (regardless of the current namespace or use statements).<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">namespace </span><span class="default">MyNamespace</span><span class="keyword">;<br /><br />function </span><span class="default">doSomethingFancy</span><span class="keyword">(</span><span class="default">$arg1</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="comment">// do something...<br /></span><span class="keyword">}<br /><br /></span><span class="default">$values </span><span class="keyword">= [</span><span class="default">1</span><span class="keyword">, </span><span class="default">2</span><span class="keyword">, </span><span class="default">3</span><span class="keyword">];<br /><br /></span><span class="default">array_map</span><span class="keyword">(</span><span class="string">'doSomethingFancy'</span><span class="keyword">, </span><span class="default">$values</span><span class="keyword">);<br /></span><span class="comment">// array_map() expects parameter 1 to be a valid callback, function 'doSomethingFancy' not found or invalid function name<br /><br /></span><span class="default">array_map</span><span class="keyword">(</span><span class="string">'MyNamespace\doSomethingFancy'</span><span class="keyword">, </span><span class="default">$values</span><span class="keyword">);<br /></span><span class="comment">// =&gt; [..., ..., ...]</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120990">  <div class="votes">
    <div id="Vu120990">
    <a href="/manual/vote-note.php?id=120990&amp;page=language.types.callable&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120990">
    <a href="/manual/vote-note.php?id=120990&amp;page=language.types.callable&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120990" title="60% like this...">
    2
    </div>
  </div>
  <a href="#120990" class="name">
  <strong class="user"><em>whysteepy at gmail dot com</em></strong></a><a class="genanchor" href="#120990"> &para;</a><div class="date" title="2017-04-18 06:34"><strong>7 months ago</strong></div>
  <div class="text" id="Hcom120990">
<div class="phpcode"><code><span class="html">
Another Appearance of Callbacks! Here is one way of them - methods of an instantiated object can be callable and implemented as variable functions without php's default functions that can call user-defined callback functions.<br /><br />class Test {<br />&nbsp; &nbsp; protected $items = array();<br /><br />&nbsp; &nbsp; public function __construct() <br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; $this-&gt;items[] = array($this, 'callBackOne');<br />&nbsp; &nbsp; &nbsp; &nbsp; $this-&gt;items[] = array($this, 'callBackTwo');<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function callBackOne()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo __METHOD__ . ' has been called as a callback.';<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function callBackTwo()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo __METHOD__ . ' has been called as a callback.';<br />&nbsp; &nbsp; }&nbsp; &nbsp; <br /><br />&nbsp; &nbsp; public function getItems()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return $this-&gt;items;<br />&nbsp; &nbsp; }<br />}<br /><br />$o = new Test();<br />$itemLists = $o-&gt;getItems();<br /><br />foreach ($itemLists as $itemList) {<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; // call each one as a variable function<br />&nbsp; &nbsp; &nbsp; &nbsp; echo '&lt;pre&gt;';<br />&nbsp; &nbsp; &nbsp; &nbsp; print_r($itemList());<br />&nbsp; &nbsp; &nbsp; &nbsp; echo '&lt;/pre&gt;';<br />}<br /><br />// Outputs the following<br />// Test::callBackOne has been called as a callback.<br /><br />// Test::callBackTwo has been called as a callback.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119159">  <div class="votes">
    <div id="Vu119159">
    <a href="/manual/vote-note.php?id=119159&amp;page=language.types.callable&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119159">
    <a href="/manual/vote-note.php?id=119159&amp;page=language.types.callable&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119159" title="55% like this...">
    2
    </div>
  </div>
  <a href="#119159" class="name">
  <strong class="user"><em>pawel dot tadeusz dot niedzielski at gmail dot com</em></strong></a><a class="genanchor" href="#119159"> &para;</a><div class="date" title="2016-04-12 02:11"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119159">
<div class="phpcode"><code><span class="html">
@edanschwartz at gmail dot com<br /><br />You can use ::class property to always indicate the class you're in when using static methods:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Foo </span><span class="keyword">{<br />&nbsp; &nbsp; public static function </span><span class="default">doAwesomeThings</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">FunctionCaller</span><span class="keyword">::</span><span class="default">callIt</span><span class="keyword">(</span><span class="default">self</span><span class="keyword">::class . </span><span class="string">'::someAwesomeMethod'</span><span class="keyword">);<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public static function </span><span class="default">someAwesomeMethod</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// fantastic code goes here.<br />&nbsp; &nbsp; </span><span class="keyword">}<br />}<br /><br />class </span><span class="default">FunctionCaller </span><span class="keyword">{<br />&nbsp; &nbsp; public static function </span><span class="default">callIt</span><span class="keyword">(callable </span><span class="default">$func</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">call_user_func</span><span class="keyword">(</span><span class="default">$func</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">Foo</span><span class="keyword">::</span><span class="default">doAwesomeThings</span><span class="keyword">();<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.types.callable&amp;redirect=http://php.net/manual/en/language.types.callable.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.types.php">Types</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.types.intro.php" title="Introduction">Introduction</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.boolean.php" title="Booleans">Booleans</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.integer.php" title="Integers">Integers</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.float.php" title="Floating point numbers">Floating point numbers</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.string.php" title="Strings">Strings</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.array.php" title="Arrays">Arrays</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.iterable.php" title="Iterables">Iterables</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.object.php" title="Objects">Objects</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.resource.php" title="Resources">Resources</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.null.php" title="NULL">NULL</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.types.callable.php" title="Callbacks / Callables">Callbacks / Callables</a>
                        </li>
                          
                        <li class="">
                            <a href="language.pseudo-types.php" title="Pseudo-&#8203;types and variables used in this documentation">Pseudo-&#8203;types and variables used in this documentation</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.type-juggling.php" title="Type Juggling">Type Juggling</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

