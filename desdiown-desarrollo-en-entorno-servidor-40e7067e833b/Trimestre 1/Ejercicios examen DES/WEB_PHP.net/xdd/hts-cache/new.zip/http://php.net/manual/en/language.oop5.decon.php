<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Constructors and Destructors - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.oop5.decon.php">
 <link rel="shorturl" href="http://php.net/oop5.decon">
 <link rel="alternate" href="http://php.net/oop5.decon" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.oop5.php">
 <link rel="prev" href="http://php.net/manual/en/language.oop5.autoload.php">
 <link rel="next" href="http://php.net/manual/en/language.oop5.visibility.php">

 <link rel="alternate" href="http://php.net/manual/en/language.oop5.decon.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.oop5.decon.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.oop5.decon.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.oop5.decon.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.oop5.decon.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.oop5.decon.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.oop5.decon.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.oop5.decon.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.oop5.decon.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.oop5.decon.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.oop5.decon.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.oop5.visibility.php">
          Visibility &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.oop5.autoload.php">
          &laquo; Autoloading Classes        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.oop5.php'>Classes and Objects</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.oop5.decon.php' selected="selected">English</option>
            <option value='pt_BR/language.oop5.decon.php'>Brazilian Portuguese</option>
            <option value='zh/language.oop5.decon.php'>Chinese (Simplified)</option>
            <option value='fr/language.oop5.decon.php'>French</option>
            <option value='de/language.oop5.decon.php'>German</option>
            <option value='ja/language.oop5.decon.php'>Japanese</option>
            <option value='ro/language.oop5.decon.php'>Romanian</option>
            <option value='ru/language.oop5.decon.php'>Russian</option>
            <option value='es/language.oop5.decon.php'>Spanish</option>
            <option value='tr/language.oop5.decon.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.oop5.decon.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.oop5.decon">Report a Bug</a>
    </div>
  </div><div id="language.oop5.decon" class="sect1">
  <h2 class="title">Constructors and Destructors</h2>

  <div class="sect2" id="language.oop5.decon.constructor">
   <h3 class="title">Constructor</h3>
   <div class="methodsynopsis dc-description" id="object.construct">
    <span class="type"><span class="type void">void</span></span> <span class="methodname"><strong>__construct</strong></span>
     ([ <span class="methodparam"><span class="type"><a href="language.pseudo-types.php#language.types.mixed" class="type mixed">mixed</a></span> <code class="parameter">$args</code><span class="initializer"> = &quot;&quot;</span></span>
    [, <span class="methodparam"> <code class="parameter">$...</code></span>
   ]] )</div>

   <p class="para">
    PHP 5 allows developers to declare constructor methods for classes.
    Classes which have a constructor method call this method on each
    newly-created object, so it is suitable for any initialization that the
    object may need before it is used.
   </p>
   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <span class="simpara">
     Parent constructors are not called implicitly if the child class defines
     a constructor.  In order to run a parent constructor, a call to
     <span class="function"><strong>parent::__construct()</strong></span> within the child constructor is
     required. If the child does not define a constructor then it may be inherited
     from the parent class just like a normal class method (if it was not declared
     as private).
    </span>
   </p></blockquote>
   <div class="example" id="example-191">
    <p><strong>Example #1 using new unified constructors</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">BaseClass&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;function&nbsp;</span><span style="color: #0000BB">__construct</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;print&nbsp;</span><span style="color: #DD0000">"In&nbsp;BaseClass&nbsp;constructor\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;}<br />}<br /><br />class&nbsp;</span><span style="color: #0000BB">SubClass&nbsp;</span><span style="color: #007700">extends&nbsp;</span><span style="color: #0000BB">BaseClass&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;function&nbsp;</span><span style="color: #0000BB">__construct</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">parent</span><span style="color: #007700">::</span><span style="color: #0000BB">__construct</span><span style="color: #007700">();<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;print&nbsp;</span><span style="color: #DD0000">"In&nbsp;SubClass&nbsp;constructor\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;}<br />}<br /><br />class&nbsp;</span><span style="color: #0000BB">OtherSubClass&nbsp;</span><span style="color: #007700">extends&nbsp;</span><span style="color: #0000BB">BaseClass&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;inherits&nbsp;BaseClass's&nbsp;constructor<br /></span><span style="color: #007700">}<br /><br /></span><span style="color: #FF8000">//&nbsp;In&nbsp;BaseClass&nbsp;constructor<br /></span><span style="color: #0000BB">$obj&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">BaseClass</span><span style="color: #007700">();<br /><br /></span><span style="color: #FF8000">//&nbsp;In&nbsp;BaseClass&nbsp;constructor<br />//&nbsp;In&nbsp;SubClass&nbsp;constructor<br /></span><span style="color: #0000BB">$obj&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">SubClass</span><span style="color: #007700">();<br /><br /></span><span style="color: #FF8000">//&nbsp;In&nbsp;BaseClass&nbsp;constructor<br /></span><span style="color: #0000BB">$obj&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">OtherSubClass</span><span style="color: #007700">();<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
   <p class="para">
    For backwards compatibility with PHP 3 and 4, if PHP cannot find a 
    <a href="language.oop5.decon.php#object.construct" class="link">__construct()</a> function for a given
    class, it will
    search for the old-style constructor function, by the name of the class.
    Effectively, it means that the only case that would have compatibility
    issues is if the class had a method named 
    <a href="language.oop5.decon.php#object.construct" class="link">__construct()</a> which was used for
    different semantics.
   </p>
   
   <div class="warning"><strong class="warning">Warning</strong>
    <p class="simpara">
     Old style constructors are <em class="emphasis">DEPRECATED</em> in PHP 7.0, and
     will be removed in a future version. You should always use
     <a href="language.oop5.decon.php#object.construct" class="link">__construct()</a> in new code.
    </p>
   </div>
   <p class="para">
    Unlike with other methods, PHP will not generate an
    <strong><code>E_STRICT</code></strong> level error message when
    <a href="language.oop5.decon.php#object.construct" class="link">__construct()</a> is overridden with different parameters
    than the parent <a href="language.oop5.decon.php#object.construct" class="link">__construct()</a> method has.
   </p>
   <p class="para">
    As of PHP 5.3.3, methods with the same name as the last element of a
    namespaced class name will no longer be treated as constructor. This
    change doesn&#039;t affect non-namespaced classes.
   </p>
   <div class="example" id="example-192">
    <p><strong>Example #2 Constructors in namespaced classes</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">namespace&nbsp;</span><span style="color: #0000BB">Foo</span><span style="color: #007700">;<br />class&nbsp;</span><span style="color: #0000BB">Bar&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">Bar</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;treated&nbsp;as&nbsp;constructor&nbsp;in&nbsp;PHP&nbsp;5.3.0-5.3.2<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;treated&nbsp;as&nbsp;regular&nbsp;method&nbsp;as&nbsp;of&nbsp;PHP&nbsp;5.3.3<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">}<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
  </div>

  <div class="sect2" id="language.oop5.decon.destructor">
   <h3 class="title">Destructor</h3>
   <div class="methodsynopsis dc-description" id="object.destruct">
    <span class="type"><span class="type void">void</span></span> <span class="methodname"><strong>__destruct</strong></span>
     ( <span class="methodparam">void</span>
    )</div>

   <p class="para">
    PHP 5 introduces a destructor concept similar to that of other
    object-oriented languages, such as C++. The destructor method will be
    called as soon as there are no other references to a particular object,
    or in any order during the shutdown sequence.
   </p>
   <div class="example" id="example-193">
    <p><strong>Example #3 Destructor Example</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">MyDestructableClass&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;function&nbsp;</span><span style="color: #0000BB">__construct</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;print&nbsp;</span><span style="color: #DD0000">"In&nbsp;constructor\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">name&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">"MyDestructableClass"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;}<br /><br />&nbsp;&nbsp;&nbsp;function&nbsp;</span><span style="color: #0000BB">__destruct</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;print&nbsp;</span><span style="color: #DD0000">"Destroying&nbsp;"&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">name&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;}<br />}<br /><br /></span><span style="color: #0000BB">$obj&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">MyDestructableClass</span><span style="color: #007700">();<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
   <p class="para">
    Like constructors, parent destructors will not be called implicitly by
    the engine. In order to run a parent destructor, one would have to
    explicitly call <span class="function"><strong>parent::__destruct()</strong></span> in the destructor
    body. Also like constructors, a child class may inherit the parent&#039;s
    destructor if it does not implement one itself.
   </p>
   <p class="para">
    The destructor will be called even if script execution is stopped using
    <span class="function"><a href="function.exit.php" class="function">exit()</a></span>. Calling <span class="function"><a href="function.exit.php" class="function">exit()</a></span> in a destructor
    will prevent the remaining shutdown routines from executing.
   </p>
   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <p class="para">
     Destructors called during the script shutdown have HTTP headers already
     sent. The working directory in the script shutdown phase can be different
     with some SAPIs (e.g. Apache).
    </p>
   </p></blockquote>
   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <p class="para">
     Attempting to throw an exception from a destructor (called in the time of
     script termination) causes a fatal error.
    </p>
   </p></blockquote>
  </div>

 </div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.oop5.decon&amp;redirect=http://php.net/manual/en/language.oop5.decon.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">53 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="99903">  <div class="votes">
    <div id="Vu99903">
    <a href="/manual/vote-note.php?id=99903&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd99903">
    <a href="/manual/vote-note.php?id=99903&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V99903" title="71% like this...">
    296
    </div>
  </div>
  <a href="#99903" class="name">
  <strong class="user"><em>rayro at gmx dot de</em></strong></a><a class="genanchor" href="#99903"> &para;</a><div class="date" title="2010-09-14 03:35"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom99903">
<div class="phpcode"><code><span class="html">
the easiest way to use and understand multiple constructors:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">A<br /></span><span class="keyword">{<br />&nbsp; &nbsp; function </span><span class="default">__construct</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$a </span><span class="keyword">= </span><span class="default">func_get_args</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$i </span><span class="keyword">= </span><span class="default">func_num_args</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">method_exists</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">,</span><span class="default">$f</span><span class="keyword">=</span><span class="string">'__construct'</span><span class="keyword">.</span><span class="default">$i</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">call_user_func_array</span><span class="keyword">(array(</span><span class="default">$this</span><span class="keyword">,</span><span class="default">$f</span><span class="keyword">),</span><span class="default">$a</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">__construct1</span><span class="keyword">(</span><span class="default">$a1</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo(</span><span class="string">'__construct with 1 param called: '</span><span class="keyword">.</span><span class="default">$a1</span><span class="keyword">.</span><span class="default">PHP_EOL</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">__construct2</span><span class="keyword">(</span><span class="default">$a1</span><span class="keyword">,</span><span class="default">$a2</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo(</span><span class="string">'__construct with 2 params called: '</span><span class="keyword">.</span><span class="default">$a1</span><span class="keyword">.</span><span class="string">','</span><span class="keyword">.</span><span class="default">$a2</span><span class="keyword">.</span><span class="default">PHP_EOL</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">__construct3</span><span class="keyword">(</span><span class="default">$a1</span><span class="keyword">,</span><span class="default">$a2</span><span class="keyword">,</span><span class="default">$a3</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo(</span><span class="string">'__construct with 3 params called: '</span><span class="keyword">.</span><span class="default">$a1</span><span class="keyword">.</span><span class="string">','</span><span class="keyword">.</span><span class="default">$a2</span><span class="keyword">.</span><span class="string">','</span><span class="keyword">.</span><span class="default">$a3</span><span class="keyword">.</span><span class="default">PHP_EOL</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">$o </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">(</span><span class="string">'sheep'</span><span class="keyword">);<br /></span><span class="default">$o </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">(</span><span class="string">'sheep'</span><span class="keyword">,</span><span class="string">'cat'</span><span class="keyword">);<br /></span><span class="default">$o </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">(</span><span class="string">'sheep'</span><span class="keyword">,</span><span class="string">'cat'</span><span class="keyword">,</span><span class="string">'dog'</span><span class="keyword">);<br /><br /></span><span class="comment">// results:<br />// __construct with 1 param called: sheep<br />// __construct with 2 params called: sheep,cat<br />// __construct with 3 params called: sheep,cat,dog<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="105368">  <div class="votes">
    <div id="Vu105368">
    <a href="/manual/vote-note.php?id=105368&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd105368">
    <a href="/manual/vote-note.php?id=105368&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V105368" title="70% like this...">
    66
    </div>
  </div>
  <a href="#105368" class="name">
  <strong class="user"><em>david dot scourfield at llynfi dot co dot uk</em></strong></a><a class="genanchor" href="#105368"> &para;</a><div class="date" title="2011-08-12 04:17"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom105368">
<div class="phpcode"><code><span class="html">
Be aware of potential memory leaks caused by circular references within objects.&nbsp; The PHP manual states "[t]he destructor method will be called as soon as all references to a particular object are removed" and this is precisely true: if two objects reference each other (or even if one object has a field that points to itself as in $this-&gt;foo = $this) then this reference will prevent the destructor being called even when there are no other references to the object at all.&nbsp; The programmer can no longer access the objects, but they still stay in memory.<br /><br />Consider the following example:<br /><br /><span class="default">&lt;?php<br /><br />header</span><span class="keyword">(</span><span class="string">"Content-type: text/plain"</span><span class="keyword">);<br /><br />class </span><span class="default">Foo </span><span class="keyword">{<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * An indentifier<br />&nbsp; &nbsp;&nbsp; * @var string <br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">private </span><span class="default">$name</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * A reference to another Foo object<br />&nbsp; &nbsp;&nbsp; * @var Foo<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">private </span><span class="default">$link</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">name </span><span class="keyword">= </span><span class="default">$name</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">setLink</span><span class="keyword">(</span><span class="default">Foo $link</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">link </span><span class="keyword">= </span><span class="default">$link</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">__destruct</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'Destroying: '</span><span class="keyword">, </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">name</span><span class="keyword">, </span><span class="default">PHP_EOL</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="comment">// create two Foo objects:<br /></span><span class="default">$foo </span><span class="keyword">= new </span><span class="default">Foo</span><span class="keyword">(</span><span class="string">'Foo 1'</span><span class="keyword">);<br /></span><span class="default">$bar </span><span class="keyword">= new </span><span class="default">Foo</span><span class="keyword">(</span><span class="string">'Foo 2'</span><span class="keyword">);<br /><br /></span><span class="comment">// make them point to each other<br /></span><span class="default">$foo</span><span class="keyword">-&gt;</span><span class="default">setLink</span><span class="keyword">(</span><span class="default">$bar</span><span class="keyword">);<br /></span><span class="default">$bar</span><span class="keyword">-&gt;</span><span class="default">setLink</span><span class="keyword">(</span><span class="default">$foo</span><span class="keyword">);<br /><br /></span><span class="comment">// destroy the global references to them<br /></span><span class="default">$foo </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br /></span><span class="default">$bar </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br /><br /></span><span class="comment">// we now have no way to access Foo 1 or Foo 2, so they OUGHT to be __destruct()ed<br />// but they are not, so we get a memory leak as they are still in memory.<br />//<br />// Uncomment the next line to see the difference when explicitly calling the GC:<br />// gc_collect_cycles();<br />// <br />// see also: <a href="http://www.php.net/manual/en/features.gc.php" rel="nofollow" target="_blank">http://www.php.net/manual/en/features.gc.php</a><br />// <br /><br />// create two more Foo objects, but DO NOT set their internal Foo references<br />// so nothing except the vars $foo and $bar point to them:<br /></span><span class="default">$foo </span><span class="keyword">= new </span><span class="default">Foo</span><span class="keyword">(</span><span class="string">'Foo 3'</span><span class="keyword">);<br /></span><span class="default">$bar </span><span class="keyword">= new </span><span class="default">Foo</span><span class="keyword">(</span><span class="string">'Foo 4'</span><span class="keyword">);<br /><br /></span><span class="comment">// destroy the global references to them<br /></span><span class="default">$foo </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br /></span><span class="default">$bar </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br /><br /></span><span class="comment">// we now have no way to access Foo 3 or Foo 4 and as there are no more references<br />// to them anywhere, their __destruct() methods are automatically called here,<br />// BEFORE the next line is executed:<br /><br /></span><span class="keyword">echo </span><span class="string">'End of script'</span><span class="keyword">, </span><span class="default">PHP_EOL</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;<br /></span><br />This will output:<br /><br />Destroying: Foo 3<br />Destroying: Foo 4<br />End of script<br />Destroying: Foo 1<br />Destroying: Foo 2<br /><br />But if we uncomment the gc_collect_cycles(); function call in the middle of the script, we get:<br /><br />Destroying: Foo 2<br />Destroying: Foo 1<br />Destroying: Foo 3<br />Destroying: Foo 4<br />End of script<br /><br />As may be desired.<br /><br />NOTE: calling gc_collect_cycles() does have a speed overhead, so only use it if you feel you need to.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121521">  <div class="votes">
    <div id="Vu121521">
    <a href="/manual/vote-note.php?id=121521&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121521">
    <a href="/manual/vote-note.php?id=121521&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121521" title="76% like this...">
    7
    </div>
  </div>
  <a href="#121521" class="name">
  <strong class="user"><em>domger at freenet dot de</em></strong></a><a class="genanchor" href="#121521"> &para;</a><div class="date" title="2017-08-14 07:53"><strong>4 months ago</strong></div>
  <div class="text" id="Hcom121521">
<div class="phpcode"><code><span class="html">
The __destruct magic method must be public. <br /><br />public function __destruct()<br />{<br />&nbsp; &nbsp; ;<br />}<br /><br />The method will automatically be called externally to the instance.&nbsp; Declaring __destruct as protected or private will result in a warning and the magic method will not be called. <br /><br />Note: In PHP 5.3.10 i saw strange side effects while some Destructors were declared as protected.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="80314">  <div class="votes">
    <div id="Vu80314">
    <a href="/manual/vote-note.php?id=80314&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd80314">
    <a href="/manual/vote-note.php?id=80314&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V80314" title="64% like this...">
    29
    </div>
  </div>
  <a href="#80314" class="name">
  <strong class="user"><em>nerdystudmuffin at gmail dot com</em></strong></a><a class="genanchor" href="#80314"> &para;</a><div class="date" title="2008-01-09 11:11"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom80314">
<div class="phpcode"><code><span class="html">
Correction to the previous poster about non public constructors. If I wanted to implement Singleton design pattern where I would only want one instance of the class I would want to prevent instantiation of the class from outside of the class by making the constructor private. An example follows:<br /><br />class Foo {<br /><br />&nbsp; private static $instance;<br /><br />&nbsp; private __construct() {<br />&nbsp; &nbsp; // Do stuff<br />&nbsp; }<br /><br />&nbsp; public static getInstance() {<br /><br />&nbsp; &nbsp; if (!isset(self::$instance)) {<br />&nbsp; &nbsp; &nbsp; $c = __CLASS__;<br />&nbsp; &nbsp; &nbsp; $instance = new $c;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; return self::$instance;<br />&nbsp; }<br /><br />&nbsp; public function sayHello() {<br />&nbsp; &nbsp; echo "Hello World!!";<br />&nbsp; }<br /><br />}<br /><br />$bar = Foo::getInstance();<br /><br />// Prints 'Hello World' on the screen.<br />$bar -&gt; sayHello();</span>
</code></div>
  </div>
 </div>
  <div class="note" id="108598">  <div class="votes">
    <div id="Vu108598">
    <a href="/manual/vote-note.php?id=108598&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd108598">
    <a href="/manual/vote-note.php?id=108598&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V108598" title="58% like this...">
    9
    </div>
  </div>
  <a href="#108598" class="name">
  <strong class="user"><em>Per Persson</em></strong></a><a class="genanchor" href="#108598"> &para;</a><div class="date" title="2012-05-09 01:57"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom108598">
<div class="phpcode"><code><span class="html">
As of PHP 5.3.10 destructors are not run on shutdown caused by fatal errors.<br /><br />For example:<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Logger<br /></span><span class="keyword">{<br />&nbsp; &nbsp; protected </span><span class="default">$rows </span><span class="keyword">= array();<br /><br />&nbsp; &nbsp; public function </span><span class="default">__destruct</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">save</span><span class="keyword">();<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">log</span><span class="keyword">(</span><span class="default">$row</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">rows</span><span class="keyword">[] = </span><span class="default">$row</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">save</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'&lt;ul&gt;'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach (</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">rows </span><span class="keyword">as </span><span class="default">$row</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'&lt;li&gt;'</span><span class="keyword">, </span><span class="default">$row</span><span class="keyword">, </span><span class="string">'&lt;/li&gt;'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'&lt;/ul&gt;'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$logger </span><span class="keyword">= new </span><span class="default">Logger</span><span class="keyword">;<br /></span><span class="default">$logger</span><span class="keyword">-&gt;</span><span class="default">log</span><span class="keyword">(</span><span class="string">'Before'</span><span class="keyword">);<br /><br /></span><span class="default">$nonset</span><span class="keyword">-&gt;</span><span class="default">foo</span><span class="keyword">();<br /><br /></span><span class="default">$logger</span><span class="keyword">-&gt;</span><span class="default">log</span><span class="keyword">(</span><span class="string">'After'</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />Without the $nonset-&gt;foo(); line, Before and After will both be printed, but with the line neither will be printed.<br /><br />One can however register the destructor or another method as a shutdown function:<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Logger<br /></span><span class="keyword">{<br />&nbsp; &nbsp; protected </span><span class="default">$rows </span><span class="keyword">= array();<br /><br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">register_shutdown_function</span><span class="keyword">(array(</span><span class="default">$this</span><span class="keyword">, </span><span class="string">'__destruct'</span><span class="keyword">));<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">__destruct</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">save</span><span class="keyword">();<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">log</span><span class="keyword">(</span><span class="default">$row</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">rows</span><span class="keyword">[] = </span><span class="default">$row</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">save</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'&lt;ul&gt;'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach (</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">rows </span><span class="keyword">as </span><span class="default">$row</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'&lt;li&gt;'</span><span class="keyword">, </span><span class="default">$row</span><span class="keyword">, </span><span class="string">'&lt;/li&gt;'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'&lt;/ul&gt;'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$logger </span><span class="keyword">= new </span><span class="default">Logger</span><span class="keyword">;<br /></span><span class="default">$logger</span><span class="keyword">-&gt;</span><span class="default">log</span><span class="keyword">(</span><span class="string">'Before'</span><span class="keyword">);<br /><br /></span><span class="default">$nonset</span><span class="keyword">-&gt;</span><span class="default">foo</span><span class="keyword">();<br /><br /></span><span class="default">$logger</span><span class="keyword">-&gt;</span><span class="default">log</span><span class="keyword">(</span><span class="string">'After'</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span>Now Before will be printed, but not After, so you can see that a shutdown occurred after Before.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="51414">  <div class="votes">
    <div id="Vu51414">
    <a href="/manual/vote-note.php?id=51414&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd51414">
    <a href="/manual/vote-note.php?id=51414&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V51414" title="60% like this...">
    4
    </div>
  </div>
  <a href="#51414" class="name">
  <strong class="user"><em>apfelsaft</em></strong></a><a class="genanchor" href="#51414"> &para;</a><div class="date" title="2005-03-30 01:59"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom51414">
<div class="phpcode"><code><span class="html">
at the end of a script all remaining objects aren't in fact destructed. it is only their __destruct() method, which will be called. the objects still exist after that.<br /><br />so, if your database connection object has no __destruct() or at least it doesn't disconnects the database, it will still work.<br /><br />in general, there is no need to disconnect the database (especially for persistent connections).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="85638">  <div class="votes">
    <div id="Vu85638">
    <a href="/manual/vote-note.php?id=85638&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd85638">
    <a href="/manual/vote-note.php?id=85638&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V85638" title="58% like this...">
    7
    </div>
  </div>
  <a href="#85638" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#85638"> &para;</a><div class="date" title="2008-09-09 05:42"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom85638">
<div class="phpcode"><code><span class="html">
USE PARENT::CONSTRUCT() to exploit POLYMORPHISM POWERS<br /><br />Since we are still in the __construct and __destruct section, alot of emphasis has been on __destruct - which I know nothing about. But I would like to show the power of parent::__construct for use with PHP's OOP polymorphic behavior (you'll see what this is very quickly).<br /><br />In my example, I have created a fairly robust base class that does everything that all subclasses need to do. Here's the base class def.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="comment">/*<br /> * Animal.php<br /> *<br /> * This class holds all data, and defines all functions that all <br /> * subclass extensions need to use.<br /> *<br /> */<br /></span><span class="keyword">abstract class </span><span class="default">Animal<br /></span><span class="keyword">{<br />&nbsp; public </span><span class="default">$type</span><span class="keyword">;<br />&nbsp; public </span><span class="default">$name</span><span class="keyword">;<br />&nbsp; public </span><span class="default">$sound</span><span class="keyword">;<br /><br />&nbsp; </span><span class="comment">/*<br />&nbsp;&nbsp; * called by Dog, Cat, Bird, etc.<br />&nbsp;&nbsp; */<br />&nbsp; </span><span class="keyword">public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$aType</span><span class="keyword">, </span><span class="default">$aName</span><span class="keyword">, </span><span class="default">$aSound</span><span class="keyword">)<br />&nbsp; {<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">type </span><span class="keyword">= </span><span class="default">$aType</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">name </span><span class="keyword">= </span><span class="default">$aName</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">sound </span><span class="keyword">= </span><span class="default">$aSound</span><span class="keyword">;<br />&nbsp; }<br /><br />&nbsp; </span><span class="comment">/*<br />&nbsp;&nbsp; * define the sorting rules - we will sort all Animals by name.<br />&nbsp;&nbsp; */ <br />&nbsp; </span><span class="keyword">public static function </span><span class="default">compare</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">)<br />&nbsp; {<br />&nbsp; &nbsp; if(</span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">name </span><span class="keyword">&lt; </span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">name</span><span class="keyword">) return -</span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; else if(</span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">name </span><span class="keyword">== </span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">name</span><span class="keyword">) return </span><span class="default">0</span><span class="keyword">;<br />&nbsp; &nbsp; else return </span><span class="default">1</span><span class="keyword">;<br />&nbsp; }<br /><br />&nbsp; </span><span class="comment">/*<br />&nbsp;&nbsp; * a String representation for all Animals.<br />&nbsp;&nbsp; */<br />&nbsp; </span><span class="keyword">public function </span><span class="default">__toString</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; return </span><span class="string">"</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">name</span><span class="string"> the </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">type</span><span class="string"> goes </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">sound</span><span class="string">"</span><span class="keyword">;<br />&nbsp; }<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />Trying to instantiate an object of type Animal will not work...<br /><br />$myPet = new Animal("Parrot", "Captain Jack", "Kaaawww!"); // throws Fatal Error: cannot instantiate abstract class Animal.<br /><br />Declaring Animal as abstract is like killing two birds with one stone. 1. We stop it from being instantiated - which means we do not need a private __construct() or a static getInstance() method, and 2. We can use it for polymorphic behavior. In our case here, that means "__construct", "__toString" and "compare" will be called for all subclasses of Animal that have not defined their own implementations.<br /><br />The following subclasses use parent::__construct(), which sends all new data to Animal. Our Animal class stores this data and defines functions for polymorphism to work... and the best part is, it keeps our subclass defs super short and even sweeter.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">Dog </span><span class="keyword">extends </span><span class="default">Animal</span><span class="keyword">{<br />&nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">){<br />&nbsp; &nbsp; </span><span class="default">parent</span><span class="keyword">::</span><span class="default">__construct</span><span class="keyword">(</span><span class="string">"Dog"</span><span class="keyword">, </span><span class="default">$name</span><span class="keyword">, </span><span class="string">"woof!"</span><span class="keyword">);<br />&nbsp; }<br />}<br /><br />class </span><span class="default">Cat </span><span class="keyword">extends </span><span class="default">Animal</span><span class="keyword">{<br />&nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">){<br />&nbsp; &nbsp; </span><span class="default">parent</span><span class="keyword">::</span><span class="default">__construct</span><span class="keyword">(</span><span class="string">"Cat"</span><span class="keyword">, </span><span class="default">$name</span><span class="keyword">, </span><span class="string">"meeoow!"</span><span class="keyword">);<br />&nbsp; }<br />}<br /><br />class </span><span class="default">Bird </span><span class="keyword">extends </span><span class="default">Animal</span><span class="keyword">{<br />&nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">){<br />&nbsp; &nbsp; </span><span class="default">parent</span><span class="keyword">::</span><span class="default">__construct</span><span class="keyword">(</span><span class="string">"Bird"</span><span class="keyword">, </span><span class="default">$name</span><span class="keyword">, </span><span class="string">"chirp chirp!!"</span><span class="keyword">);<br />&nbsp; }<br />}<br /><br /></span><span class="comment"># create a PHP Array and initialize it with Animal objects<br /></span><span class="default">$animals </span><span class="keyword">= array(<br />&nbsp; new </span><span class="default">Dog</span><span class="keyword">(</span><span class="string">"Fido"</span><span class="keyword">),<br />&nbsp; new </span><span class="default">Bird</span><span class="keyword">(</span><span class="string">"Celeste"</span><span class="keyword">),<br />&nbsp; new </span><span class="default">Cat</span><span class="keyword">(</span><span class="string">"Pussy"</span><span class="keyword">),<br />&nbsp; new </span><span class="default">Dog</span><span class="keyword">(</span><span class="string">"Brad"</span><span class="keyword">),<br />&nbsp; new </span><span class="default">Bird</span><span class="keyword">(</span><span class="string">"Kiki"</span><span class="keyword">),<br />&nbsp; new </span><span class="default">Cat</span><span class="keyword">(</span><span class="string">"Abraham"</span><span class="keyword">),<br />&nbsp; new </span><span class="default">Dog</span><span class="keyword">(</span><span class="string">"Jawbone"</span><span class="keyword">)<br />);<br /><br /></span><span class="comment"># sort $animals with PHP's usort - calls Animal::compare() many many times.<br /></span><span class="default">usort</span><span class="keyword">(</span><span class="default">$animals</span><span class="keyword">, array(</span><span class="string">"Animal"</span><span class="keyword">, </span><span class="string">"compare"</span><span class="keyword">));<br /><br /></span><span class="comment"># print out the sorted results - calls Animal-&gt;__toString().<br /></span><span class="keyword">foreach(</span><span class="default">$animals </span><span class="keyword">as </span><span class="default">$animal</span><span class="keyword">) echo </span><span class="string">"</span><span class="default">$animal</span><span class="string">&lt;br&gt;\n"</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;<br /></span><br />The results are "sorted by name" and "printed" by the Animal class:<br /><br />Abraham the Cat goes meeoow!<br />Brad the Dog goes woof!<br />Celeste the Bird goes chirp chirp!!<br />Fido the Dog goes woof!<br />Jawbone the Dog goes woof!<br />Kiki the Bird goes chirp chirp!!<br />Pussy the Cat goes meeoow!<br /><br />Using parent::__construct() in a subclass and a super smart base class, gives your child objects a headstart in life, by alleviating them from having to define or handle several error and exception routines that they have no control over.<br /><br />Notice how subclass definitions are really short - no variables or functions at all, and there is no private __construct() method anywhere? Notice how objects of type Dog, Cat, and Bird are all sorted by our base class Animal? All the class definitions above address several issues (keeping objects from being instantiated) and enforces the desired, consistent, and reliable behavior everytime... with the least amount of code. In addition, new extenstions can easily be created. Each subclass is now super easy to redefine or even extend... now that you can see a way to do it.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="68028">  <div class="votes">
    <div id="Vu68028">
    <a href="/manual/vote-note.php?id=68028&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd68028">
    <a href="/manual/vote-note.php?id=68028&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V68028" title="58% like this...">
    4
    </div>
  </div>
  <a href="#68028" class="name">
  <strong class="user"><em>Reza Mahjourian</em></strong></a><a class="genanchor" href="#68028"> &para;</a><div class="date" title="2006-07-10 02:18"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom68028">
<div class="phpcode"><code><span class="html">
Peter has suggested using static methods to compensate for unavailability of multiple constructors in PHP.&nbsp; This works fine for most purposes, but if you have a class hierarchy and want to delegate parts of initialization to the parent class, you can no longer use this scheme.&nbsp; It is because unlike constructors, in a static method you need to do the instantiation yourself.&nbsp; So if you call the parent static method, you will get an object of parent type which you can't continue to initialize with derived class fields.<br /><br />Imagine you have an Employee class and a derived HourlyEmployee class and you want to be able to construct these objects out of some XML input too.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Employee </span><span class="keyword">{<br />&nbsp;&nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$inName</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">name </span><span class="keyword">= </span><span class="default">$inName</span><span class="keyword">;<br />&nbsp;&nbsp; }<br /><br />&nbsp;&nbsp; public static function </span><span class="default">constructFromDom</span><span class="keyword">(</span><span class="default">$inDom</span><span class="keyword">)<br />&nbsp;&nbsp; {<br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$name </span><span class="keyword">= </span><span class="default">$inDom</span><span class="keyword">-&gt;</span><span class="default">name</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp;&nbsp; return new </span><span class="default">Employee</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">);<br />&nbsp;&nbsp; }<br /><br />&nbsp;&nbsp; private </span><span class="default">$name</span><span class="keyword">;<br />}<br /><br />class </span><span class="default">HourlyEmployee </span><span class="keyword">extends </span><span class="default">Employee </span><span class="keyword">{<br />&nbsp;&nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$inName</span><span class="keyword">, </span><span class="default">$inHourlyRate</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">parent</span><span class="keyword">::</span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$inName</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">hourlyRate </span><span class="keyword">= </span><span class="default">$inHourlyRate</span><span class="keyword">;<br />&nbsp;&nbsp; }<br /><br />&nbsp;&nbsp; public static function </span><span class="default">constructFromDom</span><span class="keyword">(</span><span class="default">$inDom</span><span class="keyword">)<br />&nbsp;&nbsp; {<br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="comment">// can't call parent::constructFromDom($inDom)<br />&nbsp; &nbsp; &nbsp;&nbsp; // need to do all the work here again<br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$name </span><span class="keyword">= </span><span class="default">$inDom</span><span class="keyword">-&gt;</span><span class="default">name</span><span class="keyword">;&nbsp; </span><span class="comment">// increased coupling<br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$hourlyRate </span><span class="keyword">= </span><span class="default">$inDom</span><span class="keyword">-&gt;</span><span class="default">hourlyrate</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp;&nbsp; return new </span><span class="default">EmployeeHourly</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">, </span><span class="default">$hourlyRate</span><span class="keyword">);<br />&nbsp;&nbsp; }<br /><br />&nbsp;&nbsp; private </span><span class="default">$hourlyRate</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />The only solution is to merge the two constructors in one by adding an optional $inDom parameter to every constructor.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="82477">  <div class="votes">
    <div id="Vu82477">
    <a href="/manual/vote-note.php?id=82477&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd82477">
    <a href="/manual/vote-note.php?id=82477&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V82477" title="57% like this...">
    1
    </div>
  </div>
  <a href="#82477" class="name">
  <strong class="user"><em>ashnazg at php dot net</em></strong></a><a class="genanchor" href="#82477"> &para;</a><div class="date" title="2008-04-12 10:26"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom82477">
<div class="phpcode"><code><span class="html">
Since my last note, I've been instructed to _NEVER_ call "unset($this)", never ever ever.&nbsp; Since my previous testing of behavior did not explicitly show me that it was indeed necessary, I'm inclined to trust those telling me not to do it.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="80107">  <div class="votes">
    <div id="Vu80107">
    <a href="/manual/vote-note.php?id=80107&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd80107">
    <a href="/manual/vote-note.php?id=80107&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V80107" title="57% like this...">
    1
    </div>
  </div>
  <a href="#80107" class="name">
  <strong class="user"><em>david at synatree dot com</em></strong></a><a class="genanchor" href="#80107"> &para;</a><div class="date" title="2007-12-29 01:26"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom80107">
<div class="phpcode"><code><span class="html">
When a script is in the process of die()ing, you can't count on the order in which __destruct() will be called.<br /><br />For a script I have been working on, I wanted to do transparent low-level encryption of any outgoing data.&nbsp; To accomplish this, I used a global singleton class configured like this:<br /><br />class EncryptedComms<br />{<br />&nbsp; &nbsp; private $C;<br />&nbsp; &nbsp; private $objs = array();<br />&nbsp; &nbsp; private static $_me;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public static function destroyAfter(&amp;$obj)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; self::getInstance()-&gt;objs[] =&amp; $obj;<br />&nbsp; &nbsp; &nbsp; &nbsp; /*<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Hopefully by forcing a reference to another object to exist <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; inside this class, the referenced object will need to be destroyed<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; before garbage collection can occur on this object.&nbsp; This will force <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; this object's destruct method to be fired AFTER the destructors of<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; all the objects referenced here.<br />&nbsp; &nbsp; &nbsp; &nbsp; */<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public function __construct($key)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $this-&gt;C = new SimpleCrypt($key);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ob_start(array($this,'getBuffer'));<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public static function &amp;getInstance($key=NULL)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; if(!self::$_me &amp;&amp; $key)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; self::$_me = new EncryptedComms($key);<br />&nbsp; &nbsp; &nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return self::$_me;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function __destruct()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; ob_end_flush();<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function getBuffer($str)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return $this-&gt;C-&gt;encrypt($str);<br />&nbsp; &nbsp; }<br /><br />}<br /><br />In this example, I tried to register other objects to always be destroyed just before this object.&nbsp; Like this:<br /><br />class A<br />{<br /><br />public function __construct()<br />{<br />&nbsp; &nbsp;&nbsp; EncryptedComms::destroyAfter($this);<br />}<br />}<br /><br />One would think that the references to the objects contained in the singleton would be destroyed first, but this is not the case.&nbsp; In fact, this won't work even if you reverse the paradigm and store a reference to EncryptedComms in every object you'd like to be destroyed before it.<br /><br />In short, when a script die()s, there doesn't seem to be any way to predict the order in which the destructors will fire.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="106968">  <div class="votes">
    <div id="Vu106968">
    <a href="/manual/vote-note.php?id=106968&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd106968">
    <a href="/manual/vote-note.php?id=106968&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V106968" title="55% like this...">
    3
    </div>
  </div>
  <a href="#106968" class="name">
  <strong class="user"><em>philipwaynerollins at gmail dot com</em></strong></a><a class="genanchor" href="#106968"> &para;</a><div class="date" title="2011-12-21 08:51"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom106968">
<div class="phpcode"><code><span class="html">
With the destructor if you're going to write to a file make sure you have the full file path and not just the filename, it seems PHP switches the working directory to the apache root directory when exiting the script.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="95569">  <div class="votes">
    <div id="Vu95569">
    <a href="/manual/vote-note.php?id=95569&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd95569">
    <a href="/manual/vote-note.php?id=95569&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V95569" title="55% like this...">
    3
    </div>
  </div>
  <a href="#95569" class="name">
  <strong class="user"><em>Jonathon Hibbard</em></strong></a><a class="genanchor" href="#95569"> &para;</a><div class="date" title="2010-01-09 04:32"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom95569">
<div class="phpcode"><code><span class="html">
Please be aware of when using __destruct() in which you are unsetting variables...<br /><br />Consider the following code:<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">my_class </span><span class="keyword">{<br />&nbsp; public </span><span class="default">$error_reporting </span><span class="keyword">= </span><span class="default">false</span><span class="keyword">;<br /><br />&nbsp; function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$error_reporting </span><span class="keyword">= </span><span class="default">false</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">error_reporting </span><span class="keyword">= </span><span class="default">$error_reporting</span><span class="keyword">;<br />&nbsp; }<br /><br />&nbsp; function </span><span class="default">__destruct</span><span class="keyword">() {<br />&nbsp; &nbsp; if(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">error_reporting </span><span class="keyword">=== </span><span class="default">true</span><span class="keyword">) </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">show_report</span><span class="keyword">();<br />&nbsp; &nbsp; unset(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">error_reporting</span><span class="keyword">);<br />&nbsp; }<br /></span><span class="default">?&gt;<br /></span><br />The above will result in an error:<br />Notice: Undefined property: my_class::$error_reporting in my_class.php on line 10<br /><br />It appears as though the variable will be unset BEFORE it actually can execute the if statement.&nbsp; Removing the unset will fix this.&nbsp; It's not needed anyways as PHP will release everything anyways, but just in case you run across this, you know why ;)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="76710">  <div class="votes">
    <div id="Vu76710">
    <a href="/manual/vote-note.php?id=76710&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd76710">
    <a href="/manual/vote-note.php?id=76710&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V76710" title="56% like this...">
    3
    </div>
  </div>
  <a href="#76710" class="name">
  <strong class="user"><em>prieler at abm dot at</em></strong></a><a class="genanchor" href="#76710"> &para;</a><div class="date" title="2007-07-27 12:42"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom76710">
<div class="phpcode"><code><span class="html">
i have written a quick example about the order of destructors and shutdown functions in php 5.2.1:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">destruction </span><span class="keyword">{<br />&nbsp; &nbsp; var </span><span class="default">$name</span><span class="keyword">;<br /><br />&nbsp; &nbsp; function </span><span class="default">destruction</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">name </span><span class="keyword">= </span><span class="default">$name</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">register_shutdown_function</span><span class="keyword">(array(&amp;</span><span class="default">$this</span><span class="keyword">, </span><span class="string">"shutdown"</span><span class="keyword">));<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; function </span><span class="default">shutdown</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'shutdown: '</span><span class="keyword">.</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">name</span><span class="keyword">.</span><span class="string">"\n"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; function </span><span class="default">__destruct</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'destruct: '</span><span class="keyword">.</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">name</span><span class="keyword">.</span><span class="string">"\n"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">destruction</span><span class="keyword">(</span><span class="string">'a: global 1'</span><span class="keyword">);<br /><br />function </span><span class="default">test</span><span class="keyword">() {<br />&nbsp; &nbsp; </span><span class="default">$b </span><span class="keyword">= new </span><span class="default">destruction</span><span class="keyword">(</span><span class="string">'b: func 1'</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$c </span><span class="keyword">= new </span><span class="default">destruction</span><span class="keyword">(</span><span class="string">'c: func 2'</span><span class="keyword">);<br />}<br /></span><span class="default">test</span><span class="keyword">();<br /><br /></span><span class="default">$d </span><span class="keyword">= new </span><span class="default">destruction</span><span class="keyword">(</span><span class="string">'d: global 2'</span><span class="keyword">);<br /><br /></span><span class="default">?&gt;<br /></span><br />this will output:<br />shutdown: a: global 1<br />shutdown: b: func 1<br />shutdown: c: func 2<br />shutdown: d: global 2<br />destruct: b: func 1<br />destruct: c: func 2<br />destruct: d: global 2<br />destruct: a: global 1<br /><br />conclusions:<br />destructors are always called on script end.<br />destructors are called in order of their "context": first functions, then global objects<br />objects in function context are deleted in order as they are set (older objects first).<br />objects in global context are deleted in reverse order (older objects last)<br /><br />shutdown functions are called before the destructors.<br />shutdown functions are called in there "register" order. ;)<br /><br />regards, J</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113968">  <div class="votes">
    <div id="Vu113968">
    <a href="/manual/vote-note.php?id=113968&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113968">
    <a href="/manual/vote-note.php?id=113968&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113968" title="54% like this...">
    1
    </div>
  </div>
  <a href="#113968" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#113968"> &para;</a><div class="date" title="2013-12-23 01:45"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom113968">
<div class="phpcode"><code><span class="html">
By inheriting from this class, you can do constructor overloading in terms of type hinting.<br /><span class="default">&lt;?php<br />&nbsp;&nbsp; </span><span class="keyword">abstract class </span><span class="default">OverloadedConstructors </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; public final function </span><span class="default">__construct</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$self </span><span class="keyword">= new </span><span class="default">ReflectionClass</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$constructors </span><span class="keyword">= </span><span class="default">array_filter</span><span class="keyword">(</span><span class="default">$self</span><span class="keyword">-&gt;</span><span class="default">getMethods</span><span class="keyword">(</span><span class="default">ReflectionMethod</span><span class="keyword">::</span><span class="default">IS_PUBLIC</span><span class="keyword">), function(</span><span class="default">ReflectionMethod $m</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">substr</span><span class="keyword">(</span><span class="default">$m</span><span class="keyword">-&gt;</span><span class="default">name</span><span class="keyword">, </span><span class="default">0</span><span class="keyword">, </span><span class="default">11</span><span class="keyword">) === </span><span class="string">'__construct'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; });<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; if(</span><span class="default">sizeof</span><span class="keyword">(</span><span class="default">$constructors</span><span class="keyword">) === </span><span class="default">0</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">trigger_error</span><span class="keyword">(</span><span class="string">'The class ' </span><span class="keyword">. </span><span class="default">get_called_class</span><span class="keyword">() . </span><span class="string">' does not provide a valid constructor.'</span><span class="keyword">, </span><span class="default">E_USER_ERROR</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$number </span><span class="keyword">= </span><span class="default">func_num_args</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$arguments </span><span class="keyword">= </span><span class="default">func_get_args</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; foreach(</span><span class="default">$constructors </span><span class="keyword">as </span><span class="default">$constructor</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if((</span><span class="default">$number </span><span class="keyword">&gt;= </span><span class="default">$constructor</span><span class="keyword">-&gt;</span><span class="default">getNumberOfRequiredParameters</span><span class="keyword">()) &amp;&amp;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; (</span><span class="default">$number </span><span class="keyword">&lt;= </span><span class="default">$constructor</span><span class="keyword">-&gt;</span><span class="default">getNumberOfParameters</span><span class="keyword">())) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$parameters </span><span class="keyword">= </span><span class="default">$constructor</span><span class="keyword">-&gt;</span><span class="default">getParameters</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">reset</span><span class="keyword">(</span><span class="default">$parameters</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; foreach(</span><span class="default">$arguments </span><span class="keyword">as </span><span class="default">$arg</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$parameter </span><span class="keyword">= </span><span class="default">current</span><span class="keyword">(</span><span class="default">$parameters</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">$parameter</span><span class="keyword">-&gt;</span><span class="default">isArray</span><span class="keyword">()) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; if(!</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$arg</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; continue </span><span class="default">2</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }elseif((</span><span class="default">$expectedClass </span><span class="keyword">= </span><span class="default">$parameter</span><span class="keyword">-&gt;</span><span class="default">getClass</span><span class="keyword">()) !== </span><span class="default">null</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; if(!(</span><span class="default">is_object</span><span class="keyword">(</span><span class="default">$arg</span><span class="keyword">) &amp;&amp; </span><span class="default">$expectedClass</span><span class="keyword">-&gt;</span><span class="default">isInstance</span><span class="keyword">(</span><span class="default">$arg</span><span class="keyword">)))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; continue </span><span class="default">2</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">next</span><span class="keyword">(</span><span class="default">$parameters</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$constructor</span><span class="keyword">-&gt;</span><span class="default">invokeArgs</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">, </span><span class="default">$arguments</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; return;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">trigger_error</span><span class="keyword">(</span><span class="string">'The required constructor for the class ' </span><span class="keyword">. </span><span class="default">get_called_class</span><span class="keyword">() . </span><span class="string">' did not exist.'</span><span class="keyword">, </span><span class="default">E_USER_ERROR</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; }<br />&nbsp;&nbsp; }<br /></span><span class="default">?&gt;<br /></span>Simply define a class like this:<br /><span class="default">&lt;?php<br />&nbsp;&nbsp; </span><span class="keyword">class </span><span class="default">Test </span><span class="keyword">extends </span><span class="default">OverloadedConstructors </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; public function </span><span class="default">__construct1</span><span class="keyword">(array </span><span class="default">$arg</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; die(</span><span class="string">'First construct'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; public function </span><span class="default">__construct2</span><span class="keyword">(</span><span class="default">stdClass $test</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; die(</span><span class="string">'Second construct'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; public function </span><span class="default">__construct3</span><span class="keyword">(</span><span class="default">$optional </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; die(</span><span class="string">'Third construct'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; }<br />&nbsp;&nbsp; }<br /></span><span class="default">?&gt;<br /></span>You can define as much constructors as you wish and limit them by php's type hinting. Note that the constructor signatures should be non-ambiguous.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="86423">  <div class="votes">
    <div id="Vu86423">
    <a href="/manual/vote-note.php?id=86423&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86423">
    <a href="/manual/vote-note.php?id=86423&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86423" title="55% like this...">
    3
    </div>
  </div>
  <a href="#86423" class="name">
  <strong class="user"><em>spleen</em></strong></a><a class="genanchor" href="#86423"> &para;</a><div class="date" title="2008-10-17 04:35"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86423">
<div class="phpcode"><code><span class="html">
It's always the easy things that get you -<br /><br />Being new to OOP, it took me quite a while to figure out that there are TWO underscores in front of the word __construct.<br /><br />It is __construct<br />Not _construct<br /><br />Extremely obvious once you figure it out, but it can be sooo frustrating until you do.<br /><br />I spent quite a bit of needless time debugging working code.<br /><br />I even thought about it a few times, thinking it looked a little long in the examples, but at the time that just seemed silly(always thinking "oh somebody would have made that clear if it weren't just a regular underscore...")<br /><br />All the manuals I looked at, all the tuturials I read, all the examples I browsed through&nbsp; - not once did anybody mention this!&nbsp; <br /><br />(please don't tell me it's explained somewhere on this page and I just missed it,&nbsp; you'll only add to my pain.)<br /><br />I hope this helps somebody else!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="102882">  <div class="votes">
    <div id="Vu102882">
    <a href="/manual/vote-note.php?id=102882&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd102882">
    <a href="/manual/vote-note.php?id=102882&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V102882" title="54% like this...">
    3
    </div>
  </div>
  <a href="#102882" class="name">
  <strong class="user"><em>phenixdoc at gmail dot com</em></strong></a><a class="genanchor" href="#102882"> &para;</a><div class="date" title="2011-03-11 04:26"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom102882">
<div class="phpcode"><code><span class="html">
multiple constructors with type signetures (almost overloading):<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">public function </span><span class="default">__construct</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$args </span><span class="keyword">= </span><span class="default">func_get_args</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$argsStr </span><span class="keyword">= </span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach (</span><span class="default">$args </span><span class="keyword">as </span><span class="default">$arg</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$argsStr </span><span class="keyword">.= </span><span class="string">'_' </span><span class="keyword">. </span><span class="default">gettype</span><span class="keyword">(</span><span class="default">$arg</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">method_exists</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">, </span><span class="default">$constructor </span><span class="keyword">= </span><span class="string">'__construct' </span><span class="keyword">. </span><span class="default">$argsStr</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">call_user_func_array</span><span class="keyword">(array(</span><span class="default">$this</span><span class="keyword">, </span><span class="default">$constructor</span><span class="keyword">), </span><span class="default">$args</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">Exception</span><span class="keyword">(</span><span class="string">'NO CONSTRUCTOR: ' </span><span class="keyword">. </span><span class="default">get_class</span><span class="keyword">() . </span><span class="default">$constructor</span><span class="keyword">, </span><span class="default">NULL</span><span class="keyword">, </span><span class="default">NULL</span><span class="keyword">);<br />&nbsp; &nbsp; }<br /><br />public function </span><span class="default">__construct_integer</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">) {}<br />public function </span><span class="default">__construct_string</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">) {}<br />public function </span><span class="default">__construct_integer_string</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">) {}<br />public function </span><span class="default">__construct_string_integer</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">) {}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117693">  <div class="votes">
    <div id="Vu117693">
    <a href="/manual/vote-note.php?id=117693&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117693">
    <a href="/manual/vote-note.php?id=117693&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117693" title="53% like this...">
    1
    </div>
  </div>
  <a href="#117693" class="name">
  <strong class="user"><em>cottton</em></strong></a><a class="genanchor" href="#117693"> &para;</a><div class="date" title="2015-07-23 07:06"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117693">
<div class="phpcode"><code><span class="html">
[quote]<br />Note:<br />Attempting to throw an exception from a destructor (called in the time of script termination) causes a fatal error.<br />[/quote]<br />Not true.<br /><br />Usually you wont be able to catch an Exception thrown out of a ::__destruct().<br />BUT following case shows that it IS possible to catch a thrown Exception from the ::__destruct()<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Something<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">__METHOD__ </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public function </span><span class="default">__destruct</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">__METHOD__ </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">Exception</span><span class="keyword">(</span><span class="string">"Exception thrown out of ::__destruct()"</span><span class="keyword">, </span><span class="default">1</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br />try{<br />&nbsp; &nbsp; </span><span class="default">$Something </span><span class="keyword">= new </span><span class="default">Something</span><span class="keyword">();<br />&nbsp; &nbsp; </span><span class="default">$Something </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">; </span><span class="comment">// will cause to call the objects ::__destruct()<br />&nbsp; &nbsp; // also possible: unset($Something);<br /></span><span class="keyword">}catch(</span><span class="default">Exception $e</span><span class="keyword">){<br />&nbsp; &nbsp; echo </span><span class="string">'Exception: ' </span><span class="keyword">. </span><span class="default">$e</span><span class="keyword">-&gt;</span><span class="default">getMessage</span><span class="keyword">() . </span><span class="default">PHP_EOL</span><span class="keyword">;<br />}<br />echo </span><span class="string">'End of script -- no Fatal Error.'</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span>IMO this is not a bug. It is ok to be able to throw and catch Exception.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114963">  <div class="votes">
    <div id="Vu114963">
    <a href="/manual/vote-note.php?id=114963&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114963">
    <a href="/manual/vote-note.php?id=114963&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114963" title="53% like this...">
    1
    </div>
  </div>
  <a href="#114963" class="name">
  <strong class="user"><em>kayvin86 at live dot com</em></strong></a><a class="genanchor" href="#114963"> &para;</a><div class="date" title="2014-05-06 05:16"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114963">
<div class="phpcode"><code><span class="html">
putting in more layman's term<br /><br />class dad{<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function __construct() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo get_class($this) . ' is fair and tall &lt;br&gt;';<br />&nbsp; &nbsp; }<br />}<br /><br />//inherit and overidding parent constructor<br />class son extends dad{<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function __construct(){<br />&nbsp; &nbsp; &nbsp; &nbsp; parent::__construct();<br />&nbsp; &nbsp; &nbsp; &nbsp; echo get_class($this) . ' is handsome &lt;br&gt;';<br />&nbsp; &nbsp; }<br />}<br /><br />//overidding parent constructor<br />class daughter extends dad{<br />&nbsp; &nbsp; function __construct(){<br />&nbsp; &nbsp; &nbsp; &nbsp; echo get_class($this) . ' is tan like her mother &lt;br&gt;';<br />&nbsp; &nbsp; &nbsp; &nbsp; echo get_class($this) . ' is pretty and has nothing to do with dad &lt;br&gt;';<br />&nbsp; &nbsp; }<br />}<br /><br />echo 'im dad: &lt;br&gt;';<br />$dad = new dad();<br /><br />echo '&lt;br&gt;';<br /><br />echo 'born a son: &lt;br&gt;';<br />$son = new son();<br /><br />echo '&lt;br&gt;';<br /><br />echo 'born a daughter: &lt;br&gt;';<br />$daughter = new daughter();<br /><br />/*output<br />im dad:<br />dad is fair and tall<br /><br />born a son:<br />son is fair and tall (notice that when parent:: is call inside son, son will be the class inside dad's contructor)<br />son is handsome<br /><br />born a daughter:<br />daughter is tan like her mother<br />daughter is pretty and has nothing to do with dad<br /> */</span>
</code></div>
  </div>
 </div>
  <div class="note" id="76235">  <div class="votes">
    <div id="Vu76235">
    <a href="/manual/vote-note.php?id=76235&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd76235">
    <a href="/manual/vote-note.php?id=76235&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V76235" title="54% like this...">
    2
    </div>
  </div>
  <a href="#76235" class="name">
  <strong class="user"><em>soapthgr8 at gmail dot com</em></strong></a><a class="genanchor" href="#76235"> &para;</a><div class="date" title="2007-07-06 07:46"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom76235">
<div class="phpcode"><code><span class="html">
This is just to clarify that the Singleton pattern is a bit more complex than just making the constructor private. It also involves caching an instance of the object and always returning the cached value. So, in the previous example, the getNewInstance() function would undermine the intent of the Singleton pattern. Instead you would just need a getInstance() function, like so.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">A </span><span class="keyword">{<br />&nbsp; </span><span class="comment">// cached instance<br />&nbsp; </span><span class="keyword">private static </span><span class="default">oInst </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br /><br />&nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp; * Prevent an object from being constructed.<br />&nbsp; &nbsp; */<br />&nbsp; </span><span class="keyword">private function </span><span class="default">__construct</span><span class="keyword">( ) {}<br />&nbsp; </span><span class="comment">/**<br />&nbsp;&nbsp; * Function to return the instance of this class.<br />&nbsp;&nbsp; */<br />&nbsp; </span><span class="keyword">public static function </span><span class="default">getInstance</span><span class="keyword">( ) {<br />&nbsp; &nbsp; if (</span><span class="default">is_null</span><span class="keyword">(</span><span class="default">self</span><span class="keyword">::</span><span class="default">$oInst</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">$oInst </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">( );<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; return </span><span class="default">self</span><span class="keyword">::</span><span class="default">$oInst</span><span class="keyword">;<br />&nbsp; }<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="99007">  <div class="votes">
    <div id="Vu99007">
    <a href="/manual/vote-note.php?id=99007&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd99007">
    <a href="/manual/vote-note.php?id=99007&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V99007" title="53% like this...">
    1
    </div>
  </div>
  <a href="#99007" class="name">
  <strong class="user"><em>maramirezc WHERE star-dev DOTTED com</em></strong></a><a class="genanchor" href="#99007"> &para;</a><div class="date" title="2010-07-21 02:14"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom99007">
<div class="phpcode"><code><span class="html">
Another way to emulate multiple constructors:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">MyClass </span><span class="keyword">{<br /><br />&nbsp;&nbsp; </span><span class="comment">// use a unique id for each derived constructor,<br />&nbsp;&nbsp; // and use a null reference to an array, <br />&nbsp;&nbsp; // for optional parameters<br />&nbsp;&nbsp; </span><span class="keyword">function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$id</span><span class="keyword">=</span><span class="string">""</span><span class="keyword">, </span><span class="default">$args</span><span class="keyword">=</span><span class="default">null</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="comment">// parent constructor called first ALWAYS<br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">parent</span><span class="keyword">::</span><span class="default">__construct</span><span class="keyword">();<br /><br />&nbsp; &nbsp; &nbsp;&nbsp; echo </span><span class="string">"main constructor\n"</span><span class="keyword">;<br /><br />&nbsp; &nbsp; &nbsp; </span><span class="comment">// avoid null or other types<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$id </span><span class="keyword">= (string) </span><span class="default">$id</span><span class="keyword">;<br /><br />&nbsp; &nbsp; &nbsp; </span><span class="comment">// allow default constructor<br />&nbsp; &nbsp; &nbsp; </span><span class="keyword">if (</span><span class="default">$id </span><span class="keyword">== </span><span class="string">""</span><span class="keyword">) {&nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$id </span><span class="keyword">= </span><span class="string">"default"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; </span><span class="comment">// just in case, use lowercase id<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$id </span><span class="keyword">= </span><span class="string">"__cons_" </span><span class="keyword">.&nbsp; </span><span class="default">strtolower</span><span class="keyword">(</span><span class="default">$id</span><span class="keyword">);<br /><br />&nbsp; &nbsp; &nbsp; </span><span class="default">$rc </span><span class="keyword">= new </span><span class="default">ReflectionClass</span><span class="keyword">(</span><span class="string">"MyClass"</span><span class="keyword">);<br /><br />&nbsp; &nbsp; &nbsp; if (!</span><span class="default">$rc</span><span class="keyword">-&gt;</span><span class="default">hasMethod</span><span class="keyword">(</span><span class="default">$id</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; echo </span><span class="string">"constructor </span><span class="default">$id</span><span class="string"> not defined\n"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; else { <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// using "method references"<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$id</span><span class="keyword">(</span><span class="default">$args</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$rc </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br />&nbsp;&nbsp; } </span><span class="comment">// function __construct<br /><br />&nbsp;&nbsp; // ALWAYS HAVE A default constructor,<br />&nbsp;&nbsp; // that ignores arguments<br />&nbsp;&nbsp; </span><span class="keyword">function </span><span class="default">__cons_default</span><span class="keyword">(</span><span class="default">$args</span><span class="keyword">=</span><span class="default">null</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp;&nbsp; echo </span><span class="string">"Default constructor\n"</span><span class="keyword">;<br />&nbsp;&nbsp; }<br /><br />&nbsp;&nbsp; </span><span class="comment">// may have other constructors that expect different<br />&nbsp;&nbsp; // argument types or argument count<br />&nbsp;&nbsp; </span><span class="keyword">function </span><span class="default">__cons_min</span><span class="keyword">(</span><span class="default">$args</span><span class="keyword">=</span><span class="default">null</span><span class="keyword">) {<br />&nbsp; &nbsp;&nbsp; if (! </span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$args</span><span class="keyword">) || </span><span class="default">count</span><span class="keyword">(</span><span class="default">$args</span><span class="keyword">) != </span><span class="default">2</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp;&nbsp; echo </span><span class="string">"Error: Not enough parameters (Constructor min(int </span><span class="default">$a</span><span class="string">, int </span><span class="default">$b</span><span class="string">)) !!!\n"</span><span class="keyword">;<br />&nbsp; &nbsp;&nbsp; }<br />&nbsp; &nbsp;&nbsp; else {<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$a </span><span class="keyword">= (int) </span><span class="default">$args</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$b </span><span class="keyword">= (int) </span><span class="default">$args</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$c </span><span class="keyword">= </span><span class="default">min</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">,</span><span class="default">$b</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; echo </span><span class="string">"Constructor min(): Result = </span><span class="default">$c</span><span class="string">\n"</span><span class="keyword">;<br />&nbsp; &nbsp;&nbsp; }<br />&nbsp;&nbsp; }<br /><br />&nbsp;&nbsp; </span><span class="comment">// may use string index (associative array),<br />&nbsp;&nbsp; // instead of integer index (standard array) <br />&nbsp;&nbsp; </span><span class="keyword">function </span><span class="default">__cons_fullname</span><span class="keyword">(</span><span class="default">$args</span><span class="keyword">=</span><span class="default">null</span><span class="keyword">) {<br />&nbsp; &nbsp;&nbsp; if (! </span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$args</span><span class="keyword">) || </span><span class="default">count</span><span class="keyword">(</span><span class="default">$args</span><span class="keyword">) &lt; </span><span class="default">2</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp;&nbsp; echo </span><span class="string">"Error: Not enough parameters (Constructor fullname(string </span><span class="default">$firstname</span><span class="string">, string </span><span class="default">$lastname</span><span class="string">)) !!!\n"</span><span class="keyword">;<br />&nbsp; &nbsp;&nbsp; }<br />&nbsp; &nbsp;&nbsp; else {<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$a </span><span class="keyword">= (string) </span><span class="default">$args</span><span class="keyword">[</span><span class="string">"firstname"</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$b </span><span class="keyword">= (string) </span><span class="default">$args</span><span class="keyword">[</span><span class="string">"lastname"</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$c </span><span class="keyword">= </span><span class="default">$a </span><span class="keyword">. </span><span class="string">" " </span><span class="keyword">. </span><span class="default">$b</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; echo </span><span class="string">"Constructor fullname(): Result = </span><span class="default">$c</span><span class="string">\n"</span><span class="keyword">;<br />&nbsp; &nbsp;&nbsp; }<br />&nbsp;&nbsp; }<br /><br />} </span><span class="comment">// class<br /><br />// --&gt; these two lines are the equivalent<br /></span><span class="default">$obj1 </span><span class="keyword">= new </span><span class="default">TestClass</span><span class="keyword">();<br /></span><span class="default">$obj2 </span><span class="keyword">= new </span><span class="default">TestClass</span><span class="keyword">(</span><span class="string">"default"</span><span class="keyword">);<br /><br /></span><span class="comment">// --&gt; these two are specialized<br /><br />// should be read as "$obj3 = new TestClass, min(99.7, 99.83);"<br /></span><span class="default">$obj3 </span><span class="keyword">= new </span><span class="default">TestClass</span><span class="keyword">(</span><span class="string">"min"</span><span class="keyword">, array(</span><span class="default">99.7</span><span class="keyword">, </span><span class="default">99.83</span><span class="keyword">));<br /><br /></span><span class="comment">// should be read as "$obj4 = new TestClass, fullname("John", "Doe");"<br /></span><span class="default">$obj4 </span><span class="keyword">= new </span><span class="default">TestClass</span><span class="keyword">(</span><span class="string">"fullname"</span><span class="keyword">, array(</span><span class="string">"firstname" </span><span class="keyword">=&gt; </span><span class="string">"John"</span><span class="keyword">, </span><span class="string">"lastname" </span><span class="keyword">=&gt; </span><span class="string">"Doe"</span><span class="keyword">));<br /><br /></span><span class="comment">// --&gt; these&nbsp; two lack parameters<br /></span><span class="default">$obj5 </span><span class="keyword">= new </span><span class="default">TestClass</span><span class="keyword">(</span><span class="string">"min"</span><span class="keyword">, array());<br /></span><span class="default">$obj6 </span><span class="keyword">= new </span><span class="default">TestClass</span><span class="keyword">(</span><span class="string">"fullname"</span><span class="keyword">);<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="76446">  <div class="votes">
    <div id="Vu76446">
    <a href="/manual/vote-note.php?id=76446&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd76446">
    <a href="/manual/vote-note.php?id=76446&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V76446" title="54% like this...">
    2
    </div>
  </div>
  <a href="#76446" class="name">
  <strong class="user"><em>fredrik at rambris dot com</em></strong></a><a class="genanchor" href="#76446"> &para;</a><div class="date" title="2007-07-16 06:59"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom76446">
<div class="phpcode"><code><span class="html">
The fact that class names are case-insensitive in PHP5 also applies to constructors. Make sure you don't have any functions named like the class *at all*.<br /><br />This has bitten me a few times.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Example </span><span class="keyword">extends </span><span class="default">Base<br /></span><span class="keyword">{<br />&nbsp; function </span><span class="default">example</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; echo </span><span class="string">"This gets called"</span><span class="keyword">;<br />&nbsp; }<br />}<br /><br />class </span><span class="default">Base<br /></span><span class="keyword">{<br />&nbsp; function </span><span class="default">__construct</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; echo </span><span class="string">"Not this"</span><span class="keyword">;<br />&nbsp; }<br />}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113052">  <div class="votes">
    <div id="Vu113052">
    <a href="/manual/vote-note.php?id=113052&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113052">
    <a href="/manual/vote-note.php?id=113052&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113052" title="51% like this...">
    1
    </div>
  </div>
  <a href="#113052" class="name">
  <strong class="user"><em>Yousef Ismaeil cliprz[At]gmail[Dot]com</em></strong></a><a class="genanchor" href="#113052"> &para;</a><div class="date" title="2013-08-22 09:06"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113052">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br /><br /></span><span class="comment">/**<br /> * a funny example Mobile class<br /> * <br /> * @author Yousef Ismaeil Cliprz[At]gmail[Dot]com<br /> */<br /><br /></span><span class="keyword">class </span><span class="default">Mobile </span><span class="keyword">{<br /><br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Some device properties<br />&nbsp; &nbsp;&nbsp; * <br />&nbsp; &nbsp;&nbsp; * @var string<br />&nbsp; &nbsp;&nbsp; * @access public<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">public </span><span class="default">$deviceName</span><span class="keyword">,</span><span class="default">$deviceVersion</span><span class="keyword">,</span><span class="default">$deviceColor</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Set some values for Mobile::properties<br />&nbsp; &nbsp;&nbsp; * <br />&nbsp; &nbsp;&nbsp; * @param string device name<br />&nbsp; &nbsp;&nbsp; * @param string device version<br />&nbsp; &nbsp;&nbsp; * @param string device color<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">__construct </span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">,</span><span class="default">$version</span><span class="keyword">,</span><span class="default">$color</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">deviceName </span><span class="keyword">= </span><span class="default">$name</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">deviceVersion </span><span class="keyword">= </span><span class="default">$version</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">deviceColor </span><span class="keyword">= </span><span class="default">$color</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"The "</span><span class="keyword">.</span><span class="default">__CLASS__</span><span class="keyword">.</span><span class="string">" class is stratup.&lt;br /&gt;&lt;br /&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Some Output<br />&nbsp; &nbsp;&nbsp; * <br />&nbsp; &nbsp;&nbsp; * @access public<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">printOut </span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'I have a '</span><span class="keyword">.</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">deviceName<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">.</span><span class="string">' version '</span><span class="keyword">.</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">deviceVersion<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">.</span><span class="string">' my device color is : '</span><span class="keyword">.</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">deviceColor</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Umm only for example we will remove Mobile::$deviceName Hum not unset only to check how __destruct working <br />&nbsp; &nbsp;&nbsp; * <br />&nbsp; &nbsp;&nbsp; * @access public<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">__destruct </span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">deviceName </span><span class="keyword">= </span><span class="string">'Removed'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'&lt;br /&gt;&lt;br /&gt;Dumpping Mobile::deviceName to make sure its removed, Olay :'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">deviceName</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"&lt;br /&gt;The "</span><span class="keyword">.</span><span class="default">__CLASS__</span><span class="keyword">.</span><span class="string">" class is shutdown."</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />}<br /><br /></span><span class="comment">// Oh ya instance<br /></span><span class="default">$mob </span><span class="keyword">= new </span><span class="default">Mobile</span><span class="keyword">(</span><span class="string">'iPhone'</span><span class="keyword">,</span><span class="string">'5'</span><span class="keyword">,</span><span class="string">'Black'</span><span class="keyword">);<br /><br /></span><span class="comment">// print output<br /></span><span class="default">$mob</span><span class="keyword">-&gt;</span><span class="default">printOut</span><span class="keyword">();<br /><br /></span><span class="default">?&gt;<br /></span><br />The Mobile class is stratup.<br /><br />I have a iPhone version 5 my device color is : Black<br /><br />Dumpping Mobile::deviceName to make sure its removed, Olay :<br />string 'Removed' (length=7)<br /><br />The Mobile class is shutdown.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="88575">  <div class="votes">
    <div id="Vu88575">
    <a href="/manual/vote-note.php?id=88575&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd88575">
    <a href="/manual/vote-note.php?id=88575&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V88575" title="52% like this...">
    1
    </div>
  </div>
  <a href="#88575" class="name">
  <strong class="user"><em>bac2day1 at gmail dot com</em></strong></a><a class="genanchor" href="#88575"> &para;</a><div class="date" title="2009-01-29 10:26"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom88575">
<div class="phpcode"><code><span class="html">
You can also capitalize on singleton for the connection as well.<br />Just add the following to your class:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">db </span><span class="keyword">{ <br />&nbsp; </span><span class="comment">//...<br />&nbsp; </span><span class="keyword">private static </span><span class="default">$instance</span><span class="keyword">;<br />&nbsp; </span><span class="comment">//...<br />&nbsp; </span><span class="keyword">public static function </span><span class="default">singleton</span><span class="keyword">() {<br />&nbsp; &nbsp; if(!isset(</span><span class="default">self</span><span class="keyword">::</span><span class="default">$instance</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$c </span><span class="keyword">= </span><span class="default">__CLASS__</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">$instance </span><span class="keyword">= new </span><span class="default">$c</span><span class="keyword">();<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; return </span><span class="default">self</span><span class="keyword">::</span><span class="default">$instance</span><span class="keyword">;<br />&nbsp; }<br />&nbsp; </span><span class="comment">//...<br /></span><span class="keyword">}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121835">  <div class="votes">
    <div id="Vu121835">
    <a href="/manual/vote-note.php?id=121835&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121835">
    <a href="/manual/vote-note.php?id=121835&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121835" title="no votes...">
    0
    </div>
  </div>
  <a href="#121835" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#121835"> &para;</a><div class="date" title="2017-11-07 12:48"><strong>1 month ago</strong></div>
  <div class="text" id="Hcom121835">
<div class="phpcode"><code><span class="html">
for multiple constructor like, you can use the constructor this way<br /><br />class Foo<br />{<br />&nbsp; &nbsp; public function __construct(...$args)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (count($args) == 1) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo 'One parameter';<br />&nbsp; &nbsp; &nbsp; &nbsp; } else if (count($args == 2)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo 'Two parameter';<br />&nbsp; &nbsp; &nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo 'More than one parameter';<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />}<br /><br />new Foo('hello', 'world');</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121165">  <div class="votes">
    <div id="Vu121165">
    <a href="/manual/vote-note.php?id=121165&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121165">
    <a href="/manual/vote-note.php?id=121165&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121165" title="no votes...">
    0
    </div>
  </div>
  <a href="#121165" class="name">
  <strong class="user"><em>bobo at yahoo dot com</em></strong></a><a class="genanchor" href="#121165"> &para;</a><div class="date" title="2017-05-31 11:48"><strong>6 months ago</strong></div>
  <div class="text" id="Hcom121165">
<div class="phpcode"><code><span class="html">
This two documents shows how OOP can work with using a constructor.<br /> <br />[Document user.php]<br /><span class="default">&lt;?php<br /></span><span class="comment">//Attribute<br /></span><span class="keyword">class </span><span class="default">user</span><span class="keyword">{<br />&nbsp; private </span><span class="default">$name</span><span class="keyword">;&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//$n<br />&nbsp; </span><span class="keyword">private </span><span class="default">$forename</span><span class="keyword">;&nbsp; &nbsp; </span><span class="comment">//$fn<br />&nbsp; </span><span class="keyword">private </span><span class="default">$birthday</span><span class="keyword">;&nbsp; &nbsp; </span><span class="comment">//$bd<br />&nbsp; </span><span class="keyword">private </span><span class="default">$username</span><span class="keyword">;<br />&nbsp; <br />&nbsp; </span><span class="comment">//constructor<br />&nbsp; </span><span class="keyword">public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$n</span><span class="keyword">,</span><span class="default">$fn</span><span class="keyword">,</span><span class="default">$bd</span><span class="keyword">)<br />&nbsp; {<br />&nbsp; &nbsp; if(</span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$n</span><span class="keyword">)&gt;=</span><span class="default">3 </span><span class="keyword">&amp;&amp; </span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$fn</span><span class="keyword">)&gt;=</span><span class="default">2</span><span class="keyword">)&nbsp; &nbsp; </span><span class="comment">//min 3 chars for name and 2 chars for the forename<br />&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">name</span><span class="keyword">=</span><span class="default">$n</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">forename</span><span class="keyword">=</span><span class="default">$fn</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">birthday</span><span class="keyword">=</span><span class="default">$bd</span><span class="keyword">;<br />&nbsp; }<br />&nbsp; </span><span class="comment">//Getter-Methode<br />&nbsp; </span><span class="keyword">public function </span><span class="default">getName</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; if(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">name</span><span class="keyword">!=</span><span class="string">""</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">name</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; else<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; return </span><span class="string">"&lt;strong style='color:red'&gt; Name required.&lt;/strong&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; }<br />&nbsp; public function </span><span class="default">getForename</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; if(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">forename</span><span class="keyword">!=</span><span class="string">""</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">forename</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; else<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; return </span><span class="string">"&lt;strong style='color:red'&gt;Forename required.&lt;/strong&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; }<br /><br />&nbsp; public function </span><span class="default">getBirthday</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; if(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">birthday</span><span class="keyword">!=</span><span class="string">""</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">birthday</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; else<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; return </span><span class="string">"&lt;strong style='color:red'&gt;Birthday required.&lt;/strong&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; }<br /><br />&nbsp; public function </span><span class="default">getUsername</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; if(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">username</span><span class="keyword">!=</span><span class="string">""</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">username</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; elseif(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">name</span><span class="keyword">!=</span><span class="string">""</span><span class="keyword">&amp;&amp;</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">forename</span><span class="keyword">!=</span><span class="string">""</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">createUN</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">username</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; else<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; return</span><span class="string">"&lt;strong style='color:red'&gt;Username can not created. &lt;/strong&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; }<br />&nbsp; <br />&nbsp; </span><span class="comment">//Creating the Username with name and forename.<br />&nbsp; </span><span class="keyword">public function </span><span class="default">createUN</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; </span><span class="default">$username</span><span class="keyword">=</span><span class="string">""</span><span class="keyword">;<br />&nbsp; &nbsp; for(</span><span class="default">$i</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">;</span><span class="default">$i</span><span class="keyword">&lt;=</span><span class="default">3</span><span class="keyword">;</span><span class="default">$i</span><span class="keyword">++)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$username</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">]= </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">name</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">];<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; for(</span><span class="default">$i</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">;</span><span class="default">$i</span><span class="keyword">&lt;=</span><span class="default">1</span><span class="keyword">;</span><span class="default">$i</span><span class="keyword">++)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$username</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">+</span><span class="default">2</span><span class="keyword">]= </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">forename</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">];<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; </span><span class="default">$username</span><span class="keyword">=</span><span class="default">implode</span><span class="keyword">(</span><span class="string">""</span><span class="keyword">,</span><span class="default">$username</span><span class="keyword">); </span><span class="comment">//changes array to string<br />&nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">$username</span><span class="keyword">;<br /><br />&nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />//-------------------------------------------------------------------------------<br />[Document user_test.php]<br /><span class="default">&lt;?php<br /></span><span class="keyword">include(</span><span class="string">"user.php"</span><span class="keyword">);<br /></span><span class="default">$user1</span><span class="keyword">= new </span><span class="default">user</span><span class="keyword">(</span><span class="string">"Musterman"</span><span class="keyword">,</span><span class="string">"Max"</span><span class="keyword">,</span><span class="string">"31.01.1998"</span><span class="keyword">);&nbsp; </span><span class="comment">//Object with contructor<br /></span><span class="keyword">echo </span><span class="default">$user1</span><span class="keyword">-&gt;</span><span class="default">getForename</span><span class="keyword">();<br />echo </span><span class="default">$user1</span><span class="keyword">-&gt;</span><span class="default">getName</span><span class="keyword">();<br />echo </span><span class="default">$user1</span><span class="keyword">-&gt;</span><span class="default">getBirthday</span><span class="keyword">();<br />echo </span><span class="default">$user1</span><span class="keyword">-&gt;</span><span class="default">createUN</span><span class="keyword">();<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113380">  <div class="votes">
    <div id="Vu113380">
    <a href="/manual/vote-note.php?id=113380&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113380">
    <a href="/manual/vote-note.php?id=113380&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113380" title="50% like this...">
    0
    </div>
  </div>
  <a href="#113380" class="name">
  <strong class="user"><em>kitchin</em></strong></a><a class="genanchor" href="#113380"> &para;</a><div class="date" title="2013-10-03 10:36"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113380">
<div class="phpcode"><code><span class="html">
If your code has a redundant constructor for PHP 4 compatibility, an E_STRICT error may be raised in PHP 5.x:<br /><br />Strict Standards:&nbsp; Redefining already defined constructor for class...<br /><br />What is a redundant constructor for PHP 4 compatibility? It looks like<br /><span class="default">&lt;?php<br /></span><span class="keyword">Class </span><span class="default">Foo </span><span class="keyword">{<br />&nbsp; function </span><span class="default">Foo</span><span class="keyword">() {<br />&nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">__construct</span><span class="keyword">();<br />&nbsp; }<br />&nbsp; function </span><span class="default">__construct</span><span class="keyword">() {<br />&nbsp; &nbsp; </span><span class="comment">// whatever<br />&nbsp; </span><span class="keyword">}<br /></span><span class="default">?&gt;<br /></span><br />If you don't need PHP 4, just delete the Foo function. Or you reverse the order of Foo and __construct, the error goes away, so that's probably OK for a single class. Also there was a suggestion to do this in Foo:<br /><span class="default">&lt;?php<br />&nbsp; </span><span class="keyword">function </span><span class="default">Foo</span><span class="keyword">() {<br />&nbsp; &nbsp; if (</span><span class="default">version_compare</span><span class="keyword">(</span><span class="default">PHP_VERSION</span><span class="keyword">,</span><span class="string">"5.0.0"</span><span class="keyword">,</span><span class="string">"&lt;"</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">__construct</span><span class="keyword">();<br />&nbsp; &nbsp; }<br />&nbsp; }<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="103383">  <div class="votes">
    <div id="Vu103383">
    <a href="/manual/vote-note.php?id=103383&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd103383">
    <a href="/manual/vote-note.php?id=103383&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V103383" title="50% like this...">
    0
    </div>
  </div>
  <a href="#103383" class="name">
  <strong class="user"><em>boukeversteeg at gmail dot com</em></strong></a><a class="genanchor" href="#103383"> &para;</a><div class="date" title="2011-04-11 07:12"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom103383">
<div class="phpcode"><code><span class="html">
Php 5.3.3 had a very strange bug, related to __destruct, but this bug was fixed in 5.3.6. This bug happened to me and it took me forever to figure it out, so I wanted to share it.<br /><br />In short, don't unset properties in __destruct():<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Foobar </span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$baz</span><span class="keyword">;<br />&nbsp; &nbsp; function </span><span class="default">__destruct</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment"># Don't do either of these, if $baz also has a __destruct()!<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">baz </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; unset(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">baz</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment"># Instead, don't clear it at all, or do this:<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">baz</span><span class="keyword">-&gt;</span><span class="default">__destruct</span><span class="keyword">();<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />If you made this mistake, this might happen in php&lt;5.3.6:<br /><span class="default">&lt;?php<br /></span><span class="comment"># Some function that throws an exception<br /></span><span class="keyword">function </span><span class="default">fail</span><span class="keyword">(</span><span class="default">$foobar</span><span class="keyword">) {<br />&nbsp; &nbsp; throw new </span><span class="default">Exception</span><span class="keyword">(</span><span class="string">"Exception A!"</span><span class="keyword">);<br />}<br /><br /></span><span class="default">$foobar </span><span class="keyword">= new </span><span class="default">Foobar</span><span class="keyword">();<br /></span><span class="default">$foobar</span><span class="keyword">-&gt;</span><span class="default">baz </span><span class="keyword">= new </span><span class="default">Foobar</span><span class="keyword">();<br /><br />try {<br />&nbsp; &nbsp; </span><span class="default">fail</span><span class="keyword">(</span><span class="default">$foobar</span><span class="keyword">); </span><span class="comment">// Send foobar to func that throws an Exception<br /></span><span class="keyword">} catch( </span><span class="default">Exception $e </span><span class="keyword">) {<br />&nbsp; &nbsp; print </span><span class="default">$e</span><span class="keyword">-&gt;</span><span class="default">getMessage</span><span class="keyword">(); </span><span class="comment">// Exception A will be caught and printed, as expected.<br /></span><span class="keyword">}<br /><br /></span><span class="default">$foobar </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">; </span><span class="comment">// clearing foobar, and its property $baz<br /><br /></span><span class="keyword">try {<br />&nbsp; &nbsp; print </span><span class="string">'Exception B:'</span><span class="keyword">;</span><span class="comment">// this will be printed<br />&nbsp; &nbsp; // output stops here.<br />&nbsp; &nbsp; </span><span class="keyword">throw new </span><span class="default">Exception</span><span class="keyword">(</span><span class="string">"Exception B!"</span><span class="keyword">);<br />} catch( </span><span class="default">Exception $e </span><span class="keyword">) {<br />&nbsp; &nbsp; print </span><span class="default">$e</span><span class="keyword">-&gt;</span><span class="default">getMessage</span><span class="keyword">(); </span><span class="comment">// doesn't happen<br /></span><span class="keyword">}<br />print </span><span class="string">'End'</span><span class="keyword">; </span><span class="comment">// this won't be printed<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="98514">  <div class="votes">
    <div id="Vu98514">
    <a href="/manual/vote-note.php?id=98514&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd98514">
    <a href="/manual/vote-note.php?id=98514&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V98514" title="50% like this...">
    0
    </div>
  </div>
  <a href="#98514" class="name">
  <strong class="user"><em>alon dot peer at gmail dot com</em></strong></a><a class="genanchor" href="#98514"> &para;</a><div class="date" title="2010-06-20 02:39"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom98514">
<div class="phpcode"><code><span class="html">
Another way to overcome PHP's lack of multi constructors support is to check for the constructor's parameters' type and variate the operation accordingly. This works well when the number of parameters stays the same in all your constructors' needs.<br /><br />Example:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">Articles </span><span class="keyword">{<br /><br />&nbsp; &nbsp; private </span><span class="default">$_articles_array</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$input</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$input</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Initialize articles array with input.<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">}<br />&nbsp; &nbsp; &nbsp; &nbsp; else if (</span><span class="default">$input </span><span class="keyword">instanceof </span><span class="default">SimpleXMLElement</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Initialize articles array by parsing the XML.<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">}<br />&nbsp; &nbsp; &nbsp; &nbsp; else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">Exception</span><span class="keyword">(</span><span class="string">'Wrong input type'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br />}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="94003">  <div class="votes">
    <div id="Vu94003">
    <a href="/manual/vote-note.php?id=94003&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd94003">
    <a href="/manual/vote-note.php?id=94003&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V94003" title="50% like this...">
    0
    </div>
  </div>
  <a href="#94003" class="name">
  <strong class="user"><em>ruggie0 at yahoo dot com</em></strong></a><a class="genanchor" href="#94003"> &para;</a><div class="date" title="2009-10-11 04:13"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom94003">
<div class="phpcode"><code><span class="html">
For those who still ***have*** to deal with php4 (like myself, which sucks), contact at tcknetwork dot com noted below that you can have both __constructor and function [classname] in the script, as __constructor has priority.<br /><br />However, to further improve compatability, do a version check in function [classname], as I do in my classes as follows:<br /><span class="default">&lt;?php<br />&nbsp;&nbsp; </span><span class="keyword">class </span><span class="default">Foo</span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$arg</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; echo </span><span class="default">$arg</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; function </span><span class="default">Foo</span><span class="keyword">(</span><span class="default">$arg</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; if(</span><span class="default">version_compare</span><span class="keyword">(</span><span class="default">PHP_VERSION</span><span class="keyword">,</span><span class="string">"5.0.0"</span><span class="keyword">,</span><span class="string">"&lt;"</span><span class="keyword">)){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$arg</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">register_shutdown_function</span><span class="keyword">(array(</span><span class="default">$this</span><span class="keyword">,</span><span class="string">"__destruct"</span><span class="keyword">));&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; }<br />&nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; function </span><span class="default">__destruct</span><span class="keyword">(){<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; echo </span><span class="string">"Ack! I'm being destroyed!"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; }<br />&nbsp;&nbsp; }<br /></span><span class="default">?&gt;</span> <br /><br />This makes it much easier to use your script with fewer compatibility issues.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="82577">  <div class="votes">
    <div id="Vu82577">
    <a href="/manual/vote-note.php?id=82577&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd82577">
    <a href="/manual/vote-note.php?id=82577&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V82577" title="50% like this...">
    0
    </div>
  </div>
  <a href="#82577" class="name">
  <strong class="user"><em>bolshun at mail dot ru</em></strong></a><a class="genanchor" href="#82577"> &para;</a><div class="date" title="2008-04-16 06:13"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom82577">
<div class="phpcode"><code><span class="html">
Ensuring that instance of some class will be available in destructor of some other class is easy: just keep a reference to that instance in this other class.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="74511">  <div class="votes">
    <div id="Vu74511">
    <a href="/manual/vote-note.php?id=74511&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd74511">
    <a href="/manual/vote-note.php?id=74511&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V74511" title="50% like this...">
    0
    </div>
  </div>
  <a href="#74511" class="name">
  <strong class="user"><em>frederic dot barboteu at laposte dot net</em></strong></a><a class="genanchor" href="#74511"> &para;</a><div class="date" title="2007-04-14 07:11"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom74511">
<div class="phpcode"><code><span class="html">
The manual says:<br />"Like constructors, parent destructors will not be called implicitly by the engine."<br /><br />This is true ONLY when a __destruct() function has been defined by the child class.<br />If no __destruct() function exists in the child class, the parent's one will be implicitly executed.<br /><br />So be carefull if you have some ancestor executing a particular task in its __destruct() function, an you plan its childs to execute it or not, wether you include "parent::__destruct()" or not.<br />If you want the child not to execute its parent __destruct() function, you must ensure that it has its own __destruct() function, even if empty. Then the parent's one will not be executed.<br /><br />This can be verified with the following code:<br /><span class="default">&lt;?php<br /></span><span class="comment">#<br /></span><span class="keyword">class </span><span class="default">AncestorClass </span><span class="keyword">{<br />&nbsp; &nbsp; function </span><span class="default">__destruct</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'&lt;br /&gt;AncestorClass: destructing '</span><span class="keyword">.</span><span class="default">get_class</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /></span><span class="comment">#<br /></span><span class="keyword">class </span><span class="default">ParentDestructClass </span><span class="keyword">extends </span><span class="default">AncestorClass </span><span class="keyword">{<br />&nbsp; &nbsp; function </span><span class="default">__destruct</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'ParentDestructClass: destructing itself'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">parent</span><span class="keyword">::</span><span class="default">__destruct</span><span class="keyword">();<br />&nbsp; &nbsp; }<br />}<br /></span><span class="comment">#<br /></span><span class="keyword">class </span><span class="default">EmptyDestructClass </span><span class="keyword">extends </span><span class="default">AncestorClass </span><span class="keyword">{<br />&nbsp; &nbsp; function </span><span class="default">__destruct</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'EmptyDestructClass: destructing itself'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="comment">#<br /></span><span class="keyword">class </span><span class="default">NoDestructClass </span><span class="keyword">extends </span><span class="default">AncestorClass </span><span class="keyword">{<br />}<br /></span><span class="comment">#---<br /></span><span class="keyword">echo </span><span class="string">'&lt;hr&gt;'</span><span class="keyword">;<br /></span><span class="default">$p</span><span class="keyword">=new </span><span class="default">ParentDestructClass</span><span class="keyword">();<br />unset(</span><span class="default">$p</span><span class="keyword">);<br />echo </span><span class="string">'&lt;hr&gt;'</span><span class="keyword">;<br /></span><span class="default">$e</span><span class="keyword">=new </span><span class="default">EmptyDestructClass</span><span class="keyword">();<br />unset(</span><span class="default">$e</span><span class="keyword">);<br />echo </span><span class="string">'&lt;hr&gt;'</span><span class="keyword">;<br /></span><span class="default">$n</span><span class="keyword">=new </span><span class="default">NoDestructClass</span><span class="keyword">();<br />unset(</span><span class="default">$n</span><span class="keyword">);<br />echo </span><span class="string">'&lt;hr&gt;'</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span>which displays:<br />---<br />ParentDestructClass: destructing itself<br />AncestorClass: destructing ParentDestructClass<br />---<br />EmptyDestructClass: destructing itself<br />---<br /><br />AncestorClass: destructing NoDestructClass<br />---</span>
</code></div>
  </div>
 </div>
  <div class="note" id="70051">  <div class="votes">
    <div id="Vu70051">
    <a href="/manual/vote-note.php?id=70051&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd70051">
    <a href="/manual/vote-note.php?id=70051&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V70051" title="50% like this...">
    0
    </div>
  </div>
  <a href="#70051" class="name"><strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#70051"> &para;</a><div class="date" title="2006-10-01 11:03"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom70051">
<div class="phpcode"><code><span class="html">
This is a simple thing to bear in mind but it's also easy to forget it.&nbsp; When chaining object constructors and destructors, always remember to call the superclass __construct() method in the subclass __construct() so that all superclass members are properly initialized before you start initializing the ones belonging to your subclass.&nbsp; <br /><br />Also, you will usually want to do your own cleanup first in your subclass __destruct() method so you will probably want to call the superclass __destruct() as the last thing in your subclass so that you can use resources defined in the superclass during the cleanup phase. <br /><br />For example, if your superclass includes a database connection and your subclass __destruct method commits things to the database then if you call the superclass destruct before doing so then the database connection will no longer be valid and you will be unable to commit your changes.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="56996">  <div class="votes">
    <div id="Vu56996">
    <a href="/manual/vote-note.php?id=56996&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd56996">
    <a href="/manual/vote-note.php?id=56996&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V56996" title="50% like this...">
    0
    </div>
  </div>
  <a href="#56996" class="name">
  <strong class="user"><em>contact at tcknetwork dot com</em></strong></a><a class="genanchor" href="#56996"> &para;</a><div class="date" title="2005-09-21 12:54"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom56996">
<div class="phpcode"><code><span class="html">
be careful while trying to access files with __destruct() because the base directory (getcwd()) will be the root of your server and not the path of your script, so add before all your path called in __destruct() :<br />EITHER&nbsp;&nbsp; dirname($_SERVER["SCRIPT_FILENAME"])."my/path/"<br />OR&nbsp; &nbsp; &nbsp; dirname(__FILE__)."my/path/"<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; (be careful with includes, it will give the path of the file processed and not the main file)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="81458">  <div class="votes">
    <div id="Vu81458">
    <a href="/manual/vote-note.php?id=81458&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd81458">
    <a href="/manual/vote-note.php?id=81458&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V81458" title="48% like this...">
    -1
    </div>
  </div>
  <a href="#81458" class="name">
  <strong class="user"><em>ashnazg at php dot net</em></strong></a><a class="genanchor" href="#81458"> &para;</a><div class="date" title="2008-02-28 02:39"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom81458">
<div class="phpcode"><code><span class="html">
While experimenting with destructs and unsets in relation to memory usage, I found what seems to be one useful way to predict when __destruct() gets called... call it manually yourself.<br /><br />I had previously assumed that explicitly calling unset($foo) would cause $foo-&gt;__destruct() to run implicitly, but that was not the behavior I saw (php 5.2.5).&nbsp; The destructors weren't running until the script ended, even though I was calling unset($foo) in the middle of my script.&nbsp; So, having $foo-&gt;__destruct() unset all of $foo's component objects was not helping my memory usage since my explicit unset($foo) was _not_ triggering $foo-&gt;__destruct()'s cleanup steps.<br /><br />Interestingly, what _did_ appear to happen is that calling unset($bar) from inside a destructor like $foo-&gt;__destruct() _DID_ cause $bar-&gt;__destruct() to be implicitly executed.&nbsp; Perhaps this is because $bar has a "parent" reference of $foo whereas $foo does not, and the object destruction behaves differently... I don't know.<br /><br />Lastly, even after explicitly calling $foo-&gt;__destruct() (even when it had "unset($this);" inside it), the reference to the $foo object remained visible.&nbsp; I had to still explicitly call unset($foo) to get rid of it.<br /><br />So, my advice based on the behavior I saw in my experiments:<br />- always unset($bar) your class's component objects from inside that class's __destruct() method;&nbsp; no explicit component destructor calls seem to be required other than those unsets, though.<br />- always explicitly call $foo-&gt;__destruct() in your code that _uses_ your class<br />- always explicitly follow $foo-&gt;__destruct() with unset($foo).<br /><br />This seems to be the best cleanup approach to take.&nbsp; Just for my own sanity, I also will always keep an unset($this) at the end of each __destruct() method.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="93097">  <div class="votes">
    <div id="Vu93097">
    <a href="/manual/vote-note.php?id=93097&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd93097">
    <a href="/manual/vote-note.php?id=93097&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V93097" title="47% like this...">
    -1
    </div>
  </div>
  <a href="#93097" class="name">
  <strong class="user"><em>enrico dot modanese at alpj dot com</em></strong></a><a class="genanchor" href="#93097"> &para;</a><div class="date" title="2009-08-23 07:05"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom93097">
<div class="phpcode"><code><span class="html">
It's usefull to note that parent::__construct() is executed like a standalone function called into the new one, and not like a first part of the code. So "return" or "die()" don't have effect on following code. If you want to avoid the execution of the child constructor you have to pass some condition from the parent. Example:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">X </span><span class="keyword">{ <br />&nbsp; function </span><span class="default">X</span><span class="keyword">(){<br />&nbsp; &nbsp; if(</span><span class="default">$_POST</span><span class="keyword">[</span><span class="string">'break'</span><span class="keyword">]==</span><span class="string">'yes'</span><span class="keyword">){return;}<br />&nbsp; &nbsp; }<br />&nbsp; }<br /><br />class </span><span class="default">Y </span><span class="keyword">extends </span><span class="default">X</span><span class="keyword">{ <br />&nbsp; function </span><span class="default">Y</span><span class="keyword">(){<br />&nbsp; &nbsp; </span><span class="default">parent</span><span class="keyword">::</span><span class="default">__construct</span><span class="keyword">();<br />&nbsp; &nbsp; print(</span><span class="string">"Y_constructor_finished"</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; }<br /><br /></span><span class="default">$_POST</span><span class="keyword">[</span><span class="string">'break'</span><span class="keyword">]==</span><span class="string">'yes'</span><span class="keyword">;<br /></span><span class="default">$new_Y</span><span class="keyword">=new </span><span class="default">Y</span><span class="keyword">();&nbsp; </span><span class="comment">// will print "Y_constructor_finished"<br /><br /></span><span class="default">Solution</span><span class="keyword">:<br /><br />class </span><span class="default">X </span><span class="keyword">{<br />&nbsp; function </span><span class="default">X</span><span class="keyword">(){<br />&nbsp; &nbsp; if(</span><span class="default">$_POST</span><span class="keyword">[</span><span class="string">'break'</span><span class="keyword">]==</span><span class="string">'yes'</span><span class="keyword">){</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">break</span><span class="keyword">=</span><span class="string">'yes'</span><span class="keyword">;return;}<br />&nbsp; &nbsp; }<br />&nbsp; }<br /><br />class </span><span class="default">Y </span><span class="keyword">extends </span><span class="default">X</span><span class="keyword">{<br />&nbsp; function </span><span class="default">Y</span><span class="keyword">(){<br />&nbsp; &nbsp; </span><span class="default">parent</span><span class="keyword">::</span><span class="default">__construct</span><span class="keyword">();<br />&nbsp; &nbsp; if(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">break</span><span class="keyword">==</span><span class="string">'yes'</span><span class="keyword">){return;}<br />&nbsp; &nbsp; print(</span><span class="string">"Y_constructor_finished"</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; }<br /><br /></span><span class="default">$_POST</span><span class="keyword">[</span><span class="string">'break'</span><span class="keyword">]=</span><span class="string">'yes'</span><span class="keyword">;<br /></span><span class="default">$new_Y</span><span class="keyword">=new </span><span class="default">Y</span><span class="keyword">();&nbsp; </span><span class="comment">// will print nothing<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="86260">  <div class="votes">
    <div id="Vu86260">
    <a href="/manual/vote-note.php?id=86260&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86260">
    <a href="/manual/vote-note.php?id=86260&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86260" title="46% like this...">
    -1
    </div>
  </div>
  <a href="#86260" class="name">
  <strong class="user"><em>Jeffrey</em></strong></a><a class="genanchor" href="#86260"> &para;</a><div class="date" title="2008-10-09 02:04"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86260">
<div class="phpcode"><code><span class="html">
Constructor Simplicity<br /><br />If your class DOES CONTAIN instance members (variables) that need to be set, then your class needs to be initialized... and you should use __construct() to do that.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">MyClassA </span><span class="keyword">{<br />&nbsp; public </span><span class="default">$data1</span><span class="keyword">, </span><span class="default">$data2</span><span class="keyword">;<br /><br />&nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$mcd1</span><span class="keyword">, </span><span class="default">$mcd2</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">data1 </span><span class="keyword">= </span><span class="default">$mcd1</span><span class="keyword">;&nbsp; </span><span class="comment">// INITIALIZE $data1<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">data2 </span><span class="keyword">= </span><span class="default">$mcd2</span><span class="keyword">;&nbsp; </span><span class="comment">// INITIALIZE $data2<br />&nbsp; </span><span class="keyword">}<br />}<br /><br /></span><span class="default">$obj1 </span><span class="keyword">= new </span><span class="default">MyClassA</span><span class="keyword">(</span><span class="string">"Hello"</span><span class="keyword">, </span><span class="string">"World!"</span><span class="keyword">);&nbsp; </span><span class="comment">// INSTANTIATE MyClassA<br /></span><span class="default">$d1 </span><span class="keyword">= </span><span class="default">$obj1</span><span class="keyword">-&gt;</span><span class="default">data1</span><span class="keyword">;<br /></span><span class="default">$d2 </span><span class="keyword">= </span><span class="default">$obj1</span><span class="keyword">-&gt;</span><span class="default">data2</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />If your class DOES NOT CONTAIN instance members or you DO NOT want to instantiate it, then there is no reason to initialize it or use __construct().<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">MyClassB </span><span class="keyword">{<br />&nbsp; const </span><span class="default">DATA1 </span><span class="keyword">= </span><span class="string">"Hello"</span><span class="keyword">;<br />&nbsp; public static </span><span class="default">$data2 </span><span class="keyword">= </span><span class="string">"World!"</span><span class="keyword">;<br />}<br /><br /></span><span class="default">$obj1 </span><span class="keyword">= new </span><span class="default">MyClassB</span><span class="keyword">();&nbsp; </span><span class="comment">// INSTANTIATE MyClassB - NO error.<br /></span><span class="default">$d1 </span><span class="keyword">= </span><span class="default">$obj1</span><span class="keyword">::</span><span class="default">DATA1</span><span class="keyword">;&nbsp; &nbsp; &nbsp; </span><span class="comment">// ERROR<br /></span><span class="default">$d2 </span><span class="keyword">= </span><span class="default">$obj1</span><span class="keyword">::</span><span class="default">data2</span><span class="keyword">;&nbsp; &nbsp; &nbsp; </span><span class="comment">// ERROR<br /></span><span class="default">$d1 </span><span class="keyword">= </span><span class="default">MyClassB</span><span class="keyword">::</span><span class="default">DATA1</span><span class="keyword">;&nbsp;&nbsp; </span><span class="comment">// ok<br /></span><span class="default">$d2 </span><span class="keyword">= </span><span class="default">MyClassB</span><span class="keyword">::</span><span class="default">$data2</span><span class="keyword">;&nbsp; </span><span class="comment">// ok<br /></span><span class="default">?&gt;<br /></span><br />The fact that $obj1 is useless and cannot be used as a reference, is further evidence that MyClassB objects should not be instantiated. NOTICE that MyClassB does not use private members or functions to make it behave that way. Rather, it is the collective nature of all the class members + what ISN'T there.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="66288">  <div class="votes">
    <div id="Vu66288">
    <a href="/manual/vote-note.php?id=66288&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd66288">
    <a href="/manual/vote-note.php?id=66288&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V66288" title="42% like this...">
    -1
    </div>
  </div>
  <a href="#66288" class="name">
  <strong class="user"><em>Peter Molnar</em></strong></a><a class="genanchor" href="#66288"> &para;</a><div class="date" title="2006-05-18 06:24"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom66288">
<div class="phpcode"><code><span class="html">
There were many notes about the inability of defining multiple constructors for the class.<br /><br />My solution is to define separate static methods for each type of constructor.<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Vector </span><span class="keyword">{<br />&nbsp; &nbsp; private </span><span class="default">$x</span><span class="keyword">;<br />&nbsp; &nbsp; private </span><span class="default">$y</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">x </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">y </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public static function </span><span class="default">createXY</span><span class="keyword">(</span><span class="default">$x</span><span class="keyword">, </span><span class="default">$y</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$v </span><span class="keyword">= new </span><span class="default">Vector</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$v</span><span class="keyword">-&gt;</span><span class="default">x </span><span class="keyword">= </span><span class="default">$x</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$v</span><span class="keyword">-&gt;</span><span class="default">y </span><span class="keyword">= </span><span class="default">$y</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$v</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="55799">  <div class="votes">
    <div id="Vu55799">
    <a href="/manual/vote-note.php?id=55799&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd55799">
    <a href="/manual/vote-note.php?id=55799&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V55799" title="42% like this...">
    -1
    </div>
  </div>
  <a href="#55799" class="name">
  <strong class="user"><em>php dot net at lk2 dot de</em></strong></a><a class="genanchor" href="#55799"> &para;</a><div class="date" title="2005-08-13 09:50"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom55799">
<div class="phpcode"><code><span class="html">
It looks like `echo()`ed output from the __destructor() function is displayed onto screen _before_ other output that the class may have have already sent before.<br /><br />This can be misleading if you have debug info printed in the destructor but not a problem if you know it.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="91013">  <div class="votes">
    <div id="Vu91013">
    <a href="/manual/vote-note.php?id=91013&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd91013">
    <a href="/manual/vote-note.php?id=91013&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V91013" title="41% like this...">
    -2
    </div>
  </div>
  <a href="#91013" class="name">
  <strong class="user"><em>hyponiq at gmail dot com</em></strong></a><a class="genanchor" href="#91013"> &para;</a><div class="date" title="2009-05-20 06:43"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom91013">
<div class="phpcode"><code><span class="html">
I just thought I'd share some valuable information that might help novice programmers/scripters in __constructor() functions.<br /><br />I've been using PHP for quite a long time, as well as programming and scripting in general.&nbsp; Even with my quite seasoned skillset, I still make obvious, painstaking mistakes.&nbsp; That said, I'd like to point out one major (albeit obvious) common mistake that programmers and scripters (such as myself) make.<br /><br />When defining the constructor for an object and using it to populate variables for use throughout the lifetime of the application, do note that if you set a static variable AFTER a dynamic one, the static variable's (intended) contents are not readible inside the assigning functions of a dynamic variable.&nbsp; (That sounded rather cryptic, so an example is in order...)<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">ExampleClass<br /></span><span class="keyword">{<br />&nbsp; &nbsp; </span><span class="comment">// assigned a static value using an expression in the constructor<br />&nbsp; &nbsp; </span><span class="keyword">public </span><span class="default">$myStaticVar</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">// assigned a value through a function of the class<br />&nbsp; &nbsp; </span><span class="keyword">public </span><span class="default">$myDynamicVar</span><span class="keyword">; <br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$myStaticVarValue</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// sets to nothing; $this-&gt;myStaticVar hasn't been assigned to yet<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">myDynamicVar </span><span class="keyword">= </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">setSomeValue</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// sets to 'Static Variable Value in this example<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">myStaticVar </span><span class="keyword">= </span><span class="default">$myStaticVarValue</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">setSomeValue</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// returns null; $this-&gt;myStaticVar hasn't been assigned to, yet<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">myStaticVar</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="comment">// automatically sets $object-&gt;myStaticVar to 'Static Variable Value'<br />//(but only after setting $object-&gt;myDynamicVar to the unassigned $object-&gt;myStaticVar)<br /></span><span class="default">$object </span><span class="keyword">= new </span><span class="default">ExampleClass</span><span class="keyword">(</span><span class="string">'Static Variable Value'</span><span class="keyword">);<br /><br /></span><span class="comment">// outputs nothing<br /></span><span class="keyword">print </span><span class="default">$object</span><span class="keyword">-&gt;</span><span class="default">myDynamicVar</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />The above example won't print anything because you're setting the $myDynamicVar to equal the $myStaticVar, but the $myStaticVar hasn't been (technically) assigned to, yet.<br /><br />So, if you wish to reference that variable inside the assignment function of a dynamic variable, you have to declare it first and foremost.&nbsp; Otherwise, its value will not be accessible yet.<br /><br />The correct way...<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">ExampleClass<br /></span><span class="keyword">{<br />&nbsp; &nbsp; </span><span class="comment">// assigned a static value using an expression in the constructor<br />&nbsp; &nbsp; </span><span class="keyword">public </span><span class="default">$myStaticVar</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">// assigned a value through a function of the class<br />&nbsp; &nbsp; </span><span class="keyword">public </span><span class="default">$myDynamicVar</span><span class="keyword">; <br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$myStaticVarValue</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// sets to $myStaticVariable (or 'Some Static Variable Value' in this example)<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">myStaticVar </span><span class="keyword">= </span><span class="default">$myStaticVarValue</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// sets to newly assigned-to $this-&gt;myStaticVariable<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">myDynamicVar </span><span class="keyword">= </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">setSomeValue</span><span class="keyword">();<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">setSomeValue</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// returns 'Static Variable Value'<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">myStaticVar</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="comment">// sets $object-&gt;myStaticVar to 'Static Variable Value' automatically before $object-&gt;myDynamicVar<br /></span><span class="default">$object </span><span class="keyword">= new </span><span class="default">ExampleClass</span><span class="keyword">(</span><span class="string">'Static Variable Value'</span><span class="keyword">);<br /><br /></span><span class="comment">// outputs 'Static Variable Value'<br /></span><span class="keyword">print </span><span class="default">$object</span><span class="keyword">-&gt;</span><span class="default">myDynamicVar</span><span class="keyword">;<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="63590">  <div class="votes">
    <div id="Vu63590">
    <a href="/manual/vote-note.php?id=63590&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd63590">
    <a href="/manual/vote-note.php?id=63590&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V63590" title="40% like this...">
    -1
    </div>
  </div>
  <a href="#63590" class="name">
  <strong class="user"><em>jcaplan at bogus dot amazon dot com</em></strong></a><a class="genanchor" href="#63590"> &para;</a><div class="date" title="2006-03-24 09:52"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom63590">
<div class="phpcode"><code><span class="html">
__construct and __destruct must be declared public in any class that you intend to instantiate with new.&nbsp;&nbsp; However, in an abstract (or never-instantiated base) class you can declare them private or protected, and subclasses can still refer to them via parent::__construct (!) (tested in PHP 5.1.2).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="83252">  <div class="votes">
    <div id="Vu83252">
    <a href="/manual/vote-note.php?id=83252&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd83252">
    <a href="/manual/vote-note.php?id=83252&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V83252" title="36% like this...">
    -3
    </div>
  </div>
  <a href="#83252" class="name">
  <strong class="user"><em>KK</em></strong></a><a class="genanchor" href="#83252"> &para;</a><div class="date" title="2008-05-16 01:57"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom83252">
<div class="phpcode"><code><span class="html">
I ran into an interesting (and subtle) code error while porting some code to PHP 5.2.5 from PHP 4.4.8 that I think illustrates a noteworthy semantic.<br /><br />I have a hierarchy of classes with both styles of constructors but where one in the middle was missing the __construct() function (it just had the old-style one that called the (nonexistent) __construct()).&nbsp; It worked fine in PHP4 but caused an endless loop (and stack overflow) in PHP5.&nbsp; I believe what happened is that in PHP4 the old-style constructor was not called, but in PHP5 it was (due to the "emulation" of PHP4), and since _construct() wasn't defined for that class, the call to $this-&gt;__construct() caused a looping call to the original (lowest child) constructor.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="78430">  <div class="votes">
    <div id="Vu78430">
    <a href="/manual/vote-note.php?id=78430&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd78430">
    <a href="/manual/vote-note.php?id=78430&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V78430" title="33% like this...">
    -1
    </div>
  </div>
  <a href="#78430" class="name">
  <strong class="user"><em>magus do t xion a t g mail d ot c o m</em></strong></a><a class="genanchor" href="#78430"> &para;</a><div class="date" title="2007-10-11 12:20"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom78430">
<div class="phpcode"><code><span class="html">
Looking through the notes I noticed a few people expressing concern that PHP5 does not support multiple constructors...<br /><br />Here is an example of a method that I use which seems to work fine:<br /><br />class Example<br />{<br />&nbsp; &nbsp;&nbsp; function __construct()<br />&nbsp; &nbsp;&nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; echo "do some basic stuff here";<br />&nbsp; &nbsp;&nbsp; }<br /><br />&nbsp; &nbsp;&nbsp; function Example($arg)<br />&nbsp; &nbsp;&nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; echo $arg;<br />&nbsp; &nbsp;&nbsp; }<br />}<br /><br />You then can call with or without arguments without having notices and/or warnings thrown at you... Of course this is limited but if you don't need something complex this can help to get the job done in some situations.&nbsp; I believe you could also add arguments to the __construct() function and as long as it is different than Example() 's args you would be fine. Although I have yet to test this.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="79986">  <div class="votes">
    <div id="Vu79986">
    <a href="/manual/vote-note.php?id=79986&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd79986">
    <a href="/manual/vote-note.php?id=79986&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V79986" title="33% like this...">
    -2
    </div>
  </div>
  <a href="#79986" class="name">
  <strong class="user"><em>Typer85 at gmail dot com</em></strong></a><a class="genanchor" href="#79986"> &para;</a><div class="date" title="2007-12-21 09:31"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom79986">
<div class="phpcode"><code><span class="html">
In regards to a Class Constructor visibility ...<br /><br />I too was having the same problem with Class Constructor visibility, in which I had one Class that was extended by several other Classes. The problem that I encountered was in one of the Child Classes, I wanted a weaker visibility. Consider the following example:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">A </span><span class="keyword">{<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">// Public Constructor ...<br />&nbsp; &nbsp; // No Problems Here.<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">__construct</span><span class="keyword">( ) {<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">// Class Function.<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">functionA</span><span class="keyword">( ) {<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">B </span><span class="keyword">extends </span><span class="default">A </span><span class="keyword">{<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">// Public Constructor ... <br />&nbsp; &nbsp; // Same As Parent Class ...<br />&nbsp; &nbsp; // Again No Problems Here.<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">__construct</span><span class="keyword">( ) {<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">// Class Function.<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">functionB</span><span class="keyword">( ) {<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">C </span><span class="keyword">extends </span><span class="default">A </span><span class="keyword">{<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">// Private Constructor ...<br />&nbsp; &nbsp; // Weaker Then Parent Class ...<br />&nbsp; &nbsp; // PHP Will Throw A Fatal Error.<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="keyword">private function </span><span class="default">__construct</span><span class="keyword">( ) {<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">// Class Function.<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">functionC</span><span class="keyword">( ) {<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />Nothing new in the above example that we have not seen before. My solution to solve this problem?<br /><br />Create an Abstract Class with all the functionality of Class A.&nbsp; Make its Class Constructor have a visibility of Protected, then extend each of the three Classes above from that Abstract Class. In a way, the Abstract Class acts as a dummy Class to get rid of the visibility problem:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">abstract class </span><span class="default">AAbstract </span><span class="keyword">{<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">// Protected Constructor ...<br />&nbsp; &nbsp; // Abstract Class Can Not Be Created Anyway ...<br />&nbsp; &nbsp; // No Problems Here.<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="keyword">protected function </span><span class="default">__construct</span><span class="keyword">( ) {<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">// Class Function ...<br />&nbsp; &nbsp; // Originally In Class A ...<br />&nbsp; &nbsp; // Which Was Used As A Super Class.<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">functionA</span><span class="keyword">( ) {<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">A </span><span class="keyword">extends </span><span class="default">AAbstract </span><span class="keyword">{<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">// Public Constructor ...<br />&nbsp; &nbsp; // Stronger Than Parent Class ...<br />&nbsp; &nbsp; // Again No Problems Here.<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">__construct</span><span class="keyword">( ) {<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// By Moving All The Functionality Of<br />&nbsp; &nbsp; &nbsp; &nbsp; // Class A To Class AAbstract Class A<br />&nbsp; &nbsp; &nbsp; &nbsp; // Will Automatically Inherit All Of<br />&nbsp; &nbsp; &nbsp; &nbsp; // Its Functionality. The Only Thing<br />&nbsp; &nbsp; &nbsp; &nbsp; // Left To Do Is To Create A Constructor<br />&nbsp; &nbsp; &nbsp; &nbsp; // Which Calls Class AABstract's Constructor<br />&nbsp; &nbsp; &nbsp; &nbsp; // To Mimic Similar Behavior.<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">parent</span><span class="keyword">::</span><span class="default">__construct</span><span class="keyword">( );<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">// No Need To Redeclare functionA( ) <br />&nbsp; &nbsp; // Since It Was Moved To Class<br />&nbsp; &nbsp; // AAbstract.<br /></span><span class="keyword">}<br /><br />class </span><span class="default">B </span><span class="keyword">extends </span><span class="default">AAbstract&nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">// Public Constructor ...<br />&nbsp; &nbsp; // Stronger Than Parent Class ...<br />&nbsp; &nbsp; // Again No Problems Here.<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">__construct</span><span class="keyword">( ) {<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">parent</span><span class="keyword">::</span><span class="default">__construct</span><span class="keyword">( );<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">// Class Function ...<br />&nbsp; &nbsp; // Specific To This Class.<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">functionB</span><span class="keyword">( ) {<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">C </span><span class="keyword">extends </span><span class="default">AAbstract </span><span class="keyword">{<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">// Protected Constructor ...<br />&nbsp; &nbsp; // Same As Parent Class ...<br />&nbsp; &nbsp; // Again No Problems Here.<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="keyword">protected function </span><span class="default">__construct</span><span class="keyword">( ) {<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">// Class Function ...<br />&nbsp; &nbsp; // Specific To This Class.<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">functionC</span><span class="keyword">( ) {<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />As you can see the problem is more or less fixed. Class AAbstract acts a dummy class, containing all the original functionality of Class A. But because it has a protected Constructor, in order to make its functionality available, Class A is redeclared as Child Class with the only difference of it having a public Constructor that automatically calls the Parent Constructor.<br /><br />Notice that Class B does not extend from Class A but also from Class AAbstract! If I wanted to change Class B's Constructor to protected, I can easily do it! Notice that an extra Method was added to Class B ... this is because Class B has extra functionality specific to itself. Same applies to Class C.<br /><br />Why don't Class B and Class C extend from Class A? Because Class A has a public Constructor, which pretty much defies the point of this solution.<br /><br />This solution is not perfect however and has some flaws.<br /><br />Good Luck,</span>
</code></div>
  </div>
 </div>
  <div class="note" id="86348">  <div class="votes">
    <div id="Vu86348">
    <a href="/manual/vote-note.php?id=86348&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86348">
    <a href="/manual/vote-note.php?id=86348&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86348" title="28% like this...">
    -3
    </div>
  </div>
  <a href="#86348" class="name">
  <strong class="user"><em>office at kitsoftware dot ro</em></strong></a><a class="genanchor" href="#86348"> &para;</a><div class="date" title="2008-10-14 07:01"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86348">
<div class="phpcode"><code><span class="html">
Should be noted that according to the NEWS (in PHP 5.3) file, in PHP 5.3, handling an exception in the __destructor should not output a FATAL error ...</span>
</code></div>
  </div>
 </div>
  <div class="note" id="70876">  <div class="votes">
    <div id="Vu70876">
    <a href="/manual/vote-note.php?id=70876&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd70876">
    <a href="/manual/vote-note.php?id=70876&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V70876" title="28% like this...">
    -3
    </div>
  </div>
  <a href="#70876" class="name">
  <strong class="user"><em>phaxius</em></strong></a><a class="genanchor" href="#70876"> &para;</a><div class="date" title="2006-11-01 09:23"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom70876">
<div class="phpcode"><code><span class="html">
Hello, I've been messing with php for about a week but am learning a lot.&nbsp; It occurred to me that it might be necessary in some cases to write a class that takes a variable number of arguments.&nbsp; After some experimentation, this example was formed:<br /><br />class variableArgs{<br />public $a = array();<br />protected $numOfArgs;<br />public function __construct()<br />{<br />&nbsp; $numOfArgs=func_num_args();<br />&nbsp; if(func_num_args()==0)<br />&nbsp; {<br />&nbsp; &nbsp; $numOfArgs=1;<br />&nbsp; &nbsp; $a[0]='No arguments passed';<br />&nbsp; &nbsp; $this-&gt;Arg[0]=$a[0];<br />&nbsp; }<br />&nbsp; else<br />&nbsp; for($i=0; $i&lt;func_num_args(); $i++)<br />&nbsp; {<br />&nbsp; &nbsp; $a[$i]=func_get_arg($i);<br />&nbsp; &nbsp; $this-&gt;Arg[$i]=$a[$i];<br />&nbsp; }<br />}<br />public function showArgs()<br />{<br />&nbsp; echo 'showArgs() called &lt;br /&gt;';<br />&nbsp; for ($i=0; $i&lt;$numOfArgs; $i++)<br />&nbsp; {<br />&nbsp; &nbsp; echo '$i: ' . $i . '&lt;br /&gt;';<br />&nbsp; &nbsp; echo $this-&gt;Arg[$i];<br />&nbsp; &nbsp; echo '&lt;br /&gt;';<br />&nbsp; }<br />}<br />public function __destruct(){}<br /><br />}<br /><br />$test1 = new variableArgs;<br />$test2 = new variableArgs("arg1");<br />$test3 = new variableArgs("arg1", "arg2");<br />$test4 = new variableArgs("arg1", "arg2", "arg3");<br /><br />$test1-&gt;showArgs();<br />$test2-&gt;showArgs();<br />$test3-&gt;showArgs();<br />$test4-&gt;showArgs();<br /><br />This outputs the following:<br /><br />showArgs() called <br />$i: 0<br />No arguments passed<br />showArgs() called <br />$i: 0<br />arg1<br />showArgs() called <br />$i: 0<br />arg1<br />$i: 1<br />arg2<br />showArgs() called <br />$i: 0<br />arg1<br />$i: 1<br />arg2<br />$i: 2<br />arg3<br /><br />I have no idea how efficient this is, but it works at any rate.&nbsp; Hopefully this helps someone.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="96446">  <div class="votes">
    <div id="Vu96446">
    <a href="/manual/vote-note.php?id=96446&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd96446">
    <a href="/manual/vote-note.php?id=96446&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V96446" title="25% like this...">
    -2
    </div>
  </div>
  <a href="#96446" class="name">
  <strong class="user"><em>thomasrutter</em></strong></a><a class="genanchor" href="#96446"> &para;</a><div class="date" title="2010-02-27 03:20"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom96446">
<div class="phpcode"><code><span class="html">
The manual page says that throwing an exception from a destructor causes a fatal error;&nbsp; I've found that this only happens when the exception is _uncaught_ within the context of that destructor.&nbsp; If you catch it within that same destructor it seems to be fine.<br /><br />This is equally true of other contexts, such as:<br />- shutdown functions set with register_shutdown_function<br />- destructors<br />- custom session close functions<br />- custom error handlers<br />- perhaps other similar contexts<br /><br />An exception normally 'bubbles up' to higher and higher contexts until it is caught, but because a destructor or shutdown function is called not within execution flow but in response to a special PHP event, the exception is unable to be traced back any further than the destructor or shutdown function in which it is called.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="69036">  <div class="votes">
    <div id="Vu69036">
    <a href="/manual/vote-note.php?id=69036&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd69036">
    <a href="/manual/vote-note.php?id=69036&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V69036" title="16% like this...">
    -4
    </div>
  </div>
  <a href="#69036" class="name">
  <strong class="user"><em>chanibal at deltasoft dot int dot pl dot SPAMPROTECT</em></strong></a><a class="genanchor" href="#69036"> &para;</a><div class="date" title="2006-08-20 09:56"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom69036">
<div class="phpcode"><code><span class="html">
Note that if a class contains another class, the contained class's destructor will be triggered after the destructor of the containing class.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">contained </span><span class="keyword">{<br /> <br /> protected </span><span class="default">$parent</span><span class="keyword">;<br /><br /> public function </span><span class="default">__construct</span><span class="keyword">(&amp;</span><span class="default">$p</span><span class="keyword">) {<br />&nbsp; </span><span class="comment"># $this-&gt;parent=&amp;$p;<br />&nbsp; </span><span class="keyword">}<br /> <br /> public function </span><span class="default">__destruct</span><span class="keyword">() {<br />&nbsp; </span><span class="comment">/* unset $this-&gt;parent */<br />&nbsp; </span><span class="keyword">print </span><span class="string">'contained '</span><span class="keyword">;<br />&nbsp; }<br /> }<br /> <br />class </span><span class="default">containing </span><span class="keyword">{<br /><br /> protected </span><span class="default">$contained</span><span class="keyword">;<br /><br /> public function </span><span class="default">__construct</span><span class="keyword">() {<br />&nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">contained</span><span class="keyword">=new </span><span class="default">contained</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">);<br />&nbsp; } <br /><br /> public function </span><span class="default">__destruct</span><span class="keyword">() {<br />&nbsp; </span><span class="comment">// unset($this-&gt;contained);<br />&nbsp; </span><span class="keyword">print </span><span class="string">'containing '</span><span class="keyword">;<br />&nbsp; }<br /> }<br /> <br /> <br />new </span><span class="default">containing</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span><br />Will output<br />containing contained<br /><br />After uncommenting the // comment, the output will change to<br />contained containing <br /><br />Adding a reference from the contained class to the containing one (the # comment) will not change that, but beware, because it can cause random errors in other destructors in the parts of the script which seem unrelated! (PHP Version 5.1.2)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="78737">  <div class="votes">
    <div id="Vu78737">
    <a href="/manual/vote-note.php?id=78737&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd78737">
    <a href="/manual/vote-note.php?id=78737&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V78737" title="10% like this...">
    -8
    </div>
  </div>
  <a href="#78737" class="name">
  <strong class="user"><em>James Laver</em></strong></a><a class="genanchor" href="#78737"> &para;</a><div class="date" title="2007-10-25 02:45"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom78737">
<div class="phpcode"><code><span class="html">
I recently found, while implementing a database backed session class, that PHP has an apparently less than desirably structured destruction order. Basically, my session class which would have saved when destructed, was being destructed after one of the classes it depends on. Apparently we cannot, therefore depend on PHP to use reverse initialisation order.<br /><br />My solution was to use register_shutdown_function, which is called before any objects are killed on script end.<br /><br />Quick example (if you're going to use it, I recommend tidying up the code somewhat) :<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Session<br />&nbsp; </span><span class="keyword">function </span><span class="default">__construct</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; </span><span class="comment">//Initialise the session here...<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; //Register the shutdown function<br />&nbsp; &nbsp; </span><span class="default">register_shutdown_function</span><span class="keyword">(array(</span><span class="default">$this</span><span class="keyword">,</span><span class="string">"save"</span><span class="keyword">));<br />&nbsp; }<br /><br />&nbsp; function </span><span class="default">save</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; </span><span class="comment">//Save it here<br />&nbsp; </span><span class="keyword">}<br /><br />&nbsp; function </span><span class="default">__destruct</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; </span><span class="comment">//Persisting the session here will not work.<br />&nbsp; </span><span class="keyword">}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="54639">  <div class="votes">
    <div id="Vu54639">
    <a href="/manual/vote-note.php?id=54639&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd54639">
    <a href="/manual/vote-note.php?id=54639&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V54639" title="9% like this...">
    -9
    </div>
  </div>
  <a href="#54639" class="name">
  <strong class="user"><em>dominics at gmail dot com</em></strong></a><a class="genanchor" href="#54639"> &para;</a><div class="date" title="2005-07-10 07:12"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom54639">
<div class="phpcode"><code><span class="html">
If you're using E_STRICT error reporting, PHP will tell you if you define both __construct() and an old-style constructor (a function with the same name as the class) together in a class. Note that this occurs even if the old constructor function is abstract or final (for instance, if you were intending to only use it in a sub-class). Be wary of this if you're trying to implement the 'command' design pattern.<br /><br />The solution? Either turn E_STRICT off (and possibly forgo some other important notices), rename your function (and possibly make things a little more complicated), or look at using an interface.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119686">  <div class="votes">
    <div id="Vu119686">
    <a href="/manual/vote-note.php?id=119686&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119686">
    <a href="/manual/vote-note.php?id=119686&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119686" title="0% like this...">
    -3
    </div>
  </div>
  <a href="#119686" class="name">
  <strong class="user"><em>joelhy</em></strong></a><a class="genanchor" href="#119686"> &para;</a><div class="date" title="2016-08-03 03:26"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119686">
<div class="phpcode"><code><span class="html">
I just find out that you can instantiate an object from another object:<br />&gt;&gt;&gt; $dt = new Datetime();<br />=&gt; DateTime {#174<br />&nbsp; &nbsp;&nbsp; +"date": "2016-08-03 11:00:08.000000",<br />&nbsp; &nbsp;&nbsp; +"timezone_type": 3,<br />&nbsp; &nbsp;&nbsp; +"timezone": "Asia/Shanghai",<br />&nbsp;&nbsp; }<br />&gt;&gt;&gt; new $dt();<br />=&gt; DateTime {#167<br />&nbsp; &nbsp;&nbsp; +"date": "2016-08-03 11:00:18.000000",<br />&nbsp; &nbsp;&nbsp; +"timezone_type": 3,<br />&nbsp; &nbsp;&nbsp; +"timezone": "Asia/Shanghai",<br />&nbsp;&nbsp; }<br />&gt;&gt;&gt;</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117547">  <div class="votes">
    <div id="Vu117547">
    <a href="/manual/vote-note.php?id=117547&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117547">
    <a href="/manual/vote-note.php?id=117547&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117547" title="0% like this...">
    -4
    </div>
  </div>
  <a href="#117547" class="name">
  <strong class="user"><em>479258741 at qq dot com</em></strong></a><a class="genanchor" href="#117547"> &para;</a><div class="date" title="2015-06-26 10:54"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117547">
<div class="phpcode"><code><span class="html">
If a new reference of the object is created during __destruct, the memory for the object will not be freed, and the __destruct will not be called for a second time.<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Foo</span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$i </span><span class="keyword">= </span><span class="string">"I=12345678\n"</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">showI</span><span class="keyword">(){<br />&nbsp; &nbsp; &nbsp; &nbsp; echo(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">i</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">__destruct</span><span class="keyword">(){<br />&nbsp; &nbsp; &nbsp; &nbsp; echo(</span><span class="string">"in __destruct\n"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">'flag'</span><span class="keyword">])<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">'test'</span><span class="keyword">][</span><span class="default">0</span><span class="keyword">] = </span><span class="default">$this</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$flag </span><span class="keyword">= </span><span class="default">true</span><span class="keyword">;<br /></span><span class="default">$test </span><span class="keyword">= [new </span><span class="default">Foo</span><span class="keyword">()];<br />echo(</span><span class="string">"deleting Foo\n"</span><span class="keyword">);<br />unset(</span><span class="default">$test</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]);<br />echo(</span><span class="string">"deleted Foo\n"</span><span class="keyword">);<br /></span><span class="default">$test</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]-&gt;</span><span class="default">showI</span><span class="keyword">();<br /></span><span class="default">$flag </span><span class="keyword">= </span><span class="default">false</span><span class="keyword">;<br />echo(</span><span class="string">"re-deleting Foo\n"</span><span class="keyword">);<br />unset(</span><span class="default">$test</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]);<br />echo(</span><span class="string">"deleted Foo\n"</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span>In the above example, the output is:<br />deleting Foo<br />in __destruct<br />deleted Foo<br />I=12345678<br />re-deleting Foo<br />deleted Foo<br />so the __destruct was called only once and the memory was not freed.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="76361">  <div class="votes">
    <div id="Vu76361">
    <a href="/manual/vote-note.php?id=76361&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd76361">
    <a href="/manual/vote-note.php?id=76361&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V76361" title="0% like this...">
    -4
    </div>
  </div>
  <a href="#76361" class="name">
  <strong class="user"><em>theubaz at gmail dot com</em></strong></a><a class="genanchor" href="#76361"> &para;</a><div class="date" title="2007-07-11 04:35"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom76361">
<div class="phpcode"><code><span class="html">
What you could do is write the constructor without any declared arguments, then iterate through the arguments given and check their types/values to determine what other function to use as the constructor.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="90746">  <div class="votes">
    <div id="Vu90746">
    <a href="/manual/vote-note.php?id=90746&amp;page=language.oop5.decon&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd90746">
    <a href="/manual/vote-note.php?id=90746&amp;page=language.oop5.decon&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V90746" title="0% like this...">
    -13
    </div>
  </div>
  <a href="#90746" class="name">
  <strong class="user"><em>ceo at l-i-e dot com</em></strong></a><a class="genanchor" href="#90746"> &para;</a><div class="date" title="2009-05-07 10:38"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom90746">
<div class="phpcode"><code><span class="html">
As far as I can tell, Connection: close isn't sent until after __destruct is called in shutdown sequence.<br />I was hoping to get the HTTP connection closed and done, and do some slow non-output processing after that, but no luck.</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.oop5.decon&amp;redirect=http://php.net/manual/en/language.oop5.decon.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.oop5.php">Classes and Objects</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="oop5.intro.php" title="Introduction">Introduction</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.basic.php" title="The Basics">The Basics</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.properties.php" title="Properties">Properties</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.constants.php" title="Class Constants">Class Constants</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.autoload.php" title="Autoloading Classes">Autoloading Classes</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.oop5.decon.php" title="Constructors and Destructors">Constructors and Destructors</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.visibility.php" title="Visibility">Visibility</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.inheritance.php" title="Object Inheritance">Object Inheritance</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.paamayim-nekudotayim.php" title="Scope Resolution Operator (::)">Scope Resolution Operator (::)</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.static.php" title="Static Keyword">Static Keyword</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.abstract.php" title="Class Abstraction">Class Abstraction</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.interfaces.php" title="Object Interfaces">Object Interfaces</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.traits.php" title="Traits">Traits</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.anonymous.php" title="Anonymous classes">Anonymous classes</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.overloading.php" title="Overloading">Overloading</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.iterations.php" title="Object Iteration">Object Iteration</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.magic.php" title="Magic Methods">Magic Methods</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.final.php" title="Final Keyword">Final Keyword</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.cloning.php" title="Object Cloning">Object Cloning</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.object-comparison.php" title="Comparing Objects">Comparing Objects</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.typehinting.php" title="Type Hinting">Type Hinting</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.late-static-bindings.php" title="Late Static Bindings">Late Static Bindings</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.references.php" title="Objects and references">Objects and references</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.serialization.php" title="Object Serialization">Object Serialization</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.changelog.php" title="OOP Changelog">OOP Changelog</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

