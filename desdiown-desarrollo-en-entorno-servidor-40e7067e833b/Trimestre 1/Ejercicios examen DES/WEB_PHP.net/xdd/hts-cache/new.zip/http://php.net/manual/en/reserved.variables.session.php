<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: $_SESSION - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/reserved.variables.session.php">
 <link rel="shorturl" href="http://php.net/manual/en/reserved.variables.session.php">
 <link rel="alternate" href="http://php.net/manual/en/reserved.variables.session.php" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/reserved.variables.php">
 <link rel="prev" href="http://php.net/manual/en/reserved.variables.request.php">
 <link rel="next" href="http://php.net/manual/en/reserved.variables.environment.php">

 <link rel="alternate" href="http://php.net/manual/en/reserved.variables.session.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/reserved.variables.session.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/reserved.variables.session.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/reserved.variables.session.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/reserved.variables.session.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/reserved.variables.session.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/reserved.variables.session.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/reserved.variables.session.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/reserved.variables.session.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/reserved.variables.session.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/reserved.variables.session.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="reserved.variables.environment.php">
          $_ENV &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="reserved.variables.request.php">
          &laquo; $_REQUEST        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='reserved.variables.php'>Predefined Variables</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/reserved.variables.session.php' selected="selected">English</option>
            <option value='pt_BR/reserved.variables.session.php'>Brazilian Portuguese</option>
            <option value='zh/reserved.variables.session.php'>Chinese (Simplified)</option>
            <option value='fr/reserved.variables.session.php'>French</option>
            <option value='de/reserved.variables.session.php'>German</option>
            <option value='ja/reserved.variables.session.php'>Japanese</option>
            <option value='ro/reserved.variables.session.php'>Romanian</option>
            <option value='ru/reserved.variables.session.php'>Russian</option>
            <option value='es/reserved.variables.session.php'>Spanish</option>
            <option value='tr/reserved.variables.session.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/reserved.variables.session.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=reserved.variables.session">Report a Bug</a>
    </div>
  </div><div id="reserved.variables.session" class="refentry">
 <div class="refnamediv">
  <h1 class="refname">$_SESSION</h1>
  <h1 class="refname">$HTTP_SESSION_VARS [deprecated]</h1>
  <p class="verinfo">(PHP 4 &gt;= 4.1.0, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">$_SESSION</span> -- <span class="refname">$HTTP_SESSION_VARS [deprecated]</span> &mdash; <span class="dc-title">Session variables</span></p>

 </div>
 
 <div class="refsect1 description" id="refsect1-reserved.variables.session-description">
  <h3 class="title">Description</h3>
  <p class="para">
   An associative array containing session variables available to
   the current script. See the <a href="ref.session.php" class="link">Session
   functions</a> documentation for more information on how this
   is used.
  </p>

  <p class="simpara">
   <var class="varname"><var class="varname">$HTTP_SESSION_VARS</var></var> contains the same initial
   information, but is not a <a href="language.variables.superglobals.php" class="link">superglobal</a>.
   (Note that <var class="varname"><var class="varname">$HTTP_SESSION_VARS</var></var> and <var class="varname"><var class="varname">$_SESSION</var></var>
   are different variables and that PHP handles them as such)
  </p>
 </div>

 
 <div class="refsect1 changelog" id="refsect1-reserved.variables.session-changelog">
  <h3 class="title">Changelog</h3>
  <p class="para">
   <table class="doctable informaltable">
    
     <thead>
      <tr>
       <th>Version</th>
       <th>Description</th>
      </tr>

     </thead>

     <tbody class="tbody">
      <tr>
       <td>4.1.0</td>
       <td>
        Introduced <var class="varname"><var class="varname">$_SESSION</var></var> that deprecated
        <var class="varname"><var class="varname">$HTTP_SESSION_VARS</var></var>.
       </td>
      </tr>

     </tbody>
    
   </table>

  </p>
 </div>

 
 <div class="refsect1 notes" id="refsect1-reserved.variables.session-notes">
  <h3 class="title">Notes</h3>
  <blockquote class="note"><p><strong class="note">Note</strong>: <p class="para">This is a &#039;superglobal&#039;, or
automatic global, variable. This simply means that it is available in
all scopes throughout a script. There is no need to do
<strong class="command">global $variable;</strong> to access it within functions or methods.
</p></p></blockquote>
 </div>

 
 <div class="refsect1 seealso" id="refsect1-reserved.variables.session-seealso">
  <h3 class="title">See Also</h3>
  <p class="para">
   <ul class="simplelist">
    <li class="member"><span class="function"><a href="function.session-start.php" class="function" rel="rdfs-seeAlso">session_start()</a> - Start new or resume existing session</span></li>
   </ul>
  </p>
 </div>


</div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=reserved.variables.session&amp;redirect=http://php.net/manual/en/reserved.variables.session.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">14 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="113114">  <div class="votes">
    <div id="Vu113114">
    <a href="/manual/vote-note.php?id=113114&amp;page=reserved.variables.session&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113114">
    <a href="/manual/vote-note.php?id=113114&amp;page=reserved.variables.session&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113114" title="54% like this...">
    22
    </div>
  </div>
  <a href="#113114" class="name">
  <strong class="user"><em>opajaap at opajaap dot nl</em></strong></a><a class="genanchor" href="#113114"> &para;</a><div class="date" title="2013-08-31 11:51"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113114">
<div class="phpcode"><code><span class="html">
Be carefull with $_SESSION array elements when you have the same name as a normal global.<br /><br />The following example leads to unpredictable behaviour of the $wppa array elements, some are updated by normal code, some not, it is totally unpredictable what happens.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">global </span><span class="default">$wppa</span><span class="keyword">;<br /></span><span class="default">$wppa </span><span class="keyword">= array( </span><span class="string">'elm1' </span><span class="keyword">=&gt; </span><span class="string">'value1'</span><span class="keyword">, </span><span class="string">'elm2' </span><span class="keyword">=&gt; </span><span class="string">'value2'</span><span class="keyword">, ....</span><span class="default">etc</span><span class="keyword">...);<br /><br />if ( ! </span><span class="default">session_id</span><span class="keyword">() ) @ </span><span class="default">session_start</span><span class="keyword">();<br />if ( ! isset(</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'wppa'</span><span class="keyword">]) </span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'wppa'</span><span class="keyword">] = array();<br /><br />if ( ! isset(</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'wppa'</span><span class="keyword">][</span><span class="string">'album'</span><span class="keyword">]) ) </span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'wppa'</span><span class="keyword">][</span><span class="string">'album'</span><span class="keyword">] = array();<br /></span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'wppa'</span><span class="keyword">][</span><span class="string">'album'</span><span class="keyword">][</span><span class="default">1234</span><span class="keyword">] = </span><span class="default">1</span><span class="keyword">;<br /><br /></span><span class="default">$wppa</span><span class="keyword">[</span><span class="string">'elm1'</span><span class="keyword">] = </span><span class="string">'newvalue1'</span><span class="keyword">;<br /><br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$_SESSION</span><span class="keyword">); <br /></span><span class="default">?&gt;<br /></span>This will most likely display Array ( [wppa] =&gt; Array ( [album] =&gt; Array ( [1234] =&gt; 1 ) [elm1] =&gt; 'newvalue1' [elm2] =&gt; 'value2' ... etc ...<br />But setting $wppa['elm1'] to another value or referring to it gives unpredictable results, maybe 'value1', or 'newvalue1'. <br /><br />The most strange behaviour is that not all elements of $wppa[xx] show up as $_SESSION['wppa'][xx].</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116843">  <div class="votes">
    <div id="Vu116843">
    <a href="/manual/vote-note.php?id=116843&amp;page=reserved.variables.session&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116843">
    <a href="/manual/vote-note.php?id=116843&amp;page=reserved.variables.session&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116843" title="50% like this...">
    6
    </div>
  </div>
  <a href="#116843" class="name">
  <strong class="user"><em>Tugrul</em></strong></a><a class="genanchor" href="#116843"> &para;</a><div class="date" title="2015-03-09 05:04"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom116843">
<div class="phpcode"><code><span class="html">
Creating New Session<br />==========================<br /><span class="default">&lt;?php <br />session_start</span><span class="keyword">();<br /></span><span class="comment">/*session is started if you don't write this line can't use $_Session&nbsp; global variable*/<br /></span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">"newsession"</span><span class="keyword">]=</span><span class="default">$value</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span>Getting Session<br />==========================<br /><span class="default">&lt;?php <br />session_start</span><span class="keyword">();<br /></span><span class="comment">/*session is started if you don't write this line can't use $_Session&nbsp; global variable*/<br /></span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">"newsession"</span><span class="keyword">]=</span><span class="default">$value</span><span class="keyword">;<br /></span><span class="comment">/*session created*/<br /></span><span class="keyword">echo </span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">"newsession"</span><span class="keyword">];<br /></span><span class="comment">/*session was getting*/<br /></span><span class="default">?&gt;<br /></span>Updating Session<br />==========================<br /><span class="default">&lt;?php <br />session_start</span><span class="keyword">();<br /></span><span class="comment">/*session is started if you don't write this line can't use $_Session&nbsp; global variable*/<br /></span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">"newsession"</span><span class="keyword">]=</span><span class="default">$value</span><span class="keyword">;<br /></span><span class="comment">/*it is my new session*/<br /></span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">"newsession"</span><span class="keyword">]=</span><span class="default">$updatedvalue</span><span class="keyword">;<br /></span><span class="comment">/*session updated*/<br /></span><span class="default">?&gt;<br /></span>Deleting Session<br />==========================<br /><span class="default">&lt;?php <br />session_start</span><span class="keyword">();<br /></span><span class="comment">/*session is started if you don't write this line can't use $_Session&nbsp; global variable*/<br /></span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">"newsession"</span><span class="keyword">]=</span><span class="default">$value</span><span class="keyword">;<br />unset(</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">"newsession"</span><span class="keyword">]);<br /></span><span class="comment">/*session deleted. if you try using this you've got an error*/<br /></span><span class="default">?&gt;<br /></span><br />Reference: <a href="http://gencbilgin.net/php-session-kullanimi.html" rel="nofollow" target="_blank">http://gencbilgin.net/php-session-kullanimi.html</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="85448">  <div class="votes">
    <div id="Vu85448">
    <a href="/manual/vote-note.php?id=85448&amp;page=reserved.variables.session&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd85448">
    <a href="/manual/vote-note.php?id=85448&amp;page=reserved.variables.session&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V85448" title="51% like this...">
    5
    </div>
  </div>
  <a href="#85448" class="name">
  <strong class="user"><em>bohwaz</em></strong></a><a class="genanchor" href="#85448"> &para;</a><div class="date" title="2008-08-31 02:43"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom85448">
<div class="phpcode"><code><span class="html">
Please note that if you have register_globals to On, global variables associated to $_SESSION variables are references, so this may lead to some weird situations.<br /><br /><span class="default">&lt;?php<br /><br />session_start</span><span class="keyword">();<br /><br /></span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'test'</span><span class="keyword">] = </span><span class="default">42</span><span class="keyword">;<br /></span><span class="default">$test </span><span class="keyword">= </span><span class="default">43</span><span class="keyword">;<br />echo </span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'test'</span><span class="keyword">];<br /><br /></span><span class="default">?&gt;<br /></span><br />Load the page, OK it displays 42, reload the page... it displays 43.<br /><br />The solution is to do this after each time you do a session_start() :<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">if (</span><span class="default">ini_get</span><span class="keyword">(</span><span class="string">'register_globals'</span><span class="keyword">))<br />{<br />&nbsp; &nbsp; foreach (</span><span class="default">$_SESSION </span><span class="keyword">as </span><span class="default">$key</span><span class="keyword">=&gt;</span><span class="default">$value</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (isset(</span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">]))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; unset(</span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">]);<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121903">  <div class="votes">
    <div id="Vu121903">
    <a href="/manual/vote-note.php?id=121903&amp;page=reserved.variables.session&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121903">
    <a href="/manual/vote-note.php?id=121903&amp;page=reserved.variables.session&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121903" title="50% like this...">
    0
    </div>
  </div>
  <a href="#121903" class="name">
  <strong class="user"><em>dbagnara</em></strong></a><a class="genanchor" href="#121903"> &para;</a><div class="date" title="2017-11-22 06:27"><strong>22 days ago</strong></div>
  <div class="text" id="Hcom121903">
<div class="phpcode"><code><span class="html">
The key of values added to $_SESSION must not be numeric. An error message will be generated and the session will not be saved.<br /><br />"Notice: Unknown: Skipping numeric key 1511374723 in Unknown on line 0"</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119925">  <div class="votes">
    <div id="Vu119925">
    <a href="/manual/vote-note.php?id=119925&amp;page=reserved.variables.session&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119925">
    <a href="/manual/vote-note.php?id=119925&amp;page=reserved.variables.session&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119925" title="46% like this...">
    -3
    </div>
  </div>
  <a href="#119925" class="name">
  <strong class="user"><em>buckmanhands at gmail dot com</em></strong></a><a class="genanchor" href="#119925"> &para;</a><div class="date" title="2016-09-20 10:56"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119925">
<div class="phpcode"><code><span class="html">
If you are using a session variable as a token to use as a handshake on next page load and the token updates on the new page load, but they mysteriously will not match and there is no obvious explanation. I had the following happen and maybe it will save you some time.<br /><br />I was making a form that allowed an image upload and had an image tag ready to drop the src of the preview in after the file was chosen. But I had a preset src of "#"... this loaded the page a second time in the background and updated my token invisibly causing a broken handshake.<br /><br />My tag looked like this:<br /><br />&lt;img src="#" id="myimagepreview" alt="image preview" /&gt;<br /><br />Leave the source blank and the handshake will not break.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="92011">  <div class="votes">
    <div id="Vu92011">
    <a href="/manual/vote-note.php?id=92011&amp;page=reserved.variables.session&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd92011">
    <a href="/manual/vote-note.php?id=92011&amp;page=reserved.variables.session&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V92011" title="45% like this...">
    -12
    </div>
  </div>
  <a href="#92011" class="name">
  <strong class="user"><em>charlese at cvs dot com dot au</em></strong></a><a class="genanchor" href="#92011"> &para;</a><div class="date" title="2009-07-04 06:47"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom92011">
<div class="phpcode"><code><span class="html">
I was having troubles with session variables working in some environments and being seriously flaky in others. I was using $_SESSION as an array. It works properly when I used $_SESSION as pointers to arrays. As an example the following code works in some environments and not others.<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">//Trouble if I treate $form_convert and $_SESSION['form_convert'] as unrelated items<br /></span><span class="default">$form_convert</span><span class="keyword">=array();<br />if (isset(</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'form_convert'</span><span class="keyword">])){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$form_convert</span><span class="keyword">=</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'form_convert'</span><span class="keyword">];<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span>The following works well. <br /><span class="default">&lt;?php<br /></span><span class="keyword">if (isset(</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'form_convert'</span><span class="keyword">])){<br />&nbsp; &nbsp; </span><span class="default">$form_convert </span><span class="keyword">= </span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'form_convert'</span><span class="keyword">];<br />}else{<br />&nbsp; &nbsp; </span><span class="default">$form_convert </span><span class="keyword">= array();<br />&nbsp; &nbsp; </span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'form_convert'</span><span class="keyword">]=</span><span class="default">$form_convert</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="94676">  <div class="votes">
    <div id="Vu94676">
    <a href="/manual/vote-note.php?id=94676&amp;page=reserved.variables.session&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd94676">
    <a href="/manual/vote-note.php?id=94676&amp;page=reserved.variables.session&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V94676" title="44% like this...">
    -12
    </div>
  </div>
  <a href="#94676" class="name">
  <strong class="user"><em>Dave</em></strong></a><a class="genanchor" href="#94676"> &para;</a><div class="date" title="2009-11-17 02:05"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom94676">
<div class="phpcode"><code><span class="html">
If you deploy php code and cannot control whether register_globals is off, place this snippet in your code to prevent session injections:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">if (isset(</span><span class="default">$_REQUEST</span><span class="keyword">[</span><span class="string">'_SESSION'</span><span class="keyword">])) die(</span><span class="string">"Get lost Muppet!"</span><span class="keyword">);<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113163">  <div class="votes">
    <div id="Vu113163">
    <a href="/manual/vote-note.php?id=113163&amp;page=reserved.variables.session&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113163">
    <a href="/manual/vote-note.php?id=113163&amp;page=reserved.variables.session&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113163" title="43% like this...">
    -18
    </div>
  </div>
  <a href="#113163" class="name">
  <strong class="user"><em>Fred</em></strong></a><a class="genanchor" href="#113163"> &para;</a><div class="date" title="2013-09-07 03:09"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113163">
<div class="phpcode"><code><span class="html">
Regarding array keys, from <a href="http://php.net/manual/en/language.types.array.php," rel="nofollow" target="_blank">http://php.net/manual/en/language.types.array.php,</a> "Strings containing valid integers will be cast to the integer type". <br /><br />The manual on $_SESSION says "An associative array". So an associative array is expected literally...? It does no one any good if this bit of important info about accessing and storing session data remains buried in manual comments.<br /><br />Session variables with a single number will not work, however "1a" will work, as will "a1" and even a just single letter, for example "a" will also work.<br /><br />(Invalid)<br />1st page<br /><br /><span class="default">&lt;?php<br />session_start</span><span class="keyword">();<br /></span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">"1"</span><span class="keyword">] = </span><span class="string">"LOGGED"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />2nd page<br /><br /><span class="default">&lt;?php<br />session_start</span><span class="keyword">();<br />echo </span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">"1"</span><span class="keyword">];<br /></span><span class="default">?&gt;<br /></span><br />---------------------------------------------------------------<br /><br />(Valid)<br />1st page<br /><br /><span class="default">&lt;?php<br />session_start</span><span class="keyword">();<br /></span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">"a"</span><span class="keyword">] = </span><span class="string">"LOGGED"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />2nd page<br /><br /><span class="default">&lt;?php<br />session_start</span><span class="keyword">();<br />echo </span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">"a"</span><span class="keyword">];<br /></span><span class="default">?&gt;<br /></span><br />---------------------------------------------------------------<br /><br />(Valid)<br />1st page<br /><br /><span class="default">&lt;?php<br />session_start</span><span class="keyword">();<br /></span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">"a1"</span><span class="keyword">] = </span><span class="string">"LOGGED"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />2nd page<br /><br /><span class="default">&lt;?php<br />session_start</span><span class="keyword">();<br />echo </span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">"a1"</span><span class="keyword">];<br /></span><span class="default">?&gt;<br /></span><br />---------------------------------------------------------------<br /><br />Example from PHP.net manual on Session variables<br /><br /><span class="default">&lt;?php<br />$_SESSION</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">][</span><span class="default">1</span><span class="keyword">] = </span><span class="string">'cake'</span><span class="keyword">; </span><span class="comment">// fails<br /><br /></span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'v1'</span><span class="keyword">][</span><span class="default">2</span><span class="keyword">] = </span><span class="string">'cake'</span><span class="keyword">; </span><span class="comment">// works<br /></span><span class="default">?&gt;<br /></span><br />Source: <a href="http://php.net/manual/en/language.types.array.php" rel="nofollow" target="_blank">http://php.net/manual/en/language.types.array.php</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="112961">  <div class="votes">
    <div id="Vu112961">
    <a href="/manual/vote-note.php?id=112961&amp;page=reserved.variables.session&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd112961">
    <a href="/manual/vote-note.php?id=112961&amp;page=reserved.variables.session&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V112961" title="45% like this...">
    -20
    </div>
  </div>
  <a href="#112961" class="name">
  <strong class="user"><em>Miller</em></strong></a><a class="genanchor" href="#112961"> &para;</a><div class="date" title="2013-08-12 08:48"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom112961">
<div class="phpcode"><code><span class="html">
I wrote a little page for controlling/manipulating the session. Obviously, never use this on a production server, but I use it on my localhost to assist me in checking and changing session values on the fly.<br /><br />Again, it makes use of eval() and exposes the session, so never use this on a web server.<br /><br /><span class="default">&lt;?php<br />error_reporting</span><span class="keyword">(</span><span class="default">E_ALL</span><span class="keyword">);<br /></span><span class="default">session_start</span><span class="keyword">();<br />if (isset(</span><span class="default">$_POST</span><span class="keyword">[</span><span class="string">'session'</span><span class="keyword">])) {<br />&nbsp; &nbsp; </span><span class="default">$session </span><span class="keyword">= eval(</span><span class="string">"return </span><span class="keyword">{</span><span class="default">$_POST</span><span class="keyword">[</span><span class="string">'session'</span><span class="keyword">]}</span><span class="string">;"</span><span class="keyword">);<br />&nbsp; &nbsp; if (</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$session</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$_SESSION </span><span class="keyword">= </span><span class="default">$session</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">"Location: </span><span class="keyword">{</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_SELF'</span><span class="keyword">]}</span><span class="string">?saved"</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; else {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">"Location: </span><span class="keyword">{</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_SELF'</span><span class="keyword">]}</span><span class="string">?error"</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$session </span><span class="keyword">= </span><span class="default">htmlentities</span><span class="keyword">(</span><span class="default">var_export</span><span class="keyword">(</span><span class="default">$_SESSION</span><span class="keyword">, </span><span class="default">true</span><span class="keyword">));<br /></span><span class="default">?&gt;<br /></span>&lt;!DOCTYPE html&gt;<br />&lt;html lang="en-US"&gt;<br />&nbsp; &nbsp; &lt;head&gt;<br />&nbsp; &nbsp; &nbsp; &nbsp; &lt;meta charset="UTF-8"&gt;<br />&nbsp; &nbsp; &nbsp; &nbsp; &lt;title&gt;Session Variable Management&lt;/title&gt;<br />&nbsp; &nbsp; &nbsp; &nbsp; &lt;style&gt;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; textarea { font: 12px Consolas, Monaco, monospace; padding: 2px; border: 1px solid #444444; width: 99%; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; .saved, .error { border: 1px solid #509151; background: #DDF0DD; padding: 2px; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; .error { border-color: #915050; background: #F0DDDD; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &lt;/style&gt;<br />&nbsp; &nbsp; &lt;/head&gt;<br />&nbsp; &nbsp; &lt;body&gt;<br />&nbsp; &nbsp; &nbsp; &nbsp; &lt;h1&gt;Session Variable Management&lt;/h1&gt;<br /><span class="default">&lt;?php </span><span class="keyword">if (isset(</span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">'saved'</span><span class="keyword">])) { </span><span class="default">?&gt;<br /></span>&nbsp; &nbsp; &nbsp; &nbsp; &lt;p class="saved"&gt;The session was saved successfully.&lt;/p&gt;<br /><span class="default">&lt;?php </span><span class="keyword">} else if (isset(</span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">'error'</span><span class="keyword">])) { </span><span class="default">?&gt;<br /></span>&nbsp; &nbsp; &nbsp; &nbsp; &lt;p class="error"&gt;The session variable did not parse correctly.&lt;/p&gt;<br /><span class="default">&lt;?php </span><span class="keyword">} </span><span class="default">?&gt;<br /></span>&nbsp; &nbsp; &nbsp; &nbsp; &lt;form method="post"&gt;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &lt;textarea name="session" rows="<span class="default">&lt;?php </span><span class="keyword">echo </span><span class="default">count</span><span class="keyword">(</span><span class="default">preg_split</span><span class="keyword">(</span><span class="string">"/\n|\r/"</span><span class="keyword">, </span><span class="default">$session</span><span class="keyword">)); </span><span class="default">?&gt;</span>"&gt;<span class="default">&lt;?php </span><span class="keyword">echo </span><span class="default">$session</span><span class="keyword">; </span><span class="default">?&gt;</span>&lt;/textarea&gt;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &lt;input type="submit" value="Update Session"&gt;<br />&nbsp; &nbsp; &nbsp; &nbsp; &lt;/form&gt;<br />&nbsp; &nbsp; &lt;/body&gt;<br />&lt;/html&gt;</span>
</code></div>
  </div>
 </div>
  <div class="note" id="84852">  <div class="votes">
    <div id="Vu84852">
    <a href="/manual/vote-note.php?id=84852&amp;page=reserved.variables.session&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd84852">
    <a href="/manual/vote-note.php?id=84852&amp;page=reserved.variables.session&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V84852" title="40% like this...">
    -19
    </div>
  </div>
  <a href="#84852" class="name">
  <strong class="user"><em>jherry at netcourrier dot com</em></strong></a><a class="genanchor" href="#84852"> &para;</a><div class="date" title="2008-08-01 04:16"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom84852">
<div class="phpcode"><code><span class="html">
You may have trouble if you use '|' in the key:<br /><br />$_SESSION["foo|bar"] = "fuzzy";<br /><br />This does not work for me. I think it's because the serialisation of session object is using this char so the server reset your session when it cannot read it.<br /><br />To make it work I replaced '|' by '_'.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121018">  <div class="votes">
    <div id="Vu121018">
    <a href="/manual/vote-note.php?id=121018&amp;page=reserved.variables.session&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121018">
    <a href="/manual/vote-note.php?id=121018&amp;page=reserved.variables.session&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121018" title="27% like this...">
    -8
    </div>
  </div>
  <a href="#121018" class="name">
  <strong class="user"><em>ignasitort at gmail dot com</em></strong></a><a class="genanchor" href="#121018"> &para;</a><div class="date" title="2017-04-25 08:07"><strong>7 months ago</strong></div>
  <div class="text" id="Hcom121018">
<div class="phpcode"><code><span class="html">
I have a weird problem, when using $_SESSION&nbsp; to store&nbsp; a nonce. My nonces never match.<br />Maybe the PHP code is called twice (maybe is WP or maybe is the BROWSER) but Html is rendered with the first NONCE value, but as random nonce&nbsp; are created twice, returning PHP function (called by Javascript AJAX ) checks for the second value. As far , as I can not solve <br />My solution is:&nbsp; always check first if the NONCE exist before creating a new random value for the nonce. This way nonce cannot&nbsp; change if PHP called twice.<br /><br /><span class="default">&lt;?PHP<br /><br /> </span><span class="keyword">if (isset(</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'nonce'</span><span class="keyword">]) &amp;&amp; !empty(</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'nonce'</span><span class="keyword">])){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">error_log</span><span class="keyword">(</span><span class="string">"NONCE_ NOT EMPTY"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'nonce'</span><span class="keyword">] =&nbsp; </span><span class="default">function_rand_str</span><span class="keyword">(</span><span class="default">32</span><span class="keyword">); <br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="85147">  <div class="votes">
    <div id="Vu85147">
    <a href="/manual/vote-note.php?id=85147&amp;page=reserved.variables.session&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd85147">
    <a href="/manual/vote-note.php?id=85147&amp;page=reserved.variables.session&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V85147" title="37% like this...">
    -22
    </div>
  </div>
  <a href="#85147" class="name">
  <strong class="user"><em>Steve Clay</em></strong></a><a class="genanchor" href="#85147"> &para;</a><div class="date" title="2008-08-17 06:28"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom85147">
<div class="phpcode"><code><span class="html">
Unlike a real PHP array, $_SESSION keys at the root level must be valid variable names.<br /><br /><span class="default">&lt;?php <br />$_SESSION</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">][</span><span class="default">1</span><span class="keyword">] = </span><span class="string">'cake'</span><span class="keyword">; </span><span class="comment">// fails<br /><br /></span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'v1'</span><span class="keyword">][</span><span class="default">1</span><span class="keyword">] = </span><span class="string">'cake'</span><span class="keyword">; </span><span class="comment">// works<br /></span><span class="default">?&gt;<br /></span><br />I imagine this is an internal limitation having to do with the legacy function session_register(), where the registered global var must similarly have a valid name.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="102295">  <div class="votes">
    <div id="Vu102295">
    <a href="/manual/vote-note.php?id=102295&amp;page=reserved.variables.session&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd102295">
    <a href="/manual/vote-note.php?id=102295&amp;page=reserved.variables.session&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V102295" title="39% like this...">
    -27
    </div>
  </div>
  <a href="#102295" class="name">
  <strong class="user"><em>pike-php at kw dot nl</em></strong></a><a class="genanchor" href="#102295"> &para;</a><div class="date" title="2011-02-07 06:00"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom102295">
<div class="phpcode"><code><span class="html">
When accidently assigning a unset variable to $_SESSION, like <br /><br />&nbsp;&nbsp; $_SESSION['foo'] = $bar <br /><br />while $bar was not defined, I got the following error message:<br /><br />"Warning: Unknown(): Your script possibly relies on a session side-effect which existed until PHP 4.2.3. Please be advised that the session extension does not consider global variables as a source of data, unless register_globals is enabled. "<br /><br />The errormessage was quite unrelated and got me off-track. The real error was, $bar was not defined.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120400">  <div class="votes">
    <div id="Vu120400">
    <a href="/manual/vote-note.php?id=120400&amp;page=reserved.variables.session&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120400">
    <a href="/manual/vote-note.php?id=120400&amp;page=reserved.variables.session&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120400" title="22% like this...">
    -26
    </div>
  </div>
  <a href="#120400" class="name">
  <strong class="user"><em>Nitin Sharma</em></strong></a><a class="genanchor" href="#120400"> &para;</a><div class="date" title="2017-01-02 10:42"><strong>11 months ago</strong></div>
  <div class="text" id="Hcom120400">
<div class="phpcode"><code><span class="html">
This is the code for session.php but it is not working properly. I have three field in my database log_id,user_email,user_pass. and when I want to login into my website it does not works. I've some issues with session creation.<br />if you could help me please go ahed.<br /><span class="default">&lt;?php<br />&nbsp; &nbsp; $dbhost&nbsp; &nbsp;&nbsp; </span><span class="keyword">= </span><span class="string">"localhost"</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$dbname&nbsp; &nbsp;&nbsp; </span><span class="keyword">= </span><span class="string">"new"</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$dbuser&nbsp; &nbsp;&nbsp; </span><span class="keyword">= </span><span class="string">"root"</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$dbpass&nbsp; &nbsp;&nbsp; </span><span class="keyword">= </span><span class="string">""</span><span class="keyword">;<br /><br />&nbsp; &nbsp; </span><span class="default">$conn </span><span class="keyword">= new </span><span class="default">PDO</span><span class="keyword">(</span><span class="string">"mysql:host=</span><span class="default">$dbhost</span><span class="string">;dbname=</span><span class="default">$dbname</span><span class="string">"</span><span class="keyword">, </span><span class="default">$dbuser</span><span class="keyword">, </span><span class="default">$dbpass</span><span class="keyword">);<br /><br />&nbsp; &nbsp; </span><span class="default">session_start</span><span class="keyword">();<br />&nbsp; &nbsp; </span><span class="default">$user_check</span><span class="keyword">=</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'login_user'</span><span class="keyword">];<br />&nbsp; &nbsp; </span><span class="default">$result </span><span class="keyword">= </span><span class="default">$conn</span><span class="keyword">-&gt;</span><span class="default">prepare</span><span class="keyword">(</span><span class="string">"SELECT * FROM login WHERE user_email = :user_check"</span><span class="keyword">);&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="default">$result</span><span class="keyword">-&gt;</span><span class="default">execute</span><span class="keyword">(array(</span><span class="string">":usercheck"</span><span class="keyword">=&gt;</span><span class="default">$user_check</span><span class="keyword">));<br /><br />&nbsp; &nbsp; </span><span class="default">$row </span><span class="keyword">= </span><span class="default">$result</span><span class="keyword">-&gt;</span><span class="default">fetch</span><span class="keyword">(</span><span class="default">PDO</span><span class="keyword">::</span><span class="default">FETCH_ASSOC</span><span class="keyword">);<br /><br />&nbsp; &nbsp; </span><span class="default">$login_session </span><span class="keyword">=</span><span class="default">$row</span><span class="keyword">[</span><span class="string">'user_email'</span><span class="keyword">];<br />&nbsp; &nbsp; </span><span class="default">$user_id </span><span class="keyword">=</span><span class="default">$row</span><span class="keyword">[</span><span class="string">'log_id'</span><span class="keyword">];<br />&nbsp; &nbsp; </span><span class="default">$user_passwords </span><span class="keyword">= </span><span class="default">$row</span><span class="keyword">[</span><span class="string">'user_pass'</span><span class="keyword">];<br /><br />&nbsp; &nbsp; if(!isset(</span><span class="default">$login_session</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$conn </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">'Location: www.fb.com'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=reserved.variables.session&amp;redirect=http://php.net/manual/en/reserved.variables.session.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="reserved.variables.php">Predefined Variables</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.variables.superglobals.php" title="Superglobals">Superglobals</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.globals.php" title="$GLOBALS">$GLOBALS</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.server.php" title="$_&#8203;SERVER">$_&#8203;SERVER</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.get.php" title="$_&#8203;GET">$_&#8203;GET</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.post.php" title="$_&#8203;POST">$_&#8203;POST</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.files.php" title="$_&#8203;FILES">$_&#8203;FILES</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.request.php" title="$_&#8203;REQUEST">$_&#8203;REQUEST</a>
                        </li>
                          
                        <li class="current">
                            <a href="reserved.variables.session.php" title="$_&#8203;SESSION">$_&#8203;SESSION</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.environment.php" title="$_&#8203;ENV">$_&#8203;ENV</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.cookies.php" title="$_&#8203;COOKIE">$_&#8203;COOKIE</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.phperrormsg.php" title="$php_&#8203;errormsg">$php_&#8203;errormsg</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.httprawpostdata.php" title="$HTTP_&#8203;RAW_&#8203;POST_&#8203;DATA">$HTTP_&#8203;RAW_&#8203;POST_&#8203;DATA</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.httpresponseheader.php" title="$http_&#8203;response_&#8203;header">$http_&#8203;response_&#8203;header</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.argc.php" title="$argc">$argc</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.argv.php" title="$argv">$argv</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

