<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Error Control Operators - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.operators.errorcontrol.php">
 <link rel="shorturl" href="http://php.net/operators.errorcontrol">
 <link rel="alternate" href="http://php.net/operators.errorcontrol" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.operators.php">
 <link rel="prev" href="http://php.net/manual/en/language.operators.comparison.php">
 <link rel="next" href="http://php.net/manual/en/language.operators.execution.php">

 <link rel="alternate" href="http://php.net/manual/en/language.operators.errorcontrol.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.operators.errorcontrol.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.operators.errorcontrol.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.operators.errorcontrol.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.operators.errorcontrol.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.operators.errorcontrol.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.operators.errorcontrol.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.operators.errorcontrol.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.operators.errorcontrol.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.operators.errorcontrol.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.operators.errorcontrol.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.operators.execution.php">
          Execution Operators &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.operators.comparison.php">
          &laquo; Comparison Operators        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.operators.php'>Operators</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.operators.errorcontrol.php' selected="selected">English</option>
            <option value='pt_BR/language.operators.errorcontrol.php'>Brazilian Portuguese</option>
            <option value='zh/language.operators.errorcontrol.php'>Chinese (Simplified)</option>
            <option value='fr/language.operators.errorcontrol.php'>French</option>
            <option value='de/language.operators.errorcontrol.php'>German</option>
            <option value='ja/language.operators.errorcontrol.php'>Japanese</option>
            <option value='ro/language.operators.errorcontrol.php'>Romanian</option>
            <option value='ru/language.operators.errorcontrol.php'>Russian</option>
            <option value='es/language.operators.errorcontrol.php'>Spanish</option>
            <option value='tr/language.operators.errorcontrol.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.operators.errorcontrol.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.operators.errorcontrol">Report a Bug</a>
    </div>
  </div><div id="language.operators.errorcontrol" class="sect1">
   <h2 class="title">Error Control Operators</h2>
   <p class="simpara">
    PHP supports one error control operator: the at sign (@). When
    prepended to an expression in PHP, any error messages that might
    be generated by that expression will be ignored.
   </p>
   <p class="simpara">
    If you have set a custom error handler function with
    <span class="function"><a href="function.set-error-handler.php" class="function">set_error_handler()</a></span> then it will still get
    called, but this custom error handler can (and should) call <span class="function"><a href="function.error-reporting.php" class="function">error_reporting()</a></span>
    which will return 0 when the call that triggered the error was preceded by an @.
   </p>
   <p class="simpara">
    If the <a href="errorfunc.configuration.php#ini.track-errors" class="link"><strong class="option unknown">track_errors</strong>
</a>
    feature is enabled, any error message generated by the expression
    will be saved in the variable
    <var class="varname"><var class="varname"><a href="reserved.variables.phperrormsg.php" class="classname">$php_errormsg</a></var></var>.
    This variable will be overwritten on each error, so check early if you
    want to use it.
   </p>
   <p class="para">
    <div class="informalexample">
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #FF8000">/*&nbsp;Intentional&nbsp;file&nbsp;error&nbsp;*/<br /></span><span style="color: #0000BB">$my_file&nbsp;</span><span style="color: #007700">=&nbsp;@</span><span style="color: #0000BB">file&nbsp;</span><span style="color: #007700">(</span><span style="color: #DD0000">'non_existent_file'</span><span style="color: #007700">)&nbsp;or<br />&nbsp;&nbsp;&nbsp;&nbsp;die&nbsp;(</span><span style="color: #DD0000">"Failed&nbsp;opening&nbsp;file:&nbsp;error&nbsp;was&nbsp;'</span><span style="color: #0000BB">$php_errormsg</span><span style="color: #DD0000">'"</span><span style="color: #007700">);<br /><br /></span><span style="color: #FF8000">//&nbsp;this&nbsp;works&nbsp;for&nbsp;any&nbsp;expression,&nbsp;not&nbsp;just&nbsp;functions:<br /></span><span style="color: #0000BB">$value&nbsp;</span><span style="color: #007700">=&nbsp;@</span><span style="color: #0000BB">$cache</span><span style="color: #007700">[</span><span style="color: #0000BB">$key</span><span style="color: #007700">];<br /></span><span style="color: #FF8000">//&nbsp;will&nbsp;not&nbsp;issue&nbsp;a&nbsp;notice&nbsp;if&nbsp;the&nbsp;index&nbsp;$key&nbsp;doesn't&nbsp;exist.<br /><br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>
   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <span class="simpara">
     The @-operator works only on
     <a href="language.expressions.php" class="link">expressions</a>. A simple rule
     of thumb is: if you can take the value of something, you can prepend
     the @ operator to it. For instance, you can prepend it to variables,
     function and <span class="function"><a href="function.include.php" class="function">include</a></span> calls, constants, and
     so forth. You cannot prepend it to function or class definitions,
     or conditional structures such as <em>if</em> and
     <a href="control-structures.foreach.php" class="link">foreach</a>, and so forth.
    </span>
   </p></blockquote>
   <p class="simpara">
    See also <span class="function"><a href="function.error-reporting.php" class="function">error_reporting()</a></span> and the manual section for
    <a href="ref.errorfunc.php" class="link">Error Handling and Logging functions</a>.
   </p>
   <div class="warning"><strong class="warning">Warning</strong>
    <p class="para">
     Currently the &quot;@&quot; error-control operator prefix will even disable
     error reporting for critical errors that will terminate script
     execution. Among other things, this means that if you use &quot;@&quot; to
     suppress errors from a certain function and either it isn&#039;t
     available or has been mistyped, the script will die right there
     with no indication as to why.
    </p>
   </div>
  </div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.operators.errorcontrol&amp;redirect=http://php.net/manual/en/language.operators.errorcontrol.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">18 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="112900">  <div class="votes">
    <div id="Vu112900">
    <a href="/manual/vote-note.php?id=112900&amp;page=language.operators.errorcontrol&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd112900">
    <a href="/manual/vote-note.php?id=112900&amp;page=language.operators.errorcontrol&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V112900" title="93% like this...">
    735
    </div>
  </div>
  <a href="#112900" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#112900"> &para;</a><div class="date" title="2013-08-05 01:05"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom112900">
<div class="phpcode"><code><span class="html">
This operator is affectionately known by veteran phpers as the stfu operator.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="85042">  <div class="votes">
    <div id="Vu85042">
    <a href="/manual/vote-note.php?id=85042&amp;page=language.operators.errorcontrol&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd85042">
    <a href="/manual/vote-note.php?id=85042&amp;page=language.operators.errorcontrol&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V85042" title="82% like this...">
    108
    </div>
  </div>
  <a href="#85042" class="name">
  <strong class="user"><em>taras dot dot dot di at gmail dot com</em></strong></a><a class="genanchor" href="#85042"> &para;</a><div class="date" title="2008-08-12 08:29"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom85042">
<div class="phpcode"><code><span class="html">
I was confused as to what the @ symbol actually does, and after a few experiments have concluded the following:<br /><br />* the error handler that is set gets called regardless of what level the error reporting is set on, or whether the statement is preceeded with @<br /><br />* it is up to the error handler to impart some meaning on the different error levels. You could make your custom error handler echo all errors, even if error reporting is set to NONE.<br /><br />* so what does the @ operator do? It temporarily sets the error reporting level to 0 for that line. If that line triggers an error, the error handler will still be called, but it will be called with an error level of 0<br /><br />Hope this helps someone</span>
</code></div>
  </div>
 </div>
  <div class="note" id="94004">  <div class="votes">
    <div id="Vu94004">
    <a href="/manual/vote-note.php?id=94004&amp;page=language.operators.errorcontrol&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd94004">
    <a href="/manual/vote-note.php?id=94004&amp;page=language.operators.errorcontrol&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V94004" title="81% like this...">
    80
    </div>
  </div>
  <a href="#94004" class="name">
  <strong class="user"><em>M. T.</em></strong></a><a class="genanchor" href="#94004"> &para;</a><div class="date" title="2009-10-11 09:20"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom94004">
<div class="phpcode"><code><span class="html">
Be aware of using error control operator in statements before include() like this:<br /><br /><span class="default">&lt;?PHP<br /><br /></span><span class="keyword">(@include(</span><span class="string">"file.php"</span><span class="keyword">))<br /> OR die(</span><span class="string">"Could not find file.php!"</span><span class="keyword">);<br /><br /></span><span class="default">?&gt;<br /></span><br />This cause, that error reporting level is set to zero also for the included file. So if there are some errors in the included file, they will be not displayed.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="102543">  <div class="votes">
    <div id="Vu102543">
    <a href="/manual/vote-note.php?id=102543&amp;page=language.operators.errorcontrol&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd102543">
    <a href="/manual/vote-note.php?id=102543&amp;page=language.operators.errorcontrol&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V102543" title="76% like this...">
    39
    </div>
  </div>
  <a href="#102543" class="name">
  <strong class="user"><em>anthon at piwik dot org</em></strong></a><a class="genanchor" href="#102543"> &para;</a><div class="date" title="2011-02-20 12:39"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom102543">
<div class="phpcode"><code><span class="html">
If you're wondering what the performance impact of using the @ operator is, consider this example.&nbsp; Here, the second script (using the @ operator) takes 1.75x as long to execute...almost double the time of the first script.<br /><br />So while yes, there is some overhead, per iteration, we see that the @ operator added only .005 ms per call.&nbsp; Not reason enough, imho, to avoid using the @ operator.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">x</span><span class="keyword">() { }<br />for (</span><span class="default">$i </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">; </span><span class="default">$i </span><span class="keyword">&lt; </span><span class="default">1000000</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">++) { </span><span class="default">x</span><span class="keyword">(); }<br /></span><span class="default">?&gt;<br /></span><br />real&nbsp; &nbsp; 0m7.617s<br />user&nbsp; &nbsp; 0m6.788s<br />sys&nbsp; &nbsp; 0m0.792s<br /><br />vs<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">x</span><span class="keyword">() { }<br />for (</span><span class="default">$i </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">; </span><span class="default">$i </span><span class="keyword">&lt; </span><span class="default">1000000</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">++) { @</span><span class="default">x</span><span class="keyword">(); }<br /></span><span class="default">?&gt;<br /></span><br />real&nbsp; &nbsp; 0m13.333s<br />user&nbsp; &nbsp; 0m12.437s<br />sys&nbsp; &nbsp; 0m0.836s</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119693">  <div class="votes">
    <div id="Vu119693">
    <a href="/manual/vote-note.php?id=119693&amp;page=language.operators.errorcontrol&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119693">
    <a href="/manual/vote-note.php?id=119693&amp;page=language.operators.errorcontrol&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119693" title="76% like this...">
    7
    </div>
  </div>
  <a href="#119693" class="name">
  <strong class="user"><em>dkellner</em></strong></a><a class="genanchor" href="#119693"> &para;</a><div class="date" title="2016-08-04 10:21"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119693">
<div class="phpcode"><code><span class="html">
There is no reason to NOT use something just because "it can be misused".&nbsp; You could as well say "unlink is evil, you can delete files with it so don't ever use unlink".<br /><br />It's a valid point that the @ operator hides all errors - so my rule of thumb is: use it only if you're aware of all possible errors your expression can throw AND you consider all of them irrelevant.<br /><br />A simple example is<br /><span class="default">&lt;?php<br /><br />&nbsp; &nbsp; $x </span><span class="keyword">= @</span><span class="default">$a</span><span class="keyword">[</span><span class="string">"name"</span><span class="keyword">];<br /><br /></span><span class="default">?&gt;<br /></span>There are only 2 possible problems here: a missing variable or a missing index.&nbsp; If you're sure you're fine with both cases, you're good to go.&nbsp; And again: suppressing errors is not a crime.&nbsp; Not knowing when it's safe to suppress them is definitely worse.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="90987">  <div class="votes">
    <div id="Vu90987">
    <a href="/manual/vote-note.php?id=90987&amp;page=language.operators.errorcontrol&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd90987">
    <a href="/manual/vote-note.php?id=90987&amp;page=language.operators.errorcontrol&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V90987" title="76% like this...">
    39
    </div>
  </div>
  <a href="#90987" class="name">
  <strong class="user"><em>gerrywastaken</em></strong></a><a class="genanchor" href="#90987"> &para;</a><div class="date" title="2009-05-19 01:46"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom90987">
<div class="phpcode"><code><span class="html">
Error suppression should be avoided if possible as it doesn't just suppress the error that you are trying to stop, but will also suppress errors that you didn't predict would ever occur. This will make debugging a nightmare.<br /><br />It is far better to test for the condition that you know will cause an error before preceding to run the code. This way only the error that you know about will be suppressed and not all future errors associated with that piece of code.<br /><br />There may be a good reason for using outright error suppression in favor of the method I have suggested, however in the many years I've spent programming web apps I've yet to come across a situation where it was a good solution. The examples given on this manual page are certainly not situations where the error control operator should be used.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="98895">  <div class="votes">
    <div id="Vu98895">
    <a href="/manual/vote-note.php?id=98895&amp;page=language.operators.errorcontrol&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd98895">
    <a href="/manual/vote-note.php?id=98895&amp;page=language.operators.errorcontrol&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V98895" title="71% like this...">
    12
    </div>
  </div>
  <a href="#98895" class="name">
  <strong class="user"><em>darren at powerssa dot com</em></strong></a><a class="genanchor" href="#98895"> &para;</a><div class="date" title="2010-07-14 09:33"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom98895">
<div class="phpcode"><code><span class="html">
After some time investigating as to why I was still getting errors that were supposed to be suppressed with @ I found the following.<br /><br />1. If you have set your own default error handler then the error still gets sent to the error handler regardless of the @ sign.<br /><br />2. As mentioned below the @ suppression only changes the error level for that call. This is not to say that in your error handler you can check the given $errno for a value of 0 as the $errno will still refer to the TYPE(not the error level) of error e.g. E_WARNING or E_ERROR etc<br /><br />3. The @ only changes the rumtime error reporting level just for that one call to 0. This means inside your custom error handler you can check the current runtime error_reporting level using error_reporting() (note that one must NOT pass any parameter to this function if you want to get the current value) and if its zero then you know that it has been suppressed.<br /><span class="default">&lt;?php<br /></span><span class="comment">// Custom error handler<br /></span><span class="keyword">function </span><span class="default">myErrorHandler</span><span class="keyword">(</span><span class="default">$errno</span><span class="keyword">, </span><span class="default">$errstr</span><span class="keyword">, </span><span class="default">$errfile</span><span class="keyword">, </span><span class="default">$errline</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; if ( </span><span class="default">0 </span><span class="keyword">== </span><span class="default">error_reporting </span><span class="keyword">() ) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Error reporting is currently turned off or suppressed with @<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">return;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; </span><span class="comment">// Do your normal custom error reporting here<br /></span><span class="keyword">}<br /></span><span class="default">?&gt;<br /></span><br />For more info on setting a custom error handler see: <a href="http://php.net/manual/en/function.set-error-handler.php" rel="nofollow" target="_blank">http://php.net/manual/en/function.set-error-handler.php</a><br />For more info on error_reporting see: <a href="http://www.php.net/manual/en/function.error-reporting.php" rel="nofollow" target="_blank">http://www.php.net/manual/en/function.error-reporting.php</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="70375">  <div class="votes">
    <div id="Vu70375">
    <a href="/manual/vote-note.php?id=70375&amp;page=language.operators.errorcontrol&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd70375">
    <a href="/manual/vote-note.php?id=70375&amp;page=language.operators.errorcontrol&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V70375" title="71% like this...">
    12
    </div>
  </div>
  <a href="#70375" class="name">
  <strong class="user"><em>programming at kennebel dot com</em></strong></a><a class="genanchor" href="#70375"> &para;</a><div class="date" title="2006-10-13 06:38"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom70375">
<div class="phpcode"><code><span class="html">
To suppress errors for a new class/object:<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">// Tested: PHP 5.1.2 ~ 2006-10-13<br /><br />// Typical Example<br /></span><span class="default">$var </span><span class="keyword">= @</span><span class="default">some_function</span><span class="keyword">();<br /><br /></span><span class="comment">// Class/Object Example<br /></span><span class="default">$var </span><span class="keyword">= @new </span><span class="default">some_class</span><span class="keyword">();<br /><br /></span><span class="comment">// Does NOT Work!<br />//$var = new @some_class(); // syntax error<br /></span><span class="default">?&gt;<br /></span><br />I found this most useful when connecting to a<br />database, where i wanted to control the errors<br />and warnings displayed to the client, while still<br />using the class style of access.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="99805">  <div class="votes">
    <div id="Vu99805">
    <a href="/manual/vote-note.php?id=99805&amp;page=language.operators.errorcontrol&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd99805">
    <a href="/manual/vote-note.php?id=99805&amp;page=language.operators.errorcontrol&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V99805" title="69% like this...">
    19
    </div>
  </div>
  <a href="#99805" class="name">
  <strong class="user"><em>auser at anexample dot com</em></strong></a><a class="genanchor" href="#99805"> &para;</a><div class="date" title="2010-09-08 04:02"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom99805">
<div class="phpcode"><code><span class="html">
Be aware that using @ is dog-slow, as PHP incurs overhead to suppressing errors in this way. It's a trade-off between speed and convenience.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="48491">  <div class="votes">
    <div id="Vu48491">
    <a href="/manual/vote-note.php?id=48491&amp;page=language.operators.errorcontrol&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd48491">
    <a href="/manual/vote-note.php?id=48491&amp;page=language.operators.errorcontrol&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V48491" title="66% like this...">
    8
    </div>
  </div>
  <a href="#48491" class="name">
  <strong class="user"><em>frogger at netsurf dot de</em></strong></a><a class="genanchor" href="#48491"> &para;</a><div class="date" title="2004-12-26 08:19"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom48491">
<div class="phpcode"><code><span class="html">
Better use the function trigger_error() (<a href="http://de.php.net/manual/en/function.trigger-error.php" rel="nofollow" target="_blank">http://de.php.net/manual/en/function.trigger-error.php</a>)<br />to display defined notices, warnings and errors than check the error level your self. this lets you write messages to logfiles if defined in the php.ini, output<br />messages in dependency to the error_reporting() level and suppress output using the @-sign.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="104545">  <div class="votes">
    <div id="Vu104545">
    <a href="/manual/vote-note.php?id=104545&amp;page=language.operators.errorcontrol&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd104545">
    <a href="/manual/vote-note.php?id=104545&amp;page=language.operators.errorcontrol&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V104545" title="64% like this...">
    10
    </div>
  </div>
  <a href="#104545" class="name">
  <strong class="user"><em>bohwaz</em></strong></a><a class="genanchor" href="#104545"> &para;</a><div class="date" title="2011-06-22 06:27"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom104545">
<div class="phpcode"><code><span class="html">
If you use the ErrorException exception to have a unified error management, I'll advise you to test against error_reporting in the error handler, not in the exception handler as you might encounter some headaches like blank pages as error_reporting might not be transmitted to exception handler.<br /><br />So instead of :<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">exception_error_handler</span><span class="keyword">(</span><span class="default">$errno</span><span class="keyword">, </span><span class="default">$errstr</span><span class="keyword">, </span><span class="default">$errfile</span><span class="keyword">, </span><span class="default">$errline </span><span class="keyword">)<br />{<br />&nbsp; &nbsp; throw new </span><span class="default">ErrorException</span><span class="keyword">(</span><span class="default">$errstr</span><span class="keyword">, </span><span class="default">0</span><span class="keyword">, </span><span class="default">$errno</span><span class="keyword">, </span><span class="default">$errfile</span><span class="keyword">, </span><span class="default">$errline</span><span class="keyword">);<br />}<br /><br /></span><span class="default">set_error_handler</span><span class="keyword">(</span><span class="string">"exception_error_handler"</span><span class="keyword">);<br /><br />function </span><span class="default">catchException</span><span class="keyword">(</span><span class="default">$e</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; if (</span><span class="default">error_reporting</span><span class="keyword">() === </span><span class="default">0</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">// Do some stuff<br /></span><span class="keyword">}<br /><br /></span><span class="default">set_exception_handler</span><span class="keyword">(</span><span class="string">'catchException'</span><span class="keyword">);<br /><br /></span><span class="default">?&gt;<br /></span><br />It would be better to do :<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">exception_error_handler</span><span class="keyword">(</span><span class="default">$errno</span><span class="keyword">, </span><span class="default">$errstr</span><span class="keyword">, </span><span class="default">$errfile</span><span class="keyword">, </span><span class="default">$errline </span><span class="keyword">)<br />{<br />&nbsp; &nbsp; if (</span><span class="default">error_reporting</span><span class="keyword">() === </span><span class="default">0</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; throw new </span><span class="default">ErrorException</span><span class="keyword">(</span><span class="default">$errstr</span><span class="keyword">, </span><span class="default">0</span><span class="keyword">, </span><span class="default">$errno</span><span class="keyword">, </span><span class="default">$errfile</span><span class="keyword">, </span><span class="default">$errline</span><span class="keyword">);<br />}<br /><br /></span><span class="default">set_error_handler</span><span class="keyword">(</span><span class="string">"exception_error_handler"</span><span class="keyword">);<br /><br />function </span><span class="default">catchException</span><span class="keyword">(</span><span class="default">$e</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="comment">// Do some stuff<br /></span><span class="keyword">}<br /><br /></span><span class="default">set_exception_handler</span><span class="keyword">(</span><span class="string">'catchException'</span><span class="keyword">);<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="115899">  <div class="votes">
    <div id="Vu115899">
    <a href="/manual/vote-note.php?id=115899&amp;page=language.operators.errorcontrol&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115899">
    <a href="/manual/vote-note.php?id=115899&amp;page=language.operators.errorcontrol&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115899" title="58% like this...">
    5
    </div>
  </div>
  <a href="#115899" class="name">
  <strong class="user"><em>manisha at mindfiresolutions dot com</em></strong></a><a class="genanchor" href="#115899"> &para;</a><div class="date" title="2014-10-11 09:25"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115899">
<div class="phpcode"><code><span class="html">
Prepending @ before statement like you are doing a crime with yourself.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120767">  <div class="votes">
    <div id="Vu120767">
    <a href="/manual/vote-note.php?id=120767&amp;page=language.operators.errorcontrol&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120767">
    <a href="/manual/vote-note.php?id=120767&amp;page=language.operators.errorcontrol&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120767" title="100% like this...">
    1
    </div>
  </div>
  <a href="#120767" class="name">
  <strong class="user"><em>ricovox</em></strong></a><a class="genanchor" href="#120767"> &para;</a><div class="date" title="2017-03-07 05:29"><strong>9 months ago</strong></div>
  <div class="text" id="Hcom120767">
<div class="phpcode"><code><span class="html">
What is PHP's behavior for a variable that is assigned the return value of an expression protected by the Error Control Operator when the expression encounteres an error? <br /><br />Based on the following code, the result is NULL (but it would be nice if this were confirmed to be true in all cases).<br /><br /><span class="default">&lt;?php <br /><br />&nbsp; &nbsp; $var </span><span class="keyword">= </span><span class="default">3</span><span class="keyword">; <br />&nbsp; &nbsp; </span><span class="default">$arr </span><span class="keyword">= array(); <br /><br />&nbsp; &nbsp; </span><span class="default">$var </span><span class="keyword">= @</span><span class="default">$arr</span><span class="keyword">[</span><span class="string">'x'</span><span class="keyword">];&nbsp; &nbsp; </span><span class="comment">// what is the value of $var after this assignment?<br /><br />&nbsp; &nbsp; // is it its previous value (3) as if the assignment never took place?<br />&nbsp; &nbsp; // is it FALSE or NULL?<br />&nbsp; &nbsp; // is it some kind of exception or error message or error number?<br /><br />&nbsp;&nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">);&nbsp; </span><span class="comment">// prints "NULL"<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116731">  <div class="votes">
    <div id="Vu116731">
    <a href="/manual/vote-note.php?id=116731&amp;page=language.operators.errorcontrol&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116731">
    <a href="/manual/vote-note.php?id=116731&amp;page=language.operators.errorcontrol&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116731" title="45% like this...">
    -1
    </div>
  </div>
  <a href="#116731" class="name">
  <strong class="user"><em>karst dot REMOVETHIS at onlinq dot nl</em></strong></a><a class="genanchor" href="#116731"> &para;</a><div class="date" title="2015-02-20 02:15"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom116731">
<div class="phpcode"><code><span class="html">
While you should definitely not be too liberal with the @ operator, I also disagree with people who claim it's the ultimate sin.<br /><br />For example, a very reasonable use is to suppress the notice-level error generated by parse_ini_file() if you know the .ini file may be missing.<br />In my case getting the FALSE return value was enough to handle that situation, but I didn't want notice errors being output by my API.<br /><br />TL;DR: Use it, but only if you know what you're suppressing and why.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="71713">  <div class="votes">
    <div id="Vu71713">
    <a href="/manual/vote-note.php?id=71713&amp;page=language.operators.errorcontrol&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd71713">
    <a href="/manual/vote-note.php?id=71713&amp;page=language.operators.errorcontrol&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V71713" title="45% like this...">
    -2
    </div>
  </div>
  <a href="#71713" class="name"><strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#71713"> &para;</a><div class="date" title="2006-12-12 05:52"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom71713">
<div class="phpcode"><code><span class="html">
error_reporting()==0 for detecting the @ error suppression assumes that you did not set the error level to 0 in the first place.<br /><br />However, typically if you want to set your own error handler, you would set the error_reporting to 0. Therefore, an alternative to detect the @ error suppression is required.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="72126">  <div class="votes">
    <div id="Vu72126">
    <a href="/manual/vote-note.php?id=72126&amp;page=language.operators.errorcontrol&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd72126">
    <a href="/manual/vote-note.php?id=72126&amp;page=language.operators.errorcontrol&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V72126" title="43% like this...">
    -4
    </div>
  </div>
  <a href="#72126" class="name">
  <strong class="user"><em>nospam at blog dot fileville dot net</em></strong></a><a class="genanchor" href="#72126"> &para;</a><div class="date" title="2007-01-03 11:58"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom72126">
<div class="phpcode"><code><span class="html">
If you want to log all the error messages for a php script from a session you can use something like this:<br /><span class="default">&lt;?php<br /> session_start</span><span class="keyword">();<br />&nbsp; function </span><span class="default">error</span><span class="keyword">(</span><span class="default">$error</span><span class="keyword">, </span><span class="default">$return</span><span class="keyword">=</span><span class="default">FALSE</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; global </span><span class="default">$php_errormsg</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; if(isset(</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'php_errors'</span><span class="keyword">])) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'php_errors'</span><span class="keyword">] = array();&nbsp; &nbsp;&nbsp; <br />&nbsp; &nbsp; }<br />&nbsp; </span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'php_errors'</span><span class="keyword">][] = </span><span class="default">$error</span><span class="keyword">; </span><span class="comment">// Maybe use $php_errormsg<br />&nbsp; </span><span class="keyword">if(</span><span class="default">$return </span><span class="keyword">== </span><span class="default">TRUE</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$message </span><span class="keyword">= </span><span class="string">""</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp;&nbsp; foreach(</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'php_errors'</span><span class="keyword">] as </span><span class="default">$php_error</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$messages </span><span class="keyword">.= </span><span class="default">$php_error</span><span class="keyword">.</span><span class="string">"\n"</span><span class="keyword">;<br />&nbsp; &nbsp;&nbsp; }&nbsp; <br />&nbsp; &nbsp; return </span><span class="default">$messages</span><span class="keyword">; </span><span class="comment">// Or you can use use $_SESSION['php_errors']<br />&nbsp; </span><span class="keyword">}<br />}<br /></span><span class="default">?&gt;<br /></span>Hope this helps someone...</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114387">  <div class="votes">
    <div id="Vu114387">
    <a href="/manual/vote-note.php?id=114387&amp;page=language.operators.errorcontrol&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114387">
    <a href="/manual/vote-note.php?id=114387&amp;page=language.operators.errorcontrol&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114387" title="38% like this...">
    -5
    </div>
  </div>
  <a href="#114387" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#114387"> &para;</a><div class="date" title="2014-02-14 11:24"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114387">
<div class="phpcode"><code><span class="html">
I was wondering if anyone (else) might find a directive to disable/enable to error operator would be a useful addition. That is, instead of something like (which I have seen for a few places in some code):<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">if (</span><span class="default">defined</span><span class="keyword">(</span><span class="default">PRODUCTION</span><span class="keyword">)) {<br />&nbsp; &nbsp; @function();<br />}<br />else {<br />&nbsp; &nbsp; function();<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />There could be something like this:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">if (</span><span class="default">defined</span><span class="keyword">(</span><span class="default">PRODUCTION</span><span class="keyword">)) {<br />&nbsp; &nbsp; </span><span class="default">ini_set</span><span class="keyword">(</span><span class="string">'error.silent'</span><span class="keyword">,</span><span class="default">TRUE</span><span class="keyword">);<br />}<br />else {<br />&nbsp; &nbsp; </span><span class="default">ini_set</span><span class="keyword">(</span><span class="string">'error.silent'</span><span class="keyword">,</span><span class="default">FALSE</span><span class="keyword">);<br />}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="50565">  <div class="votes">
    <div id="Vu50565">
    <a href="/manual/vote-note.php?id=50565&amp;page=language.operators.errorcontrol&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd50565">
    <a href="/manual/vote-note.php?id=50565&amp;page=language.operators.errorcontrol&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V50565" title="36% like this...">
    -8
    </div>
  </div>
  <a href="#50565" class="name">
  <strong class="user"><em>me at hesterc dot fsnet dot co dot uk</em></strong></a><a class="genanchor" href="#50565"> &para;</a><div class="date" title="2005-03-03 08:25"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom50565">
<div class="phpcode"><code><span class="html">
If you wish to display some text when an error occurs, echo doesn't work. Use print instead. This is explained on the following link 'What is the difference between echo and print?':<br /><br /><a href="http://www.faqts.com/knowledge_base/view.phtml/aid/1/fid/40" rel="nofollow" target="_blank">http://www.faqts.com/knowledge_base/view.phtml/aid/1/fid/40</a><br /><br />It says "print can be used as part of a more complex expression where echo cannot".<br /><br />Also, you can add multiple code to the result when an error occurs by separating each line with "and". Here is an example:<br /><br /><span class="default">&lt;?php<br />$my_file </span><span class="keyword">= @</span><span class="default">file </span><span class="keyword">(</span><span class="string">'non_existent_file'</span><span class="keyword">) or print </span><span class="string">'File not found.' </span><span class="keyword">and </span><span class="default">$string </span><span class="keyword">= </span><span class="string">' Honest!' </span><span class="keyword">and print </span><span class="default">$string </span><span class="keyword">and </span><span class="default">$fp </span><span class="keyword">= </span><span class="default">fopen </span><span class="keyword">(</span><span class="string">'error_log.txt'</span><span class="keyword">, </span><span class="string">'wb+'</span><span class="keyword">) and </span><span class="default">fwrite</span><span class="keyword">(</span><span class="default">$fp</span><span class="keyword">, </span><span class="default">$string</span><span class="keyword">) and </span><span class="default">fclose</span><span class="keyword">(</span><span class="default">$fp</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />A shame you can't use curly brackets above to enclose multiple lines of code, like you can with an if statement or a loop. It could make for a single long line of code. You could always call a function instead.</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.operators.errorcontrol&amp;redirect=http://php.net/manual/en/language.operators.errorcontrol.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.operators.php">Operators</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.operators.precedence.php" title="Operator Precedence">Operator Precedence</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.arithmetic.php" title="Arithmetic Operators">Arithmetic Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.assignment.php" title="Assignment Operators">Assignment Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.bitwise.php" title="Bitwise Operators">Bitwise Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.comparison.php" title="Comparison Operators">Comparison Operators</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.operators.errorcontrol.php" title="Error Control Operators">Error Control Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.execution.php" title="Execution Operators">Execution Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.increment.php" title="Incrementing/Decrementing Operators">Incrementing/Decrementing Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.logical.php" title="Logical Operators">Logical Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.string.php" title="String Operators">String Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.array.php" title="Array Operators">Array Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.type.php" title="Type Operators">Type Operators</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

