<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Static Keyword - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.oop5.static.php">
 <link rel="shorturl" href="http://php.net/oop5.static">
 <link rel="alternate" href="http://php.net/oop5.static" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.oop5.php">
 <link rel="prev" href="http://php.net/manual/en/language.oop5.paamayim-nekudotayim.php">
 <link rel="next" href="http://php.net/manual/en/language.oop5.abstract.php">

 <link rel="alternate" href="http://php.net/manual/en/language.oop5.static.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.oop5.static.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.oop5.static.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.oop5.static.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.oop5.static.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.oop5.static.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.oop5.static.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.oop5.static.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.oop5.static.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.oop5.static.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.oop5.static.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.oop5.abstract.php">
          Class Abstraction &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.oop5.paamayim-nekudotayim.php">
          &laquo; Scope Resolution Operator (::)        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.oop5.php'>Classes and Objects</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.oop5.static.php' selected="selected">English</option>
            <option value='pt_BR/language.oop5.static.php'>Brazilian Portuguese</option>
            <option value='zh/language.oop5.static.php'>Chinese (Simplified)</option>
            <option value='fr/language.oop5.static.php'>French</option>
            <option value='de/language.oop5.static.php'>German</option>
            <option value='ja/language.oop5.static.php'>Japanese</option>
            <option value='ro/language.oop5.static.php'>Romanian</option>
            <option value='ru/language.oop5.static.php'>Russian</option>
            <option value='es/language.oop5.static.php'>Spanish</option>
            <option value='tr/language.oop5.static.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.oop5.static.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.oop5.static">Report a Bug</a>
    </div>
  </div><div id="language.oop5.static" class="sect1">
  <h2 class="title">Static Keyword</h2>

  <div class="tip"><strong class="tip">Tip</strong>
   <p class="simpara">
    This page describes the use of the <em>static</em> keyword to
    define static methods and properties. <em>static</em> can also
    be used to
    <a href="language.variables.scope.php#language.variables.scope.static" class="link">define static variables</a>
    and for
    <a href="language.oop5.late-static-bindings.php" class="link">late static bindings</a>.
    Please refer to those pages for information on those meanings of
    <em>static</em>.
   </p>
  </div>

  <p class="para">
   Declaring class properties or methods as static makes them accessible
   without needing an instantiation of the class. A property declared as
   static cannot be accessed with an instantiated class object (though
   a static method can).
  </p>

  <p class="para">
   For compatibility with PHP 4, if no <a href="language.oop5.visibility.php" class="link">visibility</a>
   declaration is used, then the property or method will be treated
   as if it was declared as <em>public</em>.
  </p>

  <div class="sect2" id="language.oop5.static.methods">
   <h3 class="title">Static methods</h3>

   <p class="para">
    Because static methods are callable without an instance of
    the object created, the pseudo-variable <var class="varname"><var class="varname">$this</var></var> is
    not available inside the method declared as static.
   </p>

   <div class="caution"><strong class="caution">Caution</strong>
    <p class="simpara">
     In PHP 5, calling non-static methods statically generates an
     <strong><code>E_STRICT</code></strong> level warning.
    </p>
   </div>

   <div class="warning"><strong class="warning">Warning</strong>
    <p class="simpara">
     In PHP 7, calling non-static methods statically is deprecated, and will
     generate an <strong><code>E_DEPRECATED</code></strong> warning. Support for
     calling non-static methods statically may be removed in the future.
    </p>
   </div>

   <div class="example" id="example-202">
    <p><strong>Example #1 Static method example</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">Foo&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;static&nbsp;function&nbsp;</span><span style="color: #0000BB">aStaticMethod</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;...<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">}<br />}<br /><br /></span><span style="color: #0000BB">Foo</span><span style="color: #007700">::</span><span style="color: #0000BB">aStaticMethod</span><span style="color: #007700">();<br /></span><span style="color: #0000BB">$classname&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'Foo'</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$classname</span><span style="color: #007700">::</span><span style="color: #0000BB">aStaticMethod</span><span style="color: #007700">();&nbsp;</span><span style="color: #FF8000">//&nbsp;As&nbsp;of&nbsp;PHP&nbsp;5.3.0<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

   </div>
  </div>
  
  <div class="sect2" id="language.oop5.static.properties">
   <h3 class="title">Static properties</h3>

   <p class="para">
    Static properties cannot be accessed through the object using the arrow
    operator -&gt;.
   </p>

   <p class="para">
    Like any other PHP static variable, static properties may only be
    initialized using a literal or constant before PHP 5.6; expressions are
    not allowed. In PHP 5.6 and later, the same rules apply as <a href="language.constants.syntax.php" class="link"><em>const</em></a>
    expressions: some limited expressions are possible, provided they can be
    evaluated at compile time.
   </p>

   <p class="para">
    As of PHP 5.3.0, it&#039;s possible to reference the class using a variable.
    The variable&#039;s value cannot be a keyword (e.g. <em>self</em>,
    <em>parent</em> and <em>static</em>).
   </p>

   <div class="example" id="example-203">
    <p><strong>Example #2 Static property example</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">Foo<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;static&nbsp;</span><span style="color: #0000BB">$my_static&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'foo'</span><span style="color: #007700">;<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">staticValue</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">self</span><span style="color: #007700">::</span><span style="color: #0000BB">$my_static</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br />class&nbsp;</span><span style="color: #0000BB">Bar&nbsp;</span><span style="color: #007700">extends&nbsp;</span><span style="color: #0000BB">Foo<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">fooStatic</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">parent</span><span style="color: #007700">::</span><span style="color: #0000BB">$my_static</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br /><br />print&nbsp;</span><span style="color: #0000BB">Foo</span><span style="color: #007700">::</span><span style="color: #0000BB">$my_static&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br /><br /></span><span style="color: #0000BB">$foo&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">Foo</span><span style="color: #007700">();<br />print&nbsp;</span><span style="color: #0000BB">$foo</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">staticValue</span><span style="color: #007700">()&nbsp;.&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br />print&nbsp;</span><span style="color: #0000BB">$foo</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">my_static&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;Undefined&nbsp;"Property"&nbsp;my_static&nbsp;<br /><br /></span><span style="color: #007700">print&nbsp;</span><span style="color: #0000BB">$foo</span><span style="color: #007700">::</span><span style="color: #0000BB">$my_static&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$classname&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'Foo'</span><span style="color: #007700">;<br />print&nbsp;</span><span style="color: #0000BB">$classname</span><span style="color: #007700">::</span><span style="color: #0000BB">$my_static&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;As&nbsp;of&nbsp;PHP&nbsp;5.3.0<br /><br /></span><span style="color: #007700">print&nbsp;</span><span style="color: #0000BB">Bar</span><span style="color: #007700">::</span><span style="color: #0000BB">$my_static&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$bar&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">Bar</span><span style="color: #007700">();<br />print&nbsp;</span><span style="color: #0000BB">$bar</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">fooStatic</span><span style="color: #007700">()&nbsp;.&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
  </div>
 </div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.oop5.static&amp;redirect=http://php.net/manual/en/language.oop5.static.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">46 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="80661">  <div class="votes">
    <div id="Vu80661">
    <a href="/manual/vote-note.php?id=80661&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd80661">
    <a href="/manual/vote-note.php?id=80661&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V80661" title="71% like this...">
    118
    </div>
  </div>
  <a href="#80661" class="name">
  <strong class="user"><em>inkredibl</em></strong></a><a class="genanchor" href="#80661"> &para;</a><div class="date" title="2008-01-28 12:27"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom80661">
<div class="phpcode"><code><span class="html">
Note that you should read "Variables/Variable scope" if you are looking for static keyword use for declaring static variables inside functions (or methods). I myself had this gap in my PHP knowledge until recently and had to google to find this out. I think this page should have a "See also" link to static function variables.<br /><a href="http://www.php.net/manual/en/language.variables.scope.php" rel="nofollow" target="_blank">http://www.php.net/manual/en/language.variables.scope.php</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="104823">  <div class="votes">
    <div id="Vu104823">
    <a href="/manual/vote-note.php?id=104823&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd104823">
    <a href="/manual/vote-note.php?id=104823&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V104823" title="72% like this...">
    77
    </div>
  </div>
  <a href="#104823" class="name">
  <strong class="user"><em>payal001 at gmail dot com</em></strong></a><a class="genanchor" href="#104823"> &para;</a><div class="date" title="2011-07-09 03:17"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom104823">
<div class="phpcode"><code><span class="html">
Here statically accessed property prefer property of the class for which it is called. Where as self keyword enforces use of current class only. Refer the below example:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">a</span><span class="keyword">{<br /><br />static protected </span><span class="default">$test</span><span class="keyword">=</span><span class="string">"class a"</span><span class="keyword">;<br /><br />public function </span><span class="default">static_test</span><span class="keyword">(){<br /><br />echo static::</span><span class="default">$test</span><span class="keyword">; </span><span class="comment">// Results class b<br /></span><span class="keyword">echo </span><span class="default">self</span><span class="keyword">::</span><span class="default">$test</span><span class="keyword">; </span><span class="comment">// Results class a<br /><br /></span><span class="keyword">}<br /><br />}<br /><br />class </span><span class="default">b </span><span class="keyword">extends </span><span class="default">a</span><span class="keyword">{<br /><br />static protected </span><span class="default">$test</span><span class="keyword">=</span><span class="string">"class b"</span><span class="keyword">;<br /><br />}<br /><br /></span><span class="default">$obj </span><span class="keyword">= new </span><span class="default">b</span><span class="keyword">();<br /></span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">static_test</span><span class="keyword">();<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="96402">  <div class="votes">
    <div id="Vu96402">
    <a href="/manual/vote-note.php?id=96402&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd96402">
    <a href="/manual/vote-note.php?id=96402&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V96402" title="60% like this...">
    19
    </div>
  </div>
  <a href="#96402" class="name">
  <strong class="user"><em>webmaster at removethis dot weird-webdesign dot de</em></strong></a><a class="genanchor" href="#96402"> &para;</a><div class="date" title="2010-02-25 01:38"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom96402">
<div class="phpcode"><code><span class="html">
On PHP 5.2.x or previous you might run into problems initializing static variables in subclasses due to the lack of late static binding:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">A </span><span class="keyword">{<br />&nbsp; &nbsp; protected static </span><span class="default">$a</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public static function </span><span class="default">init</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">) { </span><span class="default">self</span><span class="keyword">::</span><span class="default">$a </span><span class="keyword">= </span><span class="default">$value</span><span class="keyword">; }<br />&nbsp; &nbsp; public static function </span><span class="default">getA</span><span class="keyword">() { return </span><span class="default">self</span><span class="keyword">::</span><span class="default">$a</span><span class="keyword">; }<br />}<br /><br />class </span><span class="default">B </span><span class="keyword">extends </span><span class="default">A </span><span class="keyword">{<br />&nbsp; &nbsp; protected static </span><span class="default">$a</span><span class="keyword">; </span><span class="comment">// redefine $a for own use<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; // inherit the init() method<br />&nbsp; &nbsp; </span><span class="keyword">public static function </span><span class="default">getA</span><span class="keyword">() { return </span><span class="default">self</span><span class="keyword">::</span><span class="default">$a</span><span class="keyword">; }<br />}<br /><br /></span><span class="default">B</span><span class="keyword">::</span><span class="default">init</span><span class="keyword">(</span><span class="string">'lala'</span><span class="keyword">);<br />echo </span><span class="string">'A::$a = '</span><span class="keyword">.</span><span class="default">A</span><span class="keyword">::</span><span class="default">getA</span><span class="keyword">().</span><span class="string">'; B::$a = '</span><span class="keyword">.</span><span class="default">B</span><span class="keyword">::</span><span class="default">getA</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span><br />This will output:<br />A::$a = lala; B::$a = <br /><br />If the init() method looks the same for (almost) all subclasses there should be no need to implement init() in every subclass and by that producing redundant code.<br /><br />Solution 1:<br />Turn everything into non-static. BUT: This would produce redundant data on every object of the class.<br /><br />Solution 2:<br />Turn static $a on class A into an array, use classnames of subclasses as indeces. By doing so you also don't have to redefine $a for the subclasses and the superclass' $a can be private.<br /><br />Short example on a DataRecord class without error checking:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">abstract class </span><span class="default">DataRecord </span><span class="keyword">{<br />&nbsp; &nbsp; private static </span><span class="default">$db</span><span class="keyword">; </span><span class="comment">// MySQLi-Connection, same for all subclasses<br />&nbsp; &nbsp; </span><span class="keyword">private static </span><span class="default">$table </span><span class="keyword">= array(); </span><span class="comment">// Array of tables for subclasses<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="keyword">public static function </span><span class="default">init</span><span class="keyword">(</span><span class="default">$classname</span><span class="keyword">, </span><span class="default">$table</span><span class="keyword">, </span><span class="default">$db </span><span class="keyword">= </span><span class="default">false</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (!(</span><span class="default">$db </span><span class="keyword">=== </span><span class="default">false</span><span class="keyword">)) </span><span class="default">self</span><span class="keyword">::</span><span class="default">$db </span><span class="keyword">= </span><span class="default">$db</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">$table</span><span class="keyword">[</span><span class="default">$classname</span><span class="keyword">] = </span><span class="default">$table</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public static function </span><span class="default">getDB</span><span class="keyword">() { return </span><span class="default">self</span><span class="keyword">::</span><span class="default">$db</span><span class="keyword">; }<br />&nbsp; &nbsp; public static function </span><span class="default">getTable</span><span class="keyword">(</span><span class="default">$classname</span><span class="keyword">) { return </span><span class="default">self</span><span class="keyword">::</span><span class="default">$table</span><span class="keyword">[</span><span class="default">$classname</span><span class="keyword">]; }<br />}<br /><br />class </span><span class="default">UserDataRecord </span><span class="keyword">extends </span><span class="default">DataRecord </span><span class="keyword">{<br />&nbsp; &nbsp; public static function </span><span class="default">fetchFromDB</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$result </span><span class="keyword">= </span><span class="default">parent</span><span class="keyword">::</span><span class="default">getDB</span><span class="keyword">()-&gt;</span><span class="default">query</span><span class="keyword">(</span><span class="string">'select * from '</span><span class="keyword">.</span><span class="default">parent</span><span class="keyword">::</span><span class="default">getTable</span><span class="keyword">(</span><span class="string">'UserDataRecord'</span><span class="keyword">).</span><span class="string">';'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// and so on ...<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">$result</span><span class="keyword">; </span><span class="comment">// An array of UserDataRecord objects<br />&nbsp; &nbsp; </span><span class="keyword">}<br />}<br /><br /></span><span class="default">$db </span><span class="keyword">= new </span><span class="default">MySQLi</span><span class="keyword">(...);<br /></span><span class="default">UserDataRecord</span><span class="keyword">::</span><span class="default">init</span><span class="keyword">(</span><span class="string">'UserDataRecord'</span><span class="keyword">, </span><span class="string">'users'</span><span class="keyword">, </span><span class="default">$db</span><span class="keyword">);<br /></span><span class="default">$users </span><span class="keyword">= </span><span class="default">UserDataRecord</span><span class="keyword">::</span><span class="default">fetchFromDB</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span><br />I hope this helps some people who need to operate on PHP 5.2.x servers for some reason. Late static binding, of course, makes this workaround obsolete.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="89650">  <div class="votes">
    <div id="Vu89650">
    <a href="/manual/vote-note.php?id=89650&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd89650">
    <a href="/manual/vote-note.php?id=89650&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V89650" title="61% like this...">
    12
    </div>
  </div>
  <a href="#89650" class="name">
  <strong class="user"><em>davidn at xnet dot co dot nz</em></strong></a><a class="genanchor" href="#89650"> &para;</a><div class="date" title="2009-03-17 04:56"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom89650">
<div class="phpcode"><code><span class="html">
Static variables are shared between sub classes<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">MyParent </span><span class="keyword">{<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; protected static </span><span class="default">$variable</span><span class="keyword">;<br />}<br /><br />class </span><span class="default">Child1 </span><span class="keyword">extends </span><span class="default">MyParent </span><span class="keyword">{<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">set</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">$variable </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">Child2 </span><span class="keyword">extends </span><span class="default">MyParent </span><span class="keyword">{<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">show</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; echo(</span><span class="default">self</span><span class="keyword">::</span><span class="default">$variable</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$c1 </span><span class="keyword">= new </span><span class="default">Child1</span><span class="keyword">();<br /></span><span class="default">$c1</span><span class="keyword">-&gt;</span><span class="default">set</span><span class="keyword">();<br /></span><span class="default">$c2 </span><span class="keyword">= new </span><span class="default">Child2</span><span class="keyword">();<br /></span><span class="default">$c2</span><span class="keyword">-&gt;</span><span class="default">show</span><span class="keyword">(); </span><span class="comment">// prints 2<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="52519">  <div class="votes">
    <div id="Vu52519">
    <a href="/manual/vote-note.php?id=52519&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd52519">
    <a href="/manual/vote-note.php?id=52519&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V52519" title="60% like this...">
    15
    </div>
  </div>
  <a href="#52519" class="name">
  <strong class="user"><em>aidan at php dot net</em></strong></a><a class="genanchor" href="#52519"> &para;</a><div class="date" title="2005-05-04 07:14"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom52519">
<div class="phpcode"><code><span class="html">
To check if a function was called statically or not, you'll need to do:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">foo </span><span class="keyword">() {<br />&nbsp; &nbsp; </span><span class="default">$isStatic </span><span class="keyword">= !(isset(</span><span class="default">$this</span><span class="keyword">) &amp;&amp; </span><span class="default">get_class</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">) == </span><span class="default">__CLASS__</span><span class="keyword">);<br />}<br /></span><span class="default">?&gt;<br /></span><br />More at (<a href="http://blog.phpdoc.info/archives/4-Schizophrenic-Methods.html" rel="nofollow" target="_blank">http://blog.phpdoc.info/archives/4-Schizophrenic-Methods.html</a>). <br /><br />(I'll add this to the manual soon).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="80162">  <div class="votes">
    <div id="Vu80162">
    <a href="/manual/vote-note.php?id=80162&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd80162">
    <a href="/manual/vote-note.php?id=80162&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V80162" title="60% like this...">
    10
    </div>
  </div>
  <a href="#80162" class="name">
  <strong class="user"><em>ssj dot narutovash at gmail dot com</em></strong></a><a class="genanchor" href="#80162"> &para;</a><div class="date" title="2008-01-01 08:48"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom80162">
<div class="phpcode"><code><span class="html">
It's come to my attention that you cannot use a static member in an HEREDOC string.&nbsp; The following code<br /><br />class A<br />{<br />&nbsp; public static $BLAH = "user";<br /><br />&nbsp; function __construct()<br />&nbsp; {<br />&nbsp; &nbsp; echo &lt;&lt;&lt;EOD<br />&lt;h1&gt;Hello {self::$BLAH}&lt;/h1&gt;<br />EOD;<br />&nbsp; }<br />}<br /><br />$blah = new A();<br /><br />produces this in the source code:<br /><br />&lt;h1&gt;Hello {self::}&lt;/h1&gt;<br /><br />Solution:<br /><br />before using a static member, store it in a local variable, like so:<br /><br />class B<br />{<br />&nbsp; public static $BLAH = "user";<br /><br />&nbsp; function __construct()<br />&nbsp; {<br />&nbsp; &nbsp; $blah = self::$BLAH;<br />&nbsp; &nbsp; echo &lt;&lt;&lt;EOD<br />&lt;h1&gt;Hello {$blah}&lt;/h1&gt;<br />EOD;<br />&nbsp; }<br />}<br /><br />and the output's source code will be:<br /><br />&lt;h1&gt;Hello user&lt;/h1&gt;</span>
</code></div>
  </div>
 </div>
  <div class="note" id="95860">  <div class="votes">
    <div id="Vu95860">
    <a href="/manual/vote-note.php?id=95860&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd95860">
    <a href="/manual/vote-note.php?id=95860&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V95860" title="57% like this...">
    2
    </div>
  </div>
  <a href="#95860" class="name">
  <strong class="user"><em>valentin at balt dot name</em></strong></a><a class="genanchor" href="#95860"> &para;</a><div class="date" title="2010-01-26 07:46"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom95860">
<div class="phpcode"><code><span class="html">
How to implement a one storage place based on static properties.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">a </span><span class="keyword">{<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">get </span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">connect</span><span class="keyword">();<br />&nbsp; &nbsp; }<br />}<br />class </span><span class="default">b </span><span class="keyword">extends </span><span class="default">a </span><span class="keyword">{<br />&nbsp; &nbsp; private static </span><span class="default">$a</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public function </span><span class="default">connect</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">self</span><span class="keyword">::</span><span class="default">$a </span><span class="keyword">= </span><span class="string">'b'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br />class </span><span class="default">c </span><span class="keyword">extends </span><span class="default">a </span><span class="keyword">{<br />&nbsp; &nbsp; private static </span><span class="default">$a</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public function </span><span class="default">connect</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">self</span><span class="keyword">::</span><span class="default">$a </span><span class="keyword">= </span><span class="string">'c'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">$b </span><span class="keyword">= new </span><span class="default">b </span><span class="keyword">();<br /></span><span class="default">$c </span><span class="keyword">= new </span><span class="default">c </span><span class="keyword">();<br /><br /></span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">get</span><span class="keyword">();<br /></span><span class="default">$c</span><span class="keyword">-&gt;</span><span class="default">get</span><span class="keyword">();<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="103530">  <div class="votes">
    <div id="Vu103530">
    <a href="/manual/vote-note.php?id=103530&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd103530">
    <a href="/manual/vote-note.php?id=103530&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V103530" title="54% like this...">
    6
    </div>
  </div>
  <a href="#103530" class="name">
  <strong class="user"><em>gratcypalma at gmail dot om</em></strong></a><a class="genanchor" href="#103530"> &para;</a><div class="date" title="2011-04-18 11:50"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom103530">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">foo </span><span class="keyword">{<br />&nbsp; &nbsp; private static </span><span class="default">$getInitial</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public static function </span><span class="default">getInitial</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">self</span><span class="keyword">::</span><span class="default">$getInitial </span><span class="keyword">== </span><span class="default">null</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">$getInitial </span><span class="keyword">= new </span><span class="default">foo</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">self</span><span class="keyword">::</span><span class="default">$getInitial</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">foo</span><span class="keyword">::</span><span class="default">getInitial</span><span class="keyword">();<br /><br /></span><span class="comment">/*<br />this is the example to use new class with static method..<br />i hope it help<br />*/<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="101350">  <div class="votes">
    <div id="Vu101350">
    <a href="/manual/vote-note.php?id=101350&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd101350">
    <a href="/manual/vote-note.php?id=101350&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V101350" title="54% like this...">
    4
    </div>
  </div>
  <a href="#101350" class="name">
  <strong class="user"><em>tolean_dj at yahoo dot com</em></strong></a><a class="genanchor" href="#101350"> &para;</a><div class="date" title="2010-12-11 05:09"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom101350">
<div class="phpcode"><code><span class="html">
Starting with php 5.3 you can get use of new features of static keyword. Here's an example of abstract singleton class:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">abstract class </span><span class="default">Singleton </span><span class="keyword">{<br /><br />&nbsp; &nbsp; protected static </span><span class="default">$_instance </span><span class="keyword">= </span><span class="default">NULL</span><span class="keyword">;<br /><br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Prevent direct object creation<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">final private function&nbsp; </span><span class="default">__construct</span><span class="keyword">() { }<br /><br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Prevent object cloning<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">final private function&nbsp; </span><span class="default">__clone</span><span class="keyword">() { }<br /><br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Returns new or existing Singleton instance<br />&nbsp; &nbsp;&nbsp; * @return Singleton<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">final public static function </span><span class="default">getInstance</span><span class="keyword">(){<br />&nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">null </span><span class="keyword">!== static::</span><span class="default">$_instance</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return static::</span><span class="default">$_instance</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; static::</span><span class="default">$_instance </span><span class="keyword">= new static();<br />&nbsp; &nbsp; &nbsp; &nbsp; return static::</span><span class="default">$_instance</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="95217">  <div class="votes">
    <div id="Vu95217">
    <a href="/manual/vote-note.php?id=95217&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd95217">
    <a href="/manual/vote-note.php?id=95217&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V95217" title="55% like this...">
    2
    </div>
  </div>
  <a href="#95217" class="name">
  <strong class="user"><em>Jay Cain</em></strong></a><a class="genanchor" href="#95217"> &para;</a><div class="date" title="2009-12-18 02:45"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom95217">
<div class="phpcode"><code><span class="html">
Regarding the initialization of complex static variables in a class, you can emulate a static constructor by creating a static function named something like init() and calling it immediately after the class definition.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Example </span><span class="keyword">{<br />&nbsp; &nbsp; private static </span><span class="default">$a </span><span class="keyword">= </span><span class="string">"Hello"</span><span class="keyword">;<br />&nbsp; &nbsp; private static </span><span class="default">$b</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public static function </span><span class="default">init</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">$b </span><span class="keyword">= </span><span class="default">self</span><span class="keyword">::</span><span class="default">$a </span><span class="keyword">. </span><span class="string">" World!"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">Example</span><span class="keyword">::</span><span class="default">init</span><span class="keyword">();<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="99542">  <div class="votes">
    <div id="Vu99542">
    <a href="/manual/vote-note.php?id=99542&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd99542">
    <a href="/manual/vote-note.php?id=99542&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V99542" title="52% like this...">
    2
    </div>
  </div>
  <a href="#99542" class="name">
  <strong class="user"><em>Mirco</em></strong></a><a class="genanchor" href="#99542"> &para;</a><div class="date" title="2010-08-23 10:16"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom99542">
<div class="phpcode"><code><span class="html">
The simplest static constructor.<br /><br />Because php does not have a static constructor and you may want to initialize static class vars, there is one easy way, just call your own function directly after the class definition.<br /><br />for example.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">Demonstration</span><span class="keyword">()<br />{<br />&nbsp; &nbsp; return </span><span class="string">'This is the result of demonstration()'</span><span class="keyword">;<br />}<br /><br />class </span><span class="default">MyStaticClass<br /></span><span class="keyword">{<br />&nbsp; &nbsp; </span><span class="comment">//public static $MyStaticVar = Demonstration(); //!!! FAILS: syntax error<br />&nbsp; &nbsp; </span><span class="keyword">public static </span><span class="default">$MyStaticVar </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public static function </span><span class="default">MyStaticInit</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//this is the static constructor<br />&nbsp; &nbsp; &nbsp; &nbsp; //because in a function, everything is allowed, including initializing using other functions<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">$MyStaticVar </span><span class="keyword">= </span><span class="default">Demonstration</span><span class="keyword">();<br />&nbsp; &nbsp; }<br />} </span><span class="default">MyStaticClass</span><span class="keyword">::</span><span class="default">MyStaticInit</span><span class="keyword">(); </span><span class="comment">//Call the static constructor<br /><br /></span><span class="keyword">echo </span><span class="default">MyStaticClass</span><span class="keyword">::</span><span class="default">$MyStaticVar</span><span class="keyword">;<br /></span><span class="comment">//This is the result of demonstration()<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118918">  <div class="votes">
    <div id="Vu118918">
    <a href="/manual/vote-note.php?id=118918&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118918">
    <a href="/manual/vote-note.php?id=118918&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118918" title="50% like this...">
    0
    </div>
  </div>
  <a href="#118918" class="name">
  <strong class="user"><em>b1tchcakes</em></strong></a><a class="genanchor" href="#118918"> &para;</a><div class="date" title="2016-02-27 09:06"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom118918">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br /><br /></span><span class="keyword">trait </span><span class="default">t </span><span class="keyword">{<br />&nbsp; protected </span><span class="default">$p</span><span class="keyword">;<br />&nbsp; public function </span><span class="default">testMe</span><span class="keyword">() {echo </span><span class="string">'static:'</span><span class="keyword">.static::class. </span><span class="string">' // self:'</span><span class="keyword">.</span><span class="default">self</span><span class="keyword">::class .</span><span class="string">"\n"</span><span class="keyword">;}<br />}<br /><br />class </span><span class="default">a </span><span class="keyword">{ use </span><span class="default">t</span><span class="keyword">; }<br />class </span><span class="default">b </span><span class="keyword">extends </span><span class="default">a </span><span class="keyword">{}<br /><br />echo (new </span><span class="default">a</span><span class="keyword">)-&gt;</span><span class="default">testMe</span><span class="keyword">();<br />echo (new </span><span class="default">b</span><span class="keyword">)-&gt;</span><span class="default">testMe</span><span class="keyword">();<br /><br /></span><span class="default">outputs<br /></span><span class="keyword">static:</span><span class="default">a </span><span class="comment">// self:t<br /></span><span class="keyword">static:</span><span class="default">b </span><span class="comment">// self:t</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118097">  <div class="votes">
    <div id="Vu118097">
    <a href="/manual/vote-note.php?id=118097&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118097">
    <a href="/manual/vote-note.php?id=118097&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118097" title="50% like this...">
    0
    </div>
  </div>
  <a href="#118097" class="name">
  <strong class="user"><em>sideshowAnthony at googlemail dot com</em></strong></a><a class="genanchor" href="#118097"> &para;</a><div class="date" title="2015-10-02 07:44"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom118097">
<div class="phpcode"><code><span class="html">
The static keyword can still be used (in a non-oop way) inside a function. So if you need a value stored with your class, but it is very function specific, you can use this:<br /><br />class aclass {<br />&nbsp; &nbsp; public static function b(){<br />&nbsp; &nbsp; &nbsp; &nbsp; static $d=12; // Set to 12 on first function call only<br />&nbsp; &nbsp; &nbsp; &nbsp; $d+=12;<br />&nbsp; &nbsp; &nbsp; &nbsp; return "$d\n";<br />&nbsp; &nbsp; }<br />}<br /><br />echo aclass::b(); //24<br />echo aclass::b(); //36<br />echo aclass::b(); //48<br />echo aclass::$d; //fatal error</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113708">  <div class="votes">
    <div id="Vu113708">
    <a href="/manual/vote-note.php?id=113708&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113708">
    <a href="/manual/vote-note.php?id=113708&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113708" title="50% like this...">
    0
    </div>
  </div>
  <a href="#113708" class="name">
  <strong class="user"><em>manishpatel2280 at gmail dot com</em></strong></a><a class="genanchor" href="#113708"> &para;</a><div class="date" title="2013-11-19 02:45"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113708">
<div class="phpcode"><code><span class="html">
In real world, we can say will use static method when we dont want to create object instance. <br /><br />e.g ... <br /><br />validateEmail($email) {<br /> if(T) return true;<br />return false;<br />}<br /><br />//This makes not much sense<br />$obj = new Validate();<br />$result = $obj-&gt;validateEmail($email);<br /><br />//This makes more sense<br />$result = Validate::validateEmail($email);</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113519">  <div class="votes">
    <div id="Vu113519">
    <a href="/manual/vote-note.php?id=113519&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113519">
    <a href="/manual/vote-note.php?id=113519&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113519" title="50% like this...">
    0
    </div>
  </div>
  <a href="#113519" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#113519"> &para;</a><div class="date" title="2013-10-24 01:34"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113519">
<div class="phpcode"><code><span class="html">
It should be noted that in 'Example #2', you can also call a variably defined static method as follows:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Foo </span><span class="keyword">{<br />&nbsp; &nbsp; public static function </span><span class="default">aStaticMethod</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// ...<br />&nbsp; &nbsp; </span><span class="keyword">}<br />}<br /><br /></span><span class="default">$classname </span><span class="keyword">= </span><span class="string">'Foo'</span><span class="keyword">;<br /></span><span class="default">$methodname </span><span class="keyword">= </span><span class="string">'aStaticMethod'</span><span class="keyword">;<br /></span><span class="default">$classname</span><span class="keyword">::{</span><span class="default">$methodname</span><span class="keyword">}(); </span><span class="comment">// As of PHP 5.3.0 I believe<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="51484">  <div class="votes">
    <div id="Vu51484">
    <a href="/manual/vote-note.php?id=51484&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd51484">
    <a href="/manual/vote-note.php?id=51484&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V51484" title="51% like this...">
    1
    </div>
  </div>
  <a href="#51484" class="name">
  <strong class="user"><em>michalf at ncac dot torun dot pl</em></strong></a><a class="genanchor" href="#51484"> &para;</a><div class="date" title="2005-03-31 02:42"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom51484">
<div class="phpcode"><code><span class="html">
Inheritance with the static elements is a nightmare in php. Consider the following code:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">BaseClass</span><span class="keyword">{<br />&nbsp; &nbsp; public static </span><span class="default">$property</span><span class="keyword">;<br />}<br /><br />class </span><span class="default">DerivedClassOne </span><span class="keyword">extends </span><span class="default">BaseClass</span><span class="keyword">{<br />}<br /><br />class </span><span class="default">DerivedClassTwo </span><span class="keyword">extends </span><span class="default">BaseClass</span><span class="keyword">{<br />}<br /><br /></span><span class="default">DerivedClassOne</span><span class="keyword">::</span><span class="default">$property </span><span class="keyword">= </span><span class="string">"foo"</span><span class="keyword">;<br /></span><span class="default">DerivedClassTwo</span><span class="keyword">::</span><span class="default">$property </span><span class="keyword">= </span><span class="string">"bar"</span><span class="keyword">;<br /><br />echo </span><span class="default">DerivedClassOne</span><span class="keyword">::</span><span class="default">$property</span><span class="keyword">; </span><span class="comment">//one would naively expect "foo"...<br /></span><span class="default">?&gt;<br /></span><br />What would you expect as an output? "foo"? wrong. It is "bar"!!! Static variables are not inherited, they point to the BaseClass::$property.<br /><br />At this point I think it is a big pity inheritance does not work in case of static variables/methods. Keep this in mind and save your time when debugging.<br /><br />best regards - michal</span>
</code></div>
  </div>
 </div>
  <div class="note" id="85900">  <div class="votes">
    <div id="Vu85900">
    <a href="/manual/vote-note.php?id=85900&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd85900">
    <a href="/manual/vote-note.php?id=85900&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V85900" title="50% like this...">
    0
    </div>
  </div>
  <a href="#85900" class="name">
  <strong class="user"><em>vvikramraj at yahoo dot com</em></strong></a><a class="genanchor" href="#85900"> &para;</a><div class="date" title="2008-09-23 03:24"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom85900">
<div class="phpcode"><code><span class="html">
when attempting to implement a singleton class, one might also want to either<br />a) disable __clone by making it private<br />b) bash the user who attempts to clone by defining __clone to throw an exception</span>
</code></div>
  </div>
 </div>
  <div class="note" id="85277">  <div class="votes">
    <div id="Vu85277">
    <a href="/manual/vote-note.php?id=85277&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd85277">
    <a href="/manual/vote-note.php?id=85277&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V85277" title="50% like this...">
    0
    </div>
  </div>
  <a href="#85277" class="name">
  <strong class="user"><em>Mathijs Vos</em></strong></a><a class="genanchor" href="#85277"> &para;</a><div class="date" title="2008-08-23 03:53"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom85277">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">foo<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public static </span><span class="default">$myStaticClass</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">myStaticClass </span><span class="keyword">= new </span><span class="default">bar</span><span class="keyword">();<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">bar<br /></span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">(){}<br />}<br /></span><span class="default">?&gt;<br /></span><br />Please note, this won't work.<br />Use self::$myStaticClass = new bar(); instead of self::myStaticClass = new bar(); (note the $ sign).<br />Took me an hour to figure this out.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="69766">  <div class="votes">
    <div id="Vu69766">
    <a href="/manual/vote-note.php?id=69766&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd69766">
    <a href="/manual/vote-note.php?id=69766&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V69766" title="50% like this...">
    0
    </div>
  </div>
  <a href="#69766" class="name">
  <strong class="user"><em>jan(dot)-re-mov.ethis-mazanek/AT-abeo.cz</em></strong></a><a class="genanchor" href="#69766"> &para;</a><div class="date" title="2006-09-19 11:42"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom69766">
<div class="phpcode"><code><span class="html">
This reacts to comment from <br />michael at digitalgnosis dot removethis dot com from 16-Dec-2004 08:09<br /><br />&gt; Note that Base::Foo() may no longer be declared 'static' since static methods cannot be overridden (this means it will trigger errors if error level includes E_STRICT.)<br /><br />In my test on Windows PHP Version 5.1.4 it seems that it *is possible* to override static method.<br /><br />This code works at my machine without producing E_STRICT error:<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Base<br /></span><span class="keyword">{<br />&nbsp;&nbsp; static function </span><span class="default">Foo </span><span class="keyword">( </span><span class="default">$class </span><span class="keyword">= </span><span class="default">__CLASS__ </span><span class="keyword">)<br />&nbsp;&nbsp; {<br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">call_user_func</span><span class="keyword">(array(</span><span class="default">$class</span><span class="keyword">,</span><span class="string">'Bar'</span><span class="keyword">));<br />&nbsp;&nbsp; }<br />}<br /><br />class </span><span class="default">Derived </span><span class="keyword">extends </span><span class="default">Base<br /></span><span class="keyword">{<br />&nbsp;&nbsp; static function </span><span class="default">Foo </span><span class="keyword">( </span><span class="default">$class </span><span class="keyword">= </span><span class="default">__CLASS__ </span><span class="keyword">)<br />&nbsp;&nbsp; {<br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">parent</span><span class="keyword">::</span><span class="default">Foo</span><span class="keyword">(</span><span class="default">$class</span><span class="keyword">);<br />&nbsp;&nbsp; }<br /><br />&nbsp;&nbsp; static function </span><span class="default">Bar </span><span class="keyword">()<br />&nbsp;&nbsp; {<br />&nbsp; &nbsp; &nbsp;&nbsp; echo </span><span class="string">"Derived::Bar()"</span><span class="keyword">;<br />&nbsp;&nbsp; }<br />}<br /><br /></span><span class="default">Derived</span><span class="keyword">::</span><span class="default">Foo</span><span class="keyword">(); </span><span class="comment">// This time it works.<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113954">  <div class="votes">
    <div id="Vu113954">
    <a href="/manual/vote-note.php?id=113954&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113954">
    <a href="/manual/vote-note.php?id=113954&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113954" title="46% like this...">
    -1
    </div>
  </div>
  <a href="#113954" class="name">
  <strong class="user"><em>jkenigso at utk dot edu</em></strong></a><a class="genanchor" href="#113954"> &para;</a><div class="date" title="2013-12-22 12:20"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom113954">
<div class="phpcode"><code><span class="html">
It bears mention that static variables (in the following sense) persist:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">StaticVars<br /></span><span class="keyword">{<br />&nbsp; public static </span><span class="default">$a</span><span class="keyword">=</span><span class="default">1</span><span class="keyword">;<br />}<br /></span><span class="default">$b</span><span class="keyword">=new </span><span class="default">StaticVars</span><span class="keyword">;<br /></span><span class="default">$c</span><span class="keyword">=new </span><span class="default">StaticVars</span><span class="keyword">;<br /><br />echo </span><span class="default">$b</span><span class="keyword">::</span><span class="default">$a</span><span class="keyword">; </span><span class="comment">//outputs 1<br /></span><span class="default">$c</span><span class="keyword">::</span><span class="default">$a</span><span class="keyword">=</span><span class="default">2</span><span class="keyword">;<br />echo </span><span class="default">$b</span><span class="keyword">::</span><span class="default">$a</span><span class="keyword">; </span><span class="comment">//outputs 2!<br /></span><span class="default">?&gt;<br /></span><br />Note that $c::$a=2 changed the value of $b::$a even though $b and $c are totally different objects.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="86452">  <div class="votes">
    <div id="Vu86452">
    <a href="/manual/vote-note.php?id=86452&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86452">
    <a href="/manual/vote-note.php?id=86452&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86452" title="47% like this...">
    -1
    </div>
  </div>
  <a href="#86452" class="name">
  <strong class="user"><em>zerocool at gameinsde dot ru</em></strong></a><a class="genanchor" href="#86452"> &para;</a><div class="date" title="2008-10-20 01:06"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86452">
<div class="phpcode"><code><span class="html">
Hi, here's my simple Singleton example, i think it can be useful for someone. You can use this pattern to connect to the database for example.<br /><br /><span class="default">&lt;?php<br /><br />&nbsp; </span><span class="keyword">class </span><span class="default">MySingleton<br />&nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; private static </span><span class="default">$instance </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br /><br />&nbsp; &nbsp; private function </span><span class="default">__construct</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt; </span><span class="default">name </span><span class="keyword">= </span><span class="string">'Freddy'</span><span class="keyword">;<br /><br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public static function </span><span class="default">getInstance</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; if(</span><span class="default">self</span><span class="keyword">::</span><span class="default">$instance </span><span class="keyword">== </span><span class="default">null</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; print </span><span class="string">"Object created!&lt;br&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">$instance </span><span class="keyword">= new </span><span class="default">self</span><span class="keyword">;<br /><br />&nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; return </span><span class="default">self</span><span class="keyword">::</span><span class="default">$instance</span><span class="keyword">;<br /><br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">sayHello</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; print </span><span class="string">"Hello my name is </span><span class="keyword">{</span><span class="default">$this</span><span class="keyword">-&gt; </span><span class="default">name</span><span class="keyword">}</span><span class="string">!&lt;br&gt;"</span><span class="keyword">;<br /><br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">setName</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt; </span><span class="default">name </span><span class="keyword">= </span><span class="default">$name</span><span class="keyword">;<br /><br />&nbsp; &nbsp; }<br /><br />&nbsp; }<br /><br />&nbsp; </span><span class="comment">//<br /><br />&nbsp; </span><span class="default">$objA </span><span class="keyword">= </span><span class="default">MySingleton</span><span class="keyword">::</span><span class="default">getInstance</span><span class="keyword">(); </span><span class="comment">// Object created!<br /><br />&nbsp; </span><span class="default">$objA</span><span class="keyword">-&gt; </span><span class="default">sayHello</span><span class="keyword">(); </span><span class="comment">// Hello my name is Freddy!<br /><br />&nbsp; </span><span class="default">$objA</span><span class="keyword">-&gt; </span><span class="default">setName</span><span class="keyword">(</span><span class="string">"Alex"</span><span class="keyword">);<br /><br />&nbsp; </span><span class="default">$objA</span><span class="keyword">-&gt; </span><span class="default">sayHello</span><span class="keyword">(); </span><span class="comment">// Hello my name is Alex!<br /><br />&nbsp; </span><span class="default">$objB </span><span class="keyword">= </span><span class="default">MySingleton</span><span class="keyword">::</span><span class="default">getInstance</span><span class="keyword">();<br /><br />&nbsp; </span><span class="default">$objB</span><span class="keyword">-&gt; </span><span class="default">sayHello</span><span class="keyword">(); </span><span class="comment">// Hello my name is Alex!<br /><br />&nbsp; </span><span class="default">$objB</span><span class="keyword">-&gt; </span><span class="default">setName</span><span class="keyword">(</span><span class="string">"Bob"</span><span class="keyword">);<br /><br />&nbsp; </span><span class="default">$objA</span><span class="keyword">-&gt; </span><span class="default">sayHello</span><span class="keyword">(); </span><span class="comment">// Hello my name is Bob!<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="48233">  <div class="votes">
    <div id="Vu48233">
    <a href="/manual/vote-note.php?id=48233&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd48233">
    <a href="/manual/vote-note.php?id=48233&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V48233" title="47% like this...">
    -1
    </div>
  </div>
  <a href="#48233" class="name">
  <strong class="user"><em>michael at digitalgnosis dot removethis dot com</em></strong></a><a class="genanchor" href="#48233"> &para;</a><div class="date" title="2004-12-15 11:09"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom48233">
<div class="phpcode"><code><span class="html">
If you are trying to write classes that do this:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">Base<br /></span><span class="keyword">{<br />&nbsp; &nbsp; static function </span><span class="default">Foo </span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">Bar</span><span class="keyword">();<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">Derived </span><span class="keyword">extends </span><span class="default">Base<br /></span><span class="keyword">{<br />&nbsp; &nbsp; function </span><span class="default">Bar </span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Derived::Bar()"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">Derived</span><span class="keyword">::</span><span class="default">Foo</span><span class="keyword">(); </span><span class="comment">// we want this to print "Derived::Bar()"<br /><br /></span><span class="default">?&gt;<br /></span><br />Then you'll find that PHP can't (unless somebody knows the Right Way?) since 'self::' refers to the class which owns the /code/, not the actual class which is called at runtime. (__CLASS__ doesn't work either, because: A. it cannot appear before ::, and B. it behaves like 'self')<br /><br />But if you must, then here's a (only slightly nasty) workaround:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">Base<br /></span><span class="keyword">{<br />&nbsp; &nbsp; function </span><span class="default">Foo </span><span class="keyword">( </span><span class="default">$class </span><span class="keyword">= </span><span class="default">__CLASS__ </span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">call_user_func</span><span class="keyword">(array(</span><span class="default">$class</span><span class="keyword">,</span><span class="string">'Bar'</span><span class="keyword">));<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">Derived </span><span class="keyword">extends </span><span class="default">Base<br /></span><span class="keyword">{<br />&nbsp; &nbsp; function </span><span class="default">Foo </span><span class="keyword">( </span><span class="default">$class </span><span class="keyword">= </span><span class="default">__CLASS__ </span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">parent</span><span class="keyword">::</span><span class="default">Foo</span><span class="keyword">(</span><span class="default">$class</span><span class="keyword">);<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; function </span><span class="default">Bar </span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Derived::Bar()"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">Derived</span><span class="keyword">::</span><span class="default">Foo</span><span class="keyword">(); </span><span class="comment">// This time it works.&nbsp; <br /><br /></span><span class="default">?&gt;<br /></span><br />Note that Base::Foo() may no longer be declared 'static' since static methods cannot be overridden (this means it will trigger errors if error level includes E_STRICT.)<br /><br />If Foo() takes parameters then list them before $class=__CLASS__ and in most cases, you can just forget about that parameter throughout your code.<br /><br />The major caveat is, of course, that you must override Foo() in every subclass and must always include the $class parameter when calling parent::Foo().</span>
</code></div>
  </div>
 </div>
  <div class="note" id="84421">  <div class="votes">
    <div id="Vu84421">
    <a href="/manual/vote-note.php?id=84421&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd84421">
    <a href="/manual/vote-note.php?id=84421&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V84421" title="45% like this...">
    -1
    </div>
  </div>
  <a href="#84421" class="name">
  <strong class="user"><em>michaelnospamdotnospamdaly at kayakwiki</em></strong></a><a class="genanchor" href="#84421"> &para;</a><div class="date" title="2008-07-13 06:59"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom84421">
<div class="phpcode"><code><span class="html">
Further to the comment by "erikzoltan NOSPAM at msn NOSPAM dot com" on 05-Apr-2005 03:40,<br /><br />It isn't just constructors that can't be used for static variable initialization, it's functions in general:<br /><br />class XYZ<br />{<br />&nbsp;&nbsp; static&nbsp; $foo = chr(1);&nbsp;&nbsp; // will fail<br />}<br /><br />You have to do external initialization:<br /><br />XYZ::$foo = chr(1);<br />class XYZ<br />{<br />&nbsp;&nbsp; static&nbsp; $foo;<br />}</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116780">  <div class="votes">
    <div id="Vu116780">
    <a href="/manual/vote-note.php?id=116780&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116780">
    <a href="/manual/vote-note.php?id=116780&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116780" title="42% like this...">
    -1
    </div>
  </div>
  <a href="#116780" class="name">
  <strong class="user"><em>Ano</em></strong></a><a class="genanchor" href="#116780"> &para;</a><div class="date" title="2015-02-26 10:42"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom116780">
<div class="phpcode"><code><span class="html">
The doc above says:<br />"A property declared as static cannot be accessed with an instantiated class object"<br />But it can, with a double-colon, as shown in the first example (unless I got something wrong).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120507">  <div class="votes">
    <div id="Vu120507">
    <a href="/manual/vote-note.php?id=120507&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120507">
    <a href="/manual/vote-note.php?id=120507&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120507" title="40% like this...">
    -2
    </div>
  </div>
  <a href="#120507" class="name">
  <strong class="user"><em>alberto at albertoareba dot es</em></strong></a><a class="genanchor" href="#120507"> &para;</a><div class="date" title="2017-01-23 10:35"><strong>10 months ago</strong></div>
  <div class="text" id="Hcom120507">
<div class="phpcode"><code><span class="html">
Be careful while calling static constants or methods dynamically with a variable. While you can call them since PHP 5.3.0 though a simple variable, it will throw a "Syntax error" when using an object property. This issue is fixed in PHP 7.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Foo<br /></span><span class="keyword">{<br />&nbsp; &nbsp; const </span><span class="default">BAR </span><span class="keyword">= </span><span class="string">'const'</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public static function </span><span class="default">bar</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">'static'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />echo </span><span class="default">Foo</span><span class="keyword">::</span><span class="default">BAR </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">; </span><span class="comment">// Prints "const"<br /></span><span class="keyword">echo </span><span class="default">Foo</span><span class="keyword">::</span><span class="default">bar</span><span class="keyword">() . </span><span class="default">PHP_EOL</span><span class="keyword">; </span><span class="comment">// Prints "static"<br /><br /></span><span class="default">$var </span><span class="keyword">= </span><span class="string">'Foo'</span><span class="keyword">;<br />echo </span><span class="default">$var</span><span class="keyword">::</span><span class="default">BAR </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">; </span><span class="comment">// Prints "const" in PHP 5.3.0, "Syntax error" in older versions<br /></span><span class="keyword">echo </span><span class="default">$var</span><span class="keyword">::</span><span class="default">bar</span><span class="keyword">() . </span><span class="default">PHP_EOL</span><span class="keyword">; </span><span class="comment">// Prints "static" in PHP 5.3.0, "Syntax error" in older versions<br /><br /></span><span class="default">$object </span><span class="keyword">= new </span><span class="default">stdClass</span><span class="keyword">;<br /></span><span class="default">$object</span><span class="keyword">-&gt;</span><span class="default">class </span><span class="keyword">= </span><span class="string">'Foo'</span><span class="keyword">; <br />echo </span><span class="default">$object</span><span class="keyword">-&gt;</span><span class="default">class</span><span class="keyword">::</span><span class="default">BAR </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">; </span><span class="comment">// "Syntax error" in PHP 5.3.0, prints "const" in PHP 7<br /></span><span class="keyword">echo </span><span class="default">$object</span><span class="keyword">-&gt;</span><span class="default">class</span><span class="keyword">::</span><span class="default">bar</span><span class="keyword">() . </span><span class="default">PHP_EOL</span><span class="keyword">; </span><span class="comment">// "Syntax error" in PHP 5.3.0, prints "static" in PHP 7<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="88394">  <div class="votes">
    <div id="Vu88394">
    <a href="/manual/vote-note.php?id=88394&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd88394">
    <a href="/manual/vote-note.php?id=88394&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V88394" title="40% like this...">
    -2
    </div>
  </div>
  <a href="#88394" class="name">
  <strong class="user"><em>yesmarklapointe at hotmail dot com</em></strong></a><a class="genanchor" href="#88394"> &para;</a><div class="date" title="2009-01-21 11:19"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom88394">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br /></span><span class="comment">// experiments with static<br />// tested on PHP 5.2.6&nbsp; on 1-21-09<br /><br /></span><span class="keyword">class </span><span class="default">User</span><span class="keyword">{<br />&nbsp; &nbsp; const </span><span class="default">GIVEN </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;&nbsp; </span><span class="comment">// class constants can't be labeled static nor assigned visibility<br />&nbsp; &nbsp; </span><span class="keyword">public </span><span class="default">$a</span><span class="keyword">=</span><span class="default">2</span><span class="keyword">;<br />&nbsp; &nbsp; public static </span><span class="default">$b</span><span class="keyword">=</span><span class="default">3</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">me</span><span class="keyword">(){ <br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"print me"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp;&nbsp; public static function </span><span class="default">you</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"print you"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">myUser </span><span class="keyword">extends </span><span class="default">User </span><span class="keyword">{<br />}<br /><br /></span><span class="comment">// Are properties and methods instantiated to an object of a class, &amp; are they accessible?<br />//$object1= new User();&nbsp; &nbsp; &nbsp; &nbsp; // uncomment this line with each of the following lines individually<br />//echo $object1-&gt;GIVEN . "&lt;/br&gt;";&nbsp; &nbsp; &nbsp; &nbsp; // yields nothing<br />//echo $object1-&gt;GIVE . "&lt;/br&gt;";&nbsp; &nbsp; &nbsp; &nbsp; //&nbsp; deliberately misnamed, still yields nothing<br />//echo $object1-&gt;User::GIVEN . "&lt;/br&gt;";&nbsp; &nbsp; // yields nothing<br />//echo $object1-&gt;a . "&lt;/br&gt;";&nbsp; &nbsp; &nbsp; &nbsp; // yields 2<br />//echo $object1-&gt;b . "&lt;/br&gt;";&nbsp; &nbsp; &nbsp; &nbsp; // yields nothing<br />//echo $object1-&gt;me() . "&lt;/br&gt;";&nbsp; &nbsp; &nbsp; &nbsp; // yields print me<br />//echo $object1-&gt;you() . "&lt;/br&gt;";&nbsp; &nbsp; &nbsp; &nbsp; // yields print you<br /><br />// Are&nbsp; properties and methods instantiated to an object of a child class,&nbsp; &amp; are accessible?<br />//$object2= new myUser();&nbsp; &nbsp; &nbsp; &nbsp; // uncomment this line with each of the following lines individually<br />//echo $object2-&gt;GIVEN . "&lt;/br&gt;";&nbsp; &nbsp; &nbsp; &nbsp; // yields nothing<br />//echo $object2-&gt;a . "&lt;/br&gt;";&nbsp; &nbsp; &nbsp; &nbsp; // yields 2<br />//echo $object2-&gt;b . "&lt;/br&gt;";&nbsp; &nbsp; &nbsp; &nbsp; // yields nothing<br />//echo $object2-&gt;me() . "&lt;/br&gt;";&nbsp; &nbsp; &nbsp; &nbsp; // yields print me<br />//echo $object2-&gt;you() . "&lt;/br&gt;";&nbsp; &nbsp; &nbsp; &nbsp; // yields print you<br /><br />// Are the properties and methods accessible directly in the class?<br />//echo User::GIVEN . "&lt;/br&gt;";&nbsp; &nbsp; &nbsp; &nbsp; // yields 1<br />//echo User::$a . "&lt;/br&gt;";&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; // yields fatal error since it is not static<br />//echo User::$b . "&lt;/br&gt;";&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; // yields 3<br />//echo User::me() . "&lt;/br&gt;";&nbsp; &nbsp; &nbsp; &nbsp; // yields print me<br />//echo User::you() . "&lt;/br&gt;";&nbsp; &nbsp; &nbsp; &nbsp; // yields print you<br /><br />// Are the properties and methods copied to the child class and are they accessible?<br />//echo myUser::GIVEN . "&lt;/br&gt;";&nbsp; &nbsp; &nbsp; &nbsp; // yields 1<br />//echo myUser::$a . "&lt;/br&gt;";&nbsp; &nbsp; &nbsp; &nbsp; // yields fatal error since it is not static<br />//echo myUser::$b . "&lt;/br&gt;";&nbsp; &nbsp; &nbsp; &nbsp; // yields 3<br />//echo myUser::me() . "&lt;/br&gt;";&nbsp; &nbsp; &nbsp; &nbsp; // yields print me<br />//echo myUser::you() . "&lt;/br&gt;";&nbsp; &nbsp; &nbsp; &nbsp; // yields print you<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="51640">  <div class="votes">
    <div id="Vu51640">
    <a href="/manual/vote-note.php?id=51640&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd51640">
    <a href="/manual/vote-note.php?id=51640&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V51640" title="40% like this...">
    -1
    </div>
  </div>
  <a href="#51640" class="name"><strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#51640"> &para;</a><div class="date" title="2005-04-06 03:14"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom51640">
<div class="phpcode"><code><span class="html">
You misunderstand the meaning of inheritance : there is no duplication of members when you inherit from a base class. Members are shared through inheritance, and can be accessed by derived classes according to visibility (public, protected, private).<br /><br />The difference between static and non static members is only that a non static member is tied to an instance of a class although a static member is tied to the class, and not to a particular instance.<br />That is, a static member is shared by all instances of a class although a non static member exists for each instance of&nbsp; class.<br /><br />Thus, in your example, the static property has the correct value, according to principles of object oriented conception.<br />class Base<br />{<br />&nbsp; public $a;<br />&nbsp; public static $b;<br />}<br /><br />class Derived extends Base<br />{<br />&nbsp; public function __construct()<br />&nbsp; {<br />&nbsp; &nbsp; $this-&gt;a = 0;<br />&nbsp; &nbsp; parent::$b = 0;<br />&nbsp; }<br />&nbsp; public function f()<br />&nbsp; {<br />&nbsp; &nbsp; $this-&gt;a++;<br />&nbsp; &nbsp; parent::$b++;<br />&nbsp; }<br />}<br /><br />$i1 = new Derived;<br />$i2 = new Derived;<br /><br />$i1-&gt;f();<br />echo $i1-&gt;a, ' ', Derived::$b, "\n";<br />$i2-&gt;f();<br />echo $i2-&gt;a, ' ', Derived::$b, "\n";<br /><br />outputs<br />1 1<br />1 2</span>
</code></div>
  </div>
 </div>
  <div class="note" id="49018">  <div class="votes">
    <div id="Vu49018">
    <a href="/manual/vote-note.php?id=49018&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd49018">
    <a href="/manual/vote-note.php?id=49018&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V49018" title="40% like this...">
    -1
    </div>
  </div>
  <a href="#49018" class="name">
  <strong class="user"><em>ference at super_delete_brose dot co dot uk</em></strong></a><a class="genanchor" href="#49018"> &para;</a><div class="date" title="2005-01-14 07:11"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom49018">
<div class="phpcode"><code><span class="html">
Both static and const fields can be accessed with the :: operator. However, while a constant can't be changed, this is not true for static variables.<br /><br />If you want to access an array using the :: operator you have to declare the array static, since you can't have a constant array. Beware:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">foo<br /></span><span class="keyword">{<br />&nbsp; static </span><span class="default">$stuff </span><span class="keyword">= array(</span><span class="string">'key1' </span><span class="keyword">=&gt; </span><span class="default">1</span><span class="keyword">, </span><span class="string">'key2' </span><span class="keyword">=&gt; </span><span class="default">2</span><span class="keyword">);<br />}<br /><br />class </span><span class="default">bar<br /></span><span class="keyword">{<br />&nbsp; public function </span><span class="default">__construct</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">foo</span><span class="keyword">::</span><span class="default">$stuff</span><span class="keyword">);<br />&nbsp; }<br />}<br /><br />class </span><span class="default">bad<br /></span><span class="keyword">{<br />&nbsp; public function </span><span class="default">__construct</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; </span><span class="default">foo</span><span class="keyword">::</span><span class="default">$stuff </span><span class="keyword">= </span><span class="default">FALSE</span><span class="keyword">;<br />&nbsp; }<br />}<br /><br />new </span><span class="default">bar</span><span class="keyword">();&nbsp; &nbsp; </span><span class="comment">// prints array(2) { ["key1"]=&gt; int(1) ["key2"]=&gt; int(2) }<br /><br /></span><span class="keyword">new </span><span class="default">bad</span><span class="keyword">();<br />new </span><span class="default">bar</span><span class="keyword">();&nbsp; &nbsp; </span><span class="comment">// prints bool(false)<br /></span><span class="default">?&gt;<br /></span><br />A safe implementation requires a little more effort:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">foo<br /></span><span class="keyword">{<br />&nbsp; private static </span><span class="default">$stuff </span><span class="keyword">= array(</span><span class="string">'key1' </span><span class="keyword">=&gt; </span><span class="default">1</span><span class="keyword">, </span><span class="string">'key2' </span><span class="keyword">=&gt; </span><span class="default">2</span><span class="keyword">);<br /><br />&nbsp; public final static function </span><span class="default">getstuff</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; return </span><span class="default">self</span><span class="keyword">::</span><span class="default">$stuff</span><span class="keyword">;<br />&nbsp; }<br />}<br /><br />class </span><span class="default">bar<br /></span><span class="keyword">{<br />&nbsp; public function </span><span class="default">__construct</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">foo</span><span class="keyword">::</span><span class="default">getstuff</span><span class="keyword">());<br />&nbsp; }<br />}<br /><br />class </span><span class="default">bad<br /></span><span class="keyword">{<br />&nbsp; public function </span><span class="default">__construct</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; </span><span class="default">foo</span><span class="keyword">::</span><span class="default">$stuff </span><span class="keyword">= </span><span class="default">FALSE</span><span class="keyword">;<br />&nbsp; }<br />}<br /><br />new </span><span class="default">bar</span><span class="keyword">();&nbsp; &nbsp; </span><span class="comment">// prints array(2) { ["key1"]=&gt; int(1) ["key2"]=&gt; int(2) }<br /></span><span class="keyword">new </span><span class="default">bad</span><span class="keyword">();&nbsp; &nbsp; </span><span class="comment">// results in a fatal error<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="51631">  <div class="votes">
    <div id="Vu51631">
    <a href="/manual/vote-note.php?id=51631&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd51631">
    <a href="/manual/vote-note.php?id=51631&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V51631" title="40% like this...">
    -2
    </div>
  </div>
  <a href="#51631" class="name">
  <strong class="user"><em>erikzoltan NOSPAM at msn NOSPAM dot com</em></strong></a><a class="genanchor" href="#51631"> &para;</a><div class="date" title="2005-04-05 05:50"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom51631">
<div class="phpcode"><code><span class="html">
I was doing this in a more complex example (than previous note) and found that I had to place the initialization statement AFTER the class in a file where I was using the __autoload function.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="47277">  <div class="votes">
    <div id="Vu47277">
    <a href="/manual/vote-note.php?id=47277&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd47277">
    <a href="/manual/vote-note.php?id=47277&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V47277" title="37% like this...">
    -2
    </div>
  </div>
  <a href="#47277" class="name">
  <strong class="user"><em>dmintz at davidmintz dot org</em></strong></a><a class="genanchor" href="#47277"> &para;</a><div class="date" title="2004-11-09 03:20"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom47277">
<div class="phpcode"><code><span class="html">
[Editor's Note: This is done for back compatability. Depending on your error level, An E_STRICT error will be thrown.]<br /><br />PHP 5.0.1 doesn't seem to mind if you call a static method in a non-static context, though it might not be the best of style to do so.<br /><br />On the other hand, PHP complains if you try to try to call a non-static method in a static context (if your error reporting is cranked up to E_STRICT).<br /><br />class Test {<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; static function static_method() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo "Here's your static method: Foo!&lt;br /&gt;\n";<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; function static_method_caller() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo "static_method_caller says:&nbsp; ";$this-&gt;static_method();&nbsp; &nbsp; <br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; function non_static() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo "I am not a static method&lt;br /&gt;\n";<br />&nbsp; &nbsp; }<br /><br />}<br /><br />$t = new Test();<br />$t-&gt;static_method();<br />$t-&gt;static_method_caller();<br />Test::non_static();</span>
</code></div>
  </div>
 </div>
  <div class="note" id="49036">  <div class="votes">
    <div id="Vu49036">
    <a href="/manual/vote-note.php?id=49036&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd49036">
    <a href="/manual/vote-note.php?id=49036&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V49036" title="33% like this...">
    -1
    </div>
  </div>
  <a href="#49036" class="name">
  <strong class="user"><em>c_daught_d at earthlink dot net</em></strong></a><a class="genanchor" href="#49036"> &para;</a><div class="date" title="2005-01-14 01:57"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom49036">
<div class="phpcode"><code><span class="html">
A twist on christian at koch dot net's Singleton example is setting/getting non-static member variables using self::$instance-&gt;varname within static method calls.<br /><br />Within the modified Singleton class below, the member variable $value is set within the getInstance static method instead of the constructor.<br /><br />Whether this is "pure" OPP, I don't know. But it does work, is worth mentioning, and could be usefull.<br /><br />class Singleton<br />{<br /><br />&nbsp; &nbsp; private static $instance=null;<br />&nbsp; &nbsp; private $value=null;<br /><br />&nbsp; &nbsp; private function __construct() {<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public static function getInstance() {<br />&nbsp; &nbsp; &nbsp; &nbsp; if ( self::$instance == null ) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo "&lt;br&gt;new&lt;br&gt;";<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; self::$instance = new Singleton("values");<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; self::$instance-&gt;value = "values";<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo "&lt;br&gt;old&lt;br&gt;";<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; return self::$instance;<br />&nbsp; &nbsp; }<br />}</span>
</code></div>
  </div>
 </div>
  <div class="note" id="58437">  <div class="votes">
    <div id="Vu58437">
    <a href="/manual/vote-note.php?id=58437&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd58437">
    <a href="/manual/vote-note.php?id=58437&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V58437" title="33% like this...">
    -2
    </div>
  </div>
  <a href="#58437" class="name">
  <strong class="user"><em>Jakob Schwendner</em></strong></a><a class="genanchor" href="#58437"> &para;</a><div class="date" title="2005-11-04 01:17"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom58437">
<div class="phpcode"><code><span class="html">
Here is my solution to the static search method problem for data objects. I found the debug_trace version posted earlier quite clever, but a little too risky. <br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Foo </span><span class="keyword">{<br />&nbsp; &nbsp; static function </span><span class="default">find</span><span class="keyword">(</span><span class="default">$class</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$obj </span><span class="keyword">= new </span><span class="default">$class</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$obj</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">Bar </span><span class="keyword">extends </span><span class="default">Foo </span><span class="keyword">{<br />&nbsp; &nbsp; static function </span><span class="default">find</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">parent</span><span class="keyword">::</span><span class="default">find</span><span class="keyword">(</span><span class="default">__CLASS__</span><span class="keyword">);<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; function </span><span class="default">print_hello</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo(</span><span class="string">"hello"</span><span class="keyword">);<br />&nbsp; &nbsp; }&nbsp; &nbsp; <br />}<br /><br /></span><span class="default">Bar</span><span class="keyword">::</span><span class="default">find</span><span class="keyword">()-&gt;</span><span class="default">print_hello</span><span class="keyword">();<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="97313">  <div class="votes">
    <div id="Vu97313">
    <a href="/manual/vote-note.php?id=97313&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd97313">
    <a href="/manual/vote-note.php?id=97313&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V97313" title="33% like this...">
    -6
    </div>
  </div>
  <a href="#97313" class="name">
  <strong class="user"><em>myselfasunder at gmail dot com</em></strong></a><a class="genanchor" href="#97313"> &para;</a><div class="date" title="2010-04-13 09:42"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom97313">
<div class="phpcode"><code><span class="html">
If you inadvertently call a non-static method in one class from another class, using $this in the former will actually refer to the wrong class.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">CalledClass<br /></span><span class="keyword">{<br />&nbsp; &nbsp; function </span><span class="default">go</span><span class="keyword">()<br />&nbsp; &nbsp; {<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; print(</span><span class="default">get_class</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">) . </span><span class="string">"\n"</span><span class="keyword">);<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">true</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">CallerClass<br /></span><span class="keyword">{<br />&nbsp; &nbsp; function </span><span class="default">go</span><span class="keyword">()<br />&nbsp; &nbsp; {<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">CalledClass</span><span class="keyword">::</span><span class="default">Go</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">true</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$obj </span><span class="keyword">= new </span><span class="default">CallerClass</span><span class="keyword">();<br /></span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">go</span><span class="keyword">();<br /><br /></span><span class="comment">// Output is "CallerClass" instead of "CalledClass" like it should be.<br /></span><span class="default">?&gt;<br /></span><br />Dustin Oprea</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113689">  <div class="votes">
    <div id="Vu113689">
    <a href="/manual/vote-note.php?id=113689&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113689">
    <a href="/manual/vote-note.php?id=113689&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113689" title="30% like this...">
    -5
    </div>
  </div>
  <a href="#113689" class="name">
  <strong class="user"><em>desmatic</em></strong></a><a class="genanchor" href="#113689"> &para;</a><div class="date" title="2013-11-16 09:40"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113689">
<div class="phpcode"><code><span class="html">
Don't use GLOBALS in classes (or anywhere really), use static variables instead.&nbsp; They're better. They can do everything a GLOBAL can and they can be protected by accessor functions so they'll never get clobbered.<br /><br />class foo {<br /><br />&nbsp; private static $_private = null;<br />&nbsp; <br />&nbsp; public function get() {<br />&nbsp; &nbsp; if (self::$_private === null) {<br />&nbsp; &nbsp; &nbsp; self::$_private = new stdClass();<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; return self::$_private;<br />&nbsp; }<br /><br />}<br /><br />class bar extends foo {<br /><br />}<br /><br />function scope_foo() {<br />&nbsp; $f = new foo();<br />&nbsp; $f-&gt;get()-&gt;name = "superdude";<br />}<br /><br />function scope_bar() {<br />&nbsp; $b = new bar();<br />&nbsp; $b-&gt;get()-&gt;description = "an object reference test";<br />}<br /><br />scope_foo();<br />scope_bar();<br /><br />$my = new bar();<br />foreach ($my-&gt;get() as $key =&gt; $value) {<br />&nbsp; echo "{$key} =&gt; {$value}\n";<br />}<br /><br />outputs:<br />name =&gt; superdude<br />description =&gt; an object reference test</span>
</code></div>
  </div>
 </div>
  <div class="note" id="115348">  <div class="votes">
    <div id="Vu115348">
    <a href="/manual/vote-note.php?id=115348&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115348">
    <a href="/manual/vote-note.php?id=115348&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115348" title="28% like this...">
    -3
    </div>
  </div>
  <a href="#115348" class="name">
  <strong class="user"><em>ianromie at gmail dot com</em></strong></a><a class="genanchor" href="#115348"> &para;</a><div class="date" title="2014-07-09 09:18"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115348">
<div class="phpcode"><code><span class="html">
class A {<br />&nbsp; &nbsp;&nbsp; public static function getName(){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo "My Name";<br />&nbsp; &nbsp;&nbsp; }<br />&nbsp; &nbsp;&nbsp; public static function getAge(){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return "22";<br />&nbsp; &nbsp;&nbsp; }<br />}<br />A::getName();<br />echo A::getAge();</span>
</code></div>
  </div>
 </div>
  <div class="note" id="51627">  <div class="votes">
    <div id="Vu51627">
    <a href="/manual/vote-note.php?id=51627&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd51627">
    <a href="/manual/vote-note.php?id=51627&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V51627" title="31% like this...">
    -6
    </div>
  </div>
  <a href="#51627" class="name">
  <strong class="user"><em>erikzoltan NOSPAM at msn NOSPAM dot com</em></strong></a><a class="genanchor" href="#51627"> &para;</a><div class="date" title="2005-04-05 03:40"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom51627">
<div class="phpcode"><code><span class="html">
I had trouble getting a static member to be an instance of a class.&nbsp; Here's a code example that DOESN'T work.&nbsp; <br /><br /><span class="default">&lt;?php<br /><br /></span><span class="comment">// This doesn't work.<br /><br /></span><span class="keyword">class </span><span class="default">XYZ<br /></span><span class="keyword">{<br />&nbsp; &nbsp; </span><span class="comment">// The following line will throw a syntax error.<br />&nbsp; &nbsp; </span><span class="keyword">public static </span><span class="default">$ABC </span><span class="keyword">= new </span><span class="default">ABC</span><span class="keyword">();<br />}<br /><br />class </span><span class="default">ABC<br /></span><span class="keyword">{<br />}<br /><br /></span><span class="default">$myXyz </span><span class="keyword">= new </span><span class="default">XYZ</span><span class="keyword">();<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$myXyz</span><span class="keyword">);<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">XYZ</span><span class="keyword">::</span><span class="default">$ABC</span><span class="keyword">);<br /><br /></span><span class="default">?&gt;<br /></span><br />I get the following entry in my error log.&nbsp; <br /><br />[05-Apr-2005 18:27:41] PHP Parse error: syntax error, unexpected T_NEW in staticTest.php on line 7<br /><br />Since PHP doesn't appear to allow static constructor methods, I was only able to resolve this problem by moving the initialization outside of the class.&nbsp; To make my code more self-documenting I put it above the class.&nbsp; The revised example below appears to work.&nbsp; <br /><br /><span class="default">&lt;?php<br /><br /></span><span class="comment">// This will work.<br /><br />// Moved the static variable's initialization logic outside the class.&nbsp; <br /></span><span class="default">XYZ</span><span class="keyword">::</span><span class="default">$ABC </span><span class="keyword">= new </span><span class="default">ABC</span><span class="keyword">();<br /><br />class </span><span class="default">XYZ<br /></span><span class="keyword">{<br />&nbsp; &nbsp; </span><span class="comment">// I'm just declaring the static variable here, but I'm not initializing it.<br />&nbsp; &nbsp; </span><span class="keyword">public static </span><span class="default">$ABC</span><span class="keyword">;<br />}<br /><br />class </span><span class="default">ABC<br /></span><span class="keyword">{<br />}<br /><br /></span><span class="default">$myXyz </span><span class="keyword">= new </span><span class="default">XYZ</span><span class="keyword">();<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$myXyz</span><span class="keyword">);<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">XYZ</span><span class="keyword">::</span><span class="default">$ABC</span><span class="keyword">);<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="81572">  <div class="votes">
    <div id="Vu81572">
    <a href="/manual/vote-note.php?id=81572&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd81572">
    <a href="/manual/vote-note.php?id=81572&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V81572" title="25% like this...">
    -4
    </div>
  </div>
  <a href="#81572" class="name">
  <strong class="user"><em>Siarhei</em></strong></a><a class="genanchor" href="#81572"> &para;</a><div class="date" title="2008-03-04 05:25"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom81572">
<div class="phpcode"><code><span class="html">
There is a problem to make static property shared only for objects of self class not defining it in every child class. <br /><br />Example:<br /><br />class a<br />{<br />&nbsp; public static $s;<br />&nbsp; <br />&nbsp; public function get()<br />&nbsp; {<br />&nbsp; &nbsp; return self::$s;<br />&nbsp; }<br />}<br /><br />class b extends a { }<br /><br />class c extends b { }<br /><br />a::$s = 'a';<br /><br />$c = new c();<br />echo $c-&gt;get(); // a<br /><br />There is solution i found:<br /><br />class a<br />{<br />&nbsp; public final function v($vs = null)<br />&nbsp; {<br />&nbsp; &nbsp; static $s = null;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; if(!is_null($vs))<br />&nbsp; &nbsp; $s = $vs;<br /><br />&nbsp; &nbsp; return $s;<br />&nbsp; }<br />}<br /><br />class b extends a { }<br /><br />class c extends b { }<br /><br />$a = new a();<br />$a-&gt;v('a');<br /><br />$aa = new a();<br />$aa-&gt;v('last a');<br /><br />$c = new c();<br />$c-&gt;v('c');<br /><br />echo $a-&gt;v().' - '.$c-&gt;v(); // last a - c</span>
</code></div>
  </div>
 </div>
  <div class="note" id="48234">  <div class="votes">
    <div id="Vu48234">
    <a href="/manual/vote-note.php?id=48234&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd48234">
    <a href="/manual/vote-note.php?id=48234&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V48234" title="25% like this...">
    -2
    </div>
  </div>
  <a href="#48234" class="name">
  <strong class="user"><em>michael at digitalgnosis dot removethis dot com</em></strong></a><a class="genanchor" href="#48234"> &para;</a><div class="date" title="2004-12-15 11:41"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom48234">
<div class="phpcode"><code><span class="html">
Here's another way to do the same thing (see my post below) without having to muck up your Foo() function's parameters in the Base and all Derived classes.<br /><br />However, you cannot use static, and still must define Foo() in derived classes.&nbsp; This way also performs slower and may not always work--but it DOES make for prettier code.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">Base<br /></span><span class="keyword">{<br />&nbsp; &nbsp; function </span><span class="default">Foo </span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$call </span><span class="keyword">= </span><span class="default">debug_backtrace</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">call_user_func</span><span class="keyword">(array(</span><span class="default">$call</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">][</span><span class="string">'class'</span><span class="keyword">],</span><span class="string">'Bar'</span><span class="keyword">));<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">Derived </span><span class="keyword">extends </span><span class="default">Base<br /></span><span class="keyword">{<br />&nbsp; &nbsp; function </span><span class="default">Foo </span><span class="keyword">() { </span><span class="default">parent</span><span class="keyword">::</span><span class="default">Foo</span><span class="keyword">(); }<br /><br />&nbsp; &nbsp; function </span><span class="default">Bar </span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Derived::Bar()"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">Derived</span><span class="keyword">::</span><span class="default">Foo</span><span class="keyword">();<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118306">  <div class="votes">
    <div id="Vu118306">
    <a href="/manual/vote-note.php?id=118306&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118306">
    <a href="/manual/vote-note.php?id=118306&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118306" title="20% like this...">
    -3
    </div>
  </div>
  <a href="#118306" class="name">
  <strong class="user"><em>rahul dot anand77 at gmail dot com</em></strong></a><a class="genanchor" href="#118306"> &para;</a><div class="date" title="2015-11-13 10:39"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom118306">
<div class="phpcode"><code><span class="html">
To check if a method declared in a class is static or not, you can us following code. PHP5 has a Reflection Class, which is very helpful. <br /><br />try {<br />&nbsp; &nbsp; $method = new ReflectionMethod( 'className::methodName );<br />&nbsp; &nbsp; if ( $method-&gt;isStatic() )<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; // Method is static.<br />&nbsp; &nbsp; }<br />}<br />catch ( ReflectionException $e )<br />{<br />&nbsp; &nbsp; //&nbsp; &nbsp; method does not exist<br />&nbsp; &nbsp; echo $e-&gt;getMessage();<br />}<br /><br />*You can read more about Reflection class on <a href="http://php.net/manual/en/class.reflectionclass.php" rel="nofollow" target="_blank">http://php.net/manual/en/class.reflectionclass.php</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="86433">  <div class="votes">
    <div id="Vu86433">
    <a href="/manual/vote-note.php?id=86433&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86433">
    <a href="/manual/vote-note.php?id=86433&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86433" title="20% like this...">
    -3
    </div>
  </div>
  <a href="#86433" class="name">
  <strong class="user"><em>wbcarts at juno dot com</em></strong></a><a class="genanchor" href="#86433"> &para;</a><div class="date" title="2008-10-18 10:24"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86433">
<div class="phpcode"><code><span class="html">
[NB: This is a copy of the note by juno dot com on 11-Sep-2008 04:53, but with syntax highlighting.]<br /><br />A CLASS WITH MEAT ON IT'S BONES...<br /><br />I have yet to see an example that I can really get my chops into. So I am offering an example that I hope will satisfy most of us.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">RubberBall<br /></span><span class="keyword">{<br />&nbsp; </span><span class="comment">/*<br />&nbsp;&nbsp; * ALLOW these properties to be inherited TO extending classes - that's<br />&nbsp;&nbsp; * why they're not private.<br />&nbsp;&nbsp; *<br />&nbsp;&nbsp; * DO NOT ALLOW outside code to access with 'RubberBall::$property_name' - <br />&nbsp;&nbsp; * that's why they're not public.<br />&nbsp;&nbsp; *<br />&nbsp;&nbsp; * Outside code should use:<br />&nbsp;&nbsp; *&nbsp; - RubberBall::getCount()<br />&nbsp;&nbsp; *&nbsp; - RubberBall::setStart()<br />&nbsp;&nbsp; * These are the only routines outside code can use - very limited indeed.<br />&nbsp;&nbsp; *<br />&nbsp;&nbsp; * Inside code has unlimited access by using self::$property_name.<br />&nbsp;&nbsp; *<br />&nbsp;&nbsp; * All RubberBall instances will share a "single copy" of these properties - that's<br />&nbsp;&nbsp; * why they're static.<br />&nbsp;&nbsp; */<br />&nbsp; </span><span class="keyword">protected static </span><span class="default">$count </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />&nbsp; protected static </span><span class="default">$start </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />&nbsp; protected static </span><span class="default">$colors </span><span class="keyword">= array(</span><span class="string">'red'</span><span class="keyword">,</span><span class="string">'yellow'</span><span class="keyword">,</span><span class="string">'blue'</span><span class="keyword">,</span><span class="string">'orange'</span><span class="keyword">, </span><span class="string">'green'</span><span class="keyword">, </span><span class="string">'white'</span><span class="keyword">);<br />&nbsp; protected static </span><span class="default">$sizes </span><span class="keyword">= array(</span><span class="default">4</span><span class="keyword">, </span><span class="default">6</span><span class="keyword">, </span><span class="default">8</span><span class="keyword">, </span><span class="default">10</span><span class="keyword">, </span><span class="default">12</span><span class="keyword">, </span><span class="default">16</span><span class="keyword">);<br /><br />&nbsp; public </span><span class="default">$name</span><span class="keyword">;<br />&nbsp; public </span><span class="default">$color</span><span class="keyword">;<br />&nbsp; public </span><span class="default">$size</span><span class="keyword">;<br /><br />&nbsp; public function </span><span class="default">__construct</span><span class="keyword">(){<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">name </span><span class="keyword">= </span><span class="string">'RB_' </span><span class="keyword">. </span><span class="default">self</span><span class="keyword">::</span><span class="default">$start</span><span class="keyword">++;<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">color </span><span class="keyword">= (int) </span><span class="default">rand</span><span class="keyword">(</span><span class="default">0</span><span class="keyword">, </span><span class="default">5</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">size </span><span class="keyword">= </span><span class="default">self</span><span class="keyword">::</span><span class="default">$sizes</span><span class="keyword">[(int) </span><span class="default">rand</span><span class="keyword">(</span><span class="default">0</span><span class="keyword">, </span><span class="default">5</span><span class="keyword">)];<br />&nbsp; &nbsp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">$count</span><span class="keyword">++;<br />&nbsp; }<br /><br />&nbsp; public static function </span><span class="default">getCount</span><span class="keyword">(){<br />&nbsp; &nbsp; return </span><span class="default">self</span><span class="keyword">::</span><span class="default">$count</span><span class="keyword">;<br />&nbsp; }<br /><br />&nbsp; public static function </span><span class="default">setStart</span><span class="keyword">(</span><span class="default">$val</span><span class="keyword">){<br />&nbsp; &nbsp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">$start </span><span class="keyword">= </span><span class="default">$val</span><span class="keyword">;<br />&nbsp; }<br /><br />&nbsp; </span><span class="comment">/*<br />&nbsp;&nbsp; * Define the sorting rules for RubberBalls - which is to sort by self::$colors.<br />&nbsp;&nbsp; * PHP's usort() method will call this function many many times.<br />&nbsp;&nbsp; */<br />&nbsp; </span><span class="keyword">public static function </span><span class="default">compare</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">){<br />&nbsp; &nbsp; if(</span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">color </span><span class="keyword">&lt; </span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">color</span><span class="keyword">) return -</span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; else if(</span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">color </span><span class="keyword">== </span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">color</span><span class="keyword">) return </span><span class="default">0</span><span class="keyword">;<br />&nbsp; &nbsp; else return </span><span class="default">1</span><span class="keyword">;<br />&nbsp; }<br /><br />&nbsp; public function </span><span class="default">__toString</span><span class="keyword">(){<br />&nbsp; &nbsp; return </span><span class="string">"RubberBall[<br />&nbsp; &nbsp; &nbsp; name=</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">name</span><span class="string">, <br />&nbsp; &nbsp; &nbsp; color=" </span><span class="keyword">. </span><span class="default">self</span><span class="keyword">::</span><span class="default">$colors</span><span class="keyword">[</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">color</span><span class="keyword">] . </span><span class="string">", <br />&nbsp; &nbsp; &nbsp; size=" </span><span class="keyword">. </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">size </span><span class="keyword">. </span><span class="string">"\"]"</span><span class="keyword">; <br />&nbsp; }<br />}<br /><br /></span><span class="comment"># RubberBall counts the number of objects created, but allows us to <br /># set the starting count like so:<br /></span><span class="default">RubberBall</span><span class="keyword">::</span><span class="default">setStart</span><span class="keyword">(</span><span class="default">100</span><span class="keyword">);<br /><br /></span><span class="comment"># create a PHP Array and initialize it with (12) RubberBall objects<br /></span><span class="default">$balls </span><span class="keyword">= array();<br />for(</span><span class="default">$i </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">; </span><span class="default">$i </span><span class="keyword">&lt; </span><span class="default">12</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">++) </span><span class="default">$balls</span><span class="keyword">[] = new </span><span class="default">RubberBall</span><span class="keyword">();<br /><br /></span><span class="comment"># sort the RubberBall objects. PHP's usort() calls RubberBall::compare() to do this.<br /></span><span class="default">usort</span><span class="keyword">(</span><span class="default">$balls</span><span class="keyword">, array(</span><span class="string">"RubberBall"</span><span class="keyword">, </span><span class="string">"compare"</span><span class="keyword">));<br /><br /></span><span class="comment"># print the sorted results - uses the static RubberBall::getCount().<br /></span><span class="keyword">echo </span><span class="string">'RubberBall count: ' </span><span class="keyword">. </span><span class="default">RubberBall</span><span class="keyword">::</span><span class="default">getCount</span><span class="keyword">() . </span><span class="string">'&lt;br&gt;&lt;br&gt;'</span><span class="keyword">;<br />foreach(</span><span class="default">$balls </span><span class="keyword">as </span><span class="default">$ball</span><span class="keyword">) echo </span><span class="default">$ball </span><span class="keyword">. </span><span class="string">'&lt;br&gt;'</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;<br /></span><br />I'm running out of room so I have not displayed the output, but it is tested and it works great.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="85663">  <div class="votes">
    <div id="Vu85663">
    <a href="/manual/vote-note.php?id=85663&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd85663">
    <a href="/manual/vote-note.php?id=85663&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V85663" title="16% like this...">
    -4
    </div>
  </div>
  <a href="#85663" class="name">
  <strong class="user"><em>wbcarts at juno dot com</em></strong></a><a class="genanchor" href="#85663"> &para;</a><div class="date" title="2008-09-10 08:53"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom85663">
<div class="phpcode"><code><span class="html">
A CLASS WITH MEAT ON IT'S BONES...<br /><br />I have yet to see an example that I can really get my chops into. So I am offering an example that I hope will satisfy most of us.<br /><br />class RubberBall<br />{<br />&nbsp; /*<br />&nbsp;&nbsp; * ALLOW these properties to be inherited TO extending classes - that's<br />&nbsp;&nbsp; * why they're not private.<br />&nbsp;&nbsp; *<br />&nbsp;&nbsp; * DO NOT ALLOW outside code to access with 'RubberBall::$property_name' - <br />&nbsp;&nbsp; * that's why they're not public.<br />&nbsp;&nbsp; *<br />&nbsp;&nbsp; * Outside code should use:<br />&nbsp;&nbsp; *&nbsp; - RubberBall::getCount()<br />&nbsp;&nbsp; *&nbsp; - RubberBall::setStart()<br />&nbsp;&nbsp; * These are the only routines outside code can use - very limited indeed.<br />&nbsp;&nbsp; *<br />&nbsp;&nbsp; * Inside code has unlimited access by using self::$property_name.<br />&nbsp;&nbsp; *<br />&nbsp;&nbsp; * All RubberBall instances will share a "single copy" of these properties - that's<br />&nbsp;&nbsp; * why they're static.<br />&nbsp;&nbsp; */<br />&nbsp; protected static $count = 0;<br />&nbsp; protected static $start = 1;<br />&nbsp; protected static $colors = array('red','yellow','blue','orange', 'green', 'white');<br />&nbsp; protected static $sizes = array(4, 6, 8, 10, 12, 16);<br /><br />&nbsp; public $name;<br />&nbsp; public $color;<br />&nbsp; public $size;<br /><br />&nbsp; public function __construct(){<br />&nbsp; &nbsp; $this-&gt;name = 'RB_' . self::$start++;<br />&nbsp; &nbsp; $this-&gt;color = (int) rand(0, 5);<br />&nbsp; &nbsp; $this-&gt;size = self::$sizes[(int) rand(0, 5)];<br />&nbsp; &nbsp; self::$count++;<br />&nbsp; }<br /><br />&nbsp; public static function getCount(){<br />&nbsp; &nbsp; return self::$count;<br />&nbsp; }<br /><br />&nbsp; public static function setStart($val){<br />&nbsp; &nbsp; self::$start = $val;<br />&nbsp; }<br /><br />&nbsp; /*<br />&nbsp;&nbsp; * Define the sorting rules for RubberBalls - which is to sort by self::$colors.<br />&nbsp;&nbsp; * PHP's usort() method will call this function many many times.<br />&nbsp;&nbsp; */<br />&nbsp; public static function compare($a, $b){<br />&nbsp; &nbsp; if($a-&gt;color &lt; $b-&gt;color) return -1;<br />&nbsp; &nbsp; else if($a-&gt;color == $b-&gt;color) return 0;<br />&nbsp; &nbsp; else return 1;<br />&nbsp; }<br /><br />&nbsp; public function __toString(){<br />&nbsp; &nbsp; return "RubberBall[<br />&nbsp; &nbsp; &nbsp; name=$this-&gt;name, <br />&nbsp; &nbsp; &nbsp; color=" . self::$colors[$this-&gt;color] . ", <br />&nbsp; &nbsp; &nbsp; size=" . $this-&gt;size . "\"]"; <br />&nbsp; }<br />}<br /><br /># RubberBall counts the number of objects created, but allows us to <br /># set the starting count like so:<br />RubberBall::setStart(100);<br /><br /># create a PHP Array and initialize it with (12) RubberBall objects<br />$balls = array();<br />for($i = 0; $i &lt; 12; $i++) $balls[] = new RubberBall();<br /><br /># sort the RubberBall objects. PHP's usort() calls RubberBall::compare() to do this.<br />usort($balls, array("RubberBall", "compare"));<br /><br /># print the sorted results - uses the static RubberBall::getCount().<br />echo 'RubberBall count: ' . RubberBall::getCount() . '&lt;br&gt;&lt;br&gt;';<br />foreach($balls as $ball) echo $ball . '&lt;br&gt;';<br /><br />I'm running out of room so I have not displayed the output, but it is tested and it works great.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="76989">  <div class="votes">
    <div id="Vu76989">
    <a href="/manual/vote-note.php?id=76989&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd76989">
    <a href="/manual/vote-note.php?id=76989&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V76989" title="16% like this...">
    -4
    </div>
  </div>
  <a href="#76989" class="name">
  <strong class="user"><em>Clment Genzmer</em></strong></a><a class="genanchor" href="#76989"> &para;</a><div class="date" title="2007-08-09 01:54"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom76989">
<div class="phpcode"><code><span class="html">
The best solution I found for the non-inherited static problem : pass the name of the class.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">A </span><span class="keyword">{<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public static </span><span class="default">$my_vars </span><span class="keyword">= </span><span class="string">"I'm in A"</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; static function </span><span class="default">find</span><span class="keyword">(</span><span class="default">$class</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$vars </span><span class="keyword">= </span><span class="default">get_class_vars</span><span class="keyword">(</span><span class="default">$class</span><span class="keyword">) ;<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; echo </span><span class="default">$vars</span><span class="keyword">[</span><span class="string">'my_vars'</span><span class="keyword">] ;<br />&nbsp; &nbsp; }<br />}<br />class </span><span class="default">B </span><span class="keyword">extends </span><span class="default">A </span><span class="keyword">{<br />&nbsp; &nbsp;&nbsp; public static </span><span class="default">$my_vars </span><span class="keyword">= </span><span class="string">"I'm in B"</span><span class="keyword">;<br />}<br /><br /></span><span class="default">B</span><span class="keyword">::</span><span class="default">find</span><span class="keyword">(</span><span class="string">"B"</span><span class="keyword">);<br /></span><span class="comment">// Result : "I'm in B"<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="98646">  <div class="votes">
    <div id="Vu98646">
    <a href="/manual/vote-note.php?id=98646&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd98646">
    <a href="/manual/vote-note.php?id=98646&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V98646" title="11% like this...">
    -7
    </div>
  </div>
  <a href="#98646" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#98646"> &para;</a><div class="date" title="2010-06-28 06:49"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom98646">
<div class="phpcode"><code><span class="html">
I can't find anything in the PHP manual about this, but the new-ish E_STRICT error reporting will complain if an inherited class overrides a static method with a different call signature (usually a parameter list). Ironically, it seems to only be a problem of 'coding style' because the code works correctly and has done for quite a few versions. <br /><br />The exact error is "Strict Standards: Declaration of [child-class]::[method]() should be compatible with that of [parent-class]::[method]()". <br /><br />So if you must code with E_STRICT enabled, you need to rename the method name.<br /><br />Google shows that this is biting *a lot* of people. (Bugs have been filed, but there has been no response yet.)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="92148">  <div class="votes">
    <div id="Vu92148">
    <a href="/manual/vote-note.php?id=92148&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd92148">
    <a href="/manual/vote-note.php?id=92148&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V92148" title="7% like this...">
    -11
    </div>
  </div>
  <a href="#92148" class="name">
  <strong class="user"><em>sep16 at psu dot edu</em></strong></a><a class="genanchor" href="#92148"> &para;</a><div class="date" title="2009-07-10 12:32"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom92148">
<div class="phpcode"><code><span class="html">
I find having class variables useful for inherited classes, especially when inheriting abstract classes, yet self:: doesn't refer to the class calling the method, rather the actual class in which it was defined.&nbsp; Although it is less memory efficient, this can be circumvented with instance properties, but sometimes even this won't work, i.e., when using resources like class-wide database or prepared statement handles.<br /><br />The pre-5.3.0 way that I used to get around this limitation was to write a class that stores a central value and sets instance properties as references to this value.&nbsp; In this way objects can have access to the same value while still being able to use inherited methods that reference this property.<br /><br />Usage example:<br /><span class="default">&lt;?php </span><span class="comment">// (SharedPropertyClass is defined below)<br /></span><span class="keyword">class </span><span class="default">Foo </span><span class="keyword">extends </span><span class="default">SharedPropertyClass </span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$foo </span><span class="keyword">= </span><span class="string">"bar"</span><span class="keyword">;<br />&nbsp; &nbsp; public function </span><span class="default">showFoo</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">foo</span><span class="keyword">, </span><span class="string">"\n"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br />class </span><span class="default">FooToo </span><span class="keyword">extends </span><span class="default">Foo </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">makeShared</span><span class="keyword">(</span><span class="string">'foo'</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$ojjo </span><span class="keyword">= new </span><span class="default">FooToo</span><span class="keyword">;<br /></span><span class="default">$ojjo</span><span class="keyword">-&gt;</span><span class="default">showFoo</span><span class="keyword">(); </span><span class="comment">// "bar"<br /><br /></span><span class="default">$xjjx </span><span class="keyword">= new </span><span class="default">FooToo</span><span class="keyword">;<br /></span><span class="default">$xjjx</span><span class="keyword">-&gt;</span><span class="default">showFoo</span><span class="keyword">(); </span><span class="comment">// "bar"<br /><br /></span><span class="default">$ojjo</span><span class="keyword">-&gt;</span><span class="default">foo </span><span class="keyword">= </span><span class="string">"new"</span><span class="keyword">;<br /></span><span class="default">$ojjo</span><span class="keyword">-&gt;</span><span class="default">showFoo</span><span class="keyword">(); </span><span class="comment">// "new"<br /></span><span class="default">$xjjx</span><span class="keyword">-&gt;</span><span class="default">showFoo</span><span class="keyword">(); </span><span class="comment">// "new"<br /></span><span class="default">?&gt;<br /></span><br />Notice how the showFoo() method, while defined in the parent class, correctly uses the child class's "foo" property (unlike self:: would), and how the "foo" property is shared by all instances of FooToo objects (like a static property).&nbsp; This is essentially how the new static:: keyword will work, and how most people probably expected the self:: keyword to work.<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">// ---------------------------------------------------------------<br /></span><span class="keyword">abstract class </span><span class="default">SharedPropertyClass </span><span class="keyword">{<br /></span><span class="comment">// ---------------------------------------------------------------<br />/*<br />&nbsp; &nbsp; Shared properties should be declared as such in the<br />&nbsp; &nbsp; constructor function of the inheriting class.<br /><br />&nbsp; &nbsp; The first instance will have the shared property set to<br />&nbsp; &nbsp; the value in the class definition, if any, otherwise null.<br />&nbsp; &nbsp; All subsequent instances will also have their shared<br />&nbsp; &nbsp; property set as a reference to that variable.<br /><br />*/<br />&nbsp; &nbsp; </span><span class="keyword">private static </span><span class="default">$shared </span><span class="keyword">= array();<br />&nbsp; &nbsp; public function </span><span class="default">makeShared</span><span class="keyword">(</span><span class="default">$property</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$class </span><span class="keyword">= </span><span class="default">get_class</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; if (!</span><span class="default">property_exists</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">,</span><span class="default">$property</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">trigger_error</span><span class="keyword">(</span><span class="string">"Access to undeclared property "<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">. </span><span class="string">"'</span><span class="default">$property</span><span class="string">' in class </span><span class="default">$class</span><span class="string">."</span><span class="keyword">,</span><span class="default">E_USER_ERROR</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; if (!</span><span class="default">array_key_exists</span><span class="keyword">(</span><span class="default">$class</span><span class="keyword">,</span><span class="default">self</span><span class="keyword">::</span><span class="default">$shared</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">$shared</span><span class="keyword">[</span><span class="default">$class</span><span class="keyword">] = array();<br />&nbsp; &nbsp; &nbsp; &nbsp; if (!</span><span class="default">array_key_exists</span><span class="keyword">(</span><span class="default">$property</span><span class="keyword">,</span><span class="default">self</span><span class="keyword">::</span><span class="default">$shared</span><span class="keyword">[</span><span class="default">$class</span><span class="keyword">]))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">$shared</span><span class="keyword">[</span><span class="default">$class</span><span class="keyword">][</span><span class="default">$property</span><span class="keyword">]<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; = isset(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$property</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ? </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$property<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">: </span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">$property </span><span class="keyword">=&amp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">$shared</span><span class="keyword">[</span><span class="default">$class</span><span class="keyword">][</span><span class="default">$property</span><span class="keyword">];<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public function </span><span class="default">isShared</span><span class="keyword">(</span><span class="default">$property</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$class </span><span class="keyword">= </span><span class="default">get_class</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; if (!</span><span class="default">property_exists</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">,</span><span class="default">$property</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">trigger_error</span><span class="keyword">(</span><span class="string">"Access to undeclared property "<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">. </span><span class="string">"'</span><span class="default">$property</span><span class="string">' in class </span><span class="default">$class</span><span class="string">."</span><span class="keyword">,</span><span class="default">E_USER_ERROR</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">array_key_exists</span><span class="keyword">(</span><span class="default">$class</span><span class="keyword">,</span><span class="default">self</span><span class="keyword">::</span><span class="default">$shared</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &amp;&amp; </span><span class="default">array_key_exists</span><span class="keyword">(</span><span class="default">$property</span><span class="keyword">, </span><span class="default">self</span><span class="keyword">::</span><span class="default">$shared</span><span class="keyword">[</span><span class="default">$class</span><span class="keyword">]);<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114647">  <div class="votes">
    <div id="Vu114647">
    <a href="/manual/vote-note.php?id=114647&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114647">
    <a href="/manual/vote-note.php?id=114647&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114647" title="0% like this...">
    -6
    </div>
  </div>
  <a href="#114647" class="name">
  <strong class="user"><em>Denis Ribeiro - dpr001 at gmail dot com</em></strong></a><a class="genanchor" href="#114647"> &para;</a><div class="date" title="2014-03-16 02:23"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114647">
<div class="phpcode"><code><span class="html">
Other point is that static methods just can access static properties, because the pseudo variable $this not exists in this scope like example below:<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">//is wrong, because the static methods can only access static properties<br /></span><span class="keyword">class </span><span class="default">Foo </span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$property</span><span class="keyword">;<br />&nbsp; &nbsp; public static function </span><span class="default">aStaticMethod</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Accessing the property: </span><span class="keyword">{</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">property</span><span class="keyword">}</span><span class="string">"</span><span class="keyword">; </span><span class="comment">//Fatal error:Using $this<br />&nbsp; &nbsp; </span><span class="keyword">}<br />}<br /><br /></span><span class="default">Foo</span><span class="keyword">::</span><span class="default">aStaticMethod</span><span class="keyword">();<br /></span><span class="default">$classname </span><span class="keyword">= </span><span class="string">'Foo'</span><span class="keyword">;<br /></span><span class="default">$classname</span><span class="keyword">::</span><span class="default">aStaticMethod</span><span class="keyword">(); </span><span class="comment">// As of PHP 5.3.0<br /><br />//Note that property $property is static and then can be using the word self instead of pseudo variable $this<br /></span><span class="keyword">class </span><span class="default">Foo2 </span><span class="keyword">{<br />&nbsp; &nbsp; static </span><span class="default">$property </span><span class="keyword">= </span><span class="string">'test'</span><span class="keyword">;<br />&nbsp; &nbsp; public static function </span><span class="default">aStaticMethod</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Accessing the property: "</span><span class="keyword">. </span><span class="default">self</span><span class="keyword">::</span><span class="default">$property</span><span class="keyword">; </span><span class="comment">//Accessing the property: test<br />&nbsp; &nbsp; </span><span class="keyword">}<br />}<br /><br /></span><span class="default">Foo2</span><span class="keyword">::</span><span class="default">aStaticMethod</span><span class="keyword">();</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="105300">  <div class="votes">
    <div id="Vu105300">
    <a href="/manual/vote-note.php?id=105300&amp;page=language.oop5.static&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd105300">
    <a href="/manual/vote-note.php?id=105300&amp;page=language.oop5.static&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V105300" title="0% like this...">
    -5
    </div>
  </div>
  <a href="#105300" class="name">
  <strong class="user"><em>programmer-comfreek at hotmail dot com</em></strong></a><a class="genanchor" href="#105300"> &para;</a><div class="date" title="2011-08-08 07:40"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom105300">
<div class="phpcode"><code><span class="html">
If you haven't an instance for your class (e.g. all functions are static), but you also want a __destruct() functionality, consider the following example:<br /><br />We have a class which loads and saves data so we also want to have an autosave mechanism which is called at the end of the PHP script.<br /><br />So usually you declare a __destruct function but our class is designed to provide static functions / variables instead:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">A<br /></span><span class="keyword">{<br />&nbsp; static private </span><span class="default">$autoSave</span><span class="keyword">;<br />&nbsp; static public function </span><span class="default">init</span><span class="keyword">(</span><span class="default">$autoSave</span><span class="keyword">)<br />&nbsp; {<br />&nbsp; &nbsp; </span><span class="comment">/* emulating __construct() */<br />&nbsp; &nbsp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">$autoSave </span><span class="keyword">= </span><span class="default">$autoSave</span><span class="keyword">;<br />&nbsp; }<br />&nbsp; static public function </span><span class="default">save</span><span class="keyword">() { </span><span class="comment">/*...*/ </span><span class="keyword">} </span><span class="comment">/* load(), get(), etc. */<br /></span><span class="keyword">}<br /><br /></span><span class="default">?&gt;<br /></span>In order to define a __destruct function (which is definitely called) we create a new instance in the init() function and define a destruct() function (which is called from the 'real' one):<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">B<br /></span><span class="keyword">{<br />&nbsp; static private </span><span class="default">$autoSave</span><span class="keyword">;<br />&nbsp; static public function </span><span class="default">init</span><span class="keyword">(</span><span class="default">$autoSave</span><span class="keyword">)<br />&nbsp; {<br />&nbsp; &nbsp; </span><span class="comment">/* emulating __construct() */<br />&nbsp; &nbsp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">$autoSave </span><span class="keyword">= </span><span class="default">$autoSave</span><span class="keyword">;<br />&nbsp; &nbsp; new </span><span class="default">B</span><span class="keyword">();<br />&nbsp; }<br />&nbsp; static public function </span><span class="default">destruct</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; if (</span><span class="default">self</span><span class="keyword">::</span><span class="default">$autoSave</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">save</span><span class="keyword">();<br />&nbsp; }<br />&nbsp; public function </span><span class="default">__destruct</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; </span><span class="default">B</span><span class="keyword">::</span><span class="default">destruct</span><span class="keyword">();<br />&nbsp; }<br />}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.oop5.static&amp;redirect=http://php.net/manual/en/language.oop5.static.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.oop5.php">Classes and Objects</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="oop5.intro.php" title="Introduction">Introduction</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.basic.php" title="The Basics">The Basics</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.properties.php" title="Properties">Properties</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.constants.php" title="Class Constants">Class Constants</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.autoload.php" title="Autoloading Classes">Autoloading Classes</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.decon.php" title="Constructors and Destructors">Constructors and Destructors</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.visibility.php" title="Visibility">Visibility</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.inheritance.php" title="Object Inheritance">Object Inheritance</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.paamayim-nekudotayim.php" title="Scope Resolution Operator (::)">Scope Resolution Operator (::)</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.oop5.static.php" title="Static Keyword">Static Keyword</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.abstract.php" title="Class Abstraction">Class Abstraction</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.interfaces.php" title="Object Interfaces">Object Interfaces</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.traits.php" title="Traits">Traits</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.anonymous.php" title="Anonymous classes">Anonymous classes</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.overloading.php" title="Overloading">Overloading</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.iterations.php" title="Object Iteration">Object Iteration</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.magic.php" title="Magic Methods">Magic Methods</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.final.php" title="Final Keyword">Final Keyword</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.cloning.php" title="Object Cloning">Object Cloning</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.object-comparison.php" title="Comparing Objects">Comparing Objects</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.typehinting.php" title="Type Hinting">Type Hinting</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.late-static-bindings.php" title="Late Static Bindings">Late Static Bindings</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.references.php" title="Objects and references">Objects and references</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.serialization.php" title="Object Serialization">Object Serialization</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.changelog.php" title="OOP Changelog">OOP Changelog</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

