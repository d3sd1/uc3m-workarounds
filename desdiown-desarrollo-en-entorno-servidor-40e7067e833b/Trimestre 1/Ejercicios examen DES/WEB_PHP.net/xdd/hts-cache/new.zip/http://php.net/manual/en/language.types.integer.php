<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Integers - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.types.integer.php">
 <link rel="shorturl" href="http://php.net/types.integer">
 <link rel="alternate" href="http://php.net/types.integer" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.types.php">
 <link rel="prev" href="http://php.net/manual/en/language.types.boolean.php">
 <link rel="next" href="http://php.net/manual/en/language.types.float.php">

 <link rel="alternate" href="http://php.net/manual/en/language.types.integer.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.types.integer.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.types.integer.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.types.integer.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.types.integer.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.types.integer.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.types.integer.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.types.integer.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.types.integer.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.types.integer.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.types.integer.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.types.float.php">
          Floating point numbers &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.types.boolean.php">
          &laquo; Booleans        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.types.php'>Types</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.types.integer.php' selected="selected">English</option>
            <option value='pt_BR/language.types.integer.php'>Brazilian Portuguese</option>
            <option value='zh/language.types.integer.php'>Chinese (Simplified)</option>
            <option value='fr/language.types.integer.php'>French</option>
            <option value='de/language.types.integer.php'>German</option>
            <option value='ja/language.types.integer.php'>Japanese</option>
            <option value='ro/language.types.integer.php'>Romanian</option>
            <option value='ru/language.types.integer.php'>Russian</option>
            <option value='es/language.types.integer.php'>Spanish</option>
            <option value='tr/language.types.integer.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.types.integer.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.types.integer">Report a Bug</a>
    </div>
  </div><div id="language.types.integer" class="sect1">
 <h2 class="title">Integers</h2>

 <p class="simpara">
  An <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span> is a number of the set
  ℤ = {..., -2, -1, 0, 1, 2, ...}.
 </p>

 <p class="para">
  See also:
 </p>

 <ul class="itemizedlist">
  <li class="listitem">
   <span class="simpara">
    <a href="book.gmp.php" class="link">Arbitrary length integer / GMP</a>
   </span>
  </li>
  <li class="listitem">
   <span class="simpara">
    <a href="language.types.float.php" class="link">Floating point numbers</a>
   </span>
  </li>
  <li class="listitem">
   <span class="simpara">
    <a href="book.bc.php" class="link">Arbitrary precision / BCMath</a>
   </span>
  </li>
 </ul>

 <div class="sect2" id="language.types.integer.syntax">
  <h3 class="title">Syntax</h3>

  <p class="simpara">
   <span class="type"><a href="language.types.integer.php" class="type Integer">Integer</a></span>s can be specified in decimal (base 10), hexadecimal
   (base 16), octal (base 8) or binary (base 2) notation, optionally preceded by a sign
   (- or +).
  </p>

  <p class="para">
   Binary <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span> literals are available since PHP 5.4.0.
  </p>

  <p class="para">
   To use octal notation, precede the number with a <em>0</em> (zero).
   To use hexadecimal notation precede the number with <em>0x</em>.
   To use binary notation precede the number with <em>0b</em>.
  </p>

  <div class="example" id="example-41">
   <p><strong>Example #1 Integer literals</strong></p>
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$a&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1234</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;decimal&nbsp;number<br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;-</span><span style="color: #0000BB">123</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;a&nbsp;negative&nbsp;number<br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">0123</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;octal&nbsp;number&nbsp;(equivalent&nbsp;to&nbsp;83&nbsp;decimal)<br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">0x1A</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;hexadecimal&nbsp;number&nbsp;(equivalent&nbsp;to&nbsp;26&nbsp;decimal)<br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">0b11111111</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;binary&nbsp;number&nbsp;(equivalent&nbsp;to&nbsp;255&nbsp;decimal)<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>

  <p class="para">
   Formally, the structure for <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span> literals is:
  </p>

  <div class="informalexample">
   <div class="example-contents">
<div class="cdata"><pre>
decimal     : [1-9][0-9]*
            | 0

hexadecimal : 0[xX][0-9a-fA-F]+

octal       : 0[0-7]+

binary      : 0b[01]+

integer     : [+-]?decimal
            | [+-]?hexadecimal
            | [+-]?octal
            | [+-]?binary
</pre></div>
   </div>

  </div>

  <p class="para">
   The size of an <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span> is platform-dependent, although a maximum
   value of about two billion is the usual value (that&#039;s 32 bits signed).
   64-bit platforms usually have a maximum value of about 9E18, except on
   Windows prior to PHP 7, where it was always 32 bit. PHP does not support
   unsigned <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span>s. <span class="type"><a href="language.types.integer.php" class="type Integer">Integer</a></span> size can be determined
   using the constant <strong><code>PHP_INT_SIZE</code></strong>, maximum value using
   the constant <strong><code>PHP_INT_MAX</code></strong> since PHP 5.0.5,
   and minimum value using the constant <strong><code>PHP_INT_MIN</code></strong> since
   PHP 7.0.0.
  </p>

  <div class="warning"><strong class="warning">Warning</strong>
   <p class="para">
    Prior to PHP 7, if an invalid digit was given in an octal <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span>
    (i.e. 8 or 9), the rest of the number was ignored. Since PHP 7, a parse error
    is emitted.
   </p>
  </div>
 </div>

 <div class="sect2" id="language.types.integer.overflow">
  <h3 class="title">Integer overflow</h3>

  <p class="para">
   If PHP encounters a number beyond the bounds of the <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span>
   type, it will be interpreted as a <span class="type"><a href="language.types.float.php" class="type float">float</a></span> instead. Also, an
   operation which results in a number beyond the bounds of the
   <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span> type will return a <span class="type"><a href="language.types.float.php" class="type float">float</a></span> instead.
  </p>

  <div class="example" id="example-42">
   <p><strong>Example #2 Integer overflow on a 32-bit system</strong></p>
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$large_number&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">2147483647</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$large_number</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;int(2147483647)<br /><br /></span><span style="color: #0000BB">$large_number&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">2147483648</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$large_number</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;float(2147483648)<br /><br /></span><span style="color: #0000BB">$million&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1000000</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$large_number&nbsp;</span><span style="color: #007700">=&nbsp;&nbsp;</span><span style="color: #0000BB">50000&nbsp;</span><span style="color: #007700">*&nbsp;</span><span style="color: #0000BB">$million</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$large_number</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;float(50000000000)<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>

  <div class="example" id="example-43">
   <p><strong>Example #3 Integer overflow on a 64-bit system</strong></p>
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$large_number&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">9223372036854775807</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$large_number</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;int(9223372036854775807)<br /><br /></span><span style="color: #0000BB">$large_number&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">9223372036854775808</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$large_number</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;float(9.2233720368548E+18)<br /><br /></span><span style="color: #0000BB">$million&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1000000</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$large_number&nbsp;</span><span style="color: #007700">=&nbsp;&nbsp;</span><span style="color: #0000BB">50000000000000&nbsp;</span><span style="color: #007700">*&nbsp;</span><span style="color: #0000BB">$million</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$large_number</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;float(5.0E+19)<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>

  <p class="para">
   There is no <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span> division operator in PHP.
   <em>1/2</em> yields the <span class="type"><a href="language.types.float.php" class="type float">float</a></span> <em>0.5</em>.
   The value can be casted to an <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span> to round it towards zero, or
   the <span class="function"><a href="function.round.php" class="function">round()</a></span> function provides finer control over rounding.
  </p>

  <div class="informalexample">
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">25</span><span style="color: #007700">/</span><span style="color: #0000BB">7</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;float(3.5714285714286)<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">((int)&nbsp;(</span><span style="color: #0000BB">25</span><span style="color: #007700">/</span><span style="color: #0000BB">7</span><span style="color: #007700">));&nbsp;</span><span style="color: #FF8000">//&nbsp;int(3)<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">round</span><span style="color: #007700">(</span><span style="color: #0000BB">25</span><span style="color: #007700">/</span><span style="color: #0000BB">7</span><span style="color: #007700">));&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;float(4)<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>
 </div>

 <div class="sect2" id="language.types.integer.casting">
  <h3 class="title">Converting to integer</h3>

  <p class="simpara">
   To explicitly convert a value to <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span>, use either the
   <em>(int)</em> or <em>(integer)</em> casts. However, in
   most cases the cast is not needed, since a value will be automatically
   converted if an operator, function or control structure requires an
   <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span> argument. A value can also be converted to
   <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span> with the <span class="function"><a href="function.intval.php" class="function">intval()</a></span> function.
  </p>

  <p class="simpara">
   If a <span class="type"><a href="language.types.resource.php" class="type resource">resource</a></span> is converted to an <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span>, then
   the result will be the unique resource number assigned to the
   <span class="type"><a href="language.types.resource.php" class="type resource">resource</a></span> by PHP at runtime.
  </p>

  <p class="simpara">
   See also <a href="language.types.type-juggling.php" class="link">Type Juggling</a>.
  </p>

  <div class="sect3" id="language.types.integer.casting.from-boolean">
   <h4 class="title">From <a href="language.types.boolean.php" class="link">booleans</a></h4>

   <p class="simpara">
    <strong><code>FALSE</code></strong> will yield <em>0</em> (zero), and <strong><code>TRUE</code></strong> will yield
    <em>1</em> (one).
   </p>
  </div>

  <div class="sect3" id="language.types.integer.casting.from-float">
   <h4 class="title">
    From <a href="language.types.float.php" class="link">floating point numbers</a>
   </h4>

   <p class="simpara">
    When converting from <span class="type"><a href="language.types.float.php" class="type float">float</a></span> to <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span>, the number
    will be rounded <em class="emphasis">towards zero</em>.
   </p>

   <p class="para">
    If the float is beyond the boundaries of <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span> (usually
    <em>+/- 2.15e+9 = 2^31</em> on 32-bit platforms and
    <em>+/- 9.22e+18 = 2^63</em> on 64-bit platforms other than
    Windows), the result is undefined, since the <span class="type"><a href="language.types.float.php" class="type float">float</a></span> doesn&#039;t
    have enough precision to give an exact <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span> result. No
    warning, not even a notice will be issued when this happens!
   </p>

   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <p class="para">
     As of PHP 7.0.0, instead of being undefined and platform-dependent, NaN and Infinity will
     always be zero when cast to <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span>.
    </p>
   </p></blockquote>

   <div class="warning"><strong class="warning">Warning</strong>
    <p class="para">
     Never cast an unknown fraction to <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span>, as this can
     sometimes lead to unexpected results.
    </p>

    <div class="informalexample">
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">echo&nbsp;(int)&nbsp;(&nbsp;(</span><span style="color: #0000BB">0.1</span><span style="color: #007700">+</span><span style="color: #0000BB">0.7</span><span style="color: #007700">)&nbsp;*&nbsp;</span><span style="color: #0000BB">10&nbsp;</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;echoes&nbsp;7!<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>

    <p class="para">
     See also the <a href="language.types.float.php#warn.float-precision" class="link">warning about float
     precision</a>.
    </p>
   </div>
  </div>

  <div class="sect3" id="language.types.integer.casting.from-string">
   <h4 class="title">From strings</h4>

   <p class="simpara">
    See <a href="language.types.string.php#language.types.string.conversion" class="link">String conversion to
    numbers</a>
   </p>
  </div>

  <div class="sect3" id="language.types.integer.casting.from-other">
   <h4 class="title">From other types</h4>

   <div class="caution"><strong class="caution">Caution</strong>
    <p class="simpara">
     The behaviour of converting to <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span> is undefined for other
     types. Do <em class="emphasis">not</em> rely on any observed behaviour, as it
     can change without notice.
    </p>
   </div>
  </div>

 </div>
</div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.types.integer&amp;redirect=http://php.net/manual/en/language.types.integer.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">22 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="111523">  <div class="votes">
    <div id="Vu111523">
    <a href="/manual/vote-note.php?id=111523&amp;page=language.types.integer&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd111523">
    <a href="/manual/vote-note.php?id=111523&amp;page=language.types.integer&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V111523" title="62% like this...">
    36
    </div>
  </div>
  <a href="#111523" class="name">
  <strong class="user"><em>php at richardneill dot org</em></strong></a><a class="genanchor" href="#111523"> &para;</a><div class="date" title="2013-02-28 06:25"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom111523">
<div class="phpcode"><code><span class="html">
A leading zero in a numeric literal means "this is octal". But don't be confused: a leading zero in a string does not. Thus:<br />$x = 0123;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; // 83<br />$y = "0123" + 0&nbsp; &nbsp;&nbsp; // 123</span>
</code></div>
  </div>
 </div>
  <div class="note" id="77056">  <div class="votes">
    <div id="Vu77056">
    <a href="/manual/vote-note.php?id=77056&amp;page=language.types.integer&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd77056">
    <a href="/manual/vote-note.php?id=77056&amp;page=language.types.integer&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V77056" title="60% like this...">
    40
    </div>
  </div>
  <a href="#77056" class="name">
  <strong class="user"><em>d_n at NOSPAM dot Loryx dot com</em></strong></a><a class="genanchor" href="#77056"> &para;</a><div class="date" title="2007-08-13 05:33"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom77056">
<div class="phpcode"><code><span class="html">
Here are some tricks to convert from a "dotted" IP address to a LONG int, and backwards. This is very useful because accessing an IP addy in a database table is very much faster if it's stored as a BIGINT rather than in characters.<br /><br />IP to BIGINT:<br /><span class="default">&lt;?php<br />&nbsp; $ipArr&nbsp; &nbsp; </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">(</span><span class="string">'.'</span><span class="keyword">,</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'REMOTE_ADDR'</span><span class="keyword">]);<br />&nbsp; </span><span class="default">$ip&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="keyword">= </span><span class="default">$ipArr</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">] * </span><span class="default">0x1000000<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">+ </span><span class="default">$ipArr</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">] * </span><span class="default">0x10000<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">+ </span><span class="default">$ipArr</span><span class="keyword">[</span><span class="default">2</span><span class="keyword">] * </span><span class="default">0x100<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">+ </span><span class="default">$ipArr</span><span class="keyword">[</span><span class="default">3</span><span class="keyword">]<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ;<br /></span><span class="default">?&gt;<br /></span><br />IP as BIGINT read from db back to dotted form:<br /><br />Keep in mind, PHP integer operators are INTEGER -- not long. Also, since there is no integer divide in PHP, we save a couple of S-L-O-W floor (&lt;division&gt;)'s by doing bitshifts. We must use floor(/) for $ipArr[0] because though $ipVal is stored as a long value, $ipVal &gt;&gt; 24 will operate on a truncated, integer value of $ipVal! $ipVint is, however, a nice integer, so <br />we can enjoy the bitshifts.<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; &nbsp; &nbsp; $ipVal </span><span class="keyword">= </span><span class="default">$row</span><span class="keyword">[</span><span class="string">'client_IP'</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$ipArr </span><span class="keyword">= array(</span><span class="default">0 </span><span class="keyword">=&gt;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">floor</span><span class="keyword">(&nbsp; </span><span class="default">$ipVal&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="keyword">/ </span><span class="default">0x1000000</span><span class="keyword">) );<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$ipVint&nbsp;&nbsp; </span><span class="keyword">= </span><span class="default">$ipVal</span><span class="keyword">-(</span><span class="default">$ipArr</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]*</span><span class="default">0x1000000</span><span class="keyword">); </span><span class="comment">// for clarity<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$ipArr</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">] = (</span><span class="default">$ipVint </span><span class="keyword">&amp; </span><span class="default">0xFF0000</span><span class="keyword">)&nbsp; &gt;&gt; </span><span class="default">16</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$ipArr</span><span class="keyword">[</span><span class="default">2</span><span class="keyword">] = (</span><span class="default">$ipVint </span><span class="keyword">&amp; </span><span class="default">0xFF00&nbsp; </span><span class="keyword">)&nbsp; &gt;&gt; </span><span class="default">8</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$ipArr</span><span class="keyword">[</span><span class="default">3</span><span class="keyword">] =&nbsp; </span><span class="default">$ipVint </span><span class="keyword">&amp; </span><span class="default">0xFF</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$ipDotted </span><span class="keyword">= </span><span class="default">implode</span><span class="keyword">(</span><span class="string">'.'</span><span class="keyword">, </span><span class="default">$ipArr</span><span class="keyword">);<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116479">  <div class="votes">
    <div id="Vu116479">
    <a href="/manual/vote-note.php?id=116479&amp;page=language.types.integer&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116479">
    <a href="/manual/vote-note.php?id=116479&amp;page=language.types.integer&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116479" title="60% like this...">
    15
    </div>
  </div>
  <a href="#116479" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#116479"> &para;</a><div class="date" title="2015-01-09 09:31"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom116479">
<div class="phpcode"><code><span class="html">
Converting to an integer works only if the input begins with a number<br />(int) "5txt" // will output the integer 5<br />(int) "before5txt" // will output the integer 0<br />(int) "53txt" // will output the integer 53<br />(int) "53txt534text" // will output the integer 53</span>
</code></div>
  </div>
 </div>
  <div class="note" id="71709">  <div class="votes">
    <div id="Vu71709">
    <a href="/manual/vote-note.php?id=71709&amp;page=language.types.integer&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd71709">
    <a href="/manual/vote-note.php?id=71709&amp;page=language.types.integer&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V71709" title="55% like this...">
    18
    </div>
  </div>
  <a href="#71709" class="name">
  <strong class="user"><em>rustamabd@gmail-you-know-what</em></strong></a><a class="genanchor" href="#71709"> &para;</a><div class="date" title="2006-12-12 01:42"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom71709">
<div class="phpcode"><code><span class="html">
Be careful with using the modulo operation on big numbers, it will cast a float argument to an int and may return wrong results. For example:<br /><span class="default">&lt;?php<br />&nbsp; &nbsp; $i </span><span class="keyword">= </span><span class="default">6887129852</span><span class="keyword">;<br />&nbsp; &nbsp; echo </span><span class="string">"i=</span><span class="default">$i</span><span class="string">\n"</span><span class="keyword">;<br />&nbsp; &nbsp; echo </span><span class="string">"i%36="</span><span class="keyword">.(</span><span class="default">$i</span><span class="keyword">%</span><span class="default">36</span><span class="keyword">).</span><span class="string">"\n"</span><span class="keyword">;<br />&nbsp; &nbsp; echo </span><span class="string">"alternative i%36="</span><span class="keyword">.(</span><span class="default">$i</span><span class="keyword">-</span><span class="default">floor</span><span class="keyword">(</span><span class="default">$i</span><span class="keyword">/</span><span class="default">36</span><span class="keyword">)*</span><span class="default">36</span><span class="keyword">).</span><span class="string">"\n"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span>Will output:<br />i=6.88713E+009<br />i%36=-24<br />alternative i%36=20</span>
</code></div>
  </div>
 </div>
  <div class="note" id="73790">  <div class="votes">
    <div id="Vu73790">
    <a href="/manual/vote-note.php?id=73790&amp;page=language.types.integer&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd73790">
    <a href="/manual/vote-note.php?id=73790&amp;page=language.types.integer&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V73790" title="51% like this...">
    3
    </div>
  </div>
  <a href="#73790" class="name">
  <strong class="user"><em>Jacek</em></strong></a><a class="genanchor" href="#73790"> &para;</a><div class="date" title="2007-03-10 04:51"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom73790">
<div class="phpcode"><code><span class="html">
On 64 bits machines max integer value is 0x7fffffffffffffff (9 223 372 036 854 775 807).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121886">  <div class="votes">
    <div id="Vu121886">
    <a href="/manual/vote-note.php?id=121886&amp;page=language.types.integer&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121886">
    <a href="/manual/vote-note.php?id=121886&amp;page=language.types.integer&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121886" title="no votes...">
    0
    </div>
  </div>
  <a href="#121886" class="name">
  <strong class="user"><em>dhairya lakhera</em></strong></a><a class="genanchor" href="#121886"> &para;</a><div class="date" title="2017-11-20 04:04"><strong>24 days ago</strong></div>
  <div class="text" id="Hcom121886">
<div class="phpcode"><code><span class="html">
-------------------------------------------------------------------------<br />Question : <br />var_dump((int) 010);&nbsp; //Output 8<br /><br />var_dump((int) "010"); //output 10<br /><br />First one is octal notation so the output is correct. But what about the when converting "010" to integer. it should be also output 8 ?<br />--------------------------------------------------------------------------<br />Answer :<br /><br />Casting to an integer using (int) will always cast to the default base, which is 10.<br /><br />Casting a string to a number this way does not take into account the many ways of formatting an integer value in PHP (leading zero for base 8, leading "0x" for base 16, leading "0b" for base 2). It will simply look at the first characters in a string and convert them to a base 10 integer. Leading zeroes will be stripped off because they have no meaning in numerical values, so you will end up with the decimal value 10 for (int)"010".<br /><br />Converting an integer value between bases using (int)010 will take into account the various ways of formatting an integer. A leading zero like in 010 means the number is in octal notation, using (int)010 will convert it to the decimal value 8 in base 10.<br /><br />This is similar to how you use 0x10 to write in hexadecimal (base 16) notation. Using (int)0x10 will convert that to the base 10 decimal value 16, whereas using (int)"0x10" will end up with the decimal value 0: since the "x" is not a numerical value, anything after that will be ignored.<br /><br />If you want to interpret the string "010" as an octal value, you need to instruct PHP to do so. intval("010", 8) will interpret the number in base 8 instead of the default base 10, and you will end up with the decimal value 8. You could also use octdec("010") to convert the octal string to the decimal value 8. Another option is to use base_convert("010", 8, 10) to explicitly convert the number "010" from base 8 to base 10, however this function will return the string "8" instead of the integer 8.<br /><br />Casting a string to an integer follows the same the logic used by the intval function:<br /><br />Returns the integer value of var, using the specified base for the conversion (the default is base 10).<br />intval allows specifying a different base as the second argument, whereas a straight cast operation does not, so using (int) will always treat a string as being in base 10.<br /><br />php &gt; var_export((int) "010");<br />10<br />php &gt; var_export(intval("010"));<br />10<br />php &gt; var_export(intval("010", 8));<br />8</span>
</code></div>
  </div>
 </div>
  <div class="note" id="79234">  <div class="votes">
    <div id="Vu79234">
    <a href="/manual/vote-note.php?id=79234&amp;page=language.types.integer&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd79234">
    <a href="/manual/vote-note.php?id=79234&amp;page=language.types.integer&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V79234" title="51% like this...">
    2
    </div>
  </div>
  <a href="#79234" class="name">
  <strong class="user"><em>darkshire</em></strong></a><a class="genanchor" href="#79234"> &para;</a><div class="date" title="2007-11-16 04:56"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom79234">
<div class="phpcode"><code><span class="html">
d_n at NOSPAM dot Loryx dot com<br />13-Aug-2007 05:33<br />Here are some tricks to convert from a "dotted" IP address to a LONG int, and backwards. This is very useful because accessing an IP addy in a database table is very much faster if it's stored as a BIGINT rather than in characters.<br /><br />IP to BIGINT:<br /><span class="default">&lt;?php<br />&nbsp; $ipArr&nbsp; &nbsp; </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">(</span><span class="string">'.'</span><span class="keyword">,</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'REMOTE_ADDR'</span><span class="keyword">]);<br />&nbsp; </span><span class="default">$ip&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="keyword">= </span><span class="default">$ipArr</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">] * </span><span class="default">0x1000000<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">+ </span><span class="default">$ipArr</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">] * </span><span class="default">0x10000<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">+ </span><span class="default">$ipArr</span><span class="keyword">[</span><span class="default">2</span><span class="keyword">] * </span><span class="default">0x100<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">+ </span><span class="default">$ipArr</span><span class="keyword">[</span><span class="default">3</span><span class="keyword">]<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ;<br /></span><span class="default">?&gt;<br /></span><br />This can be written in a bit more efficient way:<br /><span class="default">&lt;?php<br />&nbsp; $ipArr&nbsp; &nbsp; </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">(</span><span class="string">'.'</span><span class="keyword">,</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'REMOTE_ADDR'</span><span class="keyword">]);<br />&nbsp; </span><span class="default">$ip&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="keyword">= </span><span class="default">$ipArr</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]&lt;&lt;</span><span class="default">24<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">+ </span><span class="default">$ipArr</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]&lt;&lt;</span><span class="default">16<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">+ </span><span class="default">$ipArr</span><span class="keyword">[</span><span class="default">2</span><span class="keyword">] &lt;&lt;</span><span class="default">8<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">+ </span><span class="default">$ipArr</span><span class="keyword">[</span><span class="default">3</span><span class="keyword">]<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ;<br /></span><span class="default">?&gt;<br /></span><br />shift is more cheaper.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118903">  <div class="votes">
    <div id="Vu118903">
    <a href="/manual/vote-note.php?id=118903&amp;page=language.types.integer&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118903">
    <a href="/manual/vote-note.php?id=118903&amp;page=language.types.integer&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118903" title="50% like this...">
    0
    </div>
  </div>
  <a href="#118903" class="name">
  <strong class="user"><em>litbai</em></strong></a><a class="genanchor" href="#118903"> &para;</a><div class="date" title="2016-02-25 08:26"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom118903">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br />$ipArr </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">(</span><span class="string">'.'</span><span class="keyword">, </span><span class="default">$ipString</span><span class="keyword">);<br /></span><span class="default">$ipVal </span><span class="keyword">= (</span><span class="default">$ipArr</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">] &lt;&lt; </span><span class="default">24</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp;&nbsp; + (</span><span class="default">$ipArr</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">] &lt;&lt; </span><span class="default">16</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp;&nbsp; + (</span><span class="default">$ipArr</span><span class="keyword">[</span><span class="default">2</span><span class="keyword">] &lt;&lt; </span><span class="default">8</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp;&nbsp; + </span><span class="default">$ipArr</span><span class="keyword">[</span><span class="default">3</span><span class="keyword">]<br />&nbsp; &nbsp; &nbsp; &nbsp; ;<br /></span><span class="default">?&gt;<br /></span>1. the priority of bit op is lower than '+',so there should be brackets.<br />2. there is no unsighed int in PHP, if you use 32 bit version，the code above will get negative result when the first position of IP string greater than 127.<br />3. what the code actually do is calculate the integer value of transformed 32 binary bit from IP string.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121917">  <div class="votes">
    <div id="Vu121917">
    <a href="/manual/vote-note.php?id=121917&amp;page=language.types.integer&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121917">
    <a href="/manual/vote-note.php?id=121917&amp;page=language.types.integer&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121917" title="0% like this...">
    -1
    </div>
  </div>
  <a href="#121917" class="name">
  <strong class="user"><em>egwayjen at gmail dot com</em></strong></a><a class="genanchor" href="#121917"> &para;</a><div class="date" title="2017-11-27 10:01"><strong>17 days ago</strong></div>
  <div class="text" id="Hcom121917">
<div class="phpcode"><code><span class="html">
"There is no integer division operator in PHP". But since PHP 7, there is the intdiv function.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="73766">  <div class="votes">
    <div id="Vu73766">
    <a href="/manual/vote-note.php?id=73766&amp;page=language.types.integer&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd73766">
    <a href="/manual/vote-note.php?id=73766&amp;page=language.types.integer&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V73766" title="50% like this...">
    1
    </div>
  </div>
  <a href="#73766" class="name"><strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#73766"> &para;</a><div class="date" title="2007-03-09 07:26"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom73766">
<div class="phpcode"><code><span class="html">
To force the correct usage of 32-bit unsigned integer in some functions, just add '+0'&nbsp; just before processing them.<br /><br />for example <br />echo(dechex("2724838310"));<br />will print '7FFFFFFF'<br />but it should print 'A269BBA6'<br /><br />When adding '+0' php will handle the 32bit unsigned integer<br />correctly<br />echo(dechex("2724838310"+0));<br />will print 'A269BBA6'</span>
</code></div>
  </div>
 </div>
  <div class="note" id="38478">  <div class="votes">
    <div id="Vu38478">
    <a href="/manual/vote-note.php?id=38478&amp;page=language.types.integer&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd38478">
    <a href="/manual/vote-note.php?id=38478&amp;page=language.types.integer&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V38478" title="50% like this...">
    0
    </div>
  </div>
  <a href="#38478" class="name"><strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#38478"> &para;</a><div class="date" title="2003-12-23 10:18"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom38478">
<div class="phpcode"><code><span class="html">
Sometimes you need to parse an unsigned<br />32 bit integer. Here's a function I 've used:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; function parse_unsigned_int($string) {<br />&nbsp; &nbsp; &nbsp; &nbsp; $x = (float)$string;<br />&nbsp; &nbsp; &nbsp; &nbsp; if ($x &gt; (float)2147483647)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $x -= (float)"4294967296";<br />&nbsp; &nbsp; &nbsp; &nbsp; return (int)$x;<br />&nbsp; &nbsp; }</span>
</code></div>
  </div>
 </div>
  <div class="note" id="102925">  <div class="votes">
    <div id="Vu102925">
    <a href="/manual/vote-note.php?id=102925&amp;page=language.types.integer&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd102925">
    <a href="/manual/vote-note.php?id=102925&amp;page=language.types.integer&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V102925" title="46% like this...">
    -6
    </div>
  </div>
  <a href="#102925" class="name">
  <strong class="user"><em>pere dot cil at wanadoo dot fr</em></strong></a><a class="genanchor" href="#102925"> &para;</a><div class="date" title="2011-03-15 01:59"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom102925">
<div class="phpcode"><code><span class="html">
Please also note that the maximum stored in the integer depends on the platform / compilation; on windows xp 32 bits, the following value:<br /><br />0x5468792130ABCDEF<br /><br />echoes to:<br /><br />6.0822444802213E+18 (cast to float)<br /><br />On a fully 64 bits system, it echoes to:<br /><br />6082244480221302255</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117249">  <div class="votes">
    <div id="Vu117249">
    <a href="/manual/vote-note.php?id=117249&amp;page=language.types.integer&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117249">
    <a href="/manual/vote-note.php?id=117249&amp;page=language.types.integer&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117249" title="44% like this...">
    -3
    </div>
  </div>
  <a href="#117249" class="name">
  <strong class="user"><em>dewi at dewimorgan dot com</em></strong></a><a class="genanchor" href="#117249"> &para;</a><div class="date" title="2015-05-09 07:41"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117249">
<div class="phpcode"><code><span class="html">
Note that the soft-typing of numbers in PHP means that some things become very difficult. For example, efficiently emulating the more common linear congruential generators (LCGs) for fast, deterministic, pseudo-randomness. The naive code to create the next value in a sequence (for power-of-2 values of $m) is:<br /><br />$seed = ($seed * $a + $c) % $m;<br /><br />...where $m, $a, and $c are values and data types carefully chosen such that repeating this operation will eventually generate every value in the range $0 to $m, with no repetition.<br /><br />I can find no good commonly used LCGs which use PHP-compatible values. The LCG values used in by rand() in systems like Borland Delphi, Virtual Pascal, MS Visual/Quick C/C++, VMS's MTH$RANDOM, old versions of glibc, Numerical Recipes, glibc, GCC, ANSI C, Watcom, Digital Mars, CodeWarrior, IBM VisualAge C/C++, java.util.Random, Newlib, MMX... *all* fail when ported, for one of two reasons, and sometimes both:<br /><br /> - In PHP on 32 bit machines and all Windows machines, $m = 2^32 or larger requires UInt or even UInt64, or the result becomes negative.<br /><br />- Large $a multiplied by an integer seed gets converted to a float64, but the number can be too long for the 53-bit mantissa, and it drops the least significant digits... but the LCG code above requires that the most significant digits should be lost.<br /><br />These are two classes of problem to beware of when porting integer math to PHP,&nbsp; and I see no clean and efficient way to avoid either one.<br /><br />So if designing a cross-platform system that must work in PHP, you must select LCG values that fit the following criteria:<br />$m = 2^31 or less (PHP limitation). Recommend: 2^31.<br />$a = Less than 2^22 (PHP limitation); $a-1 divisible by all prime factors of $m; $a-1 divisible by 4 if $m is. Recommend: 1+(4*(any prime &lt;= 1048573)).<br />$c = smaller than (2^53-($m*$a)) (PHP limitation); relatively prime with $m. Recommend: any prime &lt;= 23622320123.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="71899">  <div class="votes">
    <div id="Vu71899">
    <a href="/manual/vote-note.php?id=71899&amp;page=language.types.integer&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd71899">
    <a href="/manual/vote-note.php?id=71899&amp;page=language.types.integer&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V71899" title="46% like this...">
    -6
    </div>
  </div>
  <a href="#71899" class="name">
  <strong class="user"><em>popefelix at gmail dot com</em></strong></a><a class="genanchor" href="#71899"> &para;</a><div class="date" title="2006-12-21 06:50"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom71899">
<div class="phpcode"><code><span class="html">
Be careful when using integer conversion to test something to see if it evaluates to a positive integer or not.&nbsp; You might get unexpected behaviour.<br /><br />To wit:<br /><span class="default">&lt;?php<br />error_reporting</span><span class="keyword">(</span><span class="default">E_ALL</span><span class="keyword">);<br />require_once </span><span class="string">'Date.php'</span><span class="keyword">;<br /><br /></span><span class="default">$date </span><span class="keyword">= new </span><span class="default">Date</span><span class="keyword">();<br />print </span><span class="string">"\$date is an instance of " </span><span class="keyword">. </span><span class="default">get_class</span><span class="keyword">(</span><span class="default">$date</span><span class="keyword">) . </span><span class="string">"\n"</span><span class="keyword">;<br /></span><span class="default">$date </span><span class="keyword">+= </span><span class="default">0</span><span class="keyword">;<br />print </span><span class="string">"\$date is now </span><span class="default">$date</span><span class="string">\n"</span><span class="keyword">;<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$date</span><span class="keyword">);<br /><br /></span><span class="default">$foo </span><span class="keyword">= new </span><span class="default">foo</span><span class="keyword">();<br />print </span><span class="string">"\$foo is an instance of " </span><span class="keyword">. </span><span class="default">get_class</span><span class="keyword">(</span><span class="default">$foo</span><span class="keyword">) . </span><span class="string">"\n"</span><span class="keyword">;<br /></span><span class="default">$foo </span><span class="keyword">+= </span><span class="default">0</span><span class="keyword">;<br />print </span><span class="string">"\$foo is now </span><span class="default">$foo</span><span class="string">\n"</span><span class="keyword">;<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$foo</span><span class="keyword">);<br /><br />class </span><span class="default">foo </span><span class="keyword">{<br />&nbsp; &nbsp; var </span><span class="default">$bar </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />&nbsp; &nbsp; var </span><span class="default">$baz </span><span class="keyword">= </span><span class="string">"la lal la"</span><span class="keyword">;<br />&nbsp; &nbsp; var </span><span class="default">$bak</span><span class="keyword">;<br /><br />&nbsp; &nbsp; function </span><span class="default">foo</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$bak </span><span class="keyword">= </span><span class="default">3.14159</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />After the integer conversion, you might expect both $foo and $date to evaluate to 0.&nbsp; However, this is not the case:<br /><br />$date is an instance of Date<br /><br />Notice: Object of class Date could not be converted to int in /home/kpeters/work/sketches/ObjectSketch.php on line 7<br />$date is now 1<br />int(1)<br />$foo is an instance of foo<br /><br />Notice: Object of class foo could not be converted to int in /home/kpeters/work/sketches/ObjectSketch.php on line 13<br />$foo is now 1<br />int(1)<br /><br />This is because the objects are first converted to boolean before being converted to int.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="86180">  <div class="votes">
    <div id="Vu86180">
    <a href="/manual/vote-note.php?id=86180&amp;page=language.types.integer&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86180">
    <a href="/manual/vote-note.php?id=86180&amp;page=language.types.integer&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86180" title="44% like this...">
    -10
    </div>
  </div>
  <a href="#86180" class="name">
  <strong class="user"><em>wbcarts at juno dot com</em></strong></a><a class="genanchor" href="#86180"> &para;</a><div class="date" title="2008-10-06 06:25"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86180">
<div class="phpcode"><code><span class="html">
PHP offers a slew of built-in functions and automatic type-casting routines which can get pretty complicated. But most of the time, you still have to take matters into your own hands and allow PHP to do its thing. In that case, and something that has NOT been mentioned, is how to construct your code. To keep things simple, I divide all my scripts in half. The top half gives my scripts the "capability" they need, and the lower half is the actual code to be "run" or "executed".<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">/*<br /> * build the program's capability - define variables and functions...<br /> */<br /></span><span class="default">$item_label </span><span class="keyword">= </span><span class="string">''</span><span class="keyword">;&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// type string<br /></span><span class="default">$item_price </span><span class="keyword">= </span><span class="default">0.0</span><span class="keyword">;&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="comment">// type float<br /></span><span class="default">$item_qty </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="comment">// type integer<br /></span><span class="default">$item_total </span><span class="keyword">= </span><span class="default">0.0</span><span class="keyword">;&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="comment">// type float - to set use calculate()<br /><br /></span><span class="keyword">function </span><span class="default">calculate</span><span class="keyword">(){<br />&nbsp; global </span><span class="default">$item_price</span><span class="keyword">, </span><span class="default">$item_qty</span><span class="keyword">, </span><span class="default">$item_total</span><span class="keyword">;<br />&nbsp; </span><span class="default">$item_price </span><span class="keyword">= </span><span class="default">number_format</span><span class="keyword">(</span><span class="default">$item_price</span><span class="keyword">, </span><span class="default">2</span><span class="keyword">);<br />&nbsp; </span><span class="default">$item_total </span><span class="keyword">= </span><span class="default">number_format</span><span class="keyword">((</span><span class="default">$item_price </span><span class="keyword">* </span><span class="default">$item_qty</span><span class="keyword">), </span><span class="default">2</span><span class="keyword">);<br />}<br /><br />function </span><span class="default">itemToString</span><span class="keyword">() {<br />&nbsp; global </span><span class="default">$item_label</span><span class="keyword">, </span><span class="default">$item_price</span><span class="keyword">, </span><span class="default">$item_qty</span><span class="keyword">, </span><span class="default">$item_total</span><span class="keyword">;<br />&nbsp; return </span><span class="string">"</span><span class="default">$item_label</span><span class="string"> [price=\$</span><span class="default">$item_price</span><span class="string">, qty=</span><span class="default">$item_qty</span><span class="string">, total=\$</span><span class="default">$item_total</span><span class="string">]"</span><span class="keyword">;<br />}<br /><br /></span><span class="comment">/*<br /> * run the program - set data, call methods...<br /> */<br /></span><span class="default">$item_label </span><span class="keyword">= </span><span class="string">"Coffee"</span><span class="keyword">;<br /></span><span class="default">$item_price </span><span class="keyword">= </span><span class="default">3.89</span><span class="keyword">;<br /></span><span class="default">$item_qty </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">;<br /></span><span class="default">calculate</span><span class="keyword">();&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="comment">// set $item_total<br /></span><span class="keyword">echo </span><span class="default">itemToString</span><span class="keyword">();&nbsp;&nbsp; </span><span class="comment">// -&gt; Coffee [price=$3.89, qty=2, total=$7.78]<br /><br /></span><span class="default">$item_label </span><span class="keyword">= </span><span class="string">"Chicken"</span><span class="keyword">;<br /></span><span class="default">$item_price </span><span class="keyword">= </span><span class="default">.80</span><span class="keyword">;&nbsp; &nbsp;&nbsp; </span><span class="comment">// per lb.<br /></span><span class="default">$item_qty </span><span class="keyword">= </span><span class="default">3.5</span><span class="keyword">;&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="comment">// lbs.<br /></span><span class="default">calculate</span><span class="keyword">();&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="comment">// set $item_total<br /></span><span class="keyword">echo </span><span class="default">itemToString</span><span class="keyword">();&nbsp;&nbsp; </span><span class="comment">// -&gt; Chicken [price=$0.80, qty=3.5, total=$2.80]<br /></span><span class="default">?&gt;<br /></span>Note: All type-casting is done by PHP's built-in number_format() method. This allows our program to enter any number (float or int) on item price or quantity in the runtime part of our script. Also, if we explicitly cast values to integer in the capability part of our script, then we start getting results that may not be desirable for this program. For example, if in the calculate method we cast item_qty to integer, then we can no longer sell chicken by the pound!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="83790">  <div class="votes">
    <div id="Vu83790">
    <a href="/manual/vote-note.php?id=83790&amp;page=language.types.integer&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd83790">
    <a href="/manual/vote-note.php?id=83790&amp;page=language.types.integer&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V83790" title="44% like this...">
    -10
    </div>
  </div>
  <a href="#83790" class="name">
  <strong class="user"><em>eric</em></strong></a><a class="genanchor" href="#83790"> &para;</a><div class="date" title="2008-06-11 01:50"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom83790">
<div class="phpcode"><code><span class="html">
In response to the comment by me at troyswanson dot net:<br /><br />-2147483648 falls into the range of 32 bit signed integers yet php treats it as a float.&nbsp; However, -2147483647-1 is treated as an integer.<br /><br />The following code demonstrates:<br /><span class="default">&lt;?php<br />&nbsp; &nbsp; var_dump</span><span class="keyword">(-</span><span class="default">2147483648</span><span class="keyword">); </span><span class="comment">//float(-2147483648)<br />&nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(-</span><span class="default">2147483647 </span><span class="keyword">- </span><span class="default">1</span><span class="keyword">); </span><span class="comment">//int(-2147483648)<br /></span><span class="default">?&gt;<br /></span><br />This is probably very similar to the MS C bug which also treats -2147483648 as an UNSIGNED because it thinks it's out of the range of a signed int.<br /><br />The problem is that the parser does not view "-x" as a single token, but rather as two, "-" and "x".&nbsp; Since "x" is out of the range of an INT, it is promoted to float, even though in this unique case, "-x" is in the range of an int.<br /><br />The best cure is probably to replace "-2147483648" with "0x80000000", as that is the hexadecimal equivalent of the same number.<br /><br />Hope that helps explain what's going on<br /><br />Peace<br /><br /> - Eric / fez</span>
</code></div>
  </div>
 </div>
  <div class="note" id="103442">  <div class="votes">
    <div id="Vu103442">
    <a href="/manual/vote-note.php?id=103442&amp;page=language.types.integer&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd103442">
    <a href="/manual/vote-note.php?id=103442&amp;page=language.types.integer&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V103442" title="41% like this...">
    -12
    </div>
  </div>
  <a href="#103442" class="name">
  <strong class="user"><em>php at keith tyler dot com</em></strong></a><a class="genanchor" href="#103442"> &para;</a><div class="date" title="2011-04-13 11:08"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom103442">
<div class="phpcode"><code><span class="html">
If you need to convert a numeric string (or more to the point, an object that represents a numeric value) that is greater then PHP_INT_MAX, and you don't have GMP or BCMath installed, you can cast to float.<br /><br />For example, when using SimpleXMLElement, you sometimes have to cast the extracted values, such as xml attributes, because they are returned as SimpleXMLElements and not their values' native types. While print() has no trouble with converting them, other functions, such as max(), might not.<br /><br />But if you cast such a value with (int), and it is over PHP_INT_MAX, you will just get PHP_INT_MAX (and vice versa for negative numbers). <br /><br />The Q&amp;D no-muss solution is to cast to (float) instead.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="69181">  <div class="votes">
    <div id="Vu69181">
    <a href="/manual/vote-note.php?id=69181&amp;page=language.types.integer&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd69181">
    <a href="/manual/vote-note.php?id=69181&amp;page=language.types.integer&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V69181" title="44% like this...">
    -14
    </div>
  </div>
  <a href="#69181" class="name">
  <strong class="user"><em>jmw254 at cornell dot edu</em></strong></a><a class="genanchor" href="#69181"> &para;</a><div class="date" title="2006-08-25 10:14"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom69181">
<div class="phpcode"><code><span class="html">
Try this one instead: <br /><br />function iplongtostring($ip)<br />{<br />&nbsp; &nbsp; $ip=floatval($ip); // otherwise it is capped at 127.255.255.255<br /><br />&nbsp; &nbsp; $a=($ip&gt;&gt;24)&amp;255;<br />&nbsp; &nbsp; $b=($ip&gt;&gt;16)&amp;255;<br />&nbsp; &nbsp; $c=($ip&gt;&gt;8)&amp;255;<br />&nbsp; &nbsp; $d=$ip&amp;255;<br /><br />&nbsp; &nbsp; return "$a.$b.$c.$d";<br />}</span>
</code></div>
  </div>
 </div>
  <div class="note" id="86588">  <div class="votes">
    <div id="Vu86588">
    <a href="/manual/vote-note.php?id=86588&amp;page=language.types.integer&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86588">
    <a href="/manual/vote-note.php?id=86588&amp;page=language.types.integer&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86588" title="42% like this...">
    -15
    </div>
  </div>
  <a href="#86588" class="name">
  <strong class="user"><em>Hamza Burak Ylmaz</em></strong></a><a class="genanchor" href="#86588"> &para;</a><div class="date" title="2008-10-24 02:36"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86588">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br /></span><span class="comment">//This is a simple function to return number of digits of an integer.<br /><br />//function declaration<br /></span><span class="keyword">function </span><span class="default">count_digit</span><span class="keyword">(</span><span class="default">$number</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="default">$digit </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />&nbsp; &nbsp; do<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$number </span><span class="keyword">/= </span><span class="default">10</span><span class="keyword">;&nbsp; &nbsp; &nbsp; </span><span class="comment">//$number = $number / 10;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$number </span><span class="keyword">= </span><span class="default">intval</span><span class="keyword">(</span><span class="default">$number</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$digit</span><span class="keyword">++;&nbsp; &nbsp; <br />&nbsp; &nbsp; }while(</span><span class="default">$number</span><span class="keyword">!=</span><span class="default">0</span><span class="keyword">);<br />&nbsp; &nbsp; return </span><span class="default">$digit</span><span class="keyword">;<br />}<br /><br /></span><span class="comment">//function call<br /></span><span class="default">$num </span><span class="keyword">= </span><span class="default">12312</span><span class="keyword">;<br /></span><span class="default">$number_of_digits </span><span class="keyword">= </span><span class="default">count_digit</span><span class="keyword">(</span><span class="default">$num</span><span class="keyword">); </span><span class="comment">//this is call :)<br /></span><span class="keyword">echo </span><span class="default">$number_of_digits</span><span class="keyword">;<br /></span><span class="comment">//prints 5<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="49417">  <div class="votes">
    <div id="Vu49417">
    <a href="/manual/vote-note.php?id=49417&amp;page=language.types.integer&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd49417">
    <a href="/manual/vote-note.php?id=49417&amp;page=language.types.integer&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V49417" title="42% like this...">
    -14
    </div>
  </div>
  <a href="#49417" class="name">
  <strong class="user"><em>rickard_cedergren at yahoo dot com</em></strong></a><a class="genanchor" href="#49417"> &para;</a><div class="date" title="2005-01-27 01:15"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom49417">
<div class="phpcode"><code><span class="html">
When doing large subtractions on 32 bit unsigned integers the result sometimes end up negative. My example script converts a IPv4 address represented as a 32 bit unsigned integer to a dotted quad (similar to ip2long()), and adds a "fix" to the operation. <br /><br />&nbsp;&nbsp; /**************************<br />&nbsp; &nbsp; * int_oct($ip) <br />&nbsp; &nbsp; * Convert INTeger rep of IP to octal (dotted quad)<br />&nbsp; &nbsp; */<br />&nbsp;&nbsp; function int_oct($ip) {<br /><br />&nbsp; &nbsp; &nbsp; /* Set variable to float */<br />&nbsp; &nbsp; &nbsp; settype($ip, float);<br /><br />&nbsp; &nbsp; &nbsp; /* FIX for silly PHP integer syndrome */<br />&nbsp; &nbsp; &nbsp; $fix = 0;<br />&nbsp; &nbsp; &nbsp; if($ip &gt; 2147483647) $fix = 16777216;<br /><br />&nbsp; &nbsp; &nbsp; if(is_numeric($ip)) {<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; return(sprintf("%u.%u.%u.%u",<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $ip / 16777216,<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (($ip % 16777216) + $fix) / 65536,<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; (($ip % 65536) + $fix / 256) / 256,<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ($ip % 256) + $fix / 256 / 256<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; )<br />&nbsp; &nbsp;&nbsp; );<br />&nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; else {<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; return('');<br />&nbsp; &nbsp; &nbsp; }<br />&nbsp;&nbsp; }</span>
</code></div>
  </div>
 </div>
  <div class="note" id="88075">  <div class="votes">
    <div id="Vu88075">
    <a href="/manual/vote-note.php?id=88075&amp;page=language.types.integer&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd88075">
    <a href="/manual/vote-note.php?id=88075&amp;page=language.types.integer&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V88075" title="39% like this...">
    -23
    </div>
  </div>
  <a href="#88075" class="name">
  <strong class="user"><em>sean dot gilbertson at gmail dot com</em></strong></a><a class="genanchor" href="#88075"> &para;</a><div class="date" title="2009-01-08 01:57"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom88075">
<div class="phpcode"><code><span class="html">
You can make a signed, negative integer an unsigned integer (in string form) by doing the following:<br /><br /><span class="default">&lt;?php<br />$unsigned </span><span class="keyword">= </span><span class="default">sprintf</span><span class="keyword">(</span><span class="string">'%u'</span><span class="keyword">, -</span><span class="default">5</span><span class="keyword">);<br /><br />echo </span><span class="default">$unsigned</span><span class="keyword">; </span><span class="comment">// prints 4294967291<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="103506">  <div class="votes">
    <div id="Vu103506">
    <a href="/manual/vote-note.php?id=103506&amp;page=language.types.integer&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd103506">
    <a href="/manual/vote-note.php?id=103506&amp;page=language.types.integer&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V103506" title="32% like this...">
    -35
    </div>
  </div>
  <a href="#103506" class="name">
  <strong class="user"><em>Richard</em></strong></a><a class="genanchor" href="#103506"> &para;</a><div class="date" title="2011-04-16 09:53"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom103506">
<div class="phpcode"><code><span class="html">
Integer arithmetic in PHP is more accurate than one might think. On a 32-bit system, the largest value that can be held in an INT is&nbsp; 2147483647.<br />However, a FLOAT can accurately hold integer values up to 10000000000000.<br />(this is because the significand precision of a double is 53-bits).</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.types.integer&amp;redirect=http://php.net/manual/en/language.types.integer.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.types.php">Types</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.types.intro.php" title="Introduction">Introduction</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.boolean.php" title="Booleans">Booleans</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.types.integer.php" title="Integers">Integers</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.float.php" title="Floating point numbers">Floating point numbers</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.string.php" title="Strings">Strings</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.array.php" title="Arrays">Arrays</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.iterable.php" title="Iterables">Iterables</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.object.php" title="Objects">Objects</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.resource.php" title="Resources">Resources</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.null.php" title="NULL">NULL</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.callable.php" title="Callbacks / Callables">Callbacks / Callables</a>
                        </li>
                          
                        <li class="">
                            <a href="language.pseudo-types.php" title="Pseudo-&#8203;types and variables used in this documentation">Pseudo-&#8203;types and variables used in this documentation</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.type-juggling.php" title="Type Juggling">Type Juggling</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

