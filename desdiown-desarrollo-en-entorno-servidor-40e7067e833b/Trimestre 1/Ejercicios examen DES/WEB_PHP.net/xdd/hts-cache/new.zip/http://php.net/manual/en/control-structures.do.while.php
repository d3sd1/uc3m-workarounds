<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: do-while - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/control-structures.do.while.php">
 <link rel="shorturl" href="http://php.net/do.while">
 <link rel="alternate" href="http://php.net/do.while" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.control-structures.php">
 <link rel="prev" href="http://php.net/manual/en/control-structures.while.php">
 <link rel="next" href="http://php.net/manual/en/control-structures.for.php">

 <link rel="alternate" href="http://php.net/manual/en/control-structures.do.while.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/control-structures.do.while.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/control-structures.do.while.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/control-structures.do.while.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/control-structures.do.while.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/control-structures.do.while.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/control-structures.do.while.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/control-structures.do.while.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/control-structures.do.while.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/control-structures.do.while.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/control-structures.do.while.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="control-structures.for.php">
          for &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="control-structures.while.php">
          &laquo; while        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.control-structures.php'>Control Structures</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/control-structures.do.while.php' selected="selected">English</option>
            <option value='pt_BR/control-structures.do.while.php'>Brazilian Portuguese</option>
            <option value='zh/control-structures.do.while.php'>Chinese (Simplified)</option>
            <option value='fr/control-structures.do.while.php'>French</option>
            <option value='de/control-structures.do.while.php'>German</option>
            <option value='ja/control-structures.do.while.php'>Japanese</option>
            <option value='ro/control-structures.do.while.php'>Romanian</option>
            <option value='ru/control-structures.do.while.php'>Russian</option>
            <option value='es/control-structures.do.while.php'>Spanish</option>
            <option value='tr/control-structures.do.while.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/control-structures.do.while.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=control-structures.do.while">Report a Bug</a>
    </div>
  </div><div id="control-structures.do.while" class="sect1">
 <h2 class="title"><em>do-while</em></h2>
 <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p>
 <p class="simpara">
  <em>do-while</em> loops are very similar to
  <em>while</em> loops, except the truth expression is
  checked at the end of each iteration instead of in the beginning.
  The main difference from regular <em>while</em> loops is
  that the first iteration of a <em>do-while</em> loop is
  guaranteed to run (the truth expression is only checked at the end
  of the iteration), whereas it may not necessarily run with a
  regular <em>while</em> loop (the truth expression is
  checked at the beginning of each iteration, if it evaluates to
  <strong><code>FALSE</code></strong> right from the beginning, the loop
  execution would end immediately).
 </p>
 <p class="para">
  There is just one syntax for <em>do-while</em> loops:

  <div class="informalexample">
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$i&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">0</span><span style="color: #007700">;<br />do&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #0000BB">$i</span><span style="color: #007700">;<br />}&nbsp;while&nbsp;(</span><span style="color: #0000BB">$i&nbsp;</span><span style="color: #007700">&gt;&nbsp;</span><span style="color: #0000BB">0</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>
 </p>
 <p class="simpara">
   The above loop would run one time exactly, since after the first
   iteration, when truth expression is checked, it evaluates to
   <strong><code>FALSE</code></strong> (<var class="varname"><var class="varname">$i</var></var> is not bigger than 0) and the loop
   execution ends.
 </p>
 <p class="para">
  Advanced C users may be familiar with a different usage of the
  <em>do-while</em> loop, to allow stopping execution in
  the middle of code blocks, by encapsulating them with
  <em>do-while</em> (0), and using the <a href="control-structures.break.php" class="link"><em>break</em></a>
  statement.  The following code fragment demonstrates this:
  <div class="informalexample">
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">do&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(</span><span style="color: #0000BB">$i&nbsp;</span><span style="color: #007700">&lt;&nbsp;</span><span style="color: #0000BB">5</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"i&nbsp;is&nbsp;not&nbsp;big&nbsp;enough"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$i&nbsp;</span><span style="color: #007700">*=&nbsp;</span><span style="color: #0000BB">$factor</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(</span><span style="color: #0000BB">$i&nbsp;</span><span style="color: #007700">&lt;&nbsp;</span><span style="color: #0000BB">$minimum_limit</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"i&nbsp;is&nbsp;ok"</span><span style="color: #007700">;<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">/*&nbsp;process&nbsp;i&nbsp;*/<br /><br /></span><span style="color: #007700">}&nbsp;while&nbsp;(</span><span style="color: #0000BB">0</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>
 </p>
 <p class="simpara">
  Don&#039;t worry if you don&#039;t understand this right away or at all.
  You can code scripts and even powerful scripts without using this
  &#039;feature&#039;.
  Since PHP 5.3.0, it is possible to use
  <a href="control-structures.goto.php" class="link"><em>goto</em></a>
  operator instead of this hack.
 </p>
</div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=control-structures.do.while&amp;redirect=http://php.net/manual/en/control-structures.do.while.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">6 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="117186">  <div class="votes">
    <div id="Vu117186">
    <a href="/manual/vote-note.php?id=117186&amp;page=control-structures.do.while&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117186">
    <a href="/manual/vote-note.php?id=117186&amp;page=control-structures.do.while&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117186" title="59% like this...">
    18
    </div>
  </div>
  <a href="#117186" class="name">
  <strong class="user"><em>Martin</em></strong></a><a class="genanchor" href="#117186"> &para;</a><div class="date" title="2015-04-28 03:51"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117186">
<div class="phpcode"><code><span class="html">
Do-while loops can also be used inside other loops, for example:<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">// generating an array with random even numbers between 1 and 1000<br /><br /></span><span class="default">$numbers </span><span class="keyword">= array();<br /></span><span class="default">$array_size </span><span class="keyword">= </span><span class="default">10</span><span class="keyword">;<br /><br /></span><span class="comment">// for loop runs as long as 2nd condition evaluates to true<br /></span><span class="keyword">for (</span><span class="default">$i</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">;</span><span class="default">$i</span><span class="keyword">&lt;</span><span class="default">$array_size</span><span class="keyword">;</span><span class="default">$i</span><span class="keyword">++) { <br /><br />&nbsp; &nbsp; &nbsp; </span><span class="comment">// always executes (as long as the for-loop runs)<br />&nbsp; &nbsp; &nbsp; </span><span class="keyword">do { <br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$random </span><span class="keyword">= </span><span class="default">rand</span><span class="keyword">(</span><span class="default">1</span><span class="keyword">,</span><span class="default">1000</span><span class="keyword">);<br /><br />&nbsp; &nbsp;&nbsp; </span><span class="comment">// if the random number is even (condition below is false), the do-while-loop execution ends<br />&nbsp; &nbsp;&nbsp; // if it's uneven (condition below is true), the loop continues by generating a new random number<br />&nbsp; &nbsp;&nbsp; </span><span class="keyword">} while ((</span><span class="default">$random </span><span class="keyword">% </span><span class="default">2</span><span class="keyword">) == </span><span class="default">1</span><span class="keyword">);<br /><br />&nbsp; &nbsp;&nbsp; </span><span class="comment">// even random number is written to array and for-loop continues iteration until original condition is met<br />&nbsp; &nbsp;&nbsp; </span><span class="default">$numbers</span><span class="keyword">[] = </span><span class="default">$random</span><span class="keyword">; <br />}<br /><br /></span><span class="comment">// sorting array by alphabet<br /><br /></span><span class="default">asort</span><span class="keyword">(</span><span class="default">$numbers</span><span class="keyword">);<br /><br /></span><span class="comment">// printing array<br /><br /></span><span class="keyword">echo </span><span class="string">'&lt;pre&gt;'</span><span class="keyword">;<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$numbers</span><span class="keyword">);<br />echo </span><span class="string">'&lt;/pre&gt;'</span><span class="keyword">;<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="74419">  <div class="votes">
    <div id="Vu74419">
    <a href="/manual/vote-note.php?id=74419&amp;page=control-structures.do.while&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd74419">
    <a href="/manual/vote-note.php?id=74419&amp;page=control-structures.do.while&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V74419" title="55% like this...">
    13
    </div>
  </div>
  <a href="#74419" class="name">
  <strong class="user"><em>jayreardon at gmail dot com</em></strong></a><a class="genanchor" href="#74419"> &para;</a><div class="date" title="2007-04-10 03:36"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom74419">
<div class="phpcode"><code><span class="html">
There is one major difference you should be aware of when using the do--while loop vs. using a simple while loop:&nbsp; And that is when the check condition is made.&nbsp; <br /><br />In a do--while loop, the test condition evaluation is at the end of the loop.&nbsp; This means that the code inside of the loop will iterate once through before the condition is ever evaluated.&nbsp; This is ideal for tasks that need to execute once before a test is made to continue, such as test that is dependant upon the results of the loop.&nbsp; <br /><br />Conversely, a plain while loop evaluates the test condition at the begining of the loop before any execution in the loop block is ever made. If for some reason your test condition evaluates to false at the very start of the loop, none of the code inside your loop will be executed.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120271">  <div class="votes">
    <div id="Vu120271">
    <a href="/manual/vote-note.php?id=120271&amp;page=control-structures.do.while&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120271">
    <a href="/manual/vote-note.php?id=120271&amp;page=control-structures.do.while&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120271" title="43% like this...">
    -3
    </div>
  </div>
  <a href="#120271" class="name">
  <strong class="user"><em>fuhse at data-quest dot de</em></strong></a><a class="genanchor" href="#120271"> &para;</a><div class="date" title="2016-12-04 03:49"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom120271">
<div class="phpcode"><code><span class="html">
What actually surprised me: There is no alternative-syntax or template syntax for a do-while-loop.<br /><br />So you can write <br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">while (</span><span class="default">$a </span><span class="keyword">&lt; </span><span class="default">10</span><span class="keyword">) :<br />&nbsp; &nbsp; </span><span class="default">$a</span><span class="keyword">++;<br />endwhile;<br /></span><span class="default">?&gt;<br /></span><br />But this won't work:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">do :<br />&nbsp; &nbsp; </span><span class="default">$a</span><span class="keyword">++<br />while (</span><span class="default">$a </span><span class="keyword">&lt;= </span><span class="default">10</span><span class="keyword">);<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119595">  <div class="votes">
    <div id="Vu119595">
    <a href="/manual/vote-note.php?id=119595&amp;page=control-structures.do.while&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119595">
    <a href="/manual/vote-note.php?id=119595&amp;page=control-structures.do.while&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119595" title="41% like this...">
    -4
    </div>
  </div>
  <a href="#119595" class="name">
  <strong class="user"><em>jaysherby at gmail dot com</em></strong></a><a class="genanchor" href="#119595"> &para;</a><div class="date" title="2016-07-13 06:12"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119595">
<div class="phpcode"><code><span class="html">
The last example on this page is simply abuse of the `break` keyword.&nbsp; Also, the suggestion to use `goto` if you don't understand the abuse of `break` is unsettling.&nbsp; (See the manual page for `goto` for more than enough reasons not to use it.)<br /><br />The final example is generally better expressed using a typical if-else statement.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">if (</span><span class="default">$i </span><span class="keyword">&lt; </span><span class="default">5</span><span class="keyword">) {<br />&nbsp; &nbsp; echo </span><span class="string">"i is not big enough"</span><span class="keyword">;<br />} else {<br />&nbsp; &nbsp; </span><span class="default">$i </span><span class="keyword">*= </span><span class="default">$factor</span><span class="keyword">;<br /><br />&nbsp; &nbsp; if (</span><span class="default">$i </span><span class="keyword">&gt;= </span><span class="default">$minimum_limit</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; echo </span><span class="string">"i is ok"</span><span class="keyword">;<br /><br />&nbsp; &nbsp; &nbsp; </span><span class="comment">/* process i */<br />&nbsp; &nbsp; </span><span class="keyword">}<br />}<br /></span><span class="default">?&gt;<br /></span><br />This version is easier to read and understand.&nbsp; And arguments for code golf are invalid as well as this version is 3 lines shorter.<br /><br />In conclusion, although you can certainly write code that abuses the `break` keyword, you shouldn't in practice.&nbsp; Keep the code easy to read and understand for whoever inherits your code.&nbsp; And remember, code is for humans not computers.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="99468">  <div class="votes">
    <div id="Vu99468">
    <a href="/manual/vote-note.php?id=99468&amp;page=control-structures.do.while&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd99468">
    <a href="/manual/vote-note.php?id=99468&amp;page=control-structures.do.while&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V99468" title="40% like this...">
    -19
    </div>
  </div>
  <a href="#99468" class="name">
  <strong class="user"><em>shaida dot mca at gmail dot com</em></strong></a><a class="genanchor" href="#99468"> &para;</a><div class="date" title="2010-08-18 11:01"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom99468">
<div class="phpcode"><code><span class="html">
Example of Do while :-<br /><br /><span class="default">&lt;?php<br />$i </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />echo </span><span class="string">'This code will run at least once because i default value is 0.&lt;br/&gt;'</span><span class="keyword">;<br />do {<br />echo </span><span class="string">'i value is ' </span><span class="keyword">. </span><span class="default">$i </span><span class="keyword">. </span><span class="string">', so code block will run. &lt;br/&gt;'</span><span class="keyword">;<br />++</span><span class="default">$i</span><span class="keyword">;<br />} while (</span><span class="default">$i </span><span class="keyword">&lt; </span><span class="default">10</span><span class="keyword">);<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="85739">  <div class="votes">
    <div id="Vu85739">
    <a href="/manual/vote-note.php?id=85739&amp;page=control-structures.do.while&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd85739">
    <a href="/manual/vote-note.php?id=85739&amp;page=control-structures.do.while&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V85739" title="38% like this...">
    -21
    </div>
  </div>
  <a href="#85739" class="name">
  <strong class="user"><em>andrew at NOSPAM dot devohive dot com</em></strong></a><a class="genanchor" href="#85739"> &para;</a><div class="date" title="2008-09-15 10:44"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom85739">
<div class="phpcode"><code><span class="html">
I'm guilty of writing constructs without curly braces sometimes... writing the do--while seemed a bit odd without the curly braces ({ and }), but just so everyone is aware of how this is written with a do--while...<br /><br />a normal while:<br /><span class="default">&lt;?php<br />&nbsp;&nbsp; </span><span class="keyword">while ( </span><span class="default">$isValid </span><span class="keyword">) </span><span class="default">$isValid </span><span class="keyword">= </span><span class="default">doSomething</span><span class="keyword">(</span><span class="default">$input</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />a do--while:<br /><span class="default">&lt;?php<br />&nbsp;&nbsp; </span><span class="keyword">do </span><span class="default">$isValid </span><span class="keyword">= </span><span class="default">doSomething</span><span class="keyword">(</span><span class="default">$input</span><span class="keyword">);<br />&nbsp;&nbsp; while ( </span><span class="default">$isValid </span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />Also, a practical example of when to use a do--while when a simple while just won't do (lol)... copying multiple 2nd level nodes from one document to another using the DOM XML extension<br /><br /><span class="default">&lt;?php<br />&nbsp;&nbsp; </span><span class="comment"># open up/create the documents and grab the root element<br />&nbsp;&nbsp; </span><span class="default">$fileDoc&nbsp; </span><span class="keyword">= </span><span class="default">domxml_open_file</span><span class="keyword">(</span><span class="string">'example.xml'</span><span class="keyword">); </span><span class="comment">// existing xml we want to copy<br />&nbsp;&nbsp; </span><span class="default">$fileRoot </span><span class="keyword">= </span><span class="default">$fileDoc</span><span class="keyword">-&gt;</span><span class="default">document_element</span><span class="keyword">();<br />&nbsp;&nbsp; </span><span class="default">$newDoc&nbsp;&nbsp; </span><span class="keyword">= </span><span class="default">domxml_new_doc</span><span class="keyword">(</span><span class="string">'1.0'</span><span class="keyword">); </span><span class="comment">// new document we want to copy to<br />&nbsp;&nbsp; </span><span class="default">$newRoot&nbsp; </span><span class="keyword">= </span><span class="default">$newDoc</span><span class="keyword">-&gt;</span><span class="default">create_element</span><span class="keyword">(</span><span class="string">'rootnode'</span><span class="keyword">);<br />&nbsp;&nbsp; </span><span class="default">$newRoot&nbsp; </span><span class="keyword">= </span><span class="default">$newDoc</span><span class="keyword">-&gt;</span><span class="default">append_child</span><span class="keyword">(</span><span class="default">$newRoot</span><span class="keyword">); </span><span class="comment">// this is the node we want to copy to<br /><br />&nbsp;&nbsp; # loop through nodes and clone (using deep)<br />&nbsp;&nbsp; </span><span class="default">$child </span><span class="keyword">= </span><span class="default">$fileRoot</span><span class="keyword">-&gt;</span><span class="default">first_child</span><span class="keyword">(); </span><span class="comment">// first_child must be called once and can only be called once<br />&nbsp;&nbsp; </span><span class="keyword">do </span><span class="default">$newRoot</span><span class="keyword">-&gt;</span><span class="default">append_child</span><span class="keyword">(</span><span class="default">$child</span><span class="keyword">-&gt;</span><span class="default">clone_node</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">)); </span><span class="comment">// do first, so that the result from first_child is appended<br />&nbsp;&nbsp; </span><span class="keyword">while ( </span><span class="default">$child </span><span class="keyword">= </span><span class="default">$child</span><span class="keyword">-&gt;</span><span class="default">next_sibling</span><span class="keyword">() ); </span><span class="comment">// we have to use next_sibling for everything after first_child<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=control-structures.do.while&amp;redirect=http://php.net/manual/en/control-structures.do.while.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.control-structures.php">Control Structures</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="control-structures.intro.php" title="Introduction">Introduction</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.if.php" title="if">if</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.else.php" title="else">else</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.elseif.php" title="elseif/else if">elseif/else if</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.alternative-syntax.php" title="Alternative syntax for control structures">Alternative syntax for control structures</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.while.php" title="while">while</a>
                        </li>
                          
                        <li class="current">
                            <a href="control-structures.do.while.php" title="do-&#8203;while">do-&#8203;while</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.for.php" title="for">for</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.foreach.php" title="foreach">foreach</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.break.php" title="break">break</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.continue.php" title="continue">continue</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.switch.php" title="switch">switch</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.declare.php" title="declare">declare</a>
                        </li>
                          
                        <li class="">
                            <a href="function.return.php" title="return">return</a>
                        </li>
                          
                        <li class="">
                            <a href="function.require.php" title="require">require</a>
                        </li>
                          
                        <li class="">
                            <a href="function.include.php" title="include">include</a>
                        </li>
                          
                        <li class="">
                            <a href="function.require-once.php" title="require_&#8203;once">require_&#8203;once</a>
                        </li>
                          
                        <li class="">
                            <a href="function.include-once.php" title="include_&#8203;once">include_&#8203;once</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.goto.php" title="goto">goto</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

