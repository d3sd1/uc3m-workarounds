<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Classes and Objects - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.oop5.php">
 <link rel="shorturl" href="http://php.net/oop5">
 <link rel="alternate" href="http://php.net/oop5" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/langref.php">
 <link rel="prev" href="http://php.net/manual/en/functions.anonymous.php">
 <link rel="next" href="http://php.net/manual/en/oop5.intro.php">

 <link rel="alternate" href="http://php.net/manual/en/language.oop5.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.oop5.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.oop5.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.oop5.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.oop5.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.oop5.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.oop5.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.oop5.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.oop5.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.oop5.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.oop5.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="oop5.intro.php">
          Introduction &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="functions.anonymous.php">
          &laquo; Anonymous functions        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.oop5.php' selected="selected">English</option>
            <option value='pt_BR/language.oop5.php'>Brazilian Portuguese</option>
            <option value='zh/language.oop5.php'>Chinese (Simplified)</option>
            <option value='fr/language.oop5.php'>French</option>
            <option value='de/language.oop5.php'>German</option>
            <option value='ja/language.oop5.php'>Japanese</option>
            <option value='ro/language.oop5.php'>Romanian</option>
            <option value='ru/language.oop5.php'>Russian</option>
            <option value='es/language.oop5.php'>Spanish</option>
            <option value='tr/language.oop5.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.oop5.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.oop5">Report a Bug</a>
    </div>
  </div><div id="language.oop5" class="chapter">
  <h1>Classes and Objects</h1>
<h2>Table of Contents</h2><ul class="chunklist chunklist_chapter"><li><a href="oop5.intro.php">Introduction</a></li><li><a href="language.oop5.basic.php">The Basics</a></li><li><a href="language.oop5.properties.php">Properties</a></li><li><a href="language.oop5.constants.php">Class Constants</a></li><li><a href="language.oop5.autoload.php">Autoloading Classes</a></li><li><a href="language.oop5.decon.php">Constructors and Destructors</a></li><li><a href="language.oop5.visibility.php">Visibility</a></li><li><a href="language.oop5.inheritance.php">Object Inheritance</a></li><li><a href="language.oop5.paamayim-nekudotayim.php">Scope Resolution Operator (::)</a></li><li><a href="language.oop5.static.php">Static Keyword</a></li><li><a href="language.oop5.abstract.php">Class Abstraction</a></li><li><a href="language.oop5.interfaces.php">Object Interfaces</a></li><li><a href="language.oop5.traits.php">Traits</a></li><li><a href="language.oop5.anonymous.php">Anonymous classes</a></li><li><a href="language.oop5.overloading.php">Overloading</a></li><li><a href="language.oop5.iterations.php">Object Iteration</a></li><li><a href="language.oop5.magic.php">Magic Methods</a></li><li><a href="language.oop5.final.php">Final Keyword</a></li><li><a href="language.oop5.cloning.php">Object Cloning</a></li><li><a href="language.oop5.object-comparison.php">Comparing Objects</a></li><li><a href="language.oop5.typehinting.php">Type Hinting</a></li><li><a href="language.oop5.late-static-bindings.php">Late Static Bindings</a></li><li><a href="language.oop5.references.php">Objects and references</a></li><li><a href="language.oop5.serialization.php">Object Serialization</a></li><li><a href="language.oop5.changelog.php">OOP Changelog</a></li></ul>


  

  


 



  

 
 


  




  

 
 


  

 



  

 
 


  

 
 


  





  

 
 


  

 



  

 
 


  

 



  



 


  

 



  

 
 


  

 
 


  

 
 


  

 
 


  

  
 


  



 


  

 



  

 


  

 
 


  


 


</div>

<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.oop5&amp;redirect=http://php.net/manual/en/language.oop5.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">8 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="46290">  <div class="votes">
    <div id="Vu46290">
    <a href="/manual/vote-note.php?id=46290&amp;page=language.oop5&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd46290">
    <a href="/manual/vote-note.php?id=46290&amp;page=language.oop5&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V46290" title="55% like this...">
    74
    </div>
  </div>
  <a href="#46290" class="name">
  <strong class="user"><em>farzan at ifarzan dot com</em></strong></a><a class="genanchor" href="#46290"> &para;</a><div class="date" title="2004-10-05 04:04"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom46290">
<div class="phpcode"><code><span class="html">
PHP 5 is very very flexible in accessing member variables and member functions. These access methods maybe look unusual and unnecessary at first glance; but they are very useful sometimes; specially when you work with SimpleXML classes and objects. I have posted a similar comment in SimpleXML function reference section, but this one is more comprehensive.<br /><br />I use the following class as reference for all examples:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Foo </span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$aMemberVar </span><span class="keyword">= </span><span class="string">'aMemberVar Member Variable'</span><span class="keyword">;<br />&nbsp; &nbsp; public </span><span class="default">$aFuncName </span><span class="keyword">= </span><span class="string">'aMemberFunc'</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">aMemberFunc</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; print </span><span class="string">'Inside `aMemberFunc()`'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$foo </span><span class="keyword">= new </span><span class="default">Foo</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />You can access member variables in an object using another variable as name:<br /><br /><span class="default">&lt;?php<br />$element </span><span class="keyword">= </span><span class="string">'aMemberVar'</span><span class="keyword">;<br />print </span><span class="default">$foo</span><span class="keyword">-&gt;</span><span class="default">$element</span><span class="keyword">; </span><span class="comment">// prints "aMemberVar Member Variable"<br /></span><span class="default">?&gt;<br /></span><br />or use functions:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">getVarName</span><span class="keyword">()<br />{ return </span><span class="string">'aMemberVar'</span><span class="keyword">; }<br /><br />print </span><span class="default">$foo</span><span class="keyword">-&gt;{</span><span class="default">getVarName</span><span class="keyword">()}; </span><span class="comment">// prints "aMemberVar Member Variable"<br /></span><span class="default">?&gt;<br /></span><br />Important Note: You must surround function name with { and } or PHP would think you are calling a member function of object "foo".<br /><br />you can use a constant or literal as well:<br /><br /><span class="default">&lt;?php<br />define</span><span class="keyword">(</span><span class="default">MY_CONSTANT</span><span class="keyword">, </span><span class="string">'aMemberVar'</span><span class="keyword">);<br />print </span><span class="default">$foo</span><span class="keyword">-&gt;{</span><span class="default">MY_CONSTANT</span><span class="keyword">}; </span><span class="comment">// Prints "aMemberVar Member Variable"<br /></span><span class="keyword">print </span><span class="default">$foo</span><span class="keyword">-&gt;{</span><span class="string">'aMemberVar'</span><span class="keyword">}; </span><span class="comment">// Prints "aMemberVar Member Variable"<br /></span><span class="default">?&gt;<br /></span><br />You can use members of other objects as well:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">print </span><span class="default">$foo</span><span class="keyword">-&gt;{</span><span class="default">$otherObj</span><span class="keyword">-&gt;</span><span class="default">var</span><span class="keyword">};<br />print </span><span class="default">$foo</span><span class="keyword">-&gt;{</span><span class="default">$otherObj</span><span class="keyword">-&gt;</span><span class="default">func</span><span class="keyword">()};<br /></span><span class="default">?&gt;<br /></span><br />You can use mathods above to access member functions as well:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">print </span><span class="default">$foo</span><span class="keyword">-&gt;{</span><span class="string">'aMemberFunc'</span><span class="keyword">}(); </span><span class="comment">// Prints "Inside `aMemberFunc()`"<br /></span><span class="keyword">print </span><span class="default">$foo</span><span class="keyword">-&gt;{</span><span class="default">$foo</span><span class="keyword">-&gt;</span><span class="default">aFuncName</span><span class="keyword">}(); </span><span class="comment">// Prints "Inside `aMemberFunc()`"<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="84292">  <div class="votes">
    <div id="Vu84292">
    <a href="/manual/vote-note.php?id=84292&amp;page=language.oop5&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd84292">
    <a href="/manual/vote-note.php?id=84292&amp;page=language.oop5&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V84292" title="51% like this...">
    41
    </div>
  </div>
  <a href="#84292" class="name">
  <strong class="user"><em>Jason</em></strong></a><a class="genanchor" href="#84292"> &para;</a><div class="date" title="2008-07-07 10:34"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom84292">
<div class="phpcode"><code><span class="html">
For real quick and dirty one-liner anonymous objects, just cast an associative array:<br /><br /><span class="default">&lt;?php<br /><br />$obj </span><span class="keyword">= (object) array(</span><span class="string">'foo' </span><span class="keyword">=&gt; </span><span class="string">'bar'</span><span class="keyword">, </span><span class="string">'property' </span><span class="keyword">=&gt; </span><span class="string">'value'</span><span class="keyword">);<br /><br />echo </span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">foo</span><span class="keyword">; </span><span class="comment">// prints 'bar'<br /></span><span class="keyword">echo </span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">property</span><span class="keyword">; </span><span class="comment">// prints 'value'<br /><br /></span><span class="default">?&gt;<br /></span><br />... no need to create a new class or function to accomplish it.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="101929">  <div class="votes">
    <div id="Vu101929">
    <a href="/manual/vote-note.php?id=101929&amp;page=language.oop5&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd101929">
    <a href="/manual/vote-note.php?id=101929&amp;page=language.oop5&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V101929" title="41% like this...">
    -66
    </div>
  </div>
  <a href="#101929" class="name">
  <strong class="user"><em>dances_with_peons at live dot com</em></strong></a><a class="genanchor" href="#101929"> &para;</a><div class="date" title="2011-01-18 02:36"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom101929">
<div class="phpcode"><code><span class="html">
As of PHP 5.3, $className::funcName() works fine.<br /><br /><span class="default">&lt;?php<br /><br />&nbsp; </span><span class="keyword">class </span><span class="default">test<br />&nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; public static function </span><span class="default">run</span><span class="keyword">() { print </span><span class="string">"Works\n"</span><span class="keyword">; }<br />&nbsp; }<br /><br />&nbsp; </span><span class="default">$className </span><span class="keyword">= </span><span class="string">'test'</span><span class="keyword">;<br />&nbsp; </span><span class="default">$className</span><span class="keyword">::</span><span class="default">run</span><span class="keyword">();<br /><br /></span><span class="default">?&gt;<br /></span><br />on my system, prints "Works".&nbsp; May work with earlier versions of PHP as well.&nbsp; Even if it doesn't, there's always<br /><br /><span class="default">&lt;?php<br /><br />&nbsp; $className </span><span class="keyword">= </span><span class="string">'test'</span><span class="keyword">;<br />&nbsp; </span><span class="default">call_user_func</span><span class="keyword">(array(</span><span class="default">$className</span><span class="keyword">, </span><span class="string">'run'</span><span class="keyword">));<br /><br /></span><span class="default">?&gt;<br /></span><br />The point is, there's no need for eval.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="87942">  <div class="votes">
    <div id="Vu87942">
    <a href="/manual/vote-note.php?id=87942&amp;page=language.oop5&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd87942">
    <a href="/manual/vote-note.php?id=87942&amp;page=language.oop5&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V87942" title="42% like this...">
    -70
    </div>
  </div>
  <a href="#87942" class="name">
  <strong class="user"><em>redrik at gmail dot com</em></strong></a><a class="genanchor" href="#87942"> &para;</a><div class="date" title="2008-12-31 01:08"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom87942">
<div class="phpcode"><code><span class="html">
Maybe someone will find these classes, which simulate enumeration, useful.<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Enum </span><span class="keyword">{<br />&nbsp; &nbsp; protected </span><span class="default">$self </span><span class="keyword">= array();<br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">( </span><span class="comment">/*...*/ </span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$args </span><span class="keyword">= </span><span class="default">func_get_args</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; for( </span><span class="default">$i</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">, </span><span class="default">$n</span><span class="keyword">=</span><span class="default">count</span><span class="keyword">(</span><span class="default">$args</span><span class="keyword">); </span><span class="default">$i</span><span class="keyword">&lt;</span><span class="default">$n</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">++ )<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">add</span><span class="keyword">(</span><span class="default">$args</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">]);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">__get</span><span class="keyword">( </span><span class="comment">/*string*/ </span><span class="default">$name </span><span class="keyword">= </span><span class="default">null </span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">self</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">];<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">add</span><span class="keyword">( </span><span class="comment">/*string*/ </span><span class="default">$name </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">, </span><span class="comment">/*int*/ </span><span class="default">$enum </span><span class="keyword">= </span><span class="default">null </span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if( isset(</span><span class="default">$enum</span><span class="keyword">) )<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">self</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">] = </span><span class="default">$enum</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">self</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">] = </span><span class="default">end</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">self</span><span class="keyword">) + </span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">DefinedEnum </span><span class="keyword">extends </span><span class="default">Enum </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">( </span><span class="comment">/*array*/ </span><span class="default">$itms </span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach( </span><span class="default">$itms </span><span class="keyword">as </span><span class="default">$name </span><span class="keyword">=&gt; </span><span class="default">$enum </span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">add</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">, </span><span class="default">$enum</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">FlagsEnum </span><span class="keyword">extends </span><span class="default">Enum </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">( </span><span class="comment">/*...*/ </span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$args </span><span class="keyword">= </span><span class="default">func_get_args</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; for( </span><span class="default">$i</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">, </span><span class="default">$n</span><span class="keyword">=</span><span class="default">count</span><span class="keyword">(</span><span class="default">$args</span><span class="keyword">), </span><span class="default">$f</span><span class="keyword">=</span><span class="default">0x1</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">&lt;</span><span class="default">$n</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">++, </span><span class="default">$f </span><span class="keyword">*= </span><span class="default">0x2 </span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">add</span><span class="keyword">(</span><span class="default">$args</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">], </span><span class="default">$f</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span>Example usage:<br /><span class="default">&lt;?php<br />$eFruits </span><span class="keyword">= new </span><span class="default">Enum</span><span class="keyword">(</span><span class="string">"APPLE"</span><span class="keyword">, </span><span class="string">"ORANGE"</span><span class="keyword">, </span><span class="string">"PEACH"</span><span class="keyword">);<br />echo </span><span class="default">$eFruits</span><span class="keyword">-&gt;</span><span class="default">APPLE </span><span class="keyword">. </span><span class="string">","</span><span class="keyword">;<br />echo </span><span class="default">$eFruits</span><span class="keyword">-&gt;</span><span class="default">ORANGE </span><span class="keyword">. </span><span class="string">","</span><span class="keyword">;<br />echo </span><span class="default">$eFruits</span><span class="keyword">-&gt;</span><span class="default">PEACH </span><span class="keyword">. </span><span class="string">"\n"</span><span class="keyword">;<br /><br /></span><span class="default">$eBeers </span><span class="keyword">= new </span><span class="default">DefinedEnum</span><span class="keyword">(</span><span class="string">"GUINESS" </span><span class="keyword">=&gt; </span><span class="default">25</span><span class="keyword">, </span><span class="string">"MIRROR_POND" </span><span class="keyword">=&gt; </span><span class="default">49</span><span class="keyword">);<br />echo </span><span class="default">$eBeers</span><span class="keyword">-&gt;</span><span class="default">GUINESS </span><span class="keyword">. </span><span class="string">","</span><span class="keyword">;<br />echo </span><span class="default">$eBeers</span><span class="keyword">-&gt;</span><span class="default">MIRROR_POND </span><span class="keyword">. </span><span class="string">"\n"</span><span class="keyword">;<br /><br /></span><span class="default">$eFlags </span><span class="keyword">= new </span><span class="default">FlagsEnum</span><span class="keyword">(</span><span class="string">"HAS_ADMIN"</span><span class="keyword">, </span><span class="string">"HAS_SUPER"</span><span class="keyword">, </span><span class="string">"HAS_POWER"</span><span class="keyword">, </span><span class="string">"HAS_GUEST"</span><span class="keyword">);<br />echo </span><span class="default">$eFlags</span><span class="keyword">-&gt;</span><span class="default">HAS_ADMIN </span><span class="keyword">. </span><span class="string">","</span><span class="keyword">;<br />echo </span><span class="default">$eFlags</span><span class="keyword">-&gt;</span><span class="default">HAS_SUPER </span><span class="keyword">. </span><span class="string">","</span><span class="keyword">;<br />echo </span><span class="default">$eFlags</span><span class="keyword">-&gt;</span><span class="default">HAS_POWER </span><span class="keyword">. </span><span class="string">","</span><span class="keyword">;<br />echo </span><span class="default">$eFlags</span><span class="keyword">-&gt;</span><span class="default">HAS_GUEST </span><span class="keyword">. </span><span class="string">"\n"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span>Will output: <br />1, 2, 3<br />25, 49<br />1,2,4,8 (or 1, 10, 100, 1000 in binary)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="101112">  <div class="votes">
    <div id="Vu101112">
    <a href="/manual/vote-note.php?id=101112&amp;page=language.oop5&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd101112">
    <a href="/manual/vote-note.php?id=101112&amp;page=language.oop5&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V101112" title="42% like this...">
    -74
    </div>
  </div>
  <a href="#101112" class="name">
  <strong class="user"><em>corpus-deus at softhome dot net</em></strong></a><a class="genanchor" href="#101112"> &para;</a><div class="date" title="2010-11-26 08:27"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom101112">
<div class="phpcode"><code><span class="html">
With regards to Singleton patterns (and variable class names) - try:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">MyClass </span><span class="keyword">{<br /><br />&nbsp; </span><span class="comment">// singleton instance<br />&nbsp; </span><span class="keyword">private static </span><span class="default">$instance</span><span class="keyword">;<br /><br />&nbsp; </span><span class="comment">// private constructor function<br />&nbsp; // to prevent external instantiation<br />&nbsp; </span><span class="keyword">private </span><span class="default">__construct</span><span class="keyword">() { }<br /><br />&nbsp; </span><span class="comment">// getInstance method<br />&nbsp; </span><span class="keyword">public static function </span><span class="default">getInstance</span><span class="keyword">() {<br /><br />&nbsp; &nbsp; if(!</span><span class="default">self</span><span class="keyword">::</span><span class="default">$instance</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">$instance </span><span class="keyword">= new </span><span class="default">self</span><span class="keyword">();<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; return </span><span class="default">self</span><span class="keyword">::</span><span class="default">$instance</span><span class="keyword">;<br /><br />&nbsp; }<br /><br />&nbsp; </span><span class="comment">//...<br /><br /></span><span class="keyword">}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114443">  <div class="votes">
    <div id="Vu114443">
    <a href="/manual/vote-note.php?id=114443&amp;page=language.oop5&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114443">
    <a href="/manual/vote-note.php?id=114443&amp;page=language.oop5&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114443" title="38% like this...">
    -62
    </div>
  </div>
  <a href="#114443" class="name">
  <strong class="user"><em>Ashley Dambra</em></strong></a><a class="genanchor" href="#114443"> &para;</a><div class="date" title="2014-02-21 06:50"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114443">
<div class="phpcode"><code><span class="html">
Here a simple class 'stdObject' that give us the possibility to create dynamic classes and the possibility to add and execute methods thing that 'stdClass' don't let us do.&nbsp; Very useful if you extends it to a controller on MVC Design pattern. Let users create own classes.<br /><br />I have also post this class on <a href="http://www.php.net/manual/en/language.types.object.php" rel="nofollow" target="_blank">http://www.php.net/manual/en/language.types.object.php</a><br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">stdObject </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">(array </span><span class="default">$arguments </span><span class="keyword">= array()) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (!empty(</span><span class="default">$arguments</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; foreach (</span><span class="default">$arguments </span><span class="keyword">as </span><span class="default">$property </span><span class="keyword">=&gt; </span><span class="default">$argument</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;{</span><span class="default">$property</span><span class="keyword">} = </span><span class="default">$argument</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">__call</span><span class="keyword">(</span><span class="default">$method</span><span class="keyword">, </span><span class="default">$arguments</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$arguments </span><span class="keyword">= </span><span class="default">array_merge</span><span class="keyword">(array(</span><span class="string">"stdObject" </span><span class="keyword">=&gt; </span><span class="default">$this</span><span class="keyword">), </span><span class="default">$arguments</span><span class="keyword">); </span><span class="comment">// Note: method argument 0 will always referred to the main class ($this).<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">if (isset(</span><span class="default">$this</span><span class="keyword">-&gt;{</span><span class="default">$method</span><span class="keyword">}) &amp;&amp; </span><span class="default">is_callable</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;{</span><span class="default">$method</span><span class="keyword">})) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">call_user_func_array</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;{</span><span class="default">$method</span><span class="keyword">}, </span><span class="default">$arguments</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">Exception</span><span class="keyword">(</span><span class="string">"Fatal error: Call to undefined method stdObject::</span><span class="keyword">{</span><span class="default">$method</span><span class="keyword">}</span><span class="string">()"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="comment">// Usage.<br /><br /></span><span class="default">$obj </span><span class="keyword">= new </span><span class="default">stdObject</span><span class="keyword">();<br /></span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">name </span><span class="keyword">= </span><span class="string">"Nick"</span><span class="keyword">;<br /></span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">surname </span><span class="keyword">= </span><span class="string">"Doe"</span><span class="keyword">;<br /></span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">age </span><span class="keyword">= </span><span class="default">20</span><span class="keyword">;<br /></span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">adresse </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br /><br /></span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">getInfo </span><span class="keyword">= function(</span><span class="default">$stdObject</span><span class="keyword">) { </span><span class="comment">// $stdObject referred to this object (stdObject).<br />&nbsp; &nbsp; </span><span class="keyword">echo </span><span class="default">$stdObject</span><span class="keyword">-&gt;</span><span class="default">name </span><span class="keyword">. </span><span class="string">" " </span><span class="keyword">. </span><span class="default">$stdObject</span><span class="keyword">-&gt;</span><span class="default">surname </span><span class="keyword">. </span><span class="string">" have " </span><span class="keyword">. </span><span class="default">$stdObject</span><span class="keyword">-&gt;</span><span class="default">age </span><span class="keyword">. </span><span class="string">" yrs old. And live in " </span><span class="keyword">. </span><span class="default">$stdObject</span><span class="keyword">-&gt;</span><span class="default">adresse</span><span class="keyword">;<br />};<br /><br /></span><span class="default">$func </span><span class="keyword">= </span><span class="string">"setAge"</span><span class="keyword">;<br /></span><span class="default">$obj</span><span class="keyword">-&gt;{</span><span class="default">$func</span><span class="keyword">} = function(</span><span class="default">$stdObject</span><span class="keyword">, </span><span class="default">$age</span><span class="keyword">) { </span><span class="comment">// $age is the first parameter passed when calling this method.<br />&nbsp; &nbsp; </span><span class="default">$stdObject</span><span class="keyword">-&gt;</span><span class="default">age </span><span class="keyword">= </span><span class="default">$age</span><span class="keyword">;<br />};<br /><br /></span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">setAge</span><span class="keyword">(</span><span class="default">24</span><span class="keyword">); </span><span class="comment">// Parameter value 24 is passing to the $age argument in method 'setAge()'.<br /><br />// Create dynamic method. Here i'm generating getter and setter dynimically<br />// Beware: Method name are case sensitive.<br /></span><span class="keyword">foreach (</span><span class="default">$obj </span><span class="keyword">as </span><span class="default">$func_name </span><span class="keyword">=&gt; </span><span class="default">$value</span><span class="keyword">) {<br />&nbsp; &nbsp; if (!</span><span class="default">$value </span><span class="keyword">instanceOf </span><span class="default">Closure</span><span class="keyword">) {<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$obj</span><span class="keyword">-&gt;{</span><span class="string">"set" </span><span class="keyword">. </span><span class="default">ucfirst</span><span class="keyword">(</span><span class="default">$func_name</span><span class="keyword">)} = function(</span><span class="default">$stdObject</span><span class="keyword">, </span><span class="default">$value</span><span class="keyword">) use (</span><span class="default">$func_name</span><span class="keyword">) {&nbsp; </span><span class="comment">// Note: you can also use keyword 'use' to bind parent variables.<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$stdObject</span><span class="keyword">-&gt;{</span><span class="default">$func_name</span><span class="keyword">} = </span><span class="default">$value</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; };<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$obj</span><span class="keyword">-&gt;{</span><span class="string">"get" </span><span class="keyword">. </span><span class="default">ucfirst</span><span class="keyword">(</span><span class="default">$func_name</span><span class="keyword">)} = function(</span><span class="default">$stdObject</span><span class="keyword">) use (</span><span class="default">$func_name</span><span class="keyword">) {&nbsp; </span><span class="comment">// Note: you can also use keyword 'use' to bind parent variables.<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">$stdObject</span><span class="keyword">-&gt;{</span><span class="default">$func_name</span><span class="keyword">};<br />&nbsp; &nbsp; &nbsp; &nbsp; };<br /><br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">setName</span><span class="keyword">(</span><span class="string">"John"</span><span class="keyword">);<br /></span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">setAdresse</span><span class="keyword">(</span><span class="string">"Boston"</span><span class="keyword">);<br /><br /></span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">getInfo</span><span class="keyword">();<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="89296">  <div class="votes">
    <div id="Vu89296">
    <a href="/manual/vote-note.php?id=89296&amp;page=language.oop5&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd89296">
    <a href="/manual/vote-note.php?id=89296&amp;page=language.oop5&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V89296" title="41% like this...">
    -75
    </div>
  </div>
  <a href="#89296" class="name">
  <strong class="user"><em>midir</em></strong></a><a class="genanchor" href="#89296"> &para;</a><div class="date" title="2009-03-02 07:40"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom89296">
<div class="phpcode"><code><span class="html">
There are a couple of tricks you can do with PHP's classes that programmers from C++, etc., will find very peculiar, but which can be useful.<br /><br />You can create instances of classes without knowing the class name in advance, when it's in a variable:<br /><br /><span class="default">&lt;?php<br /><br />$type </span><span class="keyword">= </span><span class="string">'cc'</span><span class="keyword">;<br /></span><span class="default">$obj </span><span class="keyword">= new </span><span class="default">$type</span><span class="keyword">; </span><span class="comment">// outputs "hi!"<br /><br /></span><span class="keyword">class </span><span class="default">cc </span><span class="keyword">{<br />&nbsp; &nbsp; function </span><span class="default">__construct</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'hi!'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />You can also conditionally define them by wrapping them in if/else blocks etc, like so:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">if (</span><span class="default">expr</span><span class="keyword">) {<br />&nbsp; &nbsp; class </span><span class="default">cc </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// version 1<br />&nbsp; &nbsp; </span><span class="keyword">}<br />} else {<br />&nbsp; &nbsp; class </span><span class="default">cc </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// version 2<br />&nbsp; &nbsp; </span><span class="keyword">}<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />It makes up for PHP's lack of preprocessor directives. The caveat is that the if/else code body must have been executed before you can use the class, so you need to pay attention to the order of the code, and not use things before they're defined.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116800">  <div class="votes">
    <div id="Vu116800">
    <a href="/manual/vote-note.php?id=116800&amp;page=language.oop5&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116800">
    <a href="/manual/vote-note.php?id=116800&amp;page=language.oop5&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116800" title="33% like this...">
    -83
    </div>
  </div>
  <a href="#116800" class="name">
  <strong class="user"><em>0x174[d0t]14[at]gmail[d0t]com</em></strong></a><a class="genanchor" href="#116800"> &para;</a><div class="date" title="2015-03-02 02:58"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom116800">
<div class="phpcode"><code><span class="html">
A little trick for create an anonymous object&nbsp; (exactly an half-anonymous object :D aka "_") who can handle methods.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">_<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">( array </span><span class="default">$cfg</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach(</span><span class="default">$cfg </span><span class="keyword">as </span><span class="default">$k</span><span class="keyword">=&gt;</span><span class="default">$v</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;{</span><span class="default">$k</span><span class="keyword">}=</span><span class="default">$v</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">__call</span><span class="keyword">( </span><span class="default">$fn</span><span class="keyword">, array </span><span class="default">$args</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; if(isset(</span><span class="default">$this</span><span class="keyword">-&gt;{</span><span class="default">$fn</span><span class="keyword">})){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">array_unshift</span><span class="keyword">(</span><span class="default">$args</span><span class="keyword">, </span><span class="default">$this</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">call_user_func_array</span><span class="keyword">( </span><span class="default">$this</span><span class="keyword">-&gt;{</span><span class="default">$fn</span><span class="keyword">}, </span><span class="default">$args</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$o </span><span class="keyword">= new </span><span class="default">_</span><span class="keyword">(array(<br />&nbsp; &nbsp; </span><span class="string">"color"</span><span class="keyword">=&gt;</span><span class="string">"red"</span><span class="keyword">,<br />&nbsp; &nbsp; </span><span class="string">"run"</span><span class="keyword">=&gt;function(</span><span class="default">$this</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"My color is : "</span><span class="keyword">.</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">color</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />));<br /><br /></span><span class="default">$o</span><span class="keyword">-&gt;</span><span class="default">run</span><span class="keyword">();<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.oop5&amp;redirect=http://php.net/manual/en/language.oop5.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="langref.php">Language Reference</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.basic-syntax.php" title="Basic syntax">Basic syntax</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.php" title="Types">Types</a>
                        </li>
                          
                        <li class="">
                            <a href="language.variables.php" title="Variables">Variables</a>
                        </li>
                          
                        <li class="">
                            <a href="language.constants.php" title="Constants">Constants</a>
                        </li>
                          
                        <li class="">
                            <a href="language.expressions.php" title="Expressions">Expressions</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.php" title="Operators">Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.control-structures.php" title="Control Structures">Control Structures</a>
                        </li>
                          
                        <li class="">
                            <a href="language.functions.php" title="Functions">Functions</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.oop5.php" title="Classes and Objects">Classes and Objects</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.php" title="Namespaces">Namespaces</a>
                        </li>
                          
                        <li class="">
                            <a href="language.errors.php" title="Errors">Errors</a>
                        </li>
                          
                        <li class="">
                            <a href="language.exceptions.php" title="Exceptions">Exceptions</a>
                        </li>
                          
                        <li class="">
                            <a href="language.generators.php" title="Generators">Generators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.references.php" title="References Explained">References Explained</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.php" title="Predefined Variables">Predefined Variables</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.exceptions.php" title="Predefined Exceptions">Predefined Exceptions</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.interfaces.php" title="Predefined Interfaces and Classes">Predefined Interfaces and Classes</a>
                        </li>
                          
                        <li class="">
                            <a href="context.php" title="Context options and parameters">Context options and parameters</a>
                        </li>
                          
                        <li class="">
                            <a href="wrappers.php" title="Supported Protocols and Wrappers">Supported Protocols and Wrappers</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

