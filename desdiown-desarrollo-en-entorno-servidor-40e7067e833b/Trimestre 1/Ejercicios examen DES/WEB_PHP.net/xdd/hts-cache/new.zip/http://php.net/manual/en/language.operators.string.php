<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: String Operators - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.operators.string.php">
 <link rel="shorturl" href="http://php.net/operators.string">
 <link rel="alternate" href="http://php.net/operators.string" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.operators.php">
 <link rel="prev" href="http://php.net/manual/en/language.operators.logical.php">
 <link rel="next" href="http://php.net/manual/en/language.operators.array.php">

 <link rel="alternate" href="http://php.net/manual/en/language.operators.string.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.operators.string.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.operators.string.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.operators.string.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.operators.string.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.operators.string.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.operators.string.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.operators.string.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.operators.string.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.operators.string.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.operators.string.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.operators.array.php">
          Array Operators &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.operators.logical.php">
          &laquo; Logical Operators        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.operators.php'>Operators</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.operators.string.php' selected="selected">English</option>
            <option value='pt_BR/language.operators.string.php'>Brazilian Portuguese</option>
            <option value='zh/language.operators.string.php'>Chinese (Simplified)</option>
            <option value='fr/language.operators.string.php'>French</option>
            <option value='de/language.operators.string.php'>German</option>
            <option value='ja/language.operators.string.php'>Japanese</option>
            <option value='ro/language.operators.string.php'>Romanian</option>
            <option value='ru/language.operators.string.php'>Russian</option>
            <option value='es/language.operators.string.php'>Spanish</option>
            <option value='tr/language.operators.string.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.operators.string.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.operators.string">Report a Bug</a>
    </div>
  </div><div id="language.operators.string" class="sect1">
   <h2 class="title">String Operators</h2>
   <p class="simpara">
    There are two <span class="type"><a href="language.types.string.php" class="type string">string</a></span> operators. The first is the
    concatenation operator (&#039;.&#039;), which returns the concatenation of its
    right and left arguments. The second is the concatenating assignment
    operator (&#039;<em>.=</em>&#039;), which appends the argument on the right side to
    the argument on the left side. Please read <a href="language.operators.assignment.php" class="link">Assignment
    Operators</a> for more information.
   </p>

   <p class="para">
    <div class="informalexample">
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$a&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">"Hello&nbsp;"</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$b&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">"World!"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;now&nbsp;$b&nbsp;contains&nbsp;"Hello&nbsp;World!"<br /><br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">"Hello&nbsp;"</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">.=&nbsp;</span><span style="color: #DD0000">"World!"</span><span style="color: #007700">;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;now&nbsp;$a&nbsp;contains&nbsp;"Hello&nbsp;World!"<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>
   <p class="para">
    See also the manual sections on the
    <a href="language.types.string.php" class="link">String type</a> and
    <a href="ref.strings.php" class="link">String functions</a>.
   </p>
  </div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.operators.string&amp;redirect=http://php.net/manual/en/language.operators.string.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">5 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="41950">  <div class="votes">
    <div id="Vu41950">
    <a href="/manual/vote-note.php?id=41950&amp;page=language.operators.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd41950">
    <a href="/manual/vote-note.php?id=41950&amp;page=language.operators.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V41950" title="65% like this...">
    114
    </div>
  </div>
  <a href="#41950" class="name">
  <strong class="user"><em>anders dot benke at telia dot com</em></strong></a><a class="genanchor" href="#41950"> &para;</a><div class="date" title="2004-04-27 09:53"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom41950">
<div class="phpcode"><code><span class="html">
A word of caution - the dot operator has the same precedence as + and -, which can yield unexpected results. <br /><br />Example:<br /><br />&lt;php<br />$var = 3;<br /><br />echo "Result: " . $var + 3;<br />?&gt;<br /><br />The above will print out "3" instead of "Result: 6", since first the string "Result3" is created and this is then added to 3 yielding 3, non-empty non-numeric strings being converted to 0.<br /><br />To print "Result: 6", use parantheses to alter precedence:<br /><br />&lt;php<br />$var = 3;<br /><br />echo "Result: " . ($var + 3); <br />?&gt;</span>
</code></div>
  </div>
 </div>
  <div class="note" id="110937">  <div class="votes">
    <div id="Vu110937">
    <a href="/manual/vote-note.php?id=110937&amp;page=language.operators.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd110937">
    <a href="/manual/vote-note.php?id=110937&amp;page=language.operators.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V110937" title="66% like this...">
    101
    </div>
  </div>
  <a href="#110937" class="name">
  <strong class="user"><em>K.Alex</em></strong></a><a class="genanchor" href="#110937"> &para;</a><div class="date" title="2012-12-26 10:22"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom110937">
<div class="phpcode"><code><span class="html">
As for me, curly braces serve good substitution for concatenation, and they are quicker to type and code looks cleaner. Remember to use double quotes (" ") as their content is parced by php, because in single quotes (' ') you'll get litaral name of variable provided:<br /><br /><span class="default">&lt;?php<br /><br /> $a </span><span class="keyword">= </span><span class="string">'12345'</span><span class="keyword">;<br /><br /></span><span class="comment">// This works:<br /> </span><span class="keyword">echo </span><span class="string">"qwe</span><span class="keyword">{</span><span class="default">$a</span><span class="keyword">}</span><span class="string">rty"</span><span class="keyword">; </span><span class="comment">// qwe12345rty, using braces<br /> </span><span class="keyword">echo </span><span class="string">"qwe" </span><span class="keyword">. </span><span class="default">$a </span><span class="keyword">. </span><span class="string">"rty"</span><span class="keyword">; </span><span class="comment">// qwe12345rty, concatenation used<br /><br />// Does not work:<br /> </span><span class="keyword">echo </span><span class="string">'qwe{$a}rty'</span><span class="keyword">; </span><span class="comment">// qwe{$a}rty, single quotes are not parsed<br /> </span><span class="keyword">echo </span><span class="string">"qwe</span><span class="default">$arty</span><span class="string">"</span><span class="keyword">; </span><span class="comment">// qwe, because $a became $arty, which is undefined<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="60035">  <div class="votes">
    <div id="Vu60035">
    <a href="/manual/vote-note.php?id=60035&amp;page=language.operators.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd60035">
    <a href="/manual/vote-note.php?id=60035&amp;page=language.operators.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V60035" title="63% like this...">
    84
    </div>
  </div>
  <a href="#60035" class="name">
  <strong class="user"><em>Stephen Clay</em></strong></a><a class="genanchor" href="#60035"> &para;</a><div class="date" title="2005-12-23 07:10"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom60035">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php <br /></span><span class="string">"</span><span class="keyword">{</span><span class="default">$str1</span><span class="keyword">}{</span><span class="default">$str2</span><span class="keyword">}{</span><span class="default">$str3</span><span class="keyword">}</span><span class="string">"</span><span class="keyword">; </span><span class="comment">// one concat = fast<br />&nbsp; </span><span class="default">$str1</span><span class="keyword">. </span><span class="default">$str2</span><span class="keyword">. </span><span class="default">$str3</span><span class="keyword">;&nbsp;&nbsp; </span><span class="comment">// two concats = slow<br /></span><span class="default">?&gt;<br /></span>Use double quotes to concat more than two strings instead of multiple '.' operators.&nbsp; PHP is forced to re-concatenate with every '.' operator.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="88827">  <div class="votes">
    <div id="Vu88827">
    <a href="/manual/vote-note.php?id=88827&amp;page=language.operators.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd88827">
    <a href="/manual/vote-note.php?id=88827&amp;page=language.operators.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V88827" title="62% like this...">
    70
    </div>
  </div>
  <a href="#88827" class="name">
  <strong class="user"><em>hexidecimalgadget at hotmail dot com</em></strong></a><a class="genanchor" href="#88827"> &para;</a><div class="date" title="2009-02-09 09:37"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom88827">
<div class="phpcode"><code><span class="html">
If you attempt to add numbers with a concatenation operator, your result will be the result of those numbers as strings.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">echo </span><span class="string">"thr"</span><span class="keyword">.</span><span class="string">"ee"</span><span class="keyword">;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="comment">//prints the string "three"<br /></span><span class="keyword">echo </span><span class="string">"twe" </span><span class="keyword">. </span><span class="string">"lve"</span><span class="keyword">;&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//prints the string "twelve"<br /></span><span class="keyword">echo </span><span class="default">1 </span><span class="keyword">. </span><span class="default">2</span><span class="keyword">;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//prints the string "12"<br /></span><span class="keyword">echo </span><span class="default">1.2</span><span class="keyword">;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//prints the number 1.2<br /></span><span class="keyword">echo </span><span class="default">1</span><span class="keyword">+</span><span class="default">2</span><span class="keyword">;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//prints the number 3<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="85358">  <div class="votes">
    <div id="Vu85358">
    <a href="/manual/vote-note.php?id=85358&amp;page=language.operators.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd85358">
    <a href="/manual/vote-note.php?id=85358&amp;page=language.operators.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V85358" title="53% like this...">
    11
    </div>
  </div>
  <a href="#85358" class="name">
  <strong class="user"><em>mariusads::at::helpedia.com</em></strong></a><a class="genanchor" href="#85358"> &para;</a><div class="date" title="2008-08-27 02:44"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom85358">
<div class="phpcode"><code><span class="html">
Be careful so that you don't type "." instead of ";" at the end of a line.<br /><br />It took me more than 30 minutes to debug a long script because of something like this:<br /><br />&lt;?<br />echo 'a'.<br />$c = 'x';<br />echo 'b';<br />echo 'c';<br />?&gt;<br /><br />The output is "axbc", because of the dot on the first line.</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.operators.string&amp;redirect=http://php.net/manual/en/language.operators.string.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.operators.php">Operators</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.operators.precedence.php" title="Operator Precedence">Operator Precedence</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.arithmetic.php" title="Arithmetic Operators">Arithmetic Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.assignment.php" title="Assignment Operators">Assignment Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.bitwise.php" title="Bitwise Operators">Bitwise Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.comparison.php" title="Comparison Operators">Comparison Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.errorcontrol.php" title="Error Control Operators">Error Control Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.execution.php" title="Execution Operators">Execution Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.increment.php" title="Incrementing/Decrementing Operators">Incrementing/Decrementing Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.logical.php" title="Logical Operators">Logical Operators</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.operators.string.php" title="String Operators">String Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.array.php" title="Array Operators">Array Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.type.php" title="Type Operators">Type Operators</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

