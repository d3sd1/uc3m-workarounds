<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: HTTP authentication with PHP - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/features.http-auth.php">
 <link rel="shorturl" href="http://php.net/http-auth">
 <link rel="alternate" href="http://php.net/http-auth" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/features.php">
 <link rel="prev" href="http://php.net/manual/en/features.php">
 <link rel="next" href="http://php.net/manual/en/features.cookies.php">

 <link rel="alternate" href="http://php.net/manual/en/features.http-auth.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/features.http-auth.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/features.http-auth.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/features.http-auth.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/features.http-auth.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/features.http-auth.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/features.http-auth.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/features.http-auth.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/features.http-auth.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/features.http-auth.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/features.http-auth.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="features.cookies.php">
          Cookies &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="features.php">
          &laquo; Features        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='features.php'>Features</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/features.http-auth.php' selected="selected">English</option>
            <option value='pt_BR/features.http-auth.php'>Brazilian Portuguese</option>
            <option value='zh/features.http-auth.php'>Chinese (Simplified)</option>
            <option value='fr/features.http-auth.php'>French</option>
            <option value='de/features.http-auth.php'>German</option>
            <option value='ja/features.http-auth.php'>Japanese</option>
            <option value='ro/features.http-auth.php'>Romanian</option>
            <option value='ru/features.http-auth.php'>Russian</option>
            <option value='es/features.http-auth.php'>Spanish</option>
            <option value='tr/features.http-auth.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/features.http-auth.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=features.http-auth">Report a Bug</a>
    </div>
  </div><div id="features.http-auth" class="chapter">
  <h1>HTTP authentication with PHP</h1>


  <p class="simpara">
   It is possible to use the 
   <span class="function"><a href="function.header.php" class="function">header()</a></span> function to send an <em>&quot;Authentication Required&quot;</em> 
   message to the client browser causing it to pop up a Username/Password 
   input window.  Once the user has filled in a username and a password, 
   the URL containing the PHP script will be called again with the 
   <a href="reserved.variables.php" class="link">predefined variables</a> 
   <var class="varname"><var class="varname">PHP_AUTH_USER</var></var>, <var class="varname"><var class="varname">PHP_AUTH_PW</var></var>, 
   and <var class="varname"><var class="varname">AUTH_TYPE</var></var> set to the user name, password and 
   authentication type respectively.  These predefined variables are found 
   in the <var class="varname"><var class="varname"><a href="reserved.variables.server.php" class="classname">$_SERVER</a></var></var> array. Both &quot;Basic&quot; and &quot;Digest&quot;
   (since PHP 5.1.0) authentication methods are supported. See the
   <span class="function"><a href="function.header.php" class="function">header()</a></span> function for more information.
  </p>

  <p class="para">
   An example script fragment which would force client authentication
   on a page is as follows:
  </p>
  <p class="para">
   <div class="example" id="example-378">
    <p><strong>Example #1 Basic HTTP Authentication example</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">if&nbsp;(!isset(</span><span style="color: #0000BB">$_SERVER</span><span style="color: #007700">[</span><span style="color: #DD0000">'PHP_AUTH_USER'</span><span style="color: #007700">]))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">header</span><span style="color: #007700">(</span><span style="color: #DD0000">'WWW-Authenticate:&nbsp;Basic&nbsp;realm="My&nbsp;Realm"'</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">header</span><span style="color: #007700">(</span><span style="color: #DD0000">'HTTP/1.0&nbsp;401&nbsp;Unauthorized'</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">'Text&nbsp;to&nbsp;send&nbsp;if&nbsp;user&nbsp;hits&nbsp;Cancel&nbsp;button'</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;exit;<br />}&nbsp;else&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"&lt;p&gt;Hello&nbsp;</span><span style="color: #007700">{</span><span style="color: #0000BB">$_SERVER</span><span style="color: #007700">[</span><span style="color: #DD0000">'PHP_AUTH_USER'</span><span style="color: #007700">]}</span><span style="color: #DD0000">.&lt;/p&gt;"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"&lt;p&gt;You&nbsp;entered&nbsp;</span><span style="color: #007700">{</span><span style="color: #0000BB">$_SERVER</span><span style="color: #007700">[</span><span style="color: #DD0000">'PHP_AUTH_PW'</span><span style="color: #007700">]}</span><span style="color: #DD0000">&nbsp;as&nbsp;your&nbsp;password.&lt;/p&gt;"</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
  </p>

  <p class="para">
   <div class="example" id="example-379">
    <p><strong>Example #2 Digest HTTP Authentication example</strong></p>
    <div class="example-contents"><p>
     This example shows you how to implement a simple Digest HTTP
     authentication script. For more information read the <a href="http://www.faqs.org/rfcs/rfc2617" class="link external">&raquo;&nbsp;RFC 2617</a>.
    </p></div>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$realm&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'Restricted&nbsp;area'</span><span style="color: #007700">;<br /><br /></span><span style="color: #FF8000">//user&nbsp;=&gt;&nbsp;password<br /></span><span style="color: #0000BB">$users&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">'admin'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'mypass'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'guest'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'guest'</span><span style="color: #007700">);<br /><br /><br />if&nbsp;(empty(</span><span style="color: #0000BB">$_SERVER</span><span style="color: #007700">[</span><span style="color: #DD0000">'PHP_AUTH_DIGEST'</span><span style="color: #007700">]))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">header</span><span style="color: #007700">(</span><span style="color: #DD0000">'HTTP/1.1&nbsp;401&nbsp;Unauthorized'</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">header</span><span style="color: #007700">(</span><span style="color: #DD0000">'WWW-Authenticate:&nbsp;Digest&nbsp;realm="'</span><span style="color: #007700">.</span><span style="color: #0000BB">$realm</span><span style="color: #007700">.<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">'",qop="auth",nonce="'</span><span style="color: #007700">.</span><span style="color: #0000BB">uniqid</span><span style="color: #007700">().</span><span style="color: #DD0000">'",opaque="'</span><span style="color: #007700">.</span><span style="color: #0000BB">md5</span><span style="color: #007700">(</span><span style="color: #0000BB">$realm</span><span style="color: #007700">).</span><span style="color: #DD0000">'"'</span><span style="color: #007700">);<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;die(</span><span style="color: #DD0000">'Text&nbsp;to&nbsp;send&nbsp;if&nbsp;user&nbsp;hits&nbsp;Cancel&nbsp;button'</span><span style="color: #007700">);<br />}<br /><br /><br /></span><span style="color: #FF8000">//&nbsp;analyze&nbsp;the&nbsp;PHP_AUTH_DIGEST&nbsp;variable<br /></span><span style="color: #007700">if&nbsp;(!(</span><span style="color: #0000BB">$data&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">http_digest_parse</span><span style="color: #007700">(</span><span style="color: #0000BB">$_SERVER</span><span style="color: #007700">[</span><span style="color: #DD0000">'PHP_AUTH_DIGEST'</span><span style="color: #007700">]))&nbsp;||<br />&nbsp;&nbsp;&nbsp;&nbsp;!isset(</span><span style="color: #0000BB">$users</span><span style="color: #007700">[</span><span style="color: #0000BB">$data</span><span style="color: #007700">[</span><span style="color: #DD0000">'username'</span><span style="color: #007700">]]))<br />&nbsp;&nbsp;&nbsp;&nbsp;die(</span><span style="color: #DD0000">'Wrong&nbsp;Credentials!'</span><span style="color: #007700">);<br /><br /><br /></span><span style="color: #FF8000">//&nbsp;generate&nbsp;the&nbsp;valid&nbsp;response<br /></span><span style="color: #0000BB">$A1&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">md5</span><span style="color: #007700">(</span><span style="color: #0000BB">$data</span><span style="color: #007700">[</span><span style="color: #DD0000">'username'</span><span style="color: #007700">]&nbsp;.&nbsp;</span><span style="color: #DD0000">':'&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">$realm&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">':'&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">$users</span><span style="color: #007700">[</span><span style="color: #0000BB">$data</span><span style="color: #007700">[</span><span style="color: #DD0000">'username'</span><span style="color: #007700">]]);<br /></span><span style="color: #0000BB">$A2&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">md5</span><span style="color: #007700">(</span><span style="color: #0000BB">$_SERVER</span><span style="color: #007700">[</span><span style="color: #DD0000">'REQUEST_METHOD'</span><span style="color: #007700">].</span><span style="color: #DD0000">':'</span><span style="color: #007700">.</span><span style="color: #0000BB">$data</span><span style="color: #007700">[</span><span style="color: #DD0000">'uri'</span><span style="color: #007700">]);<br /></span><span style="color: #0000BB">$valid_response&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">md5</span><span style="color: #007700">(</span><span style="color: #0000BB">$A1</span><span style="color: #007700">.</span><span style="color: #DD0000">':'</span><span style="color: #007700">.</span><span style="color: #0000BB">$data</span><span style="color: #007700">[</span><span style="color: #DD0000">'nonce'</span><span style="color: #007700">].</span><span style="color: #DD0000">':'</span><span style="color: #007700">.</span><span style="color: #0000BB">$data</span><span style="color: #007700">[</span><span style="color: #DD0000">'nc'</span><span style="color: #007700">].</span><span style="color: #DD0000">':'</span><span style="color: #007700">.</span><span style="color: #0000BB">$data</span><span style="color: #007700">[</span><span style="color: #DD0000">'cnonce'</span><span style="color: #007700">].</span><span style="color: #DD0000">':'</span><span style="color: #007700">.</span><span style="color: #0000BB">$data</span><span style="color: #007700">[</span><span style="color: #DD0000">'qop'</span><span style="color: #007700">].</span><span style="color: #DD0000">':'</span><span style="color: #007700">.</span><span style="color: #0000BB">$A2</span><span style="color: #007700">);<br /><br />if&nbsp;(</span><span style="color: #0000BB">$data</span><span style="color: #007700">[</span><span style="color: #DD0000">'response'</span><span style="color: #007700">]&nbsp;!=&nbsp;</span><span style="color: #0000BB">$valid_response</span><span style="color: #007700">)<br />&nbsp;&nbsp;&nbsp;&nbsp;die(</span><span style="color: #DD0000">'Wrong&nbsp;Credentials!'</span><span style="color: #007700">);<br /><br /></span><span style="color: #FF8000">//&nbsp;ok,&nbsp;valid&nbsp;username&nbsp;&amp;&nbsp;password<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">'You&nbsp;are&nbsp;logged&nbsp;in&nbsp;as:&nbsp;'&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">$data</span><span style="color: #007700">[</span><span style="color: #DD0000">'username'</span><span style="color: #007700">];<br /><br /><br /></span><span style="color: #FF8000">//&nbsp;function&nbsp;to&nbsp;parse&nbsp;the&nbsp;http&nbsp;auth&nbsp;header<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">http_digest_parse</span><span style="color: #007700">(</span><span style="color: #0000BB">$txt</span><span style="color: #007700">)<br />{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;protect&nbsp;against&nbsp;missing&nbsp;data<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$needed_parts&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">'nonce'</span><span style="color: #007700">=&gt;</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'nc'</span><span style="color: #007700">=&gt;</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'cnonce'</span><span style="color: #007700">=&gt;</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'qop'</span><span style="color: #007700">=&gt;</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'username'</span><span style="color: #007700">=&gt;</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'uri'</span><span style="color: #007700">=&gt;</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'response'</span><span style="color: #007700">=&gt;</span><span style="color: #0000BB">1</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$data&nbsp;</span><span style="color: #007700">=&nbsp;array();<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$keys&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">implode</span><span style="color: #007700">(</span><span style="color: #DD0000">'|'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">array_keys</span><span style="color: #007700">(</span><span style="color: #0000BB">$needed_parts</span><span style="color: #007700">));<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">preg_match_all</span><span style="color: #007700">(</span><span style="color: #DD0000">'@('&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">$keys&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">')=(?:([\'"])([^\2]+?)\2|([^\s,]+))@'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$txt</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$matches</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">PREG_SET_ORDER</span><span style="color: #007700">);<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;foreach&nbsp;(</span><span style="color: #0000BB">$matches&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">$m</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$data</span><span style="color: #007700">[</span><span style="color: #0000BB">$m</span><span style="color: #007700">[</span><span style="color: #0000BB">1</span><span style="color: #007700">]]&nbsp;=&nbsp;</span><span style="color: #0000BB">$m</span><span style="color: #007700">[</span><span style="color: #0000BB">3</span><span style="color: #007700">]&nbsp;?&nbsp;</span><span style="color: #0000BB">$m</span><span style="color: #007700">[</span><span style="color: #0000BB">3</span><span style="color: #007700">]&nbsp;:&nbsp;</span><span style="color: #0000BB">$m</span><span style="color: #007700">[</span><span style="color: #0000BB">4</span><span style="color: #007700">];<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;unset(</span><span style="color: #0000BB">$needed_parts</span><span style="color: #007700">[</span><span style="color: #0000BB">$m</span><span style="color: #007700">[</span><span style="color: #0000BB">1</span><span style="color: #007700">]]);<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">$needed_parts&nbsp;</span><span style="color: #007700">?&nbsp;</span><span style="color: #0000BB">false&nbsp;</span><span style="color: #007700">:&nbsp;</span><span style="color: #0000BB">$data</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
  </p>

  <blockquote class="note"><p><strong class="note">Note</strong>: 
   <strong>Compatibility Note</strong><br />
   <p class="para">
    Please be careful when coding the HTTP header lines. In order to guarantee maximum
    compatibility with all clients, the keyword &quot;Basic&quot; should be written with an
    uppercase &quot;B&quot;, the realm string must be enclosed in double (not single) quotes,
    and exactly one space should precede the <em class="emphasis">401</em> code in the 
    <em class="emphasis">HTTP/1.0 401</em> header line. Authentication parameters have
    to be comma-separated as seen in the digest example above.
   </p>
  </p></blockquote>

  <p class="para">
   Instead of simply printing out <var class="varname"><var class="varname">PHP_AUTH_USER</var></var> 
   and <var class="varname"><var class="varname">PHP_AUTH_PW</var></var>, as done in the above example, 
   you may want to check the username and password for validity.  
   Perhaps by sending a query to a database, or by looking up the 
   user in a dbm file.
  </p>

  <p class="para">
   Watch out for buggy Internet Explorer browsers out there.  They
   seem very picky about the order of the headers.  Sending the
   <em class="emphasis">WWW-Authenticate</em> header before the
   <em>HTTP/1.0 401</em> header seems to do the trick
   for now.
  </p>

  <p class="simpara">
   In order to prevent someone from writing a script which
   reveals the password for a page that was authenticated through a
   traditional external mechanism, the PHP_AUTH variables will not be 
   set if external authentication is enabled for that particular
   page and <a href="ini.sect.safe-mode.php#ini.safe-mode" class="link">safe mode</a> is enabled.  Regardless, 
   <var class="varname"><var class="varname">REMOTE_USER</var></var> can be used 
   to identify the externally-authenticated user.  So, you can use  
   <var class="varname"><var class="varname"><a href="reserved.variables.server.php" class="classname">$_SERVER['REMOTE_USER']</a></var></var>.
  </p>

  <blockquote class="note"><p><strong class="note">Note</strong>: 
   <strong>Configuration Note</strong><br />
   <p class="para">
    PHP uses the presence of an <em>AuthType</em> directive
    to determine whether external authentication is in effect.
   </p>
  </p></blockquote>

  <p class="simpara">
   Note, however, that the above does not prevent someone who
   controls a non-authenticated URL from stealing passwords from
   authenticated URLs on the same server.
  </p>
  <p class="simpara">
   Both Netscape Navigator and Internet Explorer will clear the local browser
   window&#039;s authentication cache for the realm upon receiving a
   server response of 401. This can effectively &quot;log out&quot; a user,
   forcing them to re-enter their username and password. Some people
   use this to &quot;time out&quot; logins, or provide a &quot;log-out&quot; button.
  </p>
  <p class="para">
   <div class="example" id="example-380">
    <p><strong>Example #3 HTTP Authentication example forcing a new name/password</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">authenticate</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">header</span><span style="color: #007700">(</span><span style="color: #DD0000">'WWW-Authenticate:&nbsp;Basic&nbsp;realm="Test&nbsp;Authentication&nbsp;System"'</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">header</span><span style="color: #007700">(</span><span style="color: #DD0000">'HTTP/1.0&nbsp;401&nbsp;Unauthorized'</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"You&nbsp;must&nbsp;enter&nbsp;a&nbsp;valid&nbsp;login&nbsp;ID&nbsp;and&nbsp;password&nbsp;to&nbsp;access&nbsp;this&nbsp;resource\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;exit;<br />}<br />&nbsp;<br />if&nbsp;(!isset(</span><span style="color: #0000BB">$_SERVER</span><span style="color: #007700">[</span><span style="color: #DD0000">'PHP_AUTH_USER'</span><span style="color: #007700">])&nbsp;||<br />&nbsp;&nbsp;&nbsp;&nbsp;(</span><span style="color: #0000BB">$_POST</span><span style="color: #007700">[</span><span style="color: #DD0000">'SeenBefore'</span><span style="color: #007700">]&nbsp;==&nbsp;</span><span style="color: #0000BB">1&nbsp;</span><span style="color: #007700">&amp;&amp;&nbsp;</span><span style="color: #0000BB">$_POST</span><span style="color: #007700">[</span><span style="color: #DD0000">'OldAuth'</span><span style="color: #007700">]&nbsp;==&nbsp;</span><span style="color: #0000BB">$_SERVER</span><span style="color: #007700">[</span><span style="color: #DD0000">'PHP_AUTH_USER'</span><span style="color: #007700">]))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">authenticate</span><span style="color: #007700">();<br />}&nbsp;else&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"&lt;p&gt;Welcome:&nbsp;"&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">htmlspecialchars</span><span style="color: #007700">(</span><span style="color: #0000BB">$_SERVER</span><span style="color: #007700">[</span><span style="color: #DD0000">'PHP_AUTH_USER'</span><span style="color: #007700">])&nbsp;.&nbsp;</span><span style="color: #DD0000">"&lt;br&nbsp;/&gt;"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"Old:&nbsp;"&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">htmlspecialchars</span><span style="color: #007700">(</span><span style="color: #0000BB">$_REQUEST</span><span style="color: #007700">[</span><span style="color: #DD0000">'OldAuth'</span><span style="color: #007700">]);<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"&lt;form&nbsp;action=''&nbsp;method='post'&gt;\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"&lt;input&nbsp;type='hidden'&nbsp;name='SeenBefore'&nbsp;value='1'&nbsp;/&gt;\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"&lt;input&nbsp;type='hidden'&nbsp;name='OldAuth'&nbsp;value=\""&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">htmlspecialchars</span><span style="color: #007700">(</span><span style="color: #0000BB">$_SERVER</span><span style="color: #007700">[</span><span style="color: #DD0000">'PHP_AUTH_USER'</span><span style="color: #007700">])&nbsp;.&nbsp;</span><span style="color: #DD0000">"\"&nbsp;/&gt;\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"&lt;input&nbsp;type='submit'&nbsp;value='Re&nbsp;Authenticate'&nbsp;/&gt;\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"&lt;/form&gt;&lt;/p&gt;\n"</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
  </p>
  <p class="simpara">
   This behavior is not required by the <em>HTTP Basic</em>
   authentication standard, so you should never depend on this. Testing with
   <em>Lynx</em> has shown that <em>Lynx</em> does not clear
   the authentication credentials with a 401 server response, so pressing back
   and then forward again will open the resource as long as the credential
   requirements haven&#039;t changed. The user can press the
   <em>&#039;_&#039;</em> key to clear their authentication information, however.
  </p>
  <p class="simpara">
   In order to get HTTP Authentication to work using IIS server with the CGI version
   of PHP you must edit your IIS configuration &quot;<em>Directory Security</em>&quot;.
   Click on &quot;<em>Edit</em>&quot; and only check
   &quot;<em>Anonymous Access</em>&quot;, all other fields
   should be left unchecked.
  </p>
  <blockquote class="note"><p><strong class="note">Note</strong>: 
   <strong>IIS Note:</strong><br />
   <span class="simpara">
    For HTTP Authentication to work with IIS, the PHP directive
    <a href="ini.core.php#ini.cgi.rfc2616-headers" class="link">cgi.rfc2616_headers</a> must
    be set to <em>0</em> (the default value).
   </span>
  </p></blockquote>
  <blockquote class="note"><p><strong class="note">Note</strong>: 
   <p class="para">
    If <a href="ini.sect.safe-mode.php#ini.safe-mode" class="link">safe mode</a> is enabled, the
    uid of the script is added to the <em>realm</em> part of
    the <em>WWW-Authenticate</em> header.
   </p>
  </p></blockquote>

 </div>

<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=features.http-auth&amp;redirect=http://php.net/manual/en/features.http-auth.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">68 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="114877">  <div class="votes">
    <div id="Vu114877">
    <a href="/manual/vote-note.php?id=114877&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114877">
    <a href="/manual/vote-note.php?id=114877&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114877" title="66% like this...">
    32
    </div>
  </div>
  <a href="#114877" class="name">
  <strong class="user"><em>derkontrollfreak+9hy5l at gmail dot com</em></strong></a><a class="genanchor" href="#114877"> &para;</a><div class="date" title="2014-04-19 03:55"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114877">
<div class="phpcode"><code><span class="html">
Workaround for missing Authorization header under CGI/FastCGI Apache:<br /><br />SetEnvIf Authorization .+ HTTP_AUTHORIZATION=$0<br /><br />Now PHP should automatically declare $_SERVER[PHP_AUTH_*] variables if the client sends the Authorization header.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="73386">  <div class="votes">
    <div id="Vu73386">
    <a href="/manual/vote-note.php?id=73386&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd73386">
    <a href="/manual/vote-note.php?id=73386&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V73386" title="60% like this...">
    33
    </div>
  </div>
  <a href="#73386" class="name">
  <strong class="user"><em>webmaster at kratia dot com</em></strong></a><a class="genanchor" href="#73386"> &para;</a><div class="date" title="2007-02-20 04:53"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom73386">
<div class="phpcode"><code><span class="html">
This is the simplest form I found to do a Basic authorization with retries.<br /><br /><span class="default">&lt;?php<br /><br />$valid_passwords </span><span class="keyword">= array (</span><span class="string">"mario" </span><span class="keyword">=&gt; </span><span class="string">"carbonell"</span><span class="keyword">);<br /></span><span class="default">$valid_users </span><span class="keyword">= </span><span class="default">array_keys</span><span class="keyword">(</span><span class="default">$valid_passwords</span><span class="keyword">);<br /><br /></span><span class="default">$user </span><span class="keyword">= </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">];<br /></span><span class="default">$pass </span><span class="keyword">= </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_PW'</span><span class="keyword">];<br /><br /></span><span class="default">$validated </span><span class="keyword">= (</span><span class="default">in_array</span><span class="keyword">(</span><span class="default">$user</span><span class="keyword">, </span><span class="default">$valid_users</span><span class="keyword">)) &amp;&amp; (</span><span class="default">$pass </span><span class="keyword">== </span><span class="default">$valid_passwords</span><span class="keyword">[</span><span class="default">$user</span><span class="keyword">]);<br /><br />if (!</span><span class="default">$validated</span><span class="keyword">) {<br />&nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">'WWW-Authenticate: Basic realm="My Realm"'</span><span class="keyword">);<br />&nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">'HTTP/1.0 401 Unauthorized'</span><span class="keyword">);<br />&nbsp; die (</span><span class="string">"Not authorized"</span><span class="keyword">);<br />}<br /><br /></span><span class="comment">// If arrives here, is a valid user.<br /></span><span class="keyword">echo </span><span class="string">"&lt;p&gt;Welcome </span><span class="default">$user</span><span class="string">.&lt;/p&gt;"</span><span class="keyword">;<br />echo </span><span class="string">"&lt;p&gt;Congratulation, you are into the system.&lt;/p&gt;"</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="73642">  <div class="votes">
    <div id="Vu73642">
    <a href="/manual/vote-note.php?id=73642&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd73642">
    <a href="/manual/vote-note.php?id=73642&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V73642" title="83% like this...">
    12
    </div>
  </div>
  <a href="#73642" class="name">
  <strong class="user"><em>Nicolas Merlet - admin(at)merletn.org</em></strong></a><a class="genanchor" href="#73642"> &para;</a><div class="date" title="2007-03-05 09:37"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom73642">
<div class="phpcode"><code><span class="html">
Be careful using http digest authentication (see above, example 34.2) if you have to use the 'setlocale' function *before* validating response with the 'http_digest_parse' function, because there's a conflict with \w in the pattern of 'preg_match_all' function :<br /><br />In fact, as \w is supposed to be any letter or digit or the underscore character, you must not forgot that this may vary depending on your locale configuration (eg. it accepts accented letters in french)...<br /><br />Due to this different pattern interpretation by the 'preg_match_all' function, the 'http_digest_parse' function will always return a false result if you have modified your locale (I mean if your locale accepts some extended characters, see <a href="http://fr.php.net/manual/en/reference.pcre.pattern.syntax.php" rel="nofollow" target="_blank">http://fr.php.net/manual/en/reference.pcre.pattern.syntax.php</a> for further information).<br /><br />IMHO, I suggest you not to use setlocale before having your authentication completed...<br /><br />PS : Here's a non-compatible setlocale declaration...<br />setlocale ( LC_ALL, 'fr_FR', 'fr', 'FR', 'french', 'fra', 'france', 'French', 'fr_FR.ISO8859-1' ) ;</span>
</code></div>
  </div>
 </div>
  <div class="note" id="96970">  <div class="votes">
    <div id="Vu96970">
    <a href="/manual/vote-note.php?id=96970&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd96970">
    <a href="/manual/vote-note.php?id=96970&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V96970" title="71% like this...">
    9
    </div>
  </div>
  <a href="#96970" class="name">
  <strong class="user"><em>Ome Ko</em></strong></a><a class="genanchor" href="#96970"> &para;</a><div class="date" title="2010-03-25 03:04"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom96970">
<div class="phpcode"><code><span class="html">
a link to <a href="http://logout:logout@" rel="nofollow" target="_blank">http://logout:logout@</a><span class="default">&lt;?=$_SERVER</span><span class="keyword">[</span><span class="string">'HTTP_HOST'</span><span class="keyword">];</span><span class="default">?&gt;</span>/SECRET/ would force a fresh login for the /SECRET directory if no user logout with password logout exists.<br /><br /><br />[NOTE BY danbrown AT php DOT net: The following note was added by "Anonymous" on 01-APR-2010 (though we presume it's not an April Fool's Day joke).]<br /><br />this logout method does not work 100% anymore, because of another bulls**t from M$:<br /><a href="http://support.microsoft.com/kb/834489" rel="nofollow" target="_blank">http://support.microsoft.com/kb/834489</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="118088">  <div class="votes">
    <div id="Vu118088">
    <a href="/manual/vote-note.php?id=118088&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118088">
    <a href="/manual/vote-note.php?id=118088&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118088" title="69% like this...">
    5
    </div>
  </div>
  <a href="#118088" class="name">
  <strong class="user"><em>jake22 at gmail dot com</em></strong></a><a class="genanchor" href="#118088"> &para;</a><div class="date" title="2015-10-01 10:42"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom118088">
<div class="phpcode"><code><span class="html">
I came up with another approach to work around the problem of browsers caching WWW authentication credentials and creating logout problems. While most browsers have some kind of way to wipe this information, I prefer having my website to take care of the task instead of relying on the user's sanity.<br /><br />Even with Lalit's method of creating a random realm name, it was still possible to get back into the protected area using the back button in Firefox, so that didn't work. Here's my solution:<br /><br />Since browsers attach the credentials to specific URLs, use virtual paths where a component of the path is actually a PHP script, and everything following it is part of the URI, such as:<br /><br /><a href="http://velocitypress.ca/some_dir/login.php/auth/8f631b92/" rel="nofollow" target="_blank">http://velocitypress.ca/some_dir/login.php/auth/8f631b92/</a><br /><br />By choosing a different number for the last component of the URL, browsers can be tricked into thinking that they are dealing with a completely different website, and thus prompting the user for credentials again.<br /><br />Note that using a random, unrestricted number will still allow the user to hit the back button to get back into the page. You should keep track of this number in a server-side file or database and regenerate it upon each successful login, so that the last number(s) become invalid. Using an invalid number might result in a 403 response or, depending on how you feel that day, a 302 to a nasty website.<br /><br />Care should be taken when linking from the page generated in this case, since relative links will be relative to the virtual and non-existant directory rather than the true script directory.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="61922">  <div class="votes">
    <div id="Vu61922">
    <a href="/manual/vote-note.php?id=61922&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd61922">
    <a href="/manual/vote-note.php?id=61922&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V61922" title="68% like this...">
    7
    </div>
  </div>
  <a href="#61922" class="name">
  <strong class="user"><em>djreficul at yahoo dot com</em></strong></a><a class="genanchor" href="#61922"> &para;</a><div class="date" title="2006-02-15 02:14"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom61922">
<div class="phpcode"><code><span class="html">
Well, I think it's easy to make authentification works correctly. I use a session var to force authentication everytime a user visit the logging area.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">if (!isset (</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'firstauthenticate'</span><span class="keyword">])) {<br />&nbsp; &nbsp; </span><span class="default">session_start</span><span class="keyword">();<br />}<br />&nbsp; function </span><span class="default">authenticate</span><span class="keyword">() {<br />&nbsp; &nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">'WWW-Authenticate: Basic realm="Sistema autentificaci�n UnoAutoSur"'</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">'HTTP/1_0 401 Unauthorized'</span><span class="keyword">);<br /></span><span class="comment">//&nbsp; &nbsp; header("Status: 401 Access Denied"); <br />&nbsp; &nbsp; </span><span class="keyword">echo </span><span class="string">"Unauthorized\n"</span><span class="keyword">;<br />&nbsp; &nbsp; exit;<br />&nbsp; }<br /> if (!isset(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">]) || </span><span class="default">strcmp </span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">],</span><span class="default">$user</span><span class="keyword">)!=</span><span class="default">0 </span><span class="keyword">|| <br />&nbsp; &nbsp; &nbsp; !isset (</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_PW'</span><span class="keyword">]) || </span><span class="default">strcmp</span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_PW'</span><span class="keyword">],</span><span class="default">$pass</span><span class="keyword">)!=</span><span class="default">0 </span><span class="keyword">|| !isset (</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'firstauthenticate'</span><span class="keyword">]) || !</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'firstauthenticate'</span><span class="keyword">]) {<br />&nbsp; &nbsp;&nbsp; </span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'firstauthenticate'</span><span class="keyword">]=</span><span class="default">true</span><span class="keyword">;<br />&nbsp;&nbsp; </span><span class="default">authenticate</span><span class="keyword">();<br /> } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//I destroy the session var now<br />&nbsp; &nbsp; </span><span class="default">session_unset</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//Your code below<br /> </span><span class="keyword">}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="52405">  <div class="votes">
    <div id="Vu52405">
    <a href="/manual/vote-note.php?id=52405&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd52405">
    <a href="/manual/vote-note.php?id=52405&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V52405" title="69% like this...">
    5
    </div>
  </div>
  <a href="#52405" class="name">
  <strong class="user"><em>charly at towebs dot com</em></strong></a><a class="genanchor" href="#52405"> &para;</a><div class="date" title="2005-04-29 10:13"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom52405">
<div class="phpcode"><code><span class="html">
A simpler approach on the post of:<br />bernard dot paques at bigfoot dot com<br />24-Sep-2004 01:42<br /><br />This is another "patch" to the PHP_AUTH_USER and PHP_AUTH_PW server variables problem running PHP as a CGI.<br /><br />First of all don't forget this fragment of code in your .htaccess (it's the only thing you need to make it work with mod_rewrite):<br /><br />&lt;IfModule mod_rewrite.c&gt;<br />&nbsp;&nbsp; RewriteEngine on<br />&nbsp;&nbsp; RewriteRule .* - [E=REMOTE_USER:%{HTTP:Authorization},L]<br />&lt;/IfModule&gt;<br /><br />Then login.php<br /><br /><span class="default">&lt;?php<br />$a </span><span class="keyword">= </span><span class="default">base64_decode</span><span class="keyword">( </span><span class="default">substr</span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">"REMOTE_USER"</span><span class="keyword">],</span><span class="default">6</span><span class="keyword">)) ;<br />if ( (</span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">) == </span><span class="default">0</span><span class="keyword">) || ( </span><span class="default">strcasecmp</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">, </span><span class="string">":" </span><span class="keyword">)&nbsp; == </span><span class="default">0 </span><span class="keyword">))<br />{<br />&nbsp;&nbsp; </span><span class="default">header</span><span class="keyword">( </span><span class="string">'WWW-Authenticate: Basic realm="Private"' </span><span class="keyword">);<br />&nbsp;&nbsp; </span><span class="default">header</span><span class="keyword">( </span><span class="string">'HTTP/1.0 401 Unauthorized' </span><span class="keyword">);<br />}<br />else<br />{<br />&nbsp;&nbsp; list(</span><span class="default">$name</span><span class="keyword">, </span><span class="default">$password</span><span class="keyword">) = </span><span class="default">explode</span><span class="keyword">(</span><span class="string">':'</span><span class="keyword">, </span><span class="default">$a</span><span class="keyword">);<br />&nbsp;&nbsp; </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">] = </span><span class="default">$name</span><span class="keyword">;<br />&nbsp;&nbsp; </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_PW'</span><span class="keyword">]&nbsp; &nbsp; = </span><span class="default">$password</span><span class="keyword">;<br /><br />}<br /><br />echo </span><span class="string">'PHP_AUTH_USER =' </span><span class="keyword">. </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">] . </span><span class="string">'&lt;br&gt;'</span><span class="keyword">;<br />echo </span><span class="string">'PHP_AUTH_PW =' </span><span class="keyword">. </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_PW'</span><span class="keyword">] . </span><span class="string">'&lt;br&gt;'</span><span class="keyword">;<br />echo </span><span class="string">'REMOTE_USER =' </span><span class="keyword">. </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'REMOTE_USER'</span><span class="keyword">] . </span><span class="string">'&lt;br&gt;'</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />First, we decode the base64 encoded string discarding the first 6 characters of "Basic " and then we do a regular validation.<br />At the end of the script we print the variables to verify it's working. This should be ommited in the production version.<br /><br />It's a variation of the script by Bernard Paques.<br />Thanks to him for that snippet.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="44686">  <div class="votes">
    <div id="Vu44686">
    <a href="/manual/vote-note.php?id=44686&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd44686">
    <a href="/manual/vote-note.php?id=44686&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V44686" title="66% like this...">
    5
    </div>
  </div>
  <a href="#44686" class="name">
  <strong class="user"><em>php at cscott dot net</em></strong></a><a class="genanchor" href="#44686"> &para;</a><div class="date" title="2004-08-12 04:18"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom44686">
<div class="phpcode"><code><span class="html">
Note that Microsoft has released a 'security update' which disables the use of username:password@host in http urls.<br /><br />&nbsp;&nbsp; <a href="http://support.microsoft.com/default.aspx?scid=kb;en-us;834489" rel="nofollow" target="_blank">http://support.microsoft.com/default.aspx?scid=kb;en-us;834489</a><br /><br />The methods described above which rely on this will no longer work in Microsoft browsers, sadly.<br /><br />You can re-enable this functionality as described at<br /><br />&nbsp;&nbsp; <a href="http://weblogs.asp.net/cumpsd/archive/2004/02/07/69366.aspx" rel="nofollow" target="_blank">http://weblogs.asp.net/cumpsd/archive/2004/02/07/69366.aspx</a><br /><br />but your users will probably be unwilling to do this.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="100396">  <div class="votes">
    <div id="Vu100396">
    <a href="/manual/vote-note.php?id=100396&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd100396">
    <a href="/manual/vote-note.php?id=100396&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V100396" title="58% like this...">
    10
    </div>
  </div>
  <a href="#100396" class="name">
  <strong class="user"><em>ceo at l-i-e dot com</em></strong></a><a class="genanchor" href="#100396"> &para;</a><div class="date" title="2010-10-13 03:51"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom100396">
<div class="phpcode"><code><span class="html">
To force a logout with Basic Auth, you can change the Realm out from under them to a different Realm.<br /><br />This forces a new set of credentials for a new "Realm" on your server.<br /><br />You just need to track the Realm name with the user/pass and change it around to something new/random as they log in and out.<br /><br />I believe that this is the only 100% guaranteed way to get a logout in HTTP Basic Auth, and if it were part of the docs a whole lot of BAD user-contributed comments here could be deleted.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117415">  <div class="votes">
    <div id="Vu117415">
    <a href="/manual/vote-note.php?id=117415&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117415">
    <a href="/manual/vote-note.php?id=117415&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117415" title="61% like this...">
    7
    </div>
  </div>
  <a href="#117415" class="name">
  <strong class="user"><em>sergio dot carvalho at gmail dot com</em></strong></a><a class="genanchor" href="#117415"> &para;</a><div class="date" title="2015-06-07 04:01"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117415">
<div class="phpcode"><code><span class="html">
The only effective way I've found to wipe out the PHP_AUTH_DIGEST or PHP_AUTH_USER AND PHP_AUTH_PW credentials is to call the header HTTP/1.1 401 Unauthorized.<br /><br />function clear_admin_access(){<br />&nbsp; &nbsp; header('HTTP/1.1 401 Unauthorized');<br />&nbsp; &nbsp; die('Admin access turned off');<br />}</span>
</code></div>
  </div>
 </div>
  <div class="note" id="28491">  <div class="votes">
    <div id="Vu28491">
    <a href="/manual/vote-note.php?id=28491&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd28491">
    <a href="/manual/vote-note.php?id=28491&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V28491" title="64% like this...">
    5
    </div>
  </div>
  <a href="#28491" class="name">
  <strong class="user"><em>emmanuel dot keller at net2000 dot ch</em></strong></a><a class="genanchor" href="#28491"> &para;</a><div class="date" title="2003-01-14 02:14"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom28491">
<div class="phpcode"><code><span class="html">
Some servers won't support the HTTP1.0 specification and will give an error 500 (for instance). This happened with a server where I uploaded an authentication script.<br /><br />If it happens, you can try the HTTP1.1 header syntax :<br /><br /><span class="default">&lt;?php<br />header</span><span class="keyword">(</span><span class="string">"WWW-Authenticate: Basic realm=\"My Realm\""</span><span class="keyword">);<br /></span><span class="default">header</span><span class="keyword">(</span><span class="string">'status: 401 Unauthorized'</span><span class="keyword">);<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="60503">  <div class="votes">
    <div id="Vu60503">
    <a href="/manual/vote-note.php?id=60503&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd60503">
    <a href="/manual/vote-note.php?id=60503&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V60503" title="63% like this...">
    5
    </div>
  </div>
  <a href="#60503" class="name">
  <strong class="user"><em>marco dot moser at oltrefersina dot it</em></strong></a><a class="genanchor" href="#60503"> &para;</a><div class="date" title="2006-01-09 06:29"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom60503">
<div class="phpcode"><code><span class="html">
I suggest to demand user's authentication and management to the web server (by .htaccess, ...):<br /><br />1. configure a global /logon/ directory with a .htaccess file restricted access<br /><br />2. use fopen wrapper:<br /><br />&nbsp; $hh = @fopen("<a href="http://{$_SERVER[" rel="nofollow" target="_blank">http://{$_SERVER[</a>'PHP_AUTH_USER']}:{$_SERVER['PHP_AUTH_PW']}".<br />&nbsp; &nbsp; @{$_SERVER['SERVER_NAME']}/logon/", "r");<br />&nbsp; if (!$hh) authenticate(); // usual header WWW-Authenticate ...<br />&nbsp; fclose($hh);</span>
</code></div>
  </div>
 </div>
  <div class="note" id="42198">  <div class="votes">
    <div id="Vu42198">
    <a href="/manual/vote-note.php?id=42198&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd42198">
    <a href="/manual/vote-note.php?id=42198&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V42198" title="63% like this...">
    3
    </div>
  </div>
  <a href="#42198" class="name">
  <strong class="user"><em>steuber at aego dot de</em></strong></a><a class="genanchor" href="#42198"> &para;</a><div class="date" title="2004-05-07 04:15"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom42198">
<div class="phpcode"><code><span class="html">
Quite a good solution for the logout problem:<br /><br />Just tell browser that it is successfully logged in!<br />This works as follows:<br />1. User clicks logout button<br />2. Script sends 401 Header<br />3. User does NOT enter a password<br />4. If no password is entered, script sends 200 Header<br /><br />So the browser remembers no password as a valid password.<br /><br />Example:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">if (<br />&nbsp; &nbsp; &nbsp;&nbsp; (!isset(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">]))<br />&nbsp; &nbsp; ||(<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; (</span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">"login"</span><span class="keyword">]==</span><span class="string">"login"</span><span class="keyword">) <br />&nbsp; &nbsp; &amp;&amp; !(<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; (</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">]==</span><span class="string">"validuser"</span><span class="keyword">) <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &amp;&amp; (</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_PW'</span><span class="keyword">]==</span><span class="string">"validpass"</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; )<br />&nbsp; &nbsp; &nbsp; &nbsp; )<br />&nbsp; &nbsp; ||(<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; (</span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">"logout"</span><span class="keyword">]==</span><span class="string">"logout"</span><span class="keyword">) <br />&nbsp; &nbsp;&nbsp; &amp;&amp; !(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_PW'</span><span class="keyword">]==</span><span class="string">""</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; )<br />&nbsp; &nbsp;&nbsp; ) {<br /></span><span class="default">Header</span><span class="keyword">(</span><span class="string">"WWW-Authenticate: Basic realm=\"Realm\""</span><span class="keyword">);<br /></span><span class="default">Header</span><span class="keyword">(</span><span class="string">"HTTP/1.0 401 Unauthorized"</span><span class="keyword">);<br />echo </span><span class="string">"Not logged out...&lt;br&gt;\n"</span><span class="keyword">;<br />echo </span><span class="string">"&lt;a href=\"index.php?login=login\"&gt;Login&lt;/a&gt;"</span><span class="keyword">;<br />exit;<br />} else if (</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_PW'</span><span class="keyword">]==</span><span class="string">""</span><span class="keyword">) {<br />echo </span><span class="string">"Logged out...&lt;br&gt;\n"</span><span class="keyword">;<br />echo </span><span class="string">"&lt;a href=\"index.php?login=login\"&gt;Login&lt;/a&gt;"</span><span class="keyword">;<br />exit;<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="37280">  <div class="votes">
    <div id="Vu37280">
    <a href="/manual/vote-note.php?id=37280&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd37280">
    <a href="/manual/vote-note.php?id=37280&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V37280" title="63% like this...">
    3
    </div>
  </div>
  <a href="#37280" class="name">
  <strong class="user"><em>Paul</em></strong></a><a class="genanchor" href="#37280"> &para;</a><div class="date" title="2003-11-08 03:53"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom37280">
<div class="phpcode"><code><span class="html">
Here is a extremely easy way to successfully logout.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">if ( </span><span class="default">$realm </span><span class="keyword">== </span><span class="string">'' </span><span class="keyword">)<br /></span><span class="default">$realm </span><span class="keyword">= </span><span class="default">mt_rand</span><span class="keyword">( </span><span class="default">1</span><span class="keyword">, </span><span class="default">1000000000 </span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">header</span><span class="keyword">( </span><span class="string">'WWW-Authenticate: Basic realm='</span><span class="keyword">.</span><span class="default">$realm </span><span class="keyword">); <br /></span><span class="default">?&gt;<br /></span><br />To log the user out simply change the value of $realm</span>
</code></div>
  </div>
 </div>
  <div class="note" id="81049">  <div class="votes">
    <div id="Vu81049">
    <a href="/manual/vote-note.php?id=81049&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd81049">
    <a href="/manual/vote-note.php?id=81049&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V81049" title="61% like this...">
    4
    </div>
  </div>
  <a href="#81049" class="name">
  <strong class="user"><em>Lars Stecken</em></strong></a><a class="genanchor" href="#81049"> &para;</a><div class="date" title="2008-02-12 10:23"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom81049">
<div class="phpcode"><code><span class="html">
To anybody who tried the digest example above and didn't get it to work.<br /><br />For me the problem seemed to be the deprecated use of '\' (backslash) in the regex instead of the '$' (Dollar) to indicate a backreference. Also the results have to be trimmed off the remaining double and single quotes. <br /><br />Here's the working example:<br /><br />// function to parse the http auth header<br />function http_digest_parse($txt)<br />{<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; // protect against missing data<br />&nbsp; &nbsp; $needed_parts = array('nonce'=&gt;1, 'nc'=&gt;1, 'cnonce'=&gt;1, 'qop'=&gt;1, 'username'=&gt;1, 'uri'=&gt;1, 'response'=&gt;1);<br />&nbsp; &nbsp; $data = array();<br /><br />&nbsp; &nbsp; preg_match_all('@(\w+)=(?:([\'"])([^$2]+)$2|([^\s,]+))@', $txt, $matches, PREG_SET_ORDER);<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; foreach ($matches as $m) {<br />&nbsp; &nbsp; &nbsp; &nbsp; $data[$m[1]] = $m[3] ? trim($m[3],"\",'") : trim($m[4],"\",'"); <br />&nbsp; &nbsp; &nbsp; &nbsp; unset($needed_parts[$m[1]]);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; return $needed_parts ? false : $data;<br />}<br /><br />Probably there's a more sophisticated way to trim the quotes within the regex, but I couldn't be bothered :-)<br /><br />Greets, Lars</span>
</code></div>
  </div>
 </div>
  <div class="note" id="70693">  <div class="votes">
    <div id="Vu70693">
    <a href="/manual/vote-note.php?id=70693&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd70693">
    <a href="/manual/vote-note.php?id=70693&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V70693" title="60% like this...">
    5
    </div>
  </div>
  <a href="#70693" class="name">
  <strong class="user"><em>SlamJam</em></strong></a><a class="genanchor" href="#70693"> &para;</a><div class="date" title="2006-10-23 11:28"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom70693">
<div class="phpcode"><code><span class="html">
I used Louis example (03-Jun-2006) and it works well for me (thanks).<br /><br />However, I added some lines, to make sure, the user does only get the Authentification-Window a few times:<br /><br /><span class="default">&lt;?php<br />$realm </span><span class="keyword">= </span><span class="default">mt_rand</span><span class="keyword">( </span><span class="default">1</span><span class="keyword">, </span><span class="default">1000000000</span><span class="keyword">).</span><span class="string">"@YourCompany"</span><span class="keyword">;<br /></span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'realm'</span><span class="keyword">] = </span><span class="default">$realm</span><span class="keyword">;<br /><br /></span><span class="comment">// In the beginning, when the realm ist defined:<br /></span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'CountTrials'</span><span class="keyword">] = </span><span class="default">1</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />And then when it comes to check the authentification (ZEND-Tutorial):<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="comment">// Not more than 3 Trials<br /></span><span class="keyword">if (!</span><span class="default">$auth</span><span class="keyword">) {<br />&nbsp;&nbsp; </span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'CountTrials'</span><span class="keyword">]++;<br />&nbsp;&nbsp; if (</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'CountTrials'</span><span class="keyword">] == </span><span class="default">4</span><span class="keyword">) {&nbsp;&nbsp; <br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">session_destroy</span><span class="keyword">() ;<br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">'Location: noentry.php'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp;&nbsp; exit ;&nbsp;&nbsp; <br />&nbsp;&nbsp; } else {<br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">"WWW-Authenticate: Basic realm="</span><span class="keyword">.</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'realm'</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">"HTTP/1.0 401 Unauthorized"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp;&nbsp; echo </span><span class="string">'Authorization Required.'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp;&nbsp; exit;<br />&nbsp;&nbsp; }<br />} else {<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; echo </span><span class="string">'&lt;P&gt;You are authorized!&lt;/P&gt;'</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />noentry.php is slightely different from comeagain.php.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="100101">  <div class="votes">
    <div id="Vu100101">
    <a href="/manual/vote-note.php?id=100101&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd100101">
    <a href="/manual/vote-note.php?id=100101&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V100101" title="60% like this...">
    4
    </div>
  </div>
  <a href="#100101" class="name">
  <strong class="user"><em>Ollie L</em></strong></a><a class="genanchor" href="#100101"> &para;</a><div class="date" title="2010-09-24 04:16"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom100101">
<div class="phpcode"><code><span class="html">
I tried example 7, and at first I couldn't get it to work. It took me a while to spot that somewhere along the line, probably by the server, a seemingly random number was being added to the realm - so the valid_result variable wasn't calculated using the correct realm.<br /><br />To get around this, or any similar problems, make the following changes to the example:<br /><br />Around line 43 (44 if after next step ;) ):<br />$needed_parts = array('nonce'=&gt;1, 'nc'=&gt;1, 'cnonce'=&gt;1, 'qop'=&gt;1, 'username'=&gt;1, 'uri'=&gt;1, 'response'=&gt;1, 'realm'=&gt;1);<br /><br />Before line 24:<br />$realm = $data['realm'];<br /><br />These two steps get the real realm used for the authentication request, and substitute it into the "valid_response" query.<br /><br />Hope this helps :)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114080">  <div class="votes">
    <div id="Vu114080">
    <a href="/manual/vote-note.php?id=114080&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114080">
    <a href="/manual/vote-note.php?id=114080&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114080" title="59% like this...">
    4
    </div>
  </div>
  <a href="#114080" class="name">
  <strong class="user"><em>Robb_Bean at gmx dot net</em></strong></a><a class="genanchor" href="#114080"> &para;</a><div class="date" title="2014-01-09 04:55"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114080">
<div class="phpcode"><code><span class="html">
In the german example #2 (digest), the <span class="default">&lt;?php $realm </span><span class="keyword">= </span><span class="string">"Geschützter Bereich"</span><span class="keyword">; </span><span class="default">?&gt;</span>. As far as I have tested the umlaut ü is problematic, resulting in an password enter infinity loop. In my case it was written in UTF-8. So I suggest using only plain ASCII characters for the realm.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="110219">  <div class="votes">
    <div id="Vu110219">
    <a href="/manual/vote-note.php?id=110219&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd110219">
    <a href="/manual/vote-note.php?id=110219&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V110219" title="57% like this...">
    5
    </div>
  </div>
  <a href="#110219" class="name">
  <strong class="user"><em>xsanychx at mail dot ru</em></strong></a><a class="genanchor" href="#110219"> &para;</a><div class="date" title="2012-10-02 09:32"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom110219">
<div class="phpcode"><code><span class="html">
New auth:<br /><br /><span class="default">&lt;?php<br />$login </span><span class="keyword">= </span><span class="string">'test_login'</span><span class="keyword">;<br /></span><span class="default">$pass </span><span class="keyword">= </span><span class="string">'test_pass'</span><span class="keyword">;<br /><br />if((</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_PW'</span><span class="keyword">]!= </span><span class="default">$pass </span><span class="keyword">|| </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">] != </span><span class="default">$login</span><span class="keyword">)|| !</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">])<br />{<br />&nbsp; &nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">'WWW-Authenticate: Basic realm="Test auth"'</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">'HTTP/1.0 401 Unauthorized'</span><span class="keyword">);<br />&nbsp; &nbsp; echo </span><span class="string">'Auth failed'</span><span class="keyword">;<br />&nbsp; &nbsp; exit;<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="88957">  <div class="votes">
    <div id="Vu88957">
    <a href="/manual/vote-note.php?id=88957&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd88957">
    <a href="/manual/vote-note.php?id=88957&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V88957" title="60% like this...">
    3
    </div>
  </div>
  <a href="#88957" class="name">
  <strong class="user"><em>Yuriy</em></strong></a><a class="genanchor" href="#88957"> &para;</a><div class="date" title="2009-02-15 06:11"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom88957">
<div class="phpcode"><code><span class="html">
Good day.<br />Sorry for my english.<br />This example shows programming "LOGIN", "LOGOUT" and "RE-LOGIN".<br />This script must use in the protected pages.<br />For work this script the browser address string must be following:<br />"<a href="http://localhost/admin/?login" rel="nofollow" target="_blank">http://localhost/admin/?login</a>" - for Login,<br />"<a href="http://localhost/admin/?logout" rel="nofollow" target="_blank">http://localhost/admin/?logout</a>" - for Logout,<br />"<a href="http://localhost/admin/?logout&amp;login" rel="nofollow" target="_blank">http://localhost/admin/?logout&amp;login</a>" - for Re-Login.<br /><span class="default">&lt;?php<br />session_start</span><span class="keyword">();<br /><br /></span><span class="default">$authorized </span><span class="keyword">= </span><span class="default">false</span><span class="keyword">;<br /><br /></span><span class="comment"># LOGOUT<br /></span><span class="keyword">if (isset(</span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">'logout'</span><span class="keyword">]) &amp;&amp; !isset(</span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">"login"</span><span class="keyword">]) &amp;&amp; isset(</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'auth'</span><span class="keyword">]))<br />{<br />&nbsp; &nbsp; </span><span class="default">$_SESSION </span><span class="keyword">= array();<br />&nbsp; &nbsp; unset(</span><span class="default">$_COOKIE</span><span class="keyword">[</span><span class="default">session_name</span><span class="keyword">()]);<br />&nbsp; &nbsp; </span><span class="default">session_destroy</span><span class="keyword">();<br />&nbsp; &nbsp; echo </span><span class="string">"logging out..."</span><span class="keyword">;<br />}<br /><br /></span><span class="comment"># checkup login and password<br /></span><span class="keyword">if (isset(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">]) &amp;&amp; isset(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_PW'</span><span class="keyword">]))<br />{<br />&nbsp; &nbsp; </span><span class="default">$user </span><span class="keyword">= </span><span class="string">'test'</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$pass </span><span class="keyword">= </span><span class="string">'test'</span><span class="keyword">;<br />&nbsp; &nbsp; if ((</span><span class="default">$user </span><span class="keyword">== </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">]) &amp;&amp; (</span><span class="default">$pass </span><span class="keyword">== (</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_PW'</span><span class="keyword">])) &amp;&amp; isset(</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'auth'</span><span class="keyword">]))<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; </span><span class="default">$authorized </span><span class="keyword">= </span><span class="default">true</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="comment"># login<br /></span><span class="keyword">if (isset(</span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">"login"</span><span class="keyword">]) &amp;&amp; !</span><span class="default">$authorized </span><span class="keyword">||<br /></span><span class="comment"># relogin<br />&nbsp; &nbsp; </span><span class="keyword">isset(</span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">"login"</span><span class="keyword">]) &amp;&amp; isset(</span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">"logout"</span><span class="keyword">]) &amp;&amp; !isset(</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'reauth'</span><span class="keyword">]))<br />{<br />&nbsp; &nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">'WWW-Authenticate: Basic Realm="Login please"'</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">'HTTP/1.0 401 Unauthorized'</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'auth'</span><span class="keyword">] = </span><span class="default">true</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'reauth'</span><span class="keyword">] = </span><span class="default">true</span><span class="keyword">;<br />&nbsp; &nbsp; echo </span><span class="string">"Login now or forever hold your clicks..."</span><span class="keyword">;<br />&nbsp; &nbsp; exit;<br />}<br /></span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'reauth'</span><span class="keyword">] = </span><span class="default">null</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span>&lt;h1&gt;you have &lt;? echo ($authorized) ? (isset($_GET["login"]) &amp;&amp; isset($_GET["logout"]) ? 're' : '') : 'not '; ?&gt;logged!&lt;/h1&gt;</span>
</code></div>
  </div>
 </div>
  <div class="note" id="67146">  <div class="votes">
    <div id="Vu67146">
    <a href="/manual/vote-note.php?id=67146&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd67146">
    <a href="/manual/vote-note.php?id=67146&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V67146" title="60% like this...">
    3
    </div>
  </div>
  <a href="#67146" class="name">
  <strong class="user"><em>Louis</em></strong></a><a class="genanchor" href="#67146"> &para;</a><div class="date" title="2006-06-03 03:51"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom67146">
<div class="phpcode"><code><span class="html">
I couldn't get authentication to work properly with any of the examples. Finally, I started from ZEND's tutorial example at:<br /><a href="http://www.zend.com/zend/tut/authentication.php?article=authentication" rel="nofollow" target="_blank">http://www.zend.com/zend/tut/authentication.php?article=authentication</a> (validate using .htpasswd) and tried to deal with the additional cases. My general conclusion is that changing the realm is the only reliable way to cause the browser to ask again, and I like to thank the person who put that example in the manual, as it got me on the right path. No matter what, the browser refuses to discard the values that it already has in mind otherwise. The problem with changing the realm, of course, is that you don't want to do it within a given session, else it causes a new request for a password. So, here goes, hopefully the spacing isn't too messed up by the cut'n'paste.<br /><br />I spent the better part of a day getting this to work right. I had a very hard time thinking through what the browser does when it encounters an authentication request: seems to me that it tries to get the password, then reloads the page... so the HTML doesn't get run. At least, this was the case with IE, I haven't tested it with anything else.<br /><br /><span class="default">&lt;?php<br />session_start</span><span class="keyword">() ;<br />if (!isset(</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'realm'</span><span class="keyword">])) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'realm'</span><span class="keyword">] = </span><span class="default">mt_rand</span><span class="keyword">( </span><span class="default">1</span><span class="keyword">, </span><span class="default">1000000000 </span><span class="keyword">).<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">" SECOND level: Enter your !!!COMPANY!!! password."</span><span class="keyword">;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">header</span><span class="keyword">( </span><span class="string">"WWW-Authenticate: Basic realm="</span><span class="keyword">.</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'realm'</span><span class="keyword">] );<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//&nbsp; Below here runs HTML-wise only if there isn't a $_SESSION,<br />&nbsp; &nbsp; &nbsp; &nbsp; // and the browser *can't* set $PHP_AUTH_USER... normally<br />&nbsp; &nbsp; &nbsp; &nbsp; // the browser, having gotten the auth info, runs the page<br />&nbsp; &nbsp; &nbsp; &nbsp; // again without getting here.<br />&nbsp; &nbsp; &nbsp; &nbsp; //&nbsp; What I'm basically getting to is that the way to get<br />&nbsp; &nbsp; &nbsp; &nbsp; // here is to escape past the login screen. I tried<br />&nbsp; &nbsp; &nbsp; &nbsp; // putting a session_destroy() here originally, but the<br />&nbsp; &nbsp; &nbsp; &nbsp; // problem is that the PHP runs regardless, so the<br />&nbsp; &nbsp; &nbsp; &nbsp; // REFRESH seems like the best way to deal with it.<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">echo </span><span class="string">"&lt;meta http-equiv=\"REFRESH\"<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; content=\"0;url=index.php\"&gt;" </span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; exit;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />if (</span><span class="default">$_POST</span><span class="keyword">[</span><span class="string">'logout'</span><span class="keyword">] == </span><span class="string">"logout"</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">session_destroy</span><span class="keyword">() ;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">'Location: comeagain.php'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; exit ;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br /></span><span class="comment">// "standard" authentication code here, from the ZEND tutorial above.<br /><br /></span><span class="default">comeagain</span><span class="keyword">.</span><span class="default">php is </span><span class="keyword">as </span><span class="default">follows</span><span class="keyword">:<br /><br />&lt;?<br /></span><span class="default">session_start</span><span class="keyword">();<br />unset(</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'realm'</span><span class="keyword">]);<br /></span><span class="default">session_destroy</span><span class="keyword">();<br />echo </span><span class="string">"&lt;html&gt;&lt;head&gt;&lt;title&gt;Logged Out&lt;/title&gt;&lt;h1&gt;Logout Page&lt;/h1&gt;&lt;body&gt;" </span><span class="keyword">;<br />echo </span><span class="string">"You have successfully logged out of TOGEN"</span><span class="keyword">;<br />echo </span><span class="string">" at "</span><span class="keyword">.</span><span class="default">date</span><span class="keyword">(</span><span class="string">"h:m:s"</span><span class="keyword">).</span><span class="string">" on "</span><span class="keyword">.</span><span class="default">date</span><span class="keyword">(</span><span class="string">"d F Y"</span><span class="keyword">) ;<br />echo </span><span class="string">"&lt;p&gt;&lt;a href=\"index.php\"&gt;Login Again&lt;/a&gt;" </span><span class="keyword">;<br />echo </span><span class="string">"&lt;/body&gt;&lt;/html&gt;" </span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />The idea is to be able to trash the session (and thus reset the realm) without prompting the browser to ask again... because it has been redirected to logout.php.<br /><br />With this combination, I get things to work. Just make sure not to have apache run htpasswd authentication at the same time, then things get really weird :-).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118089">  <div class="votes">
    <div id="Vu118089">
    <a href="/manual/vote-note.php?id=118089&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118089">
    <a href="/manual/vote-note.php?id=118089&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118089" title="58% like this...">
    2
    </div>
  </div>
  <a href="#118089" class="name">
  <strong class="user"><em>dan223 at gmail dot com</em></strong></a><a class="genanchor" href="#118089"> &para;</a><div class="date" title="2015-10-01 10:45"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom118089">
<div class="phpcode"><code><span class="html">
A simple script for SSL Client Certificate authentication with a basic authentication fall-back. I use this on my site using LDAP server to check username/passwords and client certificate to user mapping.<br /><br />&lt;? <br />// Check if and how we are authenticated<br />if ($_SERVER['SSL_CLIENT_VERIFY'] != "SUCCESS") { // Not using a client certificate<br />&nbsp; &nbsp; if ((!$_SERVER['PHP_AUTH_USER']) &amp;&amp; (!$_SERVER['PHP_AUTH_PW'])) { // Not logged in using basic authentication<br />&nbsp; &nbsp; &nbsp; &nbsp; authenticate(); // Send basic authentication headers<br />&nbsp; &nbsp; }<br />}<br /><br />if ($_SERVER['SSL_CLIENT_S_DN_CN'] != "chris") { // Check CN name of cert<br /><br />&nbsp; &nbsp; if (!(($_SERVER['PHP_AUTH_USER'] == "test") &amp;&amp; ($_SERVER['PHP_AUTH_PW'] == "123"))) { // Check username and password<br />&nbsp; &nbsp; &nbsp; &nbsp; authenticate(); // Send basic authentication headers because username and/or password didnot match<br />&nbsp; &nbsp; } <br />} <br /><br />phpinfo();<br /><br />// Call authentication display<br />function authenticate() {<br />&nbsp; &nbsp; Header("WWW-Authenticate: Basic realm=Website");<br />&nbsp; &nbsp; &nbsp; &nbsp; Header("HTTP/1.0 401 Unauthorized");<br />&nbsp; &nbsp; &nbsp; &nbsp; error401();<br />&nbsp; &nbsp; &nbsp; &nbsp; exit;<br />}<br />?&gt;<br /><br />See my website (<a href="http://velocitypress.ca/index.php?page=/manuals/" rel="nofollow" target="_blank">http://velocitypress.ca/index.php?page=/manuals/</a>) for more details on client certificate with Apache and PHP.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="44745">  <div class="votes">
    <div id="Vu44745">
    <a href="/manual/vote-note.php?id=44745&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd44745">
    <a href="/manual/vote-note.php?id=44745&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V44745" title="58% like this...">
    3
    </div>
  </div>
  <a href="#44745" class="name">
  <strong class="user"><em>jason</em></strong></a><a class="genanchor" href="#44745"> &para;</a><div class="date" title="2004-08-14 10:12"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom44745">
<div class="phpcode"><code><span class="html">
on the php+mysql auth code by tigran at freenet dot am<br /><br />There are some security weaknesses.<br /><br />First<br />$user <br />&nbsp; and <br />$pass<br /><br />are both insecure, they could leave this code open to SQL injection, you should always remove invalid characters in both, or at least encode them.<br /><br />Actually storing passwords as MD5 hashes leaves you less work to secure.<br /><br />Second security risks<br />The same mysql user has rights to both update and select, and possibly even insert and on your auth database no less.<br />Again the SQL inject attack may occur with this., and the end user could then change the users username, password, or anything else in relation to this.<br /><br />Third items is more of a performance issue,<br />&nbsp; <br />Do you really need to update the database, as updates are slower then selects, and if you do them every time they access the page, you are costing some speed penalty.&nbsp; <br /><br />One option, if you want to use sql (I think mysql has it) is memory only databases, and create a table within memory, the stores a unique session identifier for each user, that is logged in, or alternatively if it's a single front end system, you could use db files.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="18618">  <div class="votes">
    <div id="Vu18618">
    <a href="/manual/vote-note.php?id=18618&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd18618">
    <a href="/manual/vote-note.php?id=18618&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V18618" title="57% like this...">
    3
    </div>
  </div>
  <a href="#18618" class="name">
  <strong class="user"><em>sjeffrey at inquesis dot com</em></strong></a><a class="genanchor" href="#18618"> &para;</a><div class="date" title="2002-01-29 03:00"><strong>15 years ago</strong></div>
  <div class="text" id="Hcom18618">
<div class="phpcode"><code><span class="html">
To get it to work with IIS try using this code before setting your "$auth = 0" and the "if (isset($PHP_AUTH_USER) &amp;&amp; isset($PHP_AUTH_PW))"<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">//////////////////////////////////////////<br /><br /></span><span class="keyword">if (</span><span class="default">$PHP_AUTH_USER </span><span class="keyword">== </span><span class="string">"" </span><span class="keyword">&amp;&amp; </span><span class="default">$PHP_AUTH_PW </span><span class="keyword">== </span><span class="string">"" </span><span class="keyword">&amp;&amp; </span><span class="default">ereg</span><span class="keyword">(</span><span class="string">"^Basic "</span><span class="keyword">, </span><span class="default">$HTTP_AUTHORIZATION</span><span class="keyword">)) <br />{ <br />&nbsp; list(</span><span class="default">$PHP_AUTH_USER</span><span class="keyword">, </span><span class="default">$PHP_AUTH_PW</span><span class="keyword">) = <br />&nbsp; &nbsp; </span><span class="default">explode</span><span class="keyword">(</span><span class="string">":"</span><span class="keyword">, </span><span class="default">base64_decode</span><span class="keyword">(</span><span class="default">substr</span><span class="keyword">(</span><span class="default">$HTTP_AUTHORIZATION</span><span class="keyword">, </span><span class="default">6</span><span class="keyword">))); <br />}<br /><br /></span><span class="comment">//////////////////////////////////////////<br /></span><span class="default">?&gt;<br /></span><br />It worked for me on IIS 5 and PHP 4 in ISAPI</span>
</code></div>
  </div>
 </div>
  <div class="note" id="66468">  <div class="votes">
    <div id="Vu66468">
    <a href="/manual/vote-note.php?id=66468&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd66468">
    <a href="/manual/vote-note.php?id=66468&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V66468" title="57% like this...">
    2
    </div>
  </div>
  <a href="#66468" class="name">
  <strong class="user"><em>kembl at example dot com</em></strong></a><a class="genanchor" href="#66468"> &para;</a><div class="date" title="2006-05-23 08:06"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom66468">
<div class="phpcode"><code><span class="html">
# PHP (CGI mode) HTTP Authorization with ModRewrite: <br /># most right example with header check for non empty:<br /> RewriteEngine on<br /> RewriteCond %{HTTP:Authorization}&nbsp; !^$<br /> RewriteRule .* - [E=REMOTE_USER:%{HTTP:Authorization}, \<br />E=PHP_AUTH_USER:%{HTTP:Authorization},L]</span>
</code></div>
  </div>
 </div>
  <div class="note" id="40445">  <div class="votes">
    <div id="Vu40445">
    <a href="/manual/vote-note.php?id=40445&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd40445">
    <a href="/manual/vote-note.php?id=40445&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V40445" title="56% like this...">
    2
    </div>
  </div>
  <a href="#40445" class="name">
  <strong class="user"><em>rob at theblip dot com</em></strong></a><a class="genanchor" href="#40445"> &para;</a><div class="date" title="2004-03-03 08:47"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom40445">
<div class="phpcode"><code><span class="html">
Regarding HTTP authentication in IIS with the php cgi 4.3.4, there's one more step. I searched mightily and didn't find this information anywhere else, so here goes. When using HTTP auth with the php CGI, you need to do the following things:<br /><br />1. In your php.ini file, set "cgi.rfc2616_headers = 0"<br /><br />2. In Web Site Properties -&gt; File/Directory Security -&gt; Anonymous Access dialog box, check the "Anonymous access" checkbox and uncheck any other checkboxes (i.e. uncheck "Basic authentication," "Integrated Windows authentication," and "Digest" if it's enabled.) Click OK.<br /><br />3. In "Custom Errors", select the range of "401;1" through "401;5" and click the "Set to Default" button.<br /><br />It's this last step that is crucial, yet not documented anywhere. If you don't, instead of the headers asking for credentials, IIS will return its own fancy but useless 'you are not authenticated' page. But if you do, then the browser will properly ask for credentials, and supply them in the $_SERVER['PHP_AUTH_*'] elements.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="68088">  <div class="votes">
    <div id="Vu68088">
    <a href="/manual/vote-note.php?id=68088&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd68088">
    <a href="/manual/vote-note.php?id=68088&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V68088" title="55% like this...">
    2
    </div>
  </div>
  <a href="#68088" class="name">
  <strong class="user"><em>web at kwi dot dk</em></strong></a><a class="genanchor" href="#68088"> &para;</a><div class="date" title="2006-07-12 10:23"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom68088">
<div class="phpcode"><code><span class="html">
While Digest authentication is still far superior to Basic authentication, there are a number of security issues that one must keep in mind.<br /><br />In this respect, the Digest example given above is somewhat flawed, because the nonce never times out or otherwise become invalid. It thus becomes a password-equivalent (although to that specific URL only) and can be used by an eavesdropper to fetch the page at any time in the future, thus allowing the attacker to always access the latest version of the page, or (much worse) repeatedly invoke a CGI script -- for instance, if the user requests the URL "/filemanager?delete=somefile", the attacker can repeat this deletion at any point in the future, possibly after the file has been recreated.<br /><br />And while it might not be possible to change GET data without reauthentication, cookies and POST data *can* be changed.<br /><br />To protect against the first problem, the nonce can be made to include a timestamp, and a check added to ensure that nonces older than e.g. 30 minutes result in a new authentication request. <br /><br />To solve the second problem, a one-time only nonce needs to be generated -- that is, all further requests using a particular nonce must be refused.<br /><br />One way to do this: When the user requests an action such as "deletefile", store a randomly generated nonce in a session variable, issue a 401 authentication challenge with that nonce, and then check against the stored value when receiving the authentication (and clear the session variable).<br /><br />This way, although a possible eavesdropper receives the nonce and thus gains the ability to perform the action, he can only perform it once -- and the user was going to perform it anyway. (Only the user or the attacker, but not both, gets to perform the action, so it's safe.)<br /><br />Of course, at some point, the security can only be improved by switching to HTTPS / SSL / TLS (this is for instance the only way to defend against man-in-the-middle attacks). You decide the level of security.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="53962">  <div class="votes">
    <div id="Vu53962">
    <a href="/manual/vote-note.php?id=53962&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd53962">
    <a href="/manual/vote-note.php?id=53962&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V53962" title="55% like this...">
    2
    </div>
  </div>
  <a href="#53962" class="name">
  <strong class="user"><em>snagnever at gmail dot com</em></strong></a><a class="genanchor" href="#53962"> &para;</a><div class="date" title="2005-06-18 03:39"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom53962">
<div class="phpcode"><code><span class="html">
It forces a auth each time the page is accessed:<br />(maybe can save someone)<br /><br />&lt;?<br />header("Expires: Sat, 01 Jan 2000 00:00:00 GMT");<br />header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");<br />header("Cache-Control: post-check=0, pre-check=0",false);<br />header("Pragma: no-cache");<br />session_cache_limiter("public, no-store");<br />session_start();<br /><br />function http_auth()<br />{<br />&nbsp; &nbsp; $_SESSION['AUTH'] = 1;<br />&nbsp; &nbsp; header('HTTP/1.0 401 Unauthorized');<br />&nbsp; &nbsp; header('WWW-Authenticate: Basic realm="sn4g auth system"');<br />&nbsp; &nbsp; // The actions to be done when the user clicks on 'cancel'<br />&nbsp; &nbsp; exit();<br />}<br /><br />if( !isset($_SERVER['PHP_AUTH_USER']) or @$_SESSION['AUTH'] != 1 )<br />{<br />&nbsp; &nbsp; http_auth();<br />&nbsp; &nbsp; exit();<br />}<br /><br />// Actions do be done when the user has logged<br /><br />// rest, must clean the session array<br />$_SESSION = array();<br />session_destroy();<br />?&gt;</span>
</code></div>
  </div>
 </div>
  <div class="note" id="70864">  <div class="votes">
    <div id="Vu70864">
    <a href="/manual/vote-note.php?id=70864&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd70864">
    <a href="/manual/vote-note.php?id=70864&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V70864" title="55% like this...">
    2
    </div>
  </div>
  <a href="#70864" class="name">
  <strong class="user"><em>admin at isprohosting dot com</em></strong></a><a class="genanchor" href="#70864"> &para;</a><div class="date" title="2006-11-01 06:21"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom70864">
<div class="phpcode"><code><span class="html">
There are .htaccess which actually works for us (cPanel + phpsuexec) unless others failed. Perhaps it may help someone.<br /><br /># PHP (CGI mode) HTTP Authorization with ModRewrite:<br />RewriteEngine on<br />RewriteCond %{HTTP:Authorization} ^(.*)<br />RewriteRule ^(.*) - [E=HTTP_AUTHORIZATION:%1]<br /><br />Then you need small piece of php code to parse this line and then everything will work like with mod_php:<br /><br />if (isset($_SERVER['HTTP_AUTHORIZATION']))<br />{<br />$ha = base64_decode( substr($_SERVER['HTTP_AUTHORIZATION'],6) );<br />list($_SERVER['PHP_AUTH_USER'], $_SERVER['PHP_AUTH_PW']) = explode(':', $ha);<br />unset $ha;<br />}<br /><br />Enjoy!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118359">  <div class="votes">
    <div id="Vu118359">
    <a href="/manual/vote-note.php?id=118359&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118359">
    <a href="/manual/vote-note.php?id=118359&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118359" title="53% like this...">
    1
    </div>
  </div>
  <a href="#118359" class="name">
  <strong class="user"><em>john_2232 at gmail dot com</em></strong></a><a class="genanchor" href="#118359"> &para;</a><div class="date" title="2015-11-22 07:05"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom118359">
<div class="phpcode"><code><span class="html">
Here is my attempt to create a digest authentication class that will log the user in and out without using a cookie,session,db,or file. At the core is this simple code to parse the digest string into variables works for several browsers.<br /><span class="default">&lt;?php<br /></span><span class="comment">// explode the digest with multibrowser support by Tony Wyatt 21jun07<br /></span><span class="keyword">public function </span><span class="default">explodethedigest</span><span class="keyword">(</span><span class="default">$instring</span><span class="keyword">) {<br /></span><span class="default">$quote </span><span class="keyword">= </span><span class="string">'"'</span><span class="keyword">;<br /></span><span class="default">$equal </span><span class="keyword">= </span><span class="string">'='</span><span class="keyword">;<br /></span><span class="default">$comma </span><span class="keyword">= </span><span class="string">','</span><span class="keyword">;<br /></span><span class="default">$space </span><span class="keyword">= </span><span class="string">' '</span><span class="keyword">;<br /></span><span class="default">$a </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">( </span><span class="default">$comma</span><span class="keyword">, </span><span class="default">$instring</span><span class="keyword">);<br /></span><span class="default">$ax </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">(</span><span class="default">$space</span><span class="keyword">, </span><span class="default">$a</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]);<br /></span><span class="default">$b </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">( </span><span class="default">$equal</span><span class="keyword">, </span><span class="default">$ax</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">], </span><span class="default">2</span><span class="keyword">);<br /></span><span class="default">$c </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">( </span><span class="default">$equal</span><span class="keyword">, </span><span class="default">$a</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">], </span><span class="default">2</span><span class="keyword">);<br /></span><span class="default">$d </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">( </span><span class="default">$equal</span><span class="keyword">, </span><span class="default">$a</span><span class="keyword">[</span><span class="default">2</span><span class="keyword">], </span><span class="default">2</span><span class="keyword">);<br /></span><span class="default">$e </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">( </span><span class="default">$equal</span><span class="keyword">, </span><span class="default">$a</span><span class="keyword">[</span><span class="default">3</span><span class="keyword">], </span><span class="default">2</span><span class="keyword">);<br /></span><span class="default">$f </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">( </span><span class="default">$equal</span><span class="keyword">, </span><span class="default">$a</span><span class="keyword">[</span><span class="default">4</span><span class="keyword">], </span><span class="default">2</span><span class="keyword">);<br /></span><span class="default">$g </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">( </span><span class="default">$equal</span><span class="keyword">, </span><span class="default">$a</span><span class="keyword">[</span><span class="default">5</span><span class="keyword">], </span><span class="default">2</span><span class="keyword">);<br /></span><span class="default">$h </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">( </span><span class="default">$equal</span><span class="keyword">, </span><span class="default">$a</span><span class="keyword">[</span><span class="default">6</span><span class="keyword">], </span><span class="default">2</span><span class="keyword">);<br /></span><span class="default">$i </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">( </span><span class="default">$equal</span><span class="keyword">, </span><span class="default">$a</span><span class="keyword">[</span><span class="default">7</span><span class="keyword">], </span><span class="default">2</span><span class="keyword">);<br /></span><span class="default">$j </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">( </span><span class="default">$equal</span><span class="keyword">, </span><span class="default">$a</span><span class="keyword">[</span><span class="default">8</span><span class="keyword">], </span><span class="default">2</span><span class="keyword">);<br /></span><span class="default">$k </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">( </span><span class="default">$equal</span><span class="keyword">, </span><span class="default">$a</span><span class="keyword">[</span><span class="default">9</span><span class="keyword">], </span><span class="default">2</span><span class="keyword">);<br /></span><span class="default">$l </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">( </span><span class="default">$equal</span><span class="keyword">, </span><span class="default">$a</span><span class="keyword">[</span><span class="default">10</span><span class="keyword">], </span><span class="default">2</span><span class="keyword">);<br /></span><span class="default">$parts </span><span class="keyword">= array(</span><span class="default">trim</span><span class="keyword">(</span><span class="default">$b</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">])=&gt;</span><span class="default">trim</span><span class="keyword">(</span><span class="default">$b</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">], </span><span class="string">'"'</span><span class="keyword">), </span><span class="default">trim</span><span class="keyword">(</span><span class="default">$c</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">])=&gt;</span><span class="default">trim</span><span class="keyword">(</span><span class="default">$c</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">], </span><span class="string">'"'</span><span class="keyword">), </span><span class="default">trim</span><span class="keyword">(</span><span class="default">$d</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">])=&gt;</span><span class="default">trim</span><span class="keyword">(</span><span class="default">$d</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">], </span><span class="string">'"'</span><span class="keyword">), </span><span class="default">trim</span><span class="keyword">(</span><span class="default">$e</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">])=&gt;</span><span class="default">trim</span><span class="keyword">(</span><span class="default">$e</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">], </span><span class="string">'"'</span><span class="keyword">), </span><span class="default">trim</span><span class="keyword">(</span><span class="default">$f</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">])=&gt;</span><span class="default">trim</span><span class="keyword">(</span><span class="default">$f</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">], </span><span class="string">'"'</span><span class="keyword">), </span><span class="default">trim</span><span class="keyword">(</span><span class="default">$g</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">])=&gt;</span><span class="default">trim</span><span class="keyword">(</span><span class="default">$g</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">], </span><span class="string">'"'</span><span class="keyword">), </span><span class="default">trim</span><span class="keyword">(</span><span class="default">$h</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">])=&gt;</span><span class="default">trim</span><span class="keyword">(</span><span class="default">$h</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">], </span><span class="string">'"'</span><span class="keyword">), </span><span class="default">trim</span><span class="keyword">(</span><span class="default">$i</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">])=&gt;</span><span class="default">trim</span><span class="keyword">(</span><span class="default">$i</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">], </span><span class="string">'"'</span><span class="keyword">), </span><span class="default">trim</span><span class="keyword">(</span><span class="default">$j</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">])=&gt;</span><span class="default">trim</span><span class="keyword">(</span><span class="default">$j</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">], </span><span class="string">'"'</span><span class="keyword">), </span><span class="default">trim</span><span class="keyword">(</span><span class="default">$k</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">])=&gt;</span><span class="default">trim</span><span class="keyword">(</span><span class="default">$k</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">], </span><span class="string">'"'</span><span class="keyword">), </span><span class="default">trim</span><span class="keyword">(</span><span class="default">$l</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">])=&gt;</span><span class="default">trim</span><span class="keyword">(</span><span class="default">$l</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">], </span><span class="string">'"'</span><span class="keyword">));<br /><br />return </span><span class="default">$parts</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span>Give it a try at <a href="http://www.creativetheory.ca/" rel="nofollow" target="_blank">http://www.creativetheory.ca/</a> /tests/ta1.php Log in with user test password pass or user guest password guest. Go to page two for links to the code. Comments, ideas, suggestions, or critique welcome.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="76708">  <div class="votes">
    <div id="Vu76708">
    <a href="/manual/vote-note.php?id=76708&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd76708">
    <a href="/manual/vote-note.php?id=76708&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V76708" title="55% like this...">
    1
    </div>
  </div>
  <a href="#76708" class="name">
  <strong class="user"><em>gbelyh at gmail dot com</em></strong></a><a class="genanchor" href="#76708"> &para;</a><div class="date" title="2007-07-26 11:48"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom76708">
<div class="phpcode"><code><span class="html">
Back to the autherisation in CGI mode. this is the full working example:<br /><br />#&nbsp; Create the .htaccess file with following contents:<br /># also you can use the condition (search at this page)<br />RewriteEngine on<br />RewriteRule .* - [E=REMOTE_USER:%{HTTP:Authorization},L]<br /><br /># In the beginning the script checking the authorization place the code:<br /><br />$userpass = base64_decode(substr($_SERVER["REDIRECT_REMOTE_USER"],6)) ;<br /><br />$userpass = explode(":", $userpass);<br /><br />if (&nbsp; count($userpass) == 2&nbsp; ){<br />&nbsp; &nbsp;&nbsp; #this part work not for all.<br />&nbsp; &nbsp;&nbsp; #print_r($userpass);die; #&lt;- this can help find out right username and password<br />&nbsp; &nbsp;&nbsp; list($name, $password) = explode(':', $userpass);<br />&nbsp; &nbsp;&nbsp; $_SERVER['PHP_AUTH_USER'] = $name;<br />&nbsp; &nbsp;&nbsp; $_SERVER['PHP_AUTH_PW'] = $password;<br /><br />}</span>
</code></div>
  </div>
 </div>
  <div class="note" id="108132">  <div class="votes">
    <div id="Vu108132">
    <a href="/manual/vote-note.php?id=108132&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd108132">
    <a href="/manual/vote-note.php?id=108132&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V108132" title="54% like this...">
    1
    </div>
  </div>
  <a href="#108132" class="name">
  <strong class="user"><em>kazakevichilya at gmail dot com</em></strong></a><a class="genanchor" href="#108132"> &para;</a><div class="date" title="2012-03-30 08:20"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom108132">
<div class="phpcode"><code><span class="html">
In case of CGI/FastCGI you would hot be able to access PHP_AUTH* info because CGI protocol does not declare such variables (that is why their names start from PHP) and server would not pass them to the interpreter. In CGI server should authenticate user itself and pass REMOTE_USER to CGI script after it. <br /><br />So you need to "fetch" request headers and pass them to your script somehow. <br /><br />In apache you can do it via environment variables if mod_env is installed. <br /><br />Following construction in .htaccess copies request header "Authorization" to the env variable PHP_AUTH_DIGEST_RAW<br /><br />SetEnvIfNoCase ^Authorization$ "(.+)" PHP_AUTH_DIGEST_RAW=$1<br /><br />You can now access it via $_ENV.<br /><br />Do not forget to strip auth type ("Digest" in my case) from your env variable because PHP_AUTH_DIGEST does not have it.<br /><br />If mod_env is not installed you probably have mod_rewrite (everyone has it because of "human readable URLs").<br /><br />You can fetch header and pass it as GET parameter using rewrite rule: <br /><br />RewriteRule ^.*$ site.php?PHP_AUTH_DIGEST_RAW=%{HTTP:Authorization} [NC,L]<br /><br />Here HTTP request header Authorization would be acessible as PHP_AUTH_DIGEST_RAW via $_GET.<br /><br />---<br />If you use ZF you probably use Zend_Auth_Adapter_Http to auth user. <br /><br />It takes Authorization info using "Zend_Controller_Request::getHeader"<br />This method uses apache_request_header which is likely not to be accessible in old CGI/FastCGI installations or _$_SERVER['HTTP_&lt;HeaderName&gt;] , so you need to put your authentication data, obtained via _GET or ENV to <br />_$_SERVER['HTTP_AUTHORIZATION']. <br />It will make ZF work transparently with you solution and I believe any other framework should work also</span>
</code></div>
  </div>
 </div>
  <div class="note" id="71069">  <div class="votes">
    <div id="Vu71069">
    <a href="/manual/vote-note.php?id=71069&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd71069">
    <a href="/manual/vote-note.php?id=71069&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V71069" title="55% like this...">
    1
    </div>
  </div>
  <a href="#71069" class="name">
  <strong class="user"><em>Whatabrain</em></strong></a><a class="genanchor" href="#71069"> &para;</a><div class="date" title="2006-11-10 07:05"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom71069">
<div class="phpcode"><code><span class="html">
Back to the problem of authenticating in CGI mode... mcbethh suggested using this to set a local variable in php:<br />RewriteRule .* - [E=REMOTE_USER:%{HTTP:Authorization},L]<br /><br />It didn't work. I couldn't see the variable. My solution is pretty round-about, but it works:<br /><br />RewriteEngine on <br />RewriteCond %{HTTP:Authorization} !^$ <br />RewriteCond %{REQUEST_METHOD} =GET <br />RewriteCond %{QUERY_STRING} ="" <br />RewriteRule ^page.php$ page.php?login=%{HTTP:Authorization}$1 <br /><br />This causes the Auth string to be added to the URL if there are no parameters and it's a GET request. This prevents POSTs and parameter lists from being corrupted. <br /><br />Then, in the PHP script, I store the Auth string as a session cookie.<br /><br />So the only way to log in to my script is to go to the url with no parameters.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="93427">  <div class="votes">
    <div id="Vu93427">
    <a href="/manual/vote-note.php?id=93427&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd93427">
    <a href="/manual/vote-note.php?id=93427&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V93427" title="54% like this...">
    1
    </div>
  </div>
  <a href="#93427" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#93427"> &para;</a><div class="date" title="2009-09-09 10:02"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom93427">
<div class="phpcode"><code><span class="html">
The regex in http_digest_parse from Example #2 does not work for me (PHP 5.2.6), because back references are not allowed in a character class.&nbsp; This worked for me:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="comment">// function to parse the http auth header<br /></span><span class="keyword">function </span><span class="default">http_digest_parse</span><span class="keyword">(</span><span class="default">$txt</span><span class="keyword">)<br />{<br />&nbsp;&nbsp; </span><span class="comment">// protect against missing data<br />&nbsp;&nbsp; </span><span class="default">$needed_parts </span><span class="keyword">= array(</span><span class="string">'nonce'</span><span class="keyword">=&gt;</span><span class="default">1</span><span class="keyword">, </span><span class="string">'nc'</span><span class="keyword">=&gt;</span><span class="default">1</span><span class="keyword">, </span><span class="string">'cnonce'</span><span class="keyword">=&gt;</span><span class="default">1</span><span class="keyword">, </span><span class="string">'qop'</span><span class="keyword">=&gt;</span><span class="default">1</span><span class="keyword">, </span><span class="string">'username'</span><span class="keyword">=&gt;</span><span class="default">1</span><span class="keyword">, </span><span class="string">'uri'</span><span class="keyword">=&gt;</span><span class="default">1</span><span class="keyword">, </span><span class="string">'response'</span><span class="keyword">=&gt;</span><span class="default">1</span><span class="keyword">);<br />&nbsp;&nbsp; </span><span class="default">$data </span><span class="keyword">= array();<br /><br />&nbsp;&nbsp; </span><span class="default">preg_match_all</span><span class="keyword">(</span><span class="string">'@(\w+)=(?:(?:\'([^\']+)\'|"([^"]+)")|([^\s,]+))@'</span><span class="keyword">, </span><span class="default">$txt</span><span class="keyword">, </span><span class="default">$matches</span><span class="keyword">, </span><span class="default">PREG_SET_ORDER</span><span class="keyword">);<br /><br />&nbsp;&nbsp; foreach (</span><span class="default">$matches </span><span class="keyword">as </span><span class="default">$m</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$data</span><span class="keyword">[</span><span class="default">$m</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]] = </span><span class="default">$m</span><span class="keyword">[</span><span class="default">2</span><span class="keyword">] ? </span><span class="default">$m</span><span class="keyword">[</span><span class="default">2</span><span class="keyword">] : (</span><span class="default">$m</span><span class="keyword">[</span><span class="default">3</span><span class="keyword">] ? </span><span class="default">$m</span><span class="keyword">[</span><span class="default">3</span><span class="keyword">] : </span><span class="default">$m</span><span class="keyword">[</span><span class="default">4</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp;&nbsp; unset(</span><span class="default">$needed_parts</span><span class="keyword">[</span><span class="default">$m</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]]);<br />&nbsp;&nbsp; }<br /><br />&nbsp;&nbsp; return </span><span class="default">$needed_parts </span><span class="keyword">? </span><span class="default">false </span><span class="keyword">: </span><span class="default">$data</span><span class="keyword">;<br />}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="42372">  <div class="votes">
    <div id="Vu42372">
    <a href="/manual/vote-note.php?id=42372&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd42372">
    <a href="/manual/vote-note.php?id=42372&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V42372" title="55% like this...">
    1
    </div>
  </div>
  <a href="#42372" class="name">
  <strong class="user"><em>nuno at mail dot ideianet dot pt</em></strong></a><a class="genanchor" href="#42372"> &para;</a><div class="date" title="2004-05-13 03:33"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom42372">
<div class="phpcode"><code><span class="html">
In Windows 2003 Server/IIS6 with the php4+ cgi I only get HTTP authentication working with:<br /><span class="default">&lt;?php header</span><span class="keyword">(</span><span class="string">"Status: 401 Access Denied"</span><span class="keyword">); </span><span class="default">?&gt;<br /></span>with<br /><span class="default">&lt;?php header</span><span class="keyword">(</span><span class="string">'HTTP/1.0 401 Unauthorized'</span><span class="keyword">); </span><span class="default">?&gt;<br /></span>doesn't work !<br />I also need in "Custom Errors" to select the range of "401;1" through "401;5" and click the "Set to Default" button.<br />Thanks rob at theblip dot com</span>
</code></div>
  </div>
 </div>
  <div class="note" id="38517">  <div class="votes">
    <div id="Vu38517">
    <a href="/manual/vote-note.php?id=38517&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd38517">
    <a href="/manual/vote-note.php?id=38517&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V38517" title="55% like this...">
    1
    </div>
  </div>
  <a href="#38517" class="name">
  <strong class="user"><em>ken_php_net at wolfpackinteractive dot com</em></strong></a><a class="genanchor" href="#38517"> &para;</a><div class="date" title="2003-12-25 01:16"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom38517">
<div class="phpcode"><code><span class="html">
Say you have password and groups files in standard Apache format (htpasswd etc.), but you want to apply authorization based on something other than filename, ie something you can't catch in .htaccess.&nbsp; You want to emulate the server behavior in PHP -- the equivalent of:<br /><br />AuthType Basic<br />AuthName "Members"<br />AuthUserFile /path/to/.htpasswd<br />AuthGroupFile /path/to/.groups<br />require group Members<br /><br />Here's what I came up with:<br /><br /><span class="default">&lt;?PHP<br /><br />$AuthUserFile </span><span class="keyword">= </span><span class="default">file</span><span class="keyword">(</span><span class="string">"/path/to/.htpasswd"</span><span class="keyword">);<br /></span><span class="default">$AuthGroupFile </span><span class="keyword">= </span><span class="default">file</span><span class="keyword">(</span><span class="string">"/path/to/.groups"</span><span class="keyword">);<br /></span><span class="default">$group </span><span class="keyword">= </span><span class="string">"Members"</span><span class="keyword">;<br /></span><span class="default">$realm </span><span class="keyword">= </span><span class="string">"Members"</span><span class="keyword">;<br /><br />function </span><span class="default">authenticate</span><span class="keyword">(){<br />&nbsp; &nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">"WWW-Authenticate: Basic realm=\"</span><span class="default">$realm</span><span class="string">\""</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">'HTTP/1.0 401 Unauthorized'</span><span class="keyword">);<br />&nbsp; &nbsp; echo </span><span class="string">"You must enter a valid user name and password to access the requested resource."</span><span class="keyword">;<br />&nbsp; &nbsp; exit;<br />}<br /><br />for(; </span><span class="default">1</span><span class="keyword">; </span><span class="default">authenticate</span><span class="keyword">()){<br />&nbsp; &nbsp; if (!isset(</span><span class="default">$HTTP_SERVER_VARS</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">]))<br />&nbsp; &nbsp; &nbsp; &nbsp; continue;<br /><br />&nbsp; &nbsp; </span><span class="default">$user </span><span class="keyword">= </span><span class="default">$HTTP_SERVER_VARS</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">];<br />&nbsp; &nbsp; if(!</span><span class="default">preg_grep</span><span class="keyword">(</span><span class="string">"/</span><span class="default">$group</span><span class="string">: </span><span class="default">$user</span><span class="string">$/"</span><span class="keyword">, </span><span class="default">$AuthGroupFile</span><span class="keyword">))&nbsp; </span><span class="comment"># (format assumptions)<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">continue;<br /><br />&nbsp; &nbsp; if(!(</span><span class="default">$authUserLine </span><span class="keyword">= </span><span class="default">array_shift</span><span class="keyword">(</span><span class="default">preg_grep</span><span class="keyword">(</span><span class="string">"/</span><span class="default">$user</span><span class="string">:.*$/"</span><span class="keyword">, </span><span class="default">$AuthUserFile</span><span class="keyword">))))<br />&nbsp; &nbsp; &nbsp; &nbsp; continue;<br /><br />&nbsp; &nbsp; </span><span class="default">preg_match</span><span class="keyword">(</span><span class="string">"/</span><span class="default">$user</span><span class="string">:((..).*)$/"</span><span class="keyword">, </span><span class="default">$authUserLine</span><span class="keyword">, </span><span class="default">$matches</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$authPW </span><span class="keyword">= </span><span class="default">$matches</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">];<br />&nbsp; &nbsp; </span><span class="default">$salt </span><span class="keyword">= </span><span class="default">$matches</span><span class="keyword">[</span><span class="default">2</span><span class="keyword">];<br />&nbsp; &nbsp; </span><span class="default">$submittedPW </span><span class="keyword">= </span><span class="default">crypt</span><span class="keyword">(</span><span class="default">$HTTP_SERVER_VARS</span><span class="keyword">[</span><span class="string">'PHP_AUTH_PW'</span><span class="keyword">], </span><span class="default">$salt</span><span class="keyword">);<br />&nbsp; &nbsp; if(</span><span class="default">$submittedPW </span><span class="keyword">!= </span><span class="default">$authPW</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; continue;<br /><br />&nbsp; &nbsp; break;<br />}<br /><br />echo </span><span class="string">"You got in!"<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="41941">  <div class="votes">
    <div id="Vu41941">
    <a href="/manual/vote-note.php?id=41941&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd41941">
    <a href="/manual/vote-note.php?id=41941&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V41941" title="54% like this...">
    1
    </div>
  </div>
  <a href="#41941" class="name">
  <strong class="user"><em>najprogramato at post dot sk</em></strong></a><a class="genanchor" href="#41941"> &para;</a><div class="date" title="2004-04-27 05:08"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom41941">
<div class="phpcode"><code><span class="html">
Don't use apache authentification in plain text. Is more better to use own script to generete new ID which is relevant to password. Apache auth data are sent to every page, so the posible mistake are known.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="110073">  <div class="votes">
    <div id="Vu110073">
    <a href="/manual/vote-note.php?id=110073&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd110073">
    <a href="/manual/vote-note.php?id=110073&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V110073" title="52% like this...">
    1
    </div>
  </div>
  <a href="#110073" class="name">
  <strong class="user"><em>avp200681 at gmail dot com</em></strong></a><a class="genanchor" href="#110073"> &para;</a><div class="date" title="2012-09-16 06:48"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom110073">
<div class="phpcode"><code><span class="html">
I noted that $_SERVER['AUTH_TYPE'] is only available for a page that was authenticated through a traditional external mechanism (like Apache).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="70305">  <div class="votes">
    <div id="Vu70305">
    <a href="/manual/vote-note.php?id=70305&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd70305">
    <a href="/manual/vote-note.php?id=70305&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V70305" title="53% like this...">
    1
    </div>
  </div>
  <a href="#70305" class="name">
  <strong class="user"><em>roychri at php dot net</em></strong></a><a class="genanchor" href="#70305"> &para;</a><div class="date" title="2006-10-10 08:12"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom70305">
<div class="phpcode"><code><span class="html">
For PHP with CGI, make sure you put the rewrite rule above any other rewrite rule you might have.<br /><br />In my case, I put this at the top of the .htaccess (below RewriteEngine On):<br />RewriteRule .* - [E=REMOTE_USER:%{HTTP:Authorization}]<br /><br />My symptom was that the REMOTE_USER (or REDIRECT_REMOTE_USER in my case) was not being set at all.<br />The cause: I had some other RewriteRule that was kickin in and was set as LAST rule.<br />I hope this helps.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="107642">  <div class="votes">
    <div id="Vu107642">
    <a href="/manual/vote-note.php?id=107642&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd107642">
    <a href="/manual/vote-note.php?id=107642&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V107642" title="52% like this...">
    1
    </div>
  </div>
  <a href="#107642" class="name">
  <strong class="user"><em>vog at notjusthosting dot com</em></strong></a><a class="genanchor" href="#107642"> &para;</a><div class="date" title="2012-02-23 11:54"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom107642">
<div class="phpcode"><code><span class="html">
You shouldn't use the "last" ("L") directive in the RewriteRule! This will prevent all further rewrite rules to be skipped whenever a Basic or Digest Auth is given, which is almost certainly not what you want.<br /><br />So the following lines are sufficient for the .htaccess (or httpd.conf) file:<br /><br />RewriteEngine On<br />RewriteRule .* - [E=HTTP_AUTHORIZATION:%{HTTP:Authorization}]</span>
</code></div>
  </div>
 </div>
  <div class="note" id="106285">  <div class="votes">
    <div id="Vu106285">
    <a href="/manual/vote-note.php?id=106285&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd106285">
    <a href="/manual/vote-note.php?id=106285&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V106285" title="52% like this...">
    1
    </div>
  </div>
  <a href="#106285" class="name">
  <strong class="user"><em>h3ndrik</em></strong></a><a class="genanchor" href="#106285"> &para;</a><div class="date" title="2011-10-24 05:32"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom106285">
<div class="phpcode"><code><span class="html">
On my configuration with php-cgi - after setting the RewriteRule - the correct variable would be: $_SERVER['REDIRECT_HTTP_AUTHORIZATION']<br /><br />So the workaround for PhpCGI is:<br />Set in your .htaccess:<br /><br />RewriteEngine on<br />RewriteRule .* - [env=HTTP_AUTHORIZATION:%{HTTP:Authorization},last]<br /><br />Php workaround:<br /><span class="default">&lt;?php<br /></span><span class="comment">//set http auth headers for apache+php-cgi work around<br /></span><span class="keyword">if (isset(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'HTTP_AUTHORIZATION'</span><span class="keyword">]) &amp;&amp; </span><span class="default">preg_match</span><span class="keyword">(</span><span class="string">'/Basic\s+(.*)$/i'</span><span class="keyword">, </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'HTTP_AUTHORIZATION'</span><span class="keyword">], </span><span class="default">$matches</span><span class="keyword">)) {<br />&nbsp; &nbsp; list(</span><span class="default">$name</span><span class="keyword">, </span><span class="default">$password</span><span class="keyword">) = </span><span class="default">explode</span><span class="keyword">(</span><span class="string">':'</span><span class="keyword">, </span><span class="default">base64_decode</span><span class="keyword">(</span><span class="default">$matches</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]));<br />&nbsp; &nbsp; </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">] = </span><span class="default">strip_tags</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_PW'</span><span class="keyword">] = </span><span class="default">strip_tags</span><span class="keyword">(</span><span class="default">$password</span><span class="keyword">);<br />}<br /><br /></span><span class="comment">//set http auth headers for apache+php-cgi work around if variable gets renamed by apache<br /></span><span class="keyword">if (isset(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'REDIRECT_HTTP_AUTHORIZATION'</span><span class="keyword">]) &amp;&amp; </span><span class="default">preg_match</span><span class="keyword">(</span><span class="string">'/Basic\s+(.*)$/i'</span><span class="keyword">, </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'REDIRECT_HTTP_AUTHORIZATION'</span><span class="keyword">], </span><span class="default">$matches</span><span class="keyword">)) {<br />&nbsp; &nbsp; list(</span><span class="default">$name</span><span class="keyword">, </span><span class="default">$password</span><span class="keyword">) = </span><span class="default">explode</span><span class="keyword">(</span><span class="string">':'</span><span class="keyword">, </span><span class="default">base64_decode</span><span class="keyword">(</span><span class="default">$matches</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]));<br />&nbsp; &nbsp; </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">] = </span><span class="default">strip_tags</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_PW'</span><span class="keyword">] = </span><span class="default">strip_tags</span><span class="keyword">(</span><span class="default">$password</span><span class="keyword">);<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="87685">  <div class="votes">
    <div id="Vu87685">
    <a href="/manual/vote-note.php?id=87685&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd87685">
    <a href="/manual/vote-note.php?id=87685&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V87685" title="52% like this...">
    1
    </div>
  </div>
  <a href="#87685" class="name">
  <strong class="user"><em>byoung at bigbluehat dot com</em></strong></a><a class="genanchor" href="#87685"> &para;</a><div class="date" title="2008-12-16 12:02"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom87685">
<div class="phpcode"><code><span class="html">
The sample from danja at k0a1a dot net is great for getting started. However, it has some typos. Below is a slightly revised version that should work "out of the box":<br /><br /><span class="default">&lt;?php<br />session_start</span><span class="keyword">();<br /><br /></span><span class="default">$authorized </span><span class="keyword">= </span><span class="default">false</span><span class="keyword">;<br /><br />if(isset(</span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">'logout'</span><span class="keyword">]) &amp;&amp; (</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'auth'</span><span class="keyword">])) {<br />&nbsp; &nbsp; </span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'auth'</span><span class="keyword">] = </span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">session_destroy</span><span class="keyword">();<br />&nbsp; &nbsp; echo </span><span class="string">"logging out..."</span><span class="keyword">;<br />}<br /><br />if(isset(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">]) &amp;&amp; isset(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_PW'</span><span class="keyword">])) {<br />&nbsp; &nbsp; </span><span class="default">$user </span><span class="keyword">= </span><span class="string">'test'</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$pass </span><span class="keyword">= </span><span class="string">'test'</span><span class="keyword">;<br />&nbsp; &nbsp; if ((</span><span class="default">$user </span><span class="keyword">== </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">]) &amp;&amp; (</span><span class="default">$pass </span><span class="keyword">== (</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_PW'</span><span class="keyword">])) &amp;&amp; (!empty(</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'auth'</span><span class="keyword">]))) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$authorized </span><span class="keyword">= </span><span class="default">true</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />if (isset(</span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">"login"</span><span class="keyword">]) &amp;&amp; (! </span><span class="default">$authorized</span><span class="keyword">)) {<br />&nbsp; &nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">'WWW-Authenticate: Basic Realm="Login please"'</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">'HTTP/1.0 401 Unauthorized'</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'auth'</span><span class="keyword">] = </span><span class="default">true</span><span class="keyword">;<br />&nbsp; &nbsp; print(</span><span class="string">'Login now or forever hold your clicks...'</span><span class="keyword">);<br />&nbsp; &nbsp; exit;<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />&lt;h1&gt;you have &lt;? echo ($authorized) ? '' : 'not'; ?&gt; logged!&lt;/h1&gt;</span>
</code></div>
  </div>
 </div>
  <div class="note" id="99348">  <div class="votes">
    <div id="Vu99348">
    <a href="/manual/vote-note.php?id=99348&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd99348">
    <a href="/manual/vote-note.php?id=99348&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V99348" title="51% like this...">
    1
    </div>
  </div>
  <a href="#99348" class="name">
  <strong class="user"><em>idbobby at rambler dot ru</em></strong></a><a class="genanchor" href="#99348"> &para;</a><div class="date" title="2010-08-12 02:31"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom99348">
<div class="phpcode"><code><span class="html">
First of all, sorry for my English.<br />One more authorization script with logout solution.<br />In script given by meint_at_meint_dot_net (<a href="http://www.php.net/manual/en/features.http-auth.php#93859" rel="nofollow" target="_blank">http://www.php.net/manual/en/features.http-auth.php#93859</a>) rewrite_module is used. If there are any problems with that module and possibilities of administration of the web-server are restricted (including restrictions for use of .htaccess) then you can use this solution.<br /><br />index.php<br />---------<br /><br /><span class="default">&lt;?php<br /><br />$auth_realm </span><span class="keyword">= </span><span class="string">'My realm'</span><span class="keyword">;<br /><br />require_once </span><span class="string">'auth.php'</span><span class="keyword">;<br /><br />echo </span><span class="string">"You've logged in as </span><span class="keyword">{</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'username'</span><span class="keyword">]}</span><span class="string">&lt;br&gt;"</span><span class="keyword">;<br />echo </span><span class="string">'&lt;p&gt;&lt;a href="?action=logOut"&gt;LogOut&lt;/a&gt;&lt;/p&gt;'<br /><br /></span><span class="default">?&gt;<br /></span><br />auth.php<br />--------<br /><br /><span class="default">&lt;?php<br /><br />$_user_ </span><span class="keyword">= </span><span class="string">'test'</span><span class="keyword">;<br /></span><span class="default">$_password_ </span><span class="keyword">= </span><span class="string">'test'</span><span class="keyword">;<br /><br /></span><span class="default">session_start</span><span class="keyword">();<br /><br /></span><span class="default">$url_action </span><span class="keyword">= (empty(</span><span class="default">$_REQUEST</span><span class="keyword">[</span><span class="string">'action'</span><span class="keyword">])) ? </span><span class="string">'logIn' </span><span class="keyword">: </span><span class="default">$_REQUEST</span><span class="keyword">[</span><span class="string">'action'</span><span class="keyword">];<br /></span><span class="default">$auth_realm </span><span class="keyword">= (isset(</span><span class="default">$auth_realm</span><span class="keyword">)) ? </span><span class="default">$auth_realm </span><span class="keyword">: </span><span class="string">''</span><span class="keyword">;<br /><br />if (isset(</span><span class="default">$url_action</span><span class="keyword">)) {<br />&nbsp; &nbsp; if (</span><span class="default">is_callable</span><span class="keyword">(</span><span class="default">$url_action</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">call_user_func</span><span class="keyword">(</span><span class="default">$url_action</span><span class="keyword">);<br />&nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'Function does not exist, request terminated'</span><span class="keyword">;<br />&nbsp; &nbsp; };<br />};<br /><br />function </span><span class="default">logIn</span><span class="keyword">() {<br />&nbsp; &nbsp; global </span><span class="default">$auth_realm</span><span class="keyword">;<br /><br />&nbsp; &nbsp; if (!isset(</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'username'</span><span class="keyword">])) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (!isset(</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'login'</span><span class="keyword">])) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'login'</span><span class="keyword">] = </span><span class="default">TRUE</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">'WWW-Authenticate: Basic realm="'</span><span class="keyword">.</span><span class="default">$auth_realm</span><span class="keyword">.</span><span class="string">'"'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">'HTTP/1.0 401 Unauthorized'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'You must enter a valid login and password'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'&lt;p&gt;&lt;a href="?action=logOut"&gt;Try again&lt;/a&gt;&lt;/p&gt;'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; exit;<br />&nbsp; &nbsp; &nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$user </span><span class="keyword">= isset(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">]) ? </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">] : </span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$password </span><span class="keyword">= isset(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_PW'</span><span class="keyword">]) ? </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_PW'</span><span class="keyword">] : </span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$result </span><span class="keyword">= </span><span class="default">authenticate</span><span class="keyword">(</span><span class="default">$user</span><span class="keyword">, </span><span class="default">$password</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$result </span><span class="keyword">== </span><span class="default">0</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'username'</span><span class="keyword">] = </span><span class="default">$user</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">session_unset</span><span class="keyword">(</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'login'</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">errMes</span><span class="keyword">(</span><span class="default">$result</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'&lt;p&gt;&lt;a href=""&gt;Try again&lt;/a&gt;&lt;/p&gt;'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; exit;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; };<br />&nbsp; &nbsp; &nbsp; &nbsp; };<br />&nbsp; &nbsp; };<br />}<br /><br />function </span><span class="default">authenticate</span><span class="keyword">(</span><span class="default">$user</span><span class="keyword">, </span><span class="default">$password</span><span class="keyword">) {<br />&nbsp; &nbsp; global </span><span class="default">$_user_</span><span class="keyword">;<br />&nbsp; &nbsp; global </span><span class="default">$_password_</span><span class="keyword">;<br /><br />&nbsp; &nbsp; if ((</span><span class="default">$user </span><span class="keyword">== </span><span class="default">$_user_</span><span class="keyword">)&amp;&amp;(</span><span class="default">$password </span><span class="keyword">== </span><span class="default">$_password_</span><span class="keyword">)) { return </span><span class="default">0</span><span class="keyword">; }<br />&nbsp; &nbsp; else { return </span><span class="default">1</span><span class="keyword">; };<br />}<br /><br />function </span><span class="default">errMes</span><span class="keyword">(</span><span class="default">$errno</span><span class="keyword">) {<br />&nbsp; &nbsp; switch (</span><span class="default">$errno</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">0</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">1</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'The username or password you entered is incorrect'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; default:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'Unknown error'</span><span class="keyword">;<br />&nbsp; &nbsp; };<br />}<br /><br />function </span><span class="default">logOut</span><span class="keyword">() {<br /><br />&nbsp; &nbsp; </span><span class="default">session_destroy</span><span class="keyword">();<br />&nbsp; &nbsp; if (isset(</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'username'</span><span class="keyword">])) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">session_unset</span><span class="keyword">(</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'username'</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"You've successfully logged out&lt;br&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'&lt;p&gt;&lt;a href="?action=logIn"&gt;LogIn&lt;/a&gt;&lt;/p&gt;'</span><span class="keyword">;<br />&nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">"Location: ?action=logIn"</span><span class="keyword">, </span><span class="default">TRUE</span><span class="keyword">, </span><span class="default">301</span><span class="keyword">);<br />&nbsp; &nbsp; };<br />&nbsp; &nbsp; if (isset(</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'login'</span><span class="keyword">])) { </span><span class="default">session_unset</span><span class="keyword">(</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'login'</span><span class="keyword">]); };<br />&nbsp; &nbsp; exit;<br />}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121898">  <div class="votes">
    <div id="Vu121898">
    <a href="/manual/vote-note.php?id=121898&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121898">
    <a href="/manual/vote-note.php?id=121898&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121898" title="no votes...">
    0
    </div>
  </div>
  <a href="#121898" class="name">
  <strong class="user"><em>Carlos</em></strong></a><a class="genanchor" href="#121898"> &para;</a><div class="date" title="2017-11-22 10:44"><strong>22 days ago</strong></div>
  <div class="text" id="Hcom121898">
<div class="phpcode"><code><span class="html">
Simpler WorkAround for missing Authorization header under CGI/FastCGI available in Apache HTTP Server 2.4.13 and later<br /><br />&nbsp; &nbsp;&nbsp; CGIPassAuth On<br /><br />Please don't enable Authorization header with Basic Authentication, is very insecure.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116845">  <div class="votes">
    <div id="Vu116845">
    <a href="/manual/vote-note.php?id=116845&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116845">
    <a href="/manual/vote-note.php?id=116845&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116845" title="50% like this...">
    0
    </div>
  </div>
  <a href="#116845" class="name">
  <strong class="user"><em>johng121 at gmail dot com</em></strong></a><a class="genanchor" href="#116845"> &para;</a><div class="date" title="2015-03-10 12:57"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom116845">
<div class="phpcode"><code><span class="html">
I came up with another approach to work around the problem of browsers caching WWW authentication credentials and creating logout problems. While most browsers have some kind of way to wipe this information, I prefer having my website to take care of the task instead of relying on the user's sanity.<br /><br />Even with Lalit's method of creating a random realm name, it was still possible to get back into the protected area using the back button in Firefox, so that didn't work. Here's my solution:<br /><br />Since browsers attach the credentials to specific URLs, use virtual paths where a component of the path is actually a PHP script, and everything following it is part of the URI, such as:<br /><br /><a href="http://calgaryabwedding.photography/some_dir/login.php/auth/8f631b92/" rel="nofollow" target="_blank">http://calgaryabwedding.photography/some_dir/login.php/auth/8f631b92/</a><br /><br />By choosing a different number for the last component of the URL, browsers can be tricked into thinking that they are dealing with a completely different website, and thus prompting the user for credentials again.<br /><br />Note that using a random, unrestricted number will still allow the user to hit the back button to get back into the page. You should keep track of this number in a server-side file or database and regenerate it upon each successful login, so that the last number(s) become invalid. Using an invalid number might result in a 403 response or, depending on how you feel that day, a 302 to a nasty website.<br /><br />Care should be taken when linking from the page generated in this case, since relative links will be relative to the virtual and non-existant directory rather than the true script directory.<br /><br />Hope this helps somebody.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="105379">  <div class="votes">
    <div id="Vu105379">
    <a href="/manual/vote-note.php?id=105379&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd105379">
    <a href="/manual/vote-note.php?id=105379&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V105379" title="50% like this...">
    0
    </div>
  </div>
  <a href="#105379" class="name">
  <strong class="user"><em>luismontreal at gmail dot com</em></strong></a><a class="genanchor" href="#105379"> &para;</a><div class="date" title="2011-08-12 02:10"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom105379">
<div class="phpcode"><code><span class="html">
Using sessions like this makes the enter auth values at each request<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">if(</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'http_logged'</span><span class="keyword">] != </span><span class="default">1</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">] = </span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_PW'</span><span class="keyword">] = </span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; if (</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">] != </span><span class="default">$your_username </span><span class="keyword">|| </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_PW'</span><span class="keyword">] != </span><span class="default">$your_password </span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'http_logged'</span><span class="keyword">] = </span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">'WWW-Authenticate: Basic realm="realm"'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">'HTTP/1.0 401 Unauthorized'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; exit;<br />&nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'http_logged'</span><span class="keyword">] = </span><span class="default">0</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="93376">  <div class="votes">
    <div id="Vu93376">
    <a href="/manual/vote-note.php?id=93376&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd93376">
    <a href="/manual/vote-note.php?id=93376&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V93376" title="50% like this...">
    0
    </div>
  </div>
  <a href="#93376" class="name">
  <strong class="user"><em>s dot i dot g at gmx dot com</em></strong></a><a class="genanchor" href="#93376"> &para;</a><div class="date" title="2009-09-06 12:34"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom93376">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br /><br /></span><span class="comment">// try to mimic cpanel logout style<br />// only diff is usr &amp; pwd field is cleared when re-login<br />// tested with ff2 &amp; ie8<br /><br /></span><span class="default">session_start</span><span class="keyword">();<br /><br /></span><span class="default">$username </span><span class="keyword">= </span><span class="string">"test"</span><span class="keyword">;<br /></span><span class="default">$password </span><span class="keyword">= </span><span class="string">"test"</span><span class="keyword">;<br /><br />if(isset(</span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">'logout'</span><span class="keyword">]))<br />{<br />&nbsp; unset(</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">"login"</span><span class="keyword">]);<br />&nbsp; echo </span><span class="string">"You have logout ... "</span><span class="keyword">;<br />&nbsp; echo </span><span class="string">"[&lt;a href='" </span><span class="keyword">. </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_SELF'</span><span class="keyword">] . </span><span class="string">"'&gt;Login&lt;/a&gt;]"</span><span class="keyword">;<br />&nbsp; exit;<br />}<br /><br />if (!isset(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">]) || !isset(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_PW'</span><span class="keyword">]) || !isset(</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">"login"</span><span class="keyword">]))<br />{<br />&nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">"WWW-Authenticate: Basic realm=\"Test\""</span><span class="keyword">);<br />&nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">"HTTP/1.0 401 Unauthorized"</span><span class="keyword">);<br />&nbsp; </span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">"login"</span><span class="keyword">] = </span><span class="default">true</span><span class="keyword">;<br />&nbsp; echo </span><span class="string">"You are unauthorized ... "</span><span class="keyword">;<br />&nbsp; echo </span><span class="string">"[&lt;a href='" </span><span class="keyword">. </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_SELF'</span><span class="keyword">] . </span><span class="string">"'&gt;Login&lt;/a&gt;]"</span><span class="keyword">;<br />&nbsp; exit;<br />}<br />else<br />{<br />&nbsp; if(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">] == </span><span class="default">$username </span><span class="keyword">&amp;&amp; </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_PW'</span><span class="keyword">] == </span><span class="default">$password</span><span class="keyword">)<br />&nbsp; {<br />&nbsp; &nbsp; echo </span><span class="string">"You have logged in ... "</span><span class="keyword">;<br />&nbsp; &nbsp; echo </span><span class="string">"[&lt;a href='" </span><span class="keyword">. </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_SELF'</span><span class="keyword">] . </span><span class="string">"?logout'&gt;Logout&lt;/a&gt;]"</span><span class="keyword">;<br />&nbsp; }<br />&nbsp; else<br />&nbsp; {<br />&nbsp; &nbsp; unset(</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">"login"</span><span class="keyword">]);<br />&nbsp; &nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">"Location: " </span><span class="keyword">. </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_SELF'</span><span class="keyword">]);<br />&nbsp; }<br />}<br /><br /></span><span class="comment">// content here<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="72020">  <div class="votes">
    <div id="Vu72020">
    <a href="/manual/vote-note.php?id=72020&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd72020">
    <a href="/manual/vote-note.php?id=72020&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V72020" title="50% like this...">
    0
    </div>
  </div>
  <a href="#72020" class="name">
  <strong class="user"><em>bleuciell at aol dot com</em></strong></a><a class="genanchor" href="#72020"> &para;</a><div class="date" title="2006-12-29 12:51"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom72020">
<div class="phpcode"><code><span class="html">
For admin , i repair a fault , all is good now<br />Sorry for my english <br /><br />It's a piece of code , to give a piece of reflexion about simple auth , we can also cryp login and pass in db , time is here for non-replay , the code isn't finish , but it work , only for reflexion about auth mechanism<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">ky</span><span class="keyword">( </span><span class="default">$txt</span><span class="keyword">,</span><span class="default">$crypt</span><span class="keyword">) { </span><span class="default">$key </span><span class="keyword">= </span><span class="default">md5</span><span class="keyword">(</span><span class="default">$crypt</span><span class="keyword">); </span><span class="default">$cpt </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">; </span><span class="default">$var </span><span class="keyword">= </span><span class="string">""</span><span class="keyword">;<br />for ( </span><span class="default">$Ctr </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">; </span><span class="default">$Ctr </span><span class="keyword">&lt; </span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$txt</span><span class="keyword">); </span><span class="default">$Ctr</span><span class="keyword">++) { if (</span><span class="default">$cpt </span><span class="keyword">== </span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$crypt</span><span class="keyword">)) </span><span class="default">$cpt </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br /></span><span class="default">$var</span><span class="keyword">.= </span><span class="default">substr</span><span class="keyword">(</span><span class="default">$txt</span><span class="keyword">,</span><span class="default">$Ctr</span><span class="keyword">,</span><span class="default">1</span><span class="keyword">) ^ </span><span class="default">substr</span><span class="keyword">(</span><span class="default">$crypt</span><span class="keyword">,</span><span class="default">$cpt</span><span class="keyword">,</span><span class="default">1</span><span class="keyword">); </span><span class="default">$cpt</span><span class="keyword">++; } return </span><span class="default">$var</span><span class="keyword">; }<br /><br /></span><span class="default">$key </span><span class="keyword">= </span><span class="string">""</span><span class="keyword">;</span><span class="default">$list </span><span class="keyword">= </span><span class="string">'abcdefghijklmnopqrstuvwxyz0123456789'</span><span class="keyword">;<br />for(</span><span class="default">$i </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">&lt; </span><span class="default">200</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">++) {&nbsp; </span><span class="default">$key </span><span class="keyword">.= </span><span class="default">$list</span><span class="keyword">{</span><span class="default">mt_rand</span><span class="keyword">() % </span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$list</span><span class="keyword">)}; }<br /><br />function </span><span class="default">cryp</span><span class="keyword">(</span><span class="default">$txt</span><span class="keyword">,</span><span class="default">$key</span><span class="keyword">){ </span><span class="default">srand</span><span class="keyword">((double)</span><span class="default">microtime</span><span class="keyword">()*</span><span class="default">735412</span><span class="keyword">);&nbsp; </span><span class="default">$crypt </span><span class="keyword">= </span><span class="default">crypt</span><span class="keyword">(</span><span class="default">rand</span><span class="keyword">(</span><span class="default">0</span><span class="keyword">,</span><span class="default">3895234</span><span class="keyword">));</span><span class="default">$cpt </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;</span><span class="default">$var</span><span class="keyword">= </span><span class="string">""</span><span class="keyword">;<br />for ( </span><span class="default">$Ctr</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">; </span><span class="default">$Ctr </span><span class="keyword">&lt; </span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$txt</span><span class="keyword">); </span><span class="default">$Ctr</span><span class="keyword">++ ) { if (</span><span class="default">$cpt </span><span class="keyword">== </span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$crypt</span><span class="keyword">))</span><span class="default">$cpt </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br /></span><span class="default">$var</span><span class="keyword">.= </span><span class="default">substr</span><span class="keyword">(</span><span class="default">$crypt</span><span class="keyword">,</span><span class="default">$cpt</span><span class="keyword">,</span><span class="default">1</span><span class="keyword">).( </span><span class="default">substr</span><span class="keyword">(</span><span class="default">$txt</span><span class="keyword">,</span><span class="default">$Ctr</span><span class="keyword">,</span><span class="default">1</span><span class="keyword">) ^ </span><span class="default">substr</span><span class="keyword">(</span><span class="default">$crypt</span><span class="keyword">,</span><span class="default">$cpt</span><span class="keyword">,</span><span class="default">1</span><span class="keyword">) ); </span><span class="default">$cpt</span><span class="keyword">++; } return </span><span class="default">base64_encode</span><span class="keyword">(</span><span class="default">ky</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">,</span><span class="default">$key</span><span class="keyword">) ); }<br /><br />function </span><span class="default">dcryp</span><span class="keyword">(</span><span class="default">$txt</span><span class="keyword">,</span><span class="default">$key</span><span class="keyword">){ </span><span class="default">$txt</span><span class="keyword">=</span><span class="default">ky</span><span class="keyword">(</span><span class="default">base64_decode</span><span class="keyword">(</span><span class="default">$txt</span><span class="keyword">),</span><span class="default">$key</span><span class="keyword">);</span><span class="default">$var</span><span class="keyword">= </span><span class="string">""</span><span class="keyword">;<br />for ( </span><span class="default">$Ctr </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">; </span><span class="default">$Ctr </span><span class="keyword">&lt; </span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$txt</span><span class="keyword">); </span><span class="default">$Ctr</span><span class="keyword">++ ) { </span><span class="default">$md5 </span><span class="keyword">= </span><span class="default">substr</span><span class="keyword">(</span><span class="default">$txt</span><span class="keyword">,</span><span class="default">$Ctr</span><span class="keyword">,</span><span class="default">1</span><span class="keyword">);</span><span class="default">$Ctr</span><span class="keyword">++; </span><span class="default">$var</span><span class="keyword">.= (</span><span class="default">substr</span><span class="keyword">(</span><span class="default">$txt</span><span class="keyword">,</span><span class="default">$Ctr</span><span class="keyword">,</span><span class="default">1</span><span class="keyword">) ^ </span><span class="default">$md5</span><span class="keyword">); }return </span><span class="default">$var</span><span class="keyword">;}<br /><br /></span><span class="default">$time</span><span class="keyword">= </span><span class="default">time</span><span class="keyword">(); </span><span class="default">$user </span><span class="keyword">= </span><span class="default">cryp</span><span class="keyword">(</span><span class="string">'bubu'</span><span class="keyword">,</span><span class="default">$key</span><span class="keyword">); </span><span class="default">$pwd </span><span class="keyword">= </span><span class="default">cryp</span><span class="keyword">(</span><span class="string">'bubu-'</span><span class="keyword">.</span><span class="default">$time</span><span class="keyword">.</span><span class="string">''</span><span class="keyword">,</span><span class="default">$key</span><span class="keyword">);<br /><br />function </span><span class="default">pwd</span><span class="keyword">(</span><span class="default">$j</span><span class="keyword">,</span><span class="default">$key</span><span class="keyword">){ </span><span class="default">$x </span><span class="keyword">= </span><span class="default">dcryp</span><span class="keyword">(</span><span class="default">$j</span><span class="keyword">,</span><span class="default">$key</span><span class="keyword">); </span><span class="default">$x </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">(</span><span class="string">'-'</span><span class="keyword">,</span><span class="default">$x</span><span class="keyword">); return </span><span class="default">$x</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">];}<br />function </span><span class="default">pwd2</span><span class="keyword">(</span><span class="default">$j</span><span class="keyword">,</span><span class="default">$key</span><span class="keyword">){ </span><span class="default">$x </span><span class="keyword">= </span><span class="default">dcryp</span><span class="keyword">(</span><span class="default">$j</span><span class="keyword">,</span><span class="default">$key</span><span class="keyword">); </span><span class="default">$x </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">(</span><span class="string">'-'</span><span class="keyword">,</span><span class="default">$x</span><span class="keyword">); return </span><span class="default">$x</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">];}<br /><br />function </span><span class="default">auth</span><span class="keyword">(){</span><span class="default">$realm</span><span class="keyword">=</span><span class="string">"Authentification PHPindex"</span><span class="keyword">;<br /></span><span class="default">Header</span><span class="keyword">(</span><span class="string">"WWW-Authenticate: Basic realm='"</span><span class="keyword">.</span><span class="default">$realm</span><span class="keyword">.</span><span class="string">"'"</span><span class="keyword">);</span><span class="default">Header</span><span class="keyword">(</span><span class="string">"HTTP/1.0&nbsp; 401&nbsp; Unauthorized"</span><span class="keyword">);<br />echo </span><span class="string">"Vous ne pouvez accéder à cette page"</span><span class="keyword">; }<br /><br />if( !isset(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">]) &amp;&amp; !isset(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_PW'</span><span class="keyword">]) ) {</span><span class="default">auth</span><span class="keyword">();<br />} else {<br />if( </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">] == </span><span class="default">dcryp</span><span class="keyword">(</span><span class="default">$user</span><span class="keyword">,</span><span class="default">$key</span><span class="keyword">) &amp;&amp; </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_PW'</span><span class="keyword">] == </span><span class="default">pwd</span><span class="keyword">(</span><span class="default">$pwd</span><span class="keyword">,</span><span class="default">$key</span><span class="keyword">) &amp;&amp; </span><span class="default">$time </span><span class="keyword">== </span><span class="default">pwd2</span><span class="keyword">(</span><span class="default">$pwd</span><span class="keyword">,</span><span class="default">$key</span><span class="keyword">)) {<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">''</span><span class="keyword">;<br /><br />} else{ </span><span class="default">auth</span><span class="keyword">();}}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="56134">  <div class="votes">
    <div id="Vu56134">
    <a href="/manual/vote-note.php?id=56134&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd56134">
    <a href="/manual/vote-note.php?id=56134&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V56134" title="50% like this...">
    0
    </div>
  </div>
  <a href="#56134" class="name">
  <strong class="user"><em>siberion at hotmail dot com</em></strong></a><a class="genanchor" href="#56134"> &para;</a><div class="date" title="2005-08-24 09:11"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom56134">
<div class="phpcode"><code><span class="html">
I came up with another approach to work around the problem of browsers caching WWW authentication credentials and creating logout problems. While most browsers have some kind of way to wipe this information, I prefer having my website to take care of the task instead of relying on the user's sanity.<br /><br />Even with Lalit's method of creating a random realm name, it was still possible to get back into the protected area using the back button in Firefox, so that didn't work. Here's my solution:<br /><br />Since browsers attach the credentials to specific URLs, use virtual paths where a component of the path is actually a PHP script, and everything following it is part of the URI, such as:<br /><br /><a href="http://www.example.com/some_dir/login.php/auth/8f631b92/" rel="nofollow" target="_blank">http://www.example.com/some_dir/login.php/auth/8f631b92/</a><br /><br />By choosing a different number for the last component of the URL, browsers can be tricked into thinking that they are dealing with a completely different website, and thus prompting the user for credentials again.<br /><br />Note that using a random, unrestricted number will still allow the user to hit the back button to get back into the page. You should keep track of this number in a server-side file or database and regenerate it upon each successful login, so that the last number(s) become invalid. Using an invalid number might result in a 403 response or, depending on how you feel that day, a 302 to a nasty website.<br /><br />Care should be taken when linking from the page generated in this case, since relative links will be relative to the virtual and non-existant directory rather than the true script directory.<br /><br />Hope this helps somebody.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="54330">  <div class="votes">
    <div id="Vu54330">
    <a href="/manual/vote-note.php?id=54330&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd54330">
    <a href="/manual/vote-note.php?id=54330&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V54330" title="50% like this...">
    0
    </div>
  </div>
  <a href="#54330" class="name">
  <strong class="user"><em>me at lalit dot org</em></strong></a><a class="genanchor" href="#54330"> &para;</a><div class="date" title="2005-06-30 08:27"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom54330">
<div class="phpcode"><code><span class="html">
A very simple HTTP Authentication script that solves the logout problem. I wasted a lot of time figuring out a way to logout. This one works perfectly fine.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">auth_user</span><span class="keyword">() {<br />&nbsp; &nbsp; </span><span class="default">$realm </span><span class="keyword">= </span><span class="default">mt_rand</span><span class="keyword">( </span><span class="default">1</span><span class="keyword">, </span><span class="default">1000000000 </span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">'WWW-Authenticate: Basic realm="Realm ID='</span><span class="keyword">.</span><span class="default">$realm</span><span class="keyword">.</span><span class="string">']"'</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">'HTTP/1.0 401 Unauthorized'</span><span class="keyword">);<br />&nbsp; &nbsp; die(</span><span class="string">"Unauthorized access forbidden!"</span><span class="keyword">);<br />}<br /><br />if (!isset(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">])) {<br />&nbsp; &nbsp; </span><span class="default">auth_user</span><span class="keyword">();<br />} else if (!isset(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">])) {<br />&nbsp; &nbsp; </span><span class="default">auth_user</span><span class="keyword">();<br />} else if (</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">] != </span><span class="default">$auser </span><span class="keyword">|| </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_PW'</span><span class="keyword">] != </span><span class="default">$apass</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">auth_user</span><span class="keyword">();<br />} else if (isset(</span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">'action'</span><span class="keyword">]) &amp;&amp; </span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">'action'</span><span class="keyword">] == </span><span class="string">"logout"</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">auth_user</span><span class="keyword">();<br />}<br /><br /></span><span class="comment">// Normal Page Code Here<br /></span><span class="default">?&gt;<br /></span><br />Hope this helps,<br />Lalit</span>
</code></div>
  </div>
 </div>
  <div class="note" id="43322">  <div class="votes">
    <div id="Vu43322">
    <a href="/manual/vote-note.php?id=43322&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd43322">
    <a href="/manual/vote-note.php?id=43322&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V43322" title="50% like this...">
    0
    </div>
  </div>
  <a href="#43322" class="name">
  <strong class="user"><em>chris at schaake dot nu</em></strong></a><a class="genanchor" href="#43322"> &para;</a><div class="date" title="2004-06-17 09:42"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom43322">
<div class="phpcode"><code><span class="html">
A simple script for SSL Client Certificate authentication with a basic authentication fall-back. I use this on my site using LDAP server to check username/passwords and client certificate to user mapping.<br /><br />&lt;? <br />// Check if and how we are authenticated<br />if ($_SERVER['SSL_CLIENT_VERIFY'] != "SUCCESS") { // Not using a client certificate<br />&nbsp; &nbsp; if ((!$_SERVER['PHP_AUTH_USER']) &amp;&amp; (!$_SERVER['PHP_AUTH_PW'])) { // Not logged in using basic authentication<br />&nbsp; &nbsp; &nbsp; &nbsp; authenticate(); // Send basic authentication headers<br />&nbsp; &nbsp; }<br />}<br /><br />if ($_SERVER['SSL_CLIENT_S_DN_CN'] != "chris") { // Check CN name of cert<br /><br />&nbsp; &nbsp; if (!(($_SERVER['PHP_AUTH_USER'] == "test") &amp;&amp; ($_SERVER['PHP_AUTH_PW'] == "123"))) { // Check username and password<br />&nbsp; &nbsp; &nbsp; &nbsp; authenticate(); // Send basic authentication headers because username and/or password didnot match<br />&nbsp; &nbsp; } <br />} <br /><br />phpinfo();<br /><br />// Call authentication display<br />function authenticate() {<br />&nbsp; &nbsp; Header("WWW-Authenticate: Basic realm=Website");<br />&nbsp; &nbsp; &nbsp; &nbsp; Header("HTTP/1.0 401 Unauthorized");<br />&nbsp; &nbsp; &nbsp; &nbsp; error401();<br />&nbsp; &nbsp; &nbsp; &nbsp; exit;<br />}<br />?&gt;<br /><br />See my website (<a href="http://www.schaake.nu/index.php?page=/manuals/sslmanual.xml" rel="nofollow" target="_blank">http://www.schaake.nu/index.php?page=/manuals/sslmanual.xml</a>) for more details on client certificate with Apache and PHP.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="57922">  <div class="votes">
    <div id="Vu57922">
    <a href="/manual/vote-note.php?id=57922&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd57922">
    <a href="/manual/vote-note.php?id=57922&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V57922" title="47% like this...">
    -1
    </div>
  </div>
  <a href="#57922" class="name">
  <strong class="user"><em>oaev at mail dot ru</em></strong></a><a class="genanchor" href="#57922"> &para;</a><div class="date" title="2005-10-19 01:26"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom57922">
<div class="phpcode"><code><span class="html">
Once more time about PHP through CGI.<br /><br />Sometimes by some reasons (settings) web-server does not allow to set any environment variables through .htaccess file, so method offered by bernard dot paques at bigfoot dot com will not work.<br /><br />Another way to solve this is to set some GET variable:<br /><br />file .htaccess (it's just my example, maybe you can find better way):<br /><br />&lt;IfModule mod_rewrite.c&gt;<br />&nbsp;&nbsp; RewriteEngine on<br />&nbsp;&nbsp; <br />&nbsp;&nbsp; RewriteCond %{QUERY_STRING} ^$<br />&nbsp;&nbsp; RewriteRule ([^\s]+).php$ $1.php?BAD_HOSTING=%{HTTP:Authorization}<br />&nbsp;&nbsp; <br />&nbsp;&nbsp; RewriteCond %{QUERY_STRING} ^(.+)$<br />&nbsp;&nbsp; RewriteRule ([^\s]+).php $1.php?%1&amp;BAD_HOSTING=%{HTTP:Authorization}<br />&lt;/IfModule&gt;<br /><br />a part of php file:<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">if((empty(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">]) or empty(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_PW'</span><span class="keyword">])) and isset(</span><span class="default">$_REQUEST</span><span class="keyword">[</span><span class="string">'BAD_HOSTING'</span><span class="keyword">]) and </span><span class="default">preg_match</span><span class="keyword">(</span><span class="string">'/Basic\s+(.*)$/i'</span><span class="keyword">, </span><span class="default">$_REQUEST</span><span class="keyword">[</span><span class="string">'BAD_HOSTING'</span><span class="keyword">], </span><span class="default">$matc</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; list(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">], </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_PW'</span><span class="keyword">]) = </span><span class="default">explode</span><span class="keyword">(</span><span class="string">':'</span><span class="keyword">, </span><span class="default">base64_decode</span><span class="keyword">(</span><span class="default">$matc</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]));<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="66920">  <div class="votes">
    <div id="Vu66920">
    <a href="/manual/vote-note.php?id=66920&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd66920">
    <a href="/manual/vote-note.php?id=66920&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V66920" title="47% like this...">
    -1
    </div>
  </div>
  <a href="#66920" class="name">
  <strong class="user"><em>henrik at laurells dot net</em></strong></a><a class="genanchor" href="#66920"> &para;</a><div class="date" title="2006-05-31 11:36"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom66920">
<div class="phpcode"><code><span class="html">
Above top example for digest mode dosn't work if you have safemode on. You need to add a dash and UID to the compare string to make it work. Something like this;;<br /><br />$A1 = md5($data['username'].':'. <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $realm.'-'.getmyuid().':'. <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $users[$data['username']]);</span>
</code></div>
  </div>
 </div>
  <div class="note" id="90324">  <div class="votes">
    <div id="Vu90324">
    <a href="/manual/vote-note.php?id=90324&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd90324">
    <a href="/manual/vote-note.php?id=90324&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V90324" title="46% like this...">
    -1
    </div>
  </div>
  <a href="#90324" class="name">
  <strong class="user"><em>jon at toolz4schoolz dot com</em></strong></a><a class="genanchor" href="#90324"> &para;</a><div class="date" title="2009-04-16 06:10"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom90324">
<div class="phpcode"><code><span class="html">
I can't get the second example to work. The regular expression is beyond the scope of this programmer so I rewrote it as seven easy-to-read regular expressions and it works.<br /><br />Here's the whole function http_digest_parse() that works for me:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="comment">// function to parse the http auth header<br /></span><span class="keyword">function </span><span class="default">http_digest_parse</span><span class="keyword">(</span><span class="default">$txt</span><span class="keyword">) {<br /><br /></span><span class="comment">// protect against missing data<br />/*<br />$needed_parts = array('nonce'=&gt;1, 'nc'=&gt;1, 'cnonce'=&gt;1, 'qop'=&gt;1, 'username'=&gt;1, 'uri'=&gt;1, 'response'=&gt;1);<br />$data = array();<br /><br />preg_match_all('@(\w+)=(?:([\'"])([^\2]+)\2|([^\s,]+))@', $txt, $matches, PREG_SET_ORDER);<br /><br />foreach ($matches as $m) {<br />&nbsp; &nbsp; $data[$m[1]] = $m[3] ? $m[3] : $m[4];<br />&nbsp; &nbsp; unset($needed_parts[$m[1]]);<br />}<br />*/<br /><br /></span><span class="default">$res </span><span class="keyword">= </span><span class="default">preg_match</span><span class="keyword">(</span><span class="string">"/username=\"([^\"]+)\"/i"</span><span class="keyword">, </span><span class="default">$txt</span><span class="keyword">, </span><span class="default">$match</span><span class="keyword">);<br /></span><span class="default">$data</span><span class="keyword">[</span><span class="string">'username'</span><span class="keyword">] = </span><span class="default">$match</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">];<br /></span><span class="default">$res </span><span class="keyword">= </span><span class="default">preg_match</span><span class="keyword">(</span><span class="string">'/nonce=\"([^\"]+)\"/i'</span><span class="keyword">, </span><span class="default">$txt</span><span class="keyword">, </span><span class="default">$match</span><span class="keyword">);<br /></span><span class="default">$data</span><span class="keyword">[</span><span class="string">'nonce'</span><span class="keyword">] = </span><span class="default">$match</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">];<br /></span><span class="default">$res </span><span class="keyword">= </span><span class="default">preg_match</span><span class="keyword">(</span><span class="string">'/nc=([0-9]+)/i'</span><span class="keyword">, </span><span class="default">$txt</span><span class="keyword">, </span><span class="default">$match</span><span class="keyword">);<br /></span><span class="default">$data</span><span class="keyword">[</span><span class="string">'nc'</span><span class="keyword">] = </span><span class="default">$match</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">];<br /></span><span class="default">$res </span><span class="keyword">= </span><span class="default">preg_match</span><span class="keyword">(</span><span class="string">'/cnonce=\"([^\"]+)\"/i'</span><span class="keyword">, </span><span class="default">$txt</span><span class="keyword">, </span><span class="default">$match</span><span class="keyword">);<br /></span><span class="default">$data</span><span class="keyword">[</span><span class="string">'cnonce'</span><span class="keyword">] = </span><span class="default">$match</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">];<br /></span><span class="default">$res </span><span class="keyword">= </span><span class="default">preg_match</span><span class="keyword">(</span><span class="string">'/qop=([^,]+)/i'</span><span class="keyword">, </span><span class="default">$txt</span><span class="keyword">, </span><span class="default">$match</span><span class="keyword">);<br /></span><span class="default">$data</span><span class="keyword">[</span><span class="string">'qop'</span><span class="keyword">] = </span><span class="default">$match</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">];<br /></span><span class="default">$res </span><span class="keyword">= </span><span class="default">preg_match</span><span class="keyword">(</span><span class="string">'/uri=\"([^\"]+)\"/i'</span><span class="keyword">, </span><span class="default">$txt</span><span class="keyword">, </span><span class="default">$match</span><span class="keyword">);<br /></span><span class="default">$data</span><span class="keyword">[</span><span class="string">'uri'</span><span class="keyword">] = </span><span class="default">$match</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">];<br /></span><span class="default">$res </span><span class="keyword">= </span><span class="default">preg_match</span><span class="keyword">(</span><span class="string">'/response=\"([^\"]+)\"/i'</span><span class="keyword">, </span><span class="default">$txt</span><span class="keyword">, </span><span class="default">$match</span><span class="keyword">);<br /></span><span class="default">$data</span><span class="keyword">[</span><span class="string">'response'</span><span class="keyword">] = </span><span class="default">$match</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">];<br /><br /></span><span class="comment">//return $needed_parts ? false : $data;<br /></span><span class="keyword">return </span><span class="default">$data</span><span class="keyword">;<br /><br />}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="51259">  <div class="votes">
    <div id="Vu51259">
    <a href="/manual/vote-note.php?id=51259&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd51259">
    <a href="/manual/vote-note.php?id=51259&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V51259" title="46% like this...">
    -1
    </div>
  </div>
  <a href="#51259" class="name">
  <strong class="user"><em>sl at netcentrex dot net</em></strong></a><a class="genanchor" href="#51259"> &para;</a><div class="date" title="2005-03-24 02:16"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom51259">
<div class="phpcode"><code><span class="html">
This forces an instant re-authentication:<br /><br />// Force a logout.<br />function imt_logout()<br />{<br />&nbsp; &nbsp; global $_SESSION;<br />&nbsp; &nbsp; global $HTTP_SERVER_VARS;<br />&nbsp; &nbsp; global $PHP_SELF;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; // We mark the session as requiring a re-auth<br />&nbsp; &nbsp; $_SESSION['reauth-in-progress'] = 1;<br /><br />&nbsp; &nbsp; // This forces the authentication cache clearing<br />&nbsp; &nbsp; header("WWW-Authenticate: Basic realm=\"My Realm\"");<br />&nbsp; &nbsp; header("HTTP/1.0 401 Unauthorized");<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; // In case of the user clicks "cancel" in the dialog box<br />&nbsp; &nbsp; print '&lt;a href="<a href="http://" rel="nofollow" target="_blank">http://</a>'.$HTTP_SERVER_VARS['HTTP_HOST'].$PHP_SELF.'"&gt;click me&lt;/a&gt;';<br />&nbsp; &nbsp; exit();<br />}<br /><br />// Check login<br />function imt_login()<br />{<br />&nbsp; &nbsp; global $_SERVER;<br />&nbsp; &nbsp; global $_SESSION;<br />&nbsp; &nbsp; global $REGISTERED_USERS;<br /><br />&nbsp; &nbsp; // the valid_user checks the user/password (very primitive test in this example)<br />&nbsp; &nbsp; if (!valid_user($_SERVER['PHP_AUTH_USER'], $REGISTERED_USERS))<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; session_destroy();<br />&nbsp; &nbsp; &nbsp; &nbsp; header("WWW-Authenticate: Basic realm=\"My Realm\"");<br />&nbsp; &nbsp; &nbsp; &nbsp; header("HTTP/1.0 401 Unauthorized");<br />&nbsp; &nbsp; &nbsp; &nbsp; exit();<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; // OK, the user is authenticated<br />&nbsp; &nbsp; $_SESSION['user'] = $_SERVER['PHP_AUTH_USER'];<br />}<br /><br />Assuming that your page.php?action=logout forces a reauth on the same page, start your page with:<br /><br />session_start()<br />if ($_REQUEST["action"] == "logout")<br />{<br />&nbsp; &nbsp; if (isset($_SESSION['reauth-in-progress']))<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; session_destroy();<br />&nbsp; &nbsp; &nbsp; &nbsp; header("Location: <a href="http://" rel="nofollow" target="_blank">http://</a>".$HTTP_SERVER_VARS['HTTP_HOST'].$PHP_SELF);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp; imt_logout();<br />}<br />&nbsp; &nbsp; <br />imt_login();</span>
</code></div>
  </div>
 </div>
  <div class="note" id="62597">  <div class="votes">
    <div id="Vu62597">
    <a href="/manual/vote-note.php?id=62597&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd62597">
    <a href="/manual/vote-note.php?id=62597&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V62597" title="45% like this...">
    -1
    </div>
  </div>
  <a href="#62597" class="name">
  <strong class="user"><em>ZyX</em></strong></a><a class="genanchor" href="#62597"> &para;</a><div class="date" title="2006-03-04 04:04"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom62597">
<div class="phpcode"><code><span class="html">
Simple PHP Script to login on a Basic Authentication page.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="comment">/* Access Configuration */<br /></span><span class="default">define </span><span class="keyword">(</span><span class="string">'x401_host'</span><span class="keyword">, </span><span class="string">'www.example.com'</span><span class="keyword">);<br /></span><span class="default">define </span><span class="keyword">(</span><span class="string">'x401_port'</span><span class="keyword">, </span><span class="default">80</span><span class="keyword">);<br /></span><span class="default">define </span><span class="keyword">(</span><span class="string">'x401_user'</span><span class="keyword">, </span><span class="string">'your_username'</span><span class="keyword">);<br /></span><span class="default">define </span><span class="keyword">(</span><span class="string">'x401_pass'</span><span class="keyword">, </span><span class="string">'your_password'</span><span class="keyword">);<br /><br /></span><span class="comment">/* Function */<br /></span><span class="keyword">function </span><span class="default">get401Page</span><span class="keyword">(</span><span class="default">$file</span><span class="keyword">) {<br />&nbsp;&nbsp; </span><span class="default">$out&nbsp; </span><span class="keyword">= </span><span class="string">"GET </span><span class="default">$file</span><span class="string"> HTTP/1.1\r\n"</span><span class="keyword">;<br />&nbsp;&nbsp; </span><span class="default">$out </span><span class="keyword">.= </span><span class="string">"Host: "</span><span class="keyword">.</span><span class="default">x401_host</span><span class="keyword">.</span><span class="string">"t\r\n"</span><span class="keyword">;<br />&nbsp;&nbsp; </span><span class="default">$out </span><span class="keyword">.= </span><span class="string">"Connection: Close\r\n"</span><span class="keyword">;<br />&nbsp;&nbsp; </span><span class="default">$out </span><span class="keyword">.= </span><span class="string">"Authorization: Basic "</span><span class="keyword">.</span><span class="default">base64_encode</span><span class="keyword">(</span><span class="default">x401_user</span><span class="keyword">.</span><span class="string">":"</span><span class="keyword">.</span><span class="default">x401_pass</span><span class="keyword">).</span><span class="string">"\r\n"</span><span class="keyword">;<br />&nbsp;&nbsp; </span><span class="default">$out </span><span class="keyword">.= </span><span class="string">"\r\n"</span><span class="keyword">;<br /><br />&nbsp;&nbsp; if (!</span><span class="default">$conex </span><span class="keyword">= @</span><span class="default">fsockopen</span><span class="keyword">(</span><span class="default">x401_host</span><span class="keyword">, </span><span class="default">x401_port</span><span class="keyword">, </span><span class="default">$errno</span><span class="keyword">, </span><span class="default">$errstr</span><span class="keyword">, </span><span class="default">10</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp;&nbsp; return </span><span class="default">0</span><span class="keyword">;<br />&nbsp;&nbsp; </span><span class="default">fwrite</span><span class="keyword">(</span><span class="default">$conex</span><span class="keyword">, </span><span class="default">$out</span><span class="keyword">);<br />&nbsp;&nbsp; </span><span class="default">$data </span><span class="keyword">= </span><span class="string">''</span><span class="keyword">;<br />&nbsp;&nbsp; while (!</span><span class="default">feof</span><span class="keyword">(</span><span class="default">$conex</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$data </span><span class="keyword">.= </span><span class="default">fgets</span><span class="keyword">(</span><span class="default">$conex</span><span class="keyword">, </span><span class="default">512</span><span class="keyword">);<br />&nbsp;&nbsp; }<br />&nbsp;&nbsp; </span><span class="default">fclose</span><span class="keyword">(</span><span class="default">$conex</span><span class="keyword">);<br />&nbsp;&nbsp; return </span><span class="default">$data</span><span class="keyword">;<br />}<br /><br /></span><span class="comment">/* Code */<br /></span><span class="keyword">if (</span><span class="default">$source </span><span class="keyword">= </span><span class="default">get401Page</span><span class="keyword">(</span><span class="string">'/absolute/path/file.php?get=value'</span><span class="keyword">)) {<br />&nbsp; echo </span><span class="default">$source</span><span class="keyword">;<br />} else {<br />&nbsp; echo </span><span class="string">"I can't connect!"</span><span class="keyword">;<br />}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="59834">  <div class="votes">
    <div id="Vu59834">
    <a href="/manual/vote-note.php?id=59834&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd59834">
    <a href="/manual/vote-note.php?id=59834&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V59834" title="45% like this...">
    -1
    </div>
  </div>
  <a href="#59834" class="name">
  <strong class="user"><em>sezer yalcin</em></strong></a><a class="genanchor" href="#59834"> &para;</a><div class="date" title="2005-12-17 01:16"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom59834">
<div class="phpcode"><code><span class="html">
none of those 'logout' methods would work well.<br /><br />Even tricky ones like using cookie to reset cache.<br /><br />Do not waste your time on this. <br /><br />Browsers want to keep username and password to help user anyway. Try closing the window, or telling user to restart browser.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="57896">  <div class="votes">
    <div id="Vu57896">
    <a href="/manual/vote-note.php?id=57896&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd57896">
    <a href="/manual/vote-note.php?id=57896&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V57896" title="44% like this...">
    -2
    </div>
  </div>
  <a href="#57896" class="name">
  <strong class="user"><em>somebody</em></strong></a><a class="genanchor" href="#57896"> &para;</a><div class="date" title="2005-10-18 07:20"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom57896">
<div class="phpcode"><code><span class="html">
In the previous example it will not work in IE. In order to have a single script work on both IE and FireFox (and handle the cache problem), you need to use the $_SERVER['HTTP_USER_AGENT'] variable to know which logout version to present to the user.<br /><br />An full example can be seen in the url (could not post it here due to size restrictions):<br /><br /><a href="http://www.free-php.org/index.php?" rel="nofollow" target="_blank">http://www.free-php.org/index.php?</a><br />cat_select=HTTP&amp;show=HTTP_Authentication<br /><br />(URL split also due to size restrictions)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="65801">  <div class="votes">
    <div id="Vu65801">
    <a href="/manual/vote-note.php?id=65801&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd65801">
    <a href="/manual/vote-note.php?id=65801&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V65801" title="42% like this...">
    -2
    </div>
  </div>
  <a href="#65801" class="name">
  <strong class="user"><em>cyberscribe at php dot net</em></strong></a><a class="genanchor" href="#65801"> &para;</a><div class="date" title="2006-05-07 11:47"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom65801">
<div class="phpcode"><code><span class="html">
To implement the Digest authentication mentioned above in PHP &lt; 5.1, try prepending the following:<br /><br /><span class="default">&lt;?php<br />$headers </span><span class="keyword">= </span><span class="default">apache_request_headers</span><span class="keyword">();<br /></span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_DIGEST'</span><span class="keyword">] = </span><span class="default">$headers</span><span class="keyword">[</span><span class="string">'Authorization'</span><span class="keyword">];<br /></span><span class="default">?&gt;<br /></span><br />or, if you don't like the idea of modifying the global $_SERVER variable directly, just use the first line and then substitute $_SERVER['PHP_AUTH_DIGEST'] in the sample code with $headers['Authorization']. Works great.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="111763">  <div class="votes">
    <div id="Vu111763">
    <a href="/manual/vote-note.php?id=111763&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd111763">
    <a href="/manual/vote-note.php?id=111763&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V111763" title="41% like this...">
    -3
    </div>
  </div>
  <a href="#111763" class="name">
  <strong class="user"><em>Mario</em></strong></a><a class="genanchor" href="#111763"> &para;</a><div class="date" title="2013-03-26 11:06"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom111763">
<div class="phpcode"><code><span class="html">
if you are using apache with mod fcgid you have to add<br /><br />&lt;IfModule fcgid_module&gt;<br />&nbsp; &nbsp; FcgidPassHeader Authorization<br />&lt;/IfModule&gt;<br /><br />to make it work</span>
</code></div>
  </div>
 </div>
  <div class="note" id="53216">  <div class="votes">
    <div id="Vu53216">
    <a href="/manual/vote-note.php?id=53216&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd53216">
    <a href="/manual/vote-note.php?id=53216&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V53216" title="41% like this...">
    -2
    </div>
  </div>
  <a href="#53216" class="name">
  <strong class="user"><em>aplanefan at mail dot com</em></strong></a><a class="genanchor" href="#53216"> &para;</a><div class="date" title="2005-05-25 06:36"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom53216">
<div class="phpcode"><code><span class="html">
I found a way to log out easily<br /><span class="default">&lt;?php<br />ob_start</span><span class="keyword">();<br />if (!isset(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">]) || </span><span class="default">$_COOKIE</span><span class="keyword">[</span><span class="string">'isin'</span><span class="keyword">] != </span><span class="string">"1"</span><span class="keyword">) {<br /></span><span class="default">header</span><span class="keyword">(</span><span class="string">'WWW-Authenticate: Basic realm="My Realm"'</span><span class="keyword">);<br /></span><span class="default">header</span><span class="keyword">(</span><span class="string">'HTTP/1.0 401 Unauthorized'</span><span class="keyword">);<br /></span><span class="default">setcookie </span><span class="keyword">(</span><span class="string">"isin"</span><span class="keyword">, </span><span class="string">"1"</span><span class="keyword">);<br />die(</span><span class="string">'&lt;a href="orderhan.php"&gt;Login&lt;/a&gt;'</span><span class="keyword">);<br />} <br />else {<br />if(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">] == </span><span class="string">"USER" </span><span class="keyword">&amp;&amp;&nbsp; </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_PW'</span><span class="keyword">]== </span><span class="string">"PASSWORD"</span><span class="keyword">) {<br />echo </span><span class="string">"you got in"</span><span class="keyword">;<br />echo </span><span class="string">"&lt;a href='"</span><span class="keyword">.</span><span class="default">$_SEVER</span><span class="keyword">[</span><span class="string">'PHP_SELF'</span><span class="keyword">].</span><span class="string">"?action=logout'&gt;logout&lt;/a&gt;"</span><span class="keyword">;<br />}<br />else {<br /></span><span class="default">setcookie </span><span class="keyword">(</span><span class="string">"isin"</span><span class="keyword">, </span><span class="string">""</span><span class="keyword">, </span><span class="default">time</span><span class="keyword">() - </span><span class="default">3600</span><span class="keyword">);<br /></span><span class="default">$url</span><span class="keyword">=</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_SELF'</span><span class="keyword">];<br /></span><span class="default">header</span><span class="keyword">(</span><span class="string">"location: </span><span class="default">$url</span><span class="string">"</span><span class="keyword">);<br />}<br />if(</span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">'action'</span><span class="keyword">] == </span><span class="string">"logout"</span><span class="keyword">) {<br /></span><span class="default">setcookie </span><span class="keyword">(</span><span class="string">"isin"</span><span class="keyword">, </span><span class="string">""</span><span class="keyword">, </span><span class="default">time</span><span class="keyword">() - </span><span class="default">3600</span><span class="keyword">);<br /></span><span class="default">$url</span><span class="keyword">=</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_SELF'</span><span class="keyword">];<br /></span><span class="default">header</span><span class="keyword">(</span><span class="string">"location: </span><span class="default">$url</span><span class="string">"</span><span class="keyword">);<br />}<br />}<br /></span><span class="default">ob_end_flush</span><span class="keyword">();<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="91770">  <div class="votes">
    <div id="Vu91770">
    <a href="/manual/vote-note.php?id=91770&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd91770">
    <a href="/manual/vote-note.php?id=91770&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V91770" title="40% like this...">
    -3
    </div>
  </div>
  <a href="#91770" class="name">
  <strong class="user"><em>norther</em></strong></a><a class="genanchor" href="#91770"> &para;</a><div class="date" title="2009-06-25 12:36"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom91770">
<div class="phpcode"><code><span class="html">
If you are using PHP + IIS, make sure to set HTTP Error 401;5 to Default in IIS directory config. Otherwise it won't prompt for username and password but just show an error message.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="94164">  <div class="votes">
    <div id="Vu94164">
    <a href="/manual/vote-note.php?id=94164&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd94164">
    <a href="/manual/vote-note.php?id=94164&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V94164" title="38% like this...">
    -4
    </div>
  </div>
  <a href="#94164" class="name">
  <strong class="user"><em>ale (at) tana (dot) it</em></strong></a><a class="genanchor" href="#94164"> &para;</a><div class="date" title="2009-10-20 10:52"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom94164">
<div class="phpcode"><code><span class="html">
After we do auth with PHP in Apache, we miss the userid in the access.log file, unless we redefine the LogFormat to be "%{REMOTE_USER}e" rather than "%u", and upon successful authentication we do<br /><span class="default">&lt;?php<br />&nbsp;&nbsp; apache_setenv</span><span class="keyword">(</span><span class="string">'REMOTE_USER'</span><span class="keyword">, </span><span class="default">$user</span><span class="keyword">);<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="33094">  <div class="votes">
    <div id="Vu33094">
    <a href="/manual/vote-note.php?id=33094&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd33094">
    <a href="/manual/vote-note.php?id=33094&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V33094" title="38% like this...">
    -3
    </div>
  </div>
  <a href="#33094" class="name">
  <strong class="user"><em>steve at topozone dot com</em></strong></a><a class="genanchor" href="#33094"> &para;</a><div class="date" title="2003-06-16 12:51"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom33094">
<div class="phpcode"><code><span class="html">
The method described in the text does not appear to work with PHP in cgi mode and Apache-2.x. I seems that Apache has gotten stricter or introduced a bug such that you can initiate the authentication, but Apache seems to try to&nbsp; authenticate the browser response which always fails because it does not know what to authenticate against and the headers never get passed back to the PHP script.<br /><br />I didn't try it with PHP as a module.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="72973">  <div class="votes">
    <div id="Vu72973">
    <a href="/manual/vote-note.php?id=72973&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd72973">
    <a href="/manual/vote-note.php?id=72973&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V72973" title="37% like this...">
    -4
    </div>
  </div>
  <a href="#72973" class="name">
  <strong class="user"><em>mg at evolution515 dot net</em></strong></a><a class="genanchor" href="#72973"> &para;</a><div class="date" title="2007-02-06 04:20"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom72973">
<div class="phpcode"><code><span class="html">
Example for digest doesn't work (at least for me):<br /><br />use this fix:<br />--------------<br />preg_match_all('@(\w+)=(?:(([\'"])(.+?)\3|([A-Za-z0-9/]+)))@', $txt, $matches, PREG_SET_ORDER);<br /><br />foreach ($matches as $m) {<br />&nbsp; &nbsp; $data[$m[1]] = $m[4] ? $m[4] : $m[5];<br />&nbsp; &nbsp; unset($needed_parts[$m[1]]);<br />}<br /><br />It's also better to but to put the Auth-Digest-Header in a function and call it on unsuccessful authentification again. Otherwise users only have the chance to submit their username/password just one time.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="40489">  <div class="votes">
    <div id="Vu40489">
    <a href="/manual/vote-note.php?id=40489&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd40489">
    <a href="/manual/vote-note.php?id=40489&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V40489" title="36% like this...">
    -3
    </div>
  </div>
  <a href="#40489" class="name">
  <strong class="user"><em>ian AT iyates DOT co DOR uk</em></strong></a><a class="genanchor" href="#40489"> &para;</a><div class="date" title="2004-03-05 05:32"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom40489">
<div class="phpcode"><code><span class="html">
In my use of HTTP Authentication, I've found that some Apache setups swap around the usual variables.<br />Here's the fix I made so that you can still use PHP_AUTH_USER and PHP_AUTH_PW. Hope it helps someone<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">## Apache server fix ##<br /></span><span class="keyword">if (isset(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">]) &amp;&amp; !isset(</span><span class="default">$_ENV</span><span class="keyword">[</span><span class="string">'REMOTE_USER'</span><span class="keyword">]))<br />&nbsp; &nbsp; </span><span class="default">$_ENV</span><span class="keyword">[</span><span class="string">'REMOTE_USER'</span><span class="keyword">] = </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">];<br />if (isset(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'AUTH_PASSWORD'</span><span class="keyword">]) &amp;&amp; !isset(</span><span class="default">$_ENV</span><span class="keyword">[</span><span class="string">'PHP_AUTH_PW'</span><span class="keyword">]))<br />&nbsp; &nbsp; </span><span class="default">$_ENV</span><span class="keyword">[</span><span class="string">'PHP_AUTH_PW'</span><span class="keyword">] = </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'AUTH_PASSWORD'</span><span class="keyword">];<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="78444">  <div class="votes">
    <div id="Vu78444">
    <a href="/manual/vote-note.php?id=78444&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd78444">
    <a href="/manual/vote-note.php?id=78444&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V78444" title="27% like this...">
    -5
    </div>
  </div>
  <a href="#78444" class="name">
  <strong class="user"><em>mt at shrewsbury dot org dot uk</em></strong></a><a class="genanchor" href="#78444"> &para;</a><div class="date" title="2007-10-12 02:28"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom78444">
<div class="phpcode"><code><span class="html">
On my servers here, the standard rewrite spell<br /><br />RewriteRule .* - [E=REMOTE_USER:%{HTTP:Authorization},L]<br /><br />to set $_SERVER[REMOTE_USER] with digest authentication results in the entire digest being bundled into $_SERVER[REMOTE_USER]<br /><br />I have used this :<br /><br />RewriteCond %{HTTP:Authorization} username=\"([^\"]+)\"<br />RewriteRule .* - [E=REMOTE_USER:%1,L]<br /><br />And it seems to work successfully.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="68464">  <div class="votes">
    <div id="Vu68464">
    <a href="/manual/vote-note.php?id=68464&amp;page=features.http-auth&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd68464">
    <a href="/manual/vote-note.php?id=68464&amp;page=features.http-auth&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V68464" title="25% like this...">
    -6
    </div>
  </div>
  <a href="#68464" class="name">
  <strong class="user"><em>blah at blah dot com</em></strong></a><a class="genanchor" href="#68464"> &para;</a><div class="date" title="2006-07-27 12:46"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom68464">
<div class="phpcode"><code><span class="html">
Getting PHP Authentication to work with CGI-bin.<br /><br />You must have mod_rewrite installed for this to work. In the directory (of the file) you want to protect, for the .htaccess file:<br /><br /># PHP (CGI mode) HTTP Authorization with ModRewrite:<br /># most right example with header check for non empty:<br />RewriteEngine on <br />RewriteCond %{HTTP:Authorization}&nbsp; !^$<br />RewriteRule ^test.php$ test.php?login=%{HTTP:Authorization} <br /><br />Change the Rewrite rule to whatever you want it to be. For simplicity, this example only applies to one file, test.php and only if the HTTP Authorization needs to take place.<br /><br />In the php file:<br />&lt;?<br />if (isset($_GET['login'])) {<br />&nbsp; &nbsp; $d = base64_decode( substr($_GET['login'],6) );<br />&nbsp; &nbsp; list($name, $password) = explode(':', $d);<br />&nbsp; &nbsp; echo 'Name:' . $name . "&lt;br&gt;\n";<br />&nbsp; &nbsp; echo 'Password:' . $password . "&lt;br&gt;\n";<br />} else {<br />&nbsp;&nbsp; header('WWW-Authenticate: Basic realm="My Realm"');<br />&nbsp;&nbsp; header('HTTP/1.0 401 Unauthorized');<br />&nbsp;&nbsp; echo 'You are not authorized. Bad user, bad!';<br />&nbsp;&nbsp; exit;<br />}<br />?&gt;<br /><br />You need to get rid of the first 6 characters for some reason, then decode the Auth data from its base64 format. Then it's a simple matter of extracting the data. You can even pass the data to the $_SERVER variables $_SERVER['PHP_AUTH_USER'] and $_SERVER['PHP_AUTH_PW']. These are the variables that get the login data if you have PHP running as an Apache module. This is useful for mods or plugins.</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=features.http-auth&amp;redirect=http://php.net/manual/en/features.http-auth.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="features.php">Features</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="current">
                            <a href="features.http-auth.php" title="HTTP authentication with PHP">HTTP authentication with PHP</a>
                        </li>
                          
                        <li class="">
                            <a href="features.cookies.php" title="Cookies">Cookies</a>
                        </li>
                          
                        <li class="">
                            <a href="features.sessions.php" title="Sessions">Sessions</a>
                        </li>
                          
                        <li class="">
                            <a href="features.xforms.php" title="Dealing with XForms">Dealing with XForms</a>
                        </li>
                          
                        <li class="">
                            <a href="features.file-upload.php" title="Handling file uploads">Handling file uploads</a>
                        </li>
                          
                        <li class="">
                            <a href="features.remote-files.php" title="Using remote files">Using remote files</a>
                        </li>
                          
                        <li class="">
                            <a href="features.connection-handling.php" title="Connection handling">Connection handling</a>
                        </li>
                          
                        <li class="">
                            <a href="features.persistent-connections.php" title="Persistent Database Connections">Persistent Database Connections</a>
                        </li>
                          
                        <li class="">
                            <a href="features.safe-mode.php" title="Safe Mode">Safe Mode</a>
                        </li>
                          
                        <li class="">
                            <a href="features.commandline.php" title="Command line usage">Command line usage</a>
                        </li>
                          
                        <li class="">
                            <a href="features.gc.php" title="Garbage Collection">Garbage Collection</a>
                        </li>
                          
                        <li class="">
                            <a href="features.dtrace.php" title="DTrace Dynamic Tracing">DTrace Dynamic Tracing</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

