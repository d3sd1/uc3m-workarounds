<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Scope Resolution Operator (::) - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.oop5.paamayim-nekudotayim.php">
 <link rel="shorturl" href="http://php.net/oop5.paamayim-nekudotayim">
 <link rel="alternate" href="http://php.net/oop5.paamayim-nekudotayim" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.oop5.php">
 <link rel="prev" href="http://php.net/manual/en/language.oop5.inheritance.php">
 <link rel="next" href="http://php.net/manual/en/language.oop5.static.php">

 <link rel="alternate" href="http://php.net/manual/en/language.oop5.paamayim-nekudotayim.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.oop5.paamayim-nekudotayim.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.oop5.paamayim-nekudotayim.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.oop5.paamayim-nekudotayim.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.oop5.paamayim-nekudotayim.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.oop5.paamayim-nekudotayim.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.oop5.paamayim-nekudotayim.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.oop5.paamayim-nekudotayim.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.oop5.paamayim-nekudotayim.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.oop5.paamayim-nekudotayim.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.oop5.paamayim-nekudotayim.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.oop5.static.php">
          Static Keyword &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.oop5.inheritance.php">
          &laquo; Object Inheritance        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.oop5.php'>Classes and Objects</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.oop5.paamayim-nekudotayim.php' selected="selected">English</option>
            <option value='pt_BR/language.oop5.paamayim-nekudotayim.php'>Brazilian Portuguese</option>
            <option value='zh/language.oop5.paamayim-nekudotayim.php'>Chinese (Simplified)</option>
            <option value='fr/language.oop5.paamayim-nekudotayim.php'>French</option>
            <option value='de/language.oop5.paamayim-nekudotayim.php'>German</option>
            <option value='ja/language.oop5.paamayim-nekudotayim.php'>Japanese</option>
            <option value='ro/language.oop5.paamayim-nekudotayim.php'>Romanian</option>
            <option value='ru/language.oop5.paamayim-nekudotayim.php'>Russian</option>
            <option value='es/language.oop5.paamayim-nekudotayim.php'>Spanish</option>
            <option value='tr/language.oop5.paamayim-nekudotayim.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.oop5.paamayim-nekudotayim.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.oop5.paamayim-nekudotayim">Report a Bug</a>
    </div>
  </div><div id="language.oop5.paamayim-nekudotayim" class="sect1">
 <h2 class="title">Scope Resolution Operator (::)</h2>

 <p class="para">
  The Scope Resolution Operator (also called Paamayim Nekudotayim) or in
  simpler terms, the double colon, is a token that allows access to
  <a href="language.oop5.static.php" class="link">static</a>,
  <a href="language.oop5.constants.php" class="link">constant</a>, and overridden
  properties or methods of a class.
 </p>

 <p class="para">
  When referencing these items from outside the class definition, use
  the name of the class.
 </p>

 <p class="para">
  As of PHP 5.3.0, it&#039;s possible to reference the class using a variable.
  The variable&#039;s value can not be a keyword (e.g. <em>self</em>,
  <em>parent</em> and <em>static</em>).
 </p>

 <p class="para">
  Paamayim Nekudotayim would, at first, seem like a strange choice for
  naming a double-colon. However, while writing the Zend Engine 0.5
  (which powers PHP 3), that&#039;s what the Zend team decided to call it.
  It actually does mean double-colon - in Hebrew!
 </p>

 <div class="example" id="example-199">
  <p><strong>Example #1 :: from outside the class definition</strong></p>
  <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">MyClass&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;const&nbsp;</span><span style="color: #0000BB">CONST_VALUE&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'A&nbsp;constant&nbsp;value'</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #0000BB">$classname&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'MyClass'</span><span style="color: #007700">;<br />echo&nbsp;</span><span style="color: #0000BB">$classname</span><span style="color: #007700">::</span><span style="color: #0000BB">CONST_VALUE</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;As&nbsp;of&nbsp;PHP&nbsp;5.3.0<br /><br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #0000BB">MyClass</span><span style="color: #007700">::</span><span style="color: #0000BB">CONST_VALUE</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
  </div>

 </div>

 <p class="para">
  Three special keywords <var class="varname"><var class="varname">self</var></var>, <var class="varname"><var class="varname">parent</var></var> and
  <var class="varname"><var class="varname">static</var></var> are used to access properties or methods from inside
  the class definition.
 </p>

 <div class="example" id="example-200">
  <p><strong>Example #2 :: from inside the class definition</strong></p>
  <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">OtherClass&nbsp;</span><span style="color: #007700">extends&nbsp;</span><span style="color: #0000BB">MyClass<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;static&nbsp;</span><span style="color: #0000BB">$my_static&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'static&nbsp;var'</span><span style="color: #007700">;<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;static&nbsp;function&nbsp;</span><span style="color: #0000BB">doubleColon</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #0000BB">parent</span><span style="color: #007700">::</span><span style="color: #0000BB">CONST_VALUE&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #0000BB">self</span><span style="color: #007700">::</span><span style="color: #0000BB">$my_static&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br /></span><span style="color: #0000BB">$classname&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'OtherClass'</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$classname</span><span style="color: #007700">::</span><span style="color: #0000BB">doubleColon</span><span style="color: #007700">();&nbsp;</span><span style="color: #FF8000">//&nbsp;As&nbsp;of&nbsp;PHP&nbsp;5.3.0<br /><br /></span><span style="color: #0000BB">OtherClass</span><span style="color: #007700">::</span><span style="color: #0000BB">doubleColon</span><span style="color: #007700">();<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
  </div>

 </div>

 <p class="para">
  When an extending class overrides the parents definition of a method,
  PHP will not call the parent&#039;s method. It&#039;s up to the extended class
  on whether or not the parent&#039;s method is called. This also applies to <a href="language.oop5.decon.php" class="link">Constructors and Destructors</a>, <a href="language.oop5.overloading.php" class="link">Overloading</a>, and <a href="language.oop5.magic.php" class="link">Magic</a> method definitions.
 </p>

 <div class="example" id="example-201">
  <p><strong>Example #3 Calling a parent&#039;s method</strong></p>
  <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">MyClass<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;protected&nbsp;function&nbsp;</span><span style="color: #0000BB">myFunc</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"MyClass::myFunc()\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br />class&nbsp;</span><span style="color: #0000BB">OtherClass&nbsp;</span><span style="color: #007700">extends&nbsp;</span><span style="color: #0000BB">MyClass<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;Override&nbsp;parent's&nbsp;definition<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">public&nbsp;function&nbsp;</span><span style="color: #0000BB">myFunc</span><span style="color: #007700">()<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;But&nbsp;still&nbsp;call&nbsp;the&nbsp;parent&nbsp;function<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">parent</span><span style="color: #007700">::</span><span style="color: #0000BB">myFunc</span><span style="color: #007700">();<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"OtherClass::myFunc()\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br /></span><span style="color: #0000BB">$class&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">OtherClass</span><span style="color: #007700">();<br /></span><span style="color: #0000BB">$class</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">myFunc</span><span style="color: #007700">();<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
  </div>

 </div>
 <p class="para">
  See also <a href="language.oop5.basic.php#language.oop5.basic.class.this" class="link">some examples of
  static call trickery</a>.
 </p>

</div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.oop5.paamayim-nekudotayim&amp;redirect=http://php.net/manual/en/language.oop5.paamayim-nekudotayim.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">12 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="94976">  <div class="votes">
    <div id="Vu94976">
    <a href="/manual/vote-note.php?id=94976&amp;page=language.oop5.paamayim-nekudotayim&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd94976">
    <a href="/manual/vote-note.php?id=94976&amp;page=language.oop5.paamayim-nekudotayim&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V94976" title="74% like this...">
    66
    </div>
  </div>
  <a href="#94976" class="name">
  <strong class="user"><em>Theriault</em></strong></a><a class="genanchor" href="#94976"> &para;</a><div class="date" title="2009-12-05 08:58"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom94976">
<div class="phpcode"><code><span class="html">
A class constant, class property (static), and class function (static) can all share the same name and be accessed using the double-colon.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">A </span><span class="keyword">{<br /><br />&nbsp; &nbsp; public static </span><span class="default">$B </span><span class="keyword">= </span><span class="string">'1'</span><span class="keyword">; </span><span class="comment"># Static class variable.<br /><br />&nbsp; &nbsp; </span><span class="keyword">const </span><span class="default">B </span><span class="keyword">= </span><span class="string">'2'</span><span class="keyword">; </span><span class="comment"># Class constant.<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="keyword">public static function </span><span class="default">B</span><span class="keyword">() { </span><span class="comment"># Static class function.<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">return </span><span class="string">'3'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />}<br /><br />echo </span><span class="default">A</span><span class="keyword">::</span><span class="default">$B </span><span class="keyword">. </span><span class="default">A</span><span class="keyword">::</span><span class="default">B </span><span class="keyword">. </span><span class="default">A</span><span class="keyword">::</span><span class="default">B</span><span class="keyword">(); </span><span class="comment"># Outputs: 123<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121085">  <div class="votes">
    <div id="Vu121085">
    <a href="/manual/vote-note.php?id=121085&amp;page=language.oop5.paamayim-nekudotayim&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121085">
    <a href="/manual/vote-note.php?id=121085&amp;page=language.oop5.paamayim-nekudotayim&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121085" title="90% like this...">
    9
    </div>
  </div>
  <a href="#121085" class="name">
  <strong class="user"><em>1naveengiri at gmail dot com</em></strong></a><a class="genanchor" href="#121085"> &para;</a><div class="date" title="2017-05-15 06:36"><strong>6 months ago</strong></div>
  <div class="text" id="Hcom121085">
<div class="phpcode"><code><span class="html">
In PHP, you use the self keyword to access static properties and methods.<br /><br />The problem is that you can replace $this-&gt;method() with self::method() anywhere, regardless if method() is declared static or not. So which one should you use?<br /><br />Consider this code:<br /><br />class ParentClass {<br />&nbsp; &nbsp; function test() {<br />&nbsp; &nbsp; &nbsp; &nbsp; self::who();&nbsp; &nbsp; // will output 'parent'<br />&nbsp; &nbsp; &nbsp; &nbsp; $this-&gt;who();&nbsp; &nbsp; // will output 'child'<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; function who() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo 'parent';<br />&nbsp; &nbsp; }<br />}<br /><br />class ChildClass extends ParentClass {<br />&nbsp; &nbsp; function who() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo 'child';<br />&nbsp; &nbsp; }<br />}<br /><br />$obj = new ChildClass();<br />$obj-&gt;test();<br />In this example, self::who() will always output ‘parent’, while $this-&gt;who() will depend on what class the object has.<br /><br />Now we can see that self refers to the class in which it is called, while $this refers to the class of the current object.<br /><br />So, you should use self only when $this is not available, or when you don’t want to allow descendant classes to overwrite the current method.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113231">  <div class="votes">
    <div id="Vu113231">
    <a href="/manual/vote-note.php?id=113231&amp;page=language.oop5.paamayim-nekudotayim&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113231">
    <a href="/manual/vote-note.php?id=113231&amp;page=language.oop5.paamayim-nekudotayim&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113231" title="66% like this...">
    15
    </div>
  </div>
  <a href="#113231" class="name">
  <strong class="user"><em>guy at syntheticwebapps dot com</em></strong></a><a class="genanchor" href="#113231"> &para;</a><div class="date" title="2013-09-15 08:29"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113231">
<div class="phpcode"><code><span class="html">
It seems as though you can use more than the class name to reference the static variables, constants, and static functions of a class definition from outside that class using the :: . The language appears to allow you to use the object itself. <br /><br />For example:<br />class horse <br />{<br />&nbsp;&nbsp; static $props = {'order'=&gt;'mammal'};<br />}<br />$animal = new horse();<br />echo $animal::$props['order'];<br /><br />// yields 'mammal'<br /><br />This does not appear to be documented but I see it as an important convenience in the language. I would like to see it documented and supported as valid. <br /><br />If it weren't supported officially, the alternative would seem to be messy, something like this:<br /><br />$animalClass = get_class($animal);<br />echo $animalClass::$props['order'];</span>
</code></div>
  </div>
 </div>
  <div class="note" id="88449">  <div class="votes">
    <div id="Vu88449">
    <a href="/manual/vote-note.php?id=88449&amp;page=language.oop5.paamayim-nekudotayim&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd88449">
    <a href="/manual/vote-note.php?id=88449&amp;page=language.oop5.paamayim-nekudotayim&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V88449" title="56% like this...">
    6
    </div>
  </div>
  <a href="#88449" class="name">
  <strong class="user"><em>luka8088 at gmail dot com</em></strong></a><a class="genanchor" href="#88449"> &para;</a><div class="date" title="2009-01-24 03:15"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom88449">
<div class="phpcode"><code><span class="html">
Little static trick to go around php strict standards ...<br />Function caller founds an object from which it was called, so that static method can alter it, replacement for $this in static function but without strict warnings :)<br /><br /><span class="default">&lt;?php<br /><br />error_reporting</span><span class="keyword">(</span><span class="default">E_ALL </span><span class="keyword">+ </span><span class="default">E_STRICT</span><span class="keyword">);<br /><br />function </span><span class="default">caller </span><span class="keyword">() {<br />&nbsp; </span><span class="default">$backtrace </span><span class="keyword">= </span><span class="default">debug_backtrace</span><span class="keyword">();<br />&nbsp; </span><span class="default">$object </span><span class="keyword">= isset(</span><span class="default">$backtrace</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">][</span><span class="string">'object'</span><span class="keyword">]) ? </span><span class="default">$backtrace</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">][</span><span class="string">'object'</span><span class="keyword">] : </span><span class="default">null</span><span class="keyword">;<br />&nbsp; </span><span class="default">$k </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; while (isset(</span><span class="default">$backtrace</span><span class="keyword">[</span><span class="default">$k</span><span class="keyword">]) &amp;&amp; (!isset(</span><span class="default">$backtrace</span><span class="keyword">[</span><span class="default">$k</span><span class="keyword">][</span><span class="string">'object'</span><span class="keyword">]) || </span><span class="default">$object </span><span class="keyword">=== </span><span class="default">$backtrace</span><span class="keyword">[</span><span class="default">$k</span><span class="keyword">][</span><span class="string">'object'</span><span class="keyword">]))<br />&nbsp; &nbsp; </span><span class="default">$k</span><span class="keyword">++;<br /><br />&nbsp; return isset(</span><span class="default">$backtrace</span><span class="keyword">[</span><span class="default">$k</span><span class="keyword">][</span><span class="string">'object'</span><span class="keyword">]) ? </span><span class="default">$backtrace</span><span class="keyword">[</span><span class="default">$k</span><span class="keyword">][</span><span class="string">'object'</span><span class="keyword">] : </span><span class="default">null</span><span class="keyword">;<br />}<br /><br />class </span><span class="default">a </span><span class="keyword">{<br /><br />&nbsp; public </span><span class="default">$data </span><span class="keyword">= </span><span class="string">'Empty'</span><span class="keyword">;<br />&nbsp; <br />&nbsp; function </span><span class="default">set_data </span><span class="keyword">() {<br />&nbsp; &nbsp; </span><span class="default">b</span><span class="keyword">::</span><span class="default">set</span><span class="keyword">();<br />&nbsp; }<br /><br />}<br /><br />class </span><span class="default">b </span><span class="keyword">{<br /><br />&nbsp; static function </span><span class="default">set </span><span class="keyword">() {<br />&nbsp; &nbsp; </span><span class="comment">// $this-&gt;data = 'Data from B !';<br />&nbsp; &nbsp; // using this in static function throws a warning ...<br />&nbsp; &nbsp; </span><span class="default">caller</span><span class="keyword">()-&gt;</span><span class="default">data </span><span class="keyword">= </span><span class="string">'Data from B !'</span><span class="keyword">;<br />&nbsp; }<br /><br />}<br /><br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">a</span><span class="keyword">();<br /></span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">set_data</span><span class="keyword">();<br />echo </span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">data</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;<br /></span><br />Outputs: Data from B !<br /><br />No warnings or errors !</span>
</code></div>
  </div>
 </div>
  <div class="note" id="97740">  <div class="votes">
    <div id="Vu97740">
    <a href="/manual/vote-note.php?id=97740&amp;page=language.oop5.paamayim-nekudotayim&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd97740">
    <a href="/manual/vote-note.php?id=97740&amp;page=language.oop5.paamayim-nekudotayim&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V97740" title="54% like this...">
    6
    </div>
  </div>
  <a href="#97740" class="name">
  <strong class="user"><em>remy dot damour at ----no-spam---laposte dot net</em></strong></a><a class="genanchor" href="#97740"> &para;</a><div class="date" title="2010-05-05 01:50"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom97740">
<div class="phpcode"><code><span class="html">
As of php 5.3.0, you can use 'static' as scope value as in below example (add flexibility to inheritance mechanism compared to 'self' keyword...)<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">A </span><span class="keyword">{<br />&nbsp; &nbsp; const </span><span class="default">C </span><span class="keyword">= </span><span class="string">'constA'</span><span class="keyword">;<br />&nbsp; &nbsp; public function </span><span class="default">m</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo static::</span><span class="default">C</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">B </span><span class="keyword">extends </span><span class="default">A </span><span class="keyword">{<br />&nbsp; &nbsp; const </span><span class="default">C </span><span class="keyword">= </span><span class="string">'constB'</span><span class="keyword">;<br />}<br /><br /></span><span class="default">$b </span><span class="keyword">= new </span><span class="default">B</span><span class="keyword">();<br /></span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">m</span><span class="keyword">();<br /><br /></span><span class="comment">// output: constB<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="91258">  <div class="votes">
    <div id="Vu91258">
    <a href="/manual/vote-note.php?id=91258&amp;page=language.oop5.paamayim-nekudotayim&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd91258">
    <a href="/manual/vote-note.php?id=91258&amp;page=language.oop5.paamayim-nekudotayim&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V91258" title="54% like this...">
    2
    </div>
  </div>
  <a href="#91258" class="name">
  <strong class="user"><em>giovanni at gargani dot it</em></strong></a><a class="genanchor" href="#91258"> &para;</a><div class="date" title="2009-06-02 06:38"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom91258">
<div class="phpcode"><code><span class="html">
Well, a "swiss knife" couple of code lines to call parent method. The only limit is you can't use it with "by reference" parameters.<br />Main advantage you dont need to know the "actual" signature of your super class, you just need to know which arguments do you need<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">someclass </span><span class="keyword">extends </span><span class="default">some superclass </span><span class="keyword">{<br /></span><span class="comment">// usable for constructors<br /> </span><span class="keyword">function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$ineedthisone</span><span class="keyword">) {<br />&nbsp; </span><span class="default">$args</span><span class="keyword">=</span><span class="default">func_get_args</span><span class="keyword">(); <br />&nbsp; </span><span class="comment">/* $args will contain any argument passed to __construct.&nbsp;&nbsp; <br />&nbsp; * Your formal argument doesnt influence the way func_get_args() works<br />&nbsp; */<br />&nbsp; </span><span class="default">call_user_func_array</span><span class="keyword">(array(</span><span class="string">'parent'</span><span class="keyword">,</span><span class="default">__FUNCTION__</span><span class="keyword">),</span><span class="default">$args</span><span class="keyword">);<br /> }<br /></span><span class="comment">// but this is not for __construct only<br /> </span><span class="keyword">function </span><span class="default">anyMethod</span><span class="keyword">() {<br />&nbsp; </span><span class="default">$args</span><span class="keyword">=</span><span class="default">func_get_args</span><span class="keyword">();<br />&nbsp; </span><span class="default">call_user_func_array</span><span class="keyword">(array(</span><span class="string">'parent'</span><span class="keyword">,</span><span class="default">__FUNCTION__</span><span class="keyword">),</span><span class="default">$args</span><span class="keyword">);<br /> }<br />&nbsp; </span><span class="comment">// Note: php 5.3.0 will even let you do<br /> </span><span class="keyword">function </span><span class="default">anyMethod</span><span class="keyword">() {<br />&nbsp; </span><span class="comment">//Needs php &gt;=5.3.x<br />&nbsp; </span><span class="default">call_user_func_array</span><span class="keyword">(array(</span><span class="string">'parent'</span><span class="keyword">,</span><span class="default">__FUNCTION__</span><span class="keyword">),</span><span class="default">func_get_args</span><span class="keyword">());<br /> }<br /><br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="84155">  <div class="votes">
    <div id="Vu84155">
    <a href="/manual/vote-note.php?id=84155&amp;page=language.oop5.paamayim-nekudotayim&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd84155">
    <a href="/manual/vote-note.php?id=84155&amp;page=language.oop5.paamayim-nekudotayim&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V84155" title="53% like this...">
    2
    </div>
  </div>
  <a href="#84155" class="name">
  <strong class="user"><em>barss dot dev at gmail dot com</em></strong></a><a class="genanchor" href="#84155"> &para;</a><div class="date" title="2008-07-01 03:47"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom84155">
<div class="phpcode"><code><span class="html">
Nice trick with scope resolution<br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">class </span><span class="default">A<br />&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; public function </span><span class="default">TestFunc</span><span class="keyword">()<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">test</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; class </span><span class="default">B<br />&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; public </span><span class="default">$test</span><span class="keyword">;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">()<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">test </span><span class="keyword">= </span><span class="string">"Nice trick"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; public function </span><span class="default">GetTest</span><span class="keyword">()<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">A</span><span class="keyword">::</span><span class="default">TestFunc</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="default">$b </span><span class="keyword">= new </span><span class="default">B</span><span class="keyword">;<br />&nbsp; &nbsp; echo </span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">GetTest</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span><br />will output<br /><br />Nice trick</span>
</code></div>
  </div>
 </div>
  <div class="note" id="94504">  <div class="votes">
    <div id="Vu94504">
    <a href="/manual/vote-note.php?id=94504&amp;page=language.oop5.paamayim-nekudotayim&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd94504">
    <a href="/manual/vote-note.php?id=94504&amp;page=language.oop5.paamayim-nekudotayim&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V94504" title="51% like this...">
    1
    </div>
  </div>
  <a href="#94504" class="name">
  <strong class="user"><em>wouter at interpotential dot com</em></strong></a><a class="genanchor" href="#94504"> &para;</a><div class="date" title="2009-11-09 07:24"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom94504">
<div class="phpcode"><code><span class="html">
It's worth noting, that the mentioned variable can also be an object instance. This appears to be the easiest way to refer to a static function as high in the inheritance hierarchy as possible, as seen from the instance. I've encountered some odd behavior while using static::something() inside a non-static method.<br /><br />See the following example code:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">FooClass </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">testSelf</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">self</span><span class="keyword">::</span><span class="default">t</span><span class="keyword">();<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">testThis</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">::</span><span class="default">t</span><span class="keyword">();<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public static function </span><span class="default">t</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">'FooClass'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; function </span><span class="default">__toString</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">'FooClass'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">BarClass </span><span class="keyword">extends </span><span class="default">FooClass </span><span class="keyword">{<br />&nbsp; &nbsp; public static function </span><span class="default">t</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">'BarClass'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />}<br /><br /></span><span class="default">$obj </span><span class="keyword">= new </span><span class="default">BarClass</span><span class="keyword">();<br /></span><span class="default">print_r</span><span class="keyword">(Array(<br />&nbsp; &nbsp; </span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">testSelf</span><span class="keyword">(), </span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">testThis</span><span class="keyword">(),<br />));<br /></span><span class="default">?&gt;<br /></span><br />which outputs:<br /><br />&lt;pre&gt;<br />Array<br />(<br />&nbsp; &nbsp; [0] =&gt; FooClass<br />&nbsp; &nbsp; [1] =&gt; BarClass<br />)<br />&lt;/pre&gt;<br /><br />As you can see, __toString has no effect on any of this. Just in case you were wondering if perhaps this was the way it's done.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="88681">  <div class="votes">
    <div id="Vu88681">
    <a href="/manual/vote-note.php?id=88681&amp;page=language.oop5.paamayim-nekudotayim&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd88681">
    <a href="/manual/vote-note.php?id=88681&amp;page=language.oop5.paamayim-nekudotayim&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V88681" title="50% like this...">
    1
    </div>
  </div>
  <a href="#88681" class="name">
  <strong class="user"><em>csaba dot dobai at php-sparcle dot com</em></strong></a><a class="genanchor" href="#88681"> &para;</a><div class="date" title="2009-02-03 09:54"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom88681">
<div class="phpcode"><code><span class="html">
For the 'late static binding' topic I published a code below, that demonstrates a trick for how to setting variable value in the late class, and print that in the parent (or the parent's parent, etc.) class.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">cA<br /></span><span class="keyword">{<br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Test property for using direct default value<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">protected static </span><span class="default">$item </span><span class="keyword">= </span><span class="string">'Foo'</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Test property for using indirect default value<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">protected static </span><span class="default">$other </span><span class="keyword">= </span><span class="string">'cA'</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public static function </span><span class="default">method</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; print </span><span class="default">self</span><span class="keyword">::</span><span class="default">$item</span><span class="keyword">.</span><span class="string">"\r\n"</span><span class="keyword">; </span><span class="comment">// It prints 'Foo' on everyway... :(<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">print </span><span class="default">self</span><span class="keyword">::</span><span class="default">$other</span><span class="keyword">.</span><span class="string">"\r\n"</span><span class="keyword">; </span><span class="comment">// We just think that, this one prints 'cA' only, but... :)<br />&nbsp; &nbsp; </span><span class="keyword">}<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public static function </span><span class="default">setOther</span><span class="keyword">(</span><span class="default">$val</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">$other </span><span class="keyword">= </span><span class="default">$val</span><span class="keyword">; </span><span class="comment">// Set a value in this scope.<br />&nbsp; &nbsp; </span><span class="keyword">}<br />}<br /><br />class </span><span class="default">cB </span><span class="keyword">extends </span><span class="default">cA<br /></span><span class="keyword">{<br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Test property with redefined default value<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">protected static </span><span class="default">$item </span><span class="keyword">= </span><span class="string">'Bar'</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public static function </span><span class="default">setOther</span><span class="keyword">(</span><span class="default">$val</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">self</span><span class="keyword">::</span><span class="default">$other </span><span class="keyword">= </span><span class="default">$val</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">cC </span><span class="keyword">extends </span><span class="default">cA<br /></span><span class="keyword">{<br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Test property with redefined default value<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">protected static </span><span class="default">$item </span><span class="keyword">= </span><span class="string">'Tango'</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public static function </span><span class="default">method</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; print </span><span class="default">self</span><span class="keyword">::</span><span class="default">$item</span><span class="keyword">.</span><span class="string">"\r\n"</span><span class="keyword">; </span><span class="comment">// It prints 'Foo' on everyway... :(<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">print </span><span class="default">self</span><span class="keyword">::</span><span class="default">$other</span><span class="keyword">.</span><span class="string">"\r\n"</span><span class="keyword">; </span><span class="comment">// We just think that, this one prints 'cA' only, but... :)<br />&nbsp; &nbsp; </span><span class="keyword">}<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Now we drop redeclaring the setOther() method, use cA with 'self::' just for fun.<br />&nbsp; &nbsp;&nbsp; */<br /></span><span class="keyword">}<br /><br />class </span><span class="default">cD </span><span class="keyword">extends </span><span class="default">cA<br /></span><span class="keyword">{<br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Test property with redefined default value<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">protected static </span><span class="default">$item </span><span class="keyword">= </span><span class="string">'Foxtrot'</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Now we drop redeclaring all methods to complete this issue.<br />&nbsp; &nbsp;&nbsp; */<br /></span><span class="keyword">}<br /><br /></span><span class="default">cB</span><span class="keyword">::</span><span class="default">setOther</span><span class="keyword">(</span><span class="string">'cB'</span><span class="keyword">); </span><span class="comment">// It's cB::method()!<br /></span><span class="default">cB</span><span class="keyword">::</span><span class="default">method</span><span class="keyword">(); </span><span class="comment">// It's cA::method()!<br /></span><span class="default">cC</span><span class="keyword">::</span><span class="default">setOther</span><span class="keyword">(</span><span class="string">'cC'</span><span class="keyword">); </span><span class="comment">// It's cA::method()!<br /></span><span class="default">cC</span><span class="keyword">::</span><span class="default">method</span><span class="keyword">(); </span><span class="comment">// It's cC::method()!<br /></span><span class="default">cD</span><span class="keyword">::</span><span class="default">setOther</span><span class="keyword">(</span><span class="string">'cD'</span><span class="keyword">); </span><span class="comment">// It's cA::method()!<br /></span><span class="default">cD</span><span class="keyword">::</span><span class="default">method</span><span class="keyword">(); </span><span class="comment">// It's cA::method()!<br /><br />/**<br /> * Results: -&gt;<br /> * Foo<br /> * cB<br /> * Tango<br /> * cC<br /> * Foo<br /> * cD<br /> * <br /> * What the hell?! :)<br /> */<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113376">  <div class="votes">
    <div id="Vu113376">
    <a href="/manual/vote-note.php?id=113376&amp;page=language.oop5.paamayim-nekudotayim&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113376">
    <a href="/manual/vote-note.php?id=113376&amp;page=language.oop5.paamayim-nekudotayim&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113376" title="50% like this...">
    0
    </div>
  </div>
  <a href="#113376" class="name">
  <strong class="user"><em>jasverix at NOSPAM dot gmail dot com</em></strong></a><a class="genanchor" href="#113376"> &para;</a><div class="date" title="2013-10-03 01:25"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113376">
<div class="phpcode"><code><span class="html">
Just found out that using the class name may also work to call similar function of anchestor class.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">Anchestor </span><span class="keyword">{<br />&nbsp;&nbsp; <br />&nbsp;&nbsp; public </span><span class="default">$Prefix </span><span class="keyword">= </span><span class="string">''</span><span class="keyword">;<br /><br />&nbsp;&nbsp; private </span><span class="default">$_string </span><span class="keyword">=&nbsp; </span><span class="string">'Bar'</span><span class="keyword">;<br />&nbsp; &nbsp; public function </span><span class="default">Foo</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">Prefix</span><span class="keyword">.</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">_string</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">MyParent </span><span class="keyword">extends </span><span class="default">Anchestor </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">Foo</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">Prefix </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">parent</span><span class="keyword">::</span><span class="default">Foo</span><span class="keyword">().</span><span class="string">'Baz'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">Child </span><span class="keyword">extends </span><span class="default">MyParent </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">Foo</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">Prefix </span><span class="keyword">= </span><span class="string">'Foo'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">Anchestor</span><span class="keyword">::</span><span class="default">Foo</span><span class="keyword">();<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$c </span><span class="keyword">= new </span><span class="default">Child</span><span class="keyword">();<br />echo </span><span class="default">$c</span><span class="keyword">-&gt;</span><span class="default">Foo</span><span class="keyword">(); </span><span class="comment">//return FooBar, because Prefix, as in Anchestor::Foo()<br /><br /></span><span class="default">?&gt;<br /></span><br />The Child class calls at Anchestor::Foo(), and therefore MyParent::Foo() is never run.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="61174">  <div class="votes">
    <div id="Vu61174">
    <a href="/manual/vote-note.php?id=61174&amp;page=language.oop5.paamayim-nekudotayim&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd61174">
    <a href="/manual/vote-note.php?id=61174&amp;page=language.oop5.paamayim-nekudotayim&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V61174" title="50% like this...">
    0
    </div>
  </div>
  <a href="#61174" class="name">
  <strong class="user"><em>developit at mail dot ru</em></strong></a><a class="genanchor" href="#61174"> &para;</a><div class="date" title="2006-01-27 03:57"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom61174">
<div class="phpcode"><code><span class="html">
You use 'self' to access this class, 'parent' - to access parent class, and what will you do to access a parent of the parent? Or to access the very root class of deep class hierarchy? The answer is to use classnames. That'll work just like 'parent'. Here's an example to explain what I mean. Following code<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">A<br /></span><span class="keyword">{<br />&nbsp; &nbsp; protected </span><span class="default">$x </span><span class="keyword">= </span><span class="string">'A'</span><span class="keyword">;<br />&nbsp; &nbsp; public function </span><span class="default">f</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">'['</span><span class="keyword">.</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">x</span><span class="keyword">.</span><span class="string">']'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">B </span><span class="keyword">extends </span><span class="default">A<br /></span><span class="keyword">{<br />&nbsp; &nbsp; protected </span><span class="default">$x </span><span class="keyword">= </span><span class="string">'B'</span><span class="keyword">;<br />&nbsp; &nbsp; public function </span><span class="default">f</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">'{'</span><span class="keyword">.</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">x</span><span class="keyword">.</span><span class="string">'}'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">C </span><span class="keyword">extends </span><span class="default">B<br /></span><span class="keyword">{<br />&nbsp; &nbsp; protected </span><span class="default">$x </span><span class="keyword">= </span><span class="string">'C'</span><span class="keyword">;<br />&nbsp; &nbsp; public function </span><span class="default">f</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">'('</span><span class="keyword">.</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">x</span><span class="keyword">.</span><span class="string">')'</span><span class="keyword">.</span><span class="default">parent</span><span class="keyword">::</span><span class="default">f</span><span class="keyword">().</span><span class="default">B</span><span class="keyword">::</span><span class="default">f</span><span class="keyword">().</span><span class="default">A</span><span class="keyword">::</span><span class="default">f</span><span class="keyword">();<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">();<br /></span><span class="default">$b </span><span class="keyword">= new </span><span class="default">B</span><span class="keyword">();<br /></span><span class="default">$c </span><span class="keyword">= new </span><span class="default">C</span><span class="keyword">();<br /><br />print </span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">f</span><span class="keyword">().</span><span class="string">'&lt;br/&gt;'</span><span class="keyword">;<br />print </span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">f</span><span class="keyword">().</span><span class="string">'&lt;br/&gt;'</span><span class="keyword">;<br />print </span><span class="default">$c</span><span class="keyword">-&gt;</span><span class="default">f</span><span class="keyword">().</span><span class="string">'&lt;br/&gt;'</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />will output <br /><br />[A] -- {B} -- (C){C}{C}[C]</span>
</code></div>
  </div>
 </div>
  <div class="note" id="73200">  <div class="votes">
    <div id="Vu73200">
    <a href="/manual/vote-note.php?id=73200&amp;page=language.oop5.paamayim-nekudotayim&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd73200">
    <a href="/manual/vote-note.php?id=73200&amp;page=language.oop5.paamayim-nekudotayim&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V73200" title="40% like this...">
    -4
    </div>
  </div>
  <a href="#73200" class="name">
  <strong class="user"><em>mongoose643 at gmail dot com</em></strong></a><a class="genanchor" href="#73200"> &para;</a><div class="date" title="2007-02-13 12:11"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom73200">
<div class="phpcode"><code><span class="html">
This is a solution for those that still need to write code compatible with php 4 but would like to use the flexibility of static variables. PHP 4 does not support static variables within the class scope but it does support them within the scope of class methods. The following is a bit of a workaround to store data in static mode in php 4.<br /><br />Note: This code also works in PHP 5.<br /><br />(Tested on version 4.3.1+)<br /><br />The tricky part is when using when arrays you have to do a bit of fancy coding to get or set individual elements in the array. The example code below should show you the basics of it though.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">StaticSample<br /></span><span class="keyword">{<br />&nbsp; &nbsp; </span><span class="comment">//Copyright Michael White (www.crestidg.com) 2007<br />&nbsp; &nbsp; //You may use and modify this code but please keep this short copyright notice in tact.<br />&nbsp; &nbsp; //If you modify the code you may comment the changes you make and append your own copyright<br />&nbsp; &nbsp; //notice to mine. This code is not to be redistributed individually for sale but please use it as part<br />&nbsp; &nbsp; //of your projects and applications - free or non-free.<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; <br />&nbsp; &nbsp; //Static workaround for php4 - even works with arrays - the trick is accessing the arrays.<br />&nbsp; &nbsp; //I used the format s_varname for my methods that employ this workaround. That keeps it<br />&nbsp; &nbsp; //similar to working with actual variables as much as possible.<br />&nbsp; &nbsp; //The s_ prefix immediately identifies it as a static variable workaround method while<br />&nbsp; &nbsp; //I'm looking thorugh my code.<br />&nbsp; &nbsp; </span><span class="keyword">function &amp;</span><span class="default">s_foo</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">=</span><span class="default">null</span><span class="keyword">, </span><span class="default">$remove</span><span class="keyword">=</span><span class="default">null</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; static </span><span class="default">$s_var</span><span class="keyword">;&nbsp; &nbsp; </span><span class="comment">//Declare the static variable.&nbsp; &nbsp; The name here doesn't matter - only the name of the method matters.<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">if(</span><span class="default">$remove</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$s_var</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; foreach(</span><span class="default">$value </span><span class="keyword">as </span><span class="default">$key </span><span class="keyword">=&gt; </span><span class="default">$data</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; unset(</span><span class="default">$s_var</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//You can't just use unset() here because the static state of the variable will bring back the value next time you call the method.<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$s_var </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; unset(</span><span class="default">$s_var</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//Make sure that you don't set the value over again.<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$value </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">$value</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$s_var</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//$s_var = array_merge($s_var, $value);&nbsp; &nbsp; &nbsp; &nbsp; //Doesn't overwrite values. This adds them - a property of the array_merge() function.<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">foreach(</span><span class="default">$value </span><span class="keyword">as </span><span class="default">$key </span><span class="keyword">=&gt; </span><span class="default">$data</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$s_var</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">] = </span><span class="default">$data</span><span class="keyword">;&nbsp; &nbsp; </span><span class="comment">//Overwrites values.<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">}<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$s_var </span><span class="keyword">= </span><span class="default">$value</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$s_var </span><span class="keyword">= </span><span class="default">$value</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$s_var</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />echo </span><span class="string">"Working with non-array values.&lt;br&gt;"</span><span class="keyword">;<br />echo </span><span class="string">"Before Setting: "</span><span class="keyword">.</span><span class="default">StaticSample</span><span class="keyword">::</span><span class="default">s_foo</span><span class="keyword">();<br />echo </span><span class="string">"&lt;br&gt;"</span><span class="keyword">;<br />echo </span><span class="string">"While Setting: "</span><span class="keyword">.</span><span class="default">StaticSample</span><span class="keyword">::</span><span class="default">s_foo</span><span class="keyword">(</span><span class="string">"VALUE HERE"</span><span class="keyword">);<br />echo </span><span class="string">"&lt;br&gt;"</span><span class="keyword">;<br />echo </span><span class="string">"After Setting: "</span><span class="keyword">.</span><span class="default">StaticSample</span><span class="keyword">::</span><span class="default">s_foo</span><span class="keyword">();<br />echo </span><span class="string">"&lt;br&gt;"</span><span class="keyword">;<br />echo </span><span class="string">"While Removing: "</span><span class="keyword">.</span><span class="default">StaticSample</span><span class="keyword">::</span><span class="default">s_foo</span><span class="keyword">(</span><span class="default">null</span><span class="keyword">, </span><span class="default">1</span><span class="keyword">);<br />echo </span><span class="string">"&lt;br&gt;"</span><span class="keyword">;<br />echo </span><span class="string">"After Removing: "</span><span class="keyword">.</span><span class="default">StaticSample</span><span class="keyword">::</span><span class="default">s_foo</span><span class="keyword">();<br />echo </span><span class="string">"&lt;hr&gt;"</span><span class="keyword">;<br />echo </span><span class="string">"Working with array values&lt;br&gt;"</span><span class="keyword">;<br /></span><span class="default">$array </span><span class="keyword">= array(</span><span class="default">0</span><span class="keyword">=&gt;</span><span class="string">"cat"</span><span class="keyword">, </span><span class="default">1</span><span class="keyword">=&gt;</span><span class="string">"dog"</span><span class="keyword">, </span><span class="default">2</span><span class="keyword">=&gt;</span><span class="string">"monkey"</span><span class="keyword">);<br />echo </span><span class="string">"Set an array value: "</span><span class="keyword">;<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">StaticSample</span><span class="keyword">::</span><span class="default">s_foo</span><span class="keyword">(</span><span class="default">$array</span><span class="keyword">));<br />echo </span><span class="string">"&lt;br&gt;"</span><span class="keyword">;<br /><br /></span><span class="comment">//Here you need to get all the values in the array then sort through or choose the one(s) you want.<br /></span><span class="default">$all_elements </span><span class="keyword">= </span><span class="default">StaticSample</span><span class="keyword">::</span><span class="default">s_foo</span><span class="keyword">();<br /></span><span class="default">$middle_element </span><span class="keyword">= </span><span class="default">$all_elements</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">];<br />echo </span><span class="string">"The middle element: "</span><span class="keyword">.</span><span class="default">$middle_element</span><span class="keyword">;<br />echo </span><span class="string">"&lt;br&gt;"</span><span class="keyword">;<br /><br /></span><span class="default">$changed_array </span><span class="keyword">= array(</span><span class="default">1</span><span class="keyword">=&gt;</span><span class="string">"big dog"</span><span class="keyword">, </span><span class="default">3</span><span class="keyword">=&gt;</span><span class="string">"bat"</span><span class="keyword">, </span><span class="string">"bird"</span><span class="keyword">=&gt;</span><span class="string">"flamingo"</span><span class="keyword">);<br />echo </span><span class="string">"Changing the value: "</span><span class="keyword">;<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">StaticSample</span><span class="keyword">::</span><span class="default">s_foo</span><span class="keyword">(</span><span class="default">$changed_array</span><span class="keyword">));<br />echo </span><span class="string">"&lt;br&gt;"</span><span class="keyword">;<br /><br /></span><span class="comment">//All you have to do here is create an array with the keys you want to erase in it.<br />//If you want to erase all keys then don't pass any array to the method.<br /></span><span class="default">$element_to_erase </span><span class="keyword">= array(</span><span class="default">3</span><span class="keyword">=&gt;</span><span class="default">null</span><span class="keyword">);<br />echo </span><span class="string">"Erasing the fourth element: "</span><span class="keyword">;<br /></span><span class="default">$elements_left </span><span class="keyword">= </span><span class="default">StaticSample</span><span class="keyword">::</span><span class="default">s_foo</span><span class="keyword">(</span><span class="default">$element_to_erase</span><span class="keyword">, </span><span class="default">1</span><span class="keyword">);<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$elements_left</span><span class="keyword">);<br />echo </span><span class="string">"&lt;br&gt;"</span><span class="keyword">;<br />echo </span><span class="string">"Enjoy!"</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.oop5.paamayim-nekudotayim&amp;redirect=http://php.net/manual/en/language.oop5.paamayim-nekudotayim.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.oop5.php">Classes and Objects</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="oop5.intro.php" title="Introduction">Introduction</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.basic.php" title="The Basics">The Basics</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.properties.php" title="Properties">Properties</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.constants.php" title="Class Constants">Class Constants</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.autoload.php" title="Autoloading Classes">Autoloading Classes</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.decon.php" title="Constructors and Destructors">Constructors and Destructors</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.visibility.php" title="Visibility">Visibility</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.inheritance.php" title="Object Inheritance">Object Inheritance</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.oop5.paamayim-nekudotayim.php" title="Scope Resolution Operator (::)">Scope Resolution Operator (::)</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.static.php" title="Static Keyword">Static Keyword</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.abstract.php" title="Class Abstraction">Class Abstraction</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.interfaces.php" title="Object Interfaces">Object Interfaces</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.traits.php" title="Traits">Traits</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.anonymous.php" title="Anonymous classes">Anonymous classes</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.overloading.php" title="Overloading">Overloading</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.iterations.php" title="Object Iteration">Object Iteration</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.magic.php" title="Magic Methods">Magic Methods</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.final.php" title="Final Keyword">Final Keyword</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.cloning.php" title="Object Cloning">Object Cloning</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.object-comparison.php" title="Comparing Objects">Comparing Objects</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.typehinting.php" title="Type Hinting">Type Hinting</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.late-static-bindings.php" title="Late Static Bindings">Late Static Bindings</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.references.php" title="Objects and references">Objects and references</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.serialization.php" title="Object Serialization">Object Serialization</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.changelog.php" title="OOP Changelog">OOP Changelog</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

