<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: $argv - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/reserved.variables.argv.php">
 <link rel="shorturl" href="http://php.net/manual/en/reserved.variables.argv.php">
 <link rel="alternate" href="http://php.net/manual/en/reserved.variables.argv.php" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/reserved.variables.php">
 <link rel="prev" href="http://php.net/manual/en/reserved.variables.argc.php">
 <link rel="next" href="http://php.net/manual/en/reserved.exceptions.php">

 <link rel="alternate" href="http://php.net/manual/en/reserved.variables.argv.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/reserved.variables.argv.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/reserved.variables.argv.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/reserved.variables.argv.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/reserved.variables.argv.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/reserved.variables.argv.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/reserved.variables.argv.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/reserved.variables.argv.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/reserved.variables.argv.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/reserved.variables.argv.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/reserved.variables.argv.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="reserved.exceptions.php">
          Predefined Exceptions &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="reserved.variables.argc.php">
          &laquo; $argc        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='reserved.variables.php'>Predefined Variables</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/reserved.variables.argv.php' selected="selected">English</option>
            <option value='pt_BR/reserved.variables.argv.php'>Brazilian Portuguese</option>
            <option value='zh/reserved.variables.argv.php'>Chinese (Simplified)</option>
            <option value='fr/reserved.variables.argv.php'>French</option>
            <option value='de/reserved.variables.argv.php'>German</option>
            <option value='ja/reserved.variables.argv.php'>Japanese</option>
            <option value='ro/reserved.variables.argv.php'>Romanian</option>
            <option value='ru/reserved.variables.argv.php'>Russian</option>
            <option value='es/reserved.variables.argv.php'>Spanish</option>
            <option value='tr/reserved.variables.argv.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/reserved.variables.argv.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=reserved.variables.argv">Report a Bug</a>
    </div>
  </div><div id="reserved.variables.argv" class="refentry">
 <div class="refnamediv">
  <h1 class="refname">$argv</h1>
  <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">$argv</span> &mdash; <span class="dc-title">Array of arguments passed to script</span></p>

 </div>
 
 <div class="refsect1 description" id="refsect1-reserved.variables.argv-description">
  <h3 class="title">Description</h3>
  <p class="para">
   Contains an <span class="type"><a href="language.types.array.php" class="type array">array</a></span> of all the arguments passed to the script when running
   from the <a href="features.commandline.php" class="link">command line</a>.
  </p>
  <blockquote class="note"><p><strong class="note">Note</strong>: 
   <span class="simpara">
    The first argument <var class="varname"><var class="varname">$argv[0]</var></var> is always the name that was
    used to run the script.
   </span>
  </p></blockquote>
  <blockquote class="note"><p><strong class="note">Note</strong>: 
   <span class="simpara">
    This variable is not available when <a href="ini.core.php#ini.register-argc-argv" class="link">register_argc_argv</a>
    is disabled.
   </span>
  </p></blockquote>
 </div>

 
 <div class="refsect1 examples" id="refsect1-reserved.variables.argv-examples">
  <h3 class="title">Examples</h3>
  <p class="para">
   <div class="example" id="example-304">
    <p><strong>Example #1 <var class="varname"><var class="varname">$argv</var></var> example</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$argv</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

    <div class="example-contents"><p>
     When executing the example with: php script.php arg1 arg2 arg3
    </p></div>
    <div class="example-contents"><p>The above example will output
something similar to:</p></div>
    <div class="example-contents screen">
<div class="cdata"><pre>
array(4) {
  [0]=&gt;
  string(10) &quot;script.php&quot;
  [1]=&gt;
  string(4) &quot;arg1&quot;
  [2]=&gt;
  string(4) &quot;arg2&quot;
  [3]=&gt;
  string(4) &quot;arg3&quot;
}
</pre></div>
    </div>
   </div>
  </p>
 </div>


 <div class="refsect1 notes" id="refsect1-reserved.variables.argv-notes">
  <h3 class="title">Notes</h3>
  <blockquote class="note"><p><strong class="note">Note</strong>: 
   <p class="para">
    This is also available as <var class="varname"><var class="varname"><a href="reserved.variables.server.php" class="classname">$_SERVER['argv']</a></var></var>. 
   </p>
  </p></blockquote>
 </div>

  
 <div class="refsect1 seealso" id="refsect1-reserved.variables.argv-seealso">
  <h3 class="title">See Also</h3>
  <p class="para">
   <ul class="simplelist">
    <li class="member"><span class="function"><a href="function.getopt.php" class="function" rel="rdfs-seeAlso">getopt()</a> - Gets options from the command line argument list</span></li>
    <li class="member"><a href="reserved.variables.argc.php" class="link"><var class="varname"><var class="varname"><a href="reserved.variables.argc.php" class="classname">$argc</a></var></var></a></li>
   </ul>
  </p>
 </div>


</div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=reserved.variables.argv&amp;redirect=http://php.net/manual/en/reserved.variables.argv.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">9 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="105491">  <div class="votes">
    <div id="Vu105491">
    <a href="/manual/vote-note.php?id=105491&amp;page=reserved.variables.argv&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd105491">
    <a href="/manual/vote-note.php?id=105491&amp;page=reserved.variables.argv&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V105491" title="69% like this...">
    60
    </div>
  </div>
  <a href="#105491" class="name">
  <strong class="user"><em>tufan dot oezduman at googlemail dot com</em></strong></a><a class="genanchor" href="#105491"> &para;</a><div class="date" title="2011-08-22 09:06"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom105491">
<div class="phpcode"><code><span class="html">
Please note that, $argv and $argc need to be declared global, while trying to access within a class method. <br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">A<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public static function </span><span class="default">b</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$argv</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(isset(</span><span class="default">$argv</span><span class="keyword">));<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">A</span><span class="keyword">::</span><span class="default">b</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span><br />will output NULL bool(false)&nbsp; with a notice of "Undefined variable ..."<br /><br />whereas global $argv fixes that.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113614">  <div class="votes">
    <div id="Vu113614">
    <a href="/manual/vote-note.php?id=113614&amp;page=reserved.variables.argv&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113614">
    <a href="/manual/vote-note.php?id=113614&amp;page=reserved.variables.argv&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113614" title="67% like this...">
    30
    </div>
  </div>
  <a href="#113614" class="name">
  <strong class="user"><em>hamboy75 at example dot com</em></strong></a><a class="genanchor" href="#113614"> &para;</a><div class="date" title="2013-11-05 03:20"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113614">
<div class="phpcode"><code><span class="html">
To use $_GET so you dont need to support both if it could be used from command line and from web browser.<br /><br />foreach ($argv as $arg) {<br />&nbsp; &nbsp; $e=explode("=",$arg);<br />&nbsp; &nbsp; if(count($e)==2)<br />&nbsp; &nbsp; &nbsp; &nbsp; $_GET[$e[0]]=$e[1];<br />&nbsp; &nbsp; else&nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; $_GET[$e[0]]=0;<br />}</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118368">  <div class="votes">
    <div id="Vu118368">
    <a href="/manual/vote-note.php?id=118368&amp;page=reserved.variables.argv&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118368">
    <a href="/manual/vote-note.php?id=118368&amp;page=reserved.variables.argv&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118368" title="60% like this...">
    3
    </div>
  </div>
  <a href="#118368" class="name">
  <strong class="user"><em>php at simoneast dot net</em></strong></a><a class="genanchor" href="#118368"> &para;</a><div class="date" title="2015-11-24 07:24"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom118368">
<div class="phpcode"><code><span class="html">
Sometimes $argv can be null, such as when "register-argc-argv" is set to false.&nbsp; In some cases I've found the variable is populated correctly when running "php-cli" instead of just "php" from the command line (or cron).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121693">  <div class="votes">
    <div id="Vu121693">
    <a href="/manual/vote-note.php?id=121693&amp;page=reserved.variables.argv&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121693">
    <a href="/manual/vote-note.php?id=121693&amp;page=reserved.variables.argv&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121693" title="0% like this...">
    -1
    </div>
  </div>
  <a href="#121693" class="name">
  <strong class="user"><em>Andreas</em></strong></a><a class="genanchor" href="#121693"> &para;</a><div class="date" title="2017-09-27 04:22"><strong>2 months ago</strong></div>
  <div class="text" id="Hcom121693">
<div class="phpcode"><code><span class="html">
How to check if one parameter is given:<br /><br />if ($argc &lt; 2 )<br />{<br />&nbsp; &nbsp; exit( "Usage: program &lt;parameter1&gt;\n" );<br />}<br /><br />process( $argv[1] );</span>
</code></div>
  </div>
 </div>
  <div class="note" id="93532">  <div class="votes">
    <div id="Vu93532">
    <a href="/manual/vote-note.php?id=93532&amp;page=reserved.variables.argv&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd93532">
    <a href="/manual/vote-note.php?id=93532&amp;page=reserved.variables.argv&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V93532" title="50% like this...">
    0
    </div>
  </div>
  <a href="#93532" class="name">
  <strong class="user"><em>Steve Schmitt</em></strong></a><a class="genanchor" href="#93532"> &para;</a><div class="date" title="2009-09-14 04:57"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom93532">
<div class="phpcode"><code><span class="html">
If you come from a shell scripting background, you might expect to find this topic under the heading "positional parameters".</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120658">  <div class="votes">
    <div id="Vu120658">
    <a href="/manual/vote-note.php?id=120658&amp;page=reserved.variables.argv&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120658">
    <a href="/manual/vote-note.php?id=120658&amp;page=reserved.variables.argv&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120658" title="28% like this...">
    -3
    </div>
  </div>
  <a href="#120658" class="name">
  <strong class="user"><em>andrew w</em></strong></a><a class="genanchor" href="#120658"> &para;</a><div class="date" title="2017-02-17 02:04"><strong>9 months ago</strong></div>
  <div class="text" id="Hcom120658">
<div class="phpcode"><code><span class="html">
An easier way to populate $_GET with $argv values.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">if ( isset( </span><span class="default">$argv </span><span class="keyword">) ) {<br />&nbsp; &nbsp; </span><span class="default">parse_str</span><span class="keyword">(<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">join</span><span class="keyword">( </span><span class="string">"&amp;"</span><span class="keyword">, </span><span class="default">array_slice</span><span class="keyword">( </span><span class="default">$argv</span><span class="keyword">, </span><span class="default">1 </span><span class="keyword">)<br />&nbsp; &nbsp; ), </span><span class="default">$_GET </span><span class="keyword">);<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118803">  <div class="votes">
    <div id="Vu118803">
    <a href="/manual/vote-note.php?id=118803&amp;page=reserved.variables.argv&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118803">
    <a href="/manual/vote-note.php?id=118803&amp;page=reserved.variables.argv&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118803" title="28% like this...">
    -14
    </div>
  </div>
  <a href="#118803" class="name">
  <strong class="user"><em>fabio at naoimporta dot com</em></strong></a><a class="genanchor" href="#118803"> &para;</a><div class="date" title="2016-02-08 11:41"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom118803">
<div class="phpcode"><code><span class="html">
When you pass an option to the file that intercept the request, it will be transformed into an array item, and the option name will be lost. Only its content is captured.<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; var_dump</span><span class="keyword">(</span><span class="default">$argv</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />call&nbsp; :&nbsp; "php file.php --test=foo baz"<br /><br />will print<br /><br />array(3) {<br />&nbsp; [0] =&gt;<br />&nbsp; string(16) "file.php"<br />&nbsp; [1] =&gt;<br />&nbsp; string(3) "foo"<br />&nbsp; [2] =&gt;<br />&nbsp; string(3) "baz"<br />}</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117264">  <div class="votes">
    <div id="Vu117264">
    <a href="/manual/vote-note.php?id=117264&amp;page=reserved.variables.argv&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117264">
    <a href="/manual/vote-note.php?id=117264&amp;page=reserved.variables.argv&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117264" title="24% like this...">
    -19
    </div>
  </div>
  <a href="#117264" class="name">
  <strong class="user"><em>KRowe</em></strong></a><a class="genanchor" href="#117264"> &para;</a><div class="date" title="2015-05-12 09:55"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117264">
<div class="phpcode"><code><span class="html">
Improves on hamboy75's note by providing better support for positional arguments:<br /><br />&nbsp; &nbsp; foreach ($argv as $arg) {<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; $e=explode("=",$arg);<br />&nbsp; &nbsp; &nbsp; &nbsp; if(count($e)==2)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $_GET[$e[0]]=$e[1];<br />&nbsp; &nbsp; &nbsp; &nbsp; else&nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $_GET[]=$e[0];<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; var_dump($_GET);<br /><br />Using this modification, arguments without an = are treated as positional (this is not web standard but generally works).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="111256">  <div class="votes">
    <div id="Vu111256">
    <a href="/manual/vote-note.php?id=111256&amp;page=reserved.variables.argv&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd111256">
    <a href="/manual/vote-note.php?id=111256&amp;page=reserved.variables.argv&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V111256" title="18% like this...">
    -93
    </div>
  </div>
  <a href="#111256" class="name">
  <strong class="user"><em>Jesse</em></strong></a><a class="genanchor" href="#111256"> &para;</a><div class="date" title="2013-01-30 11:55"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom111256">
<div class="phpcode"><code><span class="html">
If your script is read from standard input or with the -r option, $argv[0] will be "-".<br /><br />If you use the "--" option to separate PHP's arguments from your script's arguments, $argv[1] will be "--" if your script is read from a file. But if your script is read from standard input or with the -r option, the "--" will be removed.</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=reserved.variables.argv&amp;redirect=http://php.net/manual/en/reserved.variables.argv.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="reserved.variables.php">Predefined Variables</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.variables.superglobals.php" title="Superglobals">Superglobals</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.globals.php" title="$GLOBALS">$GLOBALS</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.server.php" title="$_&#8203;SERVER">$_&#8203;SERVER</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.get.php" title="$_&#8203;GET">$_&#8203;GET</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.post.php" title="$_&#8203;POST">$_&#8203;POST</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.files.php" title="$_&#8203;FILES">$_&#8203;FILES</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.request.php" title="$_&#8203;REQUEST">$_&#8203;REQUEST</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.session.php" title="$_&#8203;SESSION">$_&#8203;SESSION</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.environment.php" title="$_&#8203;ENV">$_&#8203;ENV</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.cookies.php" title="$_&#8203;COOKIE">$_&#8203;COOKIE</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.phperrormsg.php" title="$php_&#8203;errormsg">$php_&#8203;errormsg</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.httprawpostdata.php" title="$HTTP_&#8203;RAW_&#8203;POST_&#8203;DATA">$HTTP_&#8203;RAW_&#8203;POST_&#8203;DATA</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.httpresponseheader.php" title="$http_&#8203;response_&#8203;header">$http_&#8203;response_&#8203;header</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.argc.php" title="$argc">$argc</a>
                        </li>
                          
                        <li class="current">
                            <a href="reserved.variables.argv.php" title="$argv">$argv</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

