<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: News Archive - 2017</title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/archive/2017.php">
 <link rel="shorturl" href="http://php.net/archive/2017">
 <link rel="alternate" href="http://php.net/archive/2017" hreflang="x-default">



<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/archive/2017.php">

</head>
<body class=" ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class=""><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>





<div id="layout" class="clearfix">
  <section id="layout-content">

<h1>News Archive - 2017</h1>

<p>
 Here are the most important news items we have published in 2017 on PHP.net.
</p>

<hr>

<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-11-30-1" href="http://php.net/archive/2017.php#id2017-11-30-1" rel="bookmark" class="bookmark">PHP 7.2.0 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-11-30T10:04:21+00:00">30 Nov 2017</time>
  <div class="newscontent">
    <div>

	<p>The PHP development team announces the immediate availability of PHP 7.2.0.
	This release marks the second feature update to the PHP 7 series.</p>

	<p>PHP 7.2.0 comes with numerous improvements and new features such as</p>

	<ul>
	<li><a href="https://wiki.php.net/rfc/convert_numeric_keys_in_object_array_casts">Convert numeric keys in object/array casts</a></li>
	<li><a href="https://wiki.php.net/rfc/counting_non_countables">Counting of non-countable objects</a></li>
	<li><a href="https://wiki.php.net/rfc/object-typehint">Object typehint</a></li>
	<li><a href="https://wiki.php.net/rfc/hash-context.as-resource">HashContext as Object</a></li>
	<li><a href="https://wiki.php.net/rfc/argon2_password_hash">Argon2 in password hash</a></li>
	<li><a href="https://wiki.php.net/rfc/improved-tls-constants">Improve TLS constants to sane values</a></li>
	<li><a href="https://wiki.php.net/rfc/mcrypt-viking-funeral">Mcrypt extension removed</a></li>
	<li><a href="https://wiki.php.net/rfc/libsodium">New sodium extension</a></li>
	</ul>

	<p>For source downloads of PHP 7.2.0 please visit our <a href="http://www.php.net/downloads">downloads</a> page
	Windows binaries can be found on the <a href="http://windows.php.net/download">PHP for Windows</a> site.
	The list of changes is recorded in the <a href="http://www.php.net/ChangeLog-7.php#7.2.0">ChangeLog</a>.</p>

	<p>The <a href="http://php.net/manual/en/migration72.php">migration guide</a> is available in the PHP Manual.
	Please consult it for the detailed list of new features and backward incompatible changes.</p>

	<p>Many thanks to all the contributors and supporters!</p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-11-24-1" href="http://php.net/archive/2017.php#id2017-11-24-1" rel="bookmark" class="bookmark">PHP 7.1.12 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-11-24T06:02:50+00:00">24 Nov 2017</time>
  <div class="newscontent">
    <div>
       <p>The PHP development team announces the immediate availability of PHP
       7.1.12. This is a bugfix release, with several bug fixes included.
     
       All PHP 7.1 users are encouraged to upgrade to this version.
       </p>
     
       <p>For source downloads of PHP 7.1.12 please visit our <a href="http://www.php.net/downloads.php">downloads page</a>,
       Windows source and binaries can be found on <a href="http://windows.php.net/download/">windows.php.net/download/</a>.
       The list of changes is recorded in the <a href="http://www.php.net/ChangeLog-7.php#7.1.12">ChangeLog</a>.
       </p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-11-23-2" href="http://php.net/archive/2017.php#id2017-11-23-2" rel="bookmark" class="bookmark">PHP 7.0.26 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-11-23T13:00:00+01:00">23 Nov 2017</time>
  <div class="newscontent">
    <div xmlns="http://www.w3.org/2099/xhtml">
      <p>The PHP development team announces the immediate availability of PHP
      7.0.26. Several bugs have been fixed.
     
      All PHP 7.0 users are encouraged to upgrade to this version.
      </p>
     
      <p>For source downloads of PHP 7.0.26 please visit our <a href="http://www.php.net/downloads.php">downloads page</a>,
      Windows source and binaries can be found on <a href="http://windows.php.net/download/">windows.php.net/download/</a>.
      The list of changes is recorded in the <a href="http://www.php.net/ChangeLog-7.php#7.0.26">ChangeLog</a>.
      </p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"><a href="https://tek.phparch.com/"><img src="http://php.net//images/news/tek-basic.png" alt="php[tek] 2018" width="300" height="100" style="float: right;"></a></div>
    <h2 class="newstitle"><a id="id2017-11-20-1" href="https://tek.phparch.com/" rel="bookmark" class="bookmark">php[tek] 2018 : Call for Speakers</a></h2>
  </header>
  <time class="newsdate" datetime="2017-11-20T21:55:38+00:00">20 Nov 2017</time>
  <div class="newscontent">
    <div>
     The 13th annual edition of <a href="https://tek.phparch.com/?paref=phpnet&amp;utm_campaign=phpnet">php[tek]</a>, the longest running community focused PHP conference in the USA, will be taking place May 30 - June 1, 2018 in Atlanta, with workshop and training days preceeding it. We have opened up our <a href="https://tek.phparch.com/call-for-speakers/?paref=phpnet&amp;utm_campaign=phpnet">Call for Speakers</a> and look forward to seeing all the amazing proposals that you will submit to us.
     
     As always we plan on offering a broad range of topics with our attendees. We are interested in any topics related to PHP development, as well as non-technical talks that will appeal to a developer heavy audience!
     
     Our comprehensive speaker's package this year includes:
     
     - A free conference ticket
     - Round-trip economy airfare booked by us
     - Accommodations at the conference hotel:
       - 3 nights for speakers
       - 4 nights for workshop presenters
       - 5 nights for training class teachers
     
     Don't hesitate, the <a href="https://tek.phparch.com/call-for-speakers/?paref=phpnet&amp;utm_campaign=phpnet">Call for Speakers</a> is only open until December 29th, 2017. So get those submissions in soon, we look forward to hearing from you!
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-11-09-1" href="http://php.net/archive/2017.php#id2017-11-09-1" rel="bookmark" class="bookmark">PHP 7.2.0RC6 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-11-09T13:57:49+00:00">09 Nov 2017</time>
  <div class="newscontent">
    <div>
     <p>
     The PHP development team announces the immediate availability of PHP 7.2.0 RC6.
     This release is the sixth Release Candidate for 7.2.0.
     Barring any surprises, <b>we expect this to be the FINAL release candidate</b>,
     with Nov 30th's GA release being not-substantially different.
     All users of PHP are encouraged to test this version carefully, and report any bugs
     and incompatibilities in the <a href="https://bugs.php.net/">bug tracking system</a>.
     </p>

     <p><strong>THIS IS A DEVELOPMENT PREVIEW - DO NOT USE IT IN PRODUCTION!</strong></p>

     <p>
     For more information on the new features and other changes, you can read the
     <a href="https://github.com/php/php-src/blob/php-7.2.0RC6/NEWS">NEWS</a> file,
     or the <a href="https://github.com/php/php-src/blob/php-7.2.0RC6/UPGRADING">UPGRADING</a>
     file for a complete list of upgrading notes. These files can also be found in the release archive.
     </p>

     <p>
     For source downloads of PHP 7.2.0 Release Candidate 6 please visit the
     <a href="https://downloads.php.net/~pollita/">download</a> page,
     Windows sources and binaries can be found at
     <a href="http://windows.php.net/qa/">windows.php.net/qa/</a>.
     </p>

     <p>Thank you for helping us make PHP better.</p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"><a href="http://sunshinephp.com"><img src="http://php.net//images/news/sunshinephp2018.png" alt="SunshinePHP 2018" width="300" height="104" style="float: right;"></a></div>
    <h2 class="newstitle"><a id="id2017-11-08-1" href="http://sunshinephp.com" rel="bookmark" class="bookmark">SunshinePHP 2018 Conference</a></h2>
  </header>
  <time class="newsdate" datetime="2017-11-08T00:00:01+00:00">08 Nov 2017</time>
  <div class="newscontent">
    <div>
			<p>In February 2018 come to Miami, Florida and escape the cold to learn more about PHP and speak with other developers, like you, to see what others are doing. The <a href="http://sunshinephp.com/speakers" title="SunshinePHP 2018 Speaker List">SunshinePHP 2018 speaker list</a> has been announced, and we've assembled a great line-up with the most current PHP related topics for you.</p>

			<p>Topics include:</p>

			<ul>
				<li>Middleware</li>
				<li>Security</li>
				<li>API Development</li>
				<li>DevOps</li>
				<li>Continuous Delivery</li>
				<li>Databases</li>
				<li>Javascript</li>
				<li>PHP Core</li>
				<li>UI/UX</li>
				<li>Frameworks</li>
				<li>Scalability</li>
				<li>Team Development</li>
			</ul>

			<p>Come celebrate our 6th year from February 8th to 10th, 2018 in sunny Miami, Florida. There will be a full tutorial day featuring 3-hour sessions followed by 2 days of 1-hour talks and inspirational keynotes.</p>

			<p>Register now! <a href="http://sunshinephp.com/register" title="SunshinePHP">SunshinePHP.com</a></p>
		</div>
	
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"><a href="https://callforpapers.sandsmedia.com"><img src="http://php.net//images/news/ipc-2018.png" alt="International PHP Conference Spring Edition 2018 - Call for Papers" width="200" height="118" style="float: right;"></a></div>
    <h2 class="newstitle"><a id="id2017-11-06-1" href="https://callforpapers.sandsmedia.com" rel="bookmark" class="bookmark">International PHP Conference Spring Edition 2018  - Call for Papers</a></h2>
  </header>
  <time class="newsdate" datetime="2017-11-06T11:44:54-04:00">06 Nov 2017</time>
  <div class="newscontent">
    <p xmlns="http://www.w3.org/2005/Atom">The International PHP Conference is the world's first PHP conference and stands since more than a decade for top-notch pragmatic expertise in PHP and web technologies. At the IPC, internationally renowned experts from the PHP industry meet up with PHP users and developers from large and small companies. Here is the place where concepts emerge and ideas are born - the IPC signifies knowledge transfer at highest level.</p>
	<p xmlns="http://www.w3.org/2005/Atom">All delegates of the International PHP Conference have, in addition to PHP program, free access to the entire range of the <a href="https://webinale.de">webinale</a> taking place at the same time.</p>
	<p xmlns="http://www.w3.org/2005/Atom"><strong>THE BASIC FACTS</strong></p>
	<ul xmlns="http://www.w3.org/2005/Atom">
	  <li>Date: June 4-8, 2018</li>
	  <li>Location: Maritim ProArte Hotel, Berlin</li>
  	  <li>Main Conference: June 5-7, 2018</li>
	  <li>Workshop Days: June 4 and 8</li>
	  <li>Deadline for submissions: 22 November 2017</li>
	  <li>URL for submissions: <a href="https://callforpapers.sandsmedia.com">https://callforpapers.sandsmedia.com</a></li>
	</ul>
	<p xmlns="http://www.w3.org/2005/Atom">Please see the spectrum of topics we'd like to see covered:</p>
	<ul xmlns="http://www.w3.org/2005/Atom">
	<li>PHP Development</li>
	<li>Web Development</li>
	<li>Web Architecture</li>
	<li>Server &amp; Deployment</li>
	<li>Agile &amp; DevOps</li>
	<li>Performance &amp; Security</li>
	<li>Data &amp; Privacy</li>
	</ul>
	<p xmlns="http://www.w3.org/2005/Atom">We are looking forward to your exciting submissions! For further information on International PHP Conference's sessions and speakers visit: <a href="https://phpconference.com">www.phpconference.com</a></p>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-10-27-1" href="http://php.net/archive/2017.php#id2017-10-27-1" rel="bookmark" class="bookmark">PHP 7.1.11 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-10-27T05:52:49+00:00">27 Oct 2017</time>
  <div class="newscontent">
    <div>
       <p>The PHP development team announces the immediate availability of PHP
       7.1.11. This is a bugfix release, with several bug fixes included.
     
       All PHP 7.1 users are encouraged to upgrade to this version.
       </p>
     
       <p>For source downloads of PHP 7.1.11 please visit our <a href="http://www.php.net/downloads.php">downloads page</a>,
       Windows source and binaries can be found on <a href="http://windows.php.net/download/">windows.php.net/download/</a>.
       The list of changes is recorded in the <a href="http://www.php.net/ChangeLog-7.php#7.1.11">ChangeLog</a>.
       </p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-10-26-3" href="http://php.net/archive/2017.php#id2017-10-26-3" rel="bookmark" class="bookmark">PHP 5.6.32 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-10-26T13:32:22-07:00">26 Oct 2017</time>
  <div class="newscontent">
    <div>
     <p>The PHP development team announces the immediate availability of PHP
     5.6.32. This is a security release. Several security bugs were fixed in
     this release.

     All PHP 5.6 users are encouraged to upgrade to this version.</p>

     <p>For source downloads of PHP 5.6.32 please visit our <a href="http://www.php.net/downloads.php">downloads page</a>,
     Windows source and binaries can be found on <a href="http://windows.php.net/download/">windows.php.net/download/</a>.
     The list of changes is recorded in the <a href="http://www.php.net/ChangeLog-5.php#5.6.32">ChangeLog</a>.
     </p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-10-26-2" href="http://php.net/archive/2017.php#id2017-10-26-2" rel="bookmark" class="bookmark">PHP 7.2.0 Release Candidate 5 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-10-26T16:26:36+00:00">26 Oct 2017</time>
  <div class="newscontent">
    <div>
     <p>
     The PHP development team announces the immediate availability of PHP 7.2.0 RC5.
     This release is the fifth Release Candidate for 7.2.0.
     All users of PHP are encouraged to test this version carefully, and report any bugs
     and incompatibilities in the <a href="https://bugs.php.net/">bug tracking system</a>.
     </p>

     <p><strong>THIS IS A DEVELOPMENT PREVIEW - DO NOT USE IT IN PRODUCTION!</strong></p>

     <p>
     For more information on the new features and other changes, you can read the
     <a href="https://github.com/php/php-src/blob/php-7.2.0RC5/NEWS">NEWS</a> file,
     or the <a href="https://github.com/php/php-src/blob/php-7.2.0RC5/UPGRADING">UPGRADING</a>
     file for a complete list of upgrading notes. These files can also be found in the release archive.
     </p>

     <p>
     For source downloads of PHP 7.2.0 Release Candidate 5 please visit the
     <a href="https://downloads.php.net/~pollita/">download</a> page,
     Windows sources and binaries can be found at
     <a href="http://windows.php.net/qa/">windows.php.net/qa/</a>.
     </p>

     <p>
     The next Release Candidate will be announced on the 9th of November.
     You can also read the full list of planned releases on
     <a href="https://wiki.php.net/todo/php72">our wiki</a>.
     </p>

     <p>Thank you for helping us make PHP better.</p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-10-26-1" href="http://php.net/archive/2017.php#id2017-10-26-1" rel="bookmark" class="bookmark">PHP 7.0.25 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-10-26T13:00:00+01:00">26 Oct 2017</time>
  <div class="newscontent">
    <div>
     <p>The PHP development team announces the immediate availability of PHP
     7.0.25. This is a security release. Several security bugs were fixed in
     this release.
     
     All PHP 7.0 users are encouraged to upgrade to this version.</p>
     
     <p>For source downloads of PHP 7.0.25 please visit our <a href="http://www.php.net/downloads.php">downloads page</a>,
     Windows source and binaries can be found on <a href="http://windows.php.net/download/">windows.php.net/download/</a>.
     The list of changes is recorded in the <a href="http://www.php.net/ChangeLog-7.php#7.0.25">ChangeLog</a>.
     </p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"><a href="https://conference.scotlandphp.co.uk/"><img src="http://php.net//images/news/scot417.png" alt="ScotlandPHP" width="400" height="250" style="float: right;"></a></div>
    <h2 class="newstitle"><a id="id2017-10-19-1" href="https://conference.scotlandphp.co.uk/" rel="bookmark" class="bookmark">ScotlandPHP</a></h2>
  </header>
  <time class="newsdate" datetime="2017-10-19T17:46:40+00:00">19 Oct 2017</time>
  <div class="newscontent">
    <div>
     <p>Scotland's Original and Best PHP Conference</p>
     <p>Saturday 4th November 2017, EICC, Edinburgh</p>
     
     <p>2 Tracks, 14 World Class Speakers, 2 Social Events, 1 Amazing Day!</p>
     
     <ul>
     <li>Josh Holmes MICROSOFT - Opening Keynote: “Rise of the Machines”</li>
     <li>Adam Culp ZEND  - “Clean Application Development”</li>
     <li>Amanda Folson NEXMO - “Open Source for Closed Source Companies”</li>
     <li>Ciaran McNulty INVIQA - “Behat Best Practices”</li>
     <li>Christian Lück CONSULTANT  - “Pushing the Limits of PHP with ReactPHP”</li>
     <li>Craig McCreath MTC - “Refactoring Large Legacy Applications with Laravel”</li>
     <li>Dave Stokes ORACLE - “MySQL 8: A New Beginning”</li>
     <li>David McKay CONSULTANT - “What even is ‘Cloud Native’?”</li>
     <li>Matt Brunt VIVA IT - “Content Security Policies: Let's Break Stuff”</li>
     <li>Renato Mefi ENRISE - “GraphQL is right in front of us, let's do it!”</li>
     <li>Seb Heuer KARTENMACHEREI  - ”The Myth of Untestable Code”</li>
     <li>Terrence Ryan GOOGLE  - “Containing Chaos with Kubernetes”</li>
     <li>Thomas Shone BOOKING.COM - ”Security Theatre: The State of Online Security”</li>
     <li>Meri Williams MOO.COM  - Closing Keynote: “Creating Space to be Awesome”</li>
     </ul>
     
     <p><a href="https://conference.scotlandphp.co.uk">More Information...</a></p>
     
     <p>Follow us on twitter: <a href="https://www.twitter.com/scotlandphp">@scotlandphp</a></p>
     
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-10-12-1" href="http://php.net/archive/2017.php#id2017-10-12-1" rel="bookmark" class="bookmark">PHP 7.2.0 Release Candidate 4 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-10-12T11:46:49+02:00">12 Oct 2017</time>
  <div class="newscontent">
    <div>
     <p>
     The PHP development team announces the immediate availability of PHP 7.2.0 RC4.
     This release is the fourth Release Candidate for 7.2.0.
     All users of PHP are encouraged to test this version carefully, and report any bugs
     and incompatibilities in the <a href="https://bugs.php.net/">bug tracking system</a>.
     </p>
     
     <p><strong>THIS IS A DEVELOPMENT PREVIEW - DO NOT USE IT IN PRODUCTION!</strong></p>
     
     <p>
     For more information on the new features and other changes, you can read the
     <a href="https://github.com/php/php-src/blob/php-7.2.0RC4/NEWS">NEWS</a> file,
     or the <a href="https://github.com/php/php-src/blob/php-7.2.0RC4/UPGRADING">UPGRADING</a>
     file for a complete list of upgrading notes. These files can also be found in the release archive.
     </p>
     
     <p>
     For source downloads of PHP 7.2.0 Release Candidate 4 please visit the
     <a href="https://downloads.php.net/~remi/">download</a> page,
     Windows sources and binaries can be found at
     <a href="http://windows.php.net/qa/">windows.php.net/qa/</a>.
     </p>
     
     <p>
     The next Release Candidate will be announced on the 26th of October.
     You can also read the full list of planned releases on
     <a href="https://wiki.php.net/todo/php72">our wiki</a>.
     </p>
     
     <p>Thank you for helping us make PHP better.</p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-09-29-1" href="http://php.net/archive/2017.php#id2017-09-29-1" rel="bookmark" class="bookmark">PHP 7.1.10 Release Announcement</a></h2>
  </header>
  <time class="newsdate" datetime="2017-09-29T08:10:14+00:00">29 Sep 2017</time>
  <div class="newscontent">
    <div>
       <p>The PHP development team announces the immediate availability of PHP
       7.1.10. This is a bugfix release, with several bug fixes included.
     
       All PHP 7.1 users are encouraged to upgrade to this version.
       </p>
     
       <p>For source downloads of PHP 7.1.10 please visit our <a href="http://www.php.net/downloads.php">downloads page</a>,
       Windows source and binaries can be found on <a href="http://windows.php.net/download/">windows.php.net/download/</a>.
       The list of changes is recorded in the <a href="http://www.php.net/ChangeLog-7.php#7.1.10">ChangeLog</a>.
       </p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-09-28-2" href="http://php.net/archive/2017.php#id2017-09-28-2" rel="bookmark" class="bookmark">PHP 7.2.0 Release Candidate 3 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-09-28T12:58:56+02:00">28 Sep 2017</time>
  <div class="newscontent">
    <div>
     <p>
     The PHP development team announces the immediate availability of PHP 7.2.0 RC3.
     This release is the third Release Candidate for 7.2.0.
     All users of PHP are encouraged to test this version carefully, and report any bugs
     and incompatibilities in the <a href="https://bugs.php.net/">bug tracking system</a>.
     </p>
     
     <p><strong>THIS IS A DEVELOPMENT PREVIEW - DO NOT USE IT IN PRODUCTION!</strong></p>
     
     <p>
     For more information on the new features and other changes, you can read the
     <a href="https://github.com/php/php-src/blob/php-7.2.0RC3/NEWS">NEWS</a> file,
     or the <a href="https://github.com/php/php-src/blob/php-7.2.0RC3/UPGRADING">UPGRADING</a>
     file for a complete list of upgrading notes. These files can also be found in the release archive.
     </p>
     
     <p>
     For source downloads of PHP 7.2.0 Release Candidate 3 please visit the
     <a href="https://downloads.php.net/~remi/">download</a> page,
     Windows sources and binaries can be found at
     <a href="http://windows.php.net/qa/">windows.php.net/qa/</a>.
     </p>
     
     <p>
     The next Release Candidate will be announced on the 12th of October.
     You can also read the full list of planned releases on
     <a href="https://wiki.php.net/todo/php72">our wiki</a>.
     </p>
     
     <p>Thank you for helping us make PHP better.</p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-09-28-2" href="http://php.net/archive/2017.php#id2017-09-28-2" rel="bookmark" class="bookmark">PHP 7.0.24 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-09-28T13:00:00+01:00">28 Sep 2017</time>
  <div class="newscontent">
    <div xmlns="http://www.w3.org/2099/xhtml">
      <p>The PHP development team announces the immediate availability of PHP
      7.0.24. Several bugs have been fixed.
     
      All PHP 7.0 users are encouraged to upgrade to this version.
      </p>
     
      <p>For source downloads of PHP 7.0.24 please visit our <a href="http://www.php.net/downloads.php">downloads page</a>,
      Windows source and binaries can be found on <a href="http://windows.php.net/download/">windows.php.net/download/</a>.
      The list of changes is recorded in the <a href="http://www.php.net/ChangeLog-7.php#7.0.24">ChangeLog</a>.
      </p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-09-14-1" href="http://php.net/archive/2017.php#id2017-09-14-1" rel="bookmark" class="bookmark">PHP 7.2.0 Release Candidate 2 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-09-14T16:07:16+00:00">14 Sep 2017</time>
  <div class="newscontent">
    <div>
     <p>
     The PHP development team announces the immediate availability of PHP 7.2.0 RC2.
     This release is the second Release Candidate for 7.2.0.
     All users of PHP are encouraged to test this version carefully, and report any bugs
     and incompatibilities in the <a href="https://bugs.php.net/">bug tracking system</a>.
     </p>
     
     <p><strong>THIS IS A DEVELOPMENT PREVIEW - DO NOT USE IT IN PRODUCTION!</strong></p>
     
     <p>
     For more information on the new features and other changes, you can read the
     <a href="https://github.com/php/php-src/blob/php-7.2.0RC2/NEWS">NEWS</a> file,
     or the <a href="https://github.com/php/php-src/blob/php-7.2.0RC2/UPGRADING">UPGRADING</a>
     file for a complete list of upgrading notes. These files can also be found in the release archive.
     </p>
     
     <p>
     For source downloads of PHP 7.2.0 Release Candidate 2 please visit the
     <a href="https://downloads.php.net/~pollita/">download</a> page,
     Windows sources and binaries can be found at
     <a href="http://windows.php.net/qa/">windows.php.net/qa/</a>.
     </p>
     
     <p>
     The next Release Candidate will be announced on the 28th of September.
     You can also read the full list of planned releases on
     <a href="https://wiki.php.net/todo/php72">our wiki</a>.
     </p>
     
     <p>Thank you for helping us make PHP better.</p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"><a href="http://conference.phpnw.org.uk/phpnw17/"><img src="http://php.net//images/news/phpnw17.png" alt="PHP North West 2017 (PHPNW17)" width="300" height="213" style="float: right;"></a></div>
    <h2 class="newstitle"><a id="id2017-09-13-1" href="http://conference.phpnw.org.uk/phpnw17/" rel="bookmark" class="bookmark">PHP North West 2017 (PHPNW17)</a></h2>
  </header>
  <time class="newsdate" datetime="2017-09-13T19:00:00+00:00">13 Sep 2017</time>
  <div class="newscontent">
    <div>
	    <p>One of the largest and most popular PHP Conferences in Europe, <a href="http://conference.phpnw.org.uk/phpnw17/">PHPNW17</a> is a long-running community-based conference, held in Manchester, UK and run on a not-for-profit basis. It is overwhelmingly supported by industry leaders, code experts, web developers and businesses across the world. This year, we are celebrating our 10th conference year, and we aim to be bigger and better than ever before.</p>
     
	    <p>The PHPNW Conference has a reputation within the PHP community as a "go to" conference due to its inspiring content, friendly atmosphere and networking opportunities. Our delegates come to our Conference because they are specifically interested in new technologies and ways to improve their skills through our tutorials and talks, as well as the awesome (unofficial) corridor track!</p>
     
	    <p>The conference starts with a <a href="http://conference.phpnw.org.uk/phpnw17/tutorial-day/">tutorial day</a> on 29th September 2017, followed by a <a href="http://conference.phpnw.org.uk/phpnw17/schedule/">three-track conference</a> on the Saturday (30th September) and Sunday (1st October). As an additional bonus we have a populare Unconference running alongside the other three tracks on the Saturday.</p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-09-01-1" href="http://php.net/archive/2017.php#id2017-09-01-1" rel="bookmark" class="bookmark">PHP 7.1.9 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-09-01T06:31:35+00:00">01 Sep 2017</time>
  <div class="newscontent">
    <div>
       <p>The PHP development team announces the immediate availability of PHP
       7.1.9. This is a bugfix release, with several bug fixes included.
     
       All PHP 7.1 users are encouraged to upgrade to this version.
       </p>
     
       <p>For source downloads of PHP 7.1.9 please visit our <a href="http://www.php.net/downloads.php">downloads page</a>,
       Windows source and binaries can be found on <a href="http://windows.php.net/download/">windows.php.net/download/</a>.
       The list of changes is recorded in the <a href="http://www.php.net/ChangeLog-7.php#7.1.9">ChangeLog</a>.
       </p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-08-31-1" href="http://php.net/archive/2017.php#id2017-08-31-1" rel="bookmark" class="bookmark">PHP 7.2.0 Release Candidate 1 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-08-31T10:53:58+02:00">31 Aug 2017</time>
  <div class="newscontent">
    <div>
      <p>
      The PHP development team announces the immediate availability of PHP 7.2.0 Release
      Candidate 1. This release is the first Release Candidate for 7.2.0.
      All users of PHP are encouraged to test this version carefully, and report any bugs
      and incompatibilities in the <a href="https://bugs.php.net/">bug tracking system</a>.
      </p>

      <p><strong>THIS IS A DEVELOPMENT PREVIEW - DO NOT USE IT IN PRODUCTION!</strong></p>

      <p>
      For more information on the new features and other changes, you can read the
      <a href="https://github.com/php/php-src/blob/php-7.2.0RC1/NEWS">NEWS</a> file,
      or the <a href="https://github.com/php/php-src/blob/php-7.2.0RC1/UPGRADING">UPGRADING</a>
      file for a complete list of upgrading notes. These files can also be found in the release archive.
      </p>

      <p>
      For source downloads of PHP 7.2.0 Release Candidate 1 please visit the
      <a href="https://downloads.php.net/~remi/">download</a> page,
      Windows sources and binaries can be found at
      <a href="http://windows.php.net/qa/">windows.php.net/qa/</a>.
      </p>

      <p>
      The second Release Candidate will be released on the 14th of September.
      You can also read the full list of planned releases on
      <a href="https://wiki.php.net/todo/php72">our wiki</a>.
      </p>

      <p>Thank you for helping us make PHP better.</p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-08-31-2" href="http://php.net/archive/2017.php#id2017-08-31-2" rel="bookmark" class="bookmark">PHP 7.0.23 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-08-31T13:00:00+01:00">31 Aug 2017</time>
  <div class="newscontent">
    <div xmlns="http://www.w3.org/2099/xhtml">
      <p>The PHP development team announces the immediate availability of PHP
      7.0.23. Several bugs have been fixed.
     
      All PHP 7.0 users are encouraged to upgrade to this version.
      </p>
     
      <p>For source downloads of PHP 7.0.23 please visit our <a href="http://www.php.net/downloads.php">downloads page</a>,
      Windows source and binaries can be found on <a href="http://windows.php.net/download/">windows.php.net/download/</a>.
      The list of changes is recorded in the <a href="http://www.php.net/ChangeLog-7.php#7.0.23">ChangeLog</a>.
      </p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-08-17-1" href="http://php.net/archive/2017.php#id2017-08-17-1" rel="bookmark" class="bookmark">PHP 7.2.0 Beta 3 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-08-17T10:17:44+02:00">17 Aug 2017</time>
  <div class="newscontent">
    <div>
      <p>
      The PHP development team announces the immediate availability of PHP 7.2.0 Beta 3.
      This release is the third and final beta for 7.2.0. All users of PHP are encouraged
      to test this version carefully, and report any bugs and incompatibilities in the
      <a href="https://bugs.php.net/">bug tracking system</a>.
      </p>

      <p><strong>THIS IS A DEVELOPMENT PREVIEW - DO NOT USE IT IN PRODUCTION!</strong></p>

      <p>
      For more information on the new features and other changes, you can read the
      <a href="https://github.com/php/php-src/blob/php-7.2.0beta3/NEWS">NEWS</a> file,
      or the <a href="https://github.com/php/php-src/blob/php-7.2.0beta3/UPGRADING">UPGRADING</a>
      file for a complete list of upgrading notes. These files can also be found in the release archive.
      </p>

      <p>
      For source downloads of PHP 7.2.0 Beta 3 please visit the
      <a href="https://downloads.php.net/~remi/">download</a> page,
      Windows sources and binaries can be found at
      <a href="http://windows.php.net/qa/">windows.php.net/qa/</a>.
      </p>

      <p>
      The first Release Candidate will be released on the 31th of August.
      You can also read the full list of planned releases on
      <a href="https://wiki.php.net/todo/php72">our wiki</a>.
      </p>

      <p>Thank you for helping us make PHP better.</p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"><a href="http://sunshinephp.com"><img src="http://php.net//images/news/sunshinephp2018.png" alt="SunshinePHP 2018" width="300" height="104" style="float: right;"></a></div>
    <h2 class="newstitle"><a id="id2017-08-16-1" href="http://sunshinephp.com" rel="bookmark" class="bookmark">SunshinePHP 2018 CFP Started</a></h2>
  </header>
  <time class="newsdate" datetime="2017-08-16T00:00:01+00:00">16 Aug 2017</time>
  <div class="newscontent">
    <div>
			<p>We are happy to announce the CFP for SunshinePHP 2018 has launched at <a href="https://cfp.sunshinephp.com" title="SunshinePHP CFP">https://cfp.sunshinephp.com</a> where we will accept talk submissions until September 30th, 2017.</p>

			<p>SunshinePHP hit it's 6th year and will happen from February 8th to 10th, 2018 in sunny Miami, Florida. As one of the largest community conferences in the U.S. there is no doubt the schedule will be amazing this year. We will have a full tutorial day featuring 3-hour sessions followed by 2 days of 1-hour talks and inspirational keynotes.</p>

			<p>Ticket sales will start soon at <a href="http://sunshinephp.com/register" title="SunshinePHP">SunshinePHP.com</a></p>
		</div>
	
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"><a href="https://2018.midwestphp.org"><img src="http://php.net//images/news/midwest-php-logo.png" alt="Midwest PHP Conference" width="647" height="571" style="float: right;"></a></div>
    <h2 class="newstitle"><a id="id2017-08-13-1" href="https://2018.midwestphp.org" rel="bookmark" class="bookmark">Midwest PHP Call for Papers</a></h2>
  </header>
  <time class="newsdate" datetime="2017-08-13T19:56:28+00:00">13 Aug 2017</time>
  <div class="newscontent">
    <div>
      <p>The <a href="https://www.meetup.com/mn-php">Minnesota PHP User Group</a> is proud to announce that the Call for Papers for the Midwest PHP 2018 Conference is now open through November 20, 2017. Abstracts can be submitted to <a href="https://cfp.midwestphp.org">https://cfp.midwestphp.org</a>. Whether you are a seasoned speaker or someone just looking to speak at your first conference, we want to see your submissions.</p>

      <p>This year's speaker package includes:
        <ul>
          <li>Full conference pass</li>
          <li>Speaker dinner the night before the conference</li>
          <li>Lunch, receptions, and activities included in regular conference</li>
          <li>Complimentary airfare/travel</li>
          <li>Two complimentary hotel nights</li>
        </ul>
     </p>

      <p>The Midwest PHP conference will be held at the Radisson Blu located within Mall of America in Bloomington, MN on March 9th and 10th. For more information about the venue and conference visit <a href="https://2018.midwestphp.org">2018.midwestphp.org</a>.</p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-08-03-3" href="http://php.net/archive/2017.php#id2017-08-03-3" rel="bookmark" class="bookmark">PHP 7.1.8 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-08-03T14:35:42+00:00">03 Aug 2017</time>
  <div class="newscontent">
    <div>
       <p>The PHP development team announces the immediate availability of PHP
       7.1.8. This is a bugfix release, with several bug fixes included.
     
       All PHP 7.1 users are encouraged to upgrade to this version.
       </p>
     
       <p>For source downloads of PHP 7.1.8 please visit our <a href="http://www.php.net/downloads.php">downloads page</a>,
       Windows source and binaries can be found on <a href="http://windows.php.net/download/">windows.php.net/download/</a>.
       The list of changes is recorded in the <a href="http://www.php.net/ChangeLog-7.php#7.1.8">ChangeLog</a>.
       </p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-08-03-2" href="http://php.net/archive/2017.php#id2017-08-03-2" rel="bookmark" class="bookmark">PHP 7.2.0 Beta 2 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-08-03T12:48:35+00:00">03 Aug 2017</time>
  <div class="newscontent">
    <div>
      <p>
      The PHP development team announces the immediate availability of PHP 7.2.0 Beta 2.
      This release is the second beta for 7.2.0. All users of PHP are encouraged to test this
      version carefully, and report any bugs and incompatibilities in the
      <a href="https://bugs.php.net/">bug tracking system</a>.
      </p>

      <p><strong>THIS IS A DEVELOPMENT PREVIEW - DO NOT USE IT IN PRODUCTION!</strong></p>

      <p>
      For more information on the new features and other changes, you can read the
      <a href="https://github.com/php/php-src/blob/php-7.2.0beta2/NEWS">NEWS</a> file,
      or the <a href="https://github.com/php/php-src/blob/php-7.2.0beta2/UPGRADING">UPGRADING</a>
      file for a complete list of upgrading notes. These files can also be found in the release archive.
      </p>

      <p>
      For source downloads of PHP 7.2.0 Beta 2 please visit the
      <a href="https://downloads.php.net/~pollita/">download</a> page,
      Windows sources and binaries can be found at
      <a href="http://windows.php.net/qa/">windows.php.net/qa/</a>.
      </p>

      <p>
      The third and final beta will be released on the 17th of August.
      You can also read the full list of planned releases on
      <a href="https://wiki.php.net/todo/php72">our wiki</a>.
      </p>

      <p>Thank you for helping us make PHP better.</p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-08-03-1" href="http://php.net/archive/2017.php#id2017-08-03-1" rel="bookmark" class="bookmark">PHP 7.0.22 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-08-03T13:00:00+01:00">03 Aug 2017</time>
  <div class="newscontent">
    <div xmlns="http://www.w3.org/2099/xhtml">
      <p>The PHP development team announces the immediate availability of PHP
      7.0.22. Several bugs have been fixed.
     
      All PHP 7.0 users are encouraged to upgrade to this version.
      </p>
     
      <p>For source downloads of PHP 7.0.22 please visit our <a href="http://www.php.net/downloads.php">downloads page</a>,
      Windows source and binaries can be found on <a href="http://windows.php.net/download/">windows.php.net/download/</a>.
      The list of changes is recorded in the <a href="http://www.php.net/ChangeLog-7.php#7.0.22">ChangeLog</a>.
      </p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"><a href="https://cfp.phpbenelux.eu/?utm_source=php_net&utm_medium=phpbnl18_logo&utm_campaign=phpbnl18&utm_term=php%2Bconference%2Bcfp&utm_content=cfp_announcement"><img src="http://php.net//images/news/phpbnl18_logo_horizontal.png" alt="PHPBenelux Conference 2018 - CfP open" width="250" height="66" style="float: right;"></a></div>
    <h2 class="newstitle"><a id="id2017-07-31-1" href="https://cfp.phpbenelux.eu/?utm_source=php_net&utm_medium=phpbnl18_logo&utm_campaign=phpbnl18&utm_term=php%2Bconference%2Bcfp&utm_content=cfp_announcement" rel="bookmark" class="bookmark">Calling all proposals for PHPBenelux Conference 2018</a></h2>
  </header>
  <time class="newsdate" datetime="2017-07-31T11:25:07+02:00">31 Jul 2017</time>
  <div class="newscontent">
    <div>
        <p>PHPBenelux Conference is an annual PHP oriented conference in Antwerp, Belgium and will take place on January 26 &amp; 27 2018. We offer two days of stellar tutorials and talks, epic social events and a lineup of the best local and international businesses involved with PHP.</p>
      <p>We like to invite speakers to submit their tutorials and talks at <a href="https://cfp.phpbenelux.eu/?utm_source=php_net&amp;utm_medium=phpbnl18_logo&amp;utm_campaign=phpbnl18&amp;utm_term=php%2Bconference%2Bcfp&amp;utm_content=cfp_announcement" tel="via" type="text/html">PHPBenelux CfP</a>. Speakers have until Monday, October 2, 2017 to submit their proposals.</p>
      <p>Follow us on <a href="https://twitter.com/intent/follow?user_id=18799269" rel="via" type="text/html">Twitter</a> or like us on <a href="https://www.facebook.com/PHPBenelux-194314644038733/" rel="via" type="text/html">Facebook</a> to stay updated with news from the PHPBenelux crew.</p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-07-20-1" href="http://php.net/archive/2017.php#id2017-07-20-1" rel="bookmark" class="bookmark">PHP 7.2.0 Beta 1 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-07-20T12:00:00+00:00">20 Jul 2017</time>
  <div class="newscontent">
    <div>
     <p>
     The PHP development team announces the immediate availability of PHP 7.2.0 Beta 1.
     This release is the first beta for 7.2.0. All users of PHP are encouraged to test this
     version carefully, and report any bugs and incompatibilities in the
     <a href="https://bugs.php.net/">bug tracking system</a>.
     </p>

     <p><strong>THIS IS A DEVELOPMENT PREVIEW - DO NOT USE IT IN PRODUCTION!</strong></p>

     <p>PHP 7.2.0 Beta 1 builds on previous releases with:</p>

     <ul>
       <li>The much anticipated Sodium extension</li>
       <li>Opcache improvements</li>
       <li>Countable support for DOMNodeList and DOMNamedNodeMap</li>
       <li>Improved handling for invalid UTF8 in json_decode()</li>
       <li>And many bugfixes...</li>
     </ul>

     <p>
     For more information on the new features and other changes, you can read the
     <a href="https://github.com/php/php-src/blob/php-7.2.0beta1/NEWS">NEWS</a> file,
     or the <a href="https://github.com/php/php-src/blob/php-7.2.0beta1/UPGRADING">UPGRADING</a>
     file for a complete list of upgrading notes. These files can also be found in the release archive.
     </p>

     <p>
     For source downloads of PHP 7.2.0 Beta 1 please visit the
     <a href="https://downloads.php.net/~pollita/">download</a> page,
     Windows sources and binaries can be found at
     <a href="http://windows.php.net/qa/">windows.php.net/qa/</a>.
     </p>

     <p>
     The second beta will be released on the 3rd of August.
     You can also read the full list of planned releases on
     <a href="https://wiki.php.net/todo/php72">our wiki</a>.
     </p>

     <p>Thank you for helping us make PHP better.</p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"><a href="https://world.phparch.com/?paref=phpnet&utm_campaign=phpnet"><img src="http://php.net//images/news/phpworld.2017.web.png" alt="php[world] 2017" width="400" height="173" style="float: right;"></a></div>
    <h2 class="newstitle"><a id="id2017-07-10-1" href="https://world.phparch.com/?paref=phpnet&utm_campaign=phpnet" rel="bookmark" class="bookmark">php[world] 2017</a></h2>
  </header>
  <time class="newsdate" datetime="2017-07-10T17:14:04-04:00">10 Jul 2017</time>
  <div class="newscontent">
    <div>
     <p>From the publishers of <a href="https://www.phparch.com">php[architect] magazine</a> comes the <a href="https://world.phparch.com/?paref=phpnet&amp;utm_campaign=phpnet">4th annual php[world] conference</a>!  As always this November in the Washington D.C. area.</p>
     
     <p>This year a number of changes have been made based upon attendee feedback, the biggest being an over 50% a drop in cost, with <a href="https://world.phparch.com/register?paref=phpnet&amp;utm_campaign=phpnet">tickets available</a> now as low as $325.  The conference also is now just 2 days long, running on November 15th &amp; 16th, and includes workshops as well as regular sessions.</p>
     
     <p>Monday &amp; Tuesday before the conference are filled with multiple full-day training classes taught by experts in their fields.</p>
     
     <p>Overall we received amazing submissions to the Call for Speakers and the <a href="https://world.phparch.com/schedule?paref=phpnet&amp;utm_campaign=phpnet">schedule this year</a> we believe to be one of our best yet.  Don't miss out on the highly reduced cost this year!  We look forward to seeing everyone in D.C. this fall for an amazing 2 days of <a href="https://world.phparch.com/schedule?paref=phpnet&amp;utm_campaign=phpnet">professional PHP content</a> at the best price around.</p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"><a href="https://2017.phpce.eu/"><img src="http://php.net//images/news/phpce-logo.png" alt="phpCE.eu" width="247" height="77" style="float: right;"></a></div>
    <h2 class="newstitle"><a id="id2017-07-07-1" href="https://2017.phpce.eu/" rel="bookmark" class="bookmark">php Central Europe Conference 2017</a></h2>
  </header>
  <time class="newsdate" datetime="2017-07-07T00:04:38+02:00">07 Jul 2017</time>
  <div class="newscontent">
    <div>
     <p><a href="https://2017.phpce.eu/">phpCE</a> is a first edition of the community conference for PHP programmers and enthusiasts. The meeting was stablished by merging two nation-wide events: PHPCon Poland and Brno PHP Conference. This edition will take place in the Ossa Congress &amp; Spa Hotel near Rawa Mazowicka, Poland on November 3rd - 5th.</p>
     <p>The unique feature of the php Central Europe Conference is three-path split of agenda, according to difficulty level of talks: Relaxing, Intermediate and Geek. Submitting a talk you must point a proper level and suggest the Program Committee, which one do you prefer. In general, talks given in the Relaxing path should be done in native language of hosting country (Polish this year).</p>
     <p>We strongly encourage potential speakers to submit more than one submission on more than one topic. The more submissions you contribute, the more options you give us to pick you. Be sure your talk title and abstract define the exact topic you want to talk about and what you hope people will learn from the session. In previous years, some submissions sounded interesting but we just didn't have enough detail for them to make the final cut.</p>
     <p>php Central Europe Conference is not limited to just PHP-related talks. There have been sessions covering a wide range of topics supporting PHP developers and DevOps as well, and we encourage you to "think outside the box" to come up with your own unique topics. To get the ideas flowing, here's a few suggestions:</p>
     <ul>
     <li>APIs (REST, SOAP, etc.),</li>
     <li>Case Study,</li>
     <li>Continuous Delivery,</li>
     <li>Database,</li>
     <li>Design Approach,</li>
     <li>Development and Maintennance,</li>
     <li>Devops Life,</li>
     <li>Frameworks and CMSes,</li>
     <li>PHP Involved Technologies,</li>
     <li>Project Management, Team Building,</li>
     <li>Profiling and Performance,</li>
     <li>Security,</li>
     <li>Testing,</li>
     <li>UI/UX,</li>
     <li>Upstream,</li>
     <li>and other.</li>
     </ul>
     <p>When the Call for Papers closes, the organizers will sort through the submissions, making their selections. Speakers will be notified as soon as the selection process has been completed.</p>
     <p>Our speaker package for this year's event includes:</p>
     <ul>
     <li>Full conference pass,</li>
     <li>2 complimentary hotel nights,</li>
     <li>Additional complimentary night (Thu/Fri) for speakers who decide to attend in our Opening Day for Speakers,</li>
     <li>100% reimbursement of airfare/travel costs for international speakers (arriving outside Poland),</li>
     <li>Lunch, dinner, receptions and all other activities included in regular conference,</li>
     <li>We'll pick you up and drop you off to/from the airport so you don't have to worry about it.</li>
     </ul>
     <p>For further information on the php Central Europe 2017 Conference visit: <a href="https://2017.phpce.eu/">2017.phpce.eu</a>.</p>
     <p>Direct link to Call for Papers is: <a href="https://cfp.phpce.eu/">cfp.phpce.eu</a>.</p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-07-06-4" href="http://php.net/archive/2017.php#id2017-07-06-4" rel="bookmark" class="bookmark">PHP 5.6.31 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-07-06T15:03:21-07:00">06 Jul 2017</time>
  <div class="newscontent">
    <div>
     <p>The PHP development team announces the immediate availability of PHP
     5.6.31. This is a security release. Several security bugs were fixed in
     this release.

     All PHP 5.6 users are encouraged to upgrade to this version.</p>

     <p>For source downloads of PHP 5.6.31 please visit our <a href="http://www.php.net/downloads.php">downloads page</a>,
     Windows source and binaries can be found on <a href="http://windows.php.net/download/">windows.php.net/download/</a>.
     The list of changes is recorded in the <a href="http://www.php.net/ChangeLog-5.php#5.6.31">ChangeLog</a>.
     </p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-07-06-3" href="http://php.net/archive/2017.php#id2017-07-06-3" rel="bookmark" class="bookmark">PHP 7.1.7 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-07-06T17:35:10+00:00">06 Jul 2017</time>
  <div class="newscontent">
    <div>
       <p>The PHP development team announces the immediate availability of PHP
       7.1.7. This is a security release with several bug fixes included.

       All PHP 7.1 users are encouraged to upgrade to this version.
       </p>

       <p>For source downloads of PHP 7.1.7 please visit our <a href="http://www.php.net/downloads.php">downloads page</a>,
       Windows source and binaries can be found on <a href="http://windows.php.net/download/">windows.php.net/download/</a>.
       The list of changes is recorded in the <a href="http://www.php.net/ChangeLog-7.php#7.1.7">ChangeLog</a>.
       </p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-07-06-2" href="http://php.net/archive/2017.php#id2017-07-06-2" rel="bookmark" class="bookmark">PHP 7.2.0 Alpha 3 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-07-06T12:25:08+02:00">06 Jul 2017</time>
  <div class="newscontent">
    <div>
     <p>The PHP development team announces the immediate availability of PHP 7.2.0 Alpha 3.
     This release contains fixes and improvements relative to Alpha 2.
     All users of PHP are encouraged to test this version carefully,
     and report any bugs and incompatibilities in the
     <a href="https://bugs.php.net/">bug tracking system</a>.</p>

     <p><strong>THIS IS A DEVELOPMENT PREVIEW - DO NOT USE IT IN PRODUCTION!</strong></p>

     <p>For information on new features and other changes, you can read the
     <a href="https://github.com/php/php-src/blob/php-7.2.0alpha3/NEWS">NEWS</a> file,
     or the <a href="https://github.com/php/php-src/blob/php-7.2.0alpha3/UPGRADING">UPGRADING</a> file
     for a complete list of upgrading notes. These files can also be found in the release archive.</p>

     <p>For source downloads of PHP 7.2.0 Alpha 3 please visit the <a href="https://downloads.php.net/~remi/">download</a> page,
     Windows sources and binaries can be found on <a href="http://windows.php.net/qa/">windows.php.net/qa/</a>.</p>

     <p>The first beta will be released on the 20th of July. You can also read the full list of planned releases on our
     <a href="https://wiki.php.net/todo/php72#timetable">wiki</a>.</p>

     <p>Thank you for helping us make PHP better.</p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-07-06-1" href="http://php.net/archive/2017.php#id2017-07-06-1" rel="bookmark" class="bookmark">PHP 7.0.21 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-07-06T13:00:00+01:00">06 Jul 2017</time>
  <div class="newscontent">
    <div>
     <p>The PHP development team announces the immediate availability of PHP
     7.0.21. This is a security release. Several security bugs were fixed in
     this release.
     
     All PHP 7.0 users are encouraged to upgrade to this version.</p>
     
     <p>For source downloads of PHP 7.0.21 please visit our <a href="http://www.php.net/downloads.php">downloads page</a>,
     Windows source and binaries can be found on <a href="http://windows.php.net/download/">windows.php.net/download/</a>.
     The list of changes is recorded in the <a href="http://www.php.net/ChangeLog-7.php#7.0.21">ChangeLog</a>.
     </p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"><a href="http://phpug-dresden.org/en/phpdd17.html"><img src="http://php.net//images/news/phpdd17.png" alt="PHP Developer Day 2017 in Dresden, Germany" width="250" height="73" style="float: right;"></a></div>
    <h2 class="newstitle"><a id="id2017-06-29-1" href="http://phpug-dresden.org/en/phpdd17.html" rel="bookmark" class="bookmark">PHP Developer Day 2017</a></h2>
  </header>
  <time class="newsdate" datetime="2017-06-29T17:24:31+02:00">29 Jun 2017</time>
  <div class="newscontent">
    <div>
     <p>
         The PHP USERGROUP DRESDEN e.V. invites you to the beautiful city of Dresden, Germany for the 3rd annual PHP Developer Day.
     </p>
     <p>
         We have 6 talks covering the following topics:
     </p>
     <ul>
         <li>Managing the PHP toolchain</li>
         <li>Middleware Web APIs in PHP 7.x</li>
         <li>PostgreSQL as a NoSQL database</li>
         <li>Event Sourcing</li>
         <li>Prooph components</li>
         <li>ReactPHP</li>
     </ul>
     <p>
         Just like the past two events in 2015 and 2016 top talks, free exchange of knowledge, community and fun are the focus of the event.
     </p>
     <p>
         Come along on <strong>SEPTEMBER 22nd at DRESDNER VOLKSHAUS, SCHÜTZENPLATZ 14 in DRESDEN, GERMANY</strong>
     </p>
     <p>
         For more information visit our website at <a href="http://phpug-dresden.org/en/phpdd17.html" target="_blank">http://phpug-dresden.org/en/phpdd17.html</a>
     </p>
     <p>
         We're looking forward to see you!
     </p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-06-23-1" href="http://php.net/archive/2017.php#id2017-06-23-1" rel="bookmark" class="bookmark">Forum PHP 2017</a></h2>
  </header>
  <time class="newsdate" datetime="2017-06-23T14:33:24+00:00">23 Jun 2017</time>
  <div class="newscontent">
    <div>
     <p>Forum PHP 2017 will take place on Oct. 26 &amp; 27th</p>
     
     <p> This year, Forum PHP welcomes you in Marriott Rive Gauche, Conference Center, 17 Boulevard Saint-Jacques, 75014
         Paris, France. <br/>
     
     The annual conference organized by AFUP, the French PHP-users group, gathering all PHP and Open Source communities,
     pros and PHP lovers.
     </p>
     
     <p> <a href="http://event.afup.org">http://event.afup.org</a> </p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-06-22-1" href="http://php.net/archive/2017.php#id2017-06-22-1" rel="bookmark" class="bookmark">PHP 7.2.0 Alpha 2 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-06-22T11:00:00+00:00">22 Jun 2017</time>
  <div class="newscontent">
    <div>
     <p>The PHP development team announces the immediate availability of PHP 7.2.0 Alpha 2.
     This release contains fixes and improvements relative to Alpha 1.
     All users of PHP are encouraged to test this version carefully,
     and report any bugs and incompatibilities in the
     <a href="https://bugs.php.net/">bug tracking system</a>.</p>

     <p><strong>THIS IS A DEVELOPMENT PREVIEW - DO NOT USE IT IN PRODUCTION!</strong></p>

     <p>For information on new features and other changes, you can read the
     <a href="https://github.com/php/php-src/blob/php-7.2.0alpha2/NEWS">NEWS</a> file,
     or the <a href="https://github.com/php/php-src/blob/php-7.2.0alpha2/UPGRADING">UPGRADING</a> file
     for a complete list of upgrading notes. These files can also be found in the release archive.</p>

     <p>For source downloads of PHP 7.2.0 Alpha 2 please visit the <a href="https://downloads.php.net/~pollita/">download</a> page,
     Windows sources and binaries can be found on <a href="http://windows.php.net/qa/">windows.php.net/qa/</a>.</p>

     <p>The third and final alpha will be released on the 6th of July. You can also read the full list of planned releases on our
     <a href="https://wiki.php.net/todo/php72#timetable">wiki</a>.</p>

     <p>Thank you for helping us make PHP better.</p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"><a href="https://laravelconf.tw/"><img src="http://php.net//images/news/laravelConfTaiwan_2017.png" alt="LaravelConf Taiwan 2017" width="250" height="250" style="float: right;"></a></div>
    <h2 class="newstitle"><a id="id2017-06-17-1" href="https://laravelconf.tw/" rel="bookmark" class="bookmark">LaravelConf Taiwan 2017</a></h2>
  </header>
  <time class="newsdate" datetime="2017-06-17T18:48:00+00:00">17 Jun 2017</time>
  <div class="newscontent">
    <div>
     <p>The first Laravel conference in Taiwan awaits you at LaravelConf Taiwan 2017 at Taipei, Taiwan.</p>
     <p><a href="https://laravelconf.tw/">LaravelConf Taiwan 2017</a> is for anyone who is passionate about building web-application, or anyone who is trying to make better experience on teamwork.</p>
     <br/>
     <p>LaravelConf Taiwan 2017 brings Laravel developers and enthusiasts together and hosts one workshop, one case study and 12 sessions in multi-track conference on 29th, June to 1st, July 2017.</p>
     <p>The workshop on the 29th, June 2017 is for hand-on training of beginners in Laravel.</p>
     <p>The main sessions and case study takes place on the 1st, July 2017.</p>
    <br/>
    <p><b>Our focus this year are:</b></p>
    <ul>
        <li>Laravel core concepts</li>
        <li>More fluent teamwork by using Laravel</li>
    </ul>
    <br/>
    <p>Come to enjoy the knowledge and socialize with other Laravel artisan.</p>
    <br/>
    <p>For more infromation: <a href="https://laravelconf.tw/">https://laravelconf.tw</a></p>
    <p>Our facebook page: <a href="https://www.facebook.com/laravelconftw/">https://www.facebook.com/laravelconftw</a></p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"><a href="http://zendcon.com"><img src="http://php.net//images/news/zendcon2017.png" alt="ZendCon 2017" width="305" height="113" style="float: right;"></a></div>
    <h2 class="newstitle"><a id="id2017-06-14-1" href="http://zendcon.com" rel="bookmark" class="bookmark">ZendCon 2017</a></h2>
  </header>
  <time class="newsdate" datetime="2017-06-14T00:00:01+00:00">14 Jun 2017</time>
  <div class="newscontent">
    <div>

			<p>With over 250 million PHP applications driven by a global community of more than 5 million active developers and all enterprises adopting open source software, ZendCon 2017 brings you a curated selection of the best experts, training, and networking opportunities to embrace this vast ecosystem.</p>

			<p>Take advantage of unique opportunities to attend a wide variety of in-depth technical sessions, participate in exhibit hall activities, and connect with experts. Learn about the best in enterprise PHP and open source development, focusing on the latest for PHP 7, the evolution of frameworks and tools, API excellence, and innovation on many open source technologies related to the web.</p>

			<p>Experience web development with the very best to accelerate great PHP.</p>

			<p>Come and enjoy ZendCon 2017 at the Hard Rock Hotel &amp; Casino in Las Vegas.</p>

			<p>Register Now at <a href="http://www.zendcon.com/register-now" title="ZendCon 2017">http://www.zendcon.com/register-now</a></p>
		</div>
	
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"><a href="https://phpconference.com"><img src="http://php.net//images/news/ipc-2017-fall.png" alt="International PHP Conference 2017 - fall edition" width="200" height="130" style="float: right;"></a></div>
    <h2 class="newstitle"><a id="id2017-06-09-1" href="https://phpconference.com" rel="bookmark" class="bookmark">International PHP Conference 2017 - fall edition</a></h2>
  </header>
  <time class="newsdate" datetime="2017-06-09T09:54:24+01:00">09 Jun 2017</time>
  <div class="newscontent">
    <div>
		<p><a href="https://phpconference.com">The International PHP Conference</a>  is the world's first PHP conference and stands since more than a decade for top-notch pragmatic expertise in PHP and web technologies. At the IPC, internationally renowned experts from the PHP industry meet up with PHP users and developers from large and small companies. Here is the place where concepts emerge and ideas are born - the IPC signifies knowledge transfer at highest level.</p>
		<p>All delegates of the International PHP Conference have, in addition to PHP program, free access to the entire range of the <a href="https://javascript-conference.com">International JavaScript Conference</a> taking place at the same time.</p>
		<p>Basic facts:</p>
		<p><strong>Date: October 23 - 27, 2017</strong></p>
		<p><strong>Location: Holiday Inn Munich City Centre, Munich</strong></p>
		<p>Highlights:</p>
		<ul>
			<li>90+ best practice sessions</li>
			<li>60+ international top speakers</li>
			<li>PHPower: Hands-on Power Workshops</li>
			<li>Expo with exciting exhibitors on October 24th &amp; 25th</li>
			<li>Conference Combo: Visit the <a href="https://javascript-conference.com">International JavaScript Conference</a> for free</li>
			<li>All inclusive: Changing buffets, snacks &amp; refreshing drinks</li>
			<li>Official certificate for attendees</li>
			<li>Free Swag: Developer bag, T-Shirt, magazines etc.</li>
			<li>Exclusive networking events</li>			
		</ul>
		<p>Topics:</p>
		<ul>
			<li>PHP Development</li>
			<li>Testing &amp; Quality</li>
			<li>Web Architecture</li>
			<li>DevOps</li>
			<li>Server &amp; Deployment</li>
			<li>Web Development</li>		
		</ul>	
		<p>For further information on the International PHP Conference visit: <a href="https://phpconference.com">www.phpconference.com</a></p>
	  </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-06-08-3" href="http://php.net/archive/2017.php#id2017-06-08-3" rel="bookmark" class="bookmark">PHP 7.1.6 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-06-08T19:40:06+00:00">08 Jun 2017</time>
  <div class="newscontent">
    <p xmlns="http://www.w3.org/2005/Atom">The PHP development team announces the immediate availability of PHP
      7.1.6. Several bugs have been fixed.
     
      All PHP 7.1 users are encouraged to upgrade to this version.
      </p>
     
	  <p xmlns="http://www.w3.org/2005/Atom">For source downloads of PHP 7.1.6 please visit our <a href="http://www.php.net/downloads.php">downloads page</a>,
      Windows source and binaries can be found on <a href="http://windows.php.net/download/">windows.php.net/download/</a>.
      The list of changes is recorded in the <a href="http://www.php.net/ChangeLog-7.php#7.1.6">ChangeLog</a>.
      </p>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-06-08-2" href="http://php.net/archive/2017.php#id2017-06-08-2" rel="bookmark" class="bookmark">PHP 7.2.0 Alpha 1 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-06-08T17:03:24+00:00">08 Jun 2017</time>
  <div class="newscontent">
    <div>
     <p>The PHP development team announces the immediate availability of PHP 7.2.0 Alpha 1.
     This release marks the beginning of the second minor release in the PHP 7.x series.
     All users of PHP are encouraged to test this version carefully,
     and report any bugs and incompatibilities in the 
     <a href="https://bugs.php.net/">bug tracking system</a>.</p>

     <p><strong>THIS IS A DEVELOPMENT PREVIEW - DO NOT USE IT IN PRODUCTION!</strong></p>

     <p>For information on new features and other changes, you can read the
     <a href="https://github.com/php/php-src/blob/php-7.2.0alpha1/NEWS">NEWS</a> file,
     or the <a href="https://github.com/php/php-src/blob/php-7.2.0alpha1/UPGRADING">UPGRADING</a> file
     for a complete list of upgrading notes. These files can also be found in the release archive.</p>

     <p>For source downloads of PHP 7.2.0 Alpha 1 please visit the <a href="https://downloads.php.net/~pollita/">download</a> page,
     Windows sources and binaries can be found on <a href="http://windows.php.net/qa/">windows.php.net/qa/</a>.</p>

     <p>The second alpha will be released on the 22nd of June. You can also read the full list of planned releases on our
     <a href="https://wiki.php.net/todo/php72#timetable">wiki</a>.</p>

     <p>Thank you for helping us make PHP better.</p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-06-08-1" href="http://php.net/archive/2017.php#id2017-06-08-1" rel="bookmark" class="bookmark">PHP 7.0.20 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-06-08T13:00:00+01:00">08 Jun 2017</time>
  <div class="newscontent">
    <div xmlns="http://www.w3.org/2099/xhtml">
      <p>The PHP development team announces the immediate availability of PHP
      7.0.20. Several bugs have been fixed.
     
      All PHP 7.0 users are encouraged to upgrade to this version.
      </p>
     
      <p>For source downloads of PHP 7.0.20 please visit our <a href="http://www.php.net/downloads.php">downloads page</a>,
      Windows source and binaries can be found on <a href="http://windows.php.net/download/">windows.php.net/download/</a>.
      The list of changes is recorded in the <a href="http://www.php.net/ChangeLog-7.php#7.0.20">ChangeLog</a>.
      </p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"><a href="http://php2017.devlink.cn/"><img src="http://php.net//images/news/beijing2017.jpg" alt="China PHP Developer Conference" width="350" height="135" style="float: right;"></a></div>
    <h2 class="newstitle"><a id="id2017-06-06-1" href="http://php.net/archive/2017.php#id2017-06-06-1" rel="bookmark" class="bookmark">China PHP Developer Conference</a></h2>
  </header>
  <time class="newsdate" datetime="2017-06-06T19:36:21+00:00">06 Jun 2017</time>
  <div class="newscontent">
    <div>
		<p>China PHP Developer Conference which organized by the DevLink will hold in Beijing on June 10th and 11th. </p>
		<p>After “The High Performance PHP”, It’s the another global developer interchange activity that DevLink hosts.</p>
		<p>During this conference, we will discuss and share the topic of "The High Availability PHP"</p>
		<p>More information about the China PHP Conference at: <a href="http://php2017.devlink.cn/">php2017.devlink.cn</a></p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"><a href="http://www.phpconchina.com/"><img src="http://php.net//images/news/shanghai2017.png" alt="The 5th Annual China PHP Conference" width="300" height="150" style="float: right;"></a></div>
    <h2 class="newstitle"><a id="id2017-05-22-1" href="http://php.net/archive/2017.php#id2017-05-22-1" rel="bookmark" class="bookmark">The 5th Annual China PHP Conference </a></h2>
  </header>
  <time class="newsdate" datetime="2017-05-22T11:50:21+00:00">22 May 2017</time>
  <div class="newscontent">
    <div>
		<p>The 5th Annual China PHP Conference – June 17 to 18, Shanghai</p>

		<p>We will be hosting a 2-days event filled with high quality, technical sessions about PHP Core, PHP High Performance, PHP Engineering, and MySQL 5.7/8.0 more.</p>

		<p>Don’t miss out on 2-great days sessions, delicious food, fantastic shows and countless networking opportunities to engage with speakers and delegates.</p>
		<p>Go to <a href="http://www.phpconchina.com/">www.phpconchina.com</a> for tickets and more information.</p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"><a href="http://devconf.ru"><img src="http://php.net//images/news/devconfru2012.png" alt="DevConf 2017" width="373" height="86" style="float: right;"></a></div>
    <h2 class="newstitle"><a id="id2017-05-18-1" href="http://devconf.ru" rel="bookmark" class="bookmark">DevCOnf 2017</a></h2>
  </header>
  <time class="newsdate" datetime="2017-05-18T13:43:56+00:00">18 May 2017</time>
  <div class="newscontent">
    <div>
     <p>
      DevConf 2017 in Moscow, Russia on June 17-18.
     </p>
     <p>
      DevConf is the ultimate meeting place for russian-speaking web-developers,
      combining several language-specific conferences under one roof.
      This year the conference will take place in <a href="http://devconf.ru/ru/members/location">Izmaylovo</a>.
     </p>
     <p>
      DevConf 2017 will include the following sections:
     </p>
     <ul>
      <li>DevConf::Backend();</li>
      <li>DevConf::Frontend();</li>
      <li>DevConf::Management();</li>
      <li>DevConf::Storage();</li>
      <li>DevConf::DevOps();</li>
     </ul>
     <p>
      Special Events:
     </p>
     <ul>
      <li>DevConf::YiiConf(); - June 16</li>
      <li>Joomla Day - June 17</li>
     </ul>
     <p>
      Each section will feature several talks from the active contributors/authors of the language.
      Among the invited speakers are Valentin Bartenev (NGINX), Ilya Gusev (PHP7.1)
      Dmitry Lenev (MySQL), Oleg Bartunov (Postgres),
      Ivan Panchenko (Postgres), Grigory Kochanov (Oracle),
      Vladimir Yldashev (Laravel), Anton Shramko (Rust),
      Konstantin Osipov (Tarantool), Andrey Trifanov (Lua),
      Ilya Alexeev (OpenStack), Ilya Klimov (VueJS),
      Alexey Pirogov (Haskell), Alexey Ohrimenko (Angular),
      Grigory Petrov (React VR), Adel Fayzrakhmanov (Toptal)
      and speakers from other companies. See more details on the official website.
     </p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"><a href="https://world.phparch.com"><img src="http://php.net//images/news/phpworld.2017.web.png" alt="php[world] 2017" width="400" height="173" style="float: right;"></a></div>
    <h2 class="newstitle"><a id="id2017-05-16-1" href="https://world.phparch.com" rel="bookmark" class="bookmark">php[world] 2017: Call for Speakers</a></h2>
  </header>
  <time class="newsdate" datetime="2017-05-16T18:08:03-04:00">16 May 2017</time>
  <div class="newscontent">
    <div>
     <p>The teams at <a href="https://www.phparch.com">php[architect]</a> and <a href="http://www.oneforall.events" title="One for All Events">One for All Events</a> are excited to announce we have opened up our <a href="https://world.phparch.com/call-for-speakers/?paref=phpnet&amp;utm_campaign=phpnet">Call for Speakers</a> for the 4th annual edition of <a href="https://world.phparch.com/?paref=phpnet&amp;utm_campaign=phpnet">php[world]</a>.</p>
     
          <p>This year we are refactoring php[world] into a more focused PHP conference concentrating on providing our attendees deep-dive content which teach core lessons about PHP. We also want talks covering advanced topics in applications and frameworks built in PHP (such as Drupal, WordPress, Laravel, Symfony, and Magento). We encourage submissions on technologies crucial to modern Web development such as HTML5, JavaScript, and emerging technologies. Ideas surrounding the entire software life cycle are often big hits for our attendees. Finally, we do welcome non-technical proposals that will appeal to a developer audience.</p>
     
          <p>This year it will be a 2-day conference with concurrent workshops, preceded by two days of training classes.  We've also updated our comprehensive speaker's package this year to simplify it; we will be offering:</p>
     
          <ul>
          <li>A free conference ticket</li>
          <li>Round-trip economy airfare booked by us</li>
          <li>Accommodations at the conference hotel:
          <ul>
          <li>3 nights for speakers &amp; workshop presenters</li>
          <li>5 nights for training class teachers</li>
          </ul></li>
          </ul>
     
          <p>Don't hesitate, the <a href="https://world.phparch.com/call-for-speakers/?paref=phpnet&amp;utm_campaign=phpnet">Call for Speakers</a> is only open until June 23rd, 2017. So get those submissions in soon, we look forward to hearing from you!</p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-05-11-2" href="http://php.net/archive/2017.php#id2017-05-11-2" rel="bookmark" class="bookmark">PHP 7.1.5 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-05-11T17:44:29+00:00">11 May 2017</time>
  <div class="newscontent">
    <div>
         <p>The PHP development team announces the immediate availability of PHP
     	7.1.5. Several bugs have been fixed.
     
     	All PHP 7.1 users are encouraged to upgrade to this version.
     	</p>
     
     	<p>For source downloads of PHP 7.1.5 please visit our <a href="http://www.php.net/downloads.php">downloads page</a>,
     	Windows source and binaries can be found on <a href="http://windows.php.net/download/">windows.php.net/download/</a>.
     	The list of changes is recorded in the <a href="http://www.php.net/ChangeLog-7.php#7.1.5">ChangeLog</a>.
     	</p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-05-11-1" href="http://php.net/archive/2017.php#id2017-05-11-1" rel="bookmark" class="bookmark">PHP 7.0.19 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-05-11T13:00:00+01:00">11 May 2017</time>
  <div class="newscontent">
    <div>
      <p>The PHP development team announces the immediate availability of PHP
      7.0.19. Several bugs have been fixed.
     
      All PHP 7.0 users are encouraged to upgrade to this version.
      </p>
     
      <p>For source downloads of PHP 7.0.19 please visit our <a href="http://www.php.net/downloads.php">downloads page</a>,
      Windows source and binaries can be found on <a href="http://windows.php.net/download/">windows.php.net/download/</a>.
      The list of changes is recorded in the <a href="http://www.php.net/ChangeLog-7.php#7.0.19">ChangeLog</a>.
      </p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"><a href="https://callforpapers.sandsmedia.com"><img src="http://php.net//images/news/ipc-2017-fall.png" alt="International PHP Conference 2017 Fall - Call for Papers" width="200" height="130" style="float: right;"></a></div>
    <h2 class="newstitle"><a id="id2017-05-09-1" href="https://callforpapers.sandsmedia.com" rel="bookmark" class="bookmark">International PHP Conference 2017 Fall - Call for Papers</a></h2>
  </header>
  <time class="newsdate" datetime="2017-05-09T15:44:54-04:00">09 May 2017</time>
  <div class="newscontent">
    <p xmlns="http://www.w3.org/2005/Atom">While we are eagerly waiting for IPC Spring and webinale to come in later May, we are already preparing for the fall edition of IPC this year. The conference's date is October 23th to 27th and the location will be Munich again.</p>
	<p xmlns="http://www.w3.org/2005/Atom">We are looking forward to your submissions for workshops, sessions &amp; keynotes. Please submit your proposals in English language. Please see our list below of topics which we'd love to see covered, but we are sure that you'll add also some extra stuff which is great and which we do not expect!</p>
	<p xmlns="http://www.w3.org/2005/Atom"><strong>THE BASIC FACTS</strong></p>
	<ul xmlns="http://www.w3.org/2005/Atom">
	  <li>Date: 23 - 27 October 2017</li>
	  <li>Location &amp; Venue: Holiday Inn Munich City Centre</li>
  	  <li>Deadline for submissions: June 9th 2017</li>
	  <li>URL for submissions: <a href="https://callforpapers.sandsmedia.com">https://callforpapers.sandsmedia.com</a></li>
	</ul>
	<p xmlns="http://www.w3.org/2005/Atom">Please see the spectrum of topics we’d like to see covered:</p>
	<ul xmlns="http://www.w3.org/2005/Atom">
	<li><strong>PHP Development</strong></li>
		<ul>
		  <li>Core PHP/PHP 7</li>
		  <li>PHP Frameworks</li>
		  <li>PHP Security</li>
		  <li>Data Stores</li>
		</ul>
	<li><strong>Testing &amp; Quality</strong></li>
		<ul>
		  <li>Scaling</li>
		  <li>Automated Testing  Quality</li>
		</ul>
	<li><strong>Web Architecture</strong></li>
		<ul>
		  <li>Software Architecture</li>
		  <li>Microservices</li>
		  <li>Web APIs &amp; API Design</li>
		  <li>RESTful Services</li>
		</ul>
	<li><strong>DevOps</strong></li>
		<ul>
		  <li>Agile Methodologies</li>
		  <li>Continuous Delivery/Deployment</li>
		  <li>DevOps</li>
		</ul>
	<li><strong>Server &amp; Deployment</strong></li>
		<ul>
		  <li>Cloud &amp; Infrastructure</li>
		  <li>Docker &amp; Co.</li>
		  <li>Analytics &amp; Monitoring</li>
		</ul>
	<li><strong>Web Development</strong></li>
		<ul>
		  <li>Performance</li>
		  <li>Security</li>
		  <li>JavaScript/ECMAScript</li>
		  <li>Angular, Node.js &amp; React</li>
		  <li>Responsive Web Design</li>
		  <li>User Experience</li>
		</ul>
	</ul>
	<p xmlns="http://www.w3.org/2005/Atom">We are looking forward to your exciting submissions! For further information on International PHP Conference’s sessions and speakers visit: <a href="https://phpconference.com">www.phpconference.com</a></p>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"><a href="https://www.phpconference.nl/"><img src="http://php.net//images/news/DPC-logo.png" alt="Dutch PHP Conference" width="350" height="215" style="float: right;"></a></div>
    <h2 class="newstitle"><a id="id2017-04-14-1" href="https://www.phpconference.nl/" rel="bookmark" class="bookmark">Dutch PHP Conference 2017</a></h2>
  </header>
  <time class="newsdate" datetime="2017-04-14T13:21:13+00:00">14 Apr 2017</time>
  <div class="newscontent">
    <div>
      <p>
        We are glad to announce that we’ll be organizing the 11th edition of the Dutch PHP Conference, which will be
        held in Amsterdam from June 29th to July 1st 2017. Thursday 29th will be the tutorial day and June 30th and July
        1st will be the main conference days. DPC brings together the best speakers and PHP, Javascript and front-end
        talent from Europe and beyond for three days of high-level technical sessions. Our
        <a href="https://www.phpconference.nl/schedule" title="Schedule | Dutch PHP conference">schedule</a>
        is already online and features a variety of talks on PHP, DevOps, Security &amp; privacy, microservices, JavaScript,
        databases and much more; so come along to our two main conference days on June 30 and July 1 in Amsterdam.
      </p>

      <p>
        <strong>In-depth tutorial sessions</strong><br/>
        The tutorial day on Thursday June 29 at the same venue gives an opportunity for a smaller number of attendees to
        spend some time with an expert, going in-depth on particular topics - topics like Docker, domain modelling, Mob
        programming, ES6, Drupal8, Progressive Web Apps and more are all on offer. These are small groups so that
        presenters can respond to individual questions, and as a result places are limited.
      </p>

      <p>
        More information about the Dutch PHP Conference at
        <a href="https://www.phpconference.nl/" title="Dutch PHP Conference">www.phpconference.nl</a>.
      </p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"><a href="https://confoo.ca/en/yvr2017/call-for-papers"><img src="http://php.net//images/news/confoo-yvr2017.png" alt="ConFoo Vancouver 2017" width="180" height="130" style="float: right;"></a></div>
    <h2 class="newstitle"><a id="id2017-04-13-3" href="https://confoo.ca/en/yvr2017/call-for-papers" rel="bookmark" class="bookmark">ConFoo Vancouver 2017 Calling for Papers</a></h2>
  </header>
  <time class="newsdate" datetime="2017-04-13T15:58:29-04:00">13 Apr 2017</time>
  <div class="newscontent">
    <div>
     <p>Want to get your web development ideas in front of a live audience? The <a href="https://confoo.ca/en/yvr2017/call-for-papers">call for papers</a> for the ConFoo Vancouver 2017 web developer conference is open! If you have a burning desire to hold forth about PHP, databases, JavaScript, or any other web development topics, we want to see your proposals. The window is open only from April 10 to May 8, 2017, so hurry. An added benefit: If your proposal is selected and you live outside of the Vancouver area, we will cover your travel and hotel.</p>
     
     <p>You’ll have 45 minutes for the talk, with 35 minutes for your topic and 10 minutes for Q&amp;A. We can’t wait to see your proposals!</p>
     
     <p>Until the talks are picked, the price for the tickets will be at its lowest. Once the talks are announced, prices will go up. Check out the <a href="https://confoo.ca/en/yvr2016/sessions">last conference</a> to get an idea of what to expect.</p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-04-13-2" href="http://php.net/archive/2017.php#id2017-04-13-2" rel="bookmark" class="bookmark">PHP 7.1.4 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-04-13T16:12:01+00:00">13 Apr 2017</time>
  <div class="newscontent">
    <div>
       <p>The PHP development team announces the immediate availability of PHP
       7.1.4. Several bugs have been fixed.
     
       All PHP 7.1 users are encouraged to upgrade to this version.
       </p>
     
       <p>For source downloads of PHP 7.1.4 please visit our <a href="http://www.php.net/downloads.php">downloads page</a>,
       Windows source and binaries can be found on <a href="http://windows.php.net/download/">windows.php.net/download/</a>.
       The list of changes is recorded in the <a href="http://www.php.net/ChangeLog-7.php#7.1.4">ChangeLog</a>.
       </p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-04-13-1" href="http://php.net/archive/2017.php#id2017-04-13-1" rel="bookmark" class="bookmark">PHP 7.0.18 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-04-13T13:00:00+01:00">13 Apr 2017</time>
  <div class="newscontent">
    <div>
      <p>The PHP development team announces the immediate availability of PHP
      7.0.18. Several bugs have been fixed.
     
      All PHP 7.0 users are encouraged to upgrade to this version.
      </p>
     
      <p>For source downloads of PHP 7.0.18 please visit our <a href="http://www.php.net/downloads.php">downloads page</a>,
      Windows source and binaries can be found on <a href="http://windows.php.net/download/">windows.php.net/download/</a>.
      The list of changes is recorded in the <a href="http://www.php.net/ChangeLog-7.php#7.0.18">ChangeLog</a>.
      </p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"><a href="http://www.pnwphp.com"><img src="http://php.net//images/news/pnw-php-2015.png" alt="pnwphp" width="200" height="195" style="float: right;"></a></div>
    <h2 class="newstitle"><a id="id2017-03-30-2" href="http://www.pnwphp.com" rel="bookmark" class="bookmark">PNWPHP 2017 CfP</a></h2>
  </header>
  <time class="newsdate" datetime="2017-03-30T07:49:46-04:00">30 Mar 2017</time>
  <div class="newscontent">
    <div>
     <p>We are happy to announce the dates for *Pacific Northwest PHP Conference (PNWPHP) 2017 are September 7-9, and will held at University of Washington in Seattle! The CFP site - <a href="http://cfp.pnwphp.com" title="Pacific Northwest PHP">http://cfp.pnwphp.com</a> - has launched, where talk submissions will accepted through May 15th, 2017.</p>
     
     <p>The <b>Pacific Northwest PHP Conference</b> is a 3-day event in Seattle, Washington for PHP and Web developers. Our past conferences have included <b>world renown speakers</b> from the PHP community, about a <b>wide range of topics</b> — from APIs and CMS to unit testing and version control</p>
     
     <p>For more details, go to <a href="http://pnwphp.com" title="PNWPHP - Pacific Northwest PHP Conference">http://pnwphp.com</a></p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"><a href="http://2017.northeastphp.org"><img src="http://php.net//images/news/nephp-2017.png" alt="NEPHP 2017" width="300" height="166" style="float: right;"></a></div>
    <h2 class="newstitle"><a id="id2017-03-30-1" href="http://2017.northeastphp.org" rel="bookmark" class="bookmark">Northeast PHP Conference CfP</a></h2>
  </header>
  <time class="newsdate" datetime="2017-03-30T07:40:09-04:00">30 Mar 2017</time>
  <div class="newscontent">
    <div>
     <p>
     The Northeast PHP conference returns once again in 2017 to Charlottetown, PEI Canada.  The <a href="http://cfp.northeastphp.org">Call for Papers</a> is open until April 15th.
     
     </p>
     <p>
     The conference will take place August 9-11, and <a href="http://2017.northeastphp.org">Early Bird Tickets</a> are now available.
     </p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-03-16-2" href="http://php.net/archive/2017.php#id2017-03-16-2" rel="bookmark" class="bookmark">PHP 7.1.3 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-03-16T15:34:44+00:00">16 Mar 2017</time>
  <div class="newscontent">
    <div>
          <p>The PHP development team announces the immediate availability of PHP
          7.1.3. Several bugs have been fixed.
     
          All PHP 7.1 users are encouraged to upgrade to this version.
          </p>
     
          <p>For source downloads of PHP 7.1.3 please visit our <a href="http://www.php.net/downloads.php">downloads page</a>,
          Windows source and binaries can be found on <a href="http://windows.php.net/download/">windows.php.net/download/</a>.
          The list of changes is recorded in the <a href="http://www.php.net/ChangeLog-7.php#7.1.3">ChangeLog</a>.
          </p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-03-16-1" href="http://php.net/archive/2017.php#id2017-03-16-1" rel="bookmark" class="bookmark">PHP 7.0.17 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-03-16T13:00:00+01:00">16 Mar 2017</time>
  <div class="newscontent">
    <div>
      <p>The PHP development team announces the immediate availability of PHP
      7.0.17. Several bugs have been fixed.
     
      All PHP 7.0 users are encouraged to upgrade to this version.
      </p>
     
      <p>For source downloads of PHP 7.0.17 please visit our <a href="http://www.php.net/downloads.php">downloads page</a>,
      Windows source and binaries can be found on <a href="http://windows.php.net/download/">windows.php.net/download/</a>.
      The list of changes is recorded in the <a href="http://www.php.net/ChangeLog-7.php#7.0.17">ChangeLog</a>.
      </p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"><a href="http://www.phpunicorn.com"><img src="http://php.net//images/news/phpunicorn-logo-250x250.png" alt="PHP Unicorn Conference Logo" width="250" height="250" style="float: right;"></a></div>
    <h2 class="newstitle"><a id="id2017-03-15-1" href="http://www.phpunicorn.com" rel="bookmark" class="bookmark">PHP Unicorn Conference (Online)</a></h2>
  </header>
  <time class="newsdate" datetime="2017-03-15T02:45:21+00:00">15 Mar 2017</time>
  <div class="newscontent">
    <div>
      <p>
        The <a href="http://www.phpunicorn.com">PHP Unicorn Conference</a> is an online conference dedicated to the programming language PHP. You’ll see talks from some of the world’s more recognizable PHP experts; speaking talent so rare, we call them Unicorns.
      </p>
      <p>
        It is true there are many great PHP conferences happening around the world and you should go to as many as can, but if you have a hard time getting to one or can’t spare the time, why not let the conference come to you? The PHP Unicorn Conference comes streaming right to your computer, wherever in the world you might be.
      </p>
      <p>
        So, join us online on May 4, 2017 for an all-day, can’t miss PHP event and hang out with some PHP Unicorns!!!
      </p>
      <p>
        <a href="https://www.papercall.io/phpunicorn">Call for Papers</a> closes March 26th, 2017. The PHP Unicorn Conference offers speaker compensation of $500 USD per speaker. To submit a talk, please visit: <a href="https://www.papercall.io/phpunicorn">https://www.papercall.io/phpunicorn</a>.
      </p>

    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"><a href="http://zendcon.com"><img src="http://php.net//images/news/zendcon2017.png" alt="ZendCon 2017" width="305" height="113" style="float: right;"></a></div>
    <h2 class="newstitle"><a id="id2017-03-14-1" href="http://zendcon.com" rel="bookmark" class="bookmark">ZendCon 2017 CFP Started</a></h2>
  </header>
  <time class="newsdate" datetime="2017-03-14T00:00:01+00:00">14 Mar 2017</time>
  <div class="newscontent">
    <div>

			<p>We are happy to announce the CFP for ZendCon 2017 has launched at <a href="https://cfp.zendcon.com" title="ZendCon 2017 CFP">https://cfp.zendcon.com</a> where we will accept talk submissions until April 14th, 2017.</p>

			<p>With over 250 million PHP applications driven by a global community of more than 5 million active developers and all enterprises adopting open source software, ZendCon 2017 brings you a curated selection of the best experts, training, and networking opportunities to embrace this vast ecosystem.</p>

			<p>Take advantage of unique opportunities to attend a wide variety of in-depth technical sessions, participate in exhibit hall activities, and connect with experts. Learn about the best in enterprise PHP and open source development, focusing on the latest for PHP 7, the evolution of frameworks and tools, API excellence, and innovation on many open source technologies related to the web.</p>

			<p>Experience web development with the very best to accelerate great PHP.</p>

			<p>Come and enjoy ZendCon 2017 at the Hard Rock Hotel &amp; Casino in Las Vegas.</p>

			<p>Register Now at <a href="http://www.zendcon.com/register-now" title="ZendCon 2017">http://www.zendcon.com/register-now</a></p>
		</div>
	
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"><a href="http://conf.phprs.com.br/"><img src="http://php.net//images/news/LogoNovoCentral.png" alt="Logo Conferência PHPRS 2017" width="250" height="94" style="float: right;"></a></div>
    <h2 class="newstitle"><a id="id2017-03-04-1" href="http://conf.phprs.com.br/" rel="bookmark" class="bookmark">Conferência PHPRS 2017</a></h2>
  </header>
  <time class="newsdate" datetime="2017-03-04T16:33:51-03:00">04 Mar 2017</time>
  <div class="newscontent">
    <div>
     <p>An event for the PHP Developer community of Rio Grande do Sul, focused on professional growth, exchange of experiences and networking. Strengthening language and the labor market.</p>
     
     <p>From May 12 to 13, 2017, in Porto Alegre / RS-Brazil, the first day will be held workshops and the second lectures.</p>
     
     <p>Check out the programming at <a href="http://conf.phprs.com.br/#schedule" title="Confer&#xEA;ncia PHPRS | 12 e 13 maio 2017">http://conf.phprs.com.br/#schedule</a> <br/>
        Subscriptions at <a href="http://conf.phprs.com.br/#tickets" title="Confer&#xEA;ncia PHPRS | 12 e 13 maio 2017">http://conf.phprs.com.br/#tickets</a></p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"><a href="http://www.madisonphpconference.com/"><img src="http://php.net//images/news/madison-php-2016-conf-logo.png" alt="Madison PHP Conference Logo" width="250" height="250" style="float: right;"></a></div>
    <h2 class="newstitle"><a id="id2017-02-24-1" href="http://2017.madisonphpconference.com/" rel="bookmark" class="bookmark">Madison PHP Conference 2017</a></h2>
  </header>
  <time class="newsdate" datetime="2017-02-24T16:59:19+00:00">24 Feb 2017</time>
  <div class="newscontent">
    <div>
            <p>Join us on Friday, September 22nd, 2017 for a full day of tutorials followed by three tracks of amazing talks on Saturday, September 23rd, 2017. Now in its fifth year, Madison PHP Conference in Madison, Wisconsin, USA focuses on PHP, related web technologies, and professional development - everything you need to energize your career. This event is organized by the locally-run <a href="http://www.madisonphp.com">Madison PHP user group</a> and is designed to offer something for attendees at all skill levels. <a href="http://www.madisonphpconference.com">Madison PHP Conference 2017</a> will be two days of networking, learning, sharing, and great fun!</p>
            <p>The <a href="http://cfp.madisonphpconference.com">Call for Papers</a> will be open until April 30th, 2017. Madison PHP Conference offers reimbursement for travel and accommodations. To view the full speaker package and to submit a talk, please visit: <a href="http://cfp.madisonphpconference.com">http://cfp.madisonphpconference.com</a>.</p>
            <p>Have you ever thought about giving a talk at a user group or at a conference but weren't sure what to talk about? Weren't sure how to format your slides? Weren't sure where to even start? Learn some tips for finding a topic, creating your talk, and engaging your audience at our speaker's workshop:<br/>
                <strong>Speaking at a Conference or User Group</strong><br/>
                Thursday, April 6, 2017 - 7:00 PM<br/>
                RSVP: <a href="https://www.meetup.com/madisonphp/events/233865912/">https://www.meetup.com/madisonphp/events/233865912/</a>
            </p>

        </div>
    
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"><a href="http://www.madisonphpconference.com/"><img src="http://php.net//images/news/madison-php-2016-conf-logo.png" alt="Madison PHP Conference Logo" width="250" height="250" style="float: right;"></a></div>
    <h2 class="newstitle"><a id="id2017-02-24-1" href="http://2017.madisonphpconference.com/" rel="bookmark" class="bookmark">Madison PHP Conference 2017</a></h2>
  </header>
  <time class="newsdate" datetime="2017-02-24T16:59:19+00:00">24 Feb 2017</time>
  <div class="newscontent">
    <div>
            <p>Join us on Friday, September 22nd, 2017 for a full day of tutorials followed by three tracks of amazing talks on Saturday, September 23rd, 2017. Now in its fifth year, Madison PHP Conference in Madison, Wisconsin, USA focuses on PHP, related web technologies, and professional development - everything you need to energize your career. This event is organized by the locally-run <a href="http://www.madisonphp.com">Madison PHP user group</a> and is designed to offer something for attendees at all skill levels. <a href="http://www.madisonphpconference.com">Madison PHP Conference 2017</a> will be two days of networking, learning, sharing, and great fun!</p>

        </div>
    
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"><a href="https://cakefest.org"><img src="http://php.net//images/news/cakefest-2017.png" alt="CakeFest 2017" width="376" height="268" style="float: right;"></a></div>
    <h2 class="newstitle"><a id="id2017-02-21-1" href="https://cakefest.org" rel="bookmark" class="bookmark">CakeFest 2017 NYC, the Official CakePHP Conference</a></h2>
  </header>
  <time class="newsdate" datetime="2017-02-21T09:19:04+00:00">21 Feb 2017</time>
  <div class="newscontent">
    <div>
     <p>
       <a href="https://cakefest.org">CakeFest</a> is organized for developers,
       managers and interested newcomers alike. Bringing a world of unique skill
       and talent together in a celebration and learning environment around the
       worlds most popular PHP framework.
     </p>
     <p>
       Celebrating over eleven years of success in the PHP and web development
       community, <a href="http://cakefest.org">CakePHP’s 2017 conference</a>
       will be an event not to miss.
     </p>
     <p>
       With two workshop days (8th/9th June) as well as two jam-packed conference
       days (10th/11th June), this is an open source conference not to miss out on!
     </p>
     <p><a href="https://cakefest.org">CakeFest</a> is on the lookout for sponsors - keen for more information? Contact us via <a href="mailto:CakeFest@cakephp.org">CakeFest@cakephp.org</a> for more!</p>

     <p>Are you a speaker looking for a new and interesting conference to speak at? <a href="https://cakefest.org">CakeFest 2017 NYC</a> is the place for you! A lot of things interest us, so why not come join in! CFP closes 15th March and Speakers will be announced before 31st March 2017</p>

     <p><a href="https://cakefest.org/tickets">Tickets</a> are selling fast, so you better grab yours while you still can!</p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-02-17-1" href="http://php.net/archive/2017.php#id2017-02-17-1" rel="bookmark" class="bookmark">PHP 7.1.2 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-02-17T06:00:25+00:00">17 Feb 2017</time>
  <div class="newscontent">
    <div>
          <p>The PHP development team announces the immediate availability of PHP
          7.1.2. Several bugs have been fixed.
     
          All PHP 7.1 users are encouraged to upgrade to this version.
          </p>
     
          <p>For source downloads of PHP 7.1.2 please visit our <a href="http://www.php.net/downloads.php">downloads page</a>,
          Windows source and binaries can be found on <a href="http://windows.php.net/download/">windows.php.net/download/</a>.
          The list of changes is recorded in the <a href="http://www.php.net/ChangeLog-7.php#7.1.2">ChangeLog</a>.
          </p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-02-16-1" href="http://php.net/archive/2017.php#id2017-02-16-1" rel="bookmark" class="bookmark">PHP 7.0.16 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-02-16T13:00:00+01:00">16 Feb 2017</time>
  <div class="newscontent">
    <div>
      <p>The PHP development team announces the immediate availability of PHP
      7.0.16. Several bugs have been fixed.
     
      All PHP 7.0 users are encouraged to upgrade to this version.
      </p>
     
      <p>For source downloads of PHP 7.0.16 please visit our <a href="http://www.php.net/downloads.php">downloads page</a>,
      Windows source and binaries can be found on <a href="http://windows.php.net/download/">windows.php.net/download/</a>.
      The list of changes is recorded in the <a href="http://www.php.net/ChangeLog-7.php#7.0.16">ChangeLog</a>.
      </p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"><a href="http://phpexperience2017.imasters.com.br/?paref=phpnet&utm_campaign=phpnet"><img src="http://php.net//images/news/php-experience-2017_logo.png" alt="PHP Experience 2017 Logo" width="264" height="24" style="float: right;"></a></div>
    <h2 class="newstitle"><a id="id2017-02-15-1" href="http://phpexperience2017.imasters.com.br/?paref=phpnet&utm_campaign=phpnet" rel="bookmark" class="bookmark">PHP Experience 2017</a></h2>
  </header>
  <time class="newsdate" datetime="2017-02-15T02:35:13+00:00">15 Feb 2017</time>
  <div class="newscontent">
    <p xmlns="http://www.w3.org/2005/Atom">iMasters PHP Experience 2017 brings together about 1,200 PHP developers in São Paulo, for <a href="http://phpexperience2017en.imasters.com.br/?paref=phpnet&amp;utm_campaign=phpnet">national and international lectures, workshops, community areas and various networking actions, divided into two days of great content</a>. In 2017 taking place from March 27-28 in São Paulo - Brazil.</p>
      <p xmlns="http://www.w3.org/2005/Atom">Curatorship by <a href="http://phpsp.org.br/?paref=phpnet&amp;utm_campaign=phpnet">PHPSP - São Paulo PHP User Group</a>.</p>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"><a href="https://tek.phparch.com/?paref=phpnet&utm_campaign=phpnet"><img src="http://php.net//images/news/phptek2017.png" alt="php[tek] 2017" width="425" height="93" style="float: right;"></a></div>
    <h2 class="newstitle"><a id="id2017-01-23-1" href="https://tek.phparch.com/?paref=phpnet&utm_campaign=phpnet" rel="bookmark" class="bookmark">php[tek] 2017: Atlanta</a></h2>
  </header>
  <time class="newsdate" datetime="2017-01-23T08:25:57-05:00">23 Jan 2017</time>
  <div class="newscontent">
    <p xmlns="http://www.w3.org/2005/Atom">We are excited to announce the <a href="https://tek.phparch.com/schedule?paref=phpnet&amp;utm_campaign=phpnet">full schedule</a> for the 12th edition of <a href="https://tek.phparch.com/?paref=phpnet&amp;utm_campaign=phpnet">php[tek] 2017</a>, the longest running community focused PHP conference.  This year taking place from May 24-26 in Atlanta, GA.</p>

<p xmlns="http://www.w3.org/2005/Atom">There is an <a href="https://tek.phparch.com/schedule?paref=phpnet&amp;utm_campaign=phpnet">amazing schedule</a> that has been put together for you, including:</p>

<ul xmlns="http://www.w3.org/2005/Atom">
<li>4 Full-day Training Classes</li>
<li>8 Hands-on Workshops</li>
<li>40 Breakout Sessions</li>
<li><a href="https://tek.phparch.com/keynotes?paref=phpnet&amp;utm_campaign=phpnet">6 Keynotes</a></li>
</ul>

<p xmlns="http://www.w3.org/2005/Atom">This is all being provided by <a href="https://tek.phparch.com/speakers?paref=phpnet&amp;utm_campaign=phpnet">40 different speakers</a> from around the world, including speakers from companies like Slack, Oracle, MongoDB, Etsy, Rackspace, IBM, Salesforce, GitLab, AOL, and much much more.</p>

<p xmlns="http://www.w3.org/2005/Atom">We sincerely look forward to seeing you in Atlanta this May!  It's going to be the best <a href="https://tek.phparch.com/?paref=phpnet&amp;utm_campaign=phpnet">php[tek]</a> ever!</p>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-01-19-3" href="http://php.net/archive/2017.php#id2017-01-19-3" rel="bookmark" class="bookmark">PHP 5.6.30 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-01-19T13:30:25-08:00">19 Jan 2017</time>
  <div class="newscontent">
    <div>
    <div xmlns="http://www.w3.org/1999/xhtml">
     <p>The PHP development team announces the immediate availability of PHP
     5.6.30. This is a security release. Several security bugs were fixed in
     this release.

     All PHP 5.6 users are encouraged to upgrade to this version.</p>

     <p>
     According to <a href="http://php.net/supported-versions.php">our release calendar</a>, this PHP 5.6 version
     is the last planned release that contains regular bugfixes. All the consequent releases
     will contain only security-relevant fixes, for the term of two years.
     PHP 5.6 users that need further bugfixes are encouraged to upgrade to PHP 7.
     </p>

     <p>For source downloads of PHP 5.6.30 please visit our <a href="http://www.php.net/downloads.php">downloads page</a>,
     Windows source and binaries can be found on <a href="http://windows.php.net/download/">windows.php.net/download/</a>.
     The list of changes is recorded in the <a href="http://www.php.net/ChangeLog-5.php#5.6.30">ChangeLog</a>.
     </p>
    </div>
     
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-01-19-2" href="http://php.net/archive/2017.php#id2017-01-19-2" rel="bookmark" class="bookmark">PHP 7.0.15 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-01-19T13:00:00+01:00">19 Jan 2017</time>
  <div class="newscontent">
    <div>
     <p>The PHP development team announces the immediate availability of PHP
     7.0.15. This is a security release. Several security bugs were fixed in
     this release.
     
     All PHP 7.0 users are encouraged to upgrade to this version.</p>
     
     <p>For source downloads of PHP 7.0.15 please visit our <a href="http://www.php.net/downloads.php">downloads page</a>,
     Windows source and binaries can be found on <a href="http://windows.php.net/download/">windows.php.net/download/</a>.
     The list of changes is recorded in the <a href="http://www.php.net/ChangeLog-7.php#7.0.15">ChangeLog</a>.
     </p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"></div>
    <h2 class="newstitle"><a id="id2017-01-19-1" href="http://php.net/archive/2017.php#id2017-01-19-1" rel="bookmark" class="bookmark">PHP 7.1.1 Released</a></h2>
  </header>
  <time class="newsdate" datetime="2017-01-19T09:56:45+00:00">19 Jan 2017</time>
  <div class="newscontent">
    <div>
     <p>The PHP development team announces the immediate availability of PHP
     7.1.1. Several bugs have been fixed.
     
     All PHP 7.1 users are encouraged to upgrade to this version.
     </p>
     
     <p>For source downloads of PHP 7.1.1 please visit our <a href="http://www.php.net/downloads.php">downloads page</a>,
     Windows source and binaries can be found on <a href="http://windows.php.net/download/">windows.php.net/download/</a>.
     The list of changes is recorded in the <a href="http://www.php.net/ChangeLog-7.php#7.1.1">ChangeLog</a>.
     </p>
    </div>
  
  </div>
</article>
<article class="newsItem">
  <header>
    <div class="newsImage"><a href="http://phpkonf.org/"><img src="http://php.net//images/news/phpkonf_2015.png" alt="PHPKonf: Istanbul PHP Conference 2017" width="296" height="110" style="float: right;"></a></div>
    <h2 class="newstitle"><a id="id2017-12-27-1" href="http://phpkonf.org/" rel="bookmark" class="bookmark">PHPKonf: Istanbul PHP Conference 2017</a></h2>
  </header>
  <time class="newsdate" datetime="2017-03-27T18:00:00+00:00">27 Mar 2017</time>
  <div class="newscontent">
    <div>
     <p>Istanbul PHP User Group is proud to announce that the PHPKonf 2017! We'll host some of the best speakers, awesome talk topics, latest technologies, and up to date news in PHP. Join us on 20th of May for a multi-track conference in ancient city Istanbul! We’ve something for every level of PHP developer with 1 keynotes, 14 talks.</p>

     For call for papers and more information: <a href="http://phpkonf.org">http://phpkonf.org</a>
    </div>
  
  </div>
</article>
    </section><!-- layout-content -->
    
<aside class="tips">
    <div class="inner">
<h3 class="announcements">Archives by year</h3>

<p class='panel active'><a href="/archive/2017.php">2017</a></p>
<p class='panel'><a href="/archive/2016.php">2016</a></p>
<p class='panel'><a href="/archive/2015.php">2015</a></p>
<p class='panel'><a href="/archive/2014.php">2014</a></p>
<p class='panel'><a href="/archive/2013.php">2013</a></p>
<p class='panel'><a href="/archive/2012.php">2012</a></p>
<p class='panel'><a href="/archive/2011.php">2011</a></p>
<p class='panel'><a href="/archive/2010.php">2010</a></p>
<p class='panel'><a href="/archive/2009.php">2009</a></p>
<p class='panel'><a href="/archive/2008.php">2008</a></p>
<p class='panel'><a href="/archive/2007.php">2007</a></p>
<p class='panel'><a href="/archive/2006.php">2006</a></p>
<p class='panel'><a href="/archive/2005.php">2005</a></p>
<p class='panel'><a href="/archive/2004.php">2004</a></p>
<p class='panel'><a href="/archive/2003.php">2003</a></p>
<p class='panel'><a href="/archive/2002.php">2002</a></p>
<p class='panel'><a href="/archive/2001.php">2001</a></p>
<p class='panel'><a href="/archive/2000.php">2000</a></p>
<p class='panel'><a href="/archive/1999.php">1999</a></p>
<p class='panel'><a href="/archive/1998.php">1998</a></p>
</div>
</aside>

  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    <div class='elephpants'><div class=images></div></div>
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

