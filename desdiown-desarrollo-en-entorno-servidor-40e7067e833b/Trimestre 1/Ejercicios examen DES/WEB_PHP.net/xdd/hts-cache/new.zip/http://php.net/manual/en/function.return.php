<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: return - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/function.return.php">
 <link rel="shorturl" href="http://php.net/return">
 <link rel="alternate" href="http://php.net/return" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.control-structures.php">
 <link rel="prev" href="http://php.net/manual/en/control-structures.declare.php">
 <link rel="next" href="http://php.net/manual/en/function.require.php">

 <link rel="alternate" href="http://php.net/manual/en/function.return.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/function.return.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/function.return.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/function.return.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/function.return.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/function.return.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/function.return.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/function.return.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/function.return.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/function.return.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/function.return.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="function.require.php">
          require &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="control-structures.declare.php">
          &laquo; declare        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.control-structures.php'>Control Structures</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/function.return.php' selected="selected">English</option>
            <option value='pt_BR/function.return.php'>Brazilian Portuguese</option>
            <option value='zh/function.return.php'>Chinese (Simplified)</option>
            <option value='fr/function.return.php'>French</option>
            <option value='de/function.return.php'>German</option>
            <option value='ja/function.return.php'>Japanese</option>
            <option value='ro/function.return.php'>Romanian</option>
            <option value='ru/function.return.php'>Russian</option>
            <option value='es/function.return.php'>Spanish</option>
            <option value='tr/function.return.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/function.return.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=function.return">Report a Bug</a>
    </div>
  </div><div id="function.return" class="sect1">
 <h2 class="title">return</h2>
 <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p>
 <p class="simpara">
  <em>return</em> returns program control to the calling module.
  Execution resumes at the expression following the called module&#039;s invocation.
 </p>
 <p class="simpara">
  If called from within a function, the <em>return</em>
  statement immediately ends execution of the current function, and
  returns its argument as the value of the function
  call. <em>return</em> also ends the execution of
  an <span class="function"><a href="function.eval.php" class="function">eval()</a></span> statement or script file.
 </p>
 <p class="simpara">
  If called from the global scope, then execution of the current
  script file is ended. If the current script file was
  <span class="function"><a href="function.include.php" class="function">include</a></span>d or <span class="function"><a href="function.require.php" class="function">require</a></span>d,
  then control is passed back to the calling file. Furthermore, if
  the current script file was <span class="function"><a href="function.include.php" class="function">include</a></span>d, then
  the value given to <em>return</em> will be returned as
  the value of the <span class="function"><a href="function.include.php" class="function">include</a></span> call. If
  <em>return</em> is called from within the main script
  file, then script execution ends. If the current script file was
  named by the <a href="ini.core.php#ini.auto-prepend-file" class="link">auto_prepend_file</a> or <a href="ini.core.php#ini.auto-append-file" class="link">auto_append_file</a>
  configuration options in <var class="filename">php.ini</var>,
  then that script file&#039;s execution is ended.
 </p>
 <p class="simpara">For more information, see <a href="functions.returning-values.php" class="link">Returning values</a>.
 </p>
 <p class="para">
  <blockquote class="note"><p><strong class="note">Note</strong>: 
   <span class="simpara">
    Note that since <em>return</em> is a language
    construct and not a function, the parentheses surrounding its
    arguments are not required. It is common to leave them out, and you
    actually should do so as PHP has less work to do in this case.
   </span>
  </p></blockquote>
  <blockquote class="note"><p><strong class="note">Note</strong>: 
   <span class="simpara">
    If no parameter is supplied, then the parentheses must be omitted
    and <strong><code>NULL</code></strong> will be
    returned. Calling <em>return</em> with parentheses but
    with no arguments will result in a parse error.
   </span>
  </p></blockquote>
  <blockquote class="note"><p><strong class="note">Note</strong>: 
   <span class="simpara">
    You should <em class="emphasis">never</em> use parentheses around your return
    variable when returning by reference, as this will not work. You can
    only return variables by reference, not the result of a statement. If
    you use <em>return ($a);</em> then you&#039;re not returning a
    variable, but the result of the expression <em>($a)</em>
    (which is, of course, the value of <var class="varname"><var class="varname">$a</var></var>).
    </span>
   </p></blockquote>
 </p>
</div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=function.return&amp;redirect=http://php.net/manual/en/function.return.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">10 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="59866">  <div class="votes">
    <div id="Vu59866">
    <a href="/manual/vote-note.php?id=59866&amp;page=function.return&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd59866">
    <a href="/manual/vote-note.php?id=59866&amp;page=function.return&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V59866" title="69% like this...">
    108
    </div>
  </div>
  <a href="#59866" class="name">
  <strong class="user"><em>warhog at warhog dot net</em></strong></a><a class="genanchor" href="#59866"> &para;</a><div class="date" title="2005-12-18 12:28"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom59866">
<div class="phpcode"><code><span class="html">
for those of you who think that using return in a script is the same as using exit note that: using return just exits the execution of the current script, exit the whole execution.<br /><br />look at that example:<br /><br />a.php<br /><span class="default">&lt;?php<br /></span><span class="keyword">include(</span><span class="string">"b.php"</span><span class="keyword">);<br />echo </span><span class="string">"a"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />b.php<br /><span class="default">&lt;?php<br /></span><span class="keyword">echo </span><span class="string">"b"</span><span class="keyword">;<br />return;<br /></span><span class="default">?&gt;<br /></span><br />(executing a.php:) will echo "ba".<br /><br />whereas (b.php modified):<br /><br />a.php<br /><span class="default">&lt;?php<br /></span><span class="keyword">include(</span><span class="string">"b.php"</span><span class="keyword">);<br />echo </span><span class="string">"a"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />b.php<br /><span class="default">&lt;?php<br /></span><span class="keyword">echo </span><span class="string">"b"</span><span class="keyword">;<br />exit;<br /></span><span class="default">?&gt;<br /></span><br />(executing a.php:) will echo "b".</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114304">  <div class="votes">
    <div id="Vu114304">
    <a href="/manual/vote-note.php?id=114304&amp;page=function.return&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114304">
    <a href="/manual/vote-note.php?id=114304&amp;page=function.return&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114304" title="64% like this...">
    50
    </div>
  </div>
  <a href="#114304" class="name">
  <strong class="user"><em>Tom</em></strong></a><a class="genanchor" href="#114304"> &para;</a><div class="date" title="2014-02-05 10:35"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114304">
<div class="phpcode"><code><span class="html">
Keep in mind that even if PHP allows you to use "return" in the global scope it is very bad design to do so.<br /><br />Using the return statement in the global scope encourages programmers to use files like functions and treat the include-statement like a function call. Where they initialize the file's "parameters" by setting variables in the global scope and reading them in the included file.<br /><br />Like so: (WARNING! This code was done by professionals in a controlled environment. Do NOT try this at home!)<br /><span class="default">&lt;?php<br />$parameter1 </span><span class="keyword">= </span><span class="string">"foo"</span><span class="keyword">;<br /></span><span class="default">$parameter2 </span><span class="keyword">= </span><span class="string">"bar"</span><span class="keyword">;<br /></span><span class="default">$result </span><span class="keyword">= include </span><span class="string">"voodoo.php"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />Where "voodoo.php" may be something like:<br /><span class="default">&lt;?php<br /></span><span class="keyword">return </span><span class="default">$parameter1 </span><span class="keyword">. </span><span class="string">" " </span><span class="keyword">. </span><span class="default">$parameter2</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />This is one of the worst designs you can implement since there is no function head, no way to understand where $parameter1 and $parameter2 come from by just looking at "voodoo". No explanation in the calling file as of what $parameter1 and -2 are doing or why they are even there. If the names of the parameters ever change in "voodoo" it will break the calling file. No IDE will properly support this very poor "design". And I won't even start on the security issues!<br /><br />If you find yourself in a situation where a return-statement in global scope is the answer to your problem, then maybe you are asking the wrong questions. Actually you may be better off using a function and throwing an exception where needed.<br /><br />Files are NOT functions. They should NOT be treated as such and under no circumstances should they "return" anything at all.<br /><br />Remember: Every time you abuse a return statement God kills a kitten and makes sure you are reborn as a mouse!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="112515">  <div class="votes">
    <div id="Vu112515">
    <a href="/manual/vote-note.php?id=112515&amp;page=function.return&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd112515">
    <a href="/manual/vote-note.php?id=112515&amp;page=function.return&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V112515" title="67% like this...">
    33
    </div>
  </div>
  <a href="#112515" class="name">
  <strong class="user"><em>J.D. Grimes</em></strong></a><a class="genanchor" href="#112515"> &para;</a><div class="date" title="2013-06-25 08:11"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom112515">
<div class="phpcode"><code><span class="html">
Note that because PHP processes the file before running it, any functions defined in an included file will still be available, even if the file is not executed.<br /><br />Example:<br /><br />a.php<br /><span class="default">&lt;?php<br /></span><span class="keyword">include </span><span class="string">'b.php'</span><span class="keyword">;<br /><br /></span><span class="default">foo</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span><br />b.php<br /><span class="default">&lt;?php<br /></span><span class="keyword">return;<br /><br />function </span><span class="default">foo</span><span class="keyword">() {<br />&nbsp; &nbsp;&nbsp; echo </span><span class="string">'foo'</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />Executing a.php will output "foo".</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116709">  <div class="votes">
    <div id="Vu116709">
    <a href="/manual/vote-note.php?id=116709&amp;page=function.return&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116709">
    <a href="/manual/vote-note.php?id=116709&amp;page=function.return&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116709" title="65% like this...">
    19
    </div>
  </div>
  <a href="#116709" class="name">
  <strong class="user"><em>Russell Weed</em></strong></a><a class="genanchor" href="#116709"> &para;</a><div class="date" title="2015-02-13 04:09"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom116709">
<div class="phpcode"><code><span class="html">
Following up on Tom and warhog's comments regarding using return in global scope, here is another reason not to do it:<br /><br />For command line scripts, the return statement will NOT return a status to the OS!<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">if (</span><span class="default">$somethingBad</span><span class="keyword">)<br />&nbsp;&nbsp; return </span><span class="default">42</span><span class="keyword">; </span><span class="comment">// This will not work! You'll get 0 back instead!<br /></span><span class="keyword">else<br />&nbsp;&nbsp; return </span><span class="default">0</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />Instead, you must use exit(): <a href="http://php.net/exit" rel="nofollow" target="_blank">http://php.net/exit</a><br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">if (</span><span class="default">$somethingBad</span><span class="keyword">)<br />&nbsp;&nbsp; exit(</span><span class="default">42</span><span class="keyword">); </span><span class="comment">// OS will receive (int) 42 as the return code<br /></span><span class="keyword">else </span><span class="comment">// everything is fine<br />&nbsp;&nbsp; </span><span class="keyword">exit(</span><span class="default">0</span><span class="keyword">);<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116497">  <div class="votes">
    <div id="Vu116497">
    <a href="/manual/vote-note.php?id=116497&amp;page=function.return&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116497">
    <a href="/manual/vote-note.php?id=116497&amp;page=function.return&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116497" title="51% like this...">
    1
    </div>
  </div>
  <a href="#116497" class="name">
  <strong class="user"><em>Anonim</em></strong></a><a class="genanchor" href="#116497"> &para;</a><div class="date" title="2015-01-13 07:58"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom116497">
<div class="phpcode"><code><span class="html">
Also note, what you cannot do anything after&nbsp; the 'return' usage in function. <br />For example:<br /><br /><span class="default">&lt;?php<br />$_SESSION</span><span class="keyword">[</span><span class="string">'text'</span><span class="keyword">] = </span><span class="string">'Best PHP'</span><span class="keyword">;<br />function </span><span class="default">getText</span><span class="keyword">()<br />{<br />&nbsp; &nbsp; </span><span class="default">$text </span><span class="keyword">= </span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'text'</span><span class="keyword">];<br />&nbsp; &nbsp; return </span><span class="default">$text</span><span class="keyword">;<br />&nbsp; &nbsp; unset(</span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'text'</span><span class="keyword">]);<br />}<br />echo </span><span class="default">getText</span><span class="keyword">().</span><span class="string">'&lt;br /&gt;'</span><span class="keyword">;<br />echo </span><span class="default">$_SESSION</span><span class="keyword">[</span><span class="string">'text'</span><span class="keyword">];<br /></span><span class="default">?&gt;<br /></span><br />This will output:<br />Best PHP<br />Best PHP<br /><br />Twice, because we have used unset() function after 'return'.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119797">  <div class="votes">
    <div id="Vu119797">
    <a href="/manual/vote-note.php?id=119797&amp;page=function.return&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119797">
    <a href="/manual/vote-note.php?id=119797&amp;page=function.return&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119797" title="50% like this...">
    0
    </div>
  </div>
  <a href="#119797" class="name">
  <strong class="user"><em>hairbysubaru at gmail dot com</em></strong></a><a class="genanchor" href="#119797"> &para;</a><div class="date" title="2016-08-29 05:48"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119797">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br /><br />$stat </span><span class="keyword">= array(</span><span class="string">"Inactive"</span><span class="keyword">,</span><span class="string">"Active"</span><span class="keyword">);<br /><br />function </span><span class="default">fred</span><span class="keyword">(</span><span class="default">$z</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="default">$a </span><span class="keyword">= </span><span class="string">"firstname"</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$b </span><span class="keyword">= </span><span class="string">"lastname"</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$status</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">;<br />&nbsp; &nbsp; return array(</span><span class="default">$a</span><span class="keyword">,</span><span class="default">$b</span><span class="keyword">,</span><span class="default">$z</span><span class="keyword">,</span><span class="default">$status</span><span class="keyword">);<br />}<br /></span><span class="default">$results </span><span class="keyword">= list(</span><span class="default">$ra</span><span class="keyword">,</span><span class="default">$rb</span><span class="keyword">,</span><span class="default">$rc</span><span class="keyword">,</span><span class="default">$status</span><span class="keyword">) = </span><span class="default">fred</span><span class="keyword">(</span><span class="string">"user_details"</span><span class="keyword">);<br /></span><span class="comment">//what we get...<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$results</span><span class="keyword">);<br /></span><span class="comment">// interpreted results, knowing the 'structure' of $results.<br /></span><span class="keyword">echo </span><span class="string">"context value 2(heading):"</span><span class="keyword">.</span><span class="default">$results</span><span class="keyword">[</span><span class="default">2</span><span class="keyword">];<br />echo </span><span class="string">"context value 0(user fname):"</span><span class="keyword">.</span><span class="default">$results</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">];<br />echo </span><span class="string">"context value 1(user lname):"</span><span class="keyword">.</span><span class="default">$results</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">];<br />echo </span><span class="string">"context value 3(status):"</span><span class="keyword">.</span><span class="default">$results</span><span class="keyword">[</span><span class="default">3</span><span class="keyword">];<br />echo </span><span class="string">"status:"</span><span class="keyword">.</span><span class="default">$stat</span><span class="keyword">[</span><span class="default">$results</span><span class="keyword">[</span><span class="default">3</span><span class="keyword">]];<br /><br /></span><span class="default">?&gt;<br /></span><br />Produces...<br /><br />Array ( [0] =&gt; firstname [1] =&gt; lastname [2] =&gt; user_details [3] =&gt; 0 ) <br /><br />context value 0(heading):user_details<br />context value 1(user fname):firstname<br />context value 2(user lname):lastname<br />context value 3(status):0<br />status:Inactive<br /><br />Context is everything.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119659">  <div class="votes">
    <div id="Vu119659">
    <a href="/manual/vote-note.php?id=119659&amp;page=function.return&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119659">
    <a href="/manual/vote-note.php?id=119659&amp;page=function.return&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119659" title="50% like this...">
    0
    </div>
  </div>
  <a href="#119659" class="name">
  <strong class="user"><em>sebi at sebi dot moe</em></strong></a><a class="genanchor" href="#119659"> &para;</a><div class="date" title="2016-07-27 02:16"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119659">
<div class="phpcode"><code><span class="html">
One situation where returning a value from a script and using it could be considered a good use is config files. Zend Framework 2 promotes this structure for this purpose, and it works pretty well. <br /><br />Example config file:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">return [<br />&nbsp; </span><span class="string">'site' </span><span class="keyword">=&gt; </span><span class="default">123</span><span class="keyword">,<br />&nbsp; </span><span class="string">'settings' </span><span class="keyword">=&gt; </span><span class="string">'asd'<br /></span><span class="keyword">];<br /><br /></span><span class="default">Reading</span><span class="keyword">:<br /><br />&lt;?</span><span class="default">php<br />$config </span><span class="keyword">= (require </span><span class="string">'config.php'</span><span class="keyword">);<br /></span><span class="comment">// Or<br /></span><span class="default">$config </span><span class="keyword">= </span><span class="default">array_merge</span><span class="keyword">(require </span><span class="string">'config/local.php'</span><span class="keyword">, require </span><span class="string">'config/application.php'</span><span class="keyword">);</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117643">  <div class="votes">
    <div id="Vu117643">
    <a href="/manual/vote-note.php?id=117643&amp;page=function.return&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117643">
    <a href="/manual/vote-note.php?id=117643&amp;page=function.return&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117643" title="42% like this...">
    -4
    </div>
  </div>
  <a href="#117643" class="name">
  <strong class="user"><em>brad dot k dot harms at gmail dot com</em></strong></a><a class="genanchor" href="#117643"> &para;</a><div class="date" title="2015-07-13 10:06"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117643">
<div class="phpcode"><code><span class="html">
I wonder if return in the global scope would be a semantic way to store low-level, pure-PHP config arrays while avoiding polluting the global scope. For example:<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">// app.php<br /><br /></span><span class="keyword">function </span><span class="default">app</span><span class="keyword">() {<br />&nbsp; &nbsp; </span><span class="default">$conf </span><span class="keyword">= include(</span><span class="string">'conf.php'</span><span class="keyword">);<br />}<br /><br /></span><span class="default">app</span><span class="keyword">();<br /><br />&lt;?</span><span class="default">php<br /></span><span class="comment">// conf.php<br /><br /></span><span class="keyword">return [<br />&nbsp; &nbsp; </span><span class="string">'db' </span><span class="keyword">=&gt; [<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'host' </span><span class="keyword">=&gt; </span><span class="string">'127.0.0.1'</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'username' </span><span class="keyword">=&gt; </span><span class="string">'user'</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'password' </span><span class="keyword">=&gt; </span><span class="string">'pass'<br />&nbsp; &nbsp; </span><span class="keyword">],<br />];<br /><br /></span><span class="default">?&gt;<br /></span><br />This approach produces exactly 0 global variables.<br /><br />(PS. I also tried this using a JS-like module pattern using an anonymous function but it seems that an anon function can't be defined and called in the same expression.)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120457">  <div class="votes">
    <div id="Vu120457">
    <a href="/manual/vote-note.php?id=120457&amp;page=function.return&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120457">
    <a href="/manual/vote-note.php?id=120457&amp;page=function.return&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120457" title="16% like this...">
    -8
    </div>
  </div>
  <a href="#120457" class="name">
  <strong class="user"><em>rupaldhamesha at hotmail dot com</em></strong></a><a class="genanchor" href="#120457"> &para;</a><div class="date" title="2017-01-12 10:12"><strong>11 months ago</strong></div>
  <div class="text" id="Hcom120457">
<div class="phpcode"><code><span class="html">
I am facing problem with return.<br /><br />I have one php file say welcome.php<br />&nbsp;&nbsp; <br />in that I am including <br />&nbsp;&nbsp; uerChecking - this is a class file<br />&nbsp;&nbsp; header.html file<br /><br />in header.html file I have included one user.php file <br />&nbsp; thisss will display user details.<br /><br />Here control is not getting transfer from user.php to header.html file<br /><br />I made this header.html file header.php file but then also control is not getting transfered.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="85112">  <div class="votes">
    <div id="Vu85112">
    <a href="/manual/vote-note.php?id=85112&amp;page=function.return&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd85112">
    <a href="/manual/vote-note.php?id=85112&amp;page=function.return&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V85112" title="26% like this...">
    -55
    </div>
  </div>
  <a href="#85112" class="name">
  <strong class="user"><em>andrew at neonsurge dot com</em></strong></a><a class="genanchor" href="#85112"> &para;</a><div class="date" title="2008-08-15 01:40"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom85112">
<div class="phpcode"><code><span class="html">
Response to stoic's message below...<br /><br />I believe the way you've explained this for people may be a bit confusing, and your verbiage is incorrect.&nbsp; Your script below is technically calling return from a global scope, but as it says right after that in the description above... "If the current script file was include()ed or require()ed, then control is passed back to the calling file".&nbsp; You are in a included file.&nbsp; Just making sure that is clear.<br /><br />Now, the way php works is before it executes actual code it does what you call "processing" is really just a syntax check.&nbsp; It does this every time per-file that is included before executing that file.&nbsp; This is a GOOD feature, as it makes sure not to run any part of non-functional code.&nbsp; What your example might have also said... is that in doing this syntax check it does not execute code, merely runs through your file (or include) checking for syntax errors before execution.&nbsp; To show that, you should put the echo "b"; and echo "a"; at the start of each file.&nbsp; This will show that "b" is echoed once, and then "a" is echoed only once, because the first time it syntax checked a.php, it was ok.&nbsp; But the second time the syntax check failed and thus it was not executed again and terminated execution of the application due to a syntax error.<br /><br />Just something to help clarify what you have stated in your comments.</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=function.return&amp;redirect=http://php.net/manual/en/function.return.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.control-structures.php">Control Structures</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="control-structures.intro.php" title="Introduction">Introduction</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.if.php" title="if">if</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.else.php" title="else">else</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.elseif.php" title="elseif/else if">elseif/else if</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.alternative-syntax.php" title="Alternative syntax for control structures">Alternative syntax for control structures</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.while.php" title="while">while</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.do.while.php" title="do-&#8203;while">do-&#8203;while</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.for.php" title="for">for</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.foreach.php" title="foreach">foreach</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.break.php" title="break">break</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.continue.php" title="continue">continue</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.switch.php" title="switch">switch</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.declare.php" title="declare">declare</a>
                        </li>
                          
                        <li class="current">
                            <a href="function.return.php" title="return">return</a>
                        </li>
                          
                        <li class="">
                            <a href="function.require.php" title="require">require</a>
                        </li>
                          
                        <li class="">
                            <a href="function.include.php" title="include">include</a>
                        </li>
                          
                        <li class="">
                            <a href="function.require-once.php" title="require_&#8203;once">require_&#8203;once</a>
                        </li>
                          
                        <li class="">
                            <a href="function.include-once.php" title="include_&#8203;once">include_&#8203;once</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.goto.php" title="goto">goto</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

