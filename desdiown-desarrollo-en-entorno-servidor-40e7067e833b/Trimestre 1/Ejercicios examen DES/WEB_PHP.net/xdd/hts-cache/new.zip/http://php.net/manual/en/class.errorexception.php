<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: ErrorException - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/class.errorexception.php">
 <link rel="shorturl" href="http://php.net/errorexception">
 <link rel="alternate" href="http://php.net/errorexception" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/reserved.exceptions.php">
 <link rel="prev" href="http://php.net/manual/en/exception.clone.php">
 <link rel="next" href="http://php.net/manual/en/errorexception.construct.php">

 <link rel="alternate" href="http://php.net/manual/en/class.errorexception.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/class.errorexception.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/class.errorexception.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/class.errorexception.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/class.errorexception.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/class.errorexception.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/class.errorexception.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/class.errorexception.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/class.errorexception.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/class.errorexception.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/class.errorexception.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="errorexception.construct.php">
          ErrorException::__construct &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="exception.clone.php">
          &laquo; Exception::__clone        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='reserved.exceptions.php'>Predefined Exceptions</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/class.errorexception.php' selected="selected">English</option>
            <option value='pt_BR/class.errorexception.php'>Brazilian Portuguese</option>
            <option value='zh/class.errorexception.php'>Chinese (Simplified)</option>
            <option value='fr/class.errorexception.php'>French</option>
            <option value='de/class.errorexception.php'>German</option>
            <option value='ja/class.errorexception.php'>Japanese</option>
            <option value='ro/class.errorexception.php'>Romanian</option>
            <option value='ru/class.errorexception.php'>Russian</option>
            <option value='es/class.errorexception.php'>Spanish</option>
            <option value='tr/class.errorexception.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/class.errorexception.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=class.errorexception">Report a Bug</a>
    </div>
  </div><div id="class.errorexception" class="reference">
 <h1 class="title">ErrorException</h1>
 
 
 <div class="partintro"><p class="verinfo">(PHP 5 &gt;= 5.1.0, PHP 7)</p>
 

  <div class="section" id="errorexception.intro">
   <h2 class="title">Introduction</h2>
   <p class="para">
    An Error Exception.
   </p>
  </div>

 
  <div class="section" id="errorexception.synopsis">
   <h2 class="title">Class synopsis</h2>
 

   <div class="classsynopsis">
    <div class="ooclass"></div>
 

    <div class="classsynopsisinfo">
     <span class="ooclass">
      <strong class="classname">ErrorException</strong>
     </span>
 
     <span class="ooclass">
      <span class="modifier">extends</span>
      <a href="class.exception.php" class="classname">Exception</a>
     </span>
     {</div>

 
    <div class="classsynopsisinfo classsynopsisinfo_comment">/* Properties */</div>
    <div class="fieldsynopsis">
     <span class="modifier">protected</span>
     <span class="type">int</span>
      <var class="varname"><a href="class.errorexception.php#errorexception.props.severity">$<var class="varname">severity</var></a></var>
    ;</div>

 
    <div class="classsynopsisinfo classsynopsisinfo_comment">/* Inherited properties */</div>
    <div class="fieldsynopsis">
     <span class="modifier">protected</span>
     <span class="type">string</span>
      <var class="varname"><a href="class.exception.php#exception.props.message">$<var class="varname">message</var></a></var>
    ;</div>
<div class="fieldsynopsis">
     <span class="modifier">protected</span>
     <span class="type">int</span>
      <var class="varname"><a href="class.exception.php#exception.props.code">$<var class="varname">code</var></a></var>
    ;</div>
<div class="fieldsynopsis">
     <span class="modifier">protected</span>
     <span class="type">string</span>
      <var class="varname"><a href="class.exception.php#exception.props.file">$<var class="varname">file</var></a></var>
    ;</div>
<div class="fieldsynopsis">
     <span class="modifier">protected</span>
     <span class="type">int</span>
      <var class="varname"><a href="class.exception.php#exception.props.line">$<var class="varname">line</var></a></var>
    ;</div>


    <div class="classsynopsisinfo classsynopsisinfo_comment">/* Methods */</div>
    <div class="constructorsynopsis dc-description">
   <span class="modifier">public</span> <span class="methodname"><a href="errorexception.construct.php" class="methodname">__construct</a></span>
    ([ <span class="methodparam"><span class="type">string</span> <code class="parameter">$message</code><span class="initializer"> = &quot;&quot;</span></span>
   [, <span class="methodparam"><span class="type">int</span> <code class="parameter">$code</code><span class="initializer"> = 0</span></span>
   [, <span class="methodparam"><span class="type">int</span> <code class="parameter">$severity</code><span class="initializer"> = E_ERROR</span></span>
   [, <span class="methodparam"><span class="type">string</span> <code class="parameter">$filename</code><span class="initializer"> = __FILE__</span></span>
   [, <span class="methodparam"><span class="type">int</span> <code class="parameter">$lineno</code><span class="initializer"> = __LINE__</span></span>
   [, <span class="methodparam"><span class="type"><a href="class.exception.php" class="type Exception">Exception</a></span> <code class="parameter">$previous</code><span class="initializer"> = <strong><code>NULL</code></strong></span></span>
  ]]]]]] )</div>

    <div class="methodsynopsis dc-description">
   <span class="modifier">final</span> <span class="modifier">public</span> <span class="type">int</span> <span class="methodname"><a href="errorexception.getseverity.php" class="methodname">getSeverity</a></span>
    ( <span class="methodparam">void</span>
   )</div>

 
    <div class="classsynopsisinfo classsynopsisinfo_comment">/* Inherited methods */</div>
    <div class="methodsynopsis dc-description">
   <span class="modifier">final</span> <span class="modifier">public</span> <span class="type">string</span> <span class="methodname"><a href="exception.getmessage.php" class="methodname">Exception::getMessage</a></span>
    ( <span class="methodparam">void</span>
   )</div>
<div class="methodsynopsis dc-description">
   <span class="modifier">final</span> <span class="modifier">public</span> <span class="type">Throwable</span> <span class="methodname"><a href="exception.getprevious.php" class="methodname">Exception::getPrevious</a></span>
    ( <span class="methodparam">void</span>
   )</div>
<div class="methodsynopsis dc-description">
   <span class="modifier">final</span> <span class="modifier">public</span> <span class="type">mixed</span> <span class="methodname"><a href="exception.getcode.php" class="methodname">Exception::getCode</a></span>
    ( <span class="methodparam">void</span>
   )</div>
<div class="methodsynopsis dc-description">
   <span class="modifier">final</span> <span class="modifier">public</span> <span class="type">string</span> <span class="methodname"><a href="exception.getfile.php" class="methodname">Exception::getFile</a></span>
    ( <span class="methodparam">void</span>
   )</div>
<div class="methodsynopsis dc-description">
   <span class="modifier">final</span> <span class="modifier">public</span> <span class="type">int</span> <span class="methodname"><a href="exception.getline.php" class="methodname">Exception::getLine</a></span>
    ( <span class="methodparam">void</span>
   )</div>
<div class="methodsynopsis dc-description">
   <span class="modifier">final</span> <span class="modifier">public</span> <span class="type">array</span> <span class="methodname"><a href="exception.gettrace.php" class="methodname">Exception::getTrace</a></span>
    ( <span class="methodparam">void</span>
   )</div>
<div class="methodsynopsis dc-description">
   <span class="modifier">final</span> <span class="modifier">public</span> <span class="type">string</span> <span class="methodname"><a href="exception.gettraceasstring.php" class="methodname">Exception::getTraceAsString</a></span>
    ( <span class="methodparam">void</span>
   )</div>
<div class="methodsynopsis dc-description">
   <span class="modifier">public</span> <span class="type">string</span>  <span class="methodname"><a href="exception.tostring.php" class="methodname">Exception::__toString</a></span>
    ( <span class="methodparam">void</span>
   )</div>
<div class="methodsynopsis dc-description">
   <span class="modifier">final</span> <span class="modifier">private</span> <span class="type">void</span> <span class="methodname"><a href="exception.clone.php" class="methodname">Exception::__clone</a></span>
    ( <span class="methodparam">void</span>
   )</div>

   }</div>

 
  </div>
 

  <div class="section" id="errorexception.props">
   <h2 class="title">Properties</h2>
   <dl>

    
     <dt id="errorexception.props.severity"><var class="varname"><var class="varname">severity</var></var></dt>

     <dd>

      <p class="para">The severity of the exception</p>
     </dd>

    
   </dl>

  </div>


  <div class="section" id="errorexception.examples">
   <h2 class="title">Examples</h2>
   <p class="para">
    <div class="example" id="variable.post.basic">
     <p><strong>Example #1 Use <span class="function"><a href="function.set-error-handler.php" class="function">set_error_handler()</a></span> to change error messages into ErrorException.</strong></p>
     <div class="example-contents">
 <div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">exception_error_handler</span><span style="color: #007700">(</span><span style="color: #0000BB">$severity</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$message</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$file</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$line</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(!(</span><span style="color: #0000BB">error_reporting</span><span style="color: #007700">()&nbsp;&amp;&nbsp;</span><span style="color: #0000BB">$severity</span><span style="color: #007700">))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;This&nbsp;error&nbsp;code&nbsp;is&nbsp;not&nbsp;included&nbsp;in&nbsp;error_reporting<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">return;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;&nbsp;&nbsp;&nbsp;throw&nbsp;new&nbsp;</span><span style="color: #0000BB">ErrorException</span><span style="color: #007700">(</span><span style="color: #0000BB">$message</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">0</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$severity</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$file</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$line</span><span style="color: #007700">);<br />}<br /></span><span style="color: #0000BB">set_error_handler</span><span style="color: #007700">(</span><span style="color: #DD0000">"exception_error_handler"</span><span style="color: #007700">);<br /><br /></span><span style="color: #FF8000">/*&nbsp;Trigger&nbsp;exception&nbsp;*/<br /></span><span style="color: #0000BB">strpos</span><span style="color: #007700">();<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

     <div class="example-contents"><p>The above example will output
something similar to:</p></div>
     <div class="example-contents screen">
<div class="cdata"><pre>
Fatal error: Uncaught exception &#039;ErrorException&#039; with message &#039;strpos() expects at least 2 parameters, 0 given&#039; in /home/bjori/tmp/ex.php:12
Stack trace:
#0 [internal function]: exception_error_handler(2, &#039;strpos() expect...&#039;, &#039;/home/bjori/php...&#039;, 12, Array)
#1 /home/bjori/php/cleandocs/test.php(12): strpos()
#2 {main}
  thrown in /home/bjori/tmp/ex.php on line 12
</pre></div>
     </div>
    </div>
   </p>
  </div>
 
 </div>
 
 



 



 



 



 
<h2>Table of Contents</h2><ul class="chunklist chunklist_reference"><li><a href="errorexception.construct.php">ErrorException::__construct</a> — Constructs the exception</li><li><a href="errorexception.getseverity.php">ErrorException::getSeverity</a> — Gets the exception severity</li></ul>
</div>

<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=class.errorexception&amp;redirect=http://php.net/manual/en/class.errorexception.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">5 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="95415">  <div class="votes">
    <div id="Vu95415">
    <a href="/manual/vote-note.php?id=95415&amp;page=class.errorexception&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd95415">
    <a href="/manual/vote-note.php?id=95415&amp;page=class.errorexception&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V95415" title="77% like this...">
    12
    </div>
  </div>
  <a href="#95415" class="name">
  <strong class="user"><em>triplepoint at gmail dot com</em></strong></a><a class="genanchor" href="#95415"> &para;</a><div class="date" title="2010-01-01 08:16"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom95415">
<div class="phpcode"><code><span class="html">
As noted below, it's important to realize that unless caught, any Exception thrown will halt the script.&nbsp; So converting EVERY notice, warning, or error to an ErrorException will halt your script when something harmlesss like E_USER_NOTICE is triggered.<br /><br />It seems to me the best use of the ErrorException class is something like this:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">custom_error_handler</span><span class="keyword">(</span><span class="default">$number</span><span class="keyword">, </span><span class="default">$string</span><span class="keyword">, </span><span class="default">$file</span><span class="keyword">, </span><span class="default">$line</span><span class="keyword">, </span><span class="default">$context</span><span class="keyword">) <br />{<br />&nbsp; &nbsp; </span><span class="comment">// Determine if this error is one of the enabled ones in php config (php.ini, .htaccess, etc)<br />&nbsp; &nbsp; </span><span class="default">$error_is_enabled </span><span class="keyword">= (bool)(</span><span class="default">$number </span><span class="keyword">&amp; </span><span class="default">ini_get</span><span class="keyword">(</span><span class="string">'error_reporting'</span><span class="keyword">) );<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">// -- FATAL ERROR<br />&nbsp; &nbsp; // throw an Error Exception, to be handled by whatever Exception handling logic is available in this context<br />&nbsp; &nbsp; </span><span class="keyword">if( </span><span class="default">in_array</span><span class="keyword">(</span><span class="default">$number</span><span class="keyword">, array(</span><span class="default">E_USER_ERROR</span><span class="keyword">, </span><span class="default">E_RECOVERABLE_ERROR</span><span class="keyword">)) &amp;&amp; </span><span class="default">$error_is_enabled </span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">ErrorException</span><span class="keyword">(</span><span class="default">$errstr</span><span class="keyword">, </span><span class="default">0</span><span class="keyword">, </span><span class="default">$errno</span><span class="keyword">, </span><span class="default">$errfile</span><span class="keyword">, </span><span class="default">$errline</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">// -- NON-FATAL ERROR/WARNING/NOTICE<br />&nbsp; &nbsp; // Log the error if it's enabled, otherwise just ignore it<br />&nbsp; &nbsp; </span><span class="keyword">else if( </span><span class="default">$error_is_enabled </span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">error_log</span><span class="keyword">( </span><span class="default">$string</span><span class="keyword">, </span><span class="default">0 </span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">false</span><span class="keyword">; </span><span class="comment">// Make sure this ends up in $php_errormsg, if appropriate<br />&nbsp; &nbsp; </span><span class="keyword">}<br />}<br /></span><span class="default">?&gt;<br /></span><br />Setting this function as the error handler will result in ErrorExceptions only being thrown for E_USER_ERROR and E_RECOVERABLE_ERROR, while other enabled error types will simply get error_log()'ed.<br /><br />It's worth noting again that no matter what you do, "E_ERROR, E_PARSE, E_CORE_ERROR, E_CORE_WARNING, E_COMPILE_ERROR, E_COMPILE_WARNING, and most of E_STRICT" will never reach your custom error handler, and therefore will not be converted into ErrorExceptions.&nbsp; Plan accordingly.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="89132">  <div class="votes">
    <div id="Vu89132">
    <a href="/manual/vote-note.php?id=89132&amp;page=class.errorexception&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd89132">
    <a href="/manual/vote-note.php?id=89132&amp;page=class.errorexception&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V89132" title="73% like this...">
    7
    </div>
  </div>
  <a href="#89132" class="name">
  <strong class="user"><em>luke at cywh dot com</em></strong></a><a class="genanchor" href="#89132"> &para;</a><div class="date" title="2009-02-23 11:56"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom89132">
<div class="phpcode"><code><span class="html">
To add to the comments made by chris AT cmbuckley DOT co DOT uk about the ErrorException problem with args:<br /><br />I noticed that the problem is in the ErrorException class itself, not the Exception class. When using just the exception class, it's no longer an issue. Besides the args problem, the only difference between Exception and ErrorException in the stack trace is that the args are left out of the error handler exception function. I'm not sure if this was on purpose or not, but it shouldn't hurt to show this information anyway.<br /><br />So instead of using this broken extended class, you can ignore it and make your own extended class and avoid the problem all together:<br /><br /><span class="default">&lt;?php<br /><br />header</span><span class="keyword">(</span><span class="string">'Content-Type: text/plain'</span><span class="keyword">);<br /><br />class </span><span class="default">ErrorHandler </span><span class="keyword">extends </span><span class="default">Exception </span><span class="keyword">{<br />&nbsp; &nbsp; protected </span><span class="default">$severity</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$message</span><span class="keyword">, </span><span class="default">$code</span><span class="keyword">, </span><span class="default">$severity</span><span class="keyword">, </span><span class="default">$filename</span><span class="keyword">, </span><span class="default">$lineno</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">message </span><span class="keyword">= </span><span class="default">$message</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">code </span><span class="keyword">= </span><span class="default">$code</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">severity </span><span class="keyword">= </span><span class="default">$severity</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">file </span><span class="keyword">= </span><span class="default">$filename</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">line </span><span class="keyword">= </span><span class="default">$lineno</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">getSeverity</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">severity</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />function </span><span class="default">exception_error_handler</span><span class="keyword">(</span><span class="default">$errno</span><span class="keyword">, </span><span class="default">$errstr</span><span class="keyword">, </span><span class="default">$errfile</span><span class="keyword">, </span><span class="default">$errline </span><span class="keyword">) {<br />&nbsp; &nbsp; throw new </span><span class="default">ErrorHandler</span><span class="keyword">(</span><span class="default">$errstr</span><span class="keyword">, </span><span class="default">0</span><span class="keyword">, </span><span class="default">$errno</span><span class="keyword">, </span><span class="default">$errfile</span><span class="keyword">, </span><span class="default">$errline</span><span class="keyword">);<br />}<br /><br /></span><span class="default">set_error_handler</span><span class="keyword">(</span><span class="string">"exception_error_handler"</span><span class="keyword">, </span><span class="default">E_ALL</span><span class="keyword">);<br /><br />function </span><span class="default">A</span><span class="keyword">() {<br />&nbsp; &nbsp; </span><span class="default">$foo</span><span class="keyword">-&gt;</span><span class="default">bar</span><span class="keyword">; </span><span class="comment">// Purposely cause error<br /></span><span class="keyword">}<br /><br />function </span><span class="default">B</span><span class="keyword">(</span><span class="default">$c</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">A</span><span class="keyword">();<br />}<br /><br />try {<br />&nbsp; &nbsp; </span><span class="default">B</span><span class="keyword">(</span><span class="string">'foobar'</span><span class="keyword">);<br />} catch (</span><span class="default">Exception $e</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$e</span><span class="keyword">-&gt;</span><span class="default">getTrace</span><span class="keyword">());<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />The only thing I wish I could do was remove the entry for the error handler function because it's quite irrelevant. Maybe that's what they were trying to do with the ErrorException class? Either way, you can't change it because the trace functions are final, and the variable is private.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="95072">  <div class="votes">
    <div id="Vu95072">
    <a href="/manual/vote-note.php?id=95072&amp;page=class.errorexception&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd95072">
    <a href="/manual/vote-note.php?id=95072&amp;page=class.errorexception&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V95072" title="62% like this...">
    9
    </div>
  </div>
  <a href="#95072" class="name">
  <strong class="user"><em>randallgirard at hotmail dot com</em></strong></a><a class="genanchor" href="#95072"> &para;</a><div class="date" title="2009-12-11 03:32"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom95072">
<div class="phpcode"><code><span class="html">
E_USER_WARNING, E_USER_NOTICE, and any other non-terminating error codes, are useless and act like E_USER_ERROR (which terminate) when you combine a custom ERROR_HANDLER with ErrorException and do not CATCH the error. There is NO way to return execution to the parent scope in the EXCEPTION_HANDLER.<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; error_reporting</span><span class="keyword">(</span><span class="default">E_ALL</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">define</span><span class="keyword">(</span><span class="string">'DEBUG'</span><span class="keyword">, </span><span class="default">true</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">define</span><span class="keyword">(</span><span class="string">'LINEBREAK'</span><span class="keyword">, </span><span class="string">"\r\n"</span><span class="keyword">);<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="default">error</span><span class="keyword">::</span><span class="default">initiate</span><span class="keyword">(</span><span class="string">'./error_backtrace.log'</span><span class="keyword">);<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; try<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">trigger_error</span><span class="keyword">(</span><span class="string">"First error"</span><span class="keyword">, </span><span class="default">E_USER_NOTICE</span><span class="keyword">);<br />&nbsp; &nbsp; catch ( </span><span class="default">ErrorException $e </span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; print(</span><span class="string">"Caught the error: "</span><span class="keyword">.</span><span class="default">$e</span><span class="keyword">-&gt;</span><span class="default">getMessage</span><span class="keyword">.</span><span class="string">"&lt;br /&gt;\r\n" </span><span class="keyword">);<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="default">trigger_error</span><span class="keyword">(</span><span class="string">"This event WILL fire"</span><span class="keyword">, </span><span class="default">E_USER_NOTICE</span><span class="keyword">);<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="default">trigger_error</span><span class="keyword">(</span><span class="string">"This event will NOT fire"</span><span class="keyword">, </span><span class="default">E_USER_NOTICE</span><span class="keyword">);<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; abstract class </span><span class="default">error </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; public static </span><span class="default">$LIST </span><span class="keyword">= array();<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; private function </span><span class="default">__construct</span><span class="keyword">() {}<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; public static function </span><span class="default">initiate</span><span class="keyword">( </span><span class="default">$log </span><span class="keyword">= </span><span class="default">false </span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">set_error_handler</span><span class="keyword">( </span><span class="string">'error::err_handler' </span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">set_exception_handler</span><span class="keyword">( </span><span class="string">'error::exc_handler' </span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if ( </span><span class="default">$log </span><span class="keyword">!== </span><span class="default">false </span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if ( ! </span><span class="default">ini_get</span><span class="keyword">(</span><span class="string">'log_errors'</span><span class="keyword">) )<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">ini_set</span><span class="keyword">(</span><span class="string">'log_errors'</span><span class="keyword">, </span><span class="default">true</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if ( ! </span><span class="default">ini_get</span><span class="keyword">(</span><span class="string">'error_log'</span><span class="keyword">) )<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">ini_set</span><span class="keyword">(</span><span class="string">'error_log'</span><span class="keyword">, </span><span class="default">$log</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; public static function </span><span class="default">err_handler</span><span class="keyword">(</span><span class="default">$errno</span><span class="keyword">, </span><span class="default">$errstr</span><span class="keyword">, </span><span class="default">$errfile</span><span class="keyword">, </span><span class="default">$errline</span><span class="keyword">, </span><span class="default">$errcontext</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$l </span><span class="keyword">= </span><span class="default">error_reporting</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if ( </span><span class="default">$l </span><span class="keyword">&amp; </span><span class="default">$errno </span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$exit </span><span class="keyword">= </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; switch ( </span><span class="default">$errno </span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">E_USER_ERROR</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$type </span><span class="keyword">= </span><span class="string">'Fatal Error'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$exit </span><span class="keyword">= </span><span class="default">true</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">E_USER_WARNING</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">E_WARNING</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$type </span><span class="keyword">= </span><span class="string">'Warning'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">E_USER_NOTICE</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">E_NOTICE</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case @</span><span class="default">E_STRICT</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$type </span><span class="keyword">= </span><span class="string">'Notice'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case @</span><span class="default">E_RECOVERABLE_ERROR</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$type </span><span class="keyword">= </span><span class="string">'Catchable'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; default:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$type </span><span class="keyword">= </span><span class="string">'Unknown Error'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$exit </span><span class="keyword">= </span><span class="default">true</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$exception </span><span class="keyword">= new \</span><span class="default">ErrorException</span><span class="keyword">(</span><span class="default">$type</span><span class="keyword">.</span><span class="string">': '</span><span class="keyword">.</span><span class="default">$errstr</span><span class="keyword">, </span><span class="default">0</span><span class="keyword">, </span><span class="default">$errno</span><span class="keyword">, </span><span class="default">$errfile</span><span class="keyword">, </span><span class="default">$errline</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if ( </span><span class="default">$exit </span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">exc_handler</span><span class="keyword">(</span><span class="default">$exception</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; exit();<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw </span><span class="default">$exception</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; function </span><span class="default">exc_handler</span><span class="keyword">(</span><span class="default">$exception</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$log </span><span class="keyword">= </span><span class="default">$exception</span><span class="keyword">-&gt;</span><span class="default">getMessage</span><span class="keyword">() . </span><span class="string">"\n" </span><span class="keyword">. </span><span class="default">$exception</span><span class="keyword">-&gt;</span><span class="default">getTraceAsString</span><span class="keyword">() . </span><span class="default">LINEBREAK</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if ( </span><span class="default">ini_get</span><span class="keyword">(</span><span class="string">'log_errors'</span><span class="keyword">) )<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">error_log</span><span class="keyword">(</span><span class="default">$log</span><span class="keyword">, </span><span class="default">0</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; print(</span><span class="string">"Unhandled Exception" </span><span class="keyword">. (</span><span class="default">DEBUG </span><span class="keyword">? </span><span class="string">" - </span><span class="default">$log</span><span class="string">" </span><span class="keyword">: </span><span class="string">''</span><span class="keyword">));<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; }<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120887">  <div class="votes">
    <div id="Vu120887">
    <a href="/manual/vote-note.php?id=120887&amp;page=class.errorexception&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120887">
    <a href="/manual/vote-note.php?id=120887&amp;page=class.errorexception&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120887" title="100% like this...">
    1
    </div>
  </div>
  <a href="#120887" class="name">
  <strong class="user"><em>Kevin</em></strong></a><a class="genanchor" href="#120887"> &para;</a><div class="date" title="2017-03-28 09:13"><strong>8 months ago</strong></div>
  <div class="text" id="Hcom120887">
<div class="phpcode"><code><span class="html">
I have been Googling all over the place for how to convert an E_NOTICE error into an exception, and I think I finally found a clean way to do it:<br /><br />@include "errorcausingcode.php";<br /><br />$lastError = error_get_last();<br />if ( !empty( $lastError ) ) {<br />&nbsp; &nbsp; throw new TemplateRenderingException($lastError['message'], $lastError['type']);<br />}<br /><br />Basically, if it's something not system haulting it will likely hit this. Then you can throw whatever exception you want. Now, this is of course if you have a need. I did, because I wanted to clean up my output buffer if there was an error that skipped over it.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="110133">  <div class="votes">
    <div id="Vu110133">
    <a href="/manual/vote-note.php?id=110133&amp;page=class.errorexception&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd110133">
    <a href="/manual/vote-note.php?id=110133&amp;page=class.errorexception&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V110133" title="23% like this...">
    -9
    </div>
  </div>
  <a href="#110133" class="name">
  <strong class="user"><em>xianrenb at gmail dot com</em></strong></a><a class="genanchor" href="#110133"> &para;</a><div class="date" title="2012-09-23 02:33"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom110133">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">exception_error_handler</span><span class="keyword">(</span><span class="default">$errno</span><span class="keyword">, </span><span class="default">$errstr</span><span class="keyword">, </span><span class="default">$errfile</span><span class="keyword">, </span><span class="default">$errline </span><span class="keyword">) {<br />&nbsp; &nbsp; throw new </span><span class="default">ErrorException</span><span class="keyword">(</span><span class="default">$errstr</span><span class="keyword">, </span><span class="default">$errno</span><span class="keyword">, </span><span class="default">0</span><span class="keyword">, </span><span class="default">$errfile</span><span class="keyword">, </span><span class="default">$errline</span><span class="keyword">);<br />}<br /></span><span class="default">set_error_handler</span><span class="keyword">(</span><span class="string">"exception_error_handler"</span><span class="keyword">);<br /><br /></span><span class="comment">/* Trigger exception */<br /></span><span class="default">strpos</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span><br />Please note that property $severity of class ErrorException is set to a constant zero for all kinds of errors in the above example.<br /><br />I think it was a bug and tried to file a bug report, but it was closed as not a bug, so I could not say the above is wrong.<br /><br />Let me show an example that uses $severity not as a constant:<br /><span class="default">&lt;?php<br />&nbsp; set_error_handler</span><span class="keyword">(function (</span><span class="default">$errno</span><span class="keyword">, </span><span class="default">$errstr</span><span class="keyword">, </span><span class="default">$errfile</span><span class="keyword">, </span><span class="default">$errline</span><span class="keyword">) {<br />&nbsp; &nbsp; throw new </span><span class="default">ErrorException</span><span class="keyword">(</span><span class="default">$errstr</span><span class="keyword">, </span><span class="default">0</span><span class="keyword">, </span><span class="default">$errno</span><span class="keyword">, </span><span class="default">$errfile</span><span class="keyword">, </span><span class="default">$errline</span><span class="keyword">);<br />&nbsp; });<br /><br />&nbsp; class </span><span class="default">MyClass </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">methodA</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; echo(</span><span class="string">"methodA:\n"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; </span><span class="default">strpos</span><span class="keyword">();<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">methodB</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; echo(</span><span class="string">"methodB:\n"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; </span><span class="default">trigger_error</span><span class="keyword">(</span><span class="string">"warning message form methodB"</span><span class="keyword">, </span><span class="default">E_WARNING</span><span class="keyword">);<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">methodC</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; echo(</span><span class="string">"methodC:\n"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; throw new </span><span class="default">ErrorException</span><span class="keyword">();<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">methodD</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; echo(</span><span class="string">"methodD:\n"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; throw new </span><span class="default">ErrorException</span><span class="keyword">(</span><span class="string">'warning message from methodD'</span><span class="keyword">, </span><span class="default">0</span><span class="keyword">, <br /></span><span class="default">E_WARNING</span><span class="keyword">);<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">run</span><span class="keyword">(</span><span class="default">$i</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$i </span><span class="keyword">=== </span><span class="default">0</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">methodA</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; } else if (</span><span class="default">$i </span><span class="keyword">=== </span><span class="default">1</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">methodB</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; } else if (</span><span class="default">$i </span><span class="keyword">=== </span><span class="default">2</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">methodC</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">methodD</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">test</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; for (</span><span class="default">$i </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">; </span><span class="default">$i </span><span class="keyword">&lt; </span><span class="default">4</span><span class="keyword">; ++</span><span class="default">$i</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; try {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">run</span><span class="keyword">(</span><span class="default">$i</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; } catch (</span><span class="default">ErrorException $e</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$e</span><span class="keyword">-&gt;</span><span class="default">getSeverity</span><span class="keyword">() === </span><span class="default">E_ERROR</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo(</span><span class="string">"E_ERROR triggered.\n"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; } else if (</span><span class="default">$e</span><span class="keyword">-&gt;</span><span class="default">getSeverity</span><span class="keyword">() === </span><span class="default">E_WARNING</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo(</span><span class="string">"E_WARNING triggered.\n"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; }<br /><br />&nbsp; </span><span class="default">$myClass </span><span class="keyword">= new </span><span class="default">MyClass</span><span class="keyword">();<br />&nbsp; </span><span class="default">$myClass</span><span class="keyword">-&gt;</span><span class="default">test</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span><br />Please note that methodC() uses (constructor of) class ErrorException with default parameters.<br /><br />I believe it is the original intention to make $severity having default value of 1, which is exactly equal to E_ERROR.<br /><br />Using property $code or Exception::getCode() to compare with E_* values could not do the same thing (as in methodC()), as $code has a default value of 0, and class Exception has it too, users may use $code for some other purposes.</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=class.errorexception&amp;redirect=http://php.net/manual/en/class.errorexception.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="reserved.exceptions.php">Predefined Exceptions</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="class.exception.php" title="Exception">Exception</a>
                        </li>
                          
                        <li class="current">
                            <a href="class.errorexception.php" title="ErrorException">ErrorException</a>
                        </li>
                          
                        <li class="">
                            <a href="class.error.php" title="Error">Error</a>
                        </li>
                          
                        <li class="">
                            <a href="class.argumentcounterror.php" title="ArgumentCountError">ArgumentCountError</a>
                        </li>
                          
                        <li class="">
                            <a href="class.arithmeticerror.php" title="ArithmeticError">ArithmeticError</a>
                        </li>
                          
                        <li class="">
                            <a href="class.assertionerror.php" title="AssertionError">AssertionError</a>
                        </li>
                          
                        <li class="">
                            <a href="class.divisionbyzeroerror.php" title="DivisionByZeroError">DivisionByZeroError</a>
                        </li>
                          
                        <li class="">
                            <a href="class.parseerror.php" title="ParseError">ParseError</a>
                        </li>
                          
                        <li class="">
                            <a href="class.typeerror.php" title="TypeError">TypeError</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

