<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Name resolution rules - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.namespaces.rules.php">
 <link rel="shorturl" href="http://php.net/namespaces.rules">
 <link rel="alternate" href="http://php.net/namespaces.rules" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.namespaces.php">
 <link rel="prev" href="http://php.net/manual/en/language.namespaces.fallback.php">
 <link rel="next" href="http://php.net/manual/en/language.namespaces.faq.php">

 <link rel="alternate" href="http://php.net/manual/en/language.namespaces.rules.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.namespaces.rules.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.namespaces.rules.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.namespaces.rules.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.namespaces.rules.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.namespaces.rules.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.namespaces.rules.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.namespaces.rules.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.namespaces.rules.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.namespaces.rules.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.namespaces.rules.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.namespaces.faq.php">
          FAQ: things you need to know about namespaces &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.namespaces.fallback.php">
          &laquo; Using namespaces: fallback to global function/constant        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.namespaces.php'>Namespaces</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.namespaces.rules.php' selected="selected">English</option>
            <option value='pt_BR/language.namespaces.rules.php'>Brazilian Portuguese</option>
            <option value='zh/language.namespaces.rules.php'>Chinese (Simplified)</option>
            <option value='fr/language.namespaces.rules.php'>French</option>
            <option value='de/language.namespaces.rules.php'>German</option>
            <option value='ja/language.namespaces.rules.php'>Japanese</option>
            <option value='ro/language.namespaces.rules.php'>Romanian</option>
            <option value='ru/language.namespaces.rules.php'>Russian</option>
            <option value='es/language.namespaces.rules.php'>Spanish</option>
            <option value='tr/language.namespaces.rules.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.namespaces.rules.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.namespaces.rules">Report a Bug</a>
    </div>
  </div><div id="language.namespaces.rules" class="sect1">
  <h2 class="title">Name resolution rules</h2>
  <p class="verinfo">(PHP 5 &gt;= 5.3.0, PHP 7)</p>
  <p class="para">
   For the purposes of these resolution rules, here are some important definitions:
   <dl>

    <strong class="title">Namespace name definitions</strong>
    
     <dt>
Unqualified name</dt>

     <dd>

      <p class="para">
       This is an identifier without a namespace separator, such as <em>Foo</em>
      </p>
     </dd>

    
    
     <dt>
Qualified name</dt>

     <dd>

      <p class="para">
       This is an identifier with a namespace separator, such as <em>Foo\Bar</em>
      </p>
     </dd>

    
    
     <dt>
Fully qualified name</dt>

     <dd>

      <p class="para">
       This is an identifier with a namespace separator that begins with a
       namespace separator, such as <em>\Foo\Bar</em>. The namespace
       <em>\Foo</em> is also a fully qualified name.
      </p>
     </dd>

    
    
     <dt>
Relative name</dt>

     <dd>

      <p class="para">
       This is an identifier starting with <em>namespace</em>, such as
       <em>namespace\Foo\Bar</em>.
      </p>
     </dd>

    
   </dl>

  </p>
  <p class="para">
   Names are resolved following these resolution rules:
   <ol type="1">
    <li class="listitem">
     <span class="simpara">
      Fully qualified names always resolve to the name without leading namespace separator.
      For instance <em>\A\B</em> resolves to <em>A\B</em>.
     </span>
    </li>
    <li class="listitem">
     <span class="simpara">
      Relative names always resolve to the name with <em>namespace</em> replaced by
      the current namespace. If the name occurs in the global namespace, the
      <em>namespace\</em> prefix is stripped. For example <em>namespace\A</em>
      inside namespace <em>X\Y</em> resolves to <em>X\Y\A</em>. The same name
      inside the global namespace resolves to <em>A</em>.
     </span>
    </li>
    <li class="listitem">
     <span class="simpara">
      For qualified names the first segment of the name is translated according to the current
      class/namespace import table. For example, if the namespace <em>A\B\C</em> is
      imported as <em>C</em>, the name <em>C\D\E</em> is translated to
      <em>A\B\C\D\E</em>.
     </span>
    </li>
    <li class="listitem">
     <span class="simpara">
      For qualified names, if no import rule applies, the current namespace is prepended to the
      name. For example, the name <em>C\D\E</em> inside namespace <em>A\B</em>,
      resolves to <em>A\B\C\D\E</em>.
     </span>
    </li>
    <li class="listitem">
     <span class="simpara">
      For unqualified names, the name is translated according to the current import table for the
      respective symbol type. This means that class-like names are translated according to the
      class/namespace import table, function names according to the function import table and
      constants according to the constant import table. For example, after
      <em>use A\B\C;</em> a usage such as <em>new C()</em> resolves to the name
      <em>A\B\C()</em>. Similarly, after <em>use function A\B\fn;</em> a usage
      such as <em>fn()</em> resolves to the name <em>A\B\fn</em>.
     </span>
    </li>
    <li class="listitem">
     <span class="simpara">
      For unqualified names, if no import rule applies and the name refers to a class-like symbol,
      the current namespace is prepended. For example <em>new C()</em> inside namespace
      <em>A\B</em> resolves to name <em>A\B\C</em>.
     </span>
    </li>
    <li class="listitem">
     <span class="simpara">
      For unqualified names, if no import rule applies and the name refers to a function or constant
      and the code is outside the global namespace, the name is resolved at runtime.
      Assuming the code is in namespace <em>A\B</em>, here is how a call to function
      <em>foo()</em> is resolved:
     </span>
      <ol type="1">
       <li class="listitem">
        <span class="simpara">
         It looks for a function from the current namespace:
         <em>A\B\foo()</em>.
        </span>
       </li>
       <li class="listitem">
        <span class="simpara">
         It tries to find and call the <em class="emphasis">global</em> function
         <em>foo()</em>.
        </span>
       </li>
      </ol>
    </li>
   </ol>
  </p>
  <div class="example" id="example-266">
   <p><strong>Example #1 Name resolutions illustrated</strong></p>
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">namespace&nbsp;</span><span style="color: #0000BB">A</span><span style="color: #007700">;<br />use&nbsp;</span><span style="color: #0000BB">B</span><span style="color: #007700">\</span><span style="color: #0000BB">D</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">C</span><span style="color: #007700">\</span><span style="color: #0000BB">E&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">F</span><span style="color: #007700">;<br /><br /></span><span style="color: #FF8000">//&nbsp;function&nbsp;calls<br /><br /></span><span style="color: #0000BB">foo</span><span style="color: #007700">();&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;first&nbsp;tries&nbsp;to&nbsp;call&nbsp;"foo"&nbsp;defined&nbsp;in&nbsp;namespace&nbsp;"A"<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;then&nbsp;calls&nbsp;global&nbsp;function&nbsp;"foo"<br /><br /></span><span style="color: #007700">\</span><span style="color: #0000BB">foo</span><span style="color: #007700">();&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;calls&nbsp;function&nbsp;"foo"&nbsp;defined&nbsp;in&nbsp;global&nbsp;scope<br /><br /></span><span style="color: #0000BB">my</span><span style="color: #007700">\</span><span style="color: #0000BB">foo</span><span style="color: #007700">();&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;calls&nbsp;function&nbsp;"foo"&nbsp;defined&nbsp;in&nbsp;namespace&nbsp;"A\my"<br /><br /></span><span style="color: #0000BB">F</span><span style="color: #007700">();&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;first&nbsp;tries&nbsp;to&nbsp;call&nbsp;"F"&nbsp;defined&nbsp;in&nbsp;namespace&nbsp;"A"<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;then&nbsp;calls&nbsp;global&nbsp;function&nbsp;"F"<br /><br />//&nbsp;class&nbsp;references<br /><br /></span><span style="color: #007700">new&nbsp;</span><span style="color: #0000BB">B</span><span style="color: #007700">();&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;creates&nbsp;object&nbsp;of&nbsp;class&nbsp;"B"&nbsp;defined&nbsp;in&nbsp;namespace&nbsp;"A"<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;if&nbsp;not&nbsp;found,&nbsp;it&nbsp;tries&nbsp;to&nbsp;autoload&nbsp;class&nbsp;"A\B"<br /><br /></span><span style="color: #007700">new&nbsp;</span><span style="color: #0000BB">D</span><span style="color: #007700">();&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;using&nbsp;import&nbsp;rules,&nbsp;creates&nbsp;object&nbsp;of&nbsp;class&nbsp;"D"&nbsp;defined&nbsp;in&nbsp;namespace&nbsp;"B"<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;if&nbsp;not&nbsp;found,&nbsp;it&nbsp;tries&nbsp;to&nbsp;autoload&nbsp;class&nbsp;"B\D"<br /><br /></span><span style="color: #007700">new&nbsp;</span><span style="color: #0000BB">F</span><span style="color: #007700">();&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;using&nbsp;import&nbsp;rules,&nbsp;creates&nbsp;object&nbsp;of&nbsp;class&nbsp;"E"&nbsp;defined&nbsp;in&nbsp;namespace&nbsp;"C"<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;if&nbsp;not&nbsp;found,&nbsp;it&nbsp;tries&nbsp;to&nbsp;autoload&nbsp;class&nbsp;"C\E"<br /><br /></span><span style="color: #007700">new&nbsp;\</span><span style="color: #0000BB">B</span><span style="color: #007700">();&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;creates&nbsp;object&nbsp;of&nbsp;class&nbsp;"B"&nbsp;defined&nbsp;in&nbsp;global&nbsp;scope<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;if&nbsp;not&nbsp;found,&nbsp;it&nbsp;tries&nbsp;to&nbsp;autoload&nbsp;class&nbsp;"B"<br /><br /></span><span style="color: #007700">new&nbsp;\</span><span style="color: #0000BB">D</span><span style="color: #007700">();&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;creates&nbsp;object&nbsp;of&nbsp;class&nbsp;"D"&nbsp;defined&nbsp;in&nbsp;global&nbsp;scope<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;if&nbsp;not&nbsp;found,&nbsp;it&nbsp;tries&nbsp;to&nbsp;autoload&nbsp;class&nbsp;"D"<br /><br /></span><span style="color: #007700">new&nbsp;\</span><span style="color: #0000BB">F</span><span style="color: #007700">();&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;creates&nbsp;object&nbsp;of&nbsp;class&nbsp;"F"&nbsp;defined&nbsp;in&nbsp;global&nbsp;scope<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;if&nbsp;not&nbsp;found,&nbsp;it&nbsp;tries&nbsp;to&nbsp;autoload&nbsp;class&nbsp;"F"<br /><br />//&nbsp;static&nbsp;methods/namespace&nbsp;functions&nbsp;from&nbsp;another&nbsp;namespace<br /><br /></span><span style="color: #0000BB">B</span><span style="color: #007700">\</span><span style="color: #0000BB">foo</span><span style="color: #007700">();&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;calls&nbsp;function&nbsp;"foo"&nbsp;from&nbsp;namespace&nbsp;"A\B"<br /><br /></span><span style="color: #0000BB">B</span><span style="color: #007700">::</span><span style="color: #0000BB">foo</span><span style="color: #007700">();&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;calls&nbsp;method&nbsp;"foo"&nbsp;of&nbsp;class&nbsp;"B"&nbsp;defined&nbsp;in&nbsp;namespace&nbsp;"A"<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;if&nbsp;class&nbsp;"A\B"&nbsp;not&nbsp;found,&nbsp;it&nbsp;tries&nbsp;to&nbsp;autoload&nbsp;class&nbsp;"A\B"<br /><br /></span><span style="color: #0000BB">D</span><span style="color: #007700">::</span><span style="color: #0000BB">foo</span><span style="color: #007700">();&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;using&nbsp;import&nbsp;rules,&nbsp;calls&nbsp;method&nbsp;"foo"&nbsp;of&nbsp;class&nbsp;"D"&nbsp;defined&nbsp;in&nbsp;namespace&nbsp;"B"<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;if&nbsp;class&nbsp;"B\D"&nbsp;not&nbsp;found,&nbsp;it&nbsp;tries&nbsp;to&nbsp;autoload&nbsp;class&nbsp;"B\D"<br /><br /></span><span style="color: #007700">\</span><span style="color: #0000BB">B</span><span style="color: #007700">\</span><span style="color: #0000BB">foo</span><span style="color: #007700">();&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;calls&nbsp;function&nbsp;"foo"&nbsp;from&nbsp;namespace&nbsp;"B"<br /><br /></span><span style="color: #007700">\</span><span style="color: #0000BB">B</span><span style="color: #007700">::</span><span style="color: #0000BB">foo</span><span style="color: #007700">();&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;calls&nbsp;method&nbsp;"foo"&nbsp;of&nbsp;class&nbsp;"B"&nbsp;from&nbsp;global&nbsp;scope<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;if&nbsp;class&nbsp;"B"&nbsp;not&nbsp;found,&nbsp;it&nbsp;tries&nbsp;to&nbsp;autoload&nbsp;class&nbsp;"B"<br /><br />//&nbsp;static&nbsp;methods/namespace&nbsp;functions&nbsp;of&nbsp;current&nbsp;namespace<br /><br /></span><span style="color: #0000BB">A</span><span style="color: #007700">\</span><span style="color: #0000BB">B</span><span style="color: #007700">::</span><span style="color: #0000BB">foo</span><span style="color: #007700">();&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;calls&nbsp;method&nbsp;"foo"&nbsp;of&nbsp;class&nbsp;"B"&nbsp;from&nbsp;namespace&nbsp;"A\A"<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;if&nbsp;class&nbsp;"A\A\B"&nbsp;not&nbsp;found,&nbsp;it&nbsp;tries&nbsp;to&nbsp;autoload&nbsp;class&nbsp;"A\A\B"<br /><br /></span><span style="color: #007700">\</span><span style="color: #0000BB">A</span><span style="color: #007700">\</span><span style="color: #0000BB">B</span><span style="color: #007700">::</span><span style="color: #0000BB">foo</span><span style="color: #007700">();&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;calls&nbsp;method&nbsp;"foo"&nbsp;of&nbsp;class&nbsp;"B"&nbsp;from&nbsp;namespace&nbsp;"A"<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;if&nbsp;class&nbsp;"A\B"&nbsp;not&nbsp;found,&nbsp;it&nbsp;tries&nbsp;to&nbsp;autoload&nbsp;class&nbsp;"A\B"<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>
 </div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.namespaces.rules&amp;redirect=http://php.net/manual/en/language.namespaces.rules.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">10 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="100645">  <div class="votes">
    <div id="Vu100645">
    <a href="/manual/vote-note.php?id=100645&amp;page=language.namespaces.rules&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd100645">
    <a href="/manual/vote-note.php?id=100645&amp;page=language.namespaces.rules&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V100645" title="84% like this...">
    17
    </div>
  </div>
  <a href="#100645" class="name">
  <strong class="user"><em>kdimi</em></strong></a><a class="genanchor" href="#100645"> &para;</a><div class="date" title="2010-10-27 06:35"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom100645">
<div class="phpcode"><code><span class="html">
If you like to declare an __autoload function within a namespace or class, use the spl_autoload_register() function to register it and it will work fine.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="92608">  <div class="votes">
    <div id="Vu92608">
    <a href="/manual/vote-note.php?id=92608&amp;page=language.namespaces.rules&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd92608">
    <a href="/manual/vote-note.php?id=92608&amp;page=language.namespaces.rules&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V92608" title="73% like this...">
    14
    </div>
  </div>
  <a href="#92608" class="name">
  <strong class="user"><em>rangel</em></strong></a><a class="genanchor" href="#92608"> &para;</a><div class="date" title="2009-07-31 12:48"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom92608">
<div class="phpcode"><code><span class="html">
The term "autoload" mentioned here shall not be confused with __autoload function to autoload objects. Regarding the __autoload and namespaces' resolution I'd like to share the following experience:<br /><br />-&gt;Say you have the following directory structure:<br /><br />- root<br />&nbsp; &nbsp; &nbsp; | - loader.php <br />&nbsp; &nbsp; &nbsp; | - ns<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; | - foo.php<br /><br />-&gt;foo.php<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">namespace </span><span class="default">ns</span><span class="keyword">;<br />class </span><span class="default">foo<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$say</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">say </span><span class="keyword">= </span><span class="string">"bar"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />}<br /></span><span class="default">?&gt;<br /></span><br />-&gt; loader.php<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">//GLOBAL SPACE &lt;--<br /></span><span class="keyword">function </span><span class="default">__autoload</span><span class="keyword">(</span><span class="default">$c</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; require_once </span><span class="default">$c </span><span class="keyword">. </span><span class="string">".php"</span><span class="keyword">;<br />}<br /><br />class </span><span class="default">foo </span><span class="keyword">extends </span><span class="default">ns</span><span class="keyword">\</span><span class="default">foo </span><span class="comment">// ns\foo is loaded here<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">parent</span><span class="keyword">::</span><span class="default">__construct</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"&lt;br /&gt;foo" </span><span class="keyword">. </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">say</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">ns</span><span class="keyword">\</span><span class="default">foo</span><span class="keyword">(); </span><span class="comment">// ns\foo also loads ns/foo.php just fine here.<br /></span><span class="keyword">echo </span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">say</span><span class="keyword">;&nbsp;&nbsp; </span><span class="comment">// prints bar as expected.<br /></span><span class="default">$b </span><span class="keyword">= new </span><span class="default">foo</span><span class="keyword">;&nbsp; </span><span class="comment">// prints foobar just fine.<br /></span><span class="default">?&gt;<br /></span><br />If you keep your directory/file matching namespace/class consistence the object __autoload works fine.<br />But... if you try to give loader.php a namespace you'll obviously get fatal errors. <br />My sample is just 1 level dir, but I've tested with a very complex and deeper structure. Hope anybody finds this useful.<br /><br />Cheers!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114187">  <div class="votes">
    <div id="Vu114187">
    <a href="/manual/vote-note.php?id=114187&amp;page=language.namespaces.rules&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114187">
    <a href="/manual/vote-note.php?id=114187&amp;page=language.namespaces.rules&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114187" title="75% like this...">
    4
    </div>
  </div>
  <a href="#114187" class="name">
  <strong class="user"><em>Kavoir.com</em></strong></a><a class="genanchor" href="#114187"> &para;</a><div class="date" title="2014-01-22 10:25"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114187">
<div class="phpcode"><code><span class="html">
For point 4, "In example, if the namespace A\B\C is imported as C" should be "In example, if the class A\B\C is imported as C".</span>
</code></div>
  </div>
 </div>
  <div class="note" id="100542">  <div class="votes">
    <div id="Vu100542">
    <a href="/manual/vote-note.php?id=100542&amp;page=language.namespaces.rules&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd100542">
    <a href="/manual/vote-note.php?id=100542&amp;page=language.namespaces.rules&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V100542" title="70% like this...">
    4
    </div>
  </div>
  <a href="#100542" class="name">
  <strong class="user"><em>safakozpinar at NOSPAM dot gmail dot com</em></strong></a><a class="genanchor" href="#100542"> &para;</a><div class="date" title="2010-10-22 01:04"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom100542">
<div class="phpcode"><code><span class="html">
As working with namespaces and using (custom or basic) autoload structure; magic function __autoload must be defined in global scope, not in a namespace, also not in another function or method.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">namespace </span><span class="default">Glue </span><span class="keyword">{<br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Define your custom structure and algorithms<br />&nbsp; &nbsp;&nbsp; * for autoloading in this class.<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">class </span><span class="default">Import<br />&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; public static function </span><span class="default">load </span><span class="keyword">(</span><span class="default">$classname</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'Autoloading class '</span><span class="keyword">.</span><span class="default">$classname</span><span class="keyword">.</span><span class="string">"\n"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; require_once </span><span class="default">$classname</span><span class="keyword">.</span><span class="string">'.php'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="comment">/**<br /> * Define function __autoload in global namespace.<br /> */<br /></span><span class="keyword">namespace {<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">__autoload </span><span class="keyword">(</span><span class="default">$classname</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; \</span><span class="default">Glue</span><span class="keyword">\</span><span class="default">Import</span><span class="keyword">::</span><span class="default">load</span><span class="keyword">(</span><span class="default">$classname</span><span class="keyword">);<br />&nbsp; &nbsp; }<br /><br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118833">  <div class="votes">
    <div id="Vu118833">
    <a href="/manual/vote-note.php?id=118833&amp;page=language.namespaces.rules&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118833">
    <a href="/manual/vote-note.php?id=118833&amp;page=language.namespaces.rules&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118833" title="66% like this...">
    1
    </div>
  </div>
  <a href="#118833" class="name">
  <strong class="user"><em>anrdaemon at freemail dot ru</em></strong></a><a class="genanchor" href="#118833"> &para;</a><div class="date" title="2016-02-12 10:32"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom118833">
<div class="phpcode"><code><span class="html">
Namespaces may be case-insensitive, but autoloaders most often do.<br />Do yourself a service, keep your cases consistent with file names, and don't overcomplicate autoloaders beyond necessity.<br />Something like this should suffice for most times:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">namespace </span><span class="default">org</span><span class="keyword">\</span><span class="default">example</span><span class="keyword">;<br /><br />function </span><span class="default">spl_autoload</span><span class="keyword">(</span><span class="default">$className</span><span class="keyword">)<br />{<br />&nbsp; </span><span class="default">$file </span><span class="keyword">= new \</span><span class="default">SplFileInfo</span><span class="keyword">(</span><span class="default">__DIR__ </span><span class="keyword">. </span><span class="default">substr</span><span class="keyword">(</span><span class="default">strtr</span><span class="keyword">(</span><span class="string">"</span><span class="default">$className</span><span class="string">.php"</span><span class="keyword">, </span><span class="string">'\\'</span><span class="keyword">, </span><span class="string">'/'</span><span class="keyword">), </span><span class="default">11</span><span class="keyword">));<br />&nbsp; </span><span class="default">$path </span><span class="keyword">= </span><span class="default">$file</span><span class="keyword">-&gt;</span><span class="default">getRealPath</span><span class="keyword">();<br />&nbsp; if(empty(</span><span class="default">$path</span><span class="keyword">))<br />&nbsp; {<br />&nbsp; &nbsp; return </span><span class="default">false</span><span class="keyword">;<br />&nbsp; }<br />&nbsp; else<br />&nbsp; {<br />&nbsp; &nbsp; return include_once </span><span class="default">$path</span><span class="keyword">;<br />&nbsp; }<br />}<br /><br />\</span><span class="default">spl_autoload_register</span><span class="keyword">(</span><span class="string">'\org\example\spl_autoload'</span><span class="keyword">);<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116370">  <div class="votes">
    <div id="Vu116370">
    <a href="/manual/vote-note.php?id=116370&amp;page=language.namespaces.rules&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116370">
    <a href="/manual/vote-note.php?id=116370&amp;page=language.namespaces.rules&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116370" title="60% like this...">
    2
    </div>
  </div>
  <a href="#116370" class="name">
  <strong class="user"><em>llmll</em></strong></a><a class="genanchor" href="#116370"> &para;</a><div class="date" title="2014-12-21 01:05"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom116370">
<div class="phpcode"><code><span class="html">
The mentioned filesystem analogy fails at an important point:<br /><br />Namespace resolution *only* works at declaration time. The compiler fixates all namespace/class references as absolute paths, like creating absolute symlinks.<br /><br />You can't expect relative symlinks, which should be evaluated during access -&gt; during PHP runtime.<br /><br />In other words, namespaces are evaluated like __CLASS__ or self:: at parse-time. What's *not* happening, is the pendant for late static binding like static:: which resolves to the current class at runtime.<br /><br />So you can't do the following:<br /><br />namespace Alpha;<br />class Helper {<br />&nbsp; &nbsp; public static $Value = "ALPHA";<br />}<br />class Base {<br />&nbsp; &nbsp; public static function Write() { <br />&nbsp; &nbsp; &nbsp; &nbsp; echo Helper::$Value;<br />&nbsp; &nbsp; }<br />}<br /><br />namespace Beta;<br />class Helper extends \Alpha\Helper {<br />&nbsp; &nbsp; public static $Value = 'BETA';<br />}&nbsp; &nbsp; <br />class Base extends \Alpha\Base {}&nbsp; &nbsp; <br /><br />\Beta\Base::Write(); // should write "BETA" as this is the executing namespace context at runtime.<br /><br />If you copy the write() function into \Beta\Base it works as expected.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114391">  <div class="votes">
    <div id="Vu114391">
    <a href="/manual/vote-note.php?id=114391&amp;page=language.namespaces.rules&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114391">
    <a href="/manual/vote-note.php?id=114391&amp;page=language.namespaces.rules&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114391" title="55% like this...">
    1
    </div>
  </div>
  <a href="#114391" class="name">
  <strong class="user"><em>CJ Taylor</em></strong></a><a class="genanchor" href="#114391"> &para;</a><div class="date" title="2014-02-14 09:52"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114391">
<div class="phpcode"><code><span class="html">
It took me playing with it a bit&nbsp; as I had a hard time finding documentation on when a class name matches a namespace, if that's even legal and what behavior to expect.&nbsp; It IS explained in #6 but I thought I'd share this with other souls like me that see it better by example.&nbsp; Assume all 3 files below are in the same directory.<br /><br />file1.php<br /><span class="default">&lt;?php<br /></span><span class="keyword">namespace </span><span class="default">foo</span><span class="keyword">;<br /><br />class </span><span class="default">foo </span><span class="keyword">{<br />&nbsp; static function </span><span class="default">hello</span><span class="keyword">() {<br />&nbsp; &nbsp; echo </span><span class="string">"hello world!"</span><span class="keyword">;<br />&nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />file2.php<br /><span class="default">&lt;?php<br /></span><span class="keyword">namespace </span><span class="default">foo</span><span class="keyword">; <br />include(</span><span class="string">'file1.php'</span><span class="keyword">);<br /><br /></span><span class="default">foo</span><span class="keyword">::</span><span class="default">hello</span><span class="keyword">(); </span><span class="comment">//you're in the same namespace, or scope.<br /></span><span class="keyword">\</span><span class="default">foo</span><span class="keyword">\</span><span class="default">foo</span><span class="keyword">::</span><span class="default">hello</span><span class="keyword">(); </span><span class="comment">//called on a global scope.<br /></span><span class="default">?&gt;<br /></span><br />file3.php<br /><span class="default">&lt;?php<br /></span><span class="keyword">include(</span><span class="string">'file1.php'</span><span class="keyword">);<br /><br /></span><span class="default">foo</span><span class="keyword">\</span><span class="default">foo</span><span class="keyword">::</span><span class="default">hello</span><span class="keyword">(); </span><span class="comment">//you're outside of the namespace<br /></span><span class="keyword">\</span><span class="default">foo</span><span class="keyword">\</span><span class="default">foo</span><span class="keyword">::</span><span class="default">hello</span><span class="keyword">(); </span><span class="comment">//called on a global scope.<br /></span><span class="default">?&gt;<br /></span><br />Depending upon what you're building (example: a module, plugin, or package on a larger application), sometimes declaring a class that matches a namespace makes sense or may even be required.&nbsp; Just be aware that if you try to reference any class that shares the same namespace, omit the namespace unless you do it globally like the examples above.<br /><br />I hope this is useful, particularly for those that are trying to wrap your head around this 5.3 feature.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="115358">  <div class="votes">
    <div id="Vu115358">
    <a href="/manual/vote-note.php?id=115358&amp;page=language.namespaces.rules&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115358">
    <a href="/manual/vote-note.php?id=115358&amp;page=language.namespaces.rules&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115358" title="33% like this...">
    -2
    </div>
  </div>
  <a href="#115358" class="name">
  <strong class="user"><em>dn dot permyakov at gmail dot com</em></strong></a><a class="genanchor" href="#115358"> &para;</a><div class="date" title="2014-07-11 10:02"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115358">
<div class="phpcode"><code><span class="html">
Can someone explain to me -&nbsp; why do we need p.4 if we have p.2 (which covers both unqualified and qualified names)?</span>
</code></div>
  </div>
 </div>
  <div class="note" id="92607">  <div class="votes">
    <div id="Vu92607">
    <a href="/manual/vote-note.php?id=92607&amp;page=language.namespaces.rules&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd92607">
    <a href="/manual/vote-note.php?id=92607&amp;page=language.namespaces.rules&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V92607" title="36% like this...">
    -3
    </div>
  </div>
  <a href="#92607" class="name">
  <strong class="user"><em>rangel</em></strong></a><a class="genanchor" href="#92607"> &para;</a><div class="date" title="2009-07-31 12:47"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom92607">
<div class="phpcode"><code><span class="html">
The term "autoload" mentioned here shall not be confused with __autoload function to autoload objects. Regarding the __autoload and namespaces' resolution I'd like to share the following experience:<br /><br />-&gt;Say you have the following directory structure:<br /><br />- root<br />&nbsp; &nbsp; &nbsp; | - loader.php <br />&nbsp; &nbsp; &nbsp; | - ns<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; | - foo.php<br /><br />-&gt;foo.php<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">namespace </span><span class="default">ns</span><span class="keyword">;<br />class </span><span class="default">foo<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$say</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">say </span><span class="keyword">= </span><span class="string">"bar"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />}<br /></span><span class="default">?&gt;<br /></span><br />-&gt; loader.php<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">//GLOBAL SPACE &lt;--<br /></span><span class="keyword">function </span><span class="default">__autoload</span><span class="keyword">(</span><span class="default">$c</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; require_once </span><span class="default">$c </span><span class="keyword">. </span><span class="string">".php"</span><span class="keyword">;<br />}<br /><br />class </span><span class="default">foo </span><span class="keyword">extends </span><span class="default">ns</span><span class="keyword">\</span><span class="default">foo </span><span class="comment">// ns\foo is loaded here<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">parent</span><span class="keyword">::</span><span class="default">__construct</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"&lt;br /&gt;foo" </span><span class="keyword">. </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">say</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">ns</span><span class="keyword">\</span><span class="default">foo</span><span class="keyword">(); </span><span class="comment">// ns\foo also loads ns/foo.php just fine here.<br /></span><span class="keyword">echo </span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">say</span><span class="keyword">;&nbsp;&nbsp; </span><span class="comment">// prints bar as expected.<br /></span><span class="default">$b </span><span class="keyword">= new </span><span class="default">foo</span><span class="keyword">;&nbsp; </span><span class="comment">// prints foobar just fine.<br /></span><span class="default">?&gt;<br /></span><br />If you keep your directory/file matching namespace/class consistence the object __autoload works fine.<br />But... if you try to give loader.php a namespace you'll obviously get fatal errors. <br />My sample is just 1 level dir, but I've tested with a very complex and deeper structure. Hope anybody finds this useful.<br /><br />Cheers!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117905">  <div class="votes">
    <div id="Vu117905">
    <a href="/manual/vote-note.php?id=117905&amp;page=language.namespaces.rules&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117905">
    <a href="/manual/vote-note.php?id=117905&amp;page=language.namespaces.rules&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117905" title="0% like this...">
    -4
    </div>
  </div>
  <a href="#117905" class="name">
  <strong class="user"><em>StanE</em></strong></a><a class="genanchor" href="#117905"> &para;</a><div class="date" title="2015-08-29 08:45"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117905">
<div class="phpcode"><code><span class="html">
What the name resolution rules do not say: Namespaces are case-insensitive.<br /><br />You can write: namespace myframework\errorhandling;<br />Or: namespace MyFramework\ErrorHandling;<br /><br />Same applies to namespaces after the "use" keyword or directly used qulified name namespaces in front of classes, functions or constants.</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.namespaces.rules&amp;redirect=http://php.net/manual/en/language.namespaces.rules.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.namespaces.php">Namespaces</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.namespaces.rationale.php" title="Namespaces overview">Namespaces overview</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.definition.php" title="Defining namespaces">Defining namespaces</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.nested.php" title="Declaring sub-&#8203;namespaces">Declaring sub-&#8203;namespaces</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.definitionmultiple.php" title="Defining multiple namespaces in the same file">Defining multiple namespaces in the same file</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.basics.php" title="Using namespaces: Basics">Using namespaces: Basics</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.dynamic.php" title="Namespaces and dynamic language features">Namespaces and dynamic language features</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.nsconstants.php" title="namespace keyword and _&#8203;_&#8203;NAMESPACE_&#8203;_&#8203; constant">namespace keyword and _&#8203;_&#8203;NAMESPACE_&#8203;_&#8203; constant</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.importing.php" title="Using namespaces: Aliasing/Importing">Using namespaces: Aliasing/Importing</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.global.php" title="Global space">Global space</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.fallback.php" title="Using namespaces: fallback to global function/constant">Using namespaces: fallback to global function/constant</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.namespaces.rules.php" title="Name resolution rules">Name resolution rules</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.faq.php" title="FAQ: things you need to know about namespaces">FAQ: things you need to know about namespaces</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

