<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Comparison Operators - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.operators.comparison.php">
 <link rel="shorturl" href="http://php.net/operators.comparison">
 <link rel="alternate" href="http://php.net/operators.comparison" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.operators.php">
 <link rel="prev" href="http://php.net/manual/en/language.operators.bitwise.php">
 <link rel="next" href="http://php.net/manual/en/language.operators.errorcontrol.php">

 <link rel="alternate" href="http://php.net/manual/en/language.operators.comparison.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.operators.comparison.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.operators.comparison.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.operators.comparison.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.operators.comparison.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.operators.comparison.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.operators.comparison.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.operators.comparison.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.operators.comparison.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.operators.comparison.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.operators.comparison.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.operators.errorcontrol.php">
          Error Control Operators &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.operators.bitwise.php">
          &laquo; Bitwise Operators        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.operators.php'>Operators</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.operators.comparison.php' selected="selected">English</option>
            <option value='pt_BR/language.operators.comparison.php'>Brazilian Portuguese</option>
            <option value='zh/language.operators.comparison.php'>Chinese (Simplified)</option>
            <option value='fr/language.operators.comparison.php'>French</option>
            <option value='de/language.operators.comparison.php'>German</option>
            <option value='ja/language.operators.comparison.php'>Japanese</option>
            <option value='ro/language.operators.comparison.php'>Romanian</option>
            <option value='ru/language.operators.comparison.php'>Russian</option>
            <option value='es/language.operators.comparison.php'>Spanish</option>
            <option value='tr/language.operators.comparison.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.operators.comparison.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.operators.comparison">Report a Bug</a>
    </div>
  </div><div id="language.operators.comparison" class="sect1">
   <h2 class="title">Comparison Operators</h2>
   <p class="simpara">
    Comparison operators, as their name implies, allow you to compare
    two values.  You may also be interested in viewing
    <a href="types.comparisons.php" class="link">the type comparison tables</a>,
    as they show examples of various type related comparisons.
   </p>
   <table class="doctable table">
    <caption><strong>Comparison Operators</strong></caption>
    
     <thead>
      <tr>
       <th>Example</th>
       <th>Name</th>
       <th>Result</th>
      </tr>

     </thead>

     <tbody class="tbody">
      <tr>
       <td>$a == $b</td>
       <td>Equal</td>
       <td><strong><code>TRUE</code></strong> if <var class="varname"><var class="varname">$a</var></var> is equal to <var class="varname"><var class="varname">$b</var></var> after type juggling.</td>
      </tr>

      <tr>
       <td>$a === $b</td>
       <td>Identical</td>
       <td>
        <strong><code>TRUE</code></strong> if <var class="varname"><var class="varname">$a</var></var> is equal to <var class="varname"><var class="varname">$b</var></var>, and they are of the same
        type.
       </td>
      </tr>

      <tr>
       <td>$a != $b</td>
       <td>Not equal</td>
       <td><strong><code>TRUE</code></strong> if <var class="varname"><var class="varname">$a</var></var> is not equal to <var class="varname"><var class="varname">$b</var></var> after type juggling.</td>
      </tr>

      <tr>
       <td>$a &lt;&gt; $b</td>
       <td>Not equal</td>
       <td><strong><code>TRUE</code></strong> if <var class="varname"><var class="varname">$a</var></var> is not equal to <var class="varname"><var class="varname">$b</var></var> after type juggling.</td>
      </tr>

      <tr>
       <td>$a !== $b</td>
       <td>Not identical</td>
       <td>
        <strong><code>TRUE</code></strong> if <var class="varname"><var class="varname">$a</var></var> is not equal to <var class="varname"><var class="varname">$b</var></var>, or they are not of the same
        type.
       </td>
      </tr>

      <tr>
       <td>$a &lt; $b</td>
       <td>Less than</td>
       <td><strong><code>TRUE</code></strong> if <var class="varname"><var class="varname">$a</var></var> is strictly less than <var class="varname"><var class="varname">$b</var></var>.</td>
      </tr>

      <tr>
       <td>$a &gt; $b</td>
       <td>Greater than</td>
       <td><strong><code>TRUE</code></strong> if <var class="varname"><var class="varname">$a</var></var> is strictly greater than <var class="varname"><var class="varname">$b</var></var>.</td>
      </tr>

      <tr>
       <td>$a &lt;= $b</td>
       <td>Less than or equal to </td>
       <td><strong><code>TRUE</code></strong> if <var class="varname"><var class="varname">$a</var></var> is less than or equal to <var class="varname"><var class="varname">$b</var></var>.</td>
      </tr>

      <tr>
       <td>$a &gt;= $b</td>
       <td>Greater than or equal to </td>
       <td><strong><code>TRUE</code></strong> if <var class="varname"><var class="varname">$a</var></var> is greater than or equal to <var class="varname"><var class="varname">$b</var></var>.</td>
      </tr>

      <tr>
       <td>$a &lt;=&gt; $b</td>
       <td>Spaceship</td>
       <td>
        An <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span> less than, equal to, or greater than zero when
        <var class="varname"><var class="varname">$a</var></var> is respectively less than, equal to, or greater
        than <var class="varname"><var class="varname">$b</var></var>. Available as of PHP 7.
       </td>
      </tr>

     </tbody>
    
   </table>

   <p class="para">
    If you compare a number with a string or the comparison involves numerical
    strings, then each string is
    <a href="language.types.string.php#language.types.string.conversion" class="link">converted to a number</a>
    and the comparison performed numerically. These rules also apply to the
    <a href="control-structures.switch.php" class="link">switch</a> statement. The
    type conversion does not take place when the comparison is === or !== as
    this involves comparing the type as well as the value.
    <div class="informalexample">
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">0&nbsp;</span><span style="color: #007700">==&nbsp;</span><span style="color: #DD0000">"a"</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;0&nbsp;==&nbsp;0&nbsp;-&gt;&nbsp;true<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #DD0000">"1"&nbsp;</span><span style="color: #007700">==&nbsp;</span><span style="color: #DD0000">"01"</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;1&nbsp;==&nbsp;1&nbsp;-&gt;&nbsp;true<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #DD0000">"10"&nbsp;</span><span style="color: #007700">==&nbsp;</span><span style="color: #DD0000">"1e1"</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;10&nbsp;==&nbsp;10&nbsp;-&gt;&nbsp;true<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">100&nbsp;</span><span style="color: #007700">==&nbsp;</span><span style="color: #DD0000">"1e2"</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;100&nbsp;==&nbsp;100&nbsp;-&gt;&nbsp;true<br /><br /></span><span style="color: #007700">switch&nbsp;(</span><span style="color: #DD0000">"a"</span><span style="color: #007700">)&nbsp;{<br />case&nbsp;</span><span style="color: #0000BB">0</span><span style="color: #007700">:<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"0"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;break;<br />case&nbsp;</span><span style="color: #DD0000">"a"</span><span style="color: #007700">:&nbsp;</span><span style="color: #FF8000">//&nbsp;never&nbsp;reached&nbsp;because&nbsp;"a"&nbsp;is&nbsp;already&nbsp;matched&nbsp;with&nbsp;0<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"a"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;break;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php&nbsp;&nbsp;<br /></span><span style="color: #FF8000">//&nbsp;Integers<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #0000BB">1&nbsp;</span><span style="color: #007700">&lt;=&gt;&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;0<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #0000BB">1&nbsp;</span><span style="color: #007700">&lt;=&gt;&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;-1<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #0000BB">2&nbsp;</span><span style="color: #007700">&lt;=&gt;&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;1<br />&nbsp;<br />//&nbsp;Floats<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #0000BB">1.5&nbsp;</span><span style="color: #007700">&lt;=&gt;&nbsp;</span><span style="color: #0000BB">1.5</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;0<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #0000BB">1.5&nbsp;</span><span style="color: #007700">&lt;=&gt;&nbsp;</span><span style="color: #0000BB">2.5</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;-1<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #0000BB">2.5&nbsp;</span><span style="color: #007700">&lt;=&gt;&nbsp;</span><span style="color: #0000BB">1.5</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;1<br />&nbsp;<br />//&nbsp;Strings<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"a"&nbsp;</span><span style="color: #007700">&lt;=&gt;&nbsp;</span><span style="color: #DD0000">"a"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;0<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"a"&nbsp;</span><span style="color: #007700">&lt;=&gt;&nbsp;</span><span style="color: #DD0000">"b"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;-1<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"b"&nbsp;</span><span style="color: #007700">&lt;=&gt;&nbsp;</span><span style="color: #DD0000">"a"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;1<br />&nbsp;<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"a"&nbsp;</span><span style="color: #007700">&lt;=&gt;&nbsp;</span><span style="color: #DD0000">"aa"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;-1<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"zz"&nbsp;</span><span style="color: #007700">&lt;=&gt;&nbsp;</span><span style="color: #DD0000">"aa"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;1<br />&nbsp;<br />//&nbsp;Arrays<br /></span><span style="color: #007700">echo&nbsp;[]&nbsp;&lt;=&gt;&nbsp;[];&nbsp;</span><span style="color: #FF8000">//&nbsp;0<br /></span><span style="color: #007700">echo&nbsp;[</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">3</span><span style="color: #007700">]&nbsp;&lt;=&gt;&nbsp;[</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">3</span><span style="color: #007700">];&nbsp;</span><span style="color: #FF8000">//&nbsp;0<br /></span><span style="color: #007700">echo&nbsp;[</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">3</span><span style="color: #007700">]&nbsp;&lt;=&gt;&nbsp;[];&nbsp;</span><span style="color: #FF8000">//&nbsp;1<br /></span><span style="color: #007700">echo&nbsp;[</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">3</span><span style="color: #007700">]&nbsp;&lt;=&gt;&nbsp;[</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">];&nbsp;</span><span style="color: #FF8000">//&nbsp;1<br /></span><span style="color: #007700">echo&nbsp;[</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">3</span><span style="color: #007700">]&nbsp;&lt;=&gt;&nbsp;[</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">4</span><span style="color: #007700">];&nbsp;</span><span style="color: #FF8000">//&nbsp;-1<br />&nbsp;<br />//&nbsp;Objects<br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;(object)&nbsp;[</span><span style="color: #DD0000">"a"&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">"b"</span><span style="color: #007700">];&nbsp;<br /></span><span style="color: #0000BB">$b&nbsp;</span><span style="color: #007700">=&nbsp;(object)&nbsp;[</span><span style="color: #DD0000">"a"&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">"b"</span><span style="color: #007700">];&nbsp;<br />echo&nbsp;</span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">&lt;=&gt;&nbsp;</span><span style="color: #0000BB">$b</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;0<br />&nbsp;<br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;(object)&nbsp;[</span><span style="color: #DD0000">"a"&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">"b"</span><span style="color: #007700">];&nbsp;<br /></span><span style="color: #0000BB">$b&nbsp;</span><span style="color: #007700">=&nbsp;(object)&nbsp;[</span><span style="color: #DD0000">"a"&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">"c"</span><span style="color: #007700">];&nbsp;<br />echo&nbsp;</span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">&lt;=&gt;&nbsp;</span><span style="color: #0000BB">$b</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;-1<br />&nbsp;<br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;(object)&nbsp;[</span><span style="color: #DD0000">"a"&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">"c"</span><span style="color: #007700">];&nbsp;<br /></span><span style="color: #0000BB">$b&nbsp;</span><span style="color: #007700">=&nbsp;(object)&nbsp;[</span><span style="color: #DD0000">"a"&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">"b"</span><span style="color: #007700">];&nbsp;<br />echo&nbsp;</span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">&lt;=&gt;&nbsp;</span><span style="color: #0000BB">$b</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;1<br />&nbsp;<br />//&nbsp;only&nbsp;values&nbsp;are&nbsp;compared<br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;(object)&nbsp;[</span><span style="color: #DD0000">"a"&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">"b"</span><span style="color: #007700">];&nbsp;<br /></span><span style="color: #0000BB">$b&nbsp;</span><span style="color: #007700">=&nbsp;(object)&nbsp;[</span><span style="color: #DD0000">"b"&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">"b"</span><span style="color: #007700">];&nbsp;<br />echo&nbsp;</span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">&lt;=&gt;&nbsp;</span><span style="color: #0000BB">$b</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;1<br /><br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
      
     </div>

    </div>
   </p>

   <p class="para">
    For various types, comparison is done according to the following
    table (in order).
   </p>
   <table id="language.operators.comparison.types" class="doctable table">
    <caption><strong>Comparison with Various Types</strong></caption>
    
     <thead>
      <tr>
       <th>Type of Operand 1</th>
       <th>Type of Operand 2</th>
       <th>Result</th>
      </tr>

     </thead>

     <tbody class="tbody">
      <tr>
       <td><span class="type"><a href="language.types.null.php" class="type null">null</a></span> or <span class="type"><a href="language.types.string.php" class="type string">string</a></span></td>
       <td><span class="type"><a href="language.types.string.php" class="type string">string</a></span></td>
       <td>Convert <strong><code>NULL</code></strong> to &quot;&quot;, numerical or lexical comparison</td>
      </tr>

      <tr>
       <td><span class="type"><a href="language.types.boolean.php" class="type bool">bool</a></span> or <span class="type"><a href="language.types.null.php" class="type null">null</a></span></td>
       <td>anything</td>
       <td>Convert both sides to <span class="type"><a href="language.types.boolean.php" class="type bool">bool</a></span>, <strong><code>FALSE</code></strong> &lt; <strong><code>TRUE</code></strong></td>
      </tr>

      <tr>
       <td><span class="type"><a href="language.types.object.php" class="type object">object</a></span></td>
       <td><span class="type"><a href="language.types.object.php" class="type object">object</a></span></td>
       <td>Built-in classes can define its own comparison, different classes
        are uncomparable, same class - compare properties the same way as
        arrays (PHP 4), PHP 5 has its own <a href="language.oop5.object-comparison.php" class="link">explanation</a>
       </td>
      </tr>

      <tr>
       <td><span class="type"><a href="language.types.string.php" class="type string">string</a></span>, <span class="type"><a href="language.types.resource.php" class="type resource">resource</a></span> or <span class="type"><a href="language.pseudo-types.php#language.types.number" class="type number">number</a></span></td>
       <td><span class="type"><a href="language.types.string.php" class="type string">string</a></span>, <span class="type"><a href="language.types.resource.php" class="type resource">resource</a></span> or <span class="type"><a href="language.pseudo-types.php#language.types.number" class="type number">number</a></span></td>
       <td>Translate strings and resources to numbers, usual math</td>
      </tr>

      <tr>
       <td><span class="type"><a href="language.types.array.php" class="type array">array</a></span></td>
       <td><span class="type"><a href="language.types.array.php" class="type array">array</a></span></td>
       <td>Array with fewer members is smaller, if key from operand 1 is not
        found in operand 2 then arrays are uncomparable, otherwise - compare
        value by value (see following example)</td>
      </tr>

      <tr>
       <td><span class="type"><a href="language.types.object.php" class="type object">object</a></span></td>
       <td>anything</td>
       <td><span class="type"><a href="language.types.object.php" class="type object">object</a></span> is always greater</td>
      </tr>

      <tr>
       <td><span class="type"><a href="language.types.array.php" class="type array">array</a></span></td>
       <td>anything</td>
       <td><span class="type"><a href="language.types.array.php" class="type array">array</a></span> is always greater</td>
      </tr>

     </tbody>
    
   </table>


   <p class="para">
    <div class="example" id="example-101">
     <p><strong>Example #1 Boolean/null comparison</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #FF8000">//&nbsp;Bool&nbsp;and&nbsp;null&nbsp;are&nbsp;compared&nbsp;as&nbsp;bool&nbsp;always<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">1&nbsp;</span><span style="color: #007700">==&nbsp;</span><span style="color: #0000BB">TRUE</span><span style="color: #007700">);&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;TRUE&nbsp;-&nbsp;same&nbsp;as&nbsp;(bool)1&nbsp;==&nbsp;TRUE<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">0&nbsp;</span><span style="color: #007700">==&nbsp;</span><span style="color: #0000BB">FALSE</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;TRUE&nbsp;-&nbsp;same&nbsp;as&nbsp;(bool)0&nbsp;==&nbsp;FALSE<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">100&nbsp;</span><span style="color: #007700">&lt;&nbsp;</span><span style="color: #0000BB">TRUE</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;FALSE&nbsp;-&nbsp;same&nbsp;as&nbsp;(bool)100&nbsp;&lt;&nbsp;TRUE<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(-</span><span style="color: #0000BB">10&nbsp;</span><span style="color: #007700">&lt;&nbsp;</span><span style="color: #0000BB">FALSE</span><span style="color: #007700">);</span><span style="color: #FF8000">//&nbsp;FALSE&nbsp;-&nbsp;same&nbsp;as&nbsp;(bool)-10&nbsp;&lt;&nbsp;FALSE<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">min</span><span style="color: #007700">(-</span><span style="color: #0000BB">100</span><span style="color: #007700">,&nbsp;-</span><span style="color: #0000BB">10</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">NULL</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">10</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">100</span><span style="color: #007700">));&nbsp;</span><span style="color: #FF8000">//&nbsp;NULL&nbsp;-&nbsp;(bool)NULL&nbsp;&lt;&nbsp;(bool)-100&nbsp;is&nbsp;FALSE&nbsp;&lt;&nbsp;TRUE<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>


   <p class="para">
    <div class="example" id="example-102">
     <p><strong>Example #2 Transcription of standard array comparison</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #FF8000">//&nbsp;Arrays&nbsp;are&nbsp;compared&nbsp;like&nbsp;this&nbsp;with&nbsp;standard&nbsp;comparison&nbsp;operators<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">standard_array_compare</span><span style="color: #007700">(</span><span style="color: #0000BB">$op1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$op2</span><span style="color: #007700">)<br />{<br />&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(</span><span style="color: #0000BB">count</span><span style="color: #007700">(</span><span style="color: #0000BB">$op1</span><span style="color: #007700">)&nbsp;&lt;&nbsp;</span><span style="color: #0000BB">count</span><span style="color: #007700">(</span><span style="color: #0000BB">$op2</span><span style="color: #007700">))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;-</span><span style="color: #0000BB">1</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;$op1&nbsp;&lt;&nbsp;$op2<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">}&nbsp;elseif&nbsp;(</span><span style="color: #0000BB">count</span><span style="color: #007700">(</span><span style="color: #0000BB">$op1</span><span style="color: #007700">)&nbsp;&gt;&nbsp;</span><span style="color: #0000BB">count</span><span style="color: #007700">(</span><span style="color: #0000BB">$op2</span><span style="color: #007700">))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;$op1&nbsp;&gt;&nbsp;$op2<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">}<br />&nbsp;&nbsp;&nbsp;&nbsp;foreach&nbsp;(</span><span style="color: #0000BB">$op1&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">$key&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #0000BB">$val</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(!</span><span style="color: #0000BB">array_key_exists</span><span style="color: #007700">(</span><span style="color: #0000BB">$key</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$op2</span><span style="color: #007700">))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">null</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;uncomparable<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">}&nbsp;elseif&nbsp;(</span><span style="color: #0000BB">$val&nbsp;</span><span style="color: #007700">&lt;&nbsp;</span><span style="color: #0000BB">$op2</span><span style="color: #007700">[</span><span style="color: #0000BB">$key</span><span style="color: #007700">])&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;-</span><span style="color: #0000BB">1</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}&nbsp;elseif&nbsp;(</span><span style="color: #0000BB">$val&nbsp;</span><span style="color: #007700">&gt;&nbsp;</span><span style="color: #0000BB">$op2</span><span style="color: #007700">[</span><span style="color: #0000BB">$key</span><span style="color: #007700">])&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">0</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;$op1&nbsp;==&nbsp;$op2<br /></span><span style="color: #007700">}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>

   <p class="para">
    See also <span class="function"><a href="function.strcasecmp.php" class="function">strcasecmp()</a></span>,
    <span class="function"><a href="function.strcmp.php" class="function">strcmp()</a></span>,
    <a href="language.operators.array.php" class="link">Array operators</a>,
    and the manual section on
    <a href="language.types.php" class="link">Types</a>.
   </p>

   <div class="warning"><strong class="warning">Warning</strong>
    <h1 class="title">Comparison of floating point numbers</h1>

    <p class="para">
     Because of the way <span class="type"><a href="language.types.float.php" class="type float">float</a></span>s are represented internally, you
     should not test two <span class="type"><a href="language.types.float.php" class="type float">float</a></span>s for equality.
    </p>

    <p class="para">
     See the documentation for <span class="type"><a href="language.types.float.php" class="type float">float</a></span> for more information.
    </p>
   </div>

   <div class="sect2" id="language.operators.comparison.ternary">
    <h3 class="title">Ternary Operator</h3>
    <p class="para">
     Another conditional operator is the &quot;?:&quot; (or ternary) operator.
     <div class="example" id="example-103">
      <p><strong>Example #3 Assigning a default value</strong></p>
      <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #FF8000">//&nbsp;Example&nbsp;usage&nbsp;for:&nbsp;Ternary&nbsp;Operator<br /></span><span style="color: #0000BB">$action&nbsp;</span><span style="color: #007700">=&nbsp;(empty(</span><span style="color: #0000BB">$_POST</span><span style="color: #007700">[</span><span style="color: #DD0000">'action'</span><span style="color: #007700">]))&nbsp;?&nbsp;</span><span style="color: #DD0000">'default'&nbsp;</span><span style="color: #007700">:&nbsp;</span><span style="color: #0000BB">$_POST</span><span style="color: #007700">[</span><span style="color: #DD0000">'action'</span><span style="color: #007700">];<br /><br /></span><span style="color: #FF8000">//&nbsp;The&nbsp;above&nbsp;is&nbsp;identical&nbsp;to&nbsp;this&nbsp;if/else&nbsp;statement<br /></span><span style="color: #007700">if&nbsp;(empty(</span><span style="color: #0000BB">$_POST</span><span style="color: #007700">[</span><span style="color: #DD0000">'action'</span><span style="color: #007700">]))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$action&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'default'</span><span style="color: #007700">;<br />}&nbsp;else&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$action&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$_POST</span><span style="color: #007700">[</span><span style="color: #DD0000">'action'</span><span style="color: #007700">];<br />}<br /><br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
      </div>

     </div>
     The expression <em>(expr1) ? (expr2) : (expr3)</em>
     evaluates to <span class="replaceable">expr2</span> if
     <span class="replaceable">expr1</span> evaluates to <strong><code>TRUE</code></strong>, and
     <span class="replaceable">expr3</span> if
     <span class="replaceable">expr1</span> evaluates to <strong><code>FALSE</code></strong>.
    </p>
    <p class="para">
     Since PHP 5.3, it is possible to leave out the middle part of the ternary
     operator. Expression <em>expr1 ?: expr3</em> returns
     <span class="replaceable">expr1</span> if <span class="replaceable">expr1</span>
     evaluates to <strong><code>TRUE</code></strong>, and <span class="replaceable">expr3</span> otherwise.
    </p>
    <blockquote class="note"><p><strong class="note">Note</strong>: 
     <span class="simpara">
      Please note that the ternary operator is an expression, and that it
      doesn&#039;t evaluate to a variable, but to the result of an expression. This
      is important to know if you want to return a variable by reference.
      The statement <em>return $var == 42 ? $a : $b;</em> in a
      return-by-reference function will therefore not work and a warning is
      issued.
     </span>
    </p></blockquote>
    <blockquote class="note"><p><strong class="note">Note</strong>: 
     <p class="para">
      It is recommended that you avoid &quot;stacking&quot; ternary expressions. PHP&#039;s
      behaviour when using more than one ternary operator within a single
      statement is non-obvious:
      <div class="example" id="example-104">
       <p><strong>Example #4 Non-obvious Ternary Behaviour</strong></p>
       <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #FF8000">//&nbsp;on&nbsp;first&nbsp;glance,&nbsp;the&nbsp;following&nbsp;appears&nbsp;to&nbsp;output&nbsp;'true'<br /></span><span style="color: #007700">echo&nbsp;(</span><span style="color: #0000BB">true</span><span style="color: #007700">?</span><span style="color: #DD0000">'true'</span><span style="color: #007700">:</span><span style="color: #0000BB">false</span><span style="color: #007700">?</span><span style="color: #DD0000">'t'</span><span style="color: #007700">:</span><span style="color: #DD0000">'f'</span><span style="color: #007700">);<br /><br /></span><span style="color: #FF8000">//&nbsp;however,&nbsp;the&nbsp;actual&nbsp;output&nbsp;of&nbsp;the&nbsp;above&nbsp;is&nbsp;'t'<br />//&nbsp;this&nbsp;is&nbsp;because&nbsp;ternary&nbsp;expressions&nbsp;are&nbsp;evaluated&nbsp;from&nbsp;left&nbsp;to&nbsp;right<br /><br />//&nbsp;the&nbsp;following&nbsp;is&nbsp;a&nbsp;more&nbsp;obvious&nbsp;version&nbsp;of&nbsp;the&nbsp;same&nbsp;code&nbsp;as&nbsp;above<br /></span><span style="color: #007700">echo&nbsp;((</span><span style="color: #0000BB">true&nbsp;</span><span style="color: #007700">?&nbsp;</span><span style="color: #DD0000">'true'&nbsp;</span><span style="color: #007700">:&nbsp;</span><span style="color: #0000BB">false</span><span style="color: #007700">)&nbsp;?&nbsp;</span><span style="color: #DD0000">'t'&nbsp;</span><span style="color: #007700">:&nbsp;</span><span style="color: #DD0000">'f'</span><span style="color: #007700">);<br /><br /></span><span style="color: #FF8000">//&nbsp;here,&nbsp;you&nbsp;can&nbsp;see&nbsp;that&nbsp;the&nbsp;first&nbsp;expression&nbsp;is&nbsp;evaluated&nbsp;to&nbsp;'true',&nbsp;which<br />//&nbsp;in&nbsp;turn&nbsp;evaluates&nbsp;to&nbsp;(bool)true,&nbsp;thus&nbsp;returning&nbsp;the&nbsp;true&nbsp;branch&nbsp;of&nbsp;the<br />//&nbsp;second&nbsp;ternary&nbsp;expression.<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
       </div>

      </div>
     </p>
    </p></blockquote>
   </div>
   
   <div class="sect2" id="language.operators.comparison.coalesce">
    <h3 class="title">Null Coalescing Operator</h3>
    <p class="para">
     Further exists the &quot;??&quot; (or null coalescing) operator, available as of PHP 7.
     <div class="example" id="example-105">
      <p><strong>Example #5 Assigning a default value</strong></p>
      <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #FF8000">//&nbsp;Example&nbsp;usage&nbsp;for:&nbsp;Null&nbsp;Coalesce&nbsp;Operator<br /></span><span style="color: #0000BB">$action&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$_POST</span><span style="color: #007700">[</span><span style="color: #DD0000">'action'</span><span style="color: #007700">]&nbsp;??&nbsp;</span><span style="color: #DD0000">'default'</span><span style="color: #007700">;<br /><br /></span><span style="color: #FF8000">//&nbsp;The&nbsp;above&nbsp;is&nbsp;identical&nbsp;to&nbsp;this&nbsp;if/else&nbsp;statement<br /></span><span style="color: #007700">if&nbsp;(isset(</span><span style="color: #0000BB">$_POST</span><span style="color: #007700">[</span><span style="color: #DD0000">'action'</span><span style="color: #007700">]))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$action&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$_POST</span><span style="color: #007700">[</span><span style="color: #DD0000">'action'</span><span style="color: #007700">];<br />}&nbsp;else&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$action&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'default'</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
      </div>

     </div>
     The expression <em>(expr1) ?? (expr2)</em> evaluates to
     <span class="replaceable">expr2</span> if <span class="replaceable">expr1</span> is
     <strong><code>NULL</code></strong>, and <span class="replaceable">expr1</span> otherwise.
    </p>
    <p class="para">
     In particular, this operator does not emit a notice if the left-hand side
     value does not exist, just like <span class="function"><a href="function.isset.php" class="function">isset()</a></span>. This is especially
     useful on array keys.
    </p>
    <blockquote class="note"><p><strong class="note">Note</strong>: 
     <span class="simpara">
      Please note that the null coalescing operator is an expression, and that it
      doesn&#039;t evaluate to a variable, but to the result of an expression. This
      is important to know if you want to return a variable by reference.
      The statement <em>return $foo ?? $bar;</em> in a
      return-by-reference function will therefore not work and a warning is
      issued.
     </span>
    </p></blockquote>
    <blockquote class="note"><p><strong class="note">Note</strong>: 
     <p class="para">
      Please note that the null coalescing operator allows for simple nesting:
      <div class="example" id="example-106">
       <p><strong>Example #6 Nesting null coalescing operator</strong></p>
       <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /><br />$foo&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">null</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$bar&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">null</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$baz&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$qux&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">;<br /><br />echo&nbsp;</span><span style="color: #0000BB">$foo&nbsp;</span><span style="color: #007700">??&nbsp;</span><span style="color: #0000BB">$bar&nbsp;</span><span style="color: #007700">??&nbsp;</span><span style="color: #0000BB">$baz&nbsp;</span><span style="color: #007700">??&nbsp;</span><span style="color: #0000BB">$qux</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;outputs&nbsp;1<br /><br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
       </div>

      </div>
     </p>
    </p></blockquote>
   </div> 
  </div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.operators.comparison&amp;redirect=http://php.net/manual/en/language.operators.comparison.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">53 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="95997">  <div class="votes">
    <div id="Vu95997">
    <a href="/manual/vote-note.php?id=95997&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd95997">
    <a href="/manual/vote-note.php?id=95997&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V95997" title="77% like this...">
    92
    </div>
  </div>
  <a href="#95997" class="name">
  <strong class="user"><em>crazy888s at hotmail dot com</em></strong></a><a class="genanchor" href="#95997"> &para;</a><div class="date" title="2010-02-01 10:32"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom95997">
<div class="phpcode"><code><span class="html">
I couldn't find much info on stacking the new ternary operator, so I ran some tests:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">echo </span><span class="default">0 </span><span class="keyword">?: </span><span class="default">1 </span><span class="keyword">?: </span><span class="default">2 </span><span class="keyword">?: </span><span class="default">3</span><span class="keyword">; </span><span class="comment">//1<br /></span><span class="keyword">echo </span><span class="default">1 </span><span class="keyword">?: </span><span class="default">0 </span><span class="keyword">?: </span><span class="default">3 </span><span class="keyword">?: </span><span class="default">2</span><span class="keyword">; </span><span class="comment">//1<br /></span><span class="keyword">echo </span><span class="default">2 </span><span class="keyword">?: </span><span class="default">1 </span><span class="keyword">?: </span><span class="default">0 </span><span class="keyword">?: </span><span class="default">3</span><span class="keyword">; </span><span class="comment">//2<br /></span><span class="keyword">echo </span><span class="default">3 </span><span class="keyword">?: </span><span class="default">2 </span><span class="keyword">?: </span><span class="default">1 </span><span class="keyword">?: </span><span class="default">0</span><span class="keyword">; </span><span class="comment">//3<br /><br /></span><span class="keyword">echo </span><span class="default">0 </span><span class="keyword">?: </span><span class="default">1 </span><span class="keyword">?: </span><span class="default">2 </span><span class="keyword">?: </span><span class="default">3</span><span class="keyword">; </span><span class="comment">//1<br /></span><span class="keyword">echo </span><span class="default">0 </span><span class="keyword">?: </span><span class="default">0 </span><span class="keyword">?: </span><span class="default">2 </span><span class="keyword">?: </span><span class="default">3</span><span class="keyword">; </span><span class="comment">//2<br /></span><span class="keyword">echo </span><span class="default">0 </span><span class="keyword">?: </span><span class="default">0 </span><span class="keyword">?: </span><span class="default">0 </span><span class="keyword">?: </span><span class="default">3</span><span class="keyword">; </span><span class="comment">//3<br /></span><span class="default">?&gt;<br /></span><br />It works just as expected, returning the first non-false value within a group of expressions.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114872">  <div class="votes">
    <div id="Vu114872">
    <a href="/manual/vote-note.php?id=114872&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114872">
    <a href="/manual/vote-note.php?id=114872&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114872" title="80% like this...">
    36
    </div>
  </div>
  <a href="#114872" class="name">
  <strong class="user"><em>Harry Willis</em></strong></a><a class="genanchor" href="#114872"> &para;</a><div class="date" title="2014-04-18 03:52"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114872">
<div class="phpcode"><code><span class="html">
I was interested about the following two uses of the ternary operator (PHP &gt;= 5.3) for using a "default" value if a variable is not set or evaluates to false:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">(isset(</span><span class="default">$some_variable</span><span class="keyword">) &amp;&amp; </span><span class="default">$some_variable</span><span class="keyword">) ? </span><span class="default">$some_variable </span><span class="keyword">: </span><span class="string">'default_value'</span><span class="keyword">;<br /><br /></span><span class="default">$some_variable </span><span class="keyword">?: </span><span class="string">'default_value'</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />The second is more readable, but will throw an ERR_NOTICE is $some_variable is not set. Of course, this could be overcome by suppressing the notice using the @ operator.<br /><br />Performance-wise, though, comparing 1 million iterations of the three statements<br /><br />&nbsp; (isset($foo) &amp;&amp; $foo) ? $foo : ''<br />&nbsp; ($foo) ?: ''<br />&nbsp; (@$foo) ?: ''<br /><br />results in the following:<br /><br />&nbsp; $foo is NOT SET.<br />&nbsp; &nbsp; [isset] 0.18222403526306<br />&nbsp; &nbsp; [?:]&nbsp; &nbsp; 0.57496404647827<br />&nbsp; &nbsp; [@ ?:]&nbsp; 0.64780592918396<br />&nbsp; $foo is NULL.<br />&nbsp; &nbsp; [isset] 0.17995285987854<br />&nbsp; &nbsp; [?:]&nbsp; &nbsp; 0.15304207801819<br />&nbsp; &nbsp; [@ ?:]&nbsp; 0.20394206047058<br />&nbsp; $foo is FALSE.<br />&nbsp; &nbsp; [isset] 0.19388508796692<br />&nbsp; &nbsp; [?:]&nbsp; &nbsp; 0.15359902381897<br />&nbsp; &nbsp; [@ ?:]&nbsp; 0.20741701126099<br />&nbsp; $foo is TRUE.<br />&nbsp; &nbsp; [isset] 0.17265486717224<br />&nbsp; &nbsp; [?:]&nbsp; &nbsp; 0.11773896217346<br />&nbsp; &nbsp; [@ ?:]&nbsp; 0.16193103790283<br /><br />In other words, using the long-form ternary operator with isset($some_variable) is preferable overall if $some_variable may not be set.<br /><br />(error_reporting was set to zero for the benchmark, to avoid printing a million notices...)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="99254">  <div class="votes">
    <div id="Vu99254">
    <a href="/manual/vote-note.php?id=99254&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd99254">
    <a href="/manual/vote-note.php?id=99254&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V99254" title="68% like this...">
    59
    </div>
  </div>
  <a href="#99254" class="name">
  <strong class="user"><em>arnaud at arnapou dot net</em></strong></a><a class="genanchor" href="#99254"> &para;</a><div class="date" title="2010-08-06 01:12"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom99254">
<div class="phpcode"><code><span class="html">
[Editor's note: consider using ===]<br /><br />I discover after 10 years of PHP development something awfull : even if you make a string comparison (both are strings), strings are tested like integers and leading "space" character (even \n, \r, \t) is ignored ....<br /><br />I spent hours because of leading \n in a string ... it hurts my developper sensibility to see two strings beeing compared like integers and not like strings ... I use strcmp now for string comparison ... so stupid ...<br /><br />Test code :<br /><span class="default">&lt;?php<br /><br />test</span><span class="keyword">(</span><span class="string">"1234"</span><span class="keyword">, </span><span class="string">"1234"</span><span class="keyword">);<br /></span><span class="default">test</span><span class="keyword">(</span><span class="string">"1234"</span><span class="keyword">, </span><span class="string">" 1234"</span><span class="keyword">);<br /></span><span class="default">test</span><span class="keyword">(</span><span class="string">"1234"</span><span class="keyword">, </span><span class="string">"\n1234"</span><span class="keyword">);<br /></span><span class="default">test</span><span class="keyword">(</span><span class="string">"1234"</span><span class="keyword">, </span><span class="string">"1234 "</span><span class="keyword">);<br /></span><span class="default">test</span><span class="keyword">(</span><span class="string">"1234"</span><span class="keyword">, </span><span class="string">"1234\n"</span><span class="keyword">);<br /><br />function </span><span class="default">test</span><span class="keyword">(</span><span class="default">$v1</span><span class="keyword">, </span><span class="default">$v2</span><span class="keyword">) {<br />&nbsp; &nbsp; echo </span><span class="string">"&lt;h1&gt;["</span><span class="keyword">.</span><span class="default">show_cr</span><span class="keyword">(</span><span class="default">$v1</span><span class="keyword">).</span><span class="string">"] vs ["</span><span class="keyword">.</span><span class="default">show_cr</span><span class="keyword">(</span><span class="default">$v2</span><span class="keyword">).</span><span class="string">"]&lt;/h1&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; echo </span><span class="default">my_var_dump</span><span class="keyword">(</span><span class="default">$v1</span><span class="keyword">).</span><span class="string">"&lt;br /&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; echo </span><span class="default">my_var_dump</span><span class="keyword">(</span><span class="default">$v2</span><span class="keyword">).</span><span class="string">"&lt;br /&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; if(</span><span class="default">$v1 </span><span class="keyword">== </span><span class="default">$v2</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"EQUAL !"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; else {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"DIFFERENT !"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />function </span><span class="default">show_cr</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">) {<br />&nbsp; &nbsp; return </span><span class="default">str_replace</span><span class="keyword">(</span><span class="string">"\n"</span><span class="keyword">, </span><span class="string">"\\n"</span><span class="keyword">, </span><span class="default">$var</span><span class="keyword">);<br />}<br /><br />function </span><span class="default">my_var_dump</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">ob_start</span><span class="keyword">();<br />&nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$dump </span><span class="keyword">= </span><span class="default">show_cr</span><span class="keyword">(</span><span class="default">trim</span><span class="keyword">(</span><span class="default">ob_get_contents</span><span class="keyword">()));<br />&nbsp; &nbsp; </span><span class="default">ob_end_clean</span><span class="keyword">();<br />&nbsp; &nbsp; return </span><span class="default">$dump</span><span class="keyword">;<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />Displays this -&gt;<br /><br />[1234] vs [1234]<br />string(4) "1234"<br />string(4) "1234"<br />EQUAL !<br /><br />[1234] vs [ 1234]<br />string(4) "1234"<br />string(5) " 1234"<br />EQUAL !<br /><br />[1234] vs [\n1234]<br />string(4) "1234"<br />string(5) "\n1234"<br />EQUAL !<br /><br />[1234] vs [1234 ]<br />string(4) "1234"<br />string(5) "1234 "<br />DIFFERENT !<br /><br />[1234] vs [1234\n]<br />string(4) "1234"<br />string(5) "1234\n"<br />DIFFERENT !</span>
</code></div>
  </div>
 </div>
  <div class="note" id="73519">  <div class="votes">
    <div id="Vu73519">
    <a href="/manual/vote-note.php?id=73519&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd73519">
    <a href="/manual/vote-note.php?id=73519&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V73519" title="82% like this...">
    25
    </div>
  </div>
  <a href="#73519" class="name">
  <strong class="user"><em>thomas dot oldbury at tgohome dot com</em></strong></a><a class="genanchor" href="#73519"> &para;</a><div class="date" title="2007-02-27 09:37"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom73519">
<div class="phpcode"><code><span class="html">
Be careful when using the ternary operator!<br /><br />The following will not evaluate to the expected result:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">echo </span><span class="string">"a string that has a " </span><span class="keyword">. (</span><span class="default">true</span><span class="keyword">) ? </span><span class="string">'true' </span><span class="keyword">: </span><span class="string">'false' </span><span class="keyword">. </span><span class="string">" condition in. "</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />Will print true.<br /><br />Instead, use this:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">echo </span><span class="string">"a string that has a " </span><span class="keyword">. ((</span><span class="default">true</span><span class="keyword">) ? </span><span class="string">'true' </span><span class="keyword">: </span><span class="string">'false'</span><span class="keyword">) . </span><span class="string">" condition in. "</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />This will evaluate to the expected result: "a string that has a true condition in. "<br /><br />I hope this helps.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="38139">  <div class="votes">
    <div id="Vu38139">
    <a href="/manual/vote-note.php?id=38139&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd38139">
    <a href="/manual/vote-note.php?id=38139&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V38139" title="80% like this...">
    25
    </div>
  </div>
  <a href="#38139" class="name">
  <strong class="user"><em>jwhiting at hampshire dot edu</em></strong></a><a class="genanchor" href="#38139"> &para;</a><div class="date" title="2003-12-09 03:31"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom38139">
<div class="phpcode"><code><span class="html">
note: the behavior below is documented in the appendix K about type comparisons, but since it is somewhat buried i thought i should raise it here for people since it threw me for a loop until i figured it out completely.<br /><br />just to clarify a tricky point about the == comparison operator when dealing with strings and numbers:<br /><br />('some string' == 0) returns TRUE<br /><br />however, ('123' == 0) returns FALSE<br /><br />also note that ((int) 'some string') returns 0<br /><br />and ((int) '123') returns 123<br /><br />the behavior makes senes but you must be careful when comparing strings to numbers, e.g. when you're comparing a request variable which you expect to be numeric. its easy to fall into the trap of:<br /><br />if ($_GET['myvar']==0) dosomething();<br /><br />as this will dosomething() even when $_GET['myvar'] is 'some string' and clearly not the value 0<br /><br />i was getting lazy with my types since php vars are so flexible, so be warned to pay attention to the details...</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114682">  <div class="votes">
    <div id="Vu114682">
    <a href="/manual/vote-note.php?id=114682&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114682">
    <a href="/manual/vote-note.php?id=114682&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114682" title="76% like this...">
    25
    </div>
  </div>
  <a href="#114682" class="name">
  <strong class="user"><em>mail at mkharitonov dot net</em></strong></a><a class="genanchor" href="#114682"> &para;</a><div class="date" title="2014-03-21 11:13"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114682">
<div class="phpcode"><code><span class="html">
Be careful with the "==" operator when both operands are strings:<br /><span class="default">&lt;?php<br />var_dump</span><span class="keyword">(</span><span class="string">'123' </span><span class="keyword">== </span><span class="string">'&nbsp; &nbsp; &nbsp;&nbsp; 123'</span><span class="keyword">); </span><span class="comment">// true<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="string">'1e3' </span><span class="keyword">== </span><span class="string">'1000'</span><span class="keyword">); </span><span class="comment">// true<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="string">'+74951112233' </span><span class="keyword">== </span><span class="string">'74951112233'</span><span class="keyword">); </span><span class="comment">// true<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="string">'00000020' </span><span class="keyword">== </span><span class="string">'0000000000000000020'</span><span class="keyword">); </span><span class="comment">// true<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="string">'0X1D' </span><span class="keyword">== </span><span class="string">'29E0'</span><span class="keyword">); </span><span class="comment">// true<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="string">'0xafebac' </span><span class="keyword">== </span><span class="string">'11529132'</span><span class="keyword">); </span><span class="comment">// true<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="string">'0xafebac' </span><span class="keyword">== </span><span class="string">'0XAFEBAC'</span><span class="keyword">); </span><span class="comment">// true<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="string">'0xeb' </span><span class="keyword">== </span><span class="string">'+235e-0'</span><span class="keyword">); </span><span class="comment">// true<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="string">'0.235' </span><span class="keyword">== </span><span class="string">'+.235'</span><span class="keyword">); </span><span class="comment">// true<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="string">'0.2e-10' </span><span class="keyword">== </span><span class="string">'2.0E-11'</span><span class="keyword">); </span><span class="comment">// true<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="string">'61529519452809720693702583126814' </span><span class="keyword">== </span><span class="string">'61529519452809720000000000000000'</span><span class="keyword">); </span><span class="comment">// true in php &lt; 5.4.4</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="56572">  <div class="votes">
    <div id="Vu56572">
    <a href="/manual/vote-note.php?id=56572&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd56572">
    <a href="/manual/vote-note.php?id=56572&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V56572" title="70% like this...">
    40
    </div>
  </div>
  <a href="#56572" class="name"><strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#56572"> &para;</a><div class="date" title="2005-09-07 01:09"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom56572">
<div class="phpcode"><code><span class="html">
The following contrasts the trinary operator associativity in PHP and Java.&nbsp; The first test would work as expected in Java (evaluates left-to-right, associates right-to-left, like if stmnt), the second in PHP (evaluates and associates left-to-right)<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">echo </span><span class="string">"\n\n######----------- trinary operator associativity\n\n"</span><span class="keyword">;<br /><br />function </span><span class="default">trinaryTest</span><span class="keyword">(</span><span class="default">$foo</span><span class="keyword">){<br /><br />&nbsp; &nbsp; </span><span class="default">$bar&nbsp; &nbsp; </span><span class="keyword">= </span><span class="default">$foo </span><span class="keyword">&gt; </span><span class="default">20<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">? </span><span class="string">"greater than 20"<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">: </span><span class="default">$foo </span><span class="keyword">&gt; </span><span class="default">10<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">? </span><span class="string">"greater than 10"<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">: </span><span class="default">$foo </span><span class="keyword">&gt; </span><span class="default">5<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">? </span><span class="string">"greater than 5"<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">: </span><span class="string">"not worthy of consideration"</span><span class="keyword">;&nbsp; &nbsp; <br />&nbsp; &nbsp; echo </span><span class="default">$foo</span><span class="keyword">.</span><span class="string">" =&gt;&nbsp; "</span><span class="keyword">.</span><span class="default">$bar</span><span class="keyword">.</span><span class="string">"\n"</span><span class="keyword">;<br />}<br /><br />echo </span><span class="string">"----trinaryTest\n\n"</span><span class="keyword">;<br /></span><span class="default">trinaryTest</span><span class="keyword">(</span><span class="default">21</span><span class="keyword">);<br /></span><span class="default">trinaryTest</span><span class="keyword">(</span><span class="default">11</span><span class="keyword">);<br /></span><span class="default">trinaryTest</span><span class="keyword">(</span><span class="default">6</span><span class="keyword">);<br /></span><span class="default">trinaryTest</span><span class="keyword">(</span><span class="default">4</span><span class="keyword">);<br /><br />function </span><span class="default">trinaryTestParens</span><span class="keyword">(</span><span class="default">$foo</span><span class="keyword">){<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="default">$bar&nbsp; &nbsp; </span><span class="keyword">= </span><span class="default">$foo </span><span class="keyword">&gt; </span><span class="default">20<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">? </span><span class="string">"greater than 20"<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">: (</span><span class="default">$foo </span><span class="keyword">&gt; </span><span class="default">10<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">? </span><span class="string">"greater than 10"<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">: (</span><span class="default">$foo </span><span class="keyword">&gt; </span><span class="default">5<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">? </span><span class="string">"greater than 5"<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">: </span><span class="string">"not worthy of consideration"</span><span class="keyword">));&nbsp; &nbsp; <br />&nbsp; &nbsp; echo </span><span class="default">$foo</span><span class="keyword">.</span><span class="string">" =&gt;&nbsp; "</span><span class="keyword">.</span><span class="default">$bar</span><span class="keyword">.</span><span class="string">"\n"</span><span class="keyword">;<br />}<br /><br />echo </span><span class="string">"----trinaryTestParens\n\n"</span><span class="keyword">;<br /></span><span class="default">trinaryTestParens</span><span class="keyword">(</span><span class="default">21</span><span class="keyword">);<br /></span><span class="default">trinaryTestParens</span><span class="keyword">(</span><span class="default">11</span><span class="keyword">);<br /></span><span class="default">trinaryTest</span><span class="keyword">(</span><span class="default">6</span><span class="keyword">);<br /></span><span class="default">trinaryTestParens</span><span class="keyword">(</span><span class="default">4</span><span class="keyword">);<br /><br /></span><span class="default">?&gt;<br /></span><br />Output:<br /><br />######----------- trinary operator associativity <br /><br />----trinaryTest<br /><br />21 =&gt;&nbsp; greater than 5<br />11 =&gt;&nbsp; greater than 5<br />6 =&gt;&nbsp; greater than 5<br />4 =&gt;&nbsp; not worthy of consideration<br /><br />----trinaryTestParens<br /><br />21 =&gt;&nbsp; greater than 20<br />11 =&gt;&nbsp; greater than 10<br />6 =&gt;&nbsp; greater than 5<br />4 =&gt;&nbsp; not worthy of consideration</span>
</code></div>
  </div>
 </div>
  <div class="note" id="60866">  <div class="votes">
    <div id="Vu60866">
    <a href="/manual/vote-note.php?id=60866&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd60866">
    <a href="/manual/vote-note.php?id=60866&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V60866" title="77% like this...">
    19
    </div>
  </div>
  <a href="#60866" class="name">
  <strong class="user"><em>rshawiii at yahoo dot com</em></strong></a><a class="genanchor" href="#60866"> &para;</a><div class="date" title="2006-01-18 11:36"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom60866">
<div class="phpcode"><code><span class="html">
You can't just compare two arrays with the === operator<br />like you would think to find out if they are equal or not.&nbsp; This is more complicated when you have multi-dimensional arrays.&nbsp; Here is a recursive comparison function.<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">/**<br /> * Compares two arrays to see if they contain the same values.&nbsp; Returns TRUE or FALSE.<br /> * usefull for determining if a record or block of data was modified (perhaps by user input)<br /> * prior to setting a "date_last_updated" or skipping updating the db in the case of no change.<br /> *<br /> * @param array $a1<br /> * @param array $a2<br /> * @return boolean<br /> */<br /></span><span class="keyword">function </span><span class="default">array_compare_recursive</span><span class="keyword">(</span><span class="default">$a1</span><span class="keyword">, </span><span class="default">$a2</span><span class="keyword">)<br />{<br />&nbsp;&nbsp; if (!(</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$a1</span><span class="keyword">) and (</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$a2</span><span class="keyword">)))) { return </span><span class="default">FALSE</span><span class="keyword">;}&nbsp; &nbsp; <br />&nbsp; &nbsp; <br />&nbsp;&nbsp; if (!</span><span class="default">count</span><span class="keyword">(</span><span class="default">$a1</span><span class="keyword">) == </span><span class="default">count</span><span class="keyword">(</span><span class="default">$a2</span><span class="keyword">)) <br />&nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp;&nbsp; return </span><span class="default">FALSE</span><span class="keyword">; </span><span class="comment">// arrays don't have same number of entries<br />&nbsp; &nbsp; &nbsp; </span><span class="keyword">}<br />&nbsp; &nbsp; &nbsp; <br />&nbsp;&nbsp; foreach (</span><span class="default">$a1 </span><span class="keyword">as </span><span class="default">$key </span><span class="keyword">=&gt; </span><span class="default">$val</span><span class="keyword">) <br />&nbsp;&nbsp; {<br />&nbsp; &nbsp; &nbsp;&nbsp; if (!</span><span class="default">array_key_exists</span><span class="keyword">(</span><span class="default">$key</span><span class="keyword">, </span><span class="default">$a2</span><span class="keyword">)) <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; {return </span><span class="default">FALSE</span><span class="keyword">; </span><span class="comment">// uncomparable array keys don't match<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">} <br />&nbsp; &nbsp; &nbsp;&nbsp; elseif (</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$val</span><span class="keyword">) and </span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$a2</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">]))&nbsp; </span><span class="comment">// if both entries are arrays then compare recursive <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="keyword">{if (!</span><span class="default">array_compare_recursive</span><span class="keyword">(</span><span class="default">$val</span><span class="keyword">,</span><span class="default">$a2</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">])) return </span><span class="default">FALSE</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; } <br />&nbsp; &nbsp; &nbsp;&nbsp; elseif (!(</span><span class="default">$val </span><span class="keyword">=== </span><span class="default">$a2</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">])) </span><span class="comment">// compare entries must be of same type.<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="keyword">{return </span><span class="default">FALSE</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; }<br />&nbsp;&nbsp; }<br />&nbsp;&nbsp; return </span><span class="default">TRUE</span><span class="keyword">; </span><span class="comment">// $a1 === $a2<br /></span><span class="keyword">}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="108104">  <div class="votes">
    <div id="Vu108104">
    <a href="/manual/vote-note.php?id=108104&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd108104">
    <a href="/manual/vote-note.php?id=108104&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V108104" title="75% like this...">
    12
    </div>
  </div>
  <a href="#108104" class="name">
  <strong class="user"><em>Jeremy Swinborne</em></strong></a><a class="genanchor" href="#108104"> &para;</a><div class="date" title="2012-03-28 08:06"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom108104">
<div class="phpcode"><code><span class="html">
Beware of the consequences of comparing strings to numbers.&nbsp; You can disprove the laws of the universe.<br /><br />echo ('X' == 0 &amp;&amp; 'X' == true &amp;&amp; 0 == false) ? 'true == false' : 'sanity prevails';<br /><br />This will output 'true == false'.&nbsp; This stems from the use of the UNIX function strtod() to convert strings to numbers before comparing.&nbsp; Since 'X' or any other string without a number in it converts to 0 when compared to a number, 0 == 0 &amp;&amp; 'X' == true &amp;&amp; 0 == false</span>
</code></div>
  </div>
 </div>
  <div class="note" id="92685">  <div class="votes">
    <div id="Vu92685">
    <a href="/manual/vote-note.php?id=92685&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd92685">
    <a href="/manual/vote-note.php?id=92685&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V92685" title="70% like this...">
    16
    </div>
  </div>
  <a href="#92685" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#92685"> &para;</a><div class="date" title="2009-08-03 10:44"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom92685">
<div class="phpcode"><code><span class="html">
Note: The ternary shortcut currently seems to be of no use in dealing with unexisting keys in an array, as PHP will throw an error. Take the following example.<br /><br /><span class="default">&lt;?php<br />$_POST</span><span class="keyword">[</span><span class="string">'Unexisting'</span><span class="keyword">] = </span><span class="default">$_POST</span><span class="keyword">[</span><span class="string">'Unexisting'</span><span class="keyword">] ?: </span><span class="default">false</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />PHP will throw an error that the "Unexisting" key does not exist. The @ operator does not work here to suppress this error.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="72894">  <div class="votes">
    <div id="Vu72894">
    <a href="/manual/vote-note.php?id=72894&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd72894">
    <a href="/manual/vote-note.php?id=72894&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V72894" title="69% like this...">
    18
    </div>
  </div>
  <a href="#72894" class="name">
  <strong class="user"><em>fernandoleal at dragoncs dot com</em></strong></a><a class="genanchor" href="#72894"> &para;</a><div class="date" title="2007-02-03 11:19"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom72894">
<div class="phpcode"><code><span class="html">
If you need nested ifs on I var its important to group the if so it works.<br />Example:<br /><span class="default">&lt;?php<br /></span><span class="comment">//Dont Works<br />//Parse error: parse error, unexpected ':' <br /> </span><span class="default">$var</span><span class="keyword">=</span><span class="string">'&lt;option value="1" '</span><span class="keyword">.</span><span class="default">$status </span><span class="keyword">== </span><span class="string">"1" </span><span class="keyword">? </span><span class="string">'selected="selected"' </span><span class="keyword">:</span><span class="string">''</span><span class="keyword">.</span><span class="string">'&gt;Value 1&lt;/option&gt;'</span><span class="keyword">;<br /> </span><span class="comment">//Works:<br /> </span><span class="default">$var</span><span class="keyword">=</span><span class="string">'&lt;option value="1" '</span><span class="keyword">.(</span><span class="default">$status </span><span class="keyword">== </span><span class="string">"1" </span><span class="keyword">? </span><span class="string">'selected="selected"' </span><span class="keyword">:</span><span class="string">''</span><span class="keyword">).</span><span class="string">'&gt;Value 1&lt;/option&gt;'</span><span class="keyword">;<br /><br />echo </span><span class="default">$var</span><span class="keyword">;<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="111487">  <div class="votes">
    <div id="Vu111487">
    <a href="/manual/vote-note.php?id=111487&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd111487">
    <a href="/manual/vote-note.php?id=111487&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V111487" title="69% like this...">
    13
    </div>
  </div>
  <a href="#111487" class="name">
  <strong class="user"><em>bimal at sanjaal dot com</em></strong></a><a class="genanchor" href="#111487"> &para;</a><div class="date" title="2013-02-25 12:02"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom111487">
<div class="phpcode"><code><span class="html">
I came across peculiar outputs while I was attempting to debug a script<br /><br /><span class="default">&lt;?php<br /></span><span class="comment"># Setup platform (pre conditions somewhere in a loop)<br /></span><span class="default">$index</span><span class="keyword">=</span><span class="default">1</span><span class="keyword">;<br /></span><span class="default">$tally </span><span class="keyword">= array();<br /><br /></span><span class="comment"># May work with warnings that $tally[$index] is not initialized<br /># Notice: Undefined offset: 1 in D:\htdocs\colors\ColorCompare\i.php on line #__<br /># It is an old fashioned way.<br /># $tally[$index] = $tally[$index] + 1;<br /><br /># Does not work: Loops to attempt to change $index and values are aways unaffected<br /></span><span class="default">$tally</span><span class="keyword">[</span><span class="default">$index</span><span class="keyword">] = isset(</span><span class="default">$tally</span><span class="keyword">[</span><span class="default">$index</span><span class="keyword">])?</span><span class="default">$tally</span><span class="keyword">[</span><span class="default">$index</span><span class="keyword">]:</span><span class="default">0</span><span class="keyword">+</span><span class="default">1</span><span class="keyword">;<br /></span><span class="default">$tally</span><span class="keyword">[</span><span class="default">$index</span><span class="keyword">] = isset(</span><span class="default">$tally</span><span class="keyword">[</span><span class="default">$index</span><span class="keyword">])?</span><span class="default">$tally</span><span class="keyword">[</span><span class="default">$index</span><span class="keyword">]:</span><span class="default">0</span><span class="keyword">+</span><span class="default">1</span><span class="keyword">;<br /></span><span class="default">$tally</span><span class="keyword">[</span><span class="default">$index</span><span class="keyword">] = isset(</span><span class="default">$tally</span><span class="keyword">[</span><span class="default">$index</span><span class="keyword">])?</span><span class="default">$tally</span><span class="keyword">[</span><span class="default">$index</span><span class="keyword">]:</span><span class="default">0</span><span class="keyword">+</span><span class="default">1</span><span class="keyword">;<br /></span><span class="comment">/*<br /># These three lines output:<br />Array<br />(<br />&nbsp; &nbsp; [1] =&gt; 1<br />)<br />*/<br /><br /># Works: This is what I need/expect<br /># $tally[$index] = 1+(isset($tally[$index])?$tally[$index]:0);<br /><br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$tally</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />The second block obviously does not work what one expects.<br />Third part is good.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="70762">  <div class="votes">
    <div id="Vu70762">
    <a href="/manual/vote-note.php?id=70762&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd70762">
    <a href="/manual/vote-note.php?id=70762&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V70762" title="72% like this...">
    11
    </div>
  </div>
  <a href="#70762" class="name">
  <strong class="user"><em>bishop</em></strong></a><a class="genanchor" href="#70762"> &para;</a><div class="date" title="2006-10-26 03:49"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom70762">
<div class="phpcode"><code><span class="html">
When you want to know if two arrays contain the same values, regardless of the values' order, you cannot use "==" or "===".&nbsp; In other words:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">(array(</span><span class="default">1</span><span class="keyword">,</span><span class="default">2</span><span class="keyword">) == array(</span><span class="default">2</span><span class="keyword">,</span><span class="default">1</span><span class="keyword">)) === </span><span class="default">false</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />To answer that question, use:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">array_equal</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">) {<br />&nbsp; &nbsp; return (</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">) &amp;&amp; </span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$b</span><span class="keyword">) &amp;&amp; </span><span class="default">array_diff</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">) === </span><span class="default">array_diff</span><span class="keyword">(</span><span class="default">$b</span><span class="keyword">, </span><span class="default">$a</span><span class="keyword">));<br />}<br /></span><span class="default">?&gt;<br /></span><br />A related, but more strict problem, is if you need to ensure that two arrays contain the same key=&gt;value pairs, regardless of the order of the pairs.&nbsp; In that case, use:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">array_identical</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">) {<br />&nbsp; &nbsp; return (</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">) &amp;&amp; </span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$b</span><span class="keyword">) &amp;&amp; </span><span class="default">array_diff_assoc</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">) === </span><span class="default">array_diff_assoc</span><span class="keyword">(</span><span class="default">$b</span><span class="keyword">, </span><span class="default">$a</span><span class="keyword">));<br />}<br /></span><span class="default">?&gt;<br /></span><br />Example:<br /><span class="default">&lt;?php<br />$a </span><span class="keyword">= array (</span><span class="default">2</span><span class="keyword">, </span><span class="default">1</span><span class="keyword">);<br /></span><span class="default">$b </span><span class="keyword">= array (</span><span class="default">1</span><span class="keyword">, </span><span class="default">2</span><span class="keyword">);<br /></span><span class="comment">// true === array_equal($a, $b);<br />// false === array_identical($a, $b);<br /><br /></span><span class="default">$a </span><span class="keyword">= array (</span><span class="string">'a' </span><span class="keyword">=&gt; </span><span class="default">2</span><span class="keyword">, </span><span class="string">'b' </span><span class="keyword">=&gt; </span><span class="default">1</span><span class="keyword">);<br /></span><span class="default">$b </span><span class="keyword">= array (</span><span class="string">'b' </span><span class="keyword">=&gt; </span><span class="default">1</span><span class="keyword">, </span><span class="string">'a' </span><span class="keyword">=&gt; </span><span class="default">2</span><span class="keyword">);<br /></span><span class="comment">// true === array_identical($a, $b)<br />// true === array_equal($a, $b)<br /></span><span class="default">?&gt;<br /></span><br />(See also the solution "rshawiii at yahoo dot com" posted)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="74399">  <div class="votes">
    <div id="Vu74399">
    <a href="/manual/vote-note.php?id=74399&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd74399">
    <a href="/manual/vote-note.php?id=74399&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V74399" title="71% like this...">
    12
    </div>
  </div>
  <a href="#74399" class="name">
  <strong class="user"><em>Hayley Watson</em></strong></a><a class="genanchor" href="#74399"> &para;</a><div class="date" title="2007-04-09 10:38"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom74399">
<div class="phpcode"><code><span class="html">
Note that the "ternary operator" is better described as the "conditional operator". The former name merely notes that it has three arguments without saying anything about what it does. Needless to say, if PHP picked up any more ternary operators, this will be a problem.<br /><br />"Conditional Operator" is actually descriptive of the semantics, and is the name historically given to it in, e.g., C.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="104840">  <div class="votes">
    <div id="Vu104840">
    <a href="/manual/vote-note.php?id=104840&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd104840">
    <a href="/manual/vote-note.php?id=104840&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V104840" title="70% like this...">
    12
    </div>
  </div>
  <a href="#104840" class="name">
  <strong class="user"><em>Cuong Huy To</em></strong></a><a class="genanchor" href="#104840"> &para;</a><div class="date" title="2011-07-10 07:48"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom104840">
<div class="phpcode"><code><span class="html">
In the table "Comparison with Various Types", please move the last line about "Object" to be above the line about "Array", since Object is considered to be greater than Array (tested on 5.3.3)<br /><br />(Please remove my "Anonymous" post of the same content before. You could check IP to see that I forgot to type my name)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="65863">  <div class="votes">
    <div id="Vu65863">
    <a href="/manual/vote-note.php?id=65863&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd65863">
    <a href="/manual/vote-note.php?id=65863&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V65863" title="68% like this...">
    17
    </div>
  </div>
  <a href="#65863" class="name">
  <strong class="user"><em>adam at caucho dot com</em></strong></a><a class="genanchor" href="#65863"> &para;</a><div class="date" title="2006-05-08 10:49"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom65863">
<div class="phpcode"><code><span class="html">
Note: according to the spec, PHP's comparison operators are not transitive.&nbsp; For example, the following are all true in PHP5:<br /><br />"11" &lt; "a" &lt; 2 &lt; "11"<br /><br />As a result, the outcome of sorting an array depends on the order the elements appear in the pre-sort array.&nbsp; The following code will dump out two arrays with *different* orderings:<br /><br /><span class="default">&lt;?php<br />$a </span><span class="keyword">= array(</span><span class="default">2</span><span class="keyword">,&nbsp; &nbsp; </span><span class="string">"a"</span><span class="keyword">,&nbsp; </span><span class="string">"11"</span><span class="keyword">, </span><span class="default">2</span><span class="keyword">);<br /></span><span class="default">$b </span><span class="keyword">= array(</span><span class="default">2</span><span class="keyword">,&nbsp; &nbsp; </span><span class="string">"11"</span><span class="keyword">, </span><span class="string">"a"</span><span class="keyword">,&nbsp; </span><span class="default">2</span><span class="keyword">);<br /></span><span class="default">sort</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">);<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">);<br /></span><span class="default">sort</span><span class="keyword">(</span><span class="default">$b</span><span class="keyword">);<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$b</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />This is not a bug report -- given the spec on this documentation page, what PHP does is "correct".&nbsp; But that may not be what was intended...</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114912">  <div class="votes">
    <div id="Vu114912">
    <a href="/manual/vote-note.php?id=114912&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114912">
    <a href="/manual/vote-note.php?id=114912&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114912" title="68% like this...">
    13
    </div>
  </div>
  <a href="#114912" class="name">
  <strong class="user"><em>gondo</em></strong></a><a class="genanchor" href="#114912"> &para;</a><div class="date" title="2014-04-25 11:47"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114912">
<div class="phpcode"><code><span class="html">
beware of the fact, that there is no `&lt;==` nor `&gt;==` therefore `false &lt;= 0` will be `true`. php v. 5.4.27</span>
</code></div>
  </div>
 </div>
  <div class="note" id="97799">  <div class="votes">
    <div id="Vu97799">
    <a href="/manual/vote-note.php?id=97799&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd97799">
    <a href="/manual/vote-note.php?id=97799&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V97799" title="70% like this...">
    11
    </div>
  </div>
  <a href="#97799" class="name">
  <strong class="user"><em>alan dot g at nospam dot net</em></strong></a><a class="genanchor" href="#97799"> &para;</a><div class="date" title="2010-05-09 12:44"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom97799">
<div class="phpcode"><code><span class="html">
a function to help settings default values, it returns its own first non-empty argument :<br /><br />make your own eor combos !<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="comment">/*<br /> * Either Or<br /> *<br /> * usage:&nbsp; $foo = eor(test1(),test2(),"default");<br /> * usage:&nbsp; $foo = eor($_GET['foo'], foogen(), $foo, "bar");<br /> */<br /><br /></span><span class="keyword">function </span><span class="default">eor</span><span class="keyword">() {<br />&nbsp; &nbsp; </span><span class="default">$vars </span><span class="keyword">= </span><span class="default">func_get_args</span><span class="keyword">();<br />&nbsp; &nbsp;&nbsp; while (!empty(</span><span class="default">$vars</span><span class="keyword">) &amp;&amp; empty(</span><span class="default">$defval</span><span class="keyword">))&nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$defval </span><span class="keyword">= </span><span class="default">array_shift</span><span class="keyword">(</span><span class="default">$vars</span><span class="keyword">);&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp;&nbsp; return </span><span class="default">$defval</span><span class="keyword">;<br />}<br /><br /> <br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="72199">  <div class="votes">
    <div id="Vu72199">
    <a href="/manual/vote-note.php?id=72199&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd72199">
    <a href="/manual/vote-note.php?id=72199&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V72199" title="69% like this...">
    15
    </div>
  </div>
  <a href="#72199" class="name">
  <strong class="user"><em>stepheneliotdewey at gmail [period] com</em></strong></a><a class="genanchor" href="#72199"> &para;</a><div class="date" title="2007-01-07 06:49"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom72199">
<div class="phpcode"><code><span class="html">
Note that typecasting will NOT prevent the default behavior for converting two numeric strings to numbers when comparing them.<br /><br />e.g.:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">if ((string) </span><span class="string">'0123' </span><span class="keyword">== (string) </span><span class="string">'123'</span><span class="keyword">)<br />&nbsp; &nbsp; print </span><span class="string">'equals'</span><span class="keyword">;<br />else<br />&nbsp; &nbsp; print </span><span class="string">'doesn\'t equal'</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />Still prints 'equals'<br /><br />As far as I can tell the only way to avoid this is to use the identity comparison operators (=== and !==).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="94039">  <div class="votes">
    <div id="Vu94039">
    <a href="/manual/vote-note.php?id=94039&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd94039">
    <a href="/manual/vote-note.php?id=94039&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V94039" title="67% like this...">
    11
    </div>
  </div>
  <a href="#94039" class="name">
  <strong class="user"><em>kapoor_rajiv at hotmail dot com</em></strong></a><a class="genanchor" href="#94039"> &para;</a><div class="date" title="2009-10-13 06:09"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom94039">
<div class="phpcode"><code><span class="html">
A quick way to do mysql bit comparison in php is to use the special character it stores . e.g<br /><span class="default">&lt;?php<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">if (</span><span class="default">$AvailableRequests</span><span class="keyword">[</span><span class="string">'OngoingService'</span><span class="keyword">] == </span><span class="string">''</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'&lt;td&gt;Yes&lt;/td&gt;'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'&lt;td&gt;No&lt;/td&gt;'</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="43754">  <div class="votes">
    <div id="Vu43754">
    <a href="/manual/vote-note.php?id=43754&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd43754">
    <a href="/manual/vote-note.php?id=43754&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V43754" title="70% like this...">
    8
    </div>
  </div>
  <a href="#43754" class="name">
  <strong class="user"><em>jeronimo at DELETE_THIS dot transartmedia dot com</em></strong></a><a class="genanchor" href="#43754"> &para;</a><div class="date" title="2004-07-02 04:01"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom43754">
<div class="phpcode"><code><span class="html">
For converted Perl programmers: use strict comparison operators (===, !==) in place of string comparison operators (eq, ne). Don't use the simple equality operators (==, !=), because ($a == $b) will return TRUE in many situations where ($a eq $b) would return FALSE.<br /><br />For instance...<br />"mary" == "fred" is FALSE, but<br />"+010" == "10.0" is TRUE (!)<br /><br />In the following examples, none of the strings being compared are identical, but because PHP *can* evaluate them as numbers, it does so, and therefore finds them equal...<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">echo (</span><span class="string">"007" </span><span class="keyword">== </span><span class="string">"7" </span><span class="keyword">? </span><span class="string">"EQUAL" </span><span class="keyword">: </span><span class="string">"not equal"</span><span class="keyword">);<br /></span><span class="comment">// Prints: EQUAL<br /><br />// Surrounding the strings with single quotes (') instead of double<br />// quotes (") to ensure the contents aren't evaluated, and forcing<br />// string types has no effect.<br /></span><span class="keyword">echo ( (string)</span><span class="string">'0001' </span><span class="keyword">== (string)</span><span class="string">'+1.' </span><span class="keyword">? </span><span class="string">"EQUAL" </span><span class="keyword">: </span><span class="string">"not equal"</span><span class="keyword">);<br /></span><span class="comment">// Prints: EQUAL<br /><br />// Including non-digit characters (like leading spaces, "e", the plus<br />// or minus sign, period, ...) can still result in this behavior, if<br />// a string happens to be valid scientific notation.<br /></span><span class="keyword">echo (</span><span class="string">'&nbsp; 131e-2' </span><span class="keyword">== </span><span class="string">'001.3100' </span><span class="keyword">? </span><span class="string">"EQUAL" </span><span class="keyword">: </span><span class="string">"not equal"</span><span class="keyword">);<br /></span><span class="comment">// Prints: EQUAL<br /><br /></span><span class="default">?&gt;<br /></span><br />If you're comparing passwords (or anything else for which "near" precision isn't good enough) this confusion could be detrimental. Stick with strict comparisons...<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="comment">// Same examples as above, using === instead of ==<br /><br /></span><span class="keyword">echo (</span><span class="string">"007" </span><span class="keyword">=== </span><span class="string">"7" </span><span class="keyword">? </span><span class="string">"EQUAL" </span><span class="keyword">: </span><span class="string">"not equal"</span><span class="keyword">);<br /></span><span class="comment">// Prints: not equal<br /><br /></span><span class="keyword">echo ( (string)</span><span class="string">'0001' </span><span class="keyword">=== (string)</span><span class="string">'+1.' </span><span class="keyword">? </span><span class="string">"EQUAL" </span><span class="keyword">: </span><span class="string">"not equal"</span><span class="keyword">);<br /></span><span class="comment">// Prints: not equal<br /><br /></span><span class="keyword">echo (</span><span class="string">'&nbsp; 131e-2' </span><span class="keyword">=== </span><span class="string">'001.3100' </span><span class="keyword">? </span><span class="string">"EQUAL" </span><span class="keyword">: </span><span class="string">"not equal"</span><span class="keyword">);<br /></span><span class="comment">// Prints: not equal<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="41251">  <div class="votes">
    <div id="Vu41251">
    <a href="/manual/vote-note.php?id=41251&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd41251">
    <a href="/manual/vote-note.php?id=41251&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V41251" title="67% like this...">
    12
    </div>
  </div>
  <a href="#41251" class="name">
  <strong class="user"><em>user@example</em></strong></a><a class="genanchor" href="#41251"> &para;</a><div class="date" title="2004-04-04 03:17"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom41251">
<div class="phpcode"><code><span class="html">
With Nested ternary Operators you have to set the logical&nbsp; parentheses to get the correct result.<br /><br /><span class="default">&lt;?php<br />$test</span><span class="keyword">=</span><span class="default">true</span><span class="keyword">;<br /></span><span class="default">$test2</span><span class="keyword">=</span><span class="default">true</span><span class="keyword">;<br /><br />(</span><span class="default">$test</span><span class="keyword">) ? </span><span class="string">"TEST1 true" </span><span class="keyword">:&nbsp; (</span><span class="default">$test2</span><span class="keyword">) ? </span><span class="string">"TEST2 true" </span><span class="keyword">: </span><span class="string">"false"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span>This will output: TEST2 true;<br /><br />correct:<br /><br /><span class="default">&lt;?php<br />$test</span><span class="keyword">=</span><span class="default">true</span><span class="keyword">;<br /></span><span class="default">$test2</span><span class="keyword">=</span><span class="default">true</span><span class="keyword">;<br /><br />(</span><span class="default">$test</span><span class="keyword">) ? </span><span class="string">"TEST1 true" </span><span class="keyword">: ((</span><span class="default">$test2</span><span class="keyword">) ? </span><span class="string">"TEST2 true" </span><span class="keyword">: </span><span class="string">"false"</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />Anyway don't nest them to much....!!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="46666">  <div class="votes">
    <div id="Vu46666">
    <a href="/manual/vote-note.php?id=46666&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd46666">
    <a href="/manual/vote-note.php?id=46666&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V46666" title="68% like this...">
    9
    </div>
  </div>
  <a href="#46666" class="name">
  <strong class="user"><em>hiroh2k at yahoo dot com</em></strong></a><a class="genanchor" href="#46666"> &para;</a><div class="date" title="2004-10-19 11:05"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom46666">
<div class="phpcode"><code><span class="html">
if you want to use the ?: operator, you should be careful with the precedence.<br /><br />Here's an example of the priority of operators:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">echo </span><span class="string">'Hello, ' </span><span class="keyword">. isset(</span><span class="default">$i</span><span class="keyword">) ? </span><span class="string">'my friend: ' </span><span class="keyword">. </span><span class="default">$username </span><span class="keyword">. </span><span class="string">', how are you doing?' </span><span class="keyword">: </span><span class="string">'my guest, ' </span><span class="keyword">. </span><span class="default">$guestusername </span><span class="keyword">. </span><span class="string">', please register'</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />This make "'Hello, ' . isset($i)" the sentence to evaluate. So, if you think to mix more sentences with the ?: operator, please use always parentheses to force the proper evaluation of the sentence.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">echo </span><span class="string">'Hello, ' </span><span class="keyword">. (isset(</span><span class="default">$i</span><span class="keyword">) ? </span><span class="string">'my friend: ' </span><span class="keyword">. </span><span class="default">$username </span><span class="keyword">. </span><span class="string">', how are you doing?' </span><span class="keyword">: </span><span class="string">'my guest, ' </span><span class="keyword">. </span><span class="default">$guestusername </span><span class="keyword">. </span><span class="string">', please register'</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />for general rule, if you mix ?: with other sentences, always close it with parentheses.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="66245">  <div class="votes">
    <div id="Vu66245">
    <a href="/manual/vote-note.php?id=66245&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd66245">
    <a href="/manual/vote-note.php?id=66245&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V66245" title="66% like this...">
    11
    </div>
  </div>
  <a href="#66245" class="name">
  <strong class="user"><em>Alex</em></strong></a><a class="genanchor" href="#66245"> &para;</a><div class="date" title="2006-05-17 07:49"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom66245">
<div class="phpcode"><code><span class="html">
I think everybody should read carefully what "jeronimo at DELETE_THIS dot transartmedia dot com" wrote. It's a great pitfall even for seasoned programmers and should be looked upon with a great attention.<br />For example, comparing passwords with == may result in a very large security hole.<br /><br />I would add some more to it:<br /><br />The workaround is to use strcmp() or ===.<br /><br />Note on ===:<br /><br />While the php documentation says that, basically,<br />($a===$b)&nbsp; is the same as&nbsp; ($a==$b &amp;&amp; gettype($a) == gettype($b)),<br />this is not true.<br /><br />The difference between == and === is that === never does any type conversion. So, while, according to documentation, ("+0.1" === ".1") should return true (because both are strings and == returns true), === actually returns false (which is good).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114887">  <div class="votes">
    <div id="Vu114887">
    <a href="/manual/vote-note.php?id=114887&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114887">
    <a href="/manual/vote-note.php?id=114887&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114887" title="66% like this...">
    3
    </div>
  </div>
  <a href="#114887" class="name">
  <strong class="user"><em>sgurukrupa at gmail dot com</em></strong></a><a class="genanchor" href="#114887"> &para;</a><div class="date" title="2014-04-21 06:23"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114887">
<div class="phpcode"><code><span class="html">
With respect to using the ternary operator as a 'null-coalescing' operator: expr1 ?: expr2, note that expr1 is evaluated only once.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="106131">  <div class="votes">
    <div id="Vu106131">
    <a href="/manual/vote-note.php?id=106131&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd106131">
    <a href="/manual/vote-note.php?id=106131&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V106131" title="62% like this...">
    7
    </div>
  </div>
  <a href="#106131" class="name">
  <strong class="user"><em>j-a-n at gmx dot de</em></strong></a><a class="genanchor" href="#106131"> &para;</a><div class="date" title="2011-10-13 02:32"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom106131">
<div class="phpcode"><code><span class="html">
Please be careful when comparing strings with floats, especally when you are using the , as decimal.<br /><br /><span class="default">&lt;?php<br />var_dump</span><span class="keyword">(</span><span class="default">$alt</span><span class="keyword">);<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$neu</span><span class="keyword">);<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$alt </span><span class="keyword">== </span><span class="default">$neu</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />string(9) "590217,73" <br />float(590217,73) <br />bool(false) <br /><br />not the float is cast to a string and then string-compared, but the string is cast to a float and then float-compared. <br /><br />to compare as strings use strval!<br /><br /><span class="default">&lt;?php<br />var_dump</span><span class="keyword">(</span><span class="default">strval</span><span class="keyword">(</span><span class="default">$alt</span><span class="keyword">));<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">strval</span><span class="keyword">(</span><span class="default">$neu</span><span class="keyword">));<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">strval</span><span class="keyword">(</span><span class="default">$alt</span><span class="keyword">) == </span><span class="default">strval</span><span class="keyword">(</span><span class="default">$neu</span><span class="keyword">));<br /></span><span class="default">?&gt;<br /></span><br />string(9) "590217,73" <br />string(9) "590217,73" <br />bool(true)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114816">  <div class="votes">
    <div id="Vu114816">
    <a href="/manual/vote-note.php?id=114816&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114816">
    <a href="/manual/vote-note.php?id=114816&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114816" title="62% like this...">
    6
    </div>
  </div>
  <a href="#114816" class="name">
  <strong class="user"><em>Boolean_Type</em></strong></a><a class="genanchor" href="#114816"> &para;</a><div class="date" title="2014-04-08 09:40"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114816">
<div class="phpcode"><code><span class="html">
Nice and helpful article!)<br />I would like to ask:<br /><br />number == null&nbsp; &nbsp;&nbsp; - it converts both types of comparisons to a boolean or numeric type? In the table the author pointed out that to a boolean. But elsewhere I read that to a numeric type.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="103597">  <div class="votes">
    <div id="Vu103597">
    <a href="/manual/vote-note.php?id=103597&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd103597">
    <a href="/manual/vote-note.php?id=103597&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V103597" title="61% like this...">
    8
    </div>
  </div>
  <a href="#103597" class="name">
  <strong class="user"><em>zak at minion dot net</em></strong></a><a class="genanchor" href="#103597"> &para;</a><div class="date" title="2011-04-21 11:18"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom103597">
<div class="phpcode"><code><span class="html">
be careful when trying to concatenate the result of a ternary operator to a string<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">print </span><span class="string">'&lt;div&gt;'</span><span class="keyword">.(</span><span class="default">FALSE</span><span class="keyword">) ? </span><span class="string">'TRUE [bad ternary]' </span><span class="keyword">: </span><span class="string">'FALSE [bad ternary]'</span><span class="keyword">;<br />print </span><span class="string">'&lt;br&gt;&lt;br&gt;'</span><span class="keyword">;<br />print </span><span class="string">'&lt;div&gt;'</span><span class="keyword">.((</span><span class="default">FALSE</span><span class="keyword">) ? </span><span class="string">'TRUE [good ternary]' </span><span class="keyword">: </span><span class="string">'FALSE [good ternary]'</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />yields:<br /><br />TRUE [bad ternary]<br /><br />FALSE [good ternary]<br /><br />this is because the ternary evaluates '&lt;div&gt;'.(FALSE) not (FALSE) - so the end result is TRUE</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117511">  <div class="votes">
    <div id="Vu117511">
    <a href="/manual/vote-note.php?id=117511&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117511">
    <a href="/manual/vote-note.php?id=117511&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117511" title="62% like this...">
    2
    </div>
  </div>
  <a href="#117511" class="name">
  <strong class="user"><em>Marcin Kuzawiski</em></strong></a><a class="genanchor" href="#117511"> &para;</a><div class="date" title="2015-06-21 08:12"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117511">
<div class="phpcode"><code><span class="html">
A &lt; B and still B &lt; A...<br /><br />$A = [1 =&gt; 1, 2 =&gt; 0, 3 =&gt; 1];<br />$B = [1 =&gt; 1, 3 =&gt; 0, 2 =&gt; 1];<br /><br />var_dump($A &lt; $B);&nbsp; // TRUE<br />var_dump($B &lt; $A);&nbsp; // TRUE<br /><br />var_dump($A &gt; $B);&nbsp; // TRUE<br />var_dump($B &gt; $A);&nbsp; // TRUE<br /><br />Next - C and D are comparable, but neither C &lt; D nor D &lt; C (and still C != D)...<br /><br />$C = [1 =&gt; 1, 2 =&gt; 1, 3 =&gt; 0];<br />$D = [1 =&gt; 1, 3 =&gt; 1, 2 =&gt; 0];<br /><br />var_dump($C &lt; $D); // FALSE<br />var_dump($D &lt; $C); // FALSE<br /><br />var_dump($C &gt; $D); // FALSE<br />var_dump($D &gt; $C); // FALSE<br /><br />var_dump($D == $C); // FALSE</span>
</code></div>
  </div>
 </div>
  <div class="note" id="103779">  <div class="votes">
    <div id="Vu103779">
    <a href="/manual/vote-note.php?id=103779&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd103779">
    <a href="/manual/vote-note.php?id=103779&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V103779" title="61% like this...">
    3
    </div>
  </div>
  <a href="#103779" class="name">
  <strong class="user"><em>email at kleijn dot jp</em></strong></a><a class="genanchor" href="#103779"> &para;</a><div class="date" title="2011-05-03 07:58"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom103779">
<div class="phpcode"><code><span class="html">
Maybe i am overlooking something but it seems to me that using unset(string) inside a ternary operator creates an error.<br /><br />(($var1==0 &amp;&amp; $var2==0)?unset($var3):$var3=$var1+$var2);<br /><br />result:<br />Parse error: syntax error, unexpected T_UNSET<br /><br />using the traditional form of IF...ELSE works normal.<br /><br />if($var1==0 &amp;&amp; $var2==0) { unset($var3); }<br />else { $var3=$var1+$var2; }<br /><br />result:<br />This unsets var3 or creates a sum of var1+var2 for var3<br /><br />JP Kleijn<br />Netherlands</span>
</code></div>
  </div>
 </div>
  <div class="note" id="97080">  <div class="votes">
    <div id="Vu97080">
    <a href="/manual/vote-note.php?id=97080&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd97080">
    <a href="/manual/vote-note.php?id=97080&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V97080" title="60% like this...">
    6
    </div>
  </div>
  <a href="#97080" class="name">
  <strong class="user"><em>taras dot bogach at gmail dot com</em></strong></a><a class="genanchor" href="#97080"> &para;</a><div class="date" title="2010-03-31 07:46"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom97080">
<div class="phpcode"><code><span class="html">
Boolean switch usege<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">User_Exception </span><span class="keyword">extends </span><span class="default">Exception</span><span class="keyword">{}<br />class </span><span class="default">User</span><span class="keyword">{<br />&nbsp; public function </span><span class="default">register</span><span class="keyword">(</span><span class="default">$login</span><span class="keyword">,</span><span class="default">$pass</span><span class="keyword">,</span><span class="default">$passCheck</span><span class="keyword">)<br />&nbsp; &nbsp; switch(</span><span class="default">false</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; case(</span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$pass</span><span class="keyword">) &gt;= </span><span class="default">5</span><span class="keyword">):<br />&nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">User_Exception</span><span class="keyword">(</span><span class="string">"Password must be at last 5 chars length"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; case(</span><span class="default">$pass </span><span class="keyword">== </span><span class="default">$passCheck</span><span class="keyword">):<br />&nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">User_Exception</span><span class="keyword">(</span><span class="string">"Password is not confirmed!"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; case(</span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$login</span><span class="keyword">) &gt;= </span><span class="default">5</span><span class="keyword">):<br />&nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">User_Exception</span><span class="keyword">(</span><span class="string">"Login must be at last 5 chars length"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; </span><span class="comment">//Do other checks<br />&nbsp; &nbsp; &nbsp; </span><span class="keyword">default:<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//Do registration<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">true</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; }<br />&nbsp; </span><span class="comment">//...<br /></span><span class="keyword">}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="88791">  <div class="votes">
    <div id="Vu88791">
    <a href="/manual/vote-note.php?id=88791&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd88791">
    <a href="/manual/vote-note.php?id=88791&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V88791" title="61% like this...">
    3
    </div>
  </div>
  <a href="#88791" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#88791"> &para;</a><div class="date" title="2009-02-07 06:37"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom88791">
<div class="phpcode"><code><span class="html">
Here is some ternary trick I like to use for selecting a default value in a set of radio buttons. This example assumes that a prior value was known and that we are offering a user the chance to edit that prior value. If no prior value was actually known, no default value will be set.<br /><br />&lt;form&gt;<br />&lt;input type='radio' name='gender' value='m' <span class="default">&lt;?=</span><span class="keyword">(</span><span class="default">$gender</span><span class="keyword">==</span><span class="string">'m'</span><span class="keyword">)?</span><span class="string">"checked"</span><span class="keyword">:</span><span class="string">""</span><span class="default">?&gt;</span>&gt;Male<br />&lt;input type='radio' name='gender' value='f' <span class="default">&lt;?=</span><span class="keyword">(</span><span class="default">$gender</span><span class="keyword">==</span><span class="string">'f'</span><span class="keyword">)?</span><span class="string">"checked"</span><span class="keyword">:</span><span class="string">""</span><span class="default">?&gt;</span>&gt;Female<br />&lt;/form&gt;<br /><br />When a "=" directly follows a "&lt;?" (no space allowed in between -- the trick does not work with "&lt;?php"), the right side of the operand (here, the result of the ternary operation) is printed out as text into the surrounding HTML code. If using "&lt;?php" form, you will need to do "<span class="default">&lt;?php </span><span class="keyword">echo </span><span class="default">exp1</span><span class="keyword">?</span><span class="default">exp2</span><span class="keyword">:</span><span class="default">exp3 ?&gt;</span>" instead.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="112370">  <div class="votes">
    <div id="Vu112370">
    <a href="/manual/vote-note.php?id=112370&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd112370">
    <a href="/manual/vote-note.php?id=112370&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V112370" title="60% like this...">
    4
    </div>
  </div>
  <a href="#112370" class="name">
  <strong class="user"><em>damien dot launay dot mail at gmail dot com</em></strong></a><a class="genanchor" href="#112370"> &para;</a><div class="date" title="2013-06-07 02:46"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom112370">
<div class="phpcode"><code><span class="html">
I found a nice way to use of new "?:" operator:<br /><br />$a = array();<br />$a['foo'] = 'oof';<br /><br />$b = @ ($a['foo'] ?: 'No foo');<br />$c = @ ($a['bar'] ?: 'No bar');<br /><br />var_dump($b, $c);<br /><br />Output:<br /><br />string(3) "oof"<br />string(6) "No bar"<br /><br />No error is thrown and $c is set with correct value.<br /><br />Benefit: no need to use isset.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118648">  <div class="votes">
    <div id="Vu118648">
    <a href="/manual/vote-note.php?id=118648&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118648">
    <a href="/manual/vote-note.php?id=118648&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118648" title="60% like this...">
    1
    </div>
  </div>
  <a href="#118648" class="name">
  <strong class="user"><em>prezire at gmail dot com</em></strong></a><a class="genanchor" href="#118648"> &para;</a><div class="date" title="2016-01-15 03:42"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom118648">
<div class="phpcode"><code><span class="html">
Take note when grouping ternary operations that return either boolean or integer concatenated to a string:<br /><span class="default">&lt;?php<br />&nbsp; </span><span class="keyword">echo </span><span class="string">'hello ' </span><span class="keyword">. </span><span class="default">true </span><span class="keyword">? </span><span class="default">1 </span><span class="keyword">: </span><span class="default">0</span><span class="keyword">, </span><span class="comment">//Outputs 1<br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="string">'hello ' </span><span class="keyword">. (</span><span class="default">true </span><span class="keyword">? </span><span class="default">1 </span><span class="keyword">: </span><span class="default">0</span><span class="keyword">); </span><span class="comment">//Outputs hello 1<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="109373">  <div class="votes">
    <div id="Vu109373">
    <a href="/manual/vote-note.php?id=109373&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd109373">
    <a href="/manual/vote-note.php?id=109373&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V109373" title="57% like this...">
    5
    </div>
  </div>
  <a href="#109373" class="name">
  <strong class="user"><em>toader_alexandru at yahoo dot com</em></strong></a><a class="genanchor" href="#109373"> &para;</a><div class="date" title="2012-07-11 01:56"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom109373">
<div class="phpcode"><code><span class="html">
it looks that<br /><br />if you check 0 against a string with == then PHP returns true:<br /><br />php -r 'var_dump(0 == "statuses");'<br />-&gt; returns TRUE<br /><br />but not if your string has a number at the beginning:<br /><br />php -r 'var_dump(0 == "2statuses");'<br />-&gt; returns FALSE<br /><br />from the specs I get it that it attempts a conversion - in this case the string to number.<br /><br />so better use ===<br />as always :)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="81370">  <div class="votes">
    <div id="Vu81370">
    <a href="/manual/vote-note.php?id=81370&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd81370">
    <a href="/manual/vote-note.php?id=81370&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V81370" title="57% like this...">
    2
    </div>
  </div>
  <a href="#81370" class="name">
  <strong class="user"><em>Amaroq</em></strong></a><a class="genanchor" href="#81370"> &para;</a><div class="date" title="2008-02-25 03:13"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom81370">
<div class="phpcode"><code><span class="html">
Most of the time, you may be content with your conditionals evaluating to true if they are evaluating a non-false, non-zero value. You may also like it when they evaluate to false when you use the number 0.<br /><br />However, there may be times where you want to make a distinction between a non-false value and a boolean true. You may also wish to make a distinction between a boolean false and a zero.<br /><br />The identity operator can make this distinction for you.<br /><br /><span class="default">&lt;?php<br />$a </span><span class="keyword">= </span><span class="string">'some string'</span><span class="keyword">;<br /></span><span class="default">$b </span><span class="keyword">= </span><span class="default">123</span><span class="keyword">;<br /></span><span class="default">$c </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br /><br />if(</span><span class="default">$a </span><span class="keyword">&amp;&amp; </span><span class="default">$b </span><span class="keyword">&amp;&amp; (!</span><span class="default">$c</span><span class="keyword">))<br />{ echo </span><span class="string">"True.\n"</span><span class="keyword">; } else { echo </span><span class="string">"False.\n"</span><span class="keyword">; }<br /><br />if(</span><span class="default">$a </span><span class="keyword">== </span><span class="default">true </span><span class="keyword">&amp;&amp; </span><span class="default">$b </span><span class="keyword">== </span><span class="default">true </span><span class="keyword">&amp;&amp; </span><span class="default">$c </span><span class="keyword">== </span><span class="default">false</span><span class="keyword">)<br />{ echo </span><span class="string">"True.\n"</span><span class="keyword">; } else { echo </span><span class="string">"False.\n"</span><span class="keyword">; }<br /><br />if(</span><span class="default">$a </span><span class="keyword">=== </span><span class="default">true </span><span class="keyword">|| </span><span class="default">$b </span><span class="keyword">=== </span><span class="default">true </span><span class="keyword">|| </span><span class="default">$c </span><span class="keyword">=== </span><span class="default">false</span><span class="keyword">)<br />{ echo </span><span class="string">"True.\n"</span><span class="keyword">; } else { echo </span><span class="string">"False.\n"</span><span class="keyword">; }<br /></span><span class="default">?&gt;<br /></span><br />The above code outputs the following:<br />True.<br />True.<br />False.<br /><br />As you can see, in the first two cases, $a and $b are considered true, while $c is considered false. If this wasn't the case, neither of the first two conditionals would have echoed "True."<br /><br />In the last case, I've cleverly used the || operator to demonstrate that both $a and $b do not evaluate to true with the identity operator, nor does $c evaluate to false.<br /><br />The === operator can be used to distinguish boolean from non-boolean values.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="108690">  <div class="votes">
    <div id="Vu108690">
    <a href="/manual/vote-note.php?id=108690&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd108690">
    <a href="/manual/vote-note.php?id=108690&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V108690" title="54% like this...">
    2
    </div>
  </div>
  <a href="#108690" class="name">
  <strong class="user"><em>wbcarts at juno dot com</em></strong></a><a class="genanchor" href="#108690"> &para;</a><div class="date" title="2012-05-17 09:20"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom108690">
<div class="phpcode"><code><span class="html">
COMPARING PHP OBJECTS (compound type)<br /><br />We have seen that PHP does a lot of type-juggling on its own -- which can wreak havoc in unexpected ways -- but it is still up to us to produce code that is clear, maintainable AND follows the rules we want to follow.<br /><br />When creating a PHP Object, it is sometimes unclear what makes two of them the same. But the good part is that we can say what is equal and what is not equal. For example, let's say we have a Student class that includes an equals() method which defines what is equal for this type of object.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="comment">#Student.php<br /><br /></span><span class="keyword">class </span><span class="default">Student<br /></span><span class="keyword">{<br />&nbsp; </span><span class="comment">/*<br />&nbsp;&nbsp; * These variables are protected to prevent outside code<br />&nbsp;&nbsp; * from tampering with them.<br />&nbsp;&nbsp; */<br />&nbsp; </span><span class="keyword">protected </span><span class="default">$student_id</span><span class="keyword">;<br />&nbsp; protected </span><span class="default">$student_name</span><span class="keyword">;<br /><br />&nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$id</span><span class="keyword">, </span><span class="default">$name</span><span class="keyword">)<br />&nbsp; {<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">student_id </span><span class="keyword">= (int)</span><span class="default">$id</span><span class="keyword">;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// cast to integer here<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">student_name </span><span class="keyword">= (string)</span><span class="default">$name</span><span class="keyword">;&nbsp;&nbsp; </span><span class="comment">// cast to string here<br />&nbsp; </span><span class="keyword">}<br /><br />&nbsp; </span><span class="comment">/*<br />&nbsp;&nbsp; * This function requires an instance of type Student and<br />&nbsp;&nbsp; * only evaluates two integers that we set in __construct().<br />&nbsp;&nbsp; */<br />&nbsp; </span><span class="keyword">public function </span><span class="default">equals</span><span class="keyword">(</span><span class="default">Student $student</span><span class="keyword">)<br />&nbsp; {<br />&nbsp; &nbsp; return (</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">getId</span><span class="keyword">() == </span><span class="default">$student</span><span class="keyword">-&gt;</span><span class="default">getId</span><span class="keyword">());<br />&nbsp; }<br /><br />&nbsp; public function </span><span class="default">getId</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">student_id</span><span class="keyword">;<br />&nbsp; }<br /><br />&nbsp; public function </span><span class="default">getName</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">student_name</span><span class="keyword">;<br />&nbsp; }<br /><br />&nbsp; public function </span><span class="default">__toString</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; return </span><span class="string">'Student [id=' </span><span class="keyword">. </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">getId</span><span class="keyword">() .<br />&nbsp; &nbsp; </span><span class="string">', name=' </span><span class="keyword">. </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">getName</span><span class="keyword">() . </span><span class="string">']'</span><span class="keyword">;<br />&nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />With this class, the protected variables cannot be tampered with by outside code. Also, the __construct() function casts the variables to the PHP primitives WE WANT, while the equals(Student $student) function, requires an argument of type Student -- which eliminates the need for an IDENTITY '===' check AND prevents any other data types from coming in. One other note: notice how the equals() function only evaluates the $student_id, this allows for two students to have the same name -- which is totally possible.<br /><br />Here's a short example -- we'll do it correctly AND try to screw it up!<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">require(</span><span class="string">'Student.php'</span><span class="keyword">);<br /><br /></span><span class="default">$s1 </span><span class="keyword">= new </span><span class="default">Student</span><span class="keyword">(</span><span class="default">122</span><span class="keyword">, </span><span class="string">'John Doe'</span><span class="keyword">);<br /></span><span class="default">$s2 </span><span class="keyword">= new </span><span class="default">Student</span><span class="keyword">(</span><span class="default">344</span><span class="keyword">, </span><span class="string">'John Doe'</span><span class="keyword">);<br /><br />echo </span><span class="default">$s1 </span><span class="keyword">. </span><span class="string">'&lt;br&gt;'</span><span class="keyword">;&nbsp; </span><span class="comment">// Student [id=122, name=John Doe]<br /></span><span class="keyword">echo </span><span class="default">$s2 </span><span class="keyword">. </span><span class="string">'&lt;br&gt;'</span><span class="keyword">;&nbsp; </span><span class="comment">// Student [id=344, name=John Doe]<br /><br /># Check for equality the CORRECT way...<br /></span><span class="keyword">echo (</span><span class="default">$s1</span><span class="keyword">-&gt;</span><span class="default">equals</span><span class="keyword">(</span><span class="default">$s2</span><span class="keyword">) ? </span><span class="string">'EQUAL' </span><span class="keyword">: </span><span class="string">'NOT EQUAL'</span><span class="keyword">);&nbsp; </span><span class="comment">// NOT EQUAL<br /><br /># Check for equality by HACKING the known value of $student_id...<br /></span><span class="keyword">echo (</span><span class="default">$s1</span><span class="keyword">-&gt;</span><span class="default">equals</span><span class="keyword">(</span><span class="default">122</span><span class="keyword">) ? </span><span class="string">'EQUAL' </span><span class="keyword">: </span><span class="string">'NOT EQUAL'</span><span class="keyword">);&nbsp; </span><span class="comment">// Catchable fatal error: Argument 1 passed to Student::equals() must be an instance of Student, integer given... etc, etc.<br /><br /></span><span class="default">?&gt;<br /></span><br />See what I mean by writing code that follows OUR RULES? The Student class does the kind of type-juggling we want (and when we want it done) -- NOT when, where, or why PHP does it (not that there's anything wrong with it).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="104456">  <div class="votes">
    <div id="Vu104456">
    <a href="/manual/vote-note.php?id=104456&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd104456">
    <a href="/manual/vote-note.php?id=104456&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V104456" title="52% like this...">
    1
    </div>
  </div>
  <a href="#104456" class="name">
  <strong class="user"><em>Mark Simon</em></strong></a><a class="genanchor" href="#104456"> &para;</a><div class="date" title="2011-06-16 02:20"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom104456">
<div class="phpcode"><code><span class="html">
The use of 5.3’s shortened ternary operator allows PHP to coalesce a null or empty value to an alternative:<br /><br />$value = $planA ?: $planB;<br /><br />My own server doesn’t yet run 5.3. A nice alternative is to use the “or” operator:<br /><br />$value = $planA or $value = planB;</span>
</code></div>
  </div>
 </div>
  <div class="note" id="92511">  <div class="votes">
    <div id="Vu92511">
    <a href="/manual/vote-note.php?id=92511&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd92511">
    <a href="/manual/vote-note.php?id=92511&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V92511" title="53% like this...">
    1
    </div>
  </div>
  <a href="#92511" class="name">
  <strong class="user"><em>monkuar at gmail dot com</em></strong></a><a class="genanchor" href="#92511"> &para;</a><div class="date" title="2009-07-27 04:45"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom92511">
<div class="phpcode"><code><span class="html">
U can even add a variable on that if u wish:<br /><br />($Profile['skinstyle']=='0')? $lol = "selected":"";<br /><br />then call it out.. alot faster. if u use EOF.. and such like on ibp :(</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121380">  <div class="votes">
    <div id="Vu121380">
    <a href="/manual/vote-note.php?id=121380&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121380">
    <a href="/manual/vote-note.php?id=121380&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121380" title="100% like this...">
    2
    </div>
  </div>
  <a href="#121380" class="name">
  <strong class="user"><em>G</em></strong></a><a class="genanchor" href="#121380"> &para;</a><div class="date" title="2017-07-15 12:19"><strong>4 months ago</strong></div>
  <div class="text" id="Hcom121380">
<div class="phpcode"><code><span class="html">
Do note, using the ternary operator shorthand (since 5.3), omitting the 2nd expression the first expression will only be called once.<br /><br />Before 5.3 (or not using the shorthand)<br /><span class="default">&lt;?php<br />$val </span><span class="keyword">= </span><span class="default">f</span><span class="keyword">(</span><span class="string">'x'</span><span class="keyword">) ? </span><span class="default">f</span><span class="keyword">(</span><span class="string">'x'</span><span class="keyword">) : </span><span class="default">false</span><span class="keyword">;<br /></span><span class="comment">// f('x') will be run twice<br /></span><span class="default">?&gt;<br /></span><br />After 5.3<br /><span class="default">&lt;?php<br />$val </span><span class="keyword">= </span><span class="default">f</span><span class="keyword">(</span><span class="string">'x'</span><span class="keyword">) ?: </span><span class="default">false</span><span class="keyword">;<br /></span><span class="comment">// f('x') will be run once<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121907">  <div class="votes">
    <div id="Vu121907">
    <a href="/manual/vote-note.php?id=121907&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121907">
    <a href="/manual/vote-note.php?id=121907&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121907" title="100% like this...">
    1
    </div>
  </div>
  <a href="#121907" class="name">
  <strong class="user"><em>niall at maranelda dot org</em></strong></a><a class="genanchor" href="#121907"> &para;</a><div class="date" title="2017-11-23 12:16"><strong>21 days ago</strong></div>
  <div class="text" id="Hcom121907">
<div class="phpcode"><code><span class="html">
Care must be taken when using the spaceship operator with arrays that do not have the same keys:<br /><br />- Contrary to the notes above ("Example #2 Transcription of standard array comparison"), it does *not* return null if the left-hand array contains a key that the right-hand array does not.<br />- Because of this, the result depends on the order you do the comparison in.<br /><br />For example:<br /><br /><span class="default">&lt;?php<br />$a </span><span class="keyword">= [</span><span class="string">'a' </span><span class="keyword">=&gt; </span><span class="default">1</span><span class="keyword">, </span><span class="string">'b' </span><span class="keyword">=&gt; </span><span class="default">2</span><span class="keyword">, </span><span class="string">'c' </span><span class="keyword">=&gt; </span><span class="default">3</span><span class="keyword">, </span><span class="string">'e' </span><span class="keyword">=&gt; </span><span class="default">4</span><span class="keyword">];<br /></span><span class="default">$b </span><span class="keyword">= [</span><span class="string">'a' </span><span class="keyword">=&gt; </span><span class="default">1</span><span class="keyword">, </span><span class="string">'b' </span><span class="keyword">=&gt; </span><span class="default">2</span><span class="keyword">, </span><span class="string">'d' </span><span class="keyword">=&gt; </span><span class="default">3</span><span class="keyword">, </span><span class="string">'e' </span><span class="keyword">=&gt; </span><span class="default">4</span><span class="keyword">];<br /><br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$a </span><span class="keyword">&lt;=&gt; </span><span class="default">$b</span><span class="keyword">);&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// int(1) : $a &gt; $b because $a has the 'c' key and $b doesn't.<br /><br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$b </span><span class="keyword">&lt;=&gt; </span><span class="default">$a</span><span class="keyword">);&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// int(1) : $b &gt; $a because $b has the 'd' key and $a doesn't.<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="99216">  <div class="votes">
    <div id="Vu99216">
    <a href="/manual/vote-note.php?id=99216&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd99216">
    <a href="/manual/vote-note.php?id=99216&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V99216" title="51% like this...">
    1
    </div>
  </div>
  <a href="#99216" class="name">
  <strong class="user"><em>mail at markuszeller dot com</em></strong></a><a class="genanchor" href="#99216"> &para;</a><div class="date" title="2010-08-04 01:40"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom99216">
<div class="phpcode"><code><span class="html">
I prefer writing (!$a == 'hello') much more than ($a != 'hello'), but I wondered about the performance.<br /><br />So I did a benchmark:<br /><span class="default">&lt;?php<br /></span><span class="keyword">for(</span><span class="default">$bench </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">; </span><span class="default">$bench </span><span class="keyword">&lt; </span><span class="default">3</span><span class="keyword">; </span><span class="default">$bench</span><span class="keyword">++)<br />{<br />&nbsp; &nbsp; </span><span class="default">$start </span><span class="keyword">= </span><span class="default">microtime</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$a </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; for(</span><span class="default">$i </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">; </span><span class="default">$i </span><span class="keyword">&lt; </span><span class="default">100000000</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">++)<br />&nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; if(!</span><span class="default">$a </span><span class="keyword">== </span><span class="string">'hello'</span><span class="keyword">) </span><span class="default">$b</span><span class="keyword">++;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; </span><span class="default">$end </span><span class="keyword">= </span><span class="default">microtime</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">);<br />&nbsp; &nbsp; echo </span><span class="string">"Used time: " </span><span class="keyword">. (</span><span class="default">$end</span><span class="keyword">-</span><span class="default">$start</span><span class="keyword">) . </span><span class="string">"\n"</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span>and it results with<br /><br /># if($a != 'hello')<br />Used time: 12.552895069122<br />Used time: 12.548940896988<br />Used time: 12.470285177231<br /><br /># if(!$a == 'hello')<br />Used time: 7.6532161235809<br />Used time: 7.6426539421082<br />Used time: 7.6452689170837</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121089">  <div class="votes">
    <div id="Vu121089">
    <a href="/manual/vote-note.php?id=121089&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121089">
    <a href="/manual/vote-note.php?id=121089&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121089" title="0% like this...">
    -2
    </div>
  </div>
  <a href="#121089" class="name">
  <strong class="user"><em>fr at felix-riesterer dot de</em></strong></a><a class="genanchor" href="#121089"> &para;</a><div class="date" title="2017-05-16 08:42"><strong>6 months ago</strong></div>
  <div class="text" id="Hcom121089">
<div class="phpcode"><code><span class="html">
I wanted to see if two arrays carry the same information even if they are technically different, so I created the following function. Hopefully this is useful to somebody.<br /><br />Note: This is a different approach than "rshawiii at yahoo dot com" has taken.<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">/**<br /> * function to compare the contents of two arrays<br /> *<br /> * This function returns true if all the following are true:<br /> * - arrays' values match<br /> * - arrays' keys match<br /> * - keys-value pairs are the same in both arrays<br /> *<br /> * The order of the key-value pairs does not matter, so even if<br /> * ($array1 == $array2) is technically false, this function might<br /> * still return true like in the following examples:<br /> *<br /> * $a = array(1, 5, 8);<br /> * $b = array(5, 1, 8);<br /> * =&gt; true<br /> *<br /> * $a = array('a' =&gt; 1, 'b' =&gt; 2, 'c' =&gt; 'xyz');<br /> * $b = array('a' =&gt; 1, 'c' =&gt; 'xyz', 'b' =&gt; 2);<br /> * =&gt; true<br /> *<br /> * $a = array(4 =&gt; 1, 7 =&gt; 2, 12 =&gt; 'xyz');<br /> * $b = array(9 =&gt; 2, 3 =&gt; 1, 123 =&gt; 'xyz');<br /> * =&gt; false<br /> *<br /> * @param array<br /> * @param array<br /> * @return bool matching<br /> */<br /></span><span class="keyword">function </span><span class="default">same_array_contents</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">) {<br /><br />&nbsp; &nbsp; </span><span class="comment">// easy<br />&nbsp; &nbsp; </span><span class="keyword">if (</span><span class="default">count</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">) != </span><span class="default">count</span><span class="keyword">(</span><span class="default">$b</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">// complicated 1: different values<br />&nbsp; &nbsp; </span><span class="default">$a_values </span><span class="keyword">= </span><span class="default">array_values</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$b_values </span><span class="keyword">= </span><span class="default">array_values</span><span class="keyword">(</span><span class="default">$b</span><span class="keyword">);<br /><br />&nbsp; &nbsp; </span><span class="default">sort</span><span class="keyword">(</span><span class="default">$a_values</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">sort</span><span class="keyword">(</span><span class="default">$b_values</span><span class="keyword">);<br /><br />&nbsp; &nbsp; if (</span><span class="default">$a_values </span><span class="keyword">!= </span><span class="default">$b_values</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">// complicated 2: different index names<br />&nbsp; &nbsp; </span><span class="default">$a_keys </span><span class="keyword">= </span><span class="default">array_keys</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$b_keys </span><span class="keyword">= </span><span class="default">array_keys</span><span class="keyword">(</span><span class="default">$b</span><span class="keyword">);<br /><br />&nbsp; &nbsp; </span><span class="default">sort</span><span class="keyword">(</span><span class="default">$a_keys</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">sort</span><span class="keyword">(</span><span class="default">$b_keys</span><span class="keyword">);<br /><br />&nbsp; &nbsp; if (</span><span class="default">$a_keys </span><span class="keyword">!= </span><span class="default">$b_keys</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">// complicated 3 (same values and same keys): key =&gt; value different?<br />&nbsp; &nbsp; </span><span class="default">$r </span><span class="keyword">= </span><span class="default">true</span><span class="keyword">; </span><span class="comment">// expect match<br /><br />&nbsp; &nbsp; </span><span class="keyword">if (</span><span class="default">array_keys</span><span class="keyword">(</span><span class="default">$a_keys</span><span class="keyword">) != </span><span class="default">$a_keys<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">|| </span><span class="default">array_keys</span><span class="keyword">(</span><span class="default">$b_keys</span><span class="keyword">) != </span><span class="default">$b_keys<br />&nbsp; &nbsp; </span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// associative array(s)<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">foreach (</span><span class="default">$a_keys </span><span class="keyword">as </span><span class="default">$key</span><span class="keyword">) {<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$a</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">] != </span><span class="default">$b</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">]) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$r </span><span class="keyword">= </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; return </span><span class="default">$r</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="100082">  <div class="votes">
    <div id="Vu100082">
    <a href="/manual/vote-note.php?id=100082&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd100082">
    <a href="/manual/vote-note.php?id=100082&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V100082" title="50% like this...">
    0
    </div>
  </div>
  <a href="#100082" class="name">
  <strong class="user"><em>me at lx dot sg</em></strong></a><a class="genanchor" href="#100082"> &para;</a><div class="date" title="2010-09-23 07:08"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom100082">
<div class="phpcode"><code><span class="html">
Replying to the comment on Aug 6, 2010, the comparisons return TRUE because they are recognized as numerical strings and are converted to integers. If you try "abc" == " abc", it will return FALSE as expected. To avoid the type conversions, simply use the identity operator (===).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="41534">  <div class="votes">
    <div id="Vu41534">
    <a href="/manual/vote-note.php?id=41534&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd41534">
    <a href="/manual/vote-note.php?id=41534&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V41534" title="50% like this...">
    0
    </div>
  </div>
  <a href="#41534" class="name">
  <strong class="user"><em>webmaster __AT__ digitalanime __DOT__ nl</em></strong></a><a class="genanchor" href="#41534"> &para;</a><div class="date" title="2004-04-13 03:31"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom41534">
<div class="phpcode"><code><span class="html">
WARNING!!!!<br /><br />Let's say, we have this little script:<br /><br /><span class="default">&lt;?php<br />$username </span><span class="keyword">= </span><span class="string">'Me'</span><span class="keyword">;<br /></span><span class="default">$guestusername </span><span class="keyword">= </span><span class="string">'Guest'</span><span class="keyword">;<br /><br />echo </span><span class="string">'Hello, ' </span><span class="keyword">. isset(</span><span class="default">$i</span><span class="keyword">) ? </span><span class="string">'my friend: ' </span><span class="keyword">. </span><span class="default">$username </span><span class="keyword">. </span><span class="string">', how are you doing?' </span><span class="keyword">: </span><span class="string">'my guest, ' </span><span class="keyword">. </span><span class="default">$guestusername </span><span class="keyword">. </span><span class="string">', please register'</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />What you want:<br />If $i is set, display:<br />Hello, my friend: Me, how are you doing?<br />If not, display:<br />Hello, my guest, Guest, please register<br /><br />BUT, you DON'T get that result!<br /><br />If $i is set, you get this:<br />my friend: Me, how are you doing? (so, there's not "Hello, " before it)<br />If $i is NOT set, you get this:<br />my friend: Me, how are you doing?<br /><br />So... That's the same!<br /><br />You can solve this by using the "(" and ")" to give priority to the ternary operator:<br /><br /><span class="default">&lt;?php<br />$username </span><span class="keyword">= </span><span class="string">'Me'</span><span class="keyword">;<br /></span><span class="default">$guestusername </span><span class="keyword">= </span><span class="string">'Guest'</span><span class="keyword">;<br /><br />echo </span><span class="string">'Hello, ' </span><span class="keyword">. (isset(</span><span class="default">$i</span><span class="keyword">) ? </span><span class="string">'my friend: ' </span><span class="keyword">. </span><span class="default">$username </span><span class="keyword">. </span><span class="string">', how are you doing?' </span><span class="keyword">: </span><span class="string">'my guest, ' </span><span class="keyword">. </span><span class="default">$guestusername </span><span class="keyword">. </span><span class="string">', please register'</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />When $i is set, you get this:<br />Hello, my friend: Me, how are you doing? (expected)<br />When $i is NOT set, you get this:<br />Hello, my guest, Guest, please register (expected too)<br /><br />So.. Please, don't be dumb and ALWAYS use the priority-signs (or.. How do you call them?), ( and ).<br />By using them, you won't get unneeded trouble and always know for sure your code is doing what you want: The right thing.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="68782">  <div class="votes">
    <div id="Vu68782">
    <a href="/manual/vote-note.php?id=68782&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd68782">
    <a href="/manual/vote-note.php?id=68782&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V68782" title="46% like this...">
    -1
    </div>
  </div>
  <a href="#68782" class="name">
  <strong class="user"><em>pcdinh at phpvietnam dot net</em></strong></a><a class="genanchor" href="#68782"> &para;</a><div class="date" title="2006-08-10 09:50"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom68782">
<div class="phpcode"><code><span class="html">
You should be very careful when using == with an result set returned from a query that can be an empty array, multi-dimensional array or a boolean false value (if the query failed to execute). In PHP, an empty array is equivalent to true.<br /><br /><span class="default">&lt;?php<br />$myArray </span><span class="keyword">= array();<br /><br /></span><span class="comment">// check if there is any error with the query<br /></span><span class="keyword">if (</span><span class="default">$myArray </span><span class="keyword">== </span><span class="default">false</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; echo </span><span class="string">"Yes"</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />return Yes<br /><br />Use === instead.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117870">  <div class="votes">
    <div id="Vu117870">
    <a href="/manual/vote-note.php?id=117870&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117870">
    <a href="/manual/vote-note.php?id=117870&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117870" title="42% like this...">
    -2
    </div>
  </div>
  <a href="#117870" class="name">
  <strong class="user"><em>Hayley Watson</em></strong></a><a class="genanchor" href="#117870"> &para;</a><div class="date" title="2015-08-24 03:49"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117870">
<div class="phpcode"><code><span class="html">
When the comparison rules for the spaceship operator say that for "object&lt;=&gt;anything" the object is always greater, and for "array&lt;=&gt;anything" the array is always greater.<br /><br />The rules should be used in the order they are listed. In the latter case, "anything" means "anything except an object".<br /><br />The former rule says that "object&lt;=&gt;array" will always decide that the object is greater (and evaluate to a positive integer); to be consistent, the comparison "array&lt;=&gt;object" must also always decide that the object is greater (and evaluate to a negative integer).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="95952">  <div class="votes">
    <div id="Vu95952">
    <a href="/manual/vote-note.php?id=95952&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd95952">
    <a href="/manual/vote-note.php?id=95952&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V95952" title="41% like this...">
    -3
    </div>
  </div>
  <a href="#95952" class="name">
  <strong class="user"><em>ISAWHIM</em></strong></a><a class="genanchor" href="#95952"> &para;</a><div class="date" title="2010-01-30 10:53"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom95952">
<div class="phpcode"><code><span class="html">
When it comes to formatting structure of the conditional statements, I found this to work best and retain logic in views...<br /><br /><span class="default">&lt;?php<br />$z </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">;<br /></span><span class="default">$text </span><span class="keyword">= (</span><span class="default">$z</span><span class="keyword">===</span><span class="default">1 </span><span class="keyword">? </span><span class="string">'ONE'<br />&nbsp; </span><span class="keyword">: (</span><span class="default">$z</span><span class="keyword">===</span><span class="default">2 </span><span class="keyword">? </span><span class="string">'TWO'<br />&nbsp; </span><span class="keyword">: (</span><span class="default">$z</span><span class="keyword">===</span><span class="default">3 </span><span class="keyword">? </span><span class="string">'THREE'<br />&nbsp; </span><span class="keyword">: </span><span class="string">'MORE' </span><span class="keyword">)));<br />echo(</span><span class="default">$text</span><span class="keyword">); </span><span class="comment">// RESULT='TWO'<br /><br />// LONGHAND<br /><br /></span><span class="default">$z </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">;<br /></span><span class="default">$text </span><span class="keyword">= (</span><span class="default">$z</span><span class="keyword">===</span><span class="default">1</span><span class="keyword">?</span><span class="string">'ONE' </span><span class="keyword">: (</span><span class="default">$z</span><span class="keyword">===</span><span class="default">2</span><span class="keyword">?</span><span class="string">'TWO' </span><span class="keyword">: (</span><span class="default">$z</span><span class="keyword">===</span><span class="default">3</span><span class="keyword">?</span><span class="string">'THREE' </span><span class="keyword">: </span><span class="string">'MORE'</span><span class="keyword">)));<br />echo(</span><span class="default">$text</span><span class="keyword">); </span><span class="comment">// RESULT='TWO'<br /></span><span class="default">?&gt;<br /></span><br />Since this is expected to test logic, and nothing more, only use it to test logic.<br /><br />To test order, if you ever forget...<br /><br /><span class="default">&lt;?php<br />$z </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br /></span><span class="default">$text </span><span class="keyword">= (</span><span class="default">$z</span><span class="keyword">===</span><span class="default">1 </span><span class="keyword">? </span><span class="string">'FIRST : OUTTER'<br />&nbsp; </span><span class="keyword">: (</span><span class="default">$z</span><span class="keyword">===</span><span class="default">1 </span><span class="keyword">? </span><span class="string">'SECOND : INNER'<br />&nbsp; </span><span class="keyword">: (</span><span class="default">$z</span><span class="keyword">===</span><span class="default">1 </span><span class="keyword">? </span><span class="string">'THIRD : LAST'<br />&nbsp; </span><span class="keyword">: </span><span class="string">'FAIL EVAL DEFAULT' </span><span class="keyword">)));<br />echo(</span><span class="default">$text</span><span class="keyword">); </span><span class="comment">// RETURN='FIRST : OUTTER'<br /><br /></span><span class="default">$z </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">;<br /></span><span class="default">$text </span><span class="keyword">= (</span><span class="default">$z</span><span class="keyword">===</span><span class="default">1 </span><span class="keyword">? </span><span class="string">'FIRST : OUTTER'<br />&nbsp; </span><span class="keyword">: (</span><span class="default">$z</span><span class="keyword">===</span><span class="default">1 </span><span class="keyword">? </span><span class="string">'SECOND : INNER'<br />&nbsp; </span><span class="keyword">: (</span><span class="default">$z</span><span class="keyword">===</span><span class="default">1 </span><span class="keyword">? </span><span class="string">'THIRD : LAST'<br />&nbsp; </span><span class="keyword">: </span><span class="string">'FAIL EVAL DEFAULT' </span><span class="keyword">)));<br />echo(</span><span class="default">$text</span><span class="keyword">); </span><span class="comment">// RETURN='FAIL EVAL DEFAULT'<br /></span><span class="default">?&gt;<br /></span><br />(IF ? THEN : ELSE)<br />(IF ? THEN : ELSE(IF ? THEN : ELSE(IF ? THEN : ELSE))<br /><br />That can't be read from inside to out, unlike a math formula, because the logic in comparison is not the same. In math nesting, you need the solution to the deepest nested element first. In logic comparison, you always start outside before you compare inside. (Logically, IF there is no door THEN you need something ELSE to get inside. Oh, there is a window... We are inside, now IF there is a fridge THEN open it or ELSE you starve.)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="93614">  <div class="votes">
    <div id="Vu93614">
    <a href="/manual/vote-note.php?id=93614&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd93614">
    <a href="/manual/vote-note.php?id=93614&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V93614" title="40% like this...">
    -3
    </div>
  </div>
  <a href="#93614" class="name">
  <strong class="user"><em>pinkgothic at gmail dot com</em></strong></a><a class="genanchor" href="#93614"> &para;</a><div class="date" title="2009-09-18 04:28"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom93614">
<div class="phpcode"><code><span class="html">
"Array with fewer members is smaller, if key from operand 1 is not found in operand 2 then arrays are uncomparable, otherwise - compare value by value (see following example)."<br /><br />The example covers this behaviour, but it isn't immediately obvious, so:<br /><br />If you're doing loose comparisons in PHP, note that they differ from checking each value individually like $value1==$value2 by adding what amounts to an empty($value1)==empty($value2) check into the mix. I found this out by investigating some (to me) bizarre behaviour.<br />[Note that the example contains no ==, just &gt; and &lt;. It's its absence that perceivedly 'causes empty() to fire'.]<br /><br />I was also pleasantly surprised to see PHP recurse. Also clear if you keep in mind that the example implies another function call to itself with &gt; and &lt; if both operands are arrays, but IMO definitely worth stating.<br /><br />It might also be worth noting that the order of array keys doesn't matter, even if a foreach() would see a 'different' array. Again, covered by the example, but might be worth stressing.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="86627">  <div class="votes">
    <div id="Vu86627">
    <a href="/manual/vote-note.php?id=86627&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86627">
    <a href="/manual/vote-note.php?id=86627&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86627" title="30% like this...">
    -8
    </div>
  </div>
  <a href="#86627" class="name">
  <strong class="user"><em>Hayley Watson</em></strong></a><a class="genanchor" href="#86627"> &para;</a><div class="date" title="2008-10-26 08:45"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86627">
<div class="phpcode"><code><span class="html">
The cast from null to boolean is documented (on the page describing the boolean type: null-&gt;false), and so is the cast from boolean to integer (on the page describing the integer type: false-&gt;0), but the cast from null to integer is undefined and the fact that it is currently implemented by casting from null to boolean and then from boolean to integer is explicitly documented (on the page describing the integer type) as something that should not be relied on (so null==0 is true only by accident, but ((int)(bool)null)==0 is true per specification).<br /><br />Perhaps as well as a "Converting to integer" section on the integer type page there should also be a "Converting from integer" section; similarly for the other types.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="72144">  <div class="votes">
    <div id="Vu72144">
    <a href="/manual/vote-note.php?id=72144&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd72144">
    <a href="/manual/vote-note.php?id=72144&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V72144" title="28% like this...">
    -6
    </div>
  </div>
  <a href="#72144" class="name"><strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#72144"> &para;</a><div class="date" title="2007-01-04 07:11"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom72144">
<div class="phpcode"><code><span class="html">
Since php 5.2 the operator == for object vs object is not recursion safe, it will cause a fatal error if one of the objects contains a refernce to it self (indirect refferences also counts here).<br />If you are just checking if two object pointers points to the same object use === instead and aviod this issue (you might get a minimal speed bost too).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="79205">  <div class="votes">
    <div id="Vu79205">
    <a href="/manual/vote-note.php?id=79205&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd79205">
    <a href="/manual/vote-note.php?id=79205&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V79205" title="29% like this...">
    -10
    </div>
  </div>
  <a href="#79205" class="name">
  <strong class="user"><em>ken at smallboxsoftware net</em></strong></a><a class="genanchor" href="#79205"> &para;</a><div class="date" title="2007-11-15 08:20"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom79205">
<div class="phpcode"><code><span class="html">
This seems a bit odd to me, but PHP can convert two strings into integers during comparison.&nbsp; For example: "700" == "+700" return true even though they are totally different strings. <br /><br />Use === or strcmp when comparing two strings to ensure that they remain as strings during comparison.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="47911">  <div class="votes">
    <div id="Vu47911">
    <a href="/manual/vote-note.php?id=47911&amp;page=language.operators.comparison&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd47911">
    <a href="/manual/vote-note.php?id=47911&amp;page=language.operators.comparison&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V47911" title="20% like this...">
    -12
    </div>
  </div>
  <a href="#47911" class="name">
  <strong class="user"><em>sven dot heyll at web dot de</em></strong></a><a class="genanchor" href="#47911"> &para;</a><div class="date" title="2004-12-05 01:19"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom47911">
<div class="phpcode"><code><span class="html">
Hi folks,<br />to the float comparison problem... <br /><br />This worked for me:<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">//! compare two floating point values, return true if they are equal <br />//! (enough) or false otherwise<br /></span><span class="keyword">function </span><span class="default">float_equal</span><span class="keyword">(</span><span class="default">$f1</span><span class="keyword">, </span><span class="default">$f2</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; return (</span><span class="default">$f1 </span><span class="keyword">&gt; </span><span class="default">$f2</span><span class="keyword">) ? (</span><span class="default">false</span><span class="keyword">) : (!(</span><span class="default">$f1 </span><span class="keyword">&lt; </span><span class="default">$f2</span><span class="keyword">));<br />}<br /><br /></span><span class="comment">// compare floats<br /></span><span class="default">$f1 </span><span class="keyword">= </span><span class="default">0.037</span><span class="keyword">;<br /></span><span class="default">$f2 </span><span class="keyword">= </span><span class="default">1000387.978</span><span class="keyword">;<br />echo </span><span class="string">"</span><span class="default">$f1</span><span class="string"> and </span><span class="default">$f2</span><span class="string"> are "</span><span class="keyword">.(</span><span class="default">float_equal</span><span class="keyword">(</span><span class="default">$f1</span><span class="keyword">,</span><span class="default">$f2</span><span class="keyword">)?(</span><span class="string">"equal"</span><span class="keyword">):(</span><span class="string">"not equal"</span><span class="keyword">)).</span><span class="string">"&lt;br /&gt;"</span><span class="keyword">;<br /></span><span class="default">$f1 </span><span class="keyword">= </span><span class="default">0.3</span><span class="keyword">;<br /></span><span class="default">$f2 </span><span class="keyword">= </span><span class="default">0.3</span><span class="keyword">;&nbsp; &nbsp; <br />echo </span><span class="string">"</span><span class="default">$f1</span><span class="string"> and </span><span class="default">$f2</span><span class="string"> are "</span><span class="keyword">.(</span><span class="default">float_equal</span><span class="keyword">(</span><span class="default">$f1</span><span class="keyword">,</span><span class="default">$f2</span><span class="keyword">)?(</span><span class="string">"equal"</span><span class="keyword">):(</span><span class="string">"not equal"</span><span class="keyword">)).</span><span class="string">"&lt;br /&gt;"</span><span class="keyword">;<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.operators.comparison&amp;redirect=http://php.net/manual/en/language.operators.comparison.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.operators.php">Operators</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.operators.precedence.php" title="Operator Precedence">Operator Precedence</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.arithmetic.php" title="Arithmetic Operators">Arithmetic Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.assignment.php" title="Assignment Operators">Assignment Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.bitwise.php" title="Bitwise Operators">Bitwise Operators</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.operators.comparison.php" title="Comparison Operators">Comparison Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.errorcontrol.php" title="Error Control Operators">Error Control Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.execution.php" title="Execution Operators">Execution Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.increment.php" title="Incrementing/Decrementing Operators">Incrementing/Decrementing Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.logical.php" title="Logical Operators">Logical Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.string.php" title="String Operators">String Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.array.php" title="Array Operators">Array Operators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.type.php" title="Type Operators">Type Operators</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

