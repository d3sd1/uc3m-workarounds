<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Spotting References - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.references.spot.php">
 <link rel="shorturl" href="http://php.net/references.spot">
 <link rel="alternate" href="http://php.net/references.spot" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.references.php">
 <link rel="prev" href="http://php.net/manual/en/language.references.unset.php">
 <link rel="next" href="http://php.net/manual/en/reserved.variables.php">

 <link rel="alternate" href="http://php.net/manual/en/language.references.spot.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.references.spot.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.references.spot.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.references.spot.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.references.spot.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.references.spot.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.references.spot.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.references.spot.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.references.spot.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.references.spot.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.references.spot.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="reserved.variables.php">
          Predefined Variables &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.references.unset.php">
          &laquo; Unsetting References        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.references.php'>References Explained</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.references.spot.php' selected="selected">English</option>
            <option value='pt_BR/language.references.spot.php'>Brazilian Portuguese</option>
            <option value='zh/language.references.spot.php'>Chinese (Simplified)</option>
            <option value='fr/language.references.spot.php'>French</option>
            <option value='de/language.references.spot.php'>German</option>
            <option value='ja/language.references.spot.php'>Japanese</option>
            <option value='ro/language.references.spot.php'>Romanian</option>
            <option value='ru/language.references.spot.php'>Russian</option>
            <option value='es/language.references.spot.php'>Spanish</option>
            <option value='tr/language.references.spot.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.references.spot.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.references.spot">Report a Bug</a>
    </div>
  </div><div id="language.references.spot" class="sect1">
   <h2 class="title">Spotting References</h2>
   <p class="simpara">
    Many syntax constructs in PHP are implemented via referencing
    mechanisms, so everything mentioned herein about reference binding also
    applies to these constructs. Some constructs, like passing and
    returning by reference, are mentioned above. Other constructs that
    use references are:
   </p>

   <div class="sect2" id="references.global">
    <h3 class="title">global References</h3>
    <p class="para">
     When you declare a variable as <strong class="command">global $var</strong> you
     are in fact creating reference to a global variable. That means,
     this is the same as:
     <div class="informalexample">
      <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$var&nbsp;</span><span style="color: #007700">=&amp;&nbsp;</span><span style="color: #0000BB">$GLOBALS</span><span style="color: #007700">[</span><span style="color: #DD0000">"var"</span><span style="color: #007700">];<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
      </div>

     </div>
    </p>
    <p class="simpara">
     This also means that unsetting <var class="varname"><var class="varname">$var</var></var>
     won&#039;t unset the global variable.
    </p>
   </div>

   <div class="sect2" id="references.this">
    <h3 class="title"><em>$this</em></h3>
    <p class="simpara">
     In an object method, <var class="varname"><var class="varname">$this</var></var> is always a reference
     to the caller object.
    </p>
   </div>
  </div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.references.spot&amp;redirect=http://php.net/manual/en/language.references.spot.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">8 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="72203">  <div class="votes">
    <div id="Vu72203">
    <a href="/manual/vote-note.php?id=72203&amp;page=language.references.spot&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd72203">
    <a href="/manual/vote-note.php?id=72203&amp;page=language.references.spot&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V72203" title="80% like this...">
    13
    </div>
  </div>
  <a href="#72203" class="name">
  <strong class="user"><em>BenBE at omorphia dot de</em></strong></a><a class="genanchor" href="#72203"> &para;</a><div class="date" title="2007-01-07 11:37"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom72203">
<div class="phpcode"><code><span class="html">
Hi,<br /><br />If you want to check if two variables are referencing each other (i.e. point to the same memory) you can use a function like this:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">same_type</span><span class="keyword">(&amp;</span><span class="default">$var1</span><span class="keyword">, &amp;</span><span class="default">$var2</span><span class="keyword">){<br />&nbsp; &nbsp; return </span><span class="default">gettype</span><span class="keyword">(</span><span class="default">$var1</span><span class="keyword">) === </span><span class="default">gettype</span><span class="keyword">(</span><span class="default">$var2</span><span class="keyword">);<br />}<br /><br />function </span><span class="default">is_ref</span><span class="keyword">(&amp;</span><span class="default">$var1</span><span class="keyword">, &amp;</span><span class="default">$var2</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="comment">//If a reference exists, the type IS the same<br />&nbsp; &nbsp; </span><span class="keyword">if(!</span><span class="default">same_type</span><span class="keyword">(</span><span class="default">$var1</span><span class="keyword">, </span><span class="default">$var2</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="default">$same </span><span class="keyword">= </span><span class="default">false</span><span class="keyword">;<br /><br />&nbsp; &nbsp; </span><span class="comment">//We now only need to ask for var1 to be an array ;-)<br />&nbsp; &nbsp; </span><span class="keyword">if(</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$var1</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//Look for an unused index in $var1<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">do {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$key </span><span class="keyword">= </span><span class="default">uniqid</span><span class="keyword">(</span><span class="string">"is_ref_"</span><span class="keyword">, </span><span class="default">true</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; } while(</span><span class="default">array_key_exists</span><span class="keyword">(</span><span class="default">$key</span><span class="keyword">, </span><span class="default">$var1</span><span class="keyword">));<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//The two variables differ in content ... They can't be the same<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">if(</span><span class="default">array_key_exists</span><span class="keyword">(</span><span class="default">$key</span><span class="keyword">, </span><span class="default">$var2</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//The arrays point to the same data if changes are reflected in $var2<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$data </span><span class="keyword">= </span><span class="default">uniqid</span><span class="keyword">(</span><span class="string">"is_ref_data_"</span><span class="keyword">, </span><span class="default">true</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$var1</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">] =&amp; </span><span class="default">$data</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//There seems to be a modification ...<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">if(</span><span class="default">array_key_exists</span><span class="keyword">(</span><span class="default">$key</span><span class="keyword">, </span><span class="default">$var2</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">$var2</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">] === </span><span class="default">$data</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$same </span><span class="keyword">= </span><span class="default">true</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//Undo our changes ...<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">unset(</span><span class="default">$var1</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">]);<br />&nbsp; &nbsp; } elseif(</span><span class="default">is_object</span><span class="keyword">(</span><span class="default">$var1</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//The same objects are required to have equal class names ;-)<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">if(</span><span class="default">get_class</span><span class="keyword">(</span><span class="default">$var1</span><span class="keyword">) !== </span><span class="default">get_class</span><span class="keyword">(</span><span class="default">$var2</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$obj1 </span><span class="keyword">= </span><span class="default">array_keys</span><span class="keyword">(</span><span class="default">get_object_vars</span><span class="keyword">(</span><span class="default">$var1</span><span class="keyword">));<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$obj2 </span><span class="keyword">= </span><span class="default">array_keys</span><span class="keyword">(</span><span class="default">get_object_vars</span><span class="keyword">(</span><span class="default">$var2</span><span class="keyword">));<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//Look for an unused index in $var1<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">do {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$key </span><span class="keyword">= </span><span class="default">uniqid</span><span class="keyword">(</span><span class="string">"is_ref_"</span><span class="keyword">, </span><span class="default">true</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; } while(</span><span class="default">in_array</span><span class="keyword">(</span><span class="default">$key</span><span class="keyword">, </span><span class="default">$obj1</span><span class="keyword">));<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//The two variables differ in content ... They can't be the same<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">if(</span><span class="default">in_array</span><span class="keyword">(</span><span class="default">$key</span><span class="keyword">, </span><span class="default">$obj2</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//The arrays point to the same data if changes are reflected in $var2<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$data </span><span class="keyword">= </span><span class="default">uniqid</span><span class="keyword">(</span><span class="string">"is_ref_data_"</span><span class="keyword">, </span><span class="default">true</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$var1</span><span class="keyword">-&gt;</span><span class="default">$key </span><span class="keyword">=&amp; </span><span class="default">$data</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//There seems to be a modification ...<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">if(isset(</span><span class="default">$var2</span><span class="keyword">-&gt;</span><span class="default">$key</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">$var2</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">] === </span><span class="default">$data</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$same </span><span class="keyword">= </span><span class="default">true</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//Undo our changes ...<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">unset(</span><span class="default">$var1</span><span class="keyword">-&gt;</span><span class="default">$key</span><span class="keyword">);<br />&nbsp; &nbsp; } elseif (</span><span class="default">is_resource</span><span class="keyword">(</span><span class="default">$var1</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">get_resource_type</span><span class="keyword">(</span><span class="default">$var1</span><span class="keyword">) !== </span><span class="default">get_resource_type</span><span class="keyword">(</span><span class="default">$var2</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; return ((string) </span><span class="default">$var1</span><span class="keyword">) === ((string) </span><span class="default">$var2</span><span class="keyword">);<br />&nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//Simple variables ...<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">if(</span><span class="default">$var1</span><span class="keyword">!==</span><span class="default">$var2</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//Data mismatch ... They can't be the same ...<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//To check for a reference of a variable with simple type<br />&nbsp; &nbsp; &nbsp; &nbsp; //simply store its old value and check against modifications of the second variable ;-)<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">do {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$key </span><span class="keyword">= </span><span class="default">uniqid</span><span class="keyword">(</span><span class="string">"is_ref_"</span><span class="keyword">, </span><span class="default">true</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; } while(</span><span class="default">$key </span><span class="keyword">=== </span><span class="default">$var1</span><span class="keyword">);<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$tmp </span><span class="keyword">= </span><span class="default">$var1</span><span class="keyword">; </span><span class="comment">//WE NEED A COPY HERE!!!<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$var1 </span><span class="keyword">= </span><span class="default">$key</span><span class="keyword">; </span><span class="comment">//Set var1 to the value of $key (copy)<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$same </span><span class="keyword">= </span><span class="default">$var1 </span><span class="keyword">=== </span><span class="default">$var2</span><span class="keyword">; </span><span class="comment">//Check if $var2 was modified too ...<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$var1 </span><span class="keyword">= </span><span class="default">$tmp</span><span class="keyword">; </span><span class="comment">//Undo our changes ...<br />&nbsp; &nbsp; </span><span class="keyword">}<br /><br />&nbsp; &nbsp; return </span><span class="default">$same</span><span class="keyword">;<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />Although this implementation is quite complete, it can't handle function references and some other minor stuff ATM.<br />This function is especially useful if you want to serialize a recursive array by hand.<br /><br />The usage is something like:<br /><span class="default">&lt;?php<br />$a </span><span class="keyword">= </span><span class="default">5</span><span class="keyword">;<br /></span><span class="default">$b </span><span class="keyword">= </span><span class="default">5</span><span class="keyword">;<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">is_ref</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">)); </span><span class="comment">//false<br /><br /></span><span class="default">$a </span><span class="keyword">= </span><span class="default">5</span><span class="keyword">;<br /></span><span class="default">$b </span><span class="keyword">= </span><span class="default">$a</span><span class="keyword">;<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">is_ref</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">)); </span><span class="comment">//false<br /><br /></span><span class="default">$a </span><span class="keyword">= </span><span class="default">5</span><span class="keyword">;<br /></span><span class="default">$b </span><span class="keyword">=&amp; </span><span class="default">$a</span><span class="keyword">;<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">is_ref</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">)); </span><span class="comment">//true<br /></span><span class="keyword">echo </span><span class="string">"---\n"</span><span class="keyword">;<br /><br /></span><span class="default">$a </span><span class="keyword">= array();<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">is_ref</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">, </span><span class="default">$a</span><span class="keyword">)); </span><span class="comment">//true<br /><br /></span><span class="default">$a</span><span class="keyword">[] =&amp; </span><span class="default">$a</span><span class="keyword">;<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">is_ref</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">, </span><span class="default">$a</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">])); </span><span class="comment">// true<br /></span><span class="keyword">echo </span><span class="string">"---\n"</span><span class="keyword">;<br /><br /></span><span class="default">$b </span><span class="keyword">= array(array());<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">is_ref</span><span class="keyword">(</span><span class="default">$b</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">)); </span><span class="comment">//true<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">is_ref</span><span class="keyword">(</span><span class="default">$b</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">])); </span><span class="comment">//false<br /></span><span class="keyword">echo </span><span class="string">"---\n"</span><span class="keyword">;<br /><br /></span><span class="default">$b </span><span class="keyword">= array();<br /></span><span class="default">$b</span><span class="keyword">[] = </span><span class="default">$b</span><span class="keyword">;<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">is_ref</span><span class="keyword">(</span><span class="default">$b</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">)); </span><span class="comment">//true<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">is_ref</span><span class="keyword">(</span><span class="default">$b</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">])); </span><span class="comment">//false<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">is_ref</span><span class="keyword">(</span><span class="default">$b</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">], </span><span class="default">$b</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">][</span><span class="default">0</span><span class="keyword">])); </span><span class="comment">//true*<br /></span><span class="keyword">echo </span><span class="string">"---\n"</span><span class="keyword">;<br /><br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">);<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$b</span><span class="keyword">);<br /><br /></span><span class="default">?&gt;<br /></span><br />* Please note the internal behaviour of PHP that seems to do the reference assignment BEFORE actually copying the variable!!! Thus you get an array containing a (different) recursive array for the last testcase, instead of an array containing an empty array as you could expect.<br /><br />BenBE.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="62405">  <div class="votes">
    <div id="Vu62405">
    <a href="/manual/vote-note.php?id=62405&amp;page=language.references.spot&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd62405">
    <a href="/manual/vote-note.php?id=62405&amp;page=language.references.spot&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V62405" title="75% like this...">
    2
    </div>
  </div>
  <a href="#62405" class="name">
  <strong class="user"><em>ludvig dot ericson at gmail dot com</em></strong></a><a class="genanchor" href="#62405"> &para;</a><div class="date" title="2006-02-27 03:36"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom62405">
<div class="phpcode"><code><span class="html">
For the sake of clarity:<br /><br />$this is a PSEUDO VARIABLE - thus not a real variable. ZE treats is in other ways then normal variables, and that means that some advanced variable-things won't work on it (for obvious reasons):<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Test </span><span class="keyword">{<br />&nbsp; &nbsp; var </span><span class="default">$monkeys </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">doFoobar</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$var </span><span class="keyword">= </span><span class="string">"this"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; $</span><span class="default">$var</span><span class="keyword">-&gt;</span><span class="default">monkeys</span><span class="keyword">++; </span><span class="comment">// Will fail on this line.<br />&nbsp; &nbsp; </span><span class="keyword">}<br />}<br /><br /></span><span class="default">$obj </span><span class="keyword">= new </span><span class="default">Test</span><span class="keyword">;<br /></span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">doFoobar</span><span class="keyword">(); </span><span class="comment">// Will fail in this call.<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">monkeys</span><span class="keyword">); </span><span class="comment">// Will return int(0) if it even reaches here.<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="61744">  <div class="votes">
    <div id="Vu61744">
    <a href="/manual/vote-note.php?id=61744&amp;page=language.references.spot&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd61744">
    <a href="/manual/vote-note.php?id=61744&amp;page=language.references.spot&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V61744" title="50% like this...">
    0
    </div>
  </div>
  <a href="#61744" class="name">
  <strong class="user"><em>ksamvel at gmail dot com</em></strong></a><a class="genanchor" href="#61744"> &para;</a><div class="date" title="2006-02-10 09:02"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom61744">
<div class="phpcode"><code><span class="html">
One may check reference to any object by simple operator==( object). Example:<br /><br /><span class="default">&lt;?php<br />&nbsp; </span><span class="keyword">class </span><span class="default">A </span><span class="keyword">{}<br /><br />&nbsp; </span><span class="default">$oA1 </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">();<br /><br />&nbsp; </span><span class="default">$roA </span><span class="keyword">= &amp; </span><span class="default">$oA1</span><span class="keyword">;<br /><br />&nbsp; echo </span><span class="string">"roA and oA1 are " </span><span class="keyword">. ( </span><span class="default">$roA </span><span class="keyword">== </span><span class="default">$oA1 </span><span class="keyword">? </span><span class="string">"same" </span><span class="keyword">: </span><span class="string">"not same"</span><span class="keyword">) . </span><span class="string">"&lt;br&gt;"</span><span class="keyword">;<br /><br />&nbsp; </span><span class="default">$oA2 </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">();<br />&nbsp; </span><span class="default">$roA </span><span class="keyword">= &amp; </span><span class="default">$roA2</span><span class="keyword">;<br /><br />&nbsp; echo </span><span class="string">"roA and oA1 are " </span><span class="keyword">. ( </span><span class="default">$roA </span><span class="keyword">== </span><span class="default">$oA1 </span><span class="keyword">? </span><span class="string">"same" </span><span class="keyword">: </span><span class="string">"not same"</span><span class="keyword">) . </span><span class="string">"&lt;br&gt;"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />Output:<br /><br />roA and oA1 are same<br />roA and oA1 are not same<br /><br />Current technique might be useful for caching in objects when inheritance is used and only base part of extended class should be copied (analog of C++: oB = oA):<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">A </span><span class="keyword">{ <br />&nbsp; </span><span class="comment">/* Any function changing state of A should set $bChanged to true */<br />&nbsp; </span><span class="keyword">public function </span><span class="default">isChanged</span><span class="keyword">() { return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">bChanged</span><span class="keyword">; }<br />&nbsp; private </span><span class="default">$bChanged</span><span class="keyword">;<br />&nbsp; </span><span class="comment">//...<br /></span><span class="keyword">}<br /><br />class </span><span class="default">B </span><span class="keyword">extends </span><span class="default">A </span><span class="keyword">{<br /></span><span class="comment">// ...<br />&nbsp; </span><span class="keyword">public function </span><span class="default">set</span><span class="keyword">( &amp;</span><span class="default">$roObj</span><span class="keyword">) {<br />&nbsp; &nbsp; if( </span><span class="default">$roObj </span><span class="keyword">instanceof </span><span class="default">A</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; if( </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">roAObj </span><span class="keyword">== </span><span class="default">$roObj </span><span class="keyword">&amp;&amp;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$roObj</span><span class="keyword">-&gt;</span><span class="default">isChanged</span><span class="keyword">()) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">/* Object was not changed do not need to copy A part of B */<br />&nbsp; &nbsp; &nbsp; </span><span class="keyword">} else {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">/* Copy A part of B */<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">roAObj </span><span class="keyword">= &amp;</span><span class="default">$roObj</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; }<br /><br />&nbsp; private </span><span class="default">$roAObj</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="55689">  <div class="votes">
    <div id="Vu55689">
    <a href="/manual/vote-note.php?id=55689&amp;page=language.references.spot&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd55689">
    <a href="/manual/vote-note.php?id=55689&amp;page=language.references.spot&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V55689" title="50% like this...">
    0
    </div>
  </div>
  <a href="#55689" class="name">
  <strong class="user"><em>Sergio Santana: ssantana at tlaloc dot imta dot mx</em></strong></a><a class="genanchor" href="#55689"> &para;</a><div class="date" title="2005-08-10 09:30"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom55689">
<div class="phpcode"><code><span class="html">
Sometimes an object's method returning a reference to itself is required. Here is a way to code it:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">MyClass </span><span class="keyword">{<br />&nbsp; public </span><span class="default">$datum</span><span class="keyword">;<br />&nbsp; public </span><span class="default">$other</span><span class="keyword">;<br />&nbsp; <br />&nbsp; function &amp;</span><span class="default">MyRef</span><span class="keyword">(</span><span class="default">$d</span><span class="keyword">) { </span><span class="comment">// the method<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">datum </span><span class="keyword">= </span><span class="default">$d</span><span class="keyword">;<br />&nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">; </span><span class="comment">// returns the reference<br />&nbsp; </span><span class="keyword">}<br />}<br /><br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">MyClass</span><span class="keyword">;<br /></span><span class="default">$b </span><span class="keyword">= </span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">MyRef</span><span class="keyword">(</span><span class="default">25</span><span class="keyword">); </span><span class="comment">// creates the reference<br /><br /></span><span class="keyword">echo </span><span class="string">"This is object \$a: \n"</span><span class="keyword">;<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">);<br />echo </span><span class="string">"This is object \$b: \n"</span><span class="keyword">;<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$b</span><span class="keyword">);<br /><br /></span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">other </span><span class="keyword">= </span><span class="default">50</span><span class="keyword">;<br /><br />echo </span><span class="string">"This is object \$a, modified" </span><span class="keyword">.<br />&nbsp; &nbsp;&nbsp; </span><span class="string">" indirectly by modifying ref \$b: \n"</span><span class="keyword">;<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />This code outputs:<br />This is object $a:<br />MyClass Object<br />(<br />&nbsp; &nbsp; [datum] =&gt; 25<br />&nbsp; &nbsp; [other] =&gt;<br />)<br />This is object $b:<br />MyClass Object<br />(<br />&nbsp; &nbsp; [datum] =&gt; 25<br />&nbsp; &nbsp; [other] =&gt;<br />)<br />This is object $a, modified indirectly by modifying ref $b:<br />MyClass Object<br />(<br />&nbsp; &nbsp; [datum] =&gt; 25<br />&nbsp; &nbsp; [other] =&gt; 50<br />)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="103660">  <div class="votes">
    <div id="Vu103660">
    <a href="/manual/vote-note.php?id=103660&amp;page=language.references.spot&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd103660">
    <a href="/manual/vote-note.php?id=103660&amp;page=language.references.spot&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V103660" title="37% like this...">
    -2
    </div>
  </div>
  <a href="#103660" class="name">
  <strong class="user"><em>Abimael Rodrguez Coln</em></strong></a><a class="genanchor" href="#103660"> &para;</a><div class="date" title="2011-04-26 11:55"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom103660">
<div class="phpcode"><code><span class="html">
This is one way to check if is a reference<br /><span class="default">&lt;?php<br />$a </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br /></span><span class="default">$b </span><span class="keyword">=&amp; </span><span class="default">$a</span><span class="keyword">;<br /></span><span class="default">$c </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">;<br /></span><span class="default">$d </span><span class="keyword">= </span><span class="default">3</span><span class="keyword">;<br /></span><span class="default">$e </span><span class="keyword">= array(</span><span class="default">$a</span><span class="keyword">);<br />function </span><span class="default">is_reference</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">){<br />&nbsp; &nbsp; </span><span class="default">$val </span><span class="keyword">= </span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="default">$var</span><span class="keyword">];<br />&nbsp; &nbsp; </span><span class="default">$tmpArray </span><span class="keyword">= array();<br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Add keys/values without reference<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">foreach(</span><span class="default">$GLOBALS </span><span class="keyword">as </span><span class="default">$k </span><span class="keyword">=&gt; </span><span class="default">$v</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; if(!</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$v</span><span class="keyword">)){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$tmpArray</span><span class="keyword">[</span><span class="default">$k</span><span class="keyword">] = </span><span class="default">$v</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Change value of rest variables<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">foreach(</span><span class="default">$GLOBALS </span><span class="keyword">as </span><span class="default">$k </span><span class="keyword">=&gt; </span><span class="default">$v</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">$k </span><span class="keyword">!= </span><span class="string">'GLOBALS'<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">&amp;&amp; </span><span class="default">$k </span><span class="keyword">!= </span><span class="string">'_POST'<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">&amp;&amp; </span><span class="default">$k </span><span class="keyword">!= </span><span class="string">'_GET'<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">&amp;&amp; </span><span class="default">$k </span><span class="keyword">!= </span><span class="string">'_COOKIE'<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">&amp;&amp; </span><span class="default">$k </span><span class="keyword">!= </span><span class="string">'_FILES'<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">&amp;&amp; </span><span class="default">$k </span><span class="keyword">!= </span><span class="default">$var<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">&amp;&amp; !</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$v</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; ){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">usleep</span><span class="keyword">(</span><span class="default">1</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="default">$k</span><span class="keyword">] = </span><span class="default">md5</span><span class="keyword">(</span><span class="default">microtime</span><span class="keyword">());<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="default">$bool </span><span class="keyword">= </span><span class="default">$val </span><span class="keyword">!= </span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="default">$var</span><span class="keyword">];<br /><br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Restore defaults values<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">foreach(</span><span class="default">$tmpArray </span><span class="keyword">as </span><span class="default">$k </span><span class="keyword">=&gt; </span><span class="default">$v</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="default">$k</span><span class="keyword">] = </span><span class="default">$v</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; return </span><span class="default">$bool</span><span class="keyword">;<br />}<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">is_reference</span><span class="keyword">(</span><span class="string">'a'</span><span class="keyword">));<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">is_reference</span><span class="keyword">(</span><span class="string">'b'</span><span class="keyword">));<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">is_reference</span><span class="keyword">(</span><span class="string">'c'</span><span class="keyword">));<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">is_reference</span><span class="keyword">(</span><span class="string">'d'</span><span class="keyword">));<br /></span><span class="default">?&gt;<br /></span><br />This won't check if reference is inside a array.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="59820">  <div class="votes">
    <div id="Vu59820">
    <a href="/manual/vote-note.php?id=59820&amp;page=language.references.spot&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd59820">
    <a href="/manual/vote-note.php?id=59820&amp;page=language.references.spot&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V59820" title="33% like this...">
    -1
    </div>
  </div>
  <a href="#59820" class="name">
  <strong class="user"><em>Sergio Santana: ssantana at tlaloc dot imta dot mx</em></strong></a><a class="genanchor" href="#59820"> &para;</a><div class="date" title="2005-12-16 08:41"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom59820">
<div class="phpcode"><code><span class="html">
*** WARNING about OBJECTS TRICKY REFERENCES ***<br />-----------------------------------------------<br />The use of references in the context of classes<br />and objects, though well defined in the documentation,<br />is somehow tricky, so one must be very careful when<br />using objects. Let's examine the following two<br />examples:<br /><br /><span class="default">&lt;?php<br />&nbsp; </span><span class="keyword">class </span><span class="default">y </span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$d</span><span class="keyword">;<br />&nbsp; }<br />&nbsp; <br />&nbsp; </span><span class="default">$A </span><span class="keyword">= new </span><span class="default">y</span><span class="keyword">;<br />&nbsp; </span><span class="default">$A</span><span class="keyword">-&gt;</span><span class="default">d </span><span class="keyword">= </span><span class="default">18</span><span class="keyword">;<br />&nbsp; echo </span><span class="string">"Object \$A before operation:\n"</span><span class="keyword">;<br />&nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$A</span><span class="keyword">);<br />&nbsp; <br />&nbsp; </span><span class="default">$B </span><span class="keyword">= </span><span class="default">$A</span><span class="keyword">; </span><span class="comment">// This is not an explicit (=&amp;) reference assignment,<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; // however, $A and $B refer to the same instance <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; // though they are not equivalent names<br />&nbsp; </span><span class="default">$C </span><span class="keyword">=&amp; </span><span class="default">$A</span><span class="keyword">; </span><span class="comment">// Explicit reference assignment, $A and $C refer to <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; // the same instance and they have become equivalent<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; // names of the same instance<br />&nbsp; <br />&nbsp; </span><span class="default">$B</span><span class="keyword">-&gt;</span><span class="default">d </span><span class="keyword">= </span><span class="default">1234</span><span class="keyword">;<br /> <br />&nbsp; echo </span><span class="string">"\nObject \$B after operation:\n"</span><span class="keyword">;<br />&nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$B</span><span class="keyword">);<br />&nbsp; echo </span><span class="string">"\nObject \$A implicitly modified after operation:\n"</span><span class="keyword">;<br />&nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$A</span><span class="keyword">); <br />&nbsp; echo </span><span class="string">"\nObject \$C implicitly modified after operation:\n"</span><span class="keyword">;<br />&nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$C</span><span class="keyword">); <br />&nbsp; <br />&nbsp; </span><span class="comment">// Let's make $A refer to another instance<br />&nbsp; </span><span class="default">$A </span><span class="keyword">= new </span><span class="default">y</span><span class="keyword">;<br />&nbsp; </span><span class="default">$A</span><span class="keyword">-&gt;</span><span class="default">d </span><span class="keyword">= </span><span class="default">25200</span><span class="keyword">;<br />&nbsp; echo </span><span class="string">"\nObject \$B after \$A modification:\n"</span><span class="keyword">;<br />&nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$B</span><span class="keyword">); </span><span class="comment">// $B doesn't change<br />&nbsp; </span><span class="keyword">echo </span><span class="string">"\nObject \$A after \$A modification:\n"</span><span class="keyword">;<br />&nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$A</span><span class="keyword">); <br />&nbsp; echo </span><span class="string">"\nObject \$C implicitly modified after \$A modification:\n"</span><span class="keyword">;<br />&nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$C</span><span class="keyword">); </span><span class="comment">// $C changes as $A changes<br /></span><span class="default">?&gt;<br /></span><br />Thus, note the difference between assignments $X = $Y and $X =&amp; $Y.<br />When $Y is anything but an object instance, the first assignment means<br />that $X will hold an independent copy of $Y, and the second, means that<br />$X and $Y will refer to the same thing, so they are tight together until <br />either $X or $Y is forced to refer to another thing. However, when $Y <br />happens to be an object instance, the semantic of $X = $Y changes and <br />becomes only slightly different to that of $X =&amp; $Y, since in both<br />cases $X and $Y become references to the same object. See what this<br />example outputs:<br /><br />Object $A before operation:<br />object(y)#1 (1) {<br />&nbsp; ["d"]=&gt;<br />&nbsp; int(18)<br />}<br /><br />Object $B after operation:<br />object(y)#1 (1) {<br />&nbsp; ["d"]=&gt;<br />&nbsp; int(1234)<br />}<br /><br />Object $A implicitly modified after operation:<br />object(y)#1 (1) {<br />&nbsp; ["d"]=&gt;<br />&nbsp; int(1234)<br />}<br /><br />Object $C implicitly modified after operation:<br />object(y)#1 (1) {<br />&nbsp; ["d"]=&gt;<br />&nbsp; int(1234)<br />}<br /><br />Object $B after $A modification:<br />object(y)#1 (1) {<br />&nbsp; ["d"]=&gt;<br />&nbsp; int(1234)<br />}<br /><br />Object $A after $A modification:<br />object(y)#2 (1) {<br />&nbsp; ["d"]=&gt;<br />&nbsp; int(25200)<br />}<br /><br />Object $C implicitly modified after $A modification:<br />object(y)#2 (1) {<br />&nbsp; ["d"]=&gt;<br />&nbsp; int(25200)<br />}<br /><br />Let's review a SECOND EXAMPLE:<br /><span class="default">&lt;?php<br />&nbsp; </span><span class="keyword">class </span><span class="default">yy </span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$d</span><span class="keyword">;<br />&nbsp; &nbsp; function </span><span class="default">yy</span><span class="keyword">(</span><span class="default">$x</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">d </span><span class="keyword">= </span><span class="default">$x</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; }<br /><br />&nbsp; function </span><span class="default">modify</span><span class="keyword">(</span><span class="default">$v</span><span class="keyword">)<br />&nbsp; {<br />&nbsp; &nbsp;&nbsp; </span><span class="default">$v</span><span class="keyword">-&gt;</span><span class="default">d </span><span class="keyword">= </span><span class="default">1225</span><span class="keyword">;<br />&nbsp; }<br /><br />&nbsp; </span><span class="default">$A </span><span class="keyword">= new </span><span class="default">yy</span><span class="keyword">(</span><span class="default">3</span><span class="keyword">);<br />&nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$A</span><span class="keyword">); <br />&nbsp; </span><span class="default">modify</span><span class="keyword">(</span><span class="default">$A</span><span class="keyword">);<br />&nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$A</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />Although, in general, a formal argument declared <br />as $v in the function 'modify' shown above, implies<br />that the actual argument $A, passed when calling <br />the function, is not modified, this is not the <br />case when $A is an object instance. See what the<br />example code outputs when executed:<br /><br />object(yy)#3 (1) {<br />&nbsp; ["d"]=&gt;<br />&nbsp; int(3)<br />}<br />object(yy)#3 (1) {<br />&nbsp; ["d"]=&gt;<br />&nbsp; int(1225)<br />}</span>
</code></div>
  </div>
 </div>
  <div class="note" id="105203">  <div class="votes">
    <div id="Vu105203">
    <a href="/manual/vote-note.php?id=105203&amp;page=language.references.spot&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd105203">
    <a href="/manual/vote-note.php?id=105203&amp;page=language.references.spot&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V105203" title="33% like this...">
    -2
    </div>
  </div>
  <a href="#105203" class="name">
  <strong class="user"><em>CodeWorX.ch</em></strong></a><a class="genanchor" href="#105203"> &para;</a><div class="date" title="2011-08-02 01:38"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom105203">
<div class="phpcode"><code><span class="html">
here is an unconventional (and not very fast) way of detecting references within arrays:<br /><br /><span class="default">&lt;?php<br /><br />&nbsp; &nbsp; </span><span class="keyword">function </span><span class="default">is_array_reference </span><span class="keyword">(</span><span class="default">$arr</span><span class="keyword">, </span><span class="default">$key</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$isRef </span><span class="keyword">= </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">ob_start</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$arr</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">strpos</span><span class="keyword">(</span><span class="default">preg_replace</span><span class="keyword">(</span><span class="string">"/[ \n\r]*/i"</span><span class="keyword">, </span><span class="string">""</span><span class="keyword">, </span><span class="default">preg_replace</span><span class="keyword">(</span><span class="string">"/( ){4,}.*(\n\r)*/i"</span><span class="keyword">, </span><span class="string">""</span><span class="keyword">, </span><span class="default">ob_get_contents</span><span class="keyword">())), </span><span class="string">"[" </span><span class="keyword">. </span><span class="default">$key </span><span class="keyword">. </span><span class="string">"]=&gt;&amp;"</span><span class="keyword">) !== </span><span class="default">false</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$isRef </span><span class="keyword">= </span><span class="default">true</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">ob_end_clean</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$isRef</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114047">  <div class="votes">
    <div id="Vu114047">
    <a href="/manual/vote-note.php?id=114047&amp;page=language.references.spot&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114047">
    <a href="/manual/vote-note.php?id=114047&amp;page=language.references.spot&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114047" title="20% like this...">
    -3
    </div>
  </div>
  <a href="#114047" class="name">
  <strong class="user"><em>lutondatta at gmail dot com</em></strong></a><a class="genanchor" href="#114047"> &para;</a><div class="date" title="2014-01-06 03:12"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114047">
<div class="phpcode"><code><span class="html">
This is very useful in passing large arrays. If you do not pass the array by reference, you are creating another copy of the array in memory. <br /><span class="default">&lt;?php<br /></span><span class="comment">//Part 1<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$x </span><span class="keyword">= </span><span class="default">40</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$y </span><span class="keyword">= </span><span class="default">$x</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$z </span><span class="keyword">=&amp; </span><span class="default">$x</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'$x is ' </span><span class="keyword">. </span><span class="default">$x </span><span class="keyword">. </span><span class="string">'&lt;br /&gt;'</span><span class="keyword">; </span><span class="comment">//Show 40<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">echo </span><span class="string">'$y is ' </span><span class="keyword">. </span><span class="default">$y </span><span class="keyword">. </span><span class="string">'&lt;br /&gt;'</span><span class="keyword">; </span><span class="comment">//Show 40<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">echo </span><span class="string">'$z is ' </span><span class="keyword">. </span><span class="default">$z </span><span class="keyword">. </span><span class="string">'&lt;br /&gt;'</span><span class="keyword">; </span><span class="comment">//Show 40<br />//Part 2<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$x </span><span class="keyword">= </span><span class="default">50</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'$x is ' </span><span class="keyword">. </span><span class="default">$x </span><span class="keyword">. </span><span class="string">'&lt;br /&gt;'</span><span class="keyword">; </span><span class="comment">//Show 50<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">echo </span><span class="string">'$y is ' </span><span class="keyword">. </span><span class="default">$y </span><span class="keyword">. </span><span class="string">'&lt;br /&gt;'</span><span class="keyword">; </span><span class="comment">//Show 40<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">echo </span><span class="string">'$z is ' </span><span class="keyword">. </span><span class="default">$z </span><span class="keyword">. </span><span class="string">'&lt;br /&gt;'</span><span class="keyword">; </span><span class="comment">//Show 50<br /></span><span class="default">?&gt;<br /></span>In part 2 value of $z will changes according to $x.</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.references.spot&amp;redirect=http://php.net/manual/en/language.references.spot.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.references.php">References Explained</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.references.whatare.php" title="What References Are">What References Are</a>
                        </li>
                          
                        <li class="">
                            <a href="language.references.whatdo.php" title="What References Do">What References Do</a>
                        </li>
                          
                        <li class="">
                            <a href="language.references.arent.php" title="What References Are Not">What References Are Not</a>
                        </li>
                          
                        <li class="">
                            <a href="language.references.pass.php" title="Passing by Reference">Passing by Reference</a>
                        </li>
                          
                        <li class="">
                            <a href="language.references.return.php" title="Returning References">Returning References</a>
                        </li>
                          
                        <li class="">
                            <a href="language.references.unset.php" title="Unsetting References">Unsetting References</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.references.spot.php" title="Spotting References">Spotting References</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

