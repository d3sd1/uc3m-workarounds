<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="tr">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Sabitler - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/tr/language.constants.php">
 <link rel="shorturl" href="http://php.net/constants">
 <link rel="alternate" href="http://php.net/constants" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/tr/index.php">
 <link rel="index" href="http://php.net/manual/tr/langref.php">
 <link rel="prev" href="http://php.net/manual/tr/language.variables.external.php">
 <link rel="next" href="http://php.net/manual/tr/language.constants.syntax.php">

 <link rel="alternate" href="http://php.net/manual/en/language.constants.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.constants.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.constants.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.constants.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.constants.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.constants.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.constants.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.constants.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.constants.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.constants.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/tr/language.constants.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.constants.syntax.php">
          S&ouml;z dizimi &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.variables.external.php">
          &laquo; Dış Kaynaklı Değişkenler        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Kılavuzu</a></li>      <li><a href='langref.php'>Dil Başvuru Kılavuzu</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.constants.php'>English</option>
            <option value='pt_BR/language.constants.php'>Brazilian Portuguese</option>
            <option value='zh/language.constants.php'>Chinese (Simplified)</option>
            <option value='fr/language.constants.php'>French</option>
            <option value='de/language.constants.php'>German</option>
            <option value='ja/language.constants.php'>Japanese</option>
            <option value='ro/language.constants.php'>Romanian</option>
            <option value='ru/language.constants.php'>Russian</option>
            <option value='es/language.constants.php'>Spanish</option>
            <option value='tr/language.constants.php' selected="selected">Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=tr/language.constants.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.constants">Report a Bug</a>
    </div>
  </div><div id="language.constants" class="chapter">
  <h1>Sabitler</h1>
<h2>İçindekiler</h2><ul class="chunklist chunklist_chapter"><li><a href="language.constants.syntax.php">S&ouml;z dizimi</a></li><li><a href="language.constants.predefined.php">Sihirli Sabitler</a></li></ul>


  <p class="simpara">
    Bir sabit basit bir değerin betimleyicisidir (ismidir). İsminden de
    anlaşılacağı gibi, betiğin çalışması sırasında bu değer değiştirilemez
    (aslında birer sabit olmayan <a href="language.constants.predefined.php" class="link">sihirli sabitler</a>
    hariç). Sabitler öntanımlı olarak büyük-küçük harf duyarlıdır.
    Geleneksel olarak, sabit isimleri daima büyük harfle yazılır.
  </p>
  <p class="para">
    Bir sabite verilen isim PHP&#039;de varolan diğer tüm isimlerle aynı
    kurallara tabidir. Geçerli bir sabit ismi bir harfle ya da alt çizgi imi
    ile başlar, herhangi bir sayıda harf, rakam ya da alt çizgi ile
    devam eder. Bir sabit ismi düzenli ifade olarak, şu şekilde ifade
    edilebilir: <em>[a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*</em>
  </p>
    <div class="tip"><strong class="tip">İpucu</strong>
<p class="simpara">Ayrıca <a href="userlandnaming.php" class="xref">Kullanıcı Alanı İsimlendirme Kılavuzu</a> belgesine de bakınız.
</p></div>
  <p class="para">
   <div class="example" id="example-95">
    <p><strong>Örnek 1  - Geçerli ve geçersiz sabit isimleri</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /><br /></span><span style="color: #FF8000">//&nbsp;Geçerli&nbsp;sabit&nbsp;isimleri<br /></span><span style="color: #0000BB">define</span><span style="color: #007700">(</span><span style="color: #DD0000">"FOO"</span><span style="color: #007700">,&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"bir&nbsp;şey"</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">define</span><span style="color: #007700">(</span><span style="color: #DD0000">"FOO2"</span><span style="color: #007700">,&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"başka&nbsp;bir&nbsp;şey"</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">define</span><span style="color: #007700">(</span><span style="color: #DD0000">"FOO_BAR"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"daha&nbsp;başka&nbsp;bir&nbsp;şey"</span><span style="color: #007700">);<br /><br /></span><span style="color: #FF8000">//&nbsp;Geçersiz&nbsp;sabit&nbsp;isimleri<br /></span><span style="color: #0000BB">define</span><span style="color: #007700">(</span><span style="color: #DD0000">"2FOO"</span><span style="color: #007700">,&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"bir&nbsp;şey"</span><span style="color: #007700">);<br /><br /></span><span style="color: #FF8000">//&nbsp;Bu&nbsp;geçerli&nbsp;olmasına&nbsp;rağmen&nbsp;kullanmaktan&nbsp;kaçınılmalıdır.<br />//&nbsp;PHP&nbsp;bir&nbsp;gün&nbsp;betiğinizin&nbsp;çalışmasını&nbsp;bozacak&nbsp;bir&nbsp;sihirli<br />//&nbsp;sabit&nbsp;kullanmaya&nbsp;karar&nbsp;verebilir.<br /></span><span style="color: #0000BB">define</span><span style="color: #007700">(</span><span style="color: #DD0000">"__FOO__"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"bir&nbsp;şey"</span><span style="color: #007700">);<br /><br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
  </p>
  <blockquote class="note"><p><strong class="note">Bilginize</strong>: 
   <span class="simpara">
    Burada bir harften söz ettiğimiz zaman, ASCII a-Z veya A-Z arasındaki ki
    bir karakterden veya karakter kodu 127-255 (<em>0x7f-0xff</em>)
    arasındaki bir karakterden bahsetmiş oluyoruz.
   </span>
  </p></blockquote>

  <p class="simpara">
    Süper küresellerde olduğu gibi, sabitlerin etki alanı da betiklerin
    genelidir. &quot;Etki alanı&quot; hakkında daha ayrıntılı bilgi edinmek için <a href="language.variables.scope.php" class="link">Değişken Etki Alanı</a>
    bölümünü okuyunuz.
  </p>

  

  
 </div>

<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.constants&amp;redirect=http://php.net/manual/tr/language.constants.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">11 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="108717">  <div class="votes">
    <div id="Vu108717">
    <a href="/manual/vote-note.php?id=108717&amp;page=language.constants&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd108717">
    <a href="/manual/vote-note.php?id=108717&amp;page=language.constants&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V108717" title="70% like this...">
    157
    </div>
  </div>
  <a href="#108717" class="name">
  <strong class="user"><em>wbcarts at juno dot com</em></strong></a><a class="genanchor" href="#108717"> &para;</a><div class="date" title="2012-05-20 03:04"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom108717">
<div class="phpcode"><code><span class="html">
11/14/2016 - note updated by sobak<br />-----<br /><br />CONSTANTS and PHP Class Definitions<br /><br />Using "define('MY_VAR', 'default value')" INSIDE a class definition does not work as expected. You have to use the PHP keyword 'const' and initialize it with a scalar value -- boolean, int, float, string (or array in PHP 5.6+) -- right away.<br /><br /><span class="default">&lt;?php<br /><br />define</span><span class="keyword">(</span><span class="string">'MIN_VALUE'</span><span class="keyword">, </span><span class="string">'0.0'</span><span class="keyword">);&nbsp;&nbsp; </span><span class="comment">// RIGHT - Works OUTSIDE of a class definition.<br /></span><span class="default">define</span><span class="keyword">(</span><span class="string">'MAX_VALUE'</span><span class="keyword">, </span><span class="string">'1.0'</span><span class="keyword">);&nbsp;&nbsp; </span><span class="comment">// RIGHT - Works OUTSIDE of a class definition.<br /><br />//const MIN_VALUE = 0.0;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; RIGHT - Works both INSIDE and OUTSIDE of a class definition.<br />//const MAX_VALUE = 1.0;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; RIGHT - Works both INSIDE and OUTSIDE of a class definition.<br /><br /></span><span class="keyword">class </span><span class="default">Constants<br /></span><span class="keyword">{<br />&nbsp; </span><span class="comment">//define('MIN_VALUE', '0.0');&nbsp; WRONG - Works OUTSIDE of a class definition.<br />&nbsp; //define('MAX_VALUE', '1.0');&nbsp; WRONG - Works OUTSIDE of a class definition.<br /><br />&nbsp; </span><span class="keyword">const </span><span class="default">MIN_VALUE </span><span class="keyword">= </span><span class="default">0.0</span><span class="keyword">;&nbsp; &nbsp; &nbsp; </span><span class="comment">// RIGHT - Works INSIDE of a class definition.<br />&nbsp; </span><span class="keyword">const </span><span class="default">MAX_VALUE </span><span class="keyword">= </span><span class="default">1.0</span><span class="keyword">;&nbsp; &nbsp; &nbsp; </span><span class="comment">// RIGHT - Works INSIDE of a class definition.<br /><br />&nbsp; </span><span class="keyword">public static function </span><span class="default">getMinValue</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; return </span><span class="default">self</span><span class="keyword">::</span><span class="default">MIN_VALUE</span><span class="keyword">;<br />&nbsp; }<br /><br />&nbsp; public static function </span><span class="default">getMaxValue</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; return </span><span class="default">self</span><span class="keyword">::</span><span class="default">MAX_VALUE</span><span class="keyword">;<br />&nbsp; }<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />#Example 1:<br />You can access these constants DIRECTLY like so:<br /> * type the class name exactly.<br /> * type two (2) colons.<br /> * type the const name exactly.<br /><br />#Example 2:<br />Because our class definition provides two (2) static functions, you can also access them like so:<br /> * type the class name exactly.<br /> * type two (2) colons.<br /> * type the function name exactly (with the parentheses).<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="comment">#Example 1:<br /></span><span class="default">$min </span><span class="keyword">= </span><span class="default">Constants</span><span class="keyword">::</span><span class="default">MIN_VALUE</span><span class="keyword">;<br /></span><span class="default">$max </span><span class="keyword">= </span><span class="default">Constants</span><span class="keyword">::</span><span class="default">MAX_VALUE</span><span class="keyword">;<br /><br /></span><span class="comment">#Example 2:<br /></span><span class="default">$min </span><span class="keyword">= </span><span class="default">Constants</span><span class="keyword">::</span><span class="default">getMinValue</span><span class="keyword">();<br /></span><span class="default">$max </span><span class="keyword">= </span><span class="default">Constants</span><span class="keyword">::</span><span class="default">getMaxValue</span><span class="keyword">();<br /><br /></span><span class="default">?&gt;<br /></span><br />Once class constants are declared AND initialized, they cannot be set to different values -- that is why there are no setMinValue() and setMaxValue() functions in the class definition -- which means they are READ-ONLY and STATIC (shared by all instances of the class).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116749">  <div class="votes">
    <div id="Vu116749">
    <a href="/manual/vote-note.php?id=116749&amp;page=language.constants&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116749">
    <a href="/manual/vote-note.php?id=116749&amp;page=language.constants&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116749" title="60% like this...">
    10
    </div>
  </div>
  <a href="#116749" class="name">
  <strong class="user"><em>Raheel Khan</em></strong></a><a class="genanchor" href="#116749"> &para;</a><div class="date" title="2015-02-22 08:39"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom116749">
<div class="phpcode"><code><span class="html">
class constant are by default public in nature but they cannot be assigned visibility factor and in turn gives syntax error<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">constants </span><span class="keyword">{<br /><br />&nbsp; &nbsp; const </span><span class="default">MAX_VALUE </span><span class="keyword">= </span><span class="default">10</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; public const </span><span class="default">MIN_VALUE </span><span class="keyword">=</span><span class="default">1</span><span class="keyword">;<br /><br />}<br /><br /></span><span class="comment">// This will work<br /></span><span class="keyword">echo </span><span class="default">constants</span><span class="keyword">::</span><span class="default">MAX_VALUE</span><span class="keyword">;<br /><br /></span><span class="comment">// This will return syntax error <br /></span><span class="keyword">echo </span><span class="default">constants</span><span class="keyword">::</span><span class="default">MIN_VALUE</span><span class="keyword">; <br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="19363">  <div class="votes">
    <div id="Vu19363">
    <a href="/manual/vote-note.php?id=19363&amp;page=language.constants&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd19363">
    <a href="/manual/vote-note.php?id=19363&amp;page=language.constants&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V19363" title="59% like this...">
    15
    </div>
  </div>
  <a href="#19363" class="name">
  <strong class="user"><em>katana at katana-inc dot com</em></strong></a><a class="genanchor" href="#19363"> &para;</a><div class="date" title="2002-02-25 11:53"><strong>15 years ago</strong></div>
  <div class="text" id="Hcom19363">
<div class="phpcode"><code><span class="html">
Warning, constants used within the heredoc syntax (<a href="http://www.php.net/manual/en/language.types.string.php" rel="nofollow" target="_blank">http://www.php.net/manual/en/language.types.string.php</a>) are not interpreted!<br /><br />Editor's Note: This is true. PHP has no way of recognizing the constant from any other string of characters within the heredoc block.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118671">  <div class="votes">
    <div id="Vu118671">
    <a href="/manual/vote-note.php?id=118671&amp;page=language.constants&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118671">
    <a href="/manual/vote-note.php?id=118671&amp;page=language.constants&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118671" title="58% like this...">
    6
    </div>
  </div>
  <a href="#118671" class="name">
  <strong class="user"><em>gried at NOSPAM dot nsys dot by</em></strong></a><a class="genanchor" href="#118671"> &para;</a><div class="date" title="2016-01-17 07:12"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom118671">
<div class="phpcode"><code><span class="html">
Lets expand comment of 'storm' about usage of undefined constants. His claim that 'An undefined constant evaluates as true...' is wrong and right at same time. As said further in documentation ' If you use an undefined constant, PHP assumes that you mean the name of the constant itself, just as if you called it as a string...'. So yeah, undefined global constant when accessed directly will be resolved as string equal to name of sought constant (as thought PHP supposes that programmer had forgot apostrophes and autofixes it) and non-zero non-empty string converts to True.<br /><br />There are two ways to prevent this:<br />1. always use function constant('CONST_NAME') to get constant value (BTW it also works for class constants - constant('CLASS_NAME::CONST_NAME') );<br />2. use only class constants (that are defined inside of class using keyword const) because they are not converted to string when not found but throw exception instead (Fatal error: Undefined class constant).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="52008">  <div class="votes">
    <div id="Vu52008">
    <a href="/manual/vote-note.php?id=52008&amp;page=language.constants&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd52008">
    <a href="/manual/vote-note.php?id=52008&amp;page=language.constants&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V52008" title="56% like this...">
    20
    </div>
  </div>
  <a href="#52008" class="name">
  <strong class="user"><em>storm</em></strong></a><a class="genanchor" href="#52008"> &para;</a><div class="date" title="2005-04-18 09:54"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom52008">
<div class="phpcode"><code><span class="html">
An undefined constant evaluates as true when not used correctly. Say for example you had something like this:<br /><br />settings.php<br /><span class="default">&lt;?php<br /></span><span class="comment">// Debug mode<br /></span><span class="default">define</span><span class="keyword">(</span><span class="string">'DEBUG'</span><span class="keyword">,</span><span class="default">false</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />test.php<br /><span class="default">&lt;?php<br /></span><span class="keyword">include(</span><span class="string">'settings.php'</span><span class="keyword">);<br /><br />if (</span><span class="default">DEBUG</span><span class="keyword">) {<br />&nbsp;&nbsp; </span><span class="comment">// echo some sensitive data.<br /></span><span class="keyword">}<br /></span><span class="default">?&gt;<br /></span><br />If for some reason settings.php doesn't get included and the DEBUG constant is not set, PHP will STILL print the sensitive data. The solution is to evaluate it. Like so:<br /><br />settings.php<br /><span class="default">&lt;?php<br /></span><span class="comment">// Debug mode<br /></span><span class="default">define</span><span class="keyword">(</span><span class="string">'DEBUG'</span><span class="keyword">,</span><span class="default">0</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />test.php<br /><span class="default">&lt;?php<br /></span><span class="keyword">include(</span><span class="string">'settings.php'</span><span class="keyword">);<br /><br />if (</span><span class="default">DEBUG </span><span class="keyword">== </span><span class="default">1</span><span class="keyword">) {<br />&nbsp;&nbsp; </span><span class="comment">// echo some sensitive data.<br /></span><span class="keyword">}<br /></span><span class="default">?&gt;<br /></span><br />Now it works correctly.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="35064">  <div class="votes">
    <div id="Vu35064">
    <a href="/manual/vote-note.php?id=35064&amp;page=language.constants&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd35064">
    <a href="/manual/vote-note.php?id=35064&amp;page=language.constants&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V35064" title="57% like this...">
    12
    </div>
  </div>
  <a href="#35064" class="name">
  <strong class="user"><em>ewspencer at industrex dot com</em></strong></a><a class="genanchor" href="#35064"> &para;</a><div class="date" title="2003-08-18 06:30"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom35064">
<div class="phpcode"><code><span class="html">
I find using the concatenation operator helps disambiguate value assignments with constants. For example, setting constants in a global configuration file:<br /><br /><span class="default">&lt;?php<br />define</span><span class="keyword">(</span><span class="string">'LOCATOR'</span><span class="keyword">,&nbsp;&nbsp; </span><span class="string">"/locator"</span><span class="keyword">);<br /></span><span class="default">define</span><span class="keyword">(</span><span class="string">'CLASSES'</span><span class="keyword">,&nbsp;&nbsp; </span><span class="default">LOCATOR</span><span class="keyword">.</span><span class="string">"/code/classes"</span><span class="keyword">);<br /></span><span class="default">define</span><span class="keyword">(</span><span class="string">'FUNCTIONS'</span><span class="keyword">, </span><span class="default">LOCATOR</span><span class="keyword">.</span><span class="string">"/code/functions"</span><span class="keyword">);<br /></span><span class="default">define</span><span class="keyword">(</span><span class="string">'USERDIR'</span><span class="keyword">,&nbsp;&nbsp; </span><span class="default">LOCATOR</span><span class="keyword">.</span><span class="string">"/user"</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />Later, I can use the same convention when invoking a constant's value for static constructs such as require() calls:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">require_once(</span><span class="default">FUNCTIONS</span><span class="keyword">.</span><span class="string">"/database.fnc"</span><span class="keyword">);<br />require_once(</span><span class="default">FUNCTIONS</span><span class="keyword">.</span><span class="string">"/randchar.fnc"</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />as well as dynamic constructs, typical of value assignment to variables:<br /><br /><span class="default">&lt;?php<br />$userid&nbsp; </span><span class="keyword">= </span><span class="default">randchar</span><span class="keyword">(</span><span class="default">8</span><span class="keyword">,</span><span class="string">'anc'</span><span class="keyword">,</span><span class="string">'u'</span><span class="keyword">);<br /></span><span class="default">$usermap </span><span class="keyword">= </span><span class="default">USERDIR</span><span class="keyword">.</span><span class="string">"/"</span><span class="keyword">.</span><span class="default">$userid</span><span class="keyword">.</span><span class="string">".png"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />The above convention works for me, and helps produce self-documenting code.<br /><br />-- Erich</span>
</code></div>
  </div>
 </div>
  <div class="note" id="74836">  <div class="votes">
    <div id="Vu74836">
    <a href="/manual/vote-note.php?id=74836&amp;page=language.constants&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd74836">
    <a href="/manual/vote-note.php?id=74836&amp;page=language.constants&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V74836" title="54% like this...">
    6
    </div>
  </div>
  <a href="#74836" class="name">
  <strong class="user"><em>Andreas R.</em></strong></a><a class="genanchor" href="#74836"> &para;</a><div class="date" title="2007-04-30 07:19"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom74836">
<div class="phpcode"><code><span class="html">
If you are looking for predefined constants like<br />* PHP_OS (to show the operating system, PHP was compiled for; php_uname('s') might be more suitable),<br />* DIRECTORY_SEPARATOR ("\\" on Win, '/' Linux,...)<br />* PATH_SEPARATOR (';' on Win, ':' on Linux,...)<br />they are buried in 'Predefined Constants' under 'List of Reserved Words' in the appendix:<br /><a href="http://www.php.net/manual/en/reserved.constants.php" rel="nofollow" target="_blank">http://www.php.net/manual/en/reserved.constants.php</a><br />while the latter two are also mentioned in 'Directory Functions'<br /><a href="http://www.php.net/manual/en/ref.dir.php" rel="nofollow" target="_blank">http://www.php.net/manual/en/ref.dir.php</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="52133">  <div class="votes">
    <div id="Vu52133">
    <a href="/manual/vote-note.php?id=52133&amp;page=language.constants&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd52133">
    <a href="/manual/vote-note.php?id=52133&amp;page=language.constants&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V52133" title="54% like this...">
    5
    </div>
  </div>
  <a href="#52133" class="name">
  <strong class="user"><em>hafenator2000 at yahoo dot com</em></strong></a><a class="genanchor" href="#52133"> &para;</a><div class="date" title="2005-04-21 02:09"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom52133">
<div class="phpcode"><code><span class="html">
PHP Modules also define constants.&nbsp; Make sure to avoid constant name collisions.&nbsp; There are two ways to do this that I can think of.<br />First: in your code make sure that the constant name is not already used.&nbsp; ex. <span class="default">&lt;?php </span><span class="keyword">if (! </span><span class="default">defined</span><span class="keyword">(</span><span class="string">"CONSTANT_NAME"</span><span class="keyword">)) { </span><span class="default">Define</span><span class="keyword">(</span><span class="string">"CONSTANT_NAME"</span><span class="keyword">,</span><span class="string">"Some Value"</span><span class="keyword">); } </span><span class="default">?&gt;</span>&nbsp; This can get messy when you start thinking about collision handling, and the implications of this.<br />Second: Use some off prepend to all your constant names without exception&nbsp; ex. <span class="default">&lt;?php Define</span><span class="keyword">(</span><span class="string">"SITE_CONSTANT_NAME"</span><span class="keyword">,</span><span class="string">"Some Value"</span><span class="keyword">); </span><span class="default">?&gt;<br /></span><br />Perhaps the developers or documentation maintainers could recommend a good prepend and ask module writers to avoid that prepend in modules.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121732">  <div class="votes">
    <div id="Vu121732">
    <a href="/manual/vote-note.php?id=121732&amp;page=language.constants&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121732">
    <a href="/manual/vote-note.php?id=121732&amp;page=language.constants&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121732" title="100% like this...">
    1
    </div>
  </div>
  <a href="#121732" class="name">
  <strong class="user"><em>jcastromail at yahoo dot es</em></strong></a><a class="genanchor" href="#121732"> &para;</a><div class="date" title="2017-10-07 12:13"><strong>2 months ago</strong></div>
  <div class="text" id="Hcom121732">
<div class="phpcode"><code><span class="html">
Performance of constants.&nbsp; PHP 7.1.10 32 bits (Opcache active, windows 10 i7-64bits) but apparently the trends is the same with the 5.x<br /><br />using a constant declared by DEFINE('CNS',value) : 0.63575601577759s<br />using a constant declared by const CNS=value : 0.61372208595276s<br />using a variable declared by $v=value : 0.51184010505676s<br /><br />In average, the use of DEFINE and CONST is around the same with some sightly&nbsp; better performance of CONST instead of DEFINE. However, using a variable is around 10-50% better than to use a constant.&nbsp; So, for a performance intensive task, constant is not the best option.<br /><br />$p1=microtime(true);<br />$x=0;<br />for($i=0;$i&lt;50000000;$i++) {<br />&nbsp; &nbsp; $x+=CNS;<br />}<br />$p2=microtime(true);</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120578">  <div class="votes">
    <div id="Vu120578">
    <a href="/manual/vote-note.php?id=120578&amp;page=language.constants&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120578">
    <a href="/manual/vote-note.php?id=120578&amp;page=language.constants&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120578" title="40% like this...">
    -8
    </div>
  </div>
  <a href="#120578" class="name">
  <strong class="user"><em>xs2ilyas at gmail dot com</em></strong></a><a class="genanchor" href="#120578"> &para;</a><div class="date" title="2017-02-03 05:38"><strong>10 months ago</strong></div>
  <div class="text" id="Hcom120578">
<div class="phpcode"><code><span class="html">
When we start a constant name with space, it doesn't produce any error.<br /><br /><span class="default">&lt;?php<br />&nbsp; define </span><span class="keyword">(</span><span class="string">" YEAR"</span><span class="keyword">,&nbsp; </span><span class="default">2000</span><span class="keyword">)<br />&nbsp; echo </span><span class="string">"success"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />output: success<br /><br />But when we call this constant, it produce error.<br /><br /><span class="default">&lt;?php<br />&nbsp; define </span><span class="keyword">(</span><span class="string">" YEAR"</span><span class="keyword">,&nbsp; </span><span class="default">2000</span><span class="keyword">)<br />&nbsp; echo </span><span class="default">YEAR</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />output: E_NOTICE :&nbsp; type 8 -- Use of undefined constant YEAR - assumed 'YEAR' -- at line 4 YEAR</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114762">  <div class="votes">
    <div id="Vu114762">
    <a href="/manual/vote-note.php?id=114762&amp;page=language.constants&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114762">
    <a href="/manual/vote-note.php?id=114762&amp;page=language.constants&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114762" title="40% like this...">
    -18
    </div>
  </div>
  <a href="#114762" class="name">
  <strong class="user"><em>php at webflips dot net</em></strong></a><a class="genanchor" href="#114762"> &para;</a><div class="date" title="2014-04-02 08:03"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114762">
<div class="phpcode"><code><span class="html">
It is perfectly valid to use a built-in PHP keyword as a constant name - as long as you the constant() function to retrieve it later:<br /><br /><span class="default">&lt;?php<br />define</span><span class="keyword">(</span><span class="string">'echo'</span><span class="keyword">, </span><span class="string">'My constant value'</span><span class="keyword">);<br /><br />echo </span><span class="default">constant</span><span class="keyword">(</span><span class="string">'echo'</span><span class="keyword">); </span><span class="comment">// outputs 'My constant value'<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.constants&amp;redirect=http://php.net/manual/tr/language.constants.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="langref.php">Dil Başvuru Kılavuzu</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.basic-syntax.php" title="Temel S&ouml;zdizimi">Temel S&ouml;zdizimi</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.php" title="T&uuml;rler">T&uuml;rler</a>
                        </li>
                          
                        <li class="">
                            <a href="language.variables.php" title="Değişkenler">Değişkenler</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.constants.php" title="Sabitler">Sabitler</a>
                        </li>
                          
                        <li class="">
                            <a href="language.expressions.php" title="İfadeler">İfadeler</a>
                        </li>
                          
                        <li class="">
                            <a href="language.operators.php" title="İşle&ccedil;ler">İşle&ccedil;ler</a>
                        </li>
                          
                        <li class="">
                            <a href="language.control-structures.php" title="Denetim Yapıları">Denetim Yapıları</a>
                        </li>
                          
                        <li class="">
                            <a href="language.functions.php" title="İşlevler">İşlevler</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.php" title="Sınıflar ve Nesneler">Sınıflar ve Nesneler</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.php" title="İsim Alanları">İsim Alanları</a>
                        </li>
                          
                        <li class="">
                            <a href="language.errors.php" title="Errors">Errors</a>
                        </li>
                          
                        <li class="">
                            <a href="language.exceptions.php" title="İstisnalar">İstisnalar</a>
                        </li>
                          
                        <li class="">
                            <a href="language.generators.php" title="Generators">Generators</a>
                        </li>
                          
                        <li class="">
                            <a href="language.references.php" title="G&ouml;nderimlerle İlgili Herşey">G&ouml;nderimlerle İlgili Herşey</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.php" title="&Ouml;ntanımlı Değişkenler">&Ouml;ntanımlı Değişkenler</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.exceptions.php" title="&Ouml;ntanımlı İstisnalar">&Ouml;ntanımlı İstisnalar</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.interfaces.php" title="&Ouml;ntanımlı Aray&uuml;zler ve Sınıflar">&Ouml;ntanımlı Aray&uuml;zler ve Sınıflar</a>
                        </li>
                          
                        <li class="">
                            <a href="context.php" title="Bağlam se&ccedil;enekleri ve değiştirgeleri">Bağlam se&ccedil;enekleri ve değiştirgeleri</a>
                        </li>
                          
                        <li class="">
                            <a href="wrappers.php" title="Supported Protocols and Wrappers">Supported Protocols and Wrappers</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

