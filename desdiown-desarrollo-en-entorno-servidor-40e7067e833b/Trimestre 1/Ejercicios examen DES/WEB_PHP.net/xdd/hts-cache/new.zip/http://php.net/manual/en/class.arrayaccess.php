<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: ArrayAccess - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/class.arrayaccess.php">
 <link rel="shorturl" href="http://php.net/arrayaccess">
 <link rel="alternate" href="http://php.net/arrayaccess" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/reserved.interfaces.php">
 <link rel="prev" href="http://php.net/manual/en/throwable.tostring.php">
 <link rel="next" href="http://php.net/manual/en/arrayaccess.offsetexists.php">

 <link rel="alternate" href="http://php.net/manual/en/class.arrayaccess.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/class.arrayaccess.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/class.arrayaccess.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/class.arrayaccess.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/class.arrayaccess.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/class.arrayaccess.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/class.arrayaccess.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/class.arrayaccess.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/class.arrayaccess.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/class.arrayaccess.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/class.arrayaccess.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="arrayaccess.offsetexists.php">
          ArrayAccess::offsetExists &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="throwable.tostring.php">
          &laquo; Throwable::__toString        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='reserved.interfaces.php'>Predefined Interfaces and Classes</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/class.arrayaccess.php' selected="selected">English</option>
            <option value='pt_BR/class.arrayaccess.php'>Brazilian Portuguese</option>
            <option value='zh/class.arrayaccess.php'>Chinese (Simplified)</option>
            <option value='fr/class.arrayaccess.php'>French</option>
            <option value='de/class.arrayaccess.php'>German</option>
            <option value='ja/class.arrayaccess.php'>Japanese</option>
            <option value='ro/class.arrayaccess.php'>Romanian</option>
            <option value='ru/class.arrayaccess.php'>Russian</option>
            <option value='es/class.arrayaccess.php'>Spanish</option>
            <option value='tr/class.arrayaccess.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/class.arrayaccess.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=class.arrayaccess">Report a Bug</a>
    </div>
  </div><div id="class.arrayaccess" class="reference">

 <h1 class="title">The ArrayAccess interface</h1>
 

 <div class="partintro"><p class="verinfo">(PHP 5 &gt;= 5.0.0, PHP 7)</p>


  <div class="section" id="arrayaccess.intro">
   <h2 class="title">Introduction</h2>
   <p class="para">
    Interface to provide accessing objects as arrays.
   </p>
  </div>


  <div class="section" id="arrayaccess.synopsis">
   <h2 class="title">Interface synopsis</h2>


   <div class="classsynopsis">
    <div class="ooclass"></div>


    <div class="classsynopsisinfo">
     <span class="ooclass">
      <strong class="classname">ArrayAccess</strong>
     </span>
     {</div>

    
    <div class="classsynopsisinfo classsynopsisinfo_comment">/* Methods */</div>
    <div class="methodsynopsis dc-description">
   <span class="modifier">abstract</span> <span class="modifier">public</span> <span class="type">boolean</span> <span class="methodname"><a href="arrayaccess.offsetexists.php" class="methodname">offsetExists</a></span>
    ( <span class="methodparam"><span class="type"><a href="language.pseudo-types.php#language.types.mixed" class="type mixed">mixed</a></span> <code class="parameter">$offset</code></span>
   )</div>
<div class="methodsynopsis dc-description">
   <span class="modifier">abstract</span> <span class="modifier">public</span> <span class="type">mixed</span> <span class="methodname"><a href="arrayaccess.offsetget.php" class="methodname">offsetGet</a></span>
    ( <span class="methodparam"><span class="type"><a href="language.pseudo-types.php#language.types.mixed" class="type mixed">mixed</a></span> <code class="parameter">$offset</code></span>
   )</div>
<div class="methodsynopsis dc-description">
   <span class="modifier">abstract</span> <span class="modifier">public</span> <span class="type">void</span> <span class="methodname"><a href="arrayaccess.offsetset.php" class="methodname">offsetSet</a></span>
    ( <span class="methodparam"><span class="type"><a href="language.pseudo-types.php#language.types.mixed" class="type mixed">mixed</a></span> <code class="parameter">$offset</code></span>
   , <span class="methodparam"><span class="type"><a href="language.pseudo-types.php#language.types.mixed" class="type mixed">mixed</a></span> <code class="parameter">$value</code></span>
   )</div>
<div class="methodsynopsis dc-description">
   <span class="modifier">abstract</span> <span class="modifier">public</span> <span class="type">void</span> <span class="methodname"><a href="arrayaccess.offsetunset.php" class="methodname">offsetUnset</a></span>
    ( <span class="methodparam"><span class="type"><a href="language.pseudo-types.php#language.types.mixed" class="type mixed">mixed</a></span> <code class="parameter">$offset</code></span>
   )</div>

   }</div>


  </div>

  <div class="section" id="arrayaccess.examples">
   <div class="example" id="example-325">
    <p><strong>Example #1 Basic usage</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">obj&nbsp;</span><span style="color: #007700">implements&nbsp;</span><span style="color: #0000BB">ArrayAccess&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;private&nbsp;</span><span style="color: #0000BB">$container&nbsp;</span><span style="color: #007700">=&nbsp;array();<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">__construct</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">container&nbsp;</span><span style="color: #007700">=&nbsp;array(<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"one"&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"two"&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"three"&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #0000BB">3</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;);<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">offsetSet</span><span style="color: #007700">(</span><span style="color: #0000BB">$offset</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$value</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(</span><span style="color: #0000BB">is_null</span><span style="color: #007700">(</span><span style="color: #0000BB">$offset</span><span style="color: #007700">))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">container</span><span style="color: #007700">[]&nbsp;=&nbsp;</span><span style="color: #0000BB">$value</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}&nbsp;else&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">container</span><span style="color: #007700">[</span><span style="color: #0000BB">$offset</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #0000BB">$value</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">offsetExists</span><span style="color: #007700">(</span><span style="color: #0000BB">$offset</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;isset(</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">container</span><span style="color: #007700">[</span><span style="color: #0000BB">$offset</span><span style="color: #007700">]);<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">offsetUnset</span><span style="color: #007700">(</span><span style="color: #0000BB">$offset</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;unset(</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">container</span><span style="color: #007700">[</span><span style="color: #0000BB">$offset</span><span style="color: #007700">]);<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">offsetGet</span><span style="color: #007700">(</span><span style="color: #0000BB">$offset</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;isset(</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">container</span><span style="color: #007700">[</span><span style="color: #0000BB">$offset</span><span style="color: #007700">])&nbsp;?&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">container</span><span style="color: #007700">[</span><span style="color: #0000BB">$offset</span><span style="color: #007700">]&nbsp;:&nbsp;</span><span style="color: #0000BB">null</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br /></span><span style="color: #0000BB">$obj&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">obj</span><span style="color: #007700">;<br /><br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(isset(</span><span style="color: #0000BB">$obj</span><span style="color: #007700">[</span><span style="color: #DD0000">"two"</span><span style="color: #007700">]));<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$obj</span><span style="color: #007700">[</span><span style="color: #DD0000">"two"</span><span style="color: #007700">]);<br />unset(</span><span style="color: #0000BB">$obj</span><span style="color: #007700">[</span><span style="color: #DD0000">"two"</span><span style="color: #007700">]);<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(isset(</span><span style="color: #0000BB">$obj</span><span style="color: #007700">[</span><span style="color: #DD0000">"two"</span><span style="color: #007700">]));<br /></span><span style="color: #0000BB">$obj</span><span style="color: #007700">[</span><span style="color: #DD0000">"two"</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #DD0000">"A&nbsp;value"</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$obj</span><span style="color: #007700">[</span><span style="color: #DD0000">"two"</span><span style="color: #007700">]);<br /></span><span style="color: #0000BB">$obj</span><span style="color: #007700">[]&nbsp;=&nbsp;</span><span style="color: #DD0000">'Append&nbsp;1'</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$obj</span><span style="color: #007700">[]&nbsp;=&nbsp;</span><span style="color: #DD0000">'Append&nbsp;2'</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$obj</span><span style="color: #007700">[]&nbsp;=&nbsp;</span><span style="color: #DD0000">'Append&nbsp;3'</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">print_r</span><span style="color: #007700">(</span><span style="color: #0000BB">$obj</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

    <div class="example-contents"><p>The above example will output
something similar to:</p></div>
    <div class="example-contents screen">
<div class="cdata"><pre>
bool(true)
int(2)
bool(false)
string(7) &quot;A value&quot;
obj Object
(
    [container:obj:private] =&gt; Array
        (
            [one] =&gt; 1
            [three] =&gt; 3
            [two] =&gt; A value
            [0] =&gt; Append 1
            [1] =&gt; Append 2
            [2] =&gt; Append 3
        )

)
</pre></div>
    </div>
   </div>
  </div>

 </div>

 






 






 






 







<h2>Table of Contents</h2><ul class="chunklist chunklist_reference"><li><a href="arrayaccess.offsetexists.php">ArrayAccess::offsetExists</a> — Whether an offset exists</li><li><a href="arrayaccess.offsetget.php">ArrayAccess::offsetGet</a> — Offset to retrieve</li><li><a href="arrayaccess.offsetset.php">ArrayAccess::offsetSet</a> — Assign a value to the specified offset</li><li><a href="arrayaccess.offsetunset.php">ArrayAccess::offsetUnset</a> — Unset an offset</li></ul>
</div>

<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=class.arrayaccess&amp;redirect=http://php.net/manual/en/class.arrayaccess.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">15 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="104061">  <div class="votes">
    <div id="Vu104061">
    <a href="/manual/vote-note.php?id=104061&amp;page=class.arrayaccess&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd104061">
    <a href="/manual/vote-note.php?id=104061&amp;page=class.arrayaccess&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V104061" title="88% like this...">
    85
    </div>
  </div>
  <a href="#104061" class="name">
  <strong class="user"><em>Per</em></strong></a><a class="genanchor" href="#104061"> &para;</a><div class="date" title="2011-05-20 02:16"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom104061">
<div class="phpcode"><code><span class="html">
It bit me today, so putting it here in the hope it will help others:<br />If you call array_key_exists() on an object of a class that implements ArrayAccess, ArrayAccess::offsetExists() wil NOT be called.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="111810">  <div class="votes">
    <div id="Vu111810">
    <a href="/manual/vote-note.php?id=111810&amp;page=class.arrayaccess&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd111810">
    <a href="/manual/vote-note.php?id=111810&amp;page=class.arrayaccess&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V111810" title="88% like this...">
    14
    </div>
  </div>
  <a href="#111810" class="name">
  <strong class="user"><em>Hayley Watson</em></strong></a><a class="genanchor" href="#111810"> &para;</a><div class="date" title="2013-03-31 12:25"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom111810">
<div class="phpcode"><code><span class="html">
The indexes used in an ArrayAccess object are not limited to strings and integers as they are for arrays: you can use any type for the index as long as you write your implementation to handle them. This fact is exploited by the SplObjectStorage class.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113865">  <div class="votes">
    <div id="Vu113865">
    <a href="/manual/vote-note.php?id=113865&amp;page=class.arrayaccess&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113865">
    <a href="/manual/vote-note.php?id=113865&amp;page=class.arrayaccess&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113865" title="76% like this...">
    36
    </div>
  </div>
  <a href="#113865" class="name">
  <strong class="user"><em>Yousef Ismaeil Cliprz</em></strong></a><a class="genanchor" href="#113865"> &para;</a><div class="date" title="2013-12-11 07:38"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113865">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br /><br /></span><span class="comment">/**<br /> * ArrayAndObjectAccess<br /> * Yes you can access class as array and the same time as object<br /> *<br /> * @author Yousef Ismaeil &lt;cliprz@gmail.com&gt;<br /> */<br /><br /></span><span class="keyword">class </span><span class="default">ArrayAndObjectAccess </span><span class="keyword">implements </span><span class="default">ArrayAccess </span><span class="keyword">{<br /><br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Data<br />&nbsp; &nbsp;&nbsp; *<br />&nbsp; &nbsp;&nbsp; * @var array<br />&nbsp; &nbsp;&nbsp; * @access private<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">private </span><span class="default">$data </span><span class="keyword">= [];<br /><br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Get a data by key<br />&nbsp; &nbsp;&nbsp; *<br />&nbsp; &nbsp;&nbsp; * @param string The key data to retrieve<br />&nbsp; &nbsp;&nbsp; * @access public<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">public function &amp;</span><span class="default">__get </span><span class="keyword">(</span><span class="default">$key</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">data</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">];<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Assigns a value to the specified data<br />&nbsp; &nbsp;&nbsp; * <br />&nbsp; &nbsp;&nbsp; * @param string The data key to assign the value to<br />&nbsp; &nbsp;&nbsp; * @param mixed&nbsp; The value to set<br />&nbsp; &nbsp;&nbsp; * @access public <br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">__set</span><span class="keyword">(</span><span class="default">$key</span><span class="keyword">,</span><span class="default">$value</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">data</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">] = </span><span class="default">$value</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Whether or not an data exists by key<br />&nbsp; &nbsp;&nbsp; *<br />&nbsp; &nbsp;&nbsp; * @param string An data key to check for<br />&nbsp; &nbsp;&nbsp; * @access public<br />&nbsp; &nbsp;&nbsp; * @return boolean<br />&nbsp; &nbsp;&nbsp; * @abstracting ArrayAccess<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">__isset </span><span class="keyword">(</span><span class="default">$key</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; return isset(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">data</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">]);<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Unsets an data by key<br />&nbsp; &nbsp;&nbsp; *<br />&nbsp; &nbsp;&nbsp; * @param string The key to unset<br />&nbsp; &nbsp;&nbsp; * @access public<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">__unset</span><span class="keyword">(</span><span class="default">$key</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; unset(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">data</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">]);<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Assigns a value to the specified offset<br />&nbsp; &nbsp;&nbsp; *<br />&nbsp; &nbsp;&nbsp; * @param string The offset to assign the value to<br />&nbsp; &nbsp;&nbsp; * @param mixed&nbsp; The value to set<br />&nbsp; &nbsp;&nbsp; * @access public<br />&nbsp; &nbsp;&nbsp; * @abstracting ArrayAccess<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">offsetSet</span><span class="keyword">(</span><span class="default">$offset</span><span class="keyword">,</span><span class="default">$value</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">is_null</span><span class="keyword">(</span><span class="default">$offset</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">data</span><span class="keyword">[] = </span><span class="default">$value</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">data</span><span class="keyword">[</span><span class="default">$offset</span><span class="keyword">] = </span><span class="default">$value</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Whether or not an offset exists<br />&nbsp; &nbsp;&nbsp; *<br />&nbsp; &nbsp;&nbsp; * @param string An offset to check for<br />&nbsp; &nbsp;&nbsp; * @access public<br />&nbsp; &nbsp;&nbsp; * @return boolean<br />&nbsp; &nbsp;&nbsp; * @abstracting ArrayAccess<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">offsetExists</span><span class="keyword">(</span><span class="default">$offset</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; return isset(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">data</span><span class="keyword">[</span><span class="default">$offset</span><span class="keyword">]);<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Unsets an offset<br />&nbsp; &nbsp;&nbsp; *<br />&nbsp; &nbsp;&nbsp; * @param string The offset to unset<br />&nbsp; &nbsp;&nbsp; * @access public<br />&nbsp; &nbsp;&nbsp; * @abstracting ArrayAccess<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">offsetUnset</span><span class="keyword">(</span><span class="default">$offset</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">offsetExists</span><span class="keyword">(</span><span class="default">$offset</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; unset(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">data</span><span class="keyword">[</span><span class="default">$offset</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Returns the value at specified offset<br />&nbsp; &nbsp;&nbsp; *<br />&nbsp; &nbsp;&nbsp; * @param string The offset to retrieve<br />&nbsp; &nbsp;&nbsp; * @access public<br />&nbsp; &nbsp;&nbsp; * @return mixed<br />&nbsp; &nbsp;&nbsp; * @abstracting ArrayAccess<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">offsetGet</span><span class="keyword">(</span><span class="default">$offset</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">offsetExists</span><span class="keyword">(</span><span class="default">$offset</span><span class="keyword">) ? </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">data</span><span class="keyword">[</span><span class="default">$offset</span><span class="keyword">] : </span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />Usage<br /><br /><span class="default">&lt;?php<br />$foo </span><span class="keyword">= new </span><span class="default">ArrayAndObjectAccess</span><span class="keyword">();<br /></span><span class="comment">// Set data as array and object<br /></span><span class="default">$foo</span><span class="keyword">-&gt;</span><span class="default">fname </span><span class="keyword">= </span><span class="string">'Yousef'</span><span class="keyword">;<br /></span><span class="default">$foo</span><span class="keyword">-&gt;</span><span class="default">lname </span><span class="keyword">= </span><span class="string">'Ismaeil'</span><span class="keyword">;<br /></span><span class="comment">// Call as object<br /></span><span class="keyword">echo </span><span class="string">'fname as object '</span><span class="keyword">.</span><span class="default">$foo</span><span class="keyword">-&gt;</span><span class="default">fname</span><span class="keyword">.</span><span class="string">"\n"</span><span class="keyword">;<br /></span><span class="comment">// Call as array<br /></span><span class="keyword">echo </span><span class="string">'lname as array '</span><span class="keyword">.</span><span class="default">$foo</span><span class="keyword">[</span><span class="string">'lname'</span><span class="keyword">].</span><span class="string">"\n"</span><span class="keyword">;<br /></span><span class="comment">// Reset as array<br /></span><span class="default">$foo</span><span class="keyword">[</span><span class="string">'fname'</span><span class="keyword">] = </span><span class="string">'Cliprz'</span><span class="keyword">;<br />echo </span><span class="default">$foo</span><span class="keyword">[</span><span class="string">'fname'</span><span class="keyword">].</span><span class="string">"\n"</span><span class="keyword">;<br /><br /></span><span class="comment">/** Outputs<br />fname as object Yousef<br />lname as array Ismaeil<br />Cliprz<br />*/<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="110827">  <div class="votes">
    <div id="Vu110827">
    <a href="/manual/vote-note.php?id=110827&amp;page=class.arrayaccess&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd110827">
    <a href="/manual/vote-note.php?id=110827&amp;page=class.arrayaccess&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V110827" title="83% like this...">
    16
    </div>
  </div>
  <a href="#110827" class="name">
  <strong class="user"><em>jojor at gmx dot net</em></strong></a><a class="genanchor" href="#110827"> &para;</a><div class="date" title="2012-12-12 01:08"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom110827">
<div class="phpcode"><code><span class="html">
Conclusion: Type hints \ArrayAccess and array are not compatible.<br /><br /><span class="default">&lt;?php<br /><br />&nbsp; &nbsp;&nbsp; </span><span class="keyword">class </span><span class="default">MyArrayAccess </span><span class="keyword">implements \</span><span class="default">ArrayAccess<br />&nbsp; &nbsp;&nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; public function </span><span class="default">offsetExists</span><span class="keyword">(</span><span class="default">$offset</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; {<br /><br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; public function </span><span class="default">offsetSet</span><span class="keyword">(</span><span class="default">$offset</span><span class="keyword">, </span><span class="default">$value</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; {<br /><br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; public function </span><span class="default">offsetGet</span><span class="keyword">(</span><span class="default">$offset</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; {<br /><br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; public function </span><span class="default">offsetUnset</span><span class="keyword">(</span><span class="default">$offset</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; {<br /><br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; }<br />&nbsp; &nbsp;&nbsp; }<br /><br /><br />&nbsp; &nbsp;&nbsp; function </span><span class="default">test</span><span class="keyword">(array </span><span class="default">$arr</span><span class="keyword">)<br />&nbsp; &nbsp;&nbsp; {<br />&nbsp; &nbsp;&nbsp; }<br /><br />&nbsp; &nbsp;&nbsp; function </span><span class="default">test2</span><span class="keyword">(\</span><span class="default">ArrayAccess $arr</span><span class="keyword">)<br />&nbsp; &nbsp;&nbsp; {<br /><br />&nbsp; &nbsp;&nbsp; }<br /><br /><br />&nbsp; &nbsp;&nbsp; </span><span class="default">$arrObj </span><span class="keyword">= new </span><span class="default">MyArrayAccess</span><span class="keyword">();<br />&nbsp; &nbsp;&nbsp; </span><span class="default">test</span><span class="keyword">([]); </span><span class="comment">//result: works!<br />&nbsp; &nbsp;&nbsp; </span><span class="default">test</span><span class="keyword">(</span><span class="default">$arrObj</span><span class="keyword">); </span><span class="comment">//result: does NOT work<br />&nbsp; &nbsp;&nbsp; </span><span class="default">test2</span><span class="keyword">([]); </span><span class="comment">//result: does NOT work<br />&nbsp; &nbsp;&nbsp; </span><span class="default">test2</span><span class="keyword">(</span><span class="default">$arrObj</span><span class="keyword">); </span><span class="comment">// result: works!<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="97163">  <div class="votes">
    <div id="Vu97163">
    <a href="/manual/vote-note.php?id=97163&amp;page=class.arrayaccess&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd97163">
    <a href="/manual/vote-note.php?id=97163&amp;page=class.arrayaccess&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V97163" title="85% like this...">
    14
    </div>
  </div>
  <a href="#97163" class="name">
  <strong class="user"><em>max at flashdroid dot com</em></strong></a><a class="genanchor" href="#97163"> &para;</a><div class="date" title="2010-04-05 06:49"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom97163">
<div class="phpcode"><code><span class="html">
Objects implementing ArrayAccess may return objects by references in PHP 5.3.0.<br /><br />You can implement your ArrayAccess object like this:<br /><br />&nbsp; &nbsp; class Reflectable implements ArrayAccess {<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; public function set($name, $value) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $this-&gt;{$name} = $value;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; public function &amp;get($name) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return $this-&gt;{$name};<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; public function offsetGet($offset) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return $this-&gt;get($offset);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; public function offsetSet($offset, $value) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $this-&gt;set($offset, $value);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; ...<br /><br />&nbsp; &nbsp; }<br /><br />This base class allows you to get / set your object properties using the [] operator just like in Javascript:<br /><br />&nbsp; &nbsp; class Boo extends Reflectable {<br />&nbsp; &nbsp; &nbsp; &nbsp; public $name;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; $obj = new Boo();<br />&nbsp; &nbsp; $obj['name'] = "boo";<br />&nbsp; &nbsp; echo $obj['name']; // prints boo</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117567">  <div class="votes">
    <div id="Vu117567">
    <a href="/manual/vote-note.php?id=117567&amp;page=class.arrayaccess&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117567">
    <a href="/manual/vote-note.php?id=117567&amp;page=class.arrayaccess&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117567" title="77% like this...">
    5
    </div>
  </div>
  <a href="#117567" class="name">
  <strong class="user"><em>kaRemovTihsjouni at gmAndTihsaildot com</em></strong></a><a class="genanchor" href="#117567"> &para;</a><div class="date" title="2015-06-30 03:03"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117567">
<div class="phpcode"><code><span class="html">
reset() method may not work as you expect with ArrayAccess objects.<br /><br />Using reset($myArrayAccessObject) returns the first property from $myArrayAccessObject, not the first item in the items array.<br /><br />If you want to use the reset() method to return the first array item, then you can use the following simple workaround:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">MyArrayAccessObject </span><span class="keyword">implements </span><span class="default">Iterator</span><span class="keyword">, </span><span class="default">ArrayAccess</span><span class="keyword">, </span><span class="default">Countable </span><span class="keyword">{<br />&nbsp; &nbsp; protected </span><span class="default">$first </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">; </span><span class="comment">//WARNING! Keep this always first.<br />&nbsp; &nbsp; </span><span class="keyword">protected </span><span class="default">$items </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; private function </span><span class="default">supportReset</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">first </span><span class="keyword">= </span><span class="default">reset</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">items</span><span class="keyword">); </span><span class="comment">//Support reset().<br />&nbsp; &nbsp; </span><span class="keyword">}<br />&nbsp; &nbsp; </span><span class="comment">// ...<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">offsetSet</span><span class="keyword">(</span><span class="default">$offset</span><span class="keyword">, </span><span class="default">$value</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$offset </span><span class="keyword">=== </span><span class="default">null</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">items</span><span class="keyword">[] = </span><span class="default">$value</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">items</span><span class="keyword">[</span><span class="default">$offset</span><span class="keyword">] = </span><span class="default">$value</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">supportReset</span><span class="keyword">();<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />Finally, call $this-&gt;supportReset() in the end of all methods that change the internal $items array, such as in offsetSet(), offsetUnset() etc.<br /><br />This way, you can use the reset() method as normally:<br /><br /><span class="default">&lt;?php<br />$firstArrayItem </span><span class="keyword">= </span><span class="default">reset</span><span class="keyword">(</span><span class="default">$myArrayAccessObject</span><span class="keyword">);<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119217">  <div class="votes">
    <div id="Vu119217">
    <a href="/manual/vote-note.php?id=119217&amp;page=class.arrayaccess&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119217">
    <a href="/manual/vote-note.php?id=119217&amp;page=class.arrayaccess&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119217" title="75% like this...">
    2
    </div>
  </div>
  <a href="#119217" class="name">
  <strong class="user"><em>nick at little-apps dot com</em></strong></a><a class="genanchor" href="#119217"> &para;</a><div class="date" title="2016-04-20 10:22"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119217">
<div class="phpcode"><code><span class="html">
A class that implements ArrayAccess will not work with array_push<br /><br />For example:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">TestArrayAccess </span><span class="keyword">implements </span><span class="default">ArrayAccess </span><span class="keyword">{<br />&nbsp; &nbsp; private </span><span class="default">$container </span><span class="keyword">= array();<br /><br />&nbsp; &nbsp; </span><span class="comment">// ArrayAccess methods<br /></span><span class="keyword">}<br /><br /></span><span class="default">$obj </span><span class="keyword">= new </span><span class="default">TestArrayAccess</span><span class="keyword">();<br /><br /></span><span class="default">array_push</span><span class="keyword">(</span><span class="default">$obj</span><span class="keyword">, </span><span class="string">'Hello World!'</span><span class="keyword">); </span><span class="comment">// Nothing will be added<br /></span><span class="default">?&gt;</span>&nbsp; <br /><br />One way of being able to use array_push would be by adding a toArray() method (note the return value is a reference).<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">TestArrayAccess </span><span class="keyword">implements </span><span class="default">ArrayAccess </span><span class="keyword">{<br />&nbsp; &nbsp; private </span><span class="default">$container </span><span class="keyword">= array();<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">// ArrayAccess methods<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="keyword">public function &amp;</span><span class="default">toArray</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">container</span><span class="keyword">;<br />&nbsp; &nbsp;&nbsp; }<br />}<br /><br /></span><span class="default">$obj </span><span class="keyword">= new </span><span class="default">TestArrayAccess</span><span class="keyword">();<br /><br /></span><span class="default">array_push</span><span class="keyword">(</span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">toArray</span><span class="keyword">(), </span><span class="string">'Hello World!'</span><span class="keyword">); </span><span class="comment">// Will now be added to array<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="111999">  <div class="votes">
    <div id="Vu111999">
    <a href="/manual/vote-note.php?id=111999&amp;page=class.arrayaccess&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd111999">
    <a href="/manual/vote-note.php?id=111999&amp;page=class.arrayaccess&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V111999" title="75% like this...">
    4
    </div>
  </div>
  <a href="#111999" class="name">
  <strong class="user"><em>ivan dot dossev at gmail dot com</em></strong></a><a class="genanchor" href="#111999"> &para;</a><div class="date" title="2013-04-20 07:09"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom111999">
<div class="phpcode"><code><span class="html">
Sadly you cannot assign by reference with the ArrayAccess (at least in PHP 5.3.23)<br />It's too bad there is no syntax for optionally passing variables by reference to functions (a feature in retro PHP).<br />That option would have let ArrayAccess fully mimic the functionality of normal array assignments:<br /><br /><span class="default">&lt;?php<br />$var </span><span class="keyword">= </span><span class="string">'hello'</span><span class="keyword">;<br /></span><span class="default">$arr </span><span class="keyword">= array();<br /></span><span class="default">$arr</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">] = </span><span class="default">$var</span><span class="keyword">;<br /></span><span class="default">$arr</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">] = &amp;</span><span class="default">$var</span><span class="keyword">;<br /></span><span class="default">$var </span><span class="keyword">= </span><span class="string">'world'</span><span class="keyword">;<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$arr</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">], </span><span class="default">$arr</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]);<br /><br /></span><span class="comment">// string(5) "hello"<br />// string(5) "world"<br /></span><span class="default">?&gt;<br /></span><br />Declaring "function offsetSet($offset, &amp;$value)" will cause a fatal error.<br />So to assign by ref you can use an ugly function call, for example:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">obj </span><span class="keyword">implements </span><span class="default">ArrayAccess </span><span class="keyword">{<br /><br />&nbsp; &nbsp; </span><span class="comment">// ... ArrayAccess example code ...<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="keyword">public function &amp;</span><span class="default">offsetSetRef</span><span class="keyword">(</span><span class="default">$offset</span><span class="keyword">, &amp;</span><span class="default">$value</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">is_null</span><span class="keyword">(</span><span class="default">$offset</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">container</span><span class="keyword">[] = &amp;</span><span class="default">$value</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">container</span><span class="keyword">[</span><span class="default">$offset</span><span class="keyword">] = &amp;</span><span class="default">$value</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$value</span><span class="keyword">; </span><span class="comment">// should return in case called within an assignment chain<br />&nbsp; &nbsp; </span><span class="keyword">}<br />}<br /><br /></span><span class="default">$var </span><span class="keyword">= </span><span class="string">'hello'</span><span class="keyword">;<br /></span><span class="default">$obj </span><span class="keyword">= new </span><span class="default">obj</span><span class="keyword">();<br /></span><span class="default">$obj</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">] = </span><span class="default">$var</span><span class="keyword">;<br /></span><span class="comment">//$obj[1] = &amp;$var; // Fatal error: Cannot assign by reference to overloaded object<br /></span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">offsetSetRef</span><span class="keyword">(</span><span class="default">1</span><span class="keyword">, </span><span class="default">$var</span><span class="keyword">); </span><span class="comment">// the work around<br /></span><span class="default">$var </span><span class="keyword">= </span><span class="string">'world'</span><span class="keyword">;<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$obj</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">], </span><span class="default">$obj</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]);<br /><br /></span><span class="comment">// string(5) "hello"<br />// string(5) "world"<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119674">  <div class="votes">
    <div id="Vu119674">
    <a href="/manual/vote-note.php?id=119674&amp;page=class.arrayaccess&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119674">
    <a href="/manual/vote-note.php?id=119674&amp;page=class.arrayaccess&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119674" title="66% like this...">
    2
    </div>
  </div>
  <a href="#119674" class="name">
  <strong class="user"><em>jordistc at gmail dot com</em></strong></a><a class="genanchor" href="#119674"> &para;</a><div class="date" title="2016-07-31 11:07"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119674">
<div class="phpcode"><code><span class="html">
You can use the array functions on a object of a class that implements ArrayAccess using the __invoke magic method in this way:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">ArrayVar </span><span class="keyword">implements </span><span class="default">ArrayAccess<br /></span><span class="keyword">{<br />&nbsp; &nbsp; private </span><span class="default">$data </span><span class="keyword">= [];<br /><br />&nbsp; &nbsp; public function </span><span class="default">__invoke</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">data</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />Now you can use it in this way:<br /><span class="default">&lt;?php<br />&nbsp; &nbsp; $arrayar </span><span class="keyword">= new </span><span class="default">ArrayVar</span><span class="keyword">();<br />&nbsp; &nbsp; </span><span class="default">$arrayar</span><span class="keyword">[</span><span class="string">'one'</span><span class="keyword">] = </span><span class="string">'primer'</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$arrayar</span><span class="keyword">[</span><span class="string">'two'</span><span class="keyword">] = </span><span class="string">'segon'</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$arrayar</span><span class="keyword">[</span><span class="string">'three'</span><span class="keyword">] = </span><span class="string">'tercer'</span><span class="keyword">;<br /><br />&nbsp; &nbsp; </span><span class="default">$keys </span><span class="keyword">= </span><span class="default">array_keys</span><span class="keyword">(</span><span class="default">$arrayar</span><span class="keyword">());<br />&nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$keys</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="comment">// array (size=3)<br />&nbsp; &nbsp; //&nbsp; &nbsp; 0 =&gt; string 'one'<br />&nbsp; &nbsp; //&nbsp; &nbsp; 1 =&gt; string 'two' <br />&nbsp; &nbsp; //&nbsp; &nbsp; 2 =&gt; string 'three'<br /><br />&nbsp; &nbsp; </span><span class="default">$diff </span><span class="keyword">= </span><span class="default">array_diff</span><span class="keyword">(</span><span class="default">$arrayar</span><span class="keyword">(), [ </span><span class="string">'two' </span><span class="keyword">=&gt; </span><span class="string">'segon'</span><span class="keyword">]);<br />&nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$diff</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="comment">// array (size=2)<br />&nbsp; &nbsp; //&nbsp; &nbsp; 'one' =&gt; string 'primer'<br />&nbsp; &nbsp; //&nbsp; &nbsp; 'three' =&gt; string 'tercer'<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114225">  <div class="votes">
    <div id="Vu114225">
    <a href="/manual/vote-note.php?id=114225&amp;page=class.arrayaccess&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114225">
    <a href="/manual/vote-note.php?id=114225&amp;page=class.arrayaccess&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114225" title="56% like this...">
    2
    </div>
  </div>
  <a href="#114225" class="name">
  <strong class="user"><em>php at lanar dot com dot au</em></strong></a><a class="genanchor" href="#114225"> &para;</a><div class="date" title="2014-01-27 01:35"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114225">
<div class="phpcode"><code><span class="html">
Objects implementing ArrayAccess do not support the increment/decrement operators ++ and --, unlike array() and ArrayObject()<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">MyArray </span><span class="keyword">implements </span><span class="default">ArrayAccess<br /></span><span class="keyword">{<br />&nbsp; &nbsp; </span><span class="comment">// offsetSet, offsetGet etc implemented<br /></span><span class="keyword">}<br /><br /></span><span class="default">$x </span><span class="keyword">= new </span><span class="default">MyArray</span><span class="keyword">() ;<br /></span><span class="default">$x</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">] = </span><span class="default">0 </span><span class="keyword">;<br /></span><span class="default">$x</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]++ ; </span><span class="comment">//error 'Indirect modification of overloaded element has no effect'<br /></span><span class="default">$x</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">] += </span><span class="default">1 </span><span class="keyword">; </span><span class="comment">// this works OK.<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121866">  <div class="votes">
    <div id="Vu121866">
    <a href="/manual/vote-note.php?id=121866&amp;page=class.arrayaccess&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121866">
    <a href="/manual/vote-note.php?id=121866&amp;page=class.arrayaccess&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121866" title="100% like this...">
    1
    </div>
  </div>
  <a href="#121866" class="name">
  <strong class="user"><em>headplan at gmail dot com</em></strong></a><a class="genanchor" href="#121866"> &para;</a><div class="date" title="2017-11-14 09:06"><strong>1 month ago</strong></div>
  <div class="text" id="Hcom121866">
<div class="phpcode"><code><span class="html">
整理前面各位大仙的解决方法.<br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">namespace </span><span class="default">InterfaceTest</span><span class="keyword">;<br /><br />use </span><span class="default">ArrayAccess</span><span class="keyword">;<br /><br />class </span><span class="default">TestArrayAccess </span><span class="keyword">implements </span><span class="default">ArrayAccess<br /></span><span class="keyword">{<br />&nbsp; &nbsp; </span><span class="comment"># 存储数据<br />&nbsp; &nbsp; </span><span class="keyword">private </span><span class="default">$data </span><span class="keyword">= [];<br /><br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * 以对象的方式访问数组中的数据<br />&nbsp; &nbsp;&nbsp; *<br />&nbsp; &nbsp;&nbsp; * @param $key<br />&nbsp; &nbsp;&nbsp; * @return mixed<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">__get</span><span class="keyword">(</span><span class="default">$key</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">data</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">];<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * 以对象方式添加一个数组元素<br />&nbsp; &nbsp;&nbsp; *<br />&nbsp; &nbsp;&nbsp; * @param $key<br />&nbsp; &nbsp;&nbsp; * @param $val<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">__set</span><span class="keyword">(</span><span class="default">$key</span><span class="keyword">, </span><span class="default">$val</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">data</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">] = </span><span class="default">$val</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * 以对象方式判断数组元素是否设置<br />&nbsp; &nbsp;&nbsp; *<br />&nbsp; &nbsp;&nbsp; * @param $key<br />&nbsp; &nbsp;&nbsp; * @return bool<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">__isset</span><span class="keyword">(</span><span class="default">$key</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return isset(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">data</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">]);<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * 以对象方式删除一个数组元素<br />&nbsp; &nbsp;&nbsp; *<br />&nbsp; &nbsp;&nbsp; * @param $key<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">__unset</span><span class="keyword">(</span><span class="default">$key</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; unset(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">data</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">]);<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * @param mixed $offset<br />&nbsp; &nbsp;&nbsp; * @return mixed|null<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">offsetGet</span><span class="keyword">(</span><span class="default">$offset</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">offsetExists</span><span class="keyword">(</span><span class="default">$offset</span><span class="keyword">) ? </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">data</span><span class="keyword">[</span><span class="default">$offset</span><span class="keyword">] : </span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * @param mixed $offset<br />&nbsp; &nbsp;&nbsp; * @param mixed $value<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">offsetSet</span><span class="keyword">(</span><span class="default">$offset</span><span class="keyword">, </span><span class="default">$value</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">is_null</span><span class="keyword">(</span><span class="default">$offset</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">data</span><span class="keyword">[] = </span><span class="default">$value</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">data</span><span class="keyword">[</span><span class="default">$offset</span><span class="keyword">] = </span><span class="default">$value</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * @param mixed $offset<br />&nbsp; &nbsp;&nbsp; * @return bool<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">offsetExists</span><span class="keyword">(</span><span class="default">$offset</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return isset(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">data</span><span class="keyword">[</span><span class="default">$offset</span><span class="keyword">]);<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * @param mixed $offset<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">offsetUnset</span><span class="keyword">(</span><span class="default">$offset</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">offsetExists</span><span class="keyword">(</span><span class="default">$offset</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; unset(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">data</span><span class="keyword">[</span><span class="default">$offset</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * @return array<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">public function &amp;</span><span class="default">__invoke</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">data</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$testArrayAccess </span><span class="keyword">= new \</span><span class="default">InterfaceTest</span><span class="keyword">\</span><span class="default">TestArrayAccess</span><span class="keyword">();<br /><br /></span><span class="default">$testArrayAccess</span><span class="keyword">[</span><span class="string">'one'</span><span class="keyword">] = </span><span class="string">'小明'</span><span class="keyword">;<br /></span><span class="default">$testArrayAccess</span><span class="keyword">-&gt;</span><span class="default">two </span><span class="keyword">= </span><span class="string">'小红'</span><span class="keyword">;<br /></span><span class="default">$testArrayAccess</span><span class="keyword">[</span><span class="string">'three'</span><span class="keyword">] = </span><span class="string">'邪皇'</span><span class="keyword">;<br /></span><span class="default">$testArrayAccess</span><span class="keyword">-&gt;</span><span class="default">four </span><span class="keyword">= </span><span class="string">'魔伶'</span><span class="keyword">; </span><span class="comment"># 调用ArrayAndObjectAccess::__set<br /></span><span class="default">$testArrayAccess</span><span class="keyword">[</span><span class="string">'five'</span><span class="keyword">] = </span><span class="string">'天尊'</span><span class="keyword">; </span><span class="comment"># 调用ArrayAndObjectAccess::offsetSet<br /><br /></span><span class="default">var_dump</span><span class="keyword">(isset(</span><span class="default">$testArrayAccess</span><span class="keyword">-&gt;</span><span class="default">one</span><span class="keyword">)); </span><span class="comment"># 调用ArrayAndObjectAccess::__isset<br /></span><span class="keyword">unset(</span><span class="default">$testArrayAccess</span><span class="keyword">-&gt;</span><span class="default">two</span><span class="keyword">); </span><span class="comment"># 调用ArrayAndObjectAccess::__unset<br /><br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$testArrayAccess</span><span class="keyword">-&gt;</span><span class="default">one</span><span class="keyword">); </span><span class="comment"># 调用ArrayAndObjectAccess::__get<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$testArrayAccess</span><span class="keyword">-&gt;</span><span class="default">three</span><span class="keyword">);<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$testArrayAccess</span><span class="keyword">-&gt;</span><span class="default">four</span><span class="keyword">);<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$testArrayAccess</span><span class="keyword">-&gt;</span><span class="default">five</span><span class="keyword">);<br /><br /></span><span class="default">var_dump</span><span class="keyword">(isset(</span><span class="default">$testArrayAccess</span><span class="keyword">[</span><span class="string">'one'</span><span class="keyword">])); </span><span class="comment"># 调用ArrayAndObjectAccess::offsetExists<br /></span><span class="keyword">unset(</span><span class="default">$testArrayAccess</span><span class="keyword">[</span><span class="string">'two'</span><span class="keyword">]); </span><span class="comment"># 调用ArrayAndObjectAccess::offsetUnset<br /><br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$testArrayAccess</span><span class="keyword">[</span><span class="string">'one'</span><span class="keyword">]); </span><span class="comment"># 调用ArrayAndObjectAccess::offsetGet<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$testArrayAccess</span><span class="keyword">[</span><span class="string">'three'</span><span class="keyword">]);<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$testArrayAccess</span><span class="keyword">[</span><span class="string">'four'</span><span class="keyword">]);<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$testArrayAccess</span><span class="keyword">[</span><span class="string">'five'</span><span class="keyword">]);<br /><br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$testArrayAccess</span><span class="keyword">);<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$testArrayAccess</span><span class="keyword">());<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">array_values</span><span class="keyword">(</span><span class="default">$testArrayAccess</span><span class="keyword">()));<br /></span><span class="default">$var </span><span class="keyword">= </span><span class="string">'hi'</span><span class="keyword">;<br /></span><span class="default">$testArrayAccess</span><span class="keyword">[</span><span class="string">'a'</span><span class="keyword">] = </span><span class="default">$var</span><span class="keyword">;<br /></span><span class="default">$testArrayAccess</span><span class="keyword">()[</span><span class="string">'b'</span><span class="keyword">] = &amp;</span><span class="default">$var</span><span class="keyword">;<br /></span><span class="default">$var </span><span class="keyword">= </span><span class="string">'baby'</span><span class="keyword">;<br /></span><span class="default">array_push</span><span class="keyword">(</span><span class="default">$testArrayAccess</span><span class="keyword">(),</span><span class="string">'test'</span><span class="keyword">); </span><span class="comment"># int array_push ( array &amp;$array , mixed $value1 [, mixed $... ] )<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$testArrayAccess</span><span class="keyword">);<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">reset</span><span class="keyword">(</span><span class="default">$testArrayAccess</span><span class="keyword">())); </span><span class="comment"># mixed reset ( array &amp;$array )<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">array_key_exists</span><span class="keyword">(</span><span class="string">'five'</span><span class="keyword">,</span><span class="default">$testArrayAccess</span><span class="keyword">()));</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121594">  <div class="votes">
    <div id="Vu121594">
    <a href="/manual/vote-note.php?id=121594&amp;page=class.arrayaccess&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121594">
    <a href="/manual/vote-note.php?id=121594&amp;page=class.arrayaccess&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121594" title="100% like this...">
    1
    </div>
  </div>
  <a href="#121594" class="name">
  <strong class="user"><em>Soaku</em></strong></a><a class="genanchor" href="#121594"> &para;</a><div class="date" title="2017-09-01 04:01"><strong>3 months ago</strong></div>
  <div class="text" id="Hcom121594">
<div class="phpcode"><code><span class="html">
When working in namespaces ALWAYS remember to prefix the ArrayAccess name with \. It will think you mean an undefined interface.<br /><br />This is a bit weird, because this interface *could* be global - You cannot define a class or interface with this name, even in a namespace.<br /><br />Hope it helps someone.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121271">  <div class="votes">
    <div id="Vu121271">
    <a href="/manual/vote-note.php?id=121271&amp;page=class.arrayaccess&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121271">
    <a href="/manual/vote-note.php?id=121271&amp;page=class.arrayaccess&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121271" title="100% like this...">
    1
    </div>
  </div>
  <a href="#121271" class="name">
  <strong class="user"><em>igorsantos07 at gibberish dot gmail dot com</em></strong></a><a class="genanchor" href="#121271"> &para;</a><div class="date" title="2017-06-24 07:48"><strong>5 months ago</strong></div>
  <div class="text" id="Hcom121271">
<div class="phpcode"><code><span class="html">
Building on comments about incompatibility between plain arrays and ArrayAccess objects, many (most?) of the array_* methods won't work with ArrayAccess objects.<br />Simple calls such as sizeof() work, but array_values() will throw an error, for instance.<br /><br />Don't expect much magic when implementing this.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121077">  <div class="votes">
    <div id="Vu121077">
    <a href="/manual/vote-note.php?id=121077&amp;page=class.arrayaccess&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121077">
    <a href="/manual/vote-note.php?id=121077&amp;page=class.arrayaccess&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121077" title="100% like this...">
    1
    </div>
  </div>
  <a href="#121077" class="name">
  <strong class="user"><em>Aussie Bags</em></strong></a><a class="genanchor" href="#121077"> &para;</a><div class="date" title="2017-05-12 10:57"><strong>7 months ago</strong></div>
  <div class="text" id="Hcom121077">
<div class="phpcode"><code><span class="html">
Although $offset can be anything, a string that looks like an integer is cast to integer before the call to any of the methods.<br /><br />$x[1]&nbsp; offset is integer 1<br />$x['1'] offset is integer 1<br />$x['1.'] offset is string '1.'</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119401">  <div class="votes">
    <div id="Vu119401">
    <a href="/manual/vote-note.php?id=119401&amp;page=class.arrayaccess&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119401">
    <a href="/manual/vote-note.php?id=119401&amp;page=class.arrayaccess&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119401" title="50% like this...">
    0
    </div>
  </div>
  <a href="#119401" class="name">
  <strong class="user"><em>luc at s dot illi dot be</em></strong></a><a class="genanchor" href="#119401"> &para;</a><div class="date" title="2016-05-28 09:51"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119401">
<div class="phpcode"><code><span class="html">
Note, that the ArrayAccess class is not limited to scalar keys:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">A </span><span class="keyword">implements </span><span class="default">ArrayAccess<br /></span><span class="keyword">{<br />&nbsp; &nbsp; function </span><span class="default">offsetSet</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">func_get_args</span><span class="keyword">());<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">offsetGet</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">func_get_args</span><span class="keyword">());<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">offsetExists</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">func_get_args</span><span class="keyword">());<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">offsetUnset</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">func_get_args</span><span class="keyword">());<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">B</span><span class="keyword">{}<br />class </span><span class="default">C</span><span class="keyword">{}<br /><br /></span><span class="default">$A </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">;<br /></span><span class="default">$A</span><span class="keyword">[[</span><span class="default">1</span><span class="keyword">,</span><span class="default">2</span><span class="keyword">,</span><span class="default">3</span><span class="keyword">]] = [</span><span class="default">4</span><span class="keyword">,</span><span class="default">5</span><span class="keyword">,</span><span class="default">6</span><span class="keyword">];<br /></span><span class="default">$A</span><span class="keyword">[new </span><span class="default">B</span><span class="keyword">] = new </span><span class="default">C</span><span class="keyword">;<br /><br /></span><span class="comment">/*<br />array(2) {<br />&nbsp; [0]=&gt;<br />&nbsp; array(3) {<br />&nbsp; &nbsp; [0]=&gt;<br />&nbsp; &nbsp; int(1)<br />&nbsp; &nbsp; [1]=&gt;<br />&nbsp; &nbsp; int(2)<br />&nbsp; &nbsp; [2]=&gt;<br />&nbsp; &nbsp; int(3)<br />&nbsp; }<br />&nbsp; [1]=&gt;<br />&nbsp; array(3) {<br />&nbsp; &nbsp; [0]=&gt;<br />&nbsp; &nbsp; int(4)<br />&nbsp; &nbsp; [1]=&gt;<br />&nbsp; &nbsp; int(5)<br />&nbsp; &nbsp; [2]=&gt;<br />&nbsp; &nbsp; int(6)<br />&nbsp; }<br />}<br />array(2) {<br />&nbsp; [0]=&gt;<br />&nbsp; object(web\B)#3 (0) {<br />&nbsp; }<br />&nbsp; [1]=&gt;<br />&nbsp; object(web\C)#4 (0) {<br />&nbsp; }<br />}<br />*/<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=class.arrayaccess&amp;redirect=http://php.net/manual/en/class.arrayaccess.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="reserved.interfaces.php">Predefined Interfaces and Classes</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="class.traversable.php" title="Traversable">Traversable</a>
                        </li>
                          
                        <li class="">
                            <a href="class.iterator.php" title="Iterator">Iterator</a>
                        </li>
                          
                        <li class="">
                            <a href="class.iteratoraggregate.php" title="IteratorAggregate">IteratorAggregate</a>
                        </li>
                          
                        <li class="">
                            <a href="class.throwable.php" title="Throwable">Throwable</a>
                        </li>
                          
                        <li class="current">
                            <a href="class.arrayaccess.php" title="ArrayAccess">ArrayAccess</a>
                        </li>
                          
                        <li class="">
                            <a href="class.serializable.php" title="Serializable">Serializable</a>
                        </li>
                          
                        <li class="">
                            <a href="class.closure.php" title="Closure">Closure</a>
                        </li>
                          
                        <li class="">
                            <a href="class.generator.php" title="Generator">Generator</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

