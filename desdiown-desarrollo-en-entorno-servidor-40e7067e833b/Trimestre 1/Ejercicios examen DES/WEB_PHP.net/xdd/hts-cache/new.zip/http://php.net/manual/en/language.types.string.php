<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Strings - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.types.string.php">
 <link rel="shorturl" href="http://php.net/types.string">
 <link rel="alternate" href="http://php.net/types.string" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.types.php">
 <link rel="prev" href="http://php.net/manual/en/language.types.float.php">
 <link rel="next" href="http://php.net/manual/en/language.types.array.php">

 <link rel="alternate" href="http://php.net/manual/en/language.types.string.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.types.string.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.types.string.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.types.string.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.types.string.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.types.string.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.types.string.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.types.string.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.types.string.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.types.string.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.types.string.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.types.array.php">
          Arrays &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.types.float.php">
          &laquo; Floating point numbers        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.types.php'>Types</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.types.string.php' selected="selected">English</option>
            <option value='pt_BR/language.types.string.php'>Brazilian Portuguese</option>
            <option value='zh/language.types.string.php'>Chinese (Simplified)</option>
            <option value='fr/language.types.string.php'>French</option>
            <option value='de/language.types.string.php'>German</option>
            <option value='ja/language.types.string.php'>Japanese</option>
            <option value='ro/language.types.string.php'>Romanian</option>
            <option value='ru/language.types.string.php'>Russian</option>
            <option value='es/language.types.string.php'>Spanish</option>
            <option value='tr/language.types.string.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.types.string.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.types.string">Report a Bug</a>
    </div>
  </div><div id="language.types.string" class="sect1">
 <h2 class="title">Strings</h2>

 <p class="para">
  A <span class="type"><a href="language.types.string.php" class="type string">string</a></span> is series of characters, where a character is
  the same as a byte. This means that PHP only supports a 256-character set,
  and hence does not offer native Unicode support. See
  <a href="language.types.string.php#language.types.string.details" class="link">details of the string
  type</a>.
 </p>

 <blockquote class="note"><p><strong class="note">Note</strong>: 
  <span class="simpara">
   As of PHP 7.0.0, there are no particular restrictions regarding the length of
   a <span class="type"><a href="language.types.string.php" class="type string">string</a></span> on 64-bit builds. On 32-bit builds and in earlier
   versions, a
   <span class="type"><a href="language.types.string.php" class="type string">string</a></span> can be as large as up to 2GB (2147483647 bytes maximum)
  </span>
 </p></blockquote>

 <div class="sect2" id="language.types.string.syntax">
  <h3 class="title">Syntax</h3>

  <p class="para">
   A <span class="type"><a href="language.types.string.php" class="type string">string</a></span> literal can be specified in four different ways:
  </p>

  <ul class="itemizedlist">
   <li class="listitem">
    <span class="simpara">
     <a href="language.types.string.php#language.types.string.syntax.single" class="link">single quoted</a>
    </span>
   </li>
   <li class="listitem">
    <span class="simpara">
     <a href="language.types.string.php#language.types.string.syntax.double" class="link">double quoted</a>
    </span>
   </li>
   <li class="listitem">
    <span class="simpara">
     <a href="language.types.string.php#language.types.string.syntax.heredoc" class="link">heredoc syntax</a>
    </span>
   </li>
   <li class="listitem">
    <span class="simpara">
     <a href="language.types.string.php#language.types.string.syntax.nowdoc" class="link">nowdoc syntax</a>
     (since PHP 5.3.0)
    </span>
   </li>
  </ul>

  <div class="sect3" id="language.types.string.syntax.single">
   <h4 class="title">Single quoted</h4>

   <p class="para">
    The simplest way to specify a <span class="type"><a href="language.types.string.php" class="type string">string</a></span> is to enclose it in single
    quotes (the character <em>&#039;</em>).
   </p>

   <p class="para">
    To specify a literal single quote, escape it with a backslash
    (<em>\</em>). To specify a literal backslash, double it
    (<em>\\</em>). All other instances of backslash will be treated
    as a literal backslash: this means that the other escape sequences you
    might be used to, such as <em>\r</em> or <em>\n</em>,
    will be output literally as specified rather than having any special
    meaning.
   </p>

   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <span class="simpara">
     Unlike the <a href="language.types.string.php#language.types.string.syntax.double" class="link">double-quoted</a>
     and <a href="language.types.string.php#language.types.string.syntax.heredoc" class="link">heredoc</a> syntaxes,
     <a href="language.variables.php" class="link">variables</a> and escape sequences
     for special characters will <em class="emphasis">not</em> be expanded when they
     occur in single quoted <span class="type"><a href="language.types.string.php" class="type string">string</a></span>s.
    </span>
   </p></blockquote>

   <div class="informalexample">
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">'this&nbsp;is&nbsp;a&nbsp;simple&nbsp;string'</span><span style="color: #007700">;<br /><br />echo&nbsp;</span><span style="color: #DD0000">'You&nbsp;can&nbsp;also&nbsp;have&nbsp;embedded&nbsp;newlines&nbsp;in&nbsp;<br />strings&nbsp;this&nbsp;way&nbsp;as&nbsp;it&nbsp;is<br />okay&nbsp;to&nbsp;do'</span><span style="color: #007700">;<br /><br /></span><span style="color: #FF8000">//&nbsp;Outputs:&nbsp;Arnold&nbsp;once&nbsp;said:&nbsp;"I'll&nbsp;be&nbsp;back"<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">'Arnold&nbsp;once&nbsp;said:&nbsp;"I\'ll&nbsp;be&nbsp;back"'</span><span style="color: #007700">;<br /><br /></span><span style="color: #FF8000">//&nbsp;Outputs:&nbsp;You&nbsp;deleted&nbsp;C:\*.*?<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">'You&nbsp;deleted&nbsp;C:\\*.*?'</span><span style="color: #007700">;<br /><br /></span><span style="color: #FF8000">//&nbsp;Outputs:&nbsp;You&nbsp;deleted&nbsp;C:\*.*?<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">'You&nbsp;deleted&nbsp;C:\*.*?'</span><span style="color: #007700">;<br /><br /></span><span style="color: #FF8000">//&nbsp;Outputs:&nbsp;This&nbsp;will&nbsp;not&nbsp;expand:&nbsp;\n&nbsp;a&nbsp;newline<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">'This&nbsp;will&nbsp;not&nbsp;expand:&nbsp;\n&nbsp;a&nbsp;newline'</span><span style="color: #007700">;<br /><br /></span><span style="color: #FF8000">//&nbsp;Outputs:&nbsp;Variables&nbsp;do&nbsp;not&nbsp;$expand&nbsp;$either<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">'Variables&nbsp;do&nbsp;not&nbsp;$expand&nbsp;$either'</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>

  </div>

  <div class="sect3" id="language.types.string.syntax.double">
   <h4 class="title">Double quoted</h4>

   <p class="para">
    If the <span class="type"><a href="language.types.string.php" class="type string">string</a></span> is enclosed in double-quotes (&quot;), PHP will
    interpret the following escape sequences for special characters:
   </p>

   <table class="doctable table">
    <caption><strong>Escaped characters</strong></caption>

    
     <thead>
      <tr>
       <th>Sequence</th>
       <th>Meaning</th>
      </tr>

     </thead>


     <tbody class="tbody">
      <tr>
       <td><em>\n</em></td>
       <td>linefeed (LF or 0x0A (10) in ASCII)</td>
      </tr>

      <tr>
       <td><em>\r</em></td>
       <td>carriage return (CR or 0x0D (13) in ASCII)</td>
      </tr>

      <tr>
       <td><em>\t</em></td>
       <td>horizontal tab (HT or 0x09 (9) in ASCII)</td>
      </tr>

      <tr>
       <td><em>\v</em></td>
       <td>vertical tab (VT or 0x0B (11) in ASCII) (since PHP 5.2.5)</td>
      </tr>

      <tr>
       <td><em>\e</em></td>
       <td>escape (ESC or 0x1B (27) in ASCII) (since PHP 5.4.4)</td>
      </tr>

      <tr>
       <td><em>\f</em></td>
       <td>form feed (FF or 0x0C (12) in ASCII) (since PHP 5.2.5)</td>
      </tr>

      <tr>
       <td><em>\\</em></td>
       <td>backslash</td>
      </tr>

      <tr>
       <td><em>\$</em></td>
       <td>dollar sign</td>
      </tr>

      <tr>
       <td><em>\&quot;</em></td>
       <td>double-quote</td>
      </tr>

      <tr>
       <td><em>\[0-7]{1,3}</em></td>
       <td>
        the sequence of characters matching the regular expression is a
        character in octal notation, which silently overflows to fit in a byte
        (e.g. &quot;\400&quot; === &quot;\000&quot;)
       </td>
      </tr>

      <tr>
       <td><em>\x[0-9A-Fa-f]{1,2}</em></td>
       <td>
        the sequence of characters matching the regular expression is a
        character in hexadecimal notation
       </td>
      </tr>

      <tr>
       <td><em>\u{[0-9A-Fa-f]+}</em></td>
       <td>
        the sequence of characters matching the regular expression is a
        Unicode codepoint, which will be output to the string as that
        codepoint&#039;s UTF-8 representation (added in PHP 7.0.0)
       </td>
      </tr>

     </tbody>
    
   </table>


   <p class="para">
    As in single quoted <span class="type"><a href="language.types.string.php" class="type string">string</a></span>s, escaping any other character will
    result in the backslash being printed too. Before PHP 5.1.1, the backslash
    in <em>\{$var}</em> had not been printed.
   </p>

   <p class="para">
    The most important feature of double-quoted <span class="type"><a href="language.types.string.php" class="type string">string</a></span>s is the fact
    that variable names will be expanded. See
    <a href="language.types.string.php#language.types.string.parsing" class="link">string parsing</a> for
    details.
   </p>
  </div>

  <div class="sect3" id="language.types.string.syntax.heredoc">
   <h4 class="title">Heredoc</h4>

   <p class="simpara">
    A third way to delimit <span class="type"><a href="language.types.string.php" class="type string">string</a></span>s is the heredoc syntax:
    <em>&lt;&lt;&lt;</em>. After this operator, an identifier is
    provided, then a newline. The <span class="type"><a href="language.types.string.php" class="type string">string</a></span> itself follows, and then
    the same identifier again to close the quotation.
   </p>

   <p class="simpara">
    The closing identifier <em class="emphasis">must</em> begin in the first column
    of the line. Also, the identifier must follow the same naming rules as any
    other label in PHP: it must contain only alphanumeric characters and
    underscores, and must start with a non-digit character or underscore.
   </p>
   
   <div class="warning"><strong class="warning">Warning</strong>
    <p class="simpara">
     It is very important to note that the line with the closing identifier must
     contain no other characters, except a semicolon (<em>;</em>). 
     That means especially that the identifier
     <em class="emphasis">may not be indented</em>, and there may not be any spaces
     or tabs before or after the semicolon. It&#039;s also important to realize that
     the first character before the closing identifier must be a newline as
     defined by the local operating system. This is <em>\n</em> on
     UNIX systems, including Mac OS X. The closing delimiter must also be 
     followed by a newline.
    </p>

    <p class="simpara">
     If this rule is broken and the closing identifier is not &quot;clean&quot;, it will
     not be considered a closing identifier, and PHP will continue looking for
     one. If a proper closing identifier is not found before the end of the
     current file, a parse error will result at the last line.
    </p>

    <div class="example" id="example-44">
     <p><strong>Example #1 Invalid example</strong></p>
     <div class="example-contents">
      
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">foo&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;</span><span style="color: #0000BB">$bar&nbsp;</span><span style="color: #007700">=&nbsp;&lt;&lt;&lt;EOT<br /></span><span style="color: #DD0000">bar<br />&nbsp;&nbsp;&nbsp;&nbsp;EOT;<br />}<br />//&nbsp;Identifier&nbsp;must&nbsp;not&nbsp;be&nbsp;indented<br />?&gt;</span>
</span>
</code></div>
     </div>

    </div>
    <div class="example" id="example-45">
     <p><strong>Example #2 Valid example</strong></p>
     <div class="example-contents">
      
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">foo&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;</span><span style="color: #0000BB">$bar&nbsp;</span><span style="color: #007700">=&nbsp;&lt;&lt;&lt;EOT<br /></span><span style="color: #DD0000">bar<br /></span><span style="color: #007700">EOT;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>

    <p class="para">
     Heredocs can not be used for initializing class properties. Since PHP 5.3,
     this limitation is valid only for heredocs containing variables.
    </p>
    
   </div>

   <p class="para">
    Heredoc text behaves just like a double-quoted <span class="type"><a href="language.types.string.php" class="type string">string</a></span>, without
    the double quotes. This means that quotes in a heredoc do not need to be
    escaped, but the escape codes listed above can still be used. Variables are
    expanded, but the same care must be taken when expressing complex variables
    inside a heredoc as with <span class="type"><a href="language.types.string.php" class="type string">string</a></span>s.
   </p>

   <div class="example" id="example-46"> 
    <p><strong>Example #3 Heredoc string quoting example</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$str&nbsp;</span><span style="color: #007700">=&nbsp;&lt;&lt;&lt;EOD<br /></span><span style="color: #DD0000">Example&nbsp;of&nbsp;string<br />spanning&nbsp;multiple&nbsp;lines<br />using&nbsp;heredoc&nbsp;syntax.<br /></span><span style="color: #007700">EOD;<br /><br /></span><span style="color: #FF8000">/*&nbsp;More&nbsp;complex&nbsp;example,&nbsp;with&nbsp;variables.&nbsp;*/<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">foo<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;var&nbsp;</span><span style="color: #0000BB">$foo</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;var&nbsp;</span><span style="color: #0000BB">$bar</span><span style="color: #007700">;<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;function&nbsp;</span><span style="color: #0000BB">__construct</span><span style="color: #007700">()<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">foo&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'Foo'</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">bar&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">'Bar1'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'Bar2'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'Bar3'</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br /></span><span style="color: #0000BB">$foo&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">foo</span><span style="color: #007700">();<br /></span><span style="color: #0000BB">$name&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'MyName'</span><span style="color: #007700">;<br /><br />echo&nbsp;&lt;&lt;&lt;EOT<br /></span><span style="color: #DD0000">My&nbsp;name&nbsp;is&nbsp;"</span><span style="color: #0000BB">$name</span><span style="color: #DD0000">".&nbsp;I&nbsp;am&nbsp;printing&nbsp;some&nbsp;</span><span style="color: #0000BB">$foo</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">foo</span><span style="color: #DD0000">.<br />Now,&nbsp;I&nbsp;am&nbsp;printing&nbsp;some&nbsp;</span><span style="color: #007700">{</span><span style="color: #0000BB">$foo</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">bar</span><span style="color: #007700">[</span><span style="color: #0000BB">1</span><span style="color: #007700">]}</span><span style="color: #DD0000">.<br />This&nbsp;should&nbsp;print&nbsp;a&nbsp;capital&nbsp;'A':&nbsp;\x41<br /></span><span style="color: #007700">EOT;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

    <div class="example-contents"><p>The above example will output:</p></div>
    <div class="example-contents screen">
<div class="cdata"><pre>
My name is &quot;MyName&quot;. I am printing some Foo.
Now, I am printing some Bar2.
This should print a capital &#039;A&#039;: A</pre></div>
    </div>
   </div>

   <p class="para">
    It is also possible to use the Heredoc syntax to pass data to function 
    arguments:
   </p>

   <div class="example" id="example-47"> 
    <p><strong>Example #4 Heredoc in arguments example</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />var_dump</span><span style="color: #007700">(array(&lt;&lt;&lt;EOD<br /></span><span style="color: #DD0000">foobar!<br /></span><span style="color: #007700">EOD<br />));<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>

   <p class="para">
    As of PHP 5.3.0, it&#039;s possible to initialize static variables and class 
    properties/constants using the Heredoc syntax:
   </p>

   <div class="example" id="example-48"> 
    <p><strong>Example #5 Using Heredoc to initialize static values</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #FF8000">//&nbsp;Static&nbsp;variables<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">foo</span><span style="color: #007700">()<br />{<br />&nbsp;&nbsp;&nbsp;&nbsp;static&nbsp;</span><span style="color: #0000BB">$bar&nbsp;</span><span style="color: #007700">=&nbsp;&lt;&lt;&lt;LABEL<br /></span><span style="color: #DD0000">Nothing&nbsp;in&nbsp;here...<br /></span><span style="color: #007700">LABEL;<br />}<br /><br /></span><span style="color: #FF8000">//&nbsp;Class&nbsp;properties/constants<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">foo<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;const&nbsp;</span><span style="color: #0000BB">BAR&nbsp;</span><span style="color: #007700">=&nbsp;&lt;&lt;&lt;FOOBAR<br /></span><span style="color: #DD0000">Constant&nbsp;example<br /></span><span style="color: #007700">FOOBAR;<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;</span><span style="color: #0000BB">$baz&nbsp;</span><span style="color: #007700">=&nbsp;&lt;&lt;&lt;FOOBAR<br /></span><span style="color: #DD0000">Property&nbsp;example<br /></span><span style="color: #007700">FOOBAR;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>

   <p class="para">
    Starting with PHP 5.3.0, the opening Heredoc identifier may optionally be 
    enclosed in double quotes:
   </p>

   <div class="example" id="example-49"> 
    <p><strong>Example #6 Using double quotes in Heredoc</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">echo&nbsp;&lt;&lt;&lt;"FOOBAR"<br /></span><span style="color: #DD0000">Hello&nbsp;World!<br /></span><span style="color: #007700">FOOBAR;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>

  </div>
  
  <div class="sect3" id="language.types.string.syntax.nowdoc">
   <h4 class="title">Nowdoc</h4>
   
   <p class="para">
    Nowdocs are to single-quoted strings what heredocs are to double-quoted
    strings. A nowdoc is specified similarly to a heredoc, but <em class="emphasis">no
    parsing is done</em> inside a nowdoc. The construct is ideal for
    embedding PHP code or other large blocks of text without the need for
    escaping. It shares some features in common with the SGML
    <em>&lt;![CDATA[ ]]&gt;</em> construct, in that it declares a
    block of text which is not for parsing.
   </p>
   
   <p class="para">
    A nowdoc is identified with the same <em>&lt;&lt;&lt;</em>
    sequence used for heredocs, but the identifier which follows is enclosed in
    single quotes, e.g. <em>&lt;&lt;&lt;&#039;EOT&#039;</em>. All the rules for
    heredoc identifiers also apply to nowdoc identifiers, especially those
    regarding the appearance of the closing identifier.
   </p>
   
   <div class="example" id="example-50">
    <p><strong>Example #7 Nowdoc string quoting example</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$str&nbsp;</span><span style="color: #007700">=&nbsp;&lt;&lt;&lt;'EOD'<br /></span><span style="color: #DD0000">Example&nbsp;of&nbsp;string<br />spanning&nbsp;multiple&nbsp;lines<br />using&nbsp;nowdoc&nbsp;syntax.<br /></span><span style="color: #007700">EOD;<br /><br /></span><span style="color: #FF8000">/*&nbsp;More&nbsp;complex&nbsp;example,&nbsp;with&nbsp;variables.&nbsp;*/<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">foo<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;</span><span style="color: #0000BB">$foo</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;</span><span style="color: #0000BB">$bar</span><span style="color: #007700">;<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;function&nbsp;</span><span style="color: #0000BB">__construct</span><span style="color: #007700">()<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">foo&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'Foo'</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">bar&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">'Bar1'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'Bar2'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'Bar3'</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br /></span><span style="color: #0000BB">$foo&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">foo</span><span style="color: #007700">();<br /></span><span style="color: #0000BB">$name&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'MyName'</span><span style="color: #007700">;<br /><br />echo&nbsp;&lt;&lt;&lt;'EOT'<br /></span><span style="color: #DD0000">My&nbsp;name&nbsp;is&nbsp;"$name".&nbsp;I&nbsp;am&nbsp;printing&nbsp;some&nbsp;$foo-&gt;foo.<br />Now,&nbsp;I&nbsp;am&nbsp;printing&nbsp;some&nbsp;{$foo-&gt;bar[1]}.<br />This&nbsp;should&nbsp;not&nbsp;print&nbsp;a&nbsp;capital&nbsp;'A':&nbsp;\x41<br /></span><span style="color: #007700">EOT;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

    <div class="example-contents"><p>The above example will output:</p></div>
    <div class="example-contents screen">
<div class="cdata"><pre>
My name is &quot;$name&quot;. I am printing some $foo-&gt;foo.
Now, I am printing some {$foo-&gt;bar[1]}.
This should not print a capital &#039;A&#039;: \x41</pre></div>
    </div>
   </div>
   
   <div class="example" id="example-51">
    <p><strong>Example #8 Static data example</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">foo&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;</span><span style="color: #0000BB">$bar&nbsp;</span><span style="color: #007700">=&nbsp;&lt;&lt;&lt;'EOT'<br /></span><span style="color: #DD0000">bar<br /></span><span style="color: #007700">EOT;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>

   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <p class="para">
     Nowdoc support was added in PHP 5.3.0.
    </p>
   </p></blockquote>

  </div>

  <div class="sect3" id="language.types.string.parsing">
   <h4 class="title">Variable parsing</h4>

   <p class="simpara">
    When a <span class="type"><a href="language.types.string.php" class="type string">string</a></span> is specified in double quotes or with heredoc,
    <a href="language.variables.php" class="link">variables</a> are parsed within it. 
   </p>

   <p class="simpara">
    There are two types of syntax: a
    <a href="language.types.string.php#language.types.string.parsing.simple" class="link">simple</a> one and a
    <a href="language.types.string.php#language.types.string.parsing.complex" class="link">complex</a> one.
    The simple syntax is the most common and convenient. It provides a way to
    embed a variable, an <span class="type"><a href="language.types.array.php" class="type array">array</a></span> value, or an <span class="type"><a href="language.types.object.php" class="type object">object</a></span>
    property in a <span class="type"><a href="language.types.string.php" class="type string">string</a></span> with a minimum of effort.
   </p>

   <p class="simpara">
    The complex syntax can be recognised by the
    curly braces surrounding the expression.
   </p>

   <div class="sect4" id="language.types.string.parsing.simple">
    <h5 class="title">Simple syntax</h5>

    <p class="simpara">
     If a dollar sign (<em>$</em>) is encountered, the parser will
     greedily take as many tokens as possible to form a valid variable name.
     Enclose the variable name in curly braces to explicitly specify the end of
     the name.
    </p>

    <div class="informalexample">
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$juice&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">"apple"</span><span style="color: #007700">;<br /><br />echo&nbsp;</span><span style="color: #DD0000">"He&nbsp;drank&nbsp;some&nbsp;</span><span style="color: #0000BB">$juice</span><span style="color: #DD0000">&nbsp;juice."</span><span style="color: #007700">.</span><span style="color: #0000BB">PHP_EOL</span><span style="color: #007700">;<br /></span><span style="color: #FF8000">//&nbsp;Invalid.&nbsp;"s"&nbsp;is&nbsp;a&nbsp;valid&nbsp;character&nbsp;for&nbsp;a&nbsp;variable&nbsp;name,&nbsp;but&nbsp;the&nbsp;variable&nbsp;is&nbsp;$juice.<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"He&nbsp;drank&nbsp;some&nbsp;juice&nbsp;made&nbsp;of&nbsp;</span><span style="color: #0000BB">$juices</span><span style="color: #DD0000">."</span><span style="color: #007700">;<br /></span><span style="color: #FF8000">//&nbsp;Valid.&nbsp;Explicitly&nbsp;specify&nbsp;the&nbsp;end&nbsp;of&nbsp;the&nbsp;variable&nbsp;name&nbsp;by&nbsp;enclosing&nbsp;it&nbsp;in&nbsp;braces:<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"He&nbsp;drank&nbsp;some&nbsp;juice&nbsp;made&nbsp;of&nbsp;</span><span style="color: #007700">${</span><span style="color: #0000BB">juice</span><span style="color: #007700">}</span><span style="color: #DD0000">s."</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

     <p class="para">The above example will output:</p>
     <div class="example-contents screen">
<div class="cdata"><pre>
He drank some apple juice.
He drank some juice made of .
He drank some juice made of apples.
</pre></div>
     </div>
    </div>

    <p class="simpara">
     Similarly, an <span class="type"><a href="language.types.array.php" class="type array">array</a></span> index or an <span class="type"><a href="language.types.object.php" class="type object">object</a></span> property
     can be parsed. With array indices, the closing square bracket
     (<em>]</em>) marks the end of the index. The same rules apply to
     object properties as to simple variables.
    </p>

    <div class="example" id="example-52"><p><strong>Example #9 Simple syntax example</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$juices&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">"apple"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"orange"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"koolaid1"&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">"purple"</span><span style="color: #007700">);<br /><br />echo&nbsp;</span><span style="color: #DD0000">"He&nbsp;drank&nbsp;some&nbsp;</span><span style="color: #0000BB">$juices</span><span style="color: #007700">[</span><span style="color: #0000BB">0</span><span style="color: #007700">]</span><span style="color: #DD0000">&nbsp;juice."</span><span style="color: #007700">.</span><span style="color: #0000BB">PHP_EOL</span><span style="color: #007700">;<br />echo&nbsp;</span><span style="color: #DD0000">"He&nbsp;drank&nbsp;some&nbsp;</span><span style="color: #0000BB">$juices</span><span style="color: #007700">[</span><span style="color: #0000BB">1</span><span style="color: #007700">]</span><span style="color: #DD0000">&nbsp;juice."</span><span style="color: #007700">.</span><span style="color: #0000BB">PHP_EOL</span><span style="color: #007700">;<br />echo&nbsp;</span><span style="color: #DD0000">"He&nbsp;drank&nbsp;some&nbsp;</span><span style="color: #0000BB">$juices</span><span style="color: #007700">[</span><span style="color: #0000BB">koolaid1</span><span style="color: #007700">]</span><span style="color: #DD0000">&nbsp;juice."</span><span style="color: #007700">.</span><span style="color: #0000BB">PHP_EOL</span><span style="color: #007700">;<br /><br />class&nbsp;</span><span style="color: #0000BB">people&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;</span><span style="color: #0000BB">$john&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">"John&nbsp;Smith"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;</span><span style="color: #0000BB">$jane&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">"Jane&nbsp;Smith"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;</span><span style="color: #0000BB">$robert&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">"Robert&nbsp;Paulsen"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;</span><span style="color: #0000BB">$smith&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">"Smith"</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #0000BB">$people&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">people</span><span style="color: #007700">();<br /><br />echo&nbsp;</span><span style="color: #DD0000">"</span><span style="color: #0000BB">$people</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">john</span><span style="color: #DD0000">&nbsp;drank&nbsp;some&nbsp;</span><span style="color: #0000BB">$juices</span><span style="color: #007700">[</span><span style="color: #0000BB">0</span><span style="color: #007700">]</span><span style="color: #DD0000">&nbsp;juice."</span><span style="color: #007700">.</span><span style="color: #0000BB">PHP_EOL</span><span style="color: #007700">;<br />echo&nbsp;</span><span style="color: #DD0000">"</span><span style="color: #0000BB">$people</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">john</span><span style="color: #DD0000">&nbsp;then&nbsp;said&nbsp;hello&nbsp;to&nbsp;</span><span style="color: #0000BB">$people</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">jane</span><span style="color: #DD0000">."</span><span style="color: #007700">.</span><span style="color: #0000BB">PHP_EOL</span><span style="color: #007700">;<br />echo&nbsp;</span><span style="color: #DD0000">"</span><span style="color: #0000BB">$people</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">john</span><span style="color: #DD0000">'s&nbsp;wife&nbsp;greeted&nbsp;</span><span style="color: #0000BB">$people</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">robert</span><span style="color: #DD0000">."</span><span style="color: #007700">.</span><span style="color: #0000BB">PHP_EOL</span><span style="color: #007700">;<br />echo&nbsp;</span><span style="color: #DD0000">"</span><span style="color: #0000BB">$people</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">robert</span><span style="color: #DD0000">&nbsp;greeted&nbsp;the&nbsp;two&nbsp;</span><span style="color: #0000BB">$people</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">smiths</span><span style="color: #DD0000">."</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;Won't&nbsp;work<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

     <div class="example-contents"><p>The above example will output:</p></div>
     <div class="example-contents screen">
<div class="cdata"><pre>
He drank some apple juice.
He drank some orange juice.
He drank some purple juice.
John Smith drank some apple juice.
John Smith then said hello to Jane Smith.
John Smith&#039;s wife greeted Robert Paulsen.
Robert Paulsen greeted the two .
</pre></div>
     </div>
    </div>

    <p class="simpara">
     As of PHP 7.1.0 also <em class="emphasis">negative</em> numeric indices are
     supported.
    </p>

    <div class="example" id="example-53"><p><strong>Example #10 Negative numeric indices</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$string&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'string'</span><span style="color: #007700">;<br />echo&nbsp;</span><span style="color: #DD0000">"The&nbsp;character&nbsp;at&nbsp;index&nbsp;-2&nbsp;is&nbsp;</span><span style="color: #0000BB">$string</span><span style="color: #007700">[-</span><span style="color: #0000BB">2</span><span style="color: #007700">]</span><span style="color: #DD0000">."</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">PHP_EOL</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$string</span><span style="color: #007700">[-</span><span style="color: #0000BB">3</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #DD0000">'o'</span><span style="color: #007700">;<br />echo&nbsp;</span><span style="color: #DD0000">"Changing&nbsp;the&nbsp;character&nbsp;at&nbsp;index&nbsp;-3&nbsp;to&nbsp;o&nbsp;gives&nbsp;</span><span style="color: #0000BB">$string</span><span style="color: #DD0000">."</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">PHP_EOL</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

     <div class="example-contents"><p>The above example will output:</p></div>
     <div class="example-contents screen">
<div class="cdata"><pre>
The character at index -2 is n.
Changing the character at index -3 to o gives strong.
</pre></div>
     </div>
    </div>

    <p class="simpara">
     For anything more complex, you should use the complex syntax.
    </p>
   </div>

   <div class="sect4" id="language.types.string.parsing.complex">
    <h5 class="title">Complex (curly) syntax</h5>

    <p class="simpara">
     This isn&#039;t called complex because the syntax is complex, but because it
     allows for the use of complex expressions.
    </p>

    <p class="simpara">
     Any scalar variable, array element or object property with a
     <span class="type"><a href="language.types.string.php" class="type string">string</a></span> representation can be included via this syntax.
     Simply write the expression the same way as it would appear outside the
     <span class="type"><a href="language.types.string.php" class="type string">string</a></span>, and then wrap it in <em>{</em> and
     <em>}</em>. Since <em>{</em> can not be escaped, this
     syntax will only be recognised when the <em>$</em> immediately
     follows the <em>{</em>. Use <em>{\$</em> to get a
     literal <em>{$</em>. Some examples to make it clear:
    </p>

    <div class="informalexample">
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #FF8000">//&nbsp;Show&nbsp;all&nbsp;errors<br /></span><span style="color: #0000BB">error_reporting</span><span style="color: #007700">(</span><span style="color: #0000BB">E_ALL</span><span style="color: #007700">);<br /><br /></span><span style="color: #0000BB">$great&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'fantastic'</span><span style="color: #007700">;<br /><br /></span><span style="color: #FF8000">//&nbsp;Won't&nbsp;work,&nbsp;outputs:&nbsp;This&nbsp;is&nbsp;{&nbsp;fantastic}<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"This&nbsp;is&nbsp;{&nbsp;</span><span style="color: #0000BB">$great</span><span style="color: #DD0000">}"</span><span style="color: #007700">;<br /><br /></span><span style="color: #FF8000">//&nbsp;Works,&nbsp;outputs:&nbsp;This&nbsp;is&nbsp;fantastic<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"This&nbsp;is&nbsp;</span><span style="color: #007700">{</span><span style="color: #0000BB">$great</span><span style="color: #007700">}</span><span style="color: #DD0000">"</span><span style="color: #007700">;<br /><br /></span><span style="color: #FF8000">//&nbsp;Works<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"This&nbsp;square&nbsp;is&nbsp;</span><span style="color: #007700">{</span><span style="color: #0000BB">$square</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">width</span><span style="color: #007700">}</span><span style="color: #DD0000">00&nbsp;centimeters&nbsp;broad."</span><span style="color: #007700">;&nbsp;<br /><br /><br /></span><span style="color: #FF8000">//&nbsp;Works,&nbsp;quoted&nbsp;keys&nbsp;only&nbsp;work&nbsp;using&nbsp;the&nbsp;curly&nbsp;brace&nbsp;syntax<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"This&nbsp;works:&nbsp;</span><span style="color: #007700">{</span><span style="color: #0000BB">$arr</span><span style="color: #007700">[</span><span style="color: #DD0000">'key'</span><span style="color: #007700">]}</span><span style="color: #DD0000">"</span><span style="color: #007700">;<br /><br /><br /></span><span style="color: #FF8000">//&nbsp;Works<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"This&nbsp;works:&nbsp;</span><span style="color: #007700">{</span><span style="color: #0000BB">$arr</span><span style="color: #007700">[</span><span style="color: #0000BB">4</span><span style="color: #007700">][</span><span style="color: #0000BB">3</span><span style="color: #007700">]}</span><span style="color: #DD0000">"</span><span style="color: #007700">;<br /><br /></span><span style="color: #FF8000">//&nbsp;This&nbsp;is&nbsp;wrong&nbsp;for&nbsp;the&nbsp;same&nbsp;reason&nbsp;as&nbsp;$foo[bar]&nbsp;is&nbsp;wrong&nbsp;&nbsp;outside&nbsp;a&nbsp;string.<br />//&nbsp;In&nbsp;other&nbsp;words,&nbsp;it&nbsp;will&nbsp;still&nbsp;work,&nbsp;but&nbsp;only&nbsp;because&nbsp;PHP&nbsp;first&nbsp;looks&nbsp;for&nbsp;a<br />//&nbsp;constant&nbsp;named&nbsp;foo;&nbsp;an&nbsp;error&nbsp;of&nbsp;level&nbsp;E_NOTICE&nbsp;(undefined&nbsp;constant)&nbsp;will&nbsp;be<br />//&nbsp;thrown.<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"This&nbsp;is&nbsp;wrong:&nbsp;</span><span style="color: #007700">{</span><span style="color: #0000BB">$arr</span><span style="color: #007700">[</span><span style="color: #0000BB">foo</span><span style="color: #007700">][</span><span style="color: #0000BB">3</span><span style="color: #007700">]}</span><span style="color: #DD0000">"</span><span style="color: #007700">;&nbsp;<br /><br /></span><span style="color: #FF8000">//&nbsp;Works.&nbsp;When&nbsp;using&nbsp;multi-dimensional&nbsp;arrays,&nbsp;always&nbsp;use&nbsp;braces&nbsp;around&nbsp;arrays<br />//&nbsp;when&nbsp;inside&nbsp;of&nbsp;strings<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"This&nbsp;works:&nbsp;</span><span style="color: #007700">{</span><span style="color: #0000BB">$arr</span><span style="color: #007700">[</span><span style="color: #DD0000">'foo'</span><span style="color: #007700">][</span><span style="color: #0000BB">3</span><span style="color: #007700">]}</span><span style="color: #DD0000">"</span><span style="color: #007700">;<br /><br /></span><span style="color: #FF8000">//&nbsp;Works.<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"This&nbsp;works:&nbsp;"&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">$arr</span><span style="color: #007700">[</span><span style="color: #DD0000">'foo'</span><span style="color: #007700">][</span><span style="color: #0000BB">3</span><span style="color: #007700">];<br /><br />echo&nbsp;</span><span style="color: #DD0000">"This&nbsp;works&nbsp;too:&nbsp;</span><span style="color: #007700">{</span><span style="color: #0000BB">$obj</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">values</span><span style="color: #007700">[</span><span style="color: #0000BB">3</span><span style="color: #007700">]-&gt;</span><span style="color: #0000BB">name</span><span style="color: #007700">}</span><span style="color: #DD0000">"</span><span style="color: #007700">;<br /><br />echo&nbsp;</span><span style="color: #DD0000">"This&nbsp;is&nbsp;the&nbsp;value&nbsp;of&nbsp;the&nbsp;var&nbsp;named&nbsp;</span><span style="color: #0000BB">$name</span><span style="color: #DD0000">:&nbsp;</span><span style="color: #007700">{${</span><span style="color: #0000BB">$name</span><span style="color: #007700">}}</span><span style="color: #DD0000">"</span><span style="color: #007700">;<br /><br />echo&nbsp;</span><span style="color: #DD0000">"This&nbsp;is&nbsp;the&nbsp;value&nbsp;of&nbsp;the&nbsp;var&nbsp;named&nbsp;by&nbsp;the&nbsp;return&nbsp;value&nbsp;of&nbsp;getName():&nbsp;</span><span style="color: #007700">{${</span><span style="color: #0000BB">getName</span><span style="color: #007700">()}}</span><span style="color: #DD0000">"</span><span style="color: #007700">;<br /><br />echo&nbsp;</span><span style="color: #DD0000">"This&nbsp;is&nbsp;the&nbsp;value&nbsp;of&nbsp;the&nbsp;var&nbsp;named&nbsp;by&nbsp;the&nbsp;return&nbsp;value&nbsp;of&nbsp;\$object-&gt;getName():&nbsp;</span><span style="color: #007700">{${</span><span style="color: #0000BB">$object</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">getName</span><span style="color: #007700">()}}</span><span style="color: #DD0000">"</span><span style="color: #007700">;<br /><br /></span><span style="color: #FF8000">//&nbsp;Won't&nbsp;work,&nbsp;outputs:&nbsp;This&nbsp;is&nbsp;the&nbsp;return&nbsp;value&nbsp;of&nbsp;getName():&nbsp;{getName()}<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"This&nbsp;is&nbsp;the&nbsp;return&nbsp;value&nbsp;of&nbsp;getName():&nbsp;{getName()}"</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>

     </div>

    </div>

    <p class="para">
     It is also possible to access class properties using variables
     within strings using this syntax.
    </p>

   <div class="informalexample">
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">foo&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;var&nbsp;</span><span style="color: #0000BB">$bar&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'I&nbsp;am&nbsp;bar.'</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #0000BB">$foo&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">foo</span><span style="color: #007700">();<br /></span><span style="color: #0000BB">$bar&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'bar'</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$baz&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">'foo'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'bar'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'baz'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'quux'</span><span style="color: #007700">);<br />echo&nbsp;</span><span style="color: #DD0000">"</span><span style="color: #007700">{</span><span style="color: #0000BB">$foo</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">$bar</span><span style="color: #007700">}</span><span style="color: #DD0000">\n"</span><span style="color: #007700">;<br />echo&nbsp;</span><span style="color: #DD0000">"</span><span style="color: #007700">{</span><span style="color: #0000BB">$foo</span><span style="color: #007700">-&gt;{</span><span style="color: #0000BB">$baz</span><span style="color: #007700">[</span><span style="color: #0000BB">1</span><span style="color: #007700">]}}</span><span style="color: #DD0000">\n"</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   <p class="para">The above example will output:</p>
   <div class="example-contents screen">
<div class="cdata"><pre>
I am bar.
I am bar.
</pre></div>
   </div>
   </div>
    
    <blockquote class="note"><p><strong class="note">Note</strong>: 
     <p class="para">
      Functions, method calls, static class variables, and class
      constants inside <em>{$}</em> work since PHP
      5. However, the value accessed will be interpreted as the name
      of a variable in the scope in which the string is defined. Using
      single curly braces (<em>{}</em>) will not work for
      accessing the return values of functions or methods or the
      values of class constants or static class variables.
     </p>
    </p></blockquote>

    <div class="informalexample">
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #FF8000">//&nbsp;Show&nbsp;all&nbsp;errors.<br /></span><span style="color: #0000BB">error_reporting</span><span style="color: #007700">(</span><span style="color: #0000BB">E_ALL</span><span style="color: #007700">);<br /><br />class&nbsp;</span><span style="color: #0000BB">beers&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;const&nbsp;</span><span style="color: #0000BB">softdrink&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'rootbeer'</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;static&nbsp;</span><span style="color: #0000BB">$ale&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'ipa'</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #0000BB">$rootbeer&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'A&nbsp;&amp;&nbsp;W'</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$ipa&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'Alexander&nbsp;Keith\'s'</span><span style="color: #007700">;<br /><br /></span><span style="color: #FF8000">//&nbsp;This&nbsp;works;&nbsp;outputs:&nbsp;I'd&nbsp;like&nbsp;an&nbsp;A&nbsp;&amp;&nbsp;W<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"I'd&nbsp;like&nbsp;an&nbsp;</span><span style="color: #007700">{${</span><span style="color: #0000BB">beers</span><span style="color: #007700">::</span><span style="color: #0000BB">softdrink</span><span style="color: #007700">}}</span><span style="color: #DD0000">\n"</span><span style="color: #007700">;<br /><br /></span><span style="color: #FF8000">//&nbsp;This&nbsp;works&nbsp;too;&nbsp;outputs:&nbsp;I'd&nbsp;like&nbsp;an&nbsp;Alexander&nbsp;Keith's<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"I'd&nbsp;like&nbsp;an&nbsp;</span><span style="color: #007700">{${</span><span style="color: #0000BB">beers</span><span style="color: #007700">::</span><span style="color: #0000BB">$ale</span><span style="color: #007700">}}</span><span style="color: #DD0000">\n"</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>

   </div>
  </div>
  
  <div class="sect3" id="language.types.string.substr">
   <h4 class="title">String access and modification by character</h4>

   <p class="para">
    Characters within <span class="type"><a href="language.types.string.php" class="type string">string</a></span>s may be accessed and modified by
    specifying the zero-based offset of the desired character after the
    <span class="type"><a href="language.types.string.php" class="type string">string</a></span> using square <span class="type"><a href="language.types.array.php" class="type array">array</a></span> brackets, as in
    <var class="varname"><var class="varname">$str[42]</var></var>. Think of a <span class="type"><a href="language.types.string.php" class="type string">string</a></span> as an
    <span class="type"><a href="language.types.array.php" class="type array">array</a></span> of characters for this purpose. The functions
    <span class="function"><a href="function.substr.php" class="function">substr()</a></span> and <span class="function"><a href="function.substr-replace.php" class="function">substr_replace()</a></span>
    can be used when you want to extract or replace more than 1 character.
   </p>
   
   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <span class="simpara">
     As of PHP 7.1.0, negative string offsets are also supported. These specify
     the offset from the end of the string.
     Formerly, negative offsets emitted <strong><code>E_NOTICE</code></strong> for reading
     (yielding an empty string) and <strong><code>E_WARNING</code></strong> for writing
     (leaving the string untouched).
    </span>
   </p></blockquote>

   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <span class="simpara">
     <span class="type"><a href="language.types.string.php" class="type String">String</a></span>s may also be accessed using braces, as in
     <var class="varname"><var class="varname">$str{42}</var></var>, for the same purpose.
    </span>
   </p></blockquote>

   <div class="warning"><strong class="warning">Warning</strong>
    <p class="simpara">
     Writing to an out of range offset pads the string with spaces.
     Non-integer types are converted to integer.
     Illegal offset type emits <strong><code>E_NOTICE</code></strong>.
     Only the first character of an assigned string is used.
     As of PHP 7.1.0, assigning an empty string throws a fatal error. Formerly,
     it assigned a NULL byte.
    </p>
   </div>

   <div class="warning"><strong class="warning">Warning</strong>
    <p class="simpara">
     Internally, PHP strings are byte arrays. As a result, accessing or
     modifying a string using array brackets is not multi-byte safe, and
     should only be done with strings that are in a single-byte encoding such
     as ISO-8859-1.
    </p>
   </div>

   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <span class="simpara">
     As of PHP 7.1.0, applying the empty index operator on a string throws a fatal
     error. Formerly, the string was silently converted to an array.
    </span>
   </p></blockquote>

   <div class="example" id="example-54">
    <p><strong>Example #11 Some string examples</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #FF8000">//&nbsp;Get&nbsp;the&nbsp;first&nbsp;character&nbsp;of&nbsp;a&nbsp;string<br /></span><span style="color: #0000BB">$str&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'This&nbsp;is&nbsp;a&nbsp;test.'</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$first&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$str</span><span style="color: #007700">[</span><span style="color: #0000BB">0</span><span style="color: #007700">];<br /><br /></span><span style="color: #FF8000">//&nbsp;Get&nbsp;the&nbsp;third&nbsp;character&nbsp;of&nbsp;a&nbsp;string<br /></span><span style="color: #0000BB">$third&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$str</span><span style="color: #007700">[</span><span style="color: #0000BB">2</span><span style="color: #007700">];<br /><br /></span><span style="color: #FF8000">//&nbsp;Get&nbsp;the&nbsp;last&nbsp;character&nbsp;of&nbsp;a&nbsp;string.<br /></span><span style="color: #0000BB">$str&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'This&nbsp;is&nbsp;still&nbsp;a&nbsp;test.'</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$last&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$str</span><span style="color: #007700">[</span><span style="color: #0000BB">strlen</span><span style="color: #007700">(</span><span style="color: #0000BB">$str</span><span style="color: #007700">)-</span><span style="color: #0000BB">1</span><span style="color: #007700">];&nbsp;<br /><br /></span><span style="color: #FF8000">//&nbsp;Modify&nbsp;the&nbsp;last&nbsp;character&nbsp;of&nbsp;a&nbsp;string<br /></span><span style="color: #0000BB">$str&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'Look&nbsp;at&nbsp;the&nbsp;sea'</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$str</span><span style="color: #007700">[</span><span style="color: #0000BB">strlen</span><span style="color: #007700">(</span><span style="color: #0000BB">$str</span><span style="color: #007700">)-</span><span style="color: #0000BB">1</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #DD0000">'e'</span><span style="color: #007700">;<br /><br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
   
   <p class="para">
    As of PHP 5.4 string offsets have to either be integers or integer-like strings, otherwise a warning
    will be thrown. Previously an offset like <em>&quot;foo&quot;</em> was silently cast to <em>0</em>.
   </p>

   <div class="example" id="example-55">
    <p><strong>Example #12 Differences between PHP 5.3 and PHP 5.4</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$str&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'abc'</span><span style="color: #007700">;<br /><br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$str</span><span style="color: #007700">[</span><span style="color: #DD0000">'1'</span><span style="color: #007700">]);<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(isset(</span><span style="color: #0000BB">$str</span><span style="color: #007700">[</span><span style="color: #DD0000">'1'</span><span style="color: #007700">]));<br /><br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$str</span><span style="color: #007700">[</span><span style="color: #DD0000">'1.0'</span><span style="color: #007700">]);<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(isset(</span><span style="color: #0000BB">$str</span><span style="color: #007700">[</span><span style="color: #DD0000">'1.0'</span><span style="color: #007700">]));<br /><br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$str</span><span style="color: #007700">[</span><span style="color: #DD0000">'x'</span><span style="color: #007700">]);<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(isset(</span><span style="color: #0000BB">$str</span><span style="color: #007700">[</span><span style="color: #DD0000">'x'</span><span style="color: #007700">]));<br /><br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$str</span><span style="color: #007700">[</span><span style="color: #DD0000">'1x'</span><span style="color: #007700">]);<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(isset(</span><span style="color: #0000BB">$str</span><span style="color: #007700">[</span><span style="color: #DD0000">'1x'</span><span style="color: #007700">]));<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

    <div class="example-contents"><p>Output of the above example in PHP 5.3:</p></div>
    <div class="example-contents screen">
<div class="cdata"><pre>
string(1) &quot;b&quot;
bool(true)
string(1) &quot;b&quot;
bool(true)
string(1) &quot;a&quot;
bool(true)
string(1) &quot;b&quot;
bool(true)
</pre></div>
    </div>
    <div class="example-contents"><p>Output of the above example in PHP 5.4:</p></div>
    <div class="example-contents screen">
<div class="cdata"><pre>
string(1) &quot;b&quot;
bool(true)

Warning: Illegal string offset &#039;1.0&#039; in /tmp/t.php on line 7
string(1) &quot;b&quot;
bool(false)

Warning: Illegal string offset &#039;x&#039; in /tmp/t.php on line 9
string(1) &quot;a&quot;
bool(false)
string(1) &quot;b&quot;
bool(false)
</pre></div>
    </div>
   </div>

   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <p class="para">
     Accessing variables of other types (not including arrays or objects
     implementing the appropriate interfaces) using <em>[]</em> or
     <em>{}</em> silently returns <strong><code>NULL</code></strong>.
    </p>
   </p></blockquote>

   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <p class="para">
     PHP 5.5 added support for accessing characters within string literals
     using <em>[]</em> or <em>{}</em>.
    </p>
   </p></blockquote>
  </div>
 </div>

 <div class="sect2" id="language.types.string.useful-funcs">
  <h3 class="title">Useful functions and operators</h3>

  <p class="para">
   <span class="type"><a href="language.types.string.php" class="type String">String</a></span>s may be concatenated using the &#039;.&#039; (dot) operator. Note
   that the &#039;+&#039; (addition) operator will <em class="emphasis">not</em> work for this.
   See <a href="language.operators.string.php" class="link">String operators</a> for
   more information.
  </p>

  <p class="para">
   There are a number of useful functions for <span class="type"><a href="language.types.string.php" class="type string">string</a></span> manipulation.
  </p>

  <p class="simpara">
   See the <a href="ref.strings.php" class="link">string functions section</a> for
   general functions, and the <a href="ref.regex.php" class="link">regular expression
   functions</a> or the <a href="ref.pcre.php" class="link">Perl-compatible regular
   expression functions</a> for advanced find &amp; replace functionality.
  </p>

  <p class="simpara">
   There are also <a href="ref.url.php" class="link">functions for URL strings</a>, and
   functions to encrypt/decrypt strings
   (<a href="ref.mcrypt.php" class="link">mcrypt</a> and
   <a href="ref.mhash.php" class="link">mhash</a>).
  </p>

  <p class="simpara">
   Finally, see also the <a href="ref.ctype.php" class="link">character type
   functions</a>.
  </p>
 </div>

 <div class="sect2" id="language.types.string.casting">
  <h3 class="title">Converting to string</h3>
  
  <p class="para">
   A value can be converted to a <span class="type"><a href="language.types.string.php" class="type string">string</a></span> using the
   <em>(string)</em> cast or the <span class="function"><a href="function.strval.php" class="function">strval()</a></span> function.
   <span class="type"><a href="language.types.string.php" class="type String">String</a></span> conversion is automatically done in the scope of an
   expression where a <span class="type"><a href="language.types.string.php" class="type string">string</a></span> is needed. This happens when using the
   <span class="function"><a href="function.echo.php" class="function">echo</a></span> or <span class="function"><a href="function.print.php" class="function">print</a></span> functions, or when a
   variable is compared to a <span class="type"><a href="language.types.string.php" class="type string">string</a></span>. The sections on
   <a href="language.types.php" class="link">Types</a> and
   <a href="language.types.type-juggling.php" class="link">Type Juggling</a> will make
   the following clearer. See also the <span class="function"><a href="function.settype.php" class="function">settype()</a></span> function.
  </p>
  
  <p class="para">
   A <span class="type"><a href="language.types.boolean.php" class="type boolean">boolean</a></span> <strong><code>TRUE</code></strong> value is converted to the <span class="type"><a href="language.types.string.php" class="type string">string</a></span>
   <em>&quot;1&quot;</em>. <span class="type"><a href="language.types.boolean.php" class="type Boolean">Boolean</a></span> <strong><code>FALSE</code></strong> is converted to
   <em>&quot;&quot;</em> (the empty string). This allows conversion back and
   forth between <span class="type"><a href="language.types.boolean.php" class="type boolean">boolean</a></span> and <span class="type"><a href="language.types.string.php" class="type string">string</a></span> values.
  </p>

  <p class="para"> 
   An <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span> or <span class="type"><a href="language.types.float.php" class="type float">float</a></span> is converted to a
   <span class="type"><a href="language.types.string.php" class="type string">string</a></span> representing the number textually (including the
   exponent part for <span class="type"><a href="language.types.float.php" class="type float">float</a></span>s). Floating point numbers can be
   converted using exponential notation (<em>4.1E+6</em>).
  </p>

  <blockquote class="note"><p><strong class="note">Note</strong>: 
   <p class="para">
    The decimal point character is defined in the script&#039;s locale (category
    LC_NUMERIC). See the <span class="function"><a href="function.setlocale.php" class="function">setlocale()</a></span> function.
   </p>
  </p></blockquote>

  <p class="para">
   <span class="type"><a href="language.types.array.php" class="type Array">Array</a></span>s are always converted to the <span class="type"><a href="language.types.string.php" class="type string">string</a></span>
   <em>&quot;Array&quot;</em>; because of this, <span class="function"><a href="function.echo.php" class="function">echo</a></span> and
   <span class="function"><a href="function.print.php" class="function">print</a></span> can not by themselves show the contents of an
   <span class="type"><a href="language.types.array.php" class="type array">array</a></span>. To view a single element, use a construction such as
   <em>echo $arr[&#039;foo&#039;]</em>. See below for tips on viewing the entire
   contents.
  </p>

  <p class="para">
   In order to convert <span class="type"><a href="language.types.object.php" class="type object">object</a></span>s to <span class="type"><a href="language.types.string.php" class="type string">string</a></span> magic
   method <a href="language.oop5.magic.php" class="link">__toString</a> must be used.
  </p>

  <p class="para">
   <span class="type"><a href="language.types.resource.php" class="type Resource">Resource</a></span>s are always converted to <span class="type"><a href="language.types.string.php" class="type string">string</a></span>s with the
   structure <em>&quot;Resource id #1&quot;</em>, where <em>1</em>
   is the resource number assigned to the <span class="type"><a href="language.types.resource.php" class="type resource">resource</a></span> by PHP at
   runtime. While the exact structure of this string should not be relied on
   and is subject to change, it will always be unique for a given resource
   within the lifetime of a script being executed (ie a Web request or CLI
   process) and won&#039;t be reused. To get a <span class="type"><a href="language.types.resource.php" class="type resource">resource</a></span>&#039;s type, use
   the <span class="function"><a href="function.get-resource-type.php" class="function">get_resource_type()</a></span> function.
  </p>

  <p class="para">
   <strong><code>NULL</code></strong> is always converted to an empty string.
  </p>
  
  <p class="para">
   As stated above, directly converting an <span class="type"><a href="language.types.array.php" class="type array">array</a></span>,
   <span class="type"><a href="language.types.object.php" class="type object">object</a></span>, or <span class="type"><a href="language.types.resource.php" class="type resource">resource</a></span> to a <span class="type"><a href="language.types.string.php" class="type string">string</a></span> does
   not provide any useful information about the value beyond its type. See the
   functions <span class="function"><a href="function.print-r.php" class="function">print_r()</a></span> and <span class="function"><a href="function.var-dump.php" class="function">var_dump()</a></span> for
   more effective means of inspecting the contents of these types.
  </p>
  
  <p class="para">
   Most PHP values can also be converted to <span class="type"><a href="language.types.string.php" class="type string">string</a></span>s for permanent
   storage. This method is called serialization, and is performed by the
   <span class="function"><a href="function.serialize.php" class="function">serialize()</a></span> function. If the PHP engine was built with
   <a href="ref.wddx.php" class="link">WDDX</a> support, PHP values can also be
   serialized as well-formed XML text.
  </p>

 </div>

 <div class="sect2" id="language.types.string.conversion">
  <h3 class="title">String conversion to numbers</h3>

  <p class="simpara">
   When a <span class="type"><a href="language.types.string.php" class="type string">string</a></span> is evaluated in a numeric context, the resulting
   value and type are determined as follows.
  </p>

  <p class="simpara">
   If the <span class="type"><a href="language.types.string.php" class="type string">string</a></span> does not contain any of the characters &#039;.&#039;, &#039;e&#039;,
   or &#039;E&#039; and the numeric value fits into integer type limits (as defined by
   <strong><code>PHP_INT_MAX</code></strong>), the <span class="type"><a href="language.types.string.php" class="type string">string</a></span> will be evaluated
   as an <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span>. In all other cases it will be evaluated as a
   <span class="type"><a href="language.types.float.php" class="type float">float</a></span>.
  </p>

  <p class="para">
   The value is given by the initial portion of the <span class="type"><a href="language.types.string.php" class="type string">string</a></span>. If the
   <span class="type"><a href="language.types.string.php" class="type string">string</a></span> starts with valid numeric data, this will be the value
   used. Otherwise, the value will be 0 (zero). Valid numeric data is an
   optional sign, followed by one or more digits (optionally containing a
   decimal point), followed by an optional exponent. The exponent is an &#039;e&#039; or
   &#039;E&#039; followed by one or more digits.
  </p>

  <div class="informalexample">
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$foo&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1&nbsp;</span><span style="color: #007700">+&nbsp;</span><span style="color: #DD0000">"10.5"</span><span style="color: #007700">;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$foo&nbsp;is&nbsp;float&nbsp;(11.5)<br /></span><span style="color: #0000BB">$foo&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1&nbsp;</span><span style="color: #007700">+&nbsp;</span><span style="color: #DD0000">"-1.3e3"</span><span style="color: #007700">;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$foo&nbsp;is&nbsp;float&nbsp;(-1299)<br /></span><span style="color: #0000BB">$foo&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1&nbsp;</span><span style="color: #007700">+&nbsp;</span><span style="color: #DD0000">"bob-1.3e3"</span><span style="color: #007700">;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$foo&nbsp;is&nbsp;integer&nbsp;(1)<br /></span><span style="color: #0000BB">$foo&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1&nbsp;</span><span style="color: #007700">+&nbsp;</span><span style="color: #DD0000">"bob3"</span><span style="color: #007700">;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$foo&nbsp;is&nbsp;integer&nbsp;(1)<br /></span><span style="color: #0000BB">$foo&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1&nbsp;</span><span style="color: #007700">+&nbsp;</span><span style="color: #DD0000">"10&nbsp;Small&nbsp;Pigs"</span><span style="color: #007700">;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$foo&nbsp;is&nbsp;integer&nbsp;(11)<br /></span><span style="color: #0000BB">$foo&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">4&nbsp;</span><span style="color: #007700">+&nbsp;</span><span style="color: #DD0000">"10.2&nbsp;Little&nbsp;Piggies"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;$foo&nbsp;is&nbsp;float&nbsp;(14.2)<br /></span><span style="color: #0000BB">$foo&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">"10.0&nbsp;pigs&nbsp;"&nbsp;</span><span style="color: #007700">+&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$foo&nbsp;is&nbsp;float&nbsp;(11)<br /></span><span style="color: #0000BB">$foo&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">"10.0&nbsp;pigs&nbsp;"&nbsp;</span><span style="color: #007700">+&nbsp;</span><span style="color: #0000BB">1.0</span><span style="color: #007700">;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$foo&nbsp;is&nbsp;float&nbsp;(11)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>

  <p class="simpara">
   For more information on this conversion, see the Unix manual page for
   strtod(3).
  </p>

  <p class="para">
   To test any of the examples in this section, cut and paste the examples and
   insert the following line to see what&#039;s going on:
  </p>

  <div class="informalexample">
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"\$foo==</span><span style="color: #0000BB">$foo</span><span style="color: #DD0000">;&nbsp;type&nbsp;is&nbsp;"&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">gettype&nbsp;</span><span style="color: #007700">(</span><span style="color: #0000BB">$foo</span><span style="color: #007700">)&nbsp;.&nbsp;</span><span style="color: #DD0000">"&lt;br&nbsp;/&gt;\n"</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>

  <p class="para">
   Do not expect to get the code of one character by converting it to integer,
   as is done in C. Use the <span class="function"><a href="function.ord.php" class="function">ord()</a></span> and
   <span class="function"><a href="function.chr.php" class="function">chr()</a></span> functions to convert between ASCII codes and
   characters.
  </p>

 </div>

 <div class="sect2" id="language.types.string.details">
  
  <h3 class="title">Details of the String Type</h3>
  
  <p class="para">
   The <span class="type"><a href="language.types.string.php" class="type string">string</a></span> in PHP is implemented as an array of bytes and an
   integer indicating the length of the buffer. It has no information about how
   those bytes translate to characters, leaving that task to the programmer.
   There are no limitations on the values the string can be composed of; in
   particular, bytes with value <em>0</em> (“NUL bytes”) are allowed
   anywhere in the string (however, a few functions, said in this manual not to
   be “binary safe”, may hand off the strings to libraries that ignore data
   after a NUL byte.)
  </p>
  <p class="para">
   This nature of the string type explains why there is no separate “byte” type
   in PHP – strings take this role. Functions that return no textual data – for
   instance, arbitrary data read from a network socket – will still return
   strings.
  </p>
  <p class="para">
   Given that PHP does not dictate a specific encoding for strings, one might
   wonder how string literals are encoded. For instance, is the string
   <em>&quot;á&quot;</em> equivalent to <em>&quot;\xE1&quot;</em> (ISO-8859-1),
   <em>&quot;\xC3\xA1&quot;</em> (UTF-8, C form),
   <em>&quot;\x61\xCC\x81&quot;</em> (UTF-8, D form) or any other possible
   representation? The answer is that string will be encoded in whatever fashion
   it is encoded in the script file. Thus, if the script is written in
   ISO-8859-1, the string will be encoded in ISO-8859-1 and so on. However,
   this does not apply if Zend Multibyte is enabled; in that case, the script
   may be written in an arbitrary encoding (which is explicity declared or is
   detected) and then converted to a certain internal encoding, which is then
   the encoding that will be used for the string literals.
   Note that there are some constraints on the encoding of the script (or on the
   internal encoding, should Zend Multibyte be enabled) – this almost always
   means that this encoding should be a compatible superset of ASCII, such as
   UTF-8 or ISO-8859-1. Note, however, that state-dependent encodings where
   the same byte values can be used in initial and non-initial shift states
   may be problematic.
  </p>
  <p class="para">
   Of course, in order to be useful, functions that operate on text may have to
   make some assumptions about how the string is encoded. Unfortunately, there
   is much variation on this matter throughout PHP’s functions:
  </p>
  <ul class="itemizedlist">
   <li class="listitem">
    <span class="simpara">
     Some functions assume that the string is encoded in some (any) single-byte
     encoding, but they do not need to interpret those bytes as specific
     characters. This is case of, for instance, <span class="function"><a href="function.substr.php" class="function">substr()</a></span>, 
     <span class="function"><a href="function.strpos.php" class="function">strpos()</a></span>, <span class="function"><a href="function.strlen.php" class="function">strlen()</a></span> or
     <span class="function"><a href="function.strcmp.php" class="function">strcmp()</a></span>. Another way to think of these functions is
     that operate on memory buffers, i.e., they work with bytes and byte
     offsets.
    </span>
   </li>
   <li class="listitem">
    <span class="simpara">
     Other functions are passed the encoding of the string, possibly they also
     assume a default if no such information is given. This is the case of
     <span class="function"><a href="function.htmlentities.php" class="function">htmlentities()</a></span> and the majority of the
     functions in the <a href="book.mbstring.php" class="link">mbstring</a> extension.
    </span>
   </li>
   <li class="listitem">
    <span class="simpara">
     Others use the current locale (see <span class="function"><a href="function.setlocale.php" class="function">setlocale()</a></span>), but
     operate byte-by-byte. This is the case of <span class="function"><a href="function.strcasecmp.php" class="function">strcasecmp()</a></span>,
     <span class="function"><a href="function.strtoupper.php" class="function">strtoupper()</a></span> and <span class="function"><a href="function.ucfirst.php" class="function">ucfirst()</a></span>.
     This means they can be used only with single-byte encodings, as long as
     the encoding is matched by the locale. For instance
     <em>strtoupper(&quot;á&quot;)</em> may return <em>&quot;Á&quot;</em> if the
     locale is correctly set and <em>á</em> is encoded with a single
     byte. If it is encoded in UTF-8, the correct result will not be returned
     and the resulting string may or may not be returned corrupted, depending
     on the current locale.
    </span>
   </li>
   <li class="listitem">
    <span class="simpara">
     Finally, they may just assume the string is using a specific encoding,
     usually UTF-8. This is the case of most functions in the
     <a href="book.intl.php" class="link">intl</a> extension and in the
     <a href="book.pcre.php" class="link">PCRE</a> extension
     (in the last case, only when the <em>u</em> modifier is used).
     Although this is due to their special purpose, the function
     <span class="function"><a href="function.utf8-decode.php" class="function">utf8_decode()</a></span> assumes a UTF-8 encoding and the
     function <span class="function"><a href="function.utf8-encode.php" class="function">utf8_encode()</a></span> assumes an ISO-8859-1 encoding.
    </span>
   </li>
  </ul>

  <p class="para">
   Ultimately, this means writing correct programs using Unicode depends on
   carefully avoiding functions that will not work and that most likely will
   corrupt the data and using instead the functions that do behave correctly,
   generally from the <a href="book.intl.php" class="link">intl</a> and
   <a href="book.mbstring.php" class="link">mbstring</a> extensions.
   However, using functions that can handle Unicode encodings is just the
   beginning. No matter the functions the language provides, it is essential to
   know the Unicode specification. For instance, a program that assumes there is
   only uppercase and lowercase is making a wrong assumption.
  </p>
 </div>
</div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.types.string&amp;redirect=http://php.net/manual/en/language.types.string.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">49 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="120160">  <div class="votes">
    <div id="Vu120160">
    <a href="/manual/vote-note.php?id=120160&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120160">
    <a href="/manual/vote-note.php?id=120160&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120160" title="85% like this...">
    99
    </div>
  </div>
  <a href="#120160" class="name">
  <strong class="user"><em>John</em></strong></a><a class="genanchor" href="#120160"> &para;</a><div class="date" title="2016-11-14 03:05"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom120160">
<div class="phpcode"><code><span class="html">
I've been a PHP programmer for a decade, and I've always been using the "single-quoted literal" and "period-concatenation" method of string creation. But I wanted to answer the performance question once and for all, using sufficient numbers of iterations and a modern PHP version. For my test, I used:<br /><br />php -v<br />PHP 7.0.12 (cli) (built: Oct 14 2016 09:56:59) ( NTS )<br />Copyright (c) 1997-2016 The PHP Group<br />Zend Engine v3.0.0, Copyright (c) 1998-2016 Zend Technologies<br /><br />------ Results: -------<br /><br />* 100 million iterations:<br /><br />$outstr = 'literal' . $n . $data . $int . $data . $float . $n;<br />63608ms (34.7% slower)<br /><br />$outstr = "literal$n$data$int$data$float$n";<br />47218ms (fastest)<br /><br />$outstr =&lt;&lt;&lt;EOS<br />literal$n$data$int$data$float$n<br />EOS;<br />47992ms (1.64% slower)<br /><br />$outstr = sprintf('literal%s%s%d%s%f%s', $n, $data, $int, $data, $float, $n);<br />76629ms (62.3% slower)<br /><br />$outstr = sprintf('literal%s%5$s%2$d%3$s%4$f%s', $n, $int, $data, $float, $data, $n);<br />96260ms (103.9% slower)<br /><br />* 10 million iterations (test adapted to see which of the two fastest methods were faster at adding a newline; either the PHP_EOL literal, or the \n string expansion):<br /><br />$outstr = 'literal' . $n . $data . $int . $data . $float . $n;<br />6228ms (reference for single-quoted without newline)<br /><br />$outstr = "literal$n$data$int$data$float$n";<br />4653ms (reference for double-quoted without newline)<br /><br />$outstr = 'literal' . $n . $data . $int . $data . $float . $n . PHP_EOL;<br />6630ms (35.3% slower than double-quoted with \n newline)<br /><br />$outstr = "literal$n$data$int$data$float$n\n";<br />4899ms (fastest at newlines)<br /><br />* 100 million iterations (a test intended to see which one of the two ${var} and {$var} double-quote styles is faster):<br /><br />$outstr = 'literal' . $n . $data . $int . $data . $float . $n;<br />67048ms (38.2% slower)<br /><br />$outstr = "literal$n$data$int$data$float$n";<br />49058ms (1.15% slower)<br /><br />$outstr = "literal{$n}{$data}{$int}{$data}{$float}{$n}"<br />49221ms (1.49% slower)<br /><br />$outstr = "literal${n}${data}${int}${data}${float}${n}"<br />48500ms (fastest; the differences are small but this held true across multiple runs of the test, and this was always the fastest variable encapsulation style)<br /><br />* 1 BILLION iterations (testing a completely literal string with nothing to parse in it):<br /><br />$outstr = 'literal string testing';<br />23852ms (fastest)<br /><br />$outstr = "literal string testing";<br />24222ms (1.55% slower)<br /><br />It blows my mind. The double-quoted strings "which look so $slow since they have to parse everything for \n backslashes and $dollar signs to do variable expansion", turned out to be the FASTEST string concatenation method in PHP - PERIOD!<br /><br />Single-quotes are only faster if your string is completely literal (with nothing to parse in it and nothing to concatenate), but the margin is very tiny and doesn't matter.<br /><br />So the "highest code performance" style rules are:<br /><br />1. Always use double-quoted strings for concatenation.<br /><br />2. Put your variables in "This is a {$variable} notation", because it's the fastest method which still allows complex expansions like "This {$var['foo']} is {$obj-&gt;awesome()}!". You cannot do that with the "${var}" style.<br /><br />3. Feel free to use single-quoted strings for TOTALLY literal strings such as array keys/values, variable values, etc, since they are a TINY bit faster when you want literal non-parsed strings. But I had to do 1 billion iterations to find a 1.55% measurable difference. So the only real reason I'd consider using single-quoted strings for my literals is for code cleanliness, to make it super clear that the string is literal.<br /><br />4. If you think another method such as sprintf() or 'this'.$var.'style' is more readable, and you don't care about maximizing performance, then feel free to use whatever concatenation method you prefer!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="107138">  <div class="votes">
    <div id="Vu107138">
    <a href="/manual/vote-note.php?id=107138&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd107138">
    <a href="/manual/vote-note.php?id=107138&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V107138" title="66% like this...">
    83
    </div>
  </div>
  <a href="#107138" class="name">
  <strong class="user"><em>gtisza at gmail dot com</em></strong></a><a class="genanchor" href="#107138"> &para;</a><div class="date" title="2012-01-10 06:32"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom107138">
<div class="phpcode"><code><span class="html">
The documentation does not mention, but a closing semicolon at the end of the heredoc is actually interpreted as a real semicolon, and as such, sometimes leads to syntax errors.<br /><br />This works:<br /><br /><span class="default">&lt;?php<br />$foo </span><span class="keyword">= &lt;&lt;&lt;END<br /></span><span class="string">abcd<br /></span><span class="keyword">END;<br /></span><span class="default">?&gt;<br /></span><br />This does not:<br /><br /><span class="default">&lt;?php<br />foo</span><span class="keyword">(&lt;&lt;&lt;END<br /></span><span class="string">abcd<br /></span><span class="keyword">END;<br />);<br /></span><span class="comment">// syntax error, unexpected ';'<br /></span><span class="default">?&gt;<br /></span><br />Without semicolon, it works fine:<br /><br /><span class="default">&lt;?php<br />foo</span><span class="keyword">(&lt;&lt;&lt;END<br /></span><span class="string">abcd<br /></span><span class="keyword">END<br />);<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119384">  <div class="votes">
    <div id="Vu119384">
    <a href="/manual/vote-note.php?id=119384&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119384">
    <a href="/manual/vote-note.php?id=119384&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119384" title="66% like this...">
    16
    </div>
  </div>
  <a href="#119384" class="name">
  <strong class="user"><em>garbage at iglou dot eu</em></strong></a><a class="genanchor" href="#119384"> &para;</a><div class="date" title="2016-05-24 10:02"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119384">
<div class="phpcode"><code><span class="html">
You can use string like array of char (like C)<br /><br />$a = "String array test";<br /><br />var_dump($a); <br />// Return string(17) "String array test"<br /><br />var_dump($a[0]); <br />// Return string(1) "S"<br /><br />// -- With array cast --<br />var_dump((array) $a); <br />// Return array(1) { [0]=&gt; string(17) "String array test"}<br /><br />var_dump((array) $a[0]); <br />// Return string(17) "S"<br /><br />- Norihiori</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119891">  <div class="votes">
    <div id="Vu119891">
    <a href="/manual/vote-note.php?id=119891&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119891">
    <a href="/manual/vote-note.php?id=119891&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119891" title="61% like this...">
    4
    </div>
  </div>
  <a href="#119891" class="name">
  <strong class="user"><em>nospam at nospam dot com</em></strong></a><a class="genanchor" href="#119891"> &para;</a><div class="date" title="2016-09-15 08:44"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119891">
<div class="phpcode"><code><span class="html">
Beware that consistent with "String conversion to numbers":<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">if (</span><span class="string">'123abc' </span><span class="keyword">== </span><span class="default">123</span><span class="keyword">) echo </span><span class="string">'(intstr == int) incorrectly tests as true.'</span><span class="keyword">;<br /><br /></span><span class="comment">// Because one side is a number, the string is incorrectly converted from intstr to int, which then matches the test number.<br /><br />// True for all conditionals such as if and switch statements (probably also while loops)!<br /><br />// This could be a huge security risk when testing/using/saving user input, while expecting and testing for only an integer.<br /><br />// It seems the only fix is for 123 to be a string as '123' so no conversion happens.<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="91628">  <div class="votes">
    <div id="Vu91628">
    <a href="/manual/vote-note.php?id=91628&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd91628">
    <a href="/manual/vote-note.php?id=91628&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V91628" title="57% like this...">
    13
    </div>
  </div>
  <a href="#91628" class="name">
  <strong class="user"><em>headden at karelia dot ru</em></strong></a><a class="genanchor" href="#91628"> &para;</a><div class="date" title="2009-06-20 12:43"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom91628">
<div class="phpcode"><code><span class="html">
Here is an easy hack to allow double-quoted strings and heredocs to contain arbitrary expressions in curly braces syntax, including constants and other function calls:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="comment">// Hack declaration<br /></span><span class="keyword">function </span><span class="default">_expr</span><span class="keyword">(</span><span class="default">$v</span><span class="keyword">) { return </span><span class="default">$v</span><span class="keyword">; }<br /></span><span class="default">$_expr </span><span class="keyword">= </span><span class="string">'_expr'</span><span class="keyword">;<br /><br /></span><span class="comment">// Our playground<br /></span><span class="default">define</span><span class="keyword">(</span><span class="string">'qwe'</span><span class="keyword">, </span><span class="string">'asd'</span><span class="keyword">);<br /></span><span class="default">define</span><span class="keyword">(</span><span class="string">'zxc'</span><span class="keyword">, </span><span class="default">5</span><span class="keyword">);<br /><br /></span><span class="default">$a</span><span class="keyword">=</span><span class="default">3</span><span class="keyword">;<br /></span><span class="default">$b</span><span class="keyword">=</span><span class="default">4</span><span class="keyword">;<br /><br />function </span><span class="default">c</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">) { return </span><span class="default">$a</span><span class="keyword">+</span><span class="default">$b</span><span class="keyword">; }<br /><br /></span><span class="comment">// Usage<br /></span><span class="keyword">echo </span><span class="string">"pre </span><span class="keyword">{</span><span class="default">$_expr</span><span class="keyword">(</span><span class="default">1</span><span class="keyword">+</span><span class="default">2</span><span class="keyword">)}</span><span class="string"> post\n"</span><span class="keyword">; </span><span class="comment">// outputs 'pre 3 post'<br /></span><span class="keyword">echo </span><span class="string">"pre </span><span class="keyword">{</span><span class="default">$_expr</span><span class="keyword">(</span><span class="default">qwe</span><span class="keyword">)}</span><span class="string"> post\n"</span><span class="keyword">; </span><span class="comment">// outputs 'pre asd post'<br /></span><span class="keyword">echo </span><span class="string">"pre </span><span class="keyword">{</span><span class="default">$_expr</span><span class="keyword">(</span><span class="default">c</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">)+</span><span class="default">zxc</span><span class="keyword">*</span><span class="default">2</span><span class="keyword">)}</span><span class="string"> post\n"</span><span class="keyword">; </span><span class="comment">// outputs 'pre 17 post'<br /><br />// General syntax is {$_expr(...)}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="46914">  <div class="votes">
    <div id="Vu46914">
    <a href="/manual/vote-note.php?id=46914&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd46914">
    <a href="/manual/vote-note.php?id=46914&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V46914" title="57% like this...">
    14
    </div>
  </div>
  <a href="#46914" class="name">
  <strong class="user"><em>lelon at lelon dot net</em></strong></a><a class="genanchor" href="#46914"> &para;</a><div class="date" title="2004-10-27 12:01"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom46914">
<div class="phpcode"><code><span class="html">
You can use the complex syntax to put the value of both object properties AND object methods inside a string.&nbsp; For example...<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Test </span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$one </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; public function </span><span class="default">two</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">2</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">$test </span><span class="keyword">= new </span><span class="default">Test</span><span class="keyword">();<br />echo </span><span class="string">"foo </span><span class="keyword">{</span><span class="default">$test</span><span class="keyword">-&gt;</span><span class="default">one</span><span class="keyword">}</span><span class="string"> bar </span><span class="keyword">{</span><span class="default">$test</span><span class="keyword">-&gt;</span><span class="default">two</span><span class="keyword">()}</span><span class="string">"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span>Will output "foo 1 bar 2".<br /><br />However, you cannot do this for all values in your namespace.&nbsp; Class constants and static properties/methods will not work because the complex syntax looks for the '$'.<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Test </span><span class="keyword">{<br />&nbsp; &nbsp; const </span><span class="default">ONE </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />}<br />echo </span><span class="string">"foo {Test::ONE} bar"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span>This will output "foo {Test::one} bar".&nbsp; Constants and static properties require you to break up the string.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120414">  <div class="votes">
    <div id="Vu120414">
    <a href="/manual/vote-note.php?id=120414&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120414">
    <a href="/manual/vote-note.php?id=120414&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120414" title="57% like this...">
    4
    </div>
  </div>
  <a href="#120414" class="name">
  <strong class="user"><em>mark at manngo dot net</em></strong></a><a class="genanchor" href="#120414"> &para;</a><div class="date" title="2017-01-05 02:52"><strong>11 months ago</strong></div>
  <div class="text" id="Hcom120414">
<div class="phpcode"><code><span class="html">
I though that it would be helpful to add this comment so that the information at least appears on the right page on the PHP site.<br /><br />Note that if you intend to use a double-quoted string with an associative key, you may run into the T_ENCAPSED_AND_WHITESPACE error. Some regard this as one of the less obvious error messages.<br /><br />An expression such as:<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; $fruit</span><span class="keyword">=array(<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'a'</span><span class="keyword">=&gt;</span><span class="string">'apple'</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'b'</span><span class="keyword">=&gt;</span><span class="string">'banana'</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//&nbsp; &nbsp; etc<br />&nbsp; &nbsp; </span><span class="keyword">);<br /><br />&nbsp; &nbsp; print </span><span class="string">"This is a </span><span class="default">$fruit</span><span class="keyword">[</span><span class="string">'a']"</span><span class="keyword">;&nbsp; &nbsp; </span><span class="comment">//&nbsp; &nbsp; T_ENCAPSED_AND_WHITESPACE<br /></span><span class="default">?&gt;<br /></span><br />will definitely fall to pieces.<br /><br />You can resolve it as follows:<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">print </span><span class="string">"This is a </span><span class="default">$fruit</span><span class="keyword">[</span><span class="default">a</span><span class="keyword">]</span><span class="string">"</span><span class="keyword">;&nbsp; &nbsp; </span><span class="comment">//&nbsp; &nbsp; unquote the key<br />&nbsp; &nbsp; </span><span class="keyword">print </span><span class="string">"This is a </span><span class="keyword">${</span><span class="default">fruit</span><span class="keyword">[</span><span class="string">'a'</span><span class="keyword">]}</span><span class="string">"</span><span class="keyword">;&nbsp; &nbsp; </span><span class="comment">//&nbsp; &nbsp; Complex Syntax<br />&nbsp; &nbsp; </span><span class="keyword">print </span><span class="string">"This is a </span><span class="keyword">{</span><span class="default">$fruit</span><span class="keyword">[</span><span class="string">'a'</span><span class="keyword">]}</span><span class="string">"</span><span class="keyword">;&nbsp; &nbsp; </span><span class="comment">//&nbsp; &nbsp; Complex Syntax variation<br /></span><span class="default">?&gt;<br /></span><br />I have a personal preference for the last variation as it is more natural and closer to what the expression would be like outside the string.<br /><br />It’s not clear (to me, at least) why PHP misinterprets the single quote inside the expression but I imagine that it has something to do with the fact quotes are not part of the value string — once the string is already being parsed the quotes just get in the way … ?</span>
</code></div>
  </div>
 </div>
  <div class="note" id="111522">  <div class="votes">
    <div id="Vu111522">
    <a href="/manual/vote-note.php?id=111522&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd111522">
    <a href="/manual/vote-note.php?id=111522&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V111522" title="54% like this...">
    9
    </div>
  </div>
  <a href="#111522" class="name">
  <strong class="user"><em>php at richardneill dot org</em></strong></a><a class="genanchor" href="#111522"> &para;</a><div class="date" title="2013-02-28 06:20"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom111522">
<div class="phpcode"><code><span class="html">
Leading zeroes in strings are (least-surprise) not treated as octal.<br />Consider:<br />&nbsp; $x = "0123"&nbsp; + 0;&nbsp;&nbsp; <br />&nbsp; $y = 0123 + 0;<br />&nbsp; echo "x is $x, y is $y";&nbsp; &nbsp; //prints&nbsp; "x is 123, y is 83"<br />in other words:<br /> * leading zeros in numeric literals in the source-code are interpreted as "octal", c.f. strtol().<br /> * leading zeros in strings (eg user-submitted data), when cast (implicitly or explicitly) to integer are ignored, and considered as decimal, c.f. strtod().</span>
</code></div>
  </div>
 </div>
  <div class="note" id="85668">  <div class="votes">
    <div id="Vu85668">
    <a href="/manual/vote-note.php?id=85668&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd85668">
    <a href="/manual/vote-note.php?id=85668&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V85668" title="54% like this...">
    11
    </div>
  </div>
  <a href="#85668" class="name">
  <strong class="user"><em>chAlx at findme dot if dot u dot need</em></strong></a><a class="genanchor" href="#85668"> &para;</a><div class="date" title="2008-09-11 08:42"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom85668">
<div class="phpcode"><code><span class="html">
To save Your mind don't read previous comments about dates&nbsp; ;)<br /><br />When both strings can be converted to the numerics (in ("$a" &gt; "$b") test) then resulted numerics are used, else FULL strings are compared char-by-char:<br /><br /><span class="default">&lt;?php<br />var_dump</span><span class="keyword">(</span><span class="string">'1.22' </span><span class="keyword">&gt; </span><span class="string">'01.23'</span><span class="keyword">); </span><span class="comment">// bool(false)<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="string">'1.22.00' </span><span class="keyword">&gt; </span><span class="string">'01.23.00'</span><span class="keyword">); </span><span class="comment">// bool(true)<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="string">'1-22-00' </span><span class="keyword">&gt; </span><span class="string">'01-23-00'</span><span class="keyword">); </span><span class="comment">// bool(true)<br /></span><span class="default">var_dump</span><span class="keyword">((float)</span><span class="string">'1.22.00' </span><span class="keyword">&gt; (float)</span><span class="string">'01.23.00'</span><span class="keyword">); </span><span class="comment">// bool(false)<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="74744">  <div class="votes">
    <div id="Vu74744">
    <a href="/manual/vote-note.php?id=74744&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd74744">
    <a href="/manual/vote-note.php?id=74744&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V74744" title="54% like this...">
    8
    </div>
  </div>
  <a href="#74744" class="name">
  <strong class="user"><em>og at gams dot at</em></strong></a><a class="genanchor" href="#74744"> &para;</a><div class="date" title="2007-04-25 05:06"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom74744">
<div class="phpcode"><code><span class="html">
easy transparent solution for using constants in the heredoc format:<br />DEFINE('TEST','TEST STRING');<br /><br />$const = get_defined_constants();<br /><br />echo &lt;&lt;&lt;END<br />{$const['TEST']}<br />END;<br /><br />Result:<br />TEST STRING</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118916">  <div class="votes">
    <div id="Vu118916">
    <a href="/manual/vote-note.php?id=118916&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118916">
    <a href="/manual/vote-note.php?id=118916&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118916" title="53% like this...">
    2
    </div>
  </div>
  <a href="#118916" class="name">
  <strong class="user"><em>sideshowAnthony at googlemail dot com</em></strong></a><a class="genanchor" href="#118916"> &para;</a><div class="date" title="2016-02-26 06:32"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom118916">
<div class="phpcode"><code><span class="html">
Something I experienced which no doubt will help someone . . .<br />In my editor, this will syntax highlight HTML and the $comment:<br /><br />$html = &lt;&lt;&lt;"EOD"<br />&lt;b&gt;$comment&lt;/b&gt;<br />EOD;<br /><br />Using this shows all the same colour:<br /><br />$html = &lt;&lt;&lt;EOD<br />&lt;b&gt;$comment&lt;/b&gt;<br />EOD;<br /><br />making it a lot easier to work with</span>
</code></div>
  </div>
 </div>
  <div class="note" id="41470">  <div class="votes">
    <div id="Vu41470">
    <a href="/manual/vote-note.php?id=41470&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd41470">
    <a href="/manual/vote-note.php?id=41470&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V41470" title="53% like this...">
    7
    </div>
  </div>
  <a href="#41470" class="name">
  <strong class="user"><em>atnak at chejz dot com</em></strong></a><a class="genanchor" href="#41470"> &para;</a><div class="date" title="2004-04-11 03:53"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom41470">
<div class="phpcode"><code><span class="html">
Here is a possible gotcha related to oddness involved with accessing strings by character past the end of the string:<br /><br />$string = 'a';<br /><br />var_dump($string[2]);&nbsp; // string(0) ""<br />var_dump($string[7]);&nbsp; // string(0) ""<br />$string[7] === '';&nbsp; // TRUE<br /><br />It appears that anything past the end of the string gives an empty string..&nbsp; However, when E_NOTICE is on, the above examples will throw the message:<br /><br />Notice:&nbsp; Uninitialized string offset:&nbsp; N in FILE on line LINE<br /><br />This message cannot be specifically masked with @$string[7], as is possible when $string itself is unset.<br /><br />isset($string[7]);&nbsp; // FALSE<br />$string[7] === NULL;&nbsp; // FALSE<br /><br />Even though it seems like a not-NULL value of type string, it is still considered unset.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="75478">  <div class="votes">
    <div id="Vu75478">
    <a href="/manual/vote-note.php?id=75478&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd75478">
    <a href="/manual/vote-note.php?id=75478&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V75478" title="53% like this...">
    5
    </div>
  </div>
  <a href="#75478" class="name">
  <strong class="user"><em>Richard Neill</em></strong></a><a class="genanchor" href="#75478"> &para;</a><div class="date" title="2007-05-31 08:31"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom75478">
<div class="phpcode"><code><span class="html">
Unlike bash, we can't do <br />&nbsp; echo "\a"&nbsp; &nbsp; &nbsp;&nbsp; #beep!<br /><br />Of course, that would be rather meaningless for PHP/web, but it's useful for PHP-CLI. The solution is simple:&nbsp; echo "\x07"</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121684">  <div class="votes">
    <div id="Vu121684">
    <a href="/manual/vote-note.php?id=121684&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121684">
    <a href="/manual/vote-note.php?id=121684&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121684" title="100% like this...">
    1
    </div>
  </div>
  <a href="#121684" class="name">
  <strong class="user"><em>jonijnm at example dot com</em></strong></a><a class="genanchor" href="#121684"> &para;</a><div class="date" title="2017-09-25 11:26"><strong>2 months ago</strong></div>
  <div class="text" id="Hcom121684">
<div class="phpcode"><code><span class="html">
Both should work :(<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">Testing </span><span class="keyword">{<br />&nbsp; &nbsp; public static </span><span class="default">$VAR </span><span class="keyword">= </span><span class="string">'static'</span><span class="keyword">;<br />&nbsp; &nbsp; public const VAR = </span><span class="string">'const'</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">sayHelloStatic</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"hello: </span><span class="keyword">{</span><span class="default">$this</span><span class="keyword">::</span><span class="default">$VAR</span><span class="keyword">}</span><span class="string">"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">sayHelloConst</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"hello: </span><span class="keyword">{</span><span class="default">$this</span><span class="keyword">::VAR}</span><span class="string">"</span><span class="keyword">; </span><span class="comment">//Parse error:&nbsp; syntax error, unexpected '}', expecting '['<br />&nbsp; &nbsp; </span><span class="keyword">}<br />}<br /><br /></span><span class="default">$obj </span><span class="keyword">= new </span><span class="default">Testing</span><span class="keyword">();<br /></span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">sayHelloStatic</span><span class="keyword">();<br /></span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">sayHelloConst</span><span class="keyword">();</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121731">  <div class="votes">
    <div id="Vu121731">
    <a href="/manual/vote-note.php?id=121731&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121731">
    <a href="/manual/vote-note.php?id=121731&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121731" title="no votes...">
    0
    </div>
  </div>
  <a href="#121731" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#121731"> &para;</a><div class="date" title="2017-10-06 12:03"><strong>2 months ago</strong></div>
  <div class="text" id="Hcom121731">
<div class="phpcode"><code><span class="html">
Took me half an hour to figure out why the documentation claims that this wouldn't, suggesting that variables ending with numbers cannot be interpolated:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">echo </span><span class="string">"This square is </span><span class="default">$square</span><span class="keyword">-&gt;</span><span class="default">width00</span><span class="string"> centimeters broad."</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />It actually DOES work. It prints out the member variable $width00 of the object $square.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="86044">  <div class="votes">
    <div id="Vu86044">
    <a href="/manual/vote-note.php?id=86044&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86044">
    <a href="/manual/vote-note.php?id=86044&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86044" title="51% like this...">
    2
    </div>
  </div>
  <a href="#86044" class="name">
  <strong class="user"><em>steve at mrclay dot org</em></strong></a><a class="genanchor" href="#86044"> &para;</a><div class="date" title="2008-09-30 01:33"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86044">
<div class="phpcode"><code><span class="html">
Simple function to create human-readably escaped double-quoted strings for use in source code or when debugging strings with newlines/tabs/etc.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">doubleQuote</span><span class="keyword">(</span><span class="default">$str</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$ret </span><span class="keyword">= </span><span class="string">'"'</span><span class="keyword">;<br />&nbsp; &nbsp; for (</span><span class="default">$i </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">, </span><span class="default">$l </span><span class="keyword">= </span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$str</span><span class="keyword">); </span><span class="default">$i </span><span class="keyword">&lt; </span><span class="default">$l</span><span class="keyword">; ++</span><span class="default">$i</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$o </span><span class="keyword">= </span><span class="default">ord</span><span class="keyword">(</span><span class="default">$str</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$o </span><span class="keyword">&lt; </span><span class="default">31 </span><span class="keyword">|| </span><span class="default">$o </span><span class="keyword">&gt; </span><span class="default">126</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; switch (</span><span class="default">$o</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">9</span><span class="keyword">: </span><span class="default">$ret </span><span class="keyword">.= </span><span class="string">'\t'</span><span class="keyword">; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">10</span><span class="keyword">: </span><span class="default">$ret </span><span class="keyword">.= </span><span class="string">'\n'</span><span class="keyword">; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">11</span><span class="keyword">: </span><span class="default">$ret </span><span class="keyword">.= </span><span class="string">'\v'</span><span class="keyword">; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">12</span><span class="keyword">: </span><span class="default">$ret </span><span class="keyword">.= </span><span class="string">'\f'</span><span class="keyword">; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">13</span><span class="keyword">: </span><span class="default">$ret </span><span class="keyword">.= </span><span class="string">'\r'</span><span class="keyword">; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; default: </span><span class="default">$ret </span><span class="keyword">.= </span><span class="string">'\x' </span><span class="keyword">. </span><span class="default">str_pad</span><span class="keyword">(</span><span class="default">dechex</span><span class="keyword">(</span><span class="default">$o</span><span class="keyword">), </span><span class="default">2</span><span class="keyword">, </span><span class="string">'0'</span><span class="keyword">, </span><span class="default">STR_PAD_LEFT</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; switch (</span><span class="default">$o</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">36</span><span class="keyword">: </span><span class="default">$ret </span><span class="keyword">.= </span><span class="string">'\$'</span><span class="keyword">; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">34</span><span class="keyword">: </span><span class="default">$ret </span><span class="keyword">.= </span><span class="string">'\"'</span><span class="keyword">; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">92</span><span class="keyword">: </span><span class="default">$ret </span><span class="keyword">.= </span><span class="string">'\\\\'</span><span class="keyword">; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; default: </span><span class="default">$ret </span><span class="keyword">.= </span><span class="default">$str</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; return </span><span class="default">$ret </span><span class="keyword">. </span><span class="string">'"'</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114523">  <div class="votes">
    <div id="Vu114523">
    <a href="/manual/vote-note.php?id=114523&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114523">
    <a href="/manual/vote-note.php?id=114523&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114523" title="50% like this...">
    0
    </div>
  </div>
  <a href="#114523" class="name">
  <strong class="user"><em>necrodust44 at gmail dot com</em></strong></a><a class="genanchor" href="#114523"> &para;</a><div class="date" title="2014-03-04 01:52"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114523">
<div class="phpcode"><code><span class="html">
String conversion to numbers.<br /><br />Unfortunately, the documentation is not correct.<br /><br />«The value is given by the initial portion of the string. If the string starts with valid numeric data, this will be the value used. Otherwise, the value will be 0 (zero).»<br /><br />It is not said and is not shown in examples throughout the documentation that, while converting strings to numbers, leading space characters are ignored, like with the strtod function.<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">echo </span><span class="string">"&nbsp; &nbsp;&nbsp; \v\f&nbsp; &nbsp; \r&nbsp;&nbsp; 1234" </span><span class="keyword">+ </span><span class="default">1</span><span class="keyword">;&nbsp; &nbsp; </span><span class="comment">// 1235<br />&nbsp; &nbsp; </span><span class="default">var_export </span><span class="keyword">(</span><span class="string">"\v\f&nbsp; &nbsp; \r&nbsp;&nbsp; 1234" </span><span class="keyword">== </span><span class="string">"1234"</span><span class="keyword">);&nbsp; &nbsp; </span><span class="comment">// true<br /></span><span class="default">?&gt;<br /></span><br />However, PHP's behaviour differs even from the strtod's. The documentation says that if the string contains a "e" or "E" character, it will be parsed as a float, and suggests to see the manual for strtod for more information. The manual says<br /><br />«A hexadecimal number consists of a "0x" or "0X" followed by a nonempty sequence of hexadecimal digits possibly containing a radix character, optionally followed by a binary exponent.&nbsp; A binary exponent consists of a 'P' or 'p', followed by an optional plus or minus sign, followed by a nonempty sequence of decimal digits, and indicates multiplication by a power of 2.»<br /><br />But it seems that PHP does not recognise the exponent or the radix character.<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">echo </span><span class="string">"0xEp4" </span><span class="keyword">+ </span><span class="default">1</span><span class="keyword">;&nbsp; &nbsp;&nbsp; </span><span class="comment">// 15<br /></span><span class="default">?&gt;<br /></span><br />strtod also uses the current locale to choose the radix character, but PHP ignores the locale, and the radix character is always 2E. However, PHP uses the locale while converting numbers to strings.<br /><br />With strtod, the current locale is also used to choose the space characters, I don't know about PHP.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="78067">  <div class="votes">
    <div id="Vu78067">
    <a href="/manual/vote-note.php?id=78067&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd78067">
    <a href="/manual/vote-note.php?id=78067&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V78067" title="50% like this...">
    1
    </div>
  </div>
  <a href="#78067" class="name">
  <strong class="user"><em>rkfranklin+php at gmail dot com</em></strong></a><a class="genanchor" href="#78067"> &para;</a><div class="date" title="2007-09-26 12:35"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom78067">
<div class="phpcode"><code><span class="html">
If you want to use a variable in an array index within a double quoted string you have to realize that when you put the curly braces around the array, everything inside the curly braces gets evaluated as if it were outside a string.&nbsp; Here are some examples:<br /><br /><span class="default">&lt;?php<br />$i </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br /></span><span class="default">$myArray</span><span class="keyword">[</span><span class="default">Person0</span><span class="keyword">] = </span><span class="default">Bob</span><span class="keyword">;<br /></span><span class="default">$myArray</span><span class="keyword">[</span><span class="default">Person1</span><span class="keyword">] = </span><span class="default">George</span><span class="keyword">;<br /><br /></span><span class="comment">// prints Bob (the ++ is used to emphasize that the expression inside the {} is really being evaluated.)<br /></span><span class="keyword">echo </span><span class="string">"</span><span class="keyword">{</span><span class="default">$myArray</span><span class="keyword">[</span><span class="string">'Person'</span><span class="keyword">.</span><span class="default">$i</span><span class="keyword">++]}</span><span class="string">&lt;br&gt;"</span><span class="keyword">;<br /><br /></span><span class="comment">// these print George<br /></span><span class="keyword">echo </span><span class="string">"</span><span class="keyword">{</span><span class="default">$myArray</span><span class="keyword">[</span><span class="string">'Person'</span><span class="keyword">.</span><span class="default">$i</span><span class="keyword">]}</span><span class="string">&lt;br&gt;"</span><span class="keyword">;<br />echo </span><span class="string">"</span><span class="keyword">{</span><span class="default">$myArray</span><span class="keyword">[</span><span class="string">"Person</span><span class="keyword">{</span><span class="default">$i</span><span class="keyword">}</span><span class="string">"</span><span class="keyword">]}</span><span class="string">&lt;br&gt;"</span><span class="keyword">;<br /><br /></span><span class="comment">// These don't work<br /></span><span class="keyword">echo </span><span class="string">"</span><span class="keyword">{</span><span class="default">$myArray</span><span class="keyword">[</span><span class="string">'Person$i'</span><span class="keyword">]}</span><span class="string">&lt;br&gt;"</span><span class="keyword">;<br />echo </span><span class="string">"</span><span class="keyword">{</span><span class="default">$myArray</span><span class="keyword">[</span><span class="string">'Person'</span><span class="default">$i</span><span class="keyword">]}</span><span class="string">&lt;br&gt;"</span><span class="keyword">;<br /><br /></span><span class="comment">// These both throw fatal errors<br />// echo "$myArray[Person$i]&lt;br&gt;";<br />//echo "$myArray[Person{$i}]&lt;br&gt;";<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="94159">  <div class="votes">
    <div id="Vu94159">
    <a href="/manual/vote-note.php?id=94159&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd94159">
    <a href="/manual/vote-note.php?id=94159&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V94159" title="50% like this...">
    0
    </div>
  </div>
  <a href="#94159" class="name">
  <strong class="user"><em>shd at earthling dot net</em></strong></a><a class="genanchor" href="#94159"> &para;</a><div class="date" title="2009-10-20 02:54"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom94159">
<div class="phpcode"><code><span class="html">
If you want a parsed variable surrounded by curly braces, just double the curly braces:<br /><br /><span class="default">&lt;?php<br />&nbsp; $foo </span><span class="keyword">= </span><span class="string">"bar"</span><span class="keyword">;<br />&nbsp; echo </span><span class="string">"{</span><span class="keyword">{</span><span class="default">$foo</span><span class="keyword">}</span><span class="string">}"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />will just show {bar}. The { is special only if followed by the $ sign and matches one }. In this case, that applies only to the inner braces. The outer ones are not escaped and pass through directly.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="59248">  <div class="votes">
    <div id="Vu59248">
    <a href="/manual/vote-note.php?id=59248&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd59248">
    <a href="/manual/vote-note.php?id=59248&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V59248" title="50% like this...">
    1
    </div>
  </div>
  <a href="#59248" class="name">
  <strong class="user"><em>webmaster at rephunter dot net</em></strong></a><a class="genanchor" href="#59248"> &para;</a><div class="date" title="2005-11-30 08:57"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom59248">
<div class="phpcode"><code><span class="html">
Use caution when you need white space at the end of a heredoc. Not only is the mandatory final newline before the terminating symbol stripped, but an immediately preceding newline or space character is also stripped.<br /><br />For example, in the following, the final space character (indicated by \s -- that is, the "\s" is not literally in the text, but is only used to indicate the space character) is stripped:<br /><br />$string = &lt;&lt;&lt;EOT<br />this is a string with a terminating space\s<br />EOT;<br /><br />In the following, there will only be a single newline at the end of the string, even though two are shown in the text:<br /><br />$string = &lt;&lt;&lt;EOT<br />this is a string that must be<br />followed by a single newline<br /><br />EOT;</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119304">  <div class="votes">
    <div id="Vu119304">
    <a href="/manual/vote-note.php?id=119304&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119304">
    <a href="/manual/vote-note.php?id=119304&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119304" title="45% like this...">
    -2
    </div>
  </div>
  <a href="#119304" class="name">
  <strong class="user"><em>user at grantsearch dot com dot au</em></strong></a><a class="genanchor" href="#119304"> &para;</a><div class="date" title="2016-05-09 05:55"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119304">
<div class="phpcode"><code><span class="html">
A word of caution about taking the use of single and double quotes shown here too literally.<br /><br />A convention is established early on, referring to double-quotes (") and semicolon (;) for example, so the later section about concatenation using the '.' (dot) operator seems to indicate the dot must be enclosed by single quotes.<br /><br />This tripped me up until I mentally reparsed it as the dot (.) operator.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="63707">  <div class="votes">
    <div id="Vu63707">
    <a href="/manual/vote-note.php?id=63707&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd63707">
    <a href="/manual/vote-note.php?id=63707&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V63707" title="47% like this...">
    -4
    </div>
  </div>
  <a href="#63707" class="name">
  <strong class="user"><em>bishop</em></strong></a><a class="genanchor" href="#63707"> &para;</a><div class="date" title="2006-03-28 12:58"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom63707">
<div class="phpcode"><code><span class="html">
You may use heredoc syntax to comment out large blocks of code, as follows:<br /><span class="default">&lt;?php<br /></span><span class="keyword">&lt;&lt;&lt;_EOC<br /></span><span class="string">&nbsp; &nbsp; // end-of-line comment will be masked... so will regular PHP:<br />&nbsp; &nbsp; echo (</span><span class="default">$test</span><span class="string"> == 'foo' ? 'bar' : 'baz'); <br />&nbsp; &nbsp; /* c-style comment will be masked, as will other heredocs (not using the same marker) */<br />&nbsp; &nbsp; echo &lt;&lt;&lt;EOHTML<br />This is text you'll never see!&nbsp; &nbsp; &nbsp; &nbsp; <br />EOHTML;<br />&nbsp; &nbsp; function defintion(</span><span class="default">$params</span><span class="string">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo 'foo';<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; class definition extends nothing&nbsp; &nbsp;&nbsp; {<br />&nbsp; &nbsp; &nbsp;&nbsp; function definition(</span><span class="default">$param</span><span class="string">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo 'do nothing';<br />&nbsp; &nbsp; &nbsp;&nbsp; }&nbsp; &nbsp; &nbsp;&nbsp; <br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; how about syntax errors?; = gone, I bet.<br /></span><span class="keyword">_EOC;<br /></span><span class="default">?&gt;<br /></span><br />Useful for debugging when C-style just won't do.&nbsp; Also useful if you wish to embed Perl-like Plain Old Documentation; extraction between POD markers is left as an exercise for the reader.<br /><br />Note there is a performance penalty for this method, as PHP must still parse and variable substitute the string.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="102709">  <div class="votes">
    <div id="Vu102709">
    <a href="/manual/vote-note.php?id=102709&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd102709">
    <a href="/manual/vote-note.php?id=102709&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V102709" title="46% like this...">
    -6
    </div>
  </div>
  <a href="#102709" class="name">
  <strong class="user"><em>dee jay simple 0 0 7 at  ge mahl  dot  com</em></strong></a><a class="genanchor" href="#102709"> &para;</a><div class="date" title="2011-03-01 12:15"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom102709">
<div class="phpcode"><code><span class="html">
I recently discovered the joys of using heredoc with sprintf and positions. Useful if you want some code to iterate, you can repeat placeholders.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">getNumber</span><span class="keyword">(</span><span class="default">$num </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$foo </span><span class="keyword">= </span><span class="default">rand</span><span class="keyword">(</span><span class="default">1</span><span class="keyword">,</span><span class="default">20</span><span class="keyword">);<br />&nbsp; &nbsp; return (</span><span class="default">$foo </span><span class="keyword">+ </span><span class="default">$num</span><span class="keyword">);<br />}<br />function </span><span class="default">getString</span><span class="keyword">() {<br />&nbsp; &nbsp; </span><span class="default">$foo </span><span class="keyword">= array(</span><span class="string">"California"</span><span class="keyword">,</span><span class="string">"Oregon"</span><span class="keyword">,</span><span class="string">"Washington"</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">shuffle</span><span class="keyword">(</span><span class="default">$foo</span><span class="keyword">);<br />&nbsp; &nbsp; return </span><span class="default">$foo</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">];<br />}<br />function </span><span class="default">getDiv</span><span class="keyword">() {<br />&nbsp; &nbsp; </span><span class="default">$num </span><span class="keyword">= </span><span class="default">getNumber</span><span class="keyword">();<br />&nbsp; &nbsp; </span><span class="default">$div </span><span class="keyword">= </span><span class="default">sprintf</span><span class="keyword">( </span><span class="string">"&lt;div&gt;%s&lt;/div&gt;"</span><span class="keyword">, </span><span class="default">getNumber</span><span class="keyword">(</span><span class="default">rand</span><span class="keyword">(-</span><span class="default">5</span><span class="keyword">,</span><span class="default">5</span><span class="keyword">)) );<br />&nbsp; &nbsp; return </span><span class="default">$div</span><span class="keyword">;<br />}<br /></span><span class="default">$string </span><span class="keyword">= &lt;&lt;&lt;THESTRING<br /></span><span class="string">I like the state of %1\$s &lt;br /&gt;<br />I picked: %2\$d as a number, &lt;br /&gt;<br />I also picked %2\$d as a number again &lt;br /&gt;<br />%3\$s&lt;br /&gt;<br />%3\$s&lt;br /&gt;<br />%3\$s&lt;br /&gt;<br />%3\$s&lt;br /&gt;<br />%3\$s&lt;br /&gt;<br /></span><span class="keyword">THESTRING;<br /><br /></span><span class="default">$returnText </span><span class="keyword">= </span><span class="default">sprintf</span><span class="keyword">(&nbsp; </span><span class="default">$string</span><span class="keyword">, </span><span class="default">getString</span><span class="keyword">(),</span><span class="default">getNumber</span><span class="keyword">(),</span><span class="default">getDiv</span><span class="keyword">()&nbsp; );<br /><br />echo </span><span class="default">$returnText</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;<br /></span><br />Expected output of the above code:<br /><br />I like the state of Oregon<br />I picked: 15 as a number,<br />I also picked 15 as a number again<br />5<br /><br />5<br /><br />5<br /><br />5<br /><br />5</span>
</code></div>
  </div>
 </div>
  <div class="note" id="87390">  <div class="votes">
    <div id="Vu87390">
    <a href="/manual/vote-note.php?id=87390&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd87390">
    <a href="/manual/vote-note.php?id=87390&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V87390" title="46% like this...">
    -6
    </div>
  </div>
  <a href="#87390" class="name">
  <strong class="user"><em>cvolny at gmail dot com</em></strong></a><a class="genanchor" href="#87390"> &para;</a><div class="date" title="2008-12-02 11:43"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom87390">
<div class="phpcode"><code><span class="html">
I commented on a php bug feature request for a string expansion function and figured I should post somewhere it might be useful:<br /><br />using regex, pretty straightforward:<br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">stringExpand</span><span class="keyword">(</span><span class="default">$subject</span><span class="keyword">, array </span><span class="default">$vars</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="comment">// loop over $vars map<br />&nbsp; &nbsp; </span><span class="keyword">foreach (</span><span class="default">$vars </span><span class="keyword">as </span><span class="default">$name </span><span class="keyword">=&gt; </span><span class="default">$value</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// use preg_replace to match ${`$name`} or $`$name`<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$subject </span><span class="keyword">= </span><span class="default">preg_replace</span><span class="keyword">(</span><span class="default">sprintf</span><span class="keyword">(</span><span class="string">'/\$\{?%s\}?/'</span><span class="keyword">, </span><span class="default">$name</span><span class="keyword">), </span><span class="default">$value</span><span class="keyword">,<br /></span><span class="default">$subject</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; </span><span class="comment">// return variable expanded string<br />&nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">$subject</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />using eval() and not limiting access to only certain variables (entire current symbol table including [super]globals):<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">stringExpandDangerous</span><span class="keyword">(</span><span class="default">$subject</span><span class="keyword">, array </span><span class="default">$vars </span><span class="keyword">= array(), </span><span class="default">$random </span><span class="keyword">= </span><span class="default">true</span><span class="keyword">) {<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// extract $vars into current symbol table<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">extract</span><span class="keyword">(</span><span class="default">$vars</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$delim</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// if requested to be random (default), generate delim, otherwise use predefined (trivially faster)<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">if (</span><span class="default">$random</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$delim </span><span class="keyword">= </span><span class="string">'___' </span><span class="keyword">. </span><span class="default">chr</span><span class="keyword">(</span><span class="default">mt_rand</span><span class="keyword">(</span><span class="default">65</span><span class="keyword">,</span><span class="default">90</span><span class="keyword">)) . </span><span class="default">chr</span><span class="keyword">(</span><span class="default">mt_rand</span><span class="keyword">(</span><span class="default">65</span><span class="keyword">,</span><span class="default">90</span><span class="keyword">)) . </span><span class="default">chr</span><span class="keyword">(</span><span class="default">mt_rand</span><span class="keyword">(</span><span class="default">65</span><span class="keyword">,</span><span class="default">90</span><span class="keyword">)) . </span><span class="default">chr</span><span class="keyword">(</span><span class="default">mt_rand</span><span class="keyword">(</span><span class="default">65</span><span class="keyword">,</span><span class="default">90</span><span class="keyword">)) . </span><span class="default">chr</span><span class="keyword">(</span><span class="default">mt_rand</span><span class="keyword">(</span><span class="default">65</span><span class="keyword">,</span><span class="default">90</span><span class="keyword">)) . </span><span class="string">'___'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$delim </span><span class="keyword">= </span><span class="string">'__ASDFZXCV1324ZXCV__'</span><span class="keyword">;&nbsp; </span><span class="comment">// button mashing...<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; // built the eval code<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$statement </span><span class="keyword">= </span><span class="string">"return &lt;&lt;&lt;</span><span class="default">$delim</span><span class="string">\n\n" </span><span class="keyword">. </span><span class="default">$subject </span><span class="keyword">. </span><span class="string">"\n</span><span class="default">$delim</span><span class="string">;\n"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// execute statement, saving output to $result variable<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$result </span><span class="keyword">= eval(</span><span class="default">$statement</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// if eval() returned FALSE, throw a custom exception<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">if (</span><span class="default">$result </span><span class="keyword">=== </span><span class="default">false</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">EvalException</span><span class="keyword">(</span><span class="default">$statement</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// return variable expanded string<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">$result</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /></span><span class="default">?&gt;<br /></span><br />I hope that helps someone, but I do caution against using the eval() route even if it is tempting.&nbsp; I don't know if there's ever a truely safe way to use eval() on the web, I'd rather not use it.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="81457">  <div class="votes">
    <div id="Vu81457">
    <a href="/manual/vote-note.php?id=81457&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd81457">
    <a href="/manual/vote-note.php?id=81457&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V81457" title="45% like this...">
    -8
    </div>
  </div>
  <a href="#81457" class="name">
  <strong class="user"><em>Evan K</em></strong></a><a class="genanchor" href="#81457"> &para;</a><div class="date" title="2008-02-28 01:03"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom81457">
<div class="phpcode"><code><span class="html">
I encountered the odd situation of having a string containing unexpanded escape sequences that I wanted to expand, but also contained dollar signs that would be interpolated as variables.&nbsp; "$5.25\n", for example, where I want to convert \n to a newline, but don't want attempted interpolation of $5.<br /><br />Some muddling through docs and many obscenties later, I produced the following, which expands escape sequences in an existing string with NO interpolation.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="comment">// where we do all our magic<br /></span><span class="keyword">function </span><span class="default">expand_escape</span><span class="keyword">(</span><span class="default">$string</span><span class="keyword">) {<br />&nbsp; &nbsp; return </span><span class="default">preg_replace_callback</span><span class="keyword">(<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'/\\\([nrtvf]|[0-7]{1,3}|[0-9A-Fa-f]{1,2})?/'</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">create_function</span><span class="keyword">(<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'$matches'</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'return ($matches[0] == "\\\\") ? "" : eval( sprintf(\'return "%s";\', $matches[0]) );'<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">),<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$string<br />&nbsp; &nbsp; </span><span class="keyword">);<br />}<br /><br /></span><span class="comment">// a string to test, and show the before and after<br /></span><span class="default">$before </span><span class="keyword">= </span><span class="string">'Quantity:\t500\nPrice:\t$5.25 each'</span><span class="keyword">;<br /></span><span class="default">$after </span><span class="keyword">= </span><span class="default">expand_escape</span><span class="keyword">(</span><span class="default">$before</span><span class="keyword">);<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$before</span><span class="keyword">, </span><span class="default">$after</span><span class="keyword">);<br /><br /></span><span class="comment">/* Outputs:<br />string(34) "Quantity:\t500\nPrice:\t$5.25 each"<br />string(31) "Quantity:&nbsp; &nbsp; 500<br />Price:&nbsp; &nbsp; $5.25 each"<br />*/<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119782">  <div class="votes">
    <div id="Vu119782">
    <a href="/manual/vote-note.php?id=119782&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119782">
    <a href="/manual/vote-note.php?id=119782&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119782" title="42% like this...">
    -4
    </div>
  </div>
  <a href="#119782" class="name">
  <strong class="user"><em>ksean</em></strong></a><a class="genanchor" href="#119782"> &para;</a><div class="date" title="2016-08-24 08:40"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119782">
<div class="phpcode"><code><span class="html">
$foo = 'foo';<br /><br />echo "{$foo}"; // foo<br />echo "${'fo' . 'o'}"; // foo<br />echo "{$'fo' . 'o'}"; // error</span>
</code></div>
  </div>
 </div>
  <div class="note" id="85477">  <div class="votes">
    <div id="Vu85477">
    <a href="/manual/vote-note.php?id=85477&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd85477">
    <a href="/manual/vote-note.php?id=85477&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V85477" title="44% like this...">
    -8
    </div>
  </div>
  <a href="#85477" class="name">
  <strong class="user"><em>harmor</em></strong></a><a class="genanchor" href="#85477"> &para;</a><div class="date" title="2008-09-01 03:05"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom85477">
<div class="phpcode"><code><span class="html">
So you want to get the last character of a string using "String access and modification by character"?&nbsp; Well negative indexes are not allowed so $str[-1] will return an empty string.<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">//Tested using: PHP 5.2.5<br /><br /></span><span class="default">$str </span><span class="keyword">= </span><span class="string">'This is a test.'</span><span class="keyword">;<br /><br /></span><span class="default">$last </span><span class="keyword">= </span><span class="default">$str</span><span class="keyword">[-</span><span class="default">1</span><span class="keyword">];&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//string(0) ""<br /></span><span class="default">$realLast </span><span class="keyword">= </span><span class="default">$str</span><span class="keyword">[</span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$str</span><span class="keyword">)-</span><span class="default">1</span><span class="keyword">];&nbsp; </span><span class="comment">//string(1) "."<br /></span><span class="default">$substr </span><span class="keyword">= </span><span class="default">substr</span><span class="keyword">(</span><span class="default">$str</span><span class="keyword">,-</span><span class="default">1</span><span class="keyword">);&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="comment">//string(1) "."<br /><br /></span><span class="keyword">echo </span><span class="string">'&lt;pre&gt;'</span><span class="keyword">;<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$last</span><span class="keyword">);<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$realLast</span><span class="keyword">);<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$substr</span><span class="keyword">);</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="108984">  <div class="votes">
    <div id="Vu108984">
    <a href="/manual/vote-note.php?id=108984&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd108984">
    <a href="/manual/vote-note.php?id=108984&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V108984" title="43% like this...">
    -8
    </div>
  </div>
  <a href="#108984" class="name">
  <strong class="user"><em>Denis R.</em></strong></a><a class="genanchor" href="#108984"> &para;</a><div class="date" title="2012-06-10 11:01"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom108984">
<div class="phpcode"><code><span class="html">
Hi.<br /><br />I noticed that the documentation does not mention that when you have an XML element which contains a dash (-) in its name can only be accessed using the bracelets notation.<br />For example:<br />&lt;xml version="1"&gt;<br />&lt;root&gt;<br />&nbsp;&nbsp; &lt;element-one&gt;value4element-one&lt;/element-one&gt;<br />&lt;/root&gt;<br /><br />to access the above 'element-one' using SimpleXML you need to use the following:<br /><br />$simpleXMLObj-&gt;root-&gt;{'element-one'}<br /><br />to retrieve the value.<br /><br />Hope this helps,<br />Denis R.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="98140">  <div class="votes">
    <div id="Vu98140">
    <a href="/manual/vote-note.php?id=98140&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd98140">
    <a href="/manual/vote-note.php?id=98140&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V98140" title="44% like this...">
    -9
    </div>
  </div>
  <a href="#98140" class="name">
  <strong class="user"><em>saamde at gmail dot com</em></strong></a><a class="genanchor" href="#98140"> &para;</a><div class="date" title="2010-05-27 03:40"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom98140">
<div class="phpcode"><code><span class="html">
Watch out for the "unexpected T_SL" error.&nbsp; This appears to occur when there is white space just after "&lt;&lt;&lt;EOT" and since it's white space it's real hard to spot the error in your code.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="108144">  <div class="votes">
    <div id="Vu108144">
    <a href="/manual/vote-note.php?id=108144&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd108144">
    <a href="/manual/vote-note.php?id=108144&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V108144" title="43% like this...">
    -10
    </div>
  </div>
  <a href="#108144" class="name">
  <strong class="user"><em>m021 at springtimesoftware dot com</em></strong></a><a class="genanchor" href="#108144"> &para;</a><div class="date" title="2012-04-01 02:00"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom108144">
<div class="phpcode"><code><span class="html">
Heredoc literals delete any trailing space (tabs and blanks) on each line. This is unexpected, since quoted strings do not do this. This is probably done for historical reasons, so would not be considered a bug.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="110259">  <div class="votes">
    <div id="Vu110259">
    <a href="/manual/vote-note.php?id=110259&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd110259">
    <a href="/manual/vote-note.php?id=110259&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V110259" title="42% like this...">
    -11
    </div>
  </div>
  <a href="#110259" class="name">
  <strong class="user"><em>mcamiano at ncsu dot edu</em></strong></a><a class="genanchor" href="#110259"> &para;</a><div class="date" title="2012-10-05 02:43"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom110259">
<div class="phpcode"><code><span class="html">
Regarding the lack of complex expression interpolation, just assign an identity function to a variable and call it:<br /><br />function id($arg) { return $arg; }<br /><br />$expr = id;<br /><br />echo "Field is: {$expr( "1 ". ucfirst('whatzit')) }";<br /> <br />It is slower due to an additional function call, but it does avoid the assignment of a one-shot temporary variable. When there are a lot of very simple value transformations made just for display purposes, it can de-clutter code.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="93325">  <div class="votes">
    <div id="Vu93325">
    <a href="/manual/vote-note.php?id=93325&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd93325">
    <a href="/manual/vote-note.php?id=93325&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V93325" title="42% like this...">
    -11
    </div>
  </div>
  <a href="#93325" class="name">
  <strong class="user"><em>Liesbeth</em></strong></a><a class="genanchor" href="#93325"> &para;</a><div class="date" title="2009-09-03 01:54"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom93325">
<div class="phpcode"><code><span class="html">
If you need to emulate a nowdoc in PHP &lt; 5.3, try using HTML mode and output capturing. This way '$' or '\n' in your string won't be a problem anymore (but unfortunately, '&lt;?' will be).<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="comment">// Start of script<br /><br /></span><span class="default">ob_start</span><span class="keyword">(); </span><span class="default">?&gt;<br /></span>&nbsp; A text with 'quotes' <br />&nbsp; &nbsp; and $$$dollars$$$.<br /><span class="default">&lt;?php $input </span><span class="keyword">= </span><span class="default">ob_get_contents</span><span class="keyword">(); </span><span class="default">ob_end_clean</span><span class="keyword">();<br /><br /></span><span class="comment">// Do what you want with $input<br /></span><span class="keyword">echo </span><span class="string">"&lt;pre&gt;" </span><span class="keyword">. </span><span class="default">$input </span><span class="keyword">. </span><span class="string">"&lt;/pre&gt;"</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="103890">  <div class="votes">
    <div id="Vu103890">
    <a href="/manual/vote-note.php?id=103890&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd103890">
    <a href="/manual/vote-note.php?id=103890&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V103890" title="41% like this...">
    -13
    </div>
  </div>
  <a href="#103890" class="name">
  <strong class="user"><em>Michael</em></strong></a><a class="genanchor" href="#103890"> &para;</a><div class="date" title="2011-05-09 05:56"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom103890">
<div class="phpcode"><code><span class="html">
Just want to mention that if you want a literal { around a variable within a string, for example if you want your output to be something like the following:<br /><br />{hello, world}<br /><br />and all that you put inside the {} is a variable, you can do a double {{}}, like this:<br /><br />$test = 'hello, world';<br />echo "{{$test}}";</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113857">  <div class="votes">
    <div id="Vu113857">
    <a href="/manual/vote-note.php?id=113857&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113857">
    <a href="/manual/vote-note.php?id=113857&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113857" title="38% like this...">
    -7
    </div>
  </div>
  <a href="#113857" class="name">
  <strong class="user"><em>espertalhao04 at hotmail dot com</em></strong></a><a class="genanchor" href="#113857"> &para;</a><div class="date" title="2013-12-10 10:34"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113857">
<div class="phpcode"><code><span class="html">
gtisza at gmail dot com<br /><br />You incorrectly stated that thee documentation doesn't refer anything about the semicolon at the end of the heredocs and nowdocs&nbsp; being interpreted as a "real" semicolon.<br /><br />If you read carefully, you will notice this, in the 1st sentence of the warning about heredocs:<br /><br />"It is very important to note that the line with the closing identifier must contain no other characters, except a semicolon (;)."<br /><br />Interesting...<br />It is refering about semicolons...<br /><br />But wait, there is more:<br /><br /><a href="http://php.net/manual/en/language.basic-syntax.instruction-separation.php" rel="nofollow" target="_blank">http://php.net/manual/en/language.basic-syntax.instruction-separation.php</a><br />1st sentence says:<br />"As in C or Perl, PHP requires instructions to be terminated with a semicolon at the end of each statement."<br /><br />So, here says that semicolons are statement separators, basicly...<br /><br />So, if you put a "real" semicolon at the end of these examples:<br /><span class="default">&lt;?php<br />&nbsp; &nbsp; $a</span><span class="keyword">=</span><span class="default">5</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$foo</span><span class="keyword">=</span><span class="string">"String"</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$bar</span><span class="keyword">=array();<br />&nbsp; &nbsp; </span><span class="default">$yep</span><span class="keyword">=</span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$other</span><span class="keyword">=</span><span class="default">func</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span>Why shouldn't you put at the end of heredocs and nowdocs?<br />After all, a heredoc or a nowdoc is simply a string.<br /><br />You should read more carefully the documentation first before saying any comment.<br /><br />About serious questions:<br />I didn't read all comments here, but you can run functions inside strings and heredocs.<br /><br />And you can even nest them inside {}<br /><br />Example:<br /><span class="default">&lt;?php<br />&nbsp; &nbsp; $f</span><span class="keyword">=function(</span><span class="default">$x</span><span class="keyword">){</span><span class="default">$a</span><span class="keyword">=</span><span class="default">func_get_args</span><span class="keyword">();unset(</span><span class="default">$a</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]);return </span><span class="default">call_user_func_array</span><span class="keyword">(</span><span class="default">$x</span><span class="keyword">,</span><span class="default">$a</span><span class="keyword">);};<br />&nbsp; &nbsp; </span><span class="default">$d</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">;<br />&nbsp; &nbsp; echo </span><span class="default">$b</span><span class="keyword">=&lt;&lt;&lt;NUMBERS<br /></span><span class="string">4.0909 rounded is: </span><span class="keyword">{</span><span class="default">$f</span><span class="keyword">(</span><span class="string">'round'</span><span class="keyword">,</span><span class="default">4.0909</span><span class="keyword">,</span><span class="default">$d</span><span class="keyword">)}</span><span class="string"><br />Time now is: </span><span class="keyword">{</span><span class="default">$f</span><span class="keyword">(</span><span class="string">'time'</span><span class="keyword">)}</span><span class="string"><br />Nested heredocs/nowdocs: </span><span class="keyword">{</span><span class="default">$f</span><span class="keyword">(</span><span class="string">'sprintf'</span><span class="keyword">,&lt;&lt;&lt;OTHER<br /></span><span class="string">Here is an %s of nested %s<br /></span><span class="keyword">OTHER<br />,</span><span class="string">"Example"</span><span class="keyword">,&lt;&lt;&lt;'NOW'<br /></span><span class="string">heredocs and nowdocs<br /></span><span class="keyword">NOW<br />)}</span><span class="string"><br /></span><span class="keyword">NUMBERS;<br /><br /></span><span class="comment">/*echoes (time is system and real time relative):<br />4.0909 rounded is: 4<br />Time now is: 1386670912<br />Nested heredocs/nowdocs: Here is an Example of nested heredocs and nowdocs<br />*/<br /></span><span class="default">?&gt;<br /></span><br />It's not pretty, and is hard to read, but sometimes it is useful to confuse curious people (like minifying the code).<br /><br />Warning: if any function that runs inside a string or heredoc gives a fatal error, the script MAY continue!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="105369">  <div class="votes">
    <div id="Vu105369">
    <a href="/manual/vote-note.php?id=105369&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd105369">
    <a href="/manual/vote-note.php?id=105369&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V105369" title="41% like this...">
    -14
    </div>
  </div>
  <a href="#105369" class="name">
  <strong class="user"><em>sgbeal at googlemail dot com</em></strong></a><a class="genanchor" href="#105369"> &para;</a><div class="date" title="2011-08-12 04:44"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom105369">
<div class="phpcode"><code><span class="html">
The docs say: "Heredoc text behaves just like a double-quoted string, without the double quotes" but there is a notable hidden exception to that rule: the final newline in the string (the one before closing heredoc token) is elided. i.e. if you have:<br /><br />$foo = &lt;&lt;&lt;EOF<br />a<br />b<br />c<br />EOF;<br /><br />the result is equivalent to "a\nb\nc", NOT "a\nb\nc\n" like the docs imply.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114736">  <div class="votes">
    <div id="Vu114736">
    <a href="/manual/vote-note.php?id=114736&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114736">
    <a href="/manual/vote-note.php?id=114736&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114736" title="38% like this...">
    -10
    </div>
  </div>
  <a href="#114736" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#114736"> &para;</a><div class="date" title="2014-03-31 03:33"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114736">
<div class="phpcode"><code><span class="html">
$my_int = "12,140";<br />echo&nbsp; 1 + $my_int ;<br /><br />Returns 13 not the expected 12141</span>
</code></div>
  </div>
 </div>
  <div class="note" id="44458">  <div class="votes">
    <div id="Vu44458">
    <a href="/manual/vote-note.php?id=44458&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd44458">
    <a href="/manual/vote-note.php?id=44458&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V44458" title="41% like this...">
    -13
    </div>
  </div>
  <a href="#44458" class="name">
  <strong class="user"><em>Jonathan Lozinski</em></strong></a><a class="genanchor" href="#44458"> &para;</a><div class="date" title="2004-08-06 12:03"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom44458">
<div class="phpcode"><code><span class="html">
A note on the heredoc stuff.<br /><br />If you're editing with VI/VIM and possible other syntax highlighting editors, then using certain words is the way forward.&nbsp; if you use &lt;&lt;&lt;HTML for example, then the text will be hightlighted for HTML!!<br /><br />I just found this out and used sed to alter all EOF to HTML.<br /><br />JAVASCRIPT also works, and possibly others.&nbsp; The only thing about &lt;&lt;&lt;JAVASCRIPT is that you can't add the &lt;script&gt; tags..,&nbsp; so use HTML instead, which will correctly highlight all JavaScript too..<br /><br />You can also use EOHTML, EOSQL, and EOJAVASCRIPT.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="58353">  <div class="votes">
    <div id="Vu58353">
    <a href="/manual/vote-note.php?id=58353&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd58353">
    <a href="/manual/vote-note.php?id=58353&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V58353" title="40% like this...">
    -15
    </div>
  </div>
  <a href="#58353" class="name">
  <strong class="user"><em>DELETETHIS dot php at dfackrell dot mailshell dot com</em></strong></a><a class="genanchor" href="#58353"> &para;</a><div class="date" title="2005-11-01 08:05"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom58353">
<div class="phpcode"><code><span class="html">
Just some quick observations on variable interpolation:<br /><br />Because PHP looks for {? to start a complex variable expression in a double-quoted string, you can call object methods, but not class methods or unbound functions.<br /><br />This works:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">a </span><span class="keyword">{<br />&nbsp; &nbsp; function </span><span class="default">b</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">"World"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">$c </span><span class="keyword">= new </span><span class="default">a</span><span class="keyword">;<br />echo </span><span class="string">"Hello </span><span class="keyword">{</span><span class="default">$c</span><span class="keyword">-&gt;</span><span class="default">b</span><span class="keyword">()}</span><span class="string">.\n"<br /></span><span class="default">?&gt;<br /></span><br />While this does not:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">b</span><span class="keyword">() {<br />&nbsp; &nbsp; return </span><span class="string">"World"</span><span class="keyword">;<br />}<br />echo </span><span class="string">"Hello {b()}\n"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />Also, it appears that you can almost without limitation perform other processing within the argument list, but not outside it.&nbsp; For example:<br /><br />&lt;?<br />$true = true;<br />define("HW", "Hello World");<br />echo "{$true &amp;&amp; HW}";<br />?&gt;<br /><br />gives: Parse error: parse error, unexpected T_BOOLEAN_AND, expecting '}' in - on line 3<br /><br />There may still be some way to kludge the syntax to allow constants and unbound function calls inside a double-quoted string, but it isn't readily apparent to me at the moment, and I'm not sure I'd prefer the workaround over breaking out of the string at this point.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="41986">  <div class="votes">
    <div id="Vu41986">
    <a href="/manual/vote-note.php?id=41986&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd41986">
    <a href="/manual/vote-note.php?id=41986&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V41986" title="37% like this...">
    -14
    </div>
  </div>
  <a href="#41986" class="name">
  <strong class="user"><em>www.feisar.de</em></strong></a><a class="genanchor" href="#41986"> &para;</a><div class="date" title="2004-04-28 07:49"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom41986">
<div class="phpcode"><code><span class="html">
watch out when comparing strings that are numbers. this example:<br /><br /><span class="default">&lt;?php<br /><br />$x1 </span><span class="keyword">= </span><span class="string">'111111111111111111'</span><span class="keyword">;<br /></span><span class="default">$x2 </span><span class="keyword">= </span><span class="string">'111111111111111112'</span><span class="keyword">;<br /><br />echo (</span><span class="default">$x1 </span><span class="keyword">== </span><span class="default">$x2</span><span class="keyword">) ? </span><span class="string">"true\n" </span><span class="keyword">: </span><span class="string">"false\n"</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;<br /></span><br />will output "true", although the strings are different. With large integer-strings, it seems that PHP compares only the integer values, not the strings. Even strval() will not work here.<br /><br />To be on the safe side, use:<br /><br />$x1 === $x2</span>
</code></div>
  </div>
 </div>
  <div class="note" id="95184">  <div class="votes">
    <div id="Vu95184">
    <a href="/manual/vote-note.php?id=95184&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd95184">
    <a href="/manual/vote-note.php?id=95184&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V95184" title="36% like this...">
    -19
    </div>
  </div>
  <a href="#95184" class="name">
  <strong class="user"><em>&amp;#34;Sascha Ziemann&amp;#34;</em></strong></a><a class="genanchor" href="#95184"> &para;</a><div class="date" title="2009-12-17 01:58"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom95184">
<div class="phpcode"><code><span class="html">
Empty strings seem to be no real strings, because they behave different to strings containing data. Here is an example.<br /><br />It is possible to change a character at a specific position using the square bracket notation:<br /><span class="default">&lt;?php<br />$str </span><span class="keyword">= </span><span class="string">'0'</span><span class="keyword">;<br /></span><span class="default">$str</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">] = </span><span class="string">'a'</span><span class="keyword">;<br />echo </span><span class="default">$str</span><span class="keyword">.</span><span class="string">"\n"</span><span class="keyword">; </span><span class="comment">// =&gt; 'a'<br /></span><span class="default">?&gt;<br /></span><br />It is also possible to change a character with does not exist, if the index is "behind" the end of the string:<br /><span class="default">&lt;?php<br />$str </span><span class="keyword">= </span><span class="string">'0'</span><span class="keyword">;<br /></span><span class="default">$str</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">] = </span><span class="string">'a'</span><span class="keyword">;<br />echo </span><span class="default">$str</span><span class="keyword">.</span><span class="string">"\n"</span><span class="keyword">; </span><span class="comment">// =&gt; 0a<br /></span><span class="default">?&gt;<br /></span><br />But if you do that on an empty string, the string gets silently converted into an array:<br /><span class="default">&lt;?php<br />$str </span><span class="keyword">= </span><span class="string">''</span><span class="keyword">;<br /></span><span class="default">$str</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">] = </span><span class="string">'a'</span><span class="keyword">;<br />echo </span><span class="default">$str</span><span class="keyword">.</span><span class="string">"\n"</span><span class="keyword">; </span><span class="comment">// =&gt; Array<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="73400">  <div class="votes">
    <div id="Vu73400">
    <a href="/manual/vote-note.php?id=73400&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd73400">
    <a href="/manual/vote-note.php?id=73400&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V73400" title="37% like this...">
    -18
    </div>
  </div>
  <a href="#73400" class="name">
  <strong class="user"><em>fmouse at fmp dot com</em></strong></a><a class="genanchor" href="#73400"> &para;</a><div class="date" title="2007-02-21 10:20"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom73400">
<div class="phpcode"><code><span class="html">
It may be obvious to some, but it's convenient to note that variables _will_ be expanded inside of single quotes if these occur inside of a double-quoted string.&nbsp; This can be handy in constructing exec calls with complex data to be passed to other programs.&nbsp; e.g.:<br /><br />$foo = "green";<br />echo "the grass is $foo";<br />the grass is green<br /><br />echo 'the grass is $foo';<br />the grass is $foo<br /><br />echo "the grass is '$foo'";<br />the grass is 'green'</span>
</code></div>
  </div>
 </div>
  <div class="note" id="87035">  <div class="votes">
    <div id="Vu87035">
    <a href="/manual/vote-note.php?id=87035&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd87035">
    <a href="/manual/vote-note.php?id=87035&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V87035" title="36% like this...">
    -24
    </div>
  </div>
  <a href="#87035" class="name">
  <strong class="user"><em>Obeliks</em></strong></a><a class="genanchor" href="#87035"> &para;</a><div class="date" title="2008-11-15 08:21"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom87035">
<div class="phpcode"><code><span class="html">
Expectedly <span class="default">&lt;?php $string</span><span class="keyword">[</span><span class="default">$x</span><span class="keyword">] </span><span class="default">?&gt;</span> and <span class="default">&lt;?php substr</span><span class="keyword">(</span><span class="default">$string</span><span class="keyword">, </span><span class="default">$x</span><span class="keyword">, </span><span class="default">1</span><span class="keyword">) </span><span class="default">?&gt;</span> will yield the same result... normally!<br /><br />However, when you turn on the&nbsp; Function Overloading Feature (<a href="http://php.net/manual/en/mbstring.overload.php" rel="nofollow" target="_blank">http://php.net/manual/en/mbstring.overload.php</a>), this might not be true!<br /><br />If you use this Overloading Feature with 3rd party software, you should check for usage of the String access operator, otherwise you might be in for some nasty surprises.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="74710">  <div class="votes">
    <div id="Vu74710">
    <a href="/manual/vote-note.php?id=74710&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd74710">
    <a href="/manual/vote-note.php?id=74710&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V74710" title="36% like this...">
    -23
    </div>
  </div>
  <a href="#74710" class="name">
  <strong class="user"><em>penda ekoka</em></strong></a><a class="genanchor" href="#74710"> &para;</a><div class="date" title="2007-04-24 10:14"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom74710">
<div class="phpcode"><code><span class="html">
error control operator (@) with heredoc syntax:<br /><br />the error control operator is pretty handy for supressing minimal errors or omissions. For example an email form that request some basic non mandatory information to your users. Some may complete the form, other may not. Lets say you don't want to tweak PHP for error levels and you just wish to create some basic template that will be emailed to the admin with the user information submitted. You manage to collect the user input in an array called $form:<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">// creating your mailer<br /></span><span class="default">$mailer </span><span class="keyword">= new </span><span class="default">SomeMailerLib</span><span class="keyword">();<br /></span><span class="default">$mailer</span><span class="keyword">-&gt;</span><span class="default">from </span><span class="keyword">= </span><span class="string">' System &lt;mail@yourwebsite.com&gt;'</span><span class="keyword">;<br /></span><span class="default">$mailer</span><span class="keyword">-&gt;</span><span class="default">to </span><span class="keyword">= </span><span class="string">'admin@yourwebsite.com'</span><span class="keyword">;<br /></span><span class="default">$mailer</span><span class="keyword">-&gt;</span><span class="default">subject </span><span class="keyword">= </span><span class="string">'New user request'</span><span class="keyword">;<br /></span><span class="comment">// you put the error control operator before the heredoc operator to suppress notices and warnings about unset indices like this<br /></span><span class="default">$mailer</span><span class="keyword">-&gt;</span><span class="default">body </span><span class="keyword">= @&lt;&lt;&lt;FORM<br /></span><span class="string">Firstname = </span><span class="keyword">{</span><span class="default">$form</span><span class="keyword">[</span><span class="string">'firstname'</span><span class="keyword">]}</span><span class="string"><br />Lastname = </span><span class="keyword">{</span><span class="default">$form</span><span class="keyword">[</span><span class="string">'lastname'</span><span class="keyword">]}</span><span class="string"><br />Email = </span><span class="keyword">{</span><span class="default">$form</span><span class="keyword">[</span><span class="string">'email'</span><span class="keyword">]}</span><span class="string"><br />Telephone = </span><span class="keyword">{</span><span class="default">$form</span><span class="keyword">[</span><span class="string">'telephone'</span><span class="keyword">]}</span><span class="string"><br />Address = </span><span class="keyword">{</span><span class="default">$form</span><span class="keyword">[</span><span class="string">'address'</span><span class="keyword">]}</span><span class="string"><br /></span><span class="keyword">FORM;<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="103680">  <div class="votes">
    <div id="Vu103680">
    <a href="/manual/vote-note.php?id=103680&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd103680">
    <a href="/manual/vote-note.php?id=103680&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V103680" title="35% like this...">
    -29
    </div>
  </div>
  <a href="#103680" class="name">
  <strong class="user"><em>Ultimater at gmail dot com</em></strong></a><a class="genanchor" href="#103680"> &para;</a><div class="date" title="2011-04-27 03:18"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom103680">
<div class="phpcode"><code><span class="html">
If you require a NowDoc but don't have support for them on your server -- since your PHP version is less than PHP 5.3.0 -- and you are in need of a workaround, I'd suggest using PHP's __halt_compiler() which is basically a knock-off of Perl's __DATA__ token if you are familiar with it.<br /><br />Give this a run to see my suggestion in action:<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">//set $nowDoc to a string containing a code snippet for the user to read<br /></span><span class="default">$nowDoc </span><span class="keyword">= </span><span class="default">file_get_contents</span><span class="keyword">(</span><span class="default">__FILE__</span><span class="keyword">,</span><span class="default">null</span><span class="keyword">,</span><span class="default">null</span><span class="keyword">,</span><span class="default">__COMPILER_HALT_OFFSET__</span><span class="keyword">);<br /></span><span class="default">$nowDoc</span><span class="keyword">=</span><span class="default">highlight_string</span><span class="keyword">(</span><span class="default">$nowDoc</span><span class="keyword">,</span><span class="default">true</span><span class="keyword">);<br /><br />echo &lt;&lt;&lt;EOF<br /></span><span class="string">&lt;!doctype html&gt;<br />&lt;html&gt;<br />&lt;head&gt;<br />&lt;meta http-equiv="content-type" content="text/html; charset=UTF-8" /&gt;<br />&lt;title&gt;NowDoc support for PHP &amp;lt; 5.3.0&lt;/title&gt;<br />&lt;meta name="author" content="Ultimater at gmail dot com" /&gt;<br />&lt;meta name="about-this-page"<br />content="Note that I built this code explicitly for the<br />php.net documenation for demonstrative purposes." /&gt;<br />&lt;style type="text/css"&gt;<br />body{text-align:center;}<br />table.border{background:#e0eaee;margin:1px auto;padding:1px;}<br />table.border td{padding:5px;border:1px solid #8880ff;text-align:left;<br />background-color:#eee;}<br />code ::selection{background:#5f5color:white;}<br />code ::-moz-selection{background:#5f5;color:white;}<br />a{color:#33a;text-decoration:none;}<br />a:hover{color:rgb(3,128,252);}<br />&lt;/style&gt;<br />&lt;/head&gt;<br />&lt;body&gt;<br />&lt;h1 style="margin:1px auto;"&gt;<br />&lt;a<br />href="<a href="http://php.net/manual/en/language.types.string.php#example-77" rel="nofollow" target="_blank">http://php.net/manual/en/language.types.string.php#example-77</a>"&gt;<br />Example #8 Simple syntax example<br />&lt;/a&gt;&lt;/h1&gt;<br />&lt;table class="border"&gt;&lt;tr&gt;&lt;td&gt;<br /></span><span class="default">$nowDoc</span><span class="string"><br />&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;<br /></span><span class="keyword">EOF;<br /><br />__halt_compiler()<br /></span><span class="comment">//Example code snippet we want displayed on the webpage<br />//note that the compiler isn't actually stopped until the semicolon<br /></span><span class="keyword">;&lt;?</span><span class="default">php<br />$juices </span><span class="keyword">= array(</span><span class="string">"apple"</span><span class="keyword">, </span><span class="string">"orange"</span><span class="keyword">, </span><span class="string">"koolaid1" </span><span class="keyword">=&gt; </span><span class="string">"purple"</span><span class="keyword">);<br /><br />echo </span><span class="string">"He drank some </span><span class="default">$juices</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]</span><span class="string"> juice."</span><span class="keyword">.</span><span class="default">PHP_EOL</span><span class="keyword">;<br />echo </span><span class="string">"He drank some </span><span class="default">$juices</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]</span><span class="string"> juice."</span><span class="keyword">.</span><span class="default">PHP_EOL</span><span class="keyword">;<br />echo </span><span class="string">"He drank some juice made of </span><span class="default">$juice</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]</span><span class="string">s."</span><span class="keyword">.</span><span class="default">PHP_EOL</span><span class="keyword">; </span><span class="comment">// Won't work<br /></span><span class="keyword">echo </span><span class="string">"He drank some </span><span class="default">$juices</span><span class="keyword">[</span><span class="default">koolaid1</span><span class="keyword">]</span><span class="string"> juice."</span><span class="keyword">.</span><span class="default">PHP_EOL</span><span class="keyword">;<br /><br />class </span><span class="default">people </span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$john </span><span class="keyword">= </span><span class="string">"John Smith"</span><span class="keyword">;<br />&nbsp; &nbsp; public </span><span class="default">$jane </span><span class="keyword">= </span><span class="string">"Jane Smith"</span><span class="keyword">;<br />&nbsp; &nbsp; public </span><span class="default">$robert </span><span class="keyword">= </span><span class="string">"Robert Paulsen"</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public </span><span class="default">$smith </span><span class="keyword">= </span><span class="string">"Smith"</span><span class="keyword">;<br />}<br /><br /></span><span class="default">$people </span><span class="keyword">= new </span><span class="default">people</span><span class="keyword">();<br /><br />echo </span><span class="string">"</span><span class="default">$people</span><span class="keyword">-&gt;</span><span class="default">john</span><span class="string"> drank some </span><span class="default">$juices</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]</span><span class="string"> juice."</span><span class="keyword">.</span><span class="default">PHP_EOL</span><span class="keyword">;<br />echo </span><span class="string">"</span><span class="default">$people</span><span class="keyword">-&gt;</span><span class="default">john</span><span class="string"> then said hello to </span><span class="default">$people</span><span class="keyword">-&gt;</span><span class="default">jane</span><span class="string">."</span><span class="keyword">.</span><span class="default">PHP_EOL</span><span class="keyword">;<br />echo </span><span class="string">"</span><span class="default">$people</span><span class="keyword">-&gt;</span><span class="default">john</span><span class="string">'s wife greeted </span><span class="default">$people</span><span class="keyword">-&gt;</span><span class="default">robert</span><span class="string">."</span><span class="keyword">.</span><span class="default">PHP_EOL</span><span class="keyword">;<br />echo </span><span class="string">"</span><span class="default">$people</span><span class="keyword">-&gt;</span><span class="default">robert</span><span class="string"> greeted the two </span><span class="default">$people</span><span class="keyword">-&gt;</span><span class="default">smiths</span><span class="string">."</span><span class="keyword">; </span><span class="comment">// Won't work<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114526">  <div class="votes">
    <div id="Vu114526">
    <a href="/manual/vote-note.php?id=114526&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114526">
    <a href="/manual/vote-note.php?id=114526&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114526" title="30% like this...">
    -18
    </div>
  </div>
  <a href="#114526" class="name">
  <strong class="user"><em>benl39 at free dot fr</em></strong></a><a class="genanchor" href="#114526"> &para;</a><div class="date" title="2014-03-04 09:14"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114526">
<div class="phpcode"><code><span class="html">
Note that :<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">echo </span><span class="string">'error' </span><span class="keyword">== </span><span class="default">0</span><span class="keyword">, </span><span class="string">'&lt;br&gt;'</span><span class="keyword">; </span><span class="comment">// TRUE<br /></span><span class="keyword">echo </span><span class="string">'error' </span><span class="keyword">== </span><span class="string">'0'</span><span class="keyword">, </span><span class="string">'&lt;br&gt;'</span><span class="keyword">; </span><span class="comment">// FALSE<br /></span><span class="keyword">echo </span><span class="string">'0' </span><span class="keyword">== </span><span class="default">0</span><span class="keyword">, </span><span class="string">'&lt;br&gt;'</span><span class="keyword">; </span><span class="comment">// TRUE<br /><br />// So, 'error' != 'error' ?<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114578">  <div class="votes">
    <div id="Vu114578">
    <a href="/manual/vote-note.php?id=114578&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114578">
    <a href="/manual/vote-note.php?id=114578&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114578" title="28% like this...">
    -16
    </div>
  </div>
  <a href="#114578" class="name">
  <strong class="user"><em>Ray.Paseur often uses Gmail</em></strong></a><a class="genanchor" href="#114578"> &para;</a><div class="date" title="2014-03-08 01:14"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114578">
<div class="phpcode"><code><span class="html">
In Example #8, above, consider the risk to the script if a programmer were to define('koolaid1', 'XYZ');&nbsp; For this reason it's wise to use quotes around literal-string associative array keys.&nbsp; As written without quotes, PHP should raise a Notice.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116496">  <div class="votes">
    <div id="Vu116496">
    <a href="/manual/vote-note.php?id=116496&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116496">
    <a href="/manual/vote-note.php?id=116496&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116496" title="26% like this...">
    -21
    </div>
  </div>
  <a href="#116496" class="name">
  <strong class="user"><em>cnbk201 at gmail dot com</em></strong></a><a class="genanchor" href="#116496"> &para;</a><div class="date" title="2015-01-12 10:07"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom116496">
<div class="phpcode"><code><span class="html">
Small note to consider in heredoc multiple dimension array will not work and neither will any native language functions<br /><br /><span class="default">&lt;?php<br /><br />$a</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">] = </span><span class="string">"man"</span><span class="keyword">;<br /></span><span class="default">$b</span><span class="keyword">[</span><span class="string">'man'</span><span class="keyword">] = </span><span class="string">"player"</span><span class="keyword">;<br />echo &lt;&lt;&lt;ED<br /></span><span class="default">$b</span><span class="keyword">[</span><span class="default">$a</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]</span><span class="string">] // will result in error<br />substr(</span><span class="default">$a</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]</span><span class="string">, 1) // will result in substr(man, 1)<br />ED; <br />?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="86365">  <div class="votes">
    <div id="Vu86365">
    <a href="/manual/vote-note.php?id=86365&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86365">
    <a href="/manual/vote-note.php?id=86365&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86365" title="30% like this...">
    -42
    </div>
  </div>
  <a href="#86365" class="name">
  <strong class="user"><em>Salil Kothadia</em></strong></a><a class="genanchor" href="#86365"> &para;</a><div class="date" title="2008-10-15 01:33"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86365">
<div class="phpcode"><code><span class="html">
An interesting finding about Heredoc "syntax error, unexpected $end".<br />I got this error because I did not use the php close tag "?&gt;" and I had no code after the heredoc code.<br /><br />foo1.php code gives "syntax error, unexpected $end".<br />But in foo2.php and foo3.php, when you add a php close tag or when you have some more code after heredoc it works fine.<br /><br />Example Code:<br />foo1.php<br />1. <span class="default">&lt;?php<br />2. $str </span><span class="keyword">= &lt;&lt;&lt;EOD<br /></span><span class="string">3. Example of string<br />4. spanning multiple lines<br />5. using heredoc syntax.<br />6. EOD;<br />7. <br /><br />foo2.php<br />1. &lt;?php<br />2. </span><span class="default">$str</span><span class="string"> = &lt;&lt;&lt;EOD<br />3. Example of string<br />4. spanning multiple lines<br />5. using heredoc syntax.<br />6. EOD;<br />7. <br />8. echo </span><span class="default">$str</span><span class="string">;<br />9.<br /><br />foo3.php<br />1. &lt;?php<br />2. </span><span class="default">$str</span><span class="string"> = &lt;&lt;&lt;EOD<br />3. Example of string<br />4. spanning multiple lines<br />5. using heredoc syntax.<br />6. EOD;<br />7. ?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121014">  <div class="votes">
    <div id="Vu121014">
    <a href="/manual/vote-note.php?id=121014&amp;page=language.types.string&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121014">
    <a href="/manual/vote-note.php?id=121014&amp;page=language.types.string&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121014" title="0% like this...">
    -4
    </div>
  </div>
  <a href="#121014" class="name">
  <strong class="user"><em>gbarros at NOSPAM dot yahoo-inc dot com</em></strong></a><a class="genanchor" href="#121014"> &para;</a><div class="date" title="2017-04-24 07:57"><strong>7 months ago</strong></div>
  <div class="text" id="Hcom121014">
<div class="phpcode"><code><span class="html">
Almost every editor (even VIM) will break the syntax highlighting on the case where you have two forward slashes in a string. Which is perfectly valid in php. In fact, you are likely to have tons of that because of URLs.<br /><br /><span class="default">&lt;?php<br />print_r</span><span class="keyword">(</span><span class="string">'hello // world&lt;br&gt;'</span><span class="keyword">);<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="string">"hello // world&lt;br&gt;"</span><span class="keyword">);<br /></span><span class="default">$x </span><span class="keyword">= &lt;&lt;&lt; ENDSTR<br /></span><span class="string">&nbsp; &nbsp; hello // world&lt;br&gt;<br /></span><span class="keyword">ENDSTR;<br /></span><span class="default">print_r</span><span class="keyword">( </span><span class="default">$x </span><span class="keyword">);<br /></span><span class="comment">/* above will result in:<br />hello // world<br />hello // world<br />hello // world<br /><br />but most code/text editors will show "// wold" as a comment.<br />*/<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.types.string&amp;redirect=http://php.net/manual/en/language.types.string.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.types.php">Types</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.types.intro.php" title="Introduction">Introduction</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.boolean.php" title="Booleans">Booleans</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.integer.php" title="Integers">Integers</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.float.php" title="Floating point numbers">Floating point numbers</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.types.string.php" title="Strings">Strings</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.array.php" title="Arrays">Arrays</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.iterable.php" title="Iterables">Iterables</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.object.php" title="Objects">Objects</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.resource.php" title="Resources">Resources</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.null.php" title="NULL">NULL</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.callable.php" title="Callbacks / Callables">Callbacks / Callables</a>
                        </li>
                          
                        <li class="">
                            <a href="language.pseudo-types.php" title="Pseudo-&#8203;types and variables used in this documentation">Pseudo-&#8203;types and variables used in this documentation</a>
                        </li>
                          
                        <li class="">
                            <a href="language.types.type-juggling.php" title="Type Juggling">Type Juggling</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

