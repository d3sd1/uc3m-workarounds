<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: switch - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/control-structures.switch.php">
 <link rel="shorturl" href="http://php.net/switch">
 <link rel="alternate" href="http://php.net/switch" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.control-structures.php">
 <link rel="prev" href="http://php.net/manual/en/control-structures.continue.php">
 <link rel="next" href="http://php.net/manual/en/control-structures.declare.php">

 <link rel="alternate" href="http://php.net/manual/en/control-structures.switch.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/control-structures.switch.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/control-structures.switch.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/control-structures.switch.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/control-structures.switch.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/control-structures.switch.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/control-structures.switch.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/control-structures.switch.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/control-structures.switch.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/control-structures.switch.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/control-structures.switch.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="control-structures.declare.php">
          declare &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="control-structures.continue.php">
          &laquo; continue        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.control-structures.php'>Control Structures</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/control-structures.switch.php' selected="selected">English</option>
            <option value='pt_BR/control-structures.switch.php'>Brazilian Portuguese</option>
            <option value='zh/control-structures.switch.php'>Chinese (Simplified)</option>
            <option value='fr/control-structures.switch.php'>French</option>
            <option value='de/control-structures.switch.php'>German</option>
            <option value='ja/control-structures.switch.php'>Japanese</option>
            <option value='ro/control-structures.switch.php'>Romanian</option>
            <option value='ru/control-structures.switch.php'>Russian</option>
            <option value='es/control-structures.switch.php'>Spanish</option>
            <option value='tr/control-structures.switch.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/control-structures.switch.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=control-structures.switch">Report a Bug</a>
    </div>
  </div><div id="control-structures.switch" class="sect1">
 <h2 class="title"><em>switch</em></h2>
 <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p>
 <p class="simpara">
  The <em>switch</em> statement is similar to a series of
  IF statements on the same expression.  In many occasions, you may
  want to compare the same variable (or expression) with many
  different values, and execute a different piece of code depending
  on which value it equals to.  This is exactly what the
  <em>switch</em> statement is for.
 </p>
 <blockquote class="note"><p><strong class="note">Note</strong>: 
  <span class="simpara">
   Note that unlike some other languages, the
   <a href="control-structures.continue.php" class="link">continue</a> statement
   applies to <em>switch</em> and acts similar to <em>break</em>.  If you
   have a <em>switch</em> inside a loop and wish to continue to the next iteration of
   the outer loop, use <em>continue 2</em>.
  </span>
 </p></blockquote>
 <blockquote class="note"><p><strong class="note">Note</strong>: 
  <p class="para">
   Note that switch/case does
   <a href="types.comparisons.php#types.comparisions-loose" class="link">loose comparison</a>.
  </p>
 </p></blockquote>
 <p class="para">
  <table class="doctable table">
   <caption><strong>Changelog</strong></caption>
   
    <thead>
     <tr>
      <th>Version</th>
      <th>Description</th>
     </tr>

    </thead>

    <tbody class="tbody">
     <tr>
      <td>7.0.0</td>
      <td>
       Multiple default cases will raise a <strong><code>E_COMPILE_ERROR</code></strong> error.
      </td>
     </tr>

    </tbody>
   
  </table>

 </p>
 <p class="para">
  The following two examples are two different ways to write the
  same thing, one using a series of <em>if</em> and
  <em>elseif</em> statements, and the other using the
  <em>switch</em> statement:
  <div class="example" id="example-117">
   <p><strong>Example #1 <em>switch</em> structure</strong></p>
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">if&nbsp;(</span><span style="color: #0000BB">$i&nbsp;</span><span style="color: #007700">==&nbsp;</span><span style="color: #0000BB">0</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"i&nbsp;equals&nbsp;0"</span><span style="color: #007700">;<br />}&nbsp;elseif&nbsp;(</span><span style="color: #0000BB">$i&nbsp;</span><span style="color: #007700">==&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"i&nbsp;equals&nbsp;1"</span><span style="color: #007700">;<br />}&nbsp;elseif&nbsp;(</span><span style="color: #0000BB">$i&nbsp;</span><span style="color: #007700">==&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"i&nbsp;equals&nbsp;2"</span><span style="color: #007700">;<br />}<br /><br />switch&nbsp;(</span><span style="color: #0000BB">$i</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;</span><span style="color: #0000BB">0</span><span style="color: #007700">:<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"i&nbsp;equals&nbsp;0"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;<br />&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">:<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"i&nbsp;equals&nbsp;1"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;<br />&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">:<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"i&nbsp;equals&nbsp;2"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>
  <div class="example" id="example-118">
   <p><strong>Example #2 <em>switch</em> structure allows usage of <span class="type"><a href="language.types.string.php" class="type string">string</a></span>s</strong></p>
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">switch&nbsp;(</span><span style="color: #0000BB">$i</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;</span><span style="color: #DD0000">"apple"</span><span style="color: #007700">:<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"i&nbsp;is&nbsp;apple"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;<br />&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;</span><span style="color: #DD0000">"bar"</span><span style="color: #007700">:<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"i&nbsp;is&nbsp;bar"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;<br />&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;</span><span style="color: #DD0000">"cake"</span><span style="color: #007700">:<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"i&nbsp;is&nbsp;cake"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>
 </p>
 <p class="para">
  It is important to understand how the <em>switch</em>
  statement is executed in order to avoid mistakes.  The
  <em>switch</em> statement executes line by line
  (actually, statement by statement).  In the beginning, no code is
  executed.  Only when a <em>case</em> statement is found
  whose expression evaluates to a value that matches the value of the
  <em>switch</em> expression does PHP begin to execute the
  statements.  PHP continues to execute the statements until the end
  of the <em>switch</em> block, or the first time it sees
  a <em>break</em> statement.  If you don&#039;t write a
  <em>break</em> statement at the end of a case&#039;s
  statement list, PHP will go on executing the statements of the
  following case.  For example:
  <div class="informalexample">
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">switch&nbsp;(</span><span style="color: #0000BB">$i</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;</span><span style="color: #0000BB">0</span><span style="color: #007700">:<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"i&nbsp;equals&nbsp;0"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">:<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"i&nbsp;equals&nbsp;1"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">:<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"i&nbsp;equals&nbsp;2"</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>
 </p>
 <p class="simpara">
  Here, if <var class="varname"><var class="varname">$i</var></var> is equal to 0, PHP would execute all of the echo
  statements!  If <var class="varname"><var class="varname">$i</var></var> is equal to 1, PHP would execute the last two
  echo statements. You would get the expected behavior (&#039;i equals 2&#039;
  would be displayed) only if <var class="varname"><var class="varname">$i</var></var> is equal to 2.  Thus,
  it is important not to forget <em>break</em> statements
  (even though you may want to avoid supplying them on purpose under
  certain circumstances).
 </p>
 <p class="simpara">
  In a <em>switch</em> statement, the condition is
  evaluated only once and the result is compared to each
  <em>case</em> statement. In an <em>elseif</em>
  statement, the condition is evaluated again. If your condition is
  more complicated than a simple compare and/or is in a tight loop,
  a <em>switch</em> may be faster.
 </p>
 <p class="para">
  The statement list for a case can also be empty, which simply
  passes control into the statement list for the next case.
  <div class="informalexample">
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">switch&nbsp;(</span><span style="color: #0000BB">$i</span><span style="color: #007700">)&nbsp;{<br />case&nbsp;</span><span style="color: #0000BB">0</span><span style="color: #007700">:<br />case&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">:<br />case&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">:<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"i&nbsp;is&nbsp;less&nbsp;than&nbsp;3&nbsp;but&nbsp;not&nbsp;negative"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;break;<br />case&nbsp;</span><span style="color: #0000BB">3</span><span style="color: #007700">:<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"i&nbsp;is&nbsp;3"</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>
 </p>
 <p class="para">
  A special case is the <em>default</em> case.  This case matches
  anything that wasn&#039;t matched by the other cases.  For example:
  <div class="informalexample">
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">switch&nbsp;(</span><span style="color: #0000BB">$i</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;</span><span style="color: #0000BB">0</span><span style="color: #007700">:<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"i&nbsp;equals&nbsp;0"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;<br />&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">:<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"i&nbsp;equals&nbsp;1"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;<br />&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">:<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"i&nbsp;equals&nbsp;2"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;<br />&nbsp;&nbsp;&nbsp;&nbsp;default:<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"i&nbsp;is&nbsp;not&nbsp;equal&nbsp;to&nbsp;0,&nbsp;1&nbsp;or&nbsp;2"</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>
 </p>
 <p class="para">
  The alternative syntax for control structures is supported with
  switches. For more information, see <a href="control-structures.alternative-syntax.php" class="link">Alternative syntax
  for control structures</a>.
  <div class="informalexample">
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">switch&nbsp;(</span><span style="color: #0000BB">$i</span><span style="color: #007700">):<br />&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;</span><span style="color: #0000BB">0</span><span style="color: #007700">:<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"i&nbsp;equals&nbsp;0"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;<br />&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">:<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"i&nbsp;equals&nbsp;1"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;<br />&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">:<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"i&nbsp;equals&nbsp;2"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;<br />&nbsp;&nbsp;&nbsp;&nbsp;default:<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"i&nbsp;is&nbsp;not&nbsp;equal&nbsp;to&nbsp;0,&nbsp;1&nbsp;or&nbsp;2"</span><span style="color: #007700">;<br />endswitch;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>
 </p>
 <p class="para">
  It&#039;s possible to use a semicolon instead of a colon after a case like:
  <div class="informalexample">
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">switch(</span><span style="color: #0000BB">$beer</span><span style="color: #007700">)<br />{<br />&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;</span><span style="color: #DD0000">'tuborg'</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;</span><span style="color: #DD0000">'carlsberg'</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;case&nbsp;</span><span style="color: #DD0000">'heineken'</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">'Good&nbsp;choice'</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;break;<br />&nbsp;&nbsp;&nbsp;&nbsp;default;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">'Please&nbsp;make&nbsp;a&nbsp;new&nbsp;selection...'</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;break;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>
 </p>
</div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=control-structures.switch&amp;redirect=http://php.net/manual/en/control-structures.switch.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">53 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="109034">  <div class="votes">
    <div id="Vu109034">
    <a href="/manual/vote-note.php?id=109034&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd109034">
    <a href="/manual/vote-note.php?id=109034&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V109034" title="75% like this...">
    172
    </div>
  </div>
  <a href="#109034" class="name">
  <strong class="user"><em>MaxTheDragon at home dot nl</em></strong></a><a class="genanchor" href="#109034"> &para;</a><div class="date" title="2012-06-14 02:29"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom109034">
<div class="phpcode"><code><span class="html">
This is listed in the documentation above, but it's a bit tucked away between the paragraphs. The difference between a series of if statements and the switch statement is that the expression you're comparing with, is evaluated only once in a switch statement. I think this fact needs a little bit more attention, so here's an example:<br /><br /><span class="default">&lt;?php<br />$a </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br /><br />if(++</span><span class="default">$a </span><span class="keyword">== </span><span class="default">3</span><span class="keyword">) echo </span><span class="default">3</span><span class="keyword">;<br />elseif(++</span><span class="default">$a </span><span class="keyword">== </span><span class="default">2</span><span class="keyword">) echo </span><span class="default">2</span><span class="keyword">;<br />elseif(++</span><span class="default">$a </span><span class="keyword">== </span><span class="default">1</span><span class="keyword">) echo </span><span class="default">1</span><span class="keyword">;<br />else echo </span><span class="string">"No match!"</span><span class="keyword">;<br /><br /></span><span class="comment">// Outputs: 2<br /><br /></span><span class="default">$a </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br /><br />switch(++</span><span class="default">$a</span><span class="keyword">) {<br />&nbsp; &nbsp; case </span><span class="default">3</span><span class="keyword">: echo </span><span class="default">3</span><span class="keyword">; break;<br />&nbsp; &nbsp; case </span><span class="default">2</span><span class="keyword">: echo </span><span class="default">2</span><span class="keyword">; break;<br />&nbsp; &nbsp; case </span><span class="default">1</span><span class="keyword">: echo </span><span class="default">1</span><span class="keyword">; break;<br />&nbsp; &nbsp; default: echo </span><span class="string">"No match!"</span><span class="keyword">; break;<br />}<br /><br /></span><span class="comment">// Outputs: 1<br /></span><span class="default">?&gt;<br /></span><br />It is therefore perfectly safe to do:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">switch(</span><span class="default">winNobelPrizeStartingFromBirth</span><span class="keyword">()) {<br />case </span><span class="string">"peace"</span><span class="keyword">: echo </span><span class="string">"You won the Nobel Peace Prize!"</span><span class="keyword">; break;<br />case </span><span class="string">"physics"</span><span class="keyword">: echo </span><span class="string">"You won the Nobel Prize in Physics!"</span><span class="keyword">; break;<br />case </span><span class="string">"chemistry"</span><span class="keyword">: echo </span><span class="string">"You won the Nobel Prize in Chemistry!"</span><span class="keyword">; break;<br />case </span><span class="string">"medicine"</span><span class="keyword">: echo </span><span class="string">"You won the Nobel Prize in Medicine!"</span><span class="keyword">; break;<br />case </span><span class="string">"literature"</span><span class="keyword">: echo </span><span class="string">"You won the Nobel Prize in Literature!"</span><span class="keyword">; break;<br />default: echo </span><span class="string">"You bought a rusty iron medal from a shady guy who insists it's a Nobel Prize..."</span><span class="keyword">; break;<br />}<br /></span><span class="default">?&gt;<br /></span><br />without having to worry about the function being re-evaluated for every case. There's no need to preemptively save the result in a variable either.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="84150">  <div class="votes">
    <div id="Vu84150">
    <a href="/manual/vote-note.php?id=84150&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd84150">
    <a href="/manual/vote-note.php?id=84150&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V84150" title="68% like this...">
    32
    </div>
  </div>
  <a href="#84150" class="name">
  <strong class="user"><em>mmxg at shaw dot ca</em></strong></a><a class="genanchor" href="#84150"> &para;</a><div class="date" title="2008-07-01 01:30"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom84150">
<div class="phpcode"><code><span class="html">
In reply to lko at netuse dot de<br /><br />Just so others know whom may not, that's because PHP does automatic type conversion if a string is evaluated as an integer (it sees the 2 in '2string' so when compared like if ('2string' == 2), PHP sees if (2 == 2) ).<br /><br />I just tested it, but if you go:<br /><br /><span class="default">&lt;?php<br /><br />$string</span><span class="keyword">=</span><span class="string">"2string"</span><span class="keyword">;<br /><br />switch(</span><span class="default">$string</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; case (string) </span><span class="default">1</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"this is 1"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; case (string) </span><span class="default">2</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"this is 2"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; case </span><span class="string">'2string'</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"this is a string"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />The output will be "this is a string" and if you change $string to "2" it will again be "this is 2".<br /><br />Just in case that may help anyone who may run into that problem.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="82351">  <div class="votes">
    <div id="Vu82351">
    <a href="/manual/vote-note.php?id=82351&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd82351">
    <a href="/manual/vote-note.php?id=82351&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V82351" title="62% like this...">
    45
    </div>
  </div>
  <a href="#82351" class="name">
  <strong class="user"><em>lko at netuse dot de</em></strong></a><a class="genanchor" href="#82351"> &para;</a><div class="date" title="2008-04-07 08:51"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom82351">
<div class="phpcode"><code><span class="html">
Attention if you have mixed types of value in one switch statemet it can make you some trouble<br /><br /><span class="default">&lt;?php<br /><br />$string</span><span class="keyword">=</span><span class="string">"2string"</span><span class="keyword">;<br /><br />switch(</span><span class="default">$string</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; case </span><span class="default">1</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"this is 1"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; case </span><span class="default">2</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"this is 2"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; case </span><span class="string">'2string'</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"this is a string"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />The swich-statement will halt on 'case 2'<br /><br />Answer: this is 2</span>
</code></div>
  </div>
 </div>
  <div class="note" id="9610">  <div class="votes">
    <div id="Vu9610">
    <a href="/manual/vote-note.php?id=9610&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd9610">
    <a href="/manual/vote-note.php?id=9610&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V9610" title="62% like this...">
    40
    </div>
  </div>
  <a href="#9610" class="name">
  <strong class="user"><em>nospam at please dot com</em></strong></a><a class="genanchor" href="#9610"> &para;</a><div class="date" title="2000-11-14 05:18"><strong>17 years ago</strong></div>
  <div class="text" id="Hcom9610">
<div class="phpcode"><code><span class="html">
Just a trick I have picked up:<br /><br />If you need to evaluate several variables to find the first one with an actual value, TRUE for instance. You can do it this was.<br /><br />There is probably a better way but it has worked out well for me.<br /><br />switch (true) {<br /><br />&nbsp; case (X != 1):<br /><br />&nbsp; case (Y != 1):<br /><br />&nbsp; default:<br />}</span>
</code></div>
  </div>
 </div>
  <div class="note" id="78725">  <div class="votes">
    <div id="Vu78725">
    <a href="/manual/vote-note.php?id=78725&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd78725">
    <a href="/manual/vote-note.php?id=78725&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V78725" title="63% like this...">
    13
    </div>
  </div>
  <a href="#78725" class="name">
  <strong class="user"><em>Hayley Watson</em></strong></a><a class="genanchor" href="#78725"> &para;</a><div class="date" title="2007-10-24 02:02"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom78725">
<div class="phpcode"><code><span class="html">
Something not mentioned in the documentation itself, and only touched on momentarily in these notes, is that the default: case need not be the last clause in the switch.<br /><span class="default">&lt;?php<br /></span><span class="keyword">for(</span><span class="default">$i</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">&lt;</span><span class="default">8</span><span class="keyword">; ++</span><span class="default">$i</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; echo </span><span class="default">$i</span><span class="keyword">,</span><span class="string">"\t"</span><span class="keyword">;<br />&nbsp; &nbsp; switch(</span><span class="default">$i</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; case </span><span class="default">1</span><span class="keyword">: echo </span><span class="string">"One"</span><span class="keyword">; break;<br />&nbsp; &nbsp; case </span><span class="default">2</span><span class="keyword">:<br />&nbsp; &nbsp; default: echo </span><span class="string">"Thingy"</span><span class="keyword">; break;<br />&nbsp; &nbsp; case </span><span class="default">3</span><span class="keyword">:<br />&nbsp; &nbsp; case </span><span class="default">4</span><span class="keyword">: echo </span><span class="string">"Three or Four"</span><span class="keyword">; break;<br />&nbsp; &nbsp; case </span><span class="default">5</span><span class="keyword">: echo </span><span class="string">"Five"</span><span class="keyword">; break;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; echo </span><span class="string">"\n"</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span>Outputs what you'd expect, namely<br />0&nbsp; &nbsp; &nbsp;&nbsp; Thingy<br />1&nbsp; &nbsp; &nbsp;&nbsp; One<br />2&nbsp; &nbsp; &nbsp;&nbsp; Thingy<br />3&nbsp; &nbsp; &nbsp;&nbsp; Three or Four<br />4&nbsp; &nbsp; &nbsp;&nbsp; Three or Four<br />5&nbsp; &nbsp; &nbsp;&nbsp; Five<br />6&nbsp; &nbsp; &nbsp;&nbsp; Thingy<br />7&nbsp; &nbsp; &nbsp;&nbsp; Thingy<br />with case 2 and the default both producing the same result ("Thingy"); strictly speaking, the case 2 clause is completely empty and control just falls straight through. The same result could have been achieved with<br /><span class="default">&lt;?php<br /></span><span class="keyword">switch(</span><span class="default">$i</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; case </span><span class="default">1</span><span class="keyword">: echo </span><span class="string">"One"</span><span class="keyword">; break;<br />&nbsp; &nbsp; case </span><span class="default">3</span><span class="keyword">:<br />&nbsp; &nbsp; case </span><span class="default">4</span><span class="keyword">: echo </span><span class="string">"Three or Four"</span><span class="keyword">; break;<br />&nbsp; &nbsp; case </span><span class="default">5</span><span class="keyword">: echo </span><span class="string">"Five"</span><span class="keyword">; break;<br />&nbsp; &nbsp; default: echo </span><span class="string">"Thingy"</span><span class="keyword">; break;<br />}<br /></span><span class="default">?&gt;<br /></span>But if "case 2" represented a fairly common case (other than "everything else"), then it would be better to declare it explicitly, not only because it saves time by not having to test EVERY other case first&nbsp; (in the current example, PHP finds 'case 2' in the first switch in two tests, but in the second switch it has to make four tests before giving up and going with the default) but also because someone (perhaps yourself in a few months' time) will be reading the code and expecting to see it handled. Listing it explicitly aids comprehension</span>
</code></div>
  </div>
 </div>
  <div class="note" id="41767">  <div class="votes">
    <div id="Vu41767">
    <a href="/manual/vote-note.php?id=41767&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd41767">
    <a href="/manual/vote-note.php?id=41767&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V41767" title="62% like this...">
    14
    </div>
  </div>
  <a href="#41767" class="name">
  <strong class="user"><em>manicdepressive at mindless dot com</em></strong></a><a class="genanchor" href="#41767"> &para;</a><div class="date" title="2004-04-21 04:43"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom41767">
<div class="phpcode"><code><span class="html">
Be careful if distinguishing between NULL and (int)0.&nbsp; As implied in the above documentation, the case statements are equivalent to the '==' operator, not the '===' operator, so the following code did not work as i expected:<br /><br /><span class="default">&lt;?php<br />$mixed </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />switch(</span><span class="default">$mixed</span><span class="keyword">){<br />&nbsp;&nbsp; case </span><span class="default">NULL</span><span class="keyword">: echo </span><span class="string">"NULL"</span><span class="keyword">;&nbsp; break;<br />&nbsp;&nbsp; case </span><span class="default">0</span><span class="keyword">: echo </span><span class="string">"zero"</span><span class="keyword">;&nbsp; break;<br />&nbsp;&nbsp; default: echo </span><span class="string">"other"</span><span class="keyword">; break;<br />}<br /></span><span class="default">?&gt;<br /></span><br />Instead, I may use a chain of else-ifs.&nbsp; (On this page, kriek at jonkreik dot com states that "in most cases [a switch statement] is 15% faster [than an else-if chain]" but jemore at m6net dotdot fr claims that when using ===, if/elseif/elseif can be 2 times faster than a switch().)<br /><br />Alternatively, if i prefer the appearance of the switch() statement I may use a trick like the one nospam at please dot com presents:<br /><br /><span class="default">&lt;?php<br />$mixed </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />switch(</span><span class="default">TRUE</span><span class="keyword">){<br />&nbsp;&nbsp; case (</span><span class="default">NULL</span><span class="keyword">===</span><span class="default">$mixed</span><span class="keyword">): </span><span class="comment">//blah break;<br />&nbsp;&nbsp; </span><span class="keyword">case (</span><span class="default">0&nbsp;&nbsp; </span><span class="keyword">===</span><span class="default">$mixed</span><span class="keyword">): </span><span class="comment">//etc. break; <br /></span><span class="keyword">}<br /></span><span class="default">?&gt;<br /></span><br />code till dawn! mark meves!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="35778">  <div class="votes">
    <div id="Vu35778">
    <a href="/manual/vote-note.php?id=35778&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd35778">
    <a href="/manual/vote-note.php?id=35778&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V35778" title="58% like this...">
    3
    </div>
  </div>
  <a href="#35778" class="name">
  <strong class="user"><em>havar at henriksen dot nu</em></strong></a><a class="genanchor" href="#35778"> &para;</a><div class="date" title="2003-09-14 01:54"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom35778">
<div class="phpcode"><code><span class="html">
Remember, that you also could use functions in a switch.<br />For example, if you need to use regular expressions in a switch:<br /><br /><span class="default">&lt;?php<br />$browserName </span><span class="keyword">= </span><span class="string">'mozilla'</span><span class="keyword">;<br />switch (</span><span class="default">$browserName</span><span class="keyword">) {<br />&nbsp; case </span><span class="string">'opera'</span><span class="keyword">:<br />&nbsp; &nbsp; echo </span><span class="string">'opera'</span><span class="keyword">;<br />&nbsp; break;<br />&nbsp; case (</span><span class="default">preg_match</span><span class="keyword">(</span><span class="string">"/Mozilla( Firebird)?|phoenix/i"</span><span class="keyword">, </span><span class="default">$browserName</span><span class="keyword">)?</span><span class="default">$browserName</span><span class="keyword">:!</span><span class="default">$browserName</span><span class="keyword">):<br />&nbsp; &nbsp; echo </span><span class="string">"Mozilla or Mozilla Firebird"</span><span class="keyword">;<br />&nbsp; break;<br />&nbsp; case </span><span class="string">'konqueror'</span><span class="keyword">:<br />&nbsp; &nbsp; echo </span><span class="string">'Konqueror'</span><span class="keyword">;<br />&nbsp; break;<br />&nbsp; default:<br />&nbsp; &nbsp; echo </span><span class="string">'Default'</span><span class="keyword">;<br />&nbsp; break;<br />}<br /></span><span class="default">?&gt;<br /></span><br />or you could just use a regular expression for everything:<br /><br /><span class="default">&lt;?php<br />$uri </span><span class="keyword">= </span><span class="string">'<a href="http://www.example.com" rel="nofollow" target="_blank">http://www.example.com</a>'</span><span class="keyword">;<br />switch (</span><span class="default">true</span><span class="keyword">) {<br />&nbsp; case </span><span class="default">preg_match</span><span class="keyword">(</span><span class="string">"/</span><span class="default">$http</span><span class="string">(s)?/i"</span><span class="keyword">, </span><span class="default">$uri</span><span class="keyword">, </span><span class="default">$matches</span><span class="keyword">):<br />&nbsp; &nbsp; echo </span><span class="default">$uri </span><span class="keyword">. </span><span class="string">' is an http/https uri...'</span><span class="keyword">;<br />&nbsp; break;<br />&nbsp; case </span><span class="default">preg_match</span><span class="keyword">(</span><span class="string">"/</span><span class="default">$ftp</span><span class="string">(s)?/i"</span><span class="keyword">, </span><span class="default">$uri</span><span class="keyword">, </span><span class="default">$matches</span><span class="keyword">):<br />&nbsp; &nbsp; echo </span><span class="default">$uri </span><span class="keyword">. </span><span class="string">' is an ftp/ftps uri...'</span><span class="keyword">;<br />&nbsp; break;<br />&nbsp; default:<br />&nbsp; &nbsp; echo </span><span class="string">'default'</span><span class="keyword">;<br />&nbsp; break;<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116448">  <div class="votes">
    <div id="Vu116448">
    <a href="/manual/vote-note.php?id=116448&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116448">
    <a href="/manual/vote-note.php?id=116448&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116448" title="54% like this...">
    4
    </div>
  </div>
  <a href="#116448" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#116448"> &para;</a><div class="date" title="2015-01-05 11:27"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom116448">
<div class="phpcode"><code><span class="html">
Please note that PHP won't throw any error/warning if your `switch` utilizes more than one `default` - in such case it will just jump to the first one.<br /><br />Also note that you (for unknown reason for me) are allowed to use semicolons `;` along colon `:` for `case` and `default` entries:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">switch(</span><span class="default">$foo</span><span class="keyword">) {<br />&nbsp;&nbsp; case </span><span class="default">0</span><span class="keyword">:&nbsp; &nbsp; </span><span class="comment">// colon<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">...<br />&nbsp;&nbsp; break;<br /><br />&nbsp;&nbsp; case </span><span class="default">1</span><span class="keyword">;&nbsp; &nbsp; </span><span class="comment">// semicolon is fine<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">...<br />&nbsp;&nbsp; break;<br />}</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="107518">  <div class="votes">
    <div id="Vu107518">
    <a href="/manual/vote-note.php?id=107518&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd107518">
    <a href="/manual/vote-note.php?id=107518&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V107518" title="53% like this...">
    7
    </div>
  </div>
  <a href="#107518" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#107518"> &para;</a><div class="date" title="2012-02-14 09:39"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom107518">
<div class="phpcode"><code><span class="html">
Rewriting the function (to be three times faster) provided by [stever at ashomecare dot com 07-Sep-2007 09:11] and demonstrating points that others have made:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">getChineseZodiac</span><span class="keyword">(</span><span class="default">$year</span><span class="keyword">){<br /><br />&nbsp; &nbsp; switch (</span><span class="default">$year </span><span class="keyword">% </span><span class="default">12</span><span class="keyword">) :<br />&nbsp; &nbsp; &nbsp; &nbsp; case&nbsp; </span><span class="default">0</span><span class="keyword">: return </span><span class="string">'Monkey'</span><span class="keyword">;&nbsp; </span><span class="comment">// Years 0, 12, 1200, 2004...<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">case&nbsp; </span><span class="default">1</span><span class="keyword">: return </span><span class="string">'Rooster'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; case&nbsp; </span><span class="default">2</span><span class="keyword">: return </span><span class="string">'Dog'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; case&nbsp; </span><span class="default">3</span><span class="keyword">: return </span><span class="string">'Boar'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; case&nbsp; </span><span class="default">4</span><span class="keyword">: return </span><span class="string">'Rat'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; case&nbsp; </span><span class="default">5</span><span class="keyword">: return </span><span class="string">'Ox'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; case&nbsp; </span><span class="default">6</span><span class="keyword">: return </span><span class="string">'Tiger'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; case&nbsp; </span><span class="default">7</span><span class="keyword">: return </span><span class="string">'Rabit'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; case&nbsp; </span><span class="default">8</span><span class="keyword">: return </span><span class="string">'Dragon'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; case&nbsp; </span><span class="default">9</span><span class="keyword">: return </span><span class="string">'Snake'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">10</span><span class="keyword">: return </span><span class="string">'Horse'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">11</span><span class="keyword">: return </span><span class="string">'Lamb'</span><span class="keyword">;<br />&nbsp; &nbsp; endswitch;<br />}<br /><br />echo </span><span class="default">getChineseZodiac</span><span class="keyword">(</span><span class="default">2016</span><span class="keyword">);<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="71457">  <div class="votes">
    <div id="Vu71457">
    <a href="/manual/vote-note.php?id=71457&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd71457">
    <a href="/manual/vote-note.php?id=71457&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V71457" title="54% like this...">
    1
    </div>
  </div>
  <a href="#71457" class="name">
  <strong class="user"><em>2mareks (at) gmail (dot) com</em></strong></a><a class="genanchor" href="#71457"> &para;</a><div class="date" title="2006-11-29 03:03"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom71457">
<div class="phpcode"><code><span class="html">
In reply to earlier comment, "switch"- I found this to be one of the best ways to interpret 'actions'. Simply create a new instance of Handler_action before including any content source files. This is a highly stripped version of the class.<br /><br />The real one I created handles (and secures) input for $_GET and $_POST, creates a 'permission' array that only allows certain actions to be called by non-admins, and creates handy little diagnostic messages that can be displayed upon redirecting.<br /><br />On that note, the beauty in this class really shines in the simple redirect. You wont be left with ugly URLs like, "<a href="http://www.domain.com/path/to/script.php?action=blah&amp;var1=123" rel="nofollow" target="_blank">http://www.domain.com/path/to/script.php?action=blah&amp;var1=123</a>". Rather, you will be left with something like "<a href="http://www.domain.com/path/to/script.php" rel="nofollow" target="_blank">http://www.domain.com/path/to/script.php</a>"- helps protect some of the site by not showing any vulnerabilities in URLs.<br /><br />Also, this class keeps all actions organized neatly by directly passing $_GET vars to the actions through function parameters.<br /><br /><span class="default">&lt;?php<br />&nbsp; </span><span class="keyword">class </span><span class="default">Handler_action </span><span class="keyword">{<br />&nbsp; &nbsp; function </span><span class="default">__construct</span><span class="keyword">( ){<br />&nbsp; &nbsp; &nbsp; </span><span class="comment">//Add code here to secure attacks through $_GET or use $_POST<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$action </span><span class="keyword">= </span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">"action"</span><span class="keyword">];<br />&nbsp; <br />&nbsp; &nbsp; &nbsp; </span><span class="comment">//$actions_index conventions:<br />&nbsp; &nbsp; &nbsp; //'action_name' =&gt; array( 'arg1', 'arg2', 'etc', ['/redirect/to/path' | NULL ] )<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$actions_index </span><span class="keyword">= array(<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'create' </span><span class="keyword">=&gt; array( </span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">'newVar1'</span><span class="keyword">], </span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">'newVar2'</span><span class="keyword">], </span><span class="string">'/home.php' </span><span class="keyword">),<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'edit' </span><span class="keyword">=&gt; array( </span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">'id'</span><span class="keyword">], </span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">'otherVar'</span><span class="keyword">], </span><span class="string">'/home.php' </span><span class="keyword">),<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'delete' </span><span class="keyword">=&gt; array( </span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">'id'</span><span class="keyword">], </span><span class="string">'/other_script.php' </span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; );<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; if( </span><span class="default">$action </span><span class="keyword">&amp;&amp; </span><span class="default">array_key_exists</span><span class="keyword">( </span><span class="default">$action</span><span class="keyword">, </span><span class="default">$actions_index </span><span class="keyword">) ){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$redirect_path </span><span class="keyword">= </span><span class="default">array_pop</span><span class="keyword">( </span><span class="default">$actions_index</span><span class="keyword">[</span><span class="default">$action</span><span class="keyword">] );<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">call_user_func_array</span><span class="keyword">( array( &amp;</span><span class="default">$this</span><span class="keyword">, </span><span class="default">$action </span><span class="keyword">), </span><span class="default">$actions_index</span><span class="keyword">[</span><span class="default">$action</span><span class="keyword">] );<br />&nbsp; &nbsp; &nbsp; &nbsp; if( </span><span class="default">$redirect_path </span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">header</span><span class="keyword">( </span><span class="string">"Location: <a href="http://www.domain.com" rel="nofollow" target="_blank">http://www.domain.com</a></span><span class="keyword">{</span><span class="default">$redirect_path</span><span class="keyword">}</span><span class="string">" </span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">//being defining actions now<br />&nbsp; &nbsp; </span><span class="keyword">function </span><span class="default">create</span><span class="keyword">( </span><span class="default">$new_var1</span><span class="keyword">, </span><span class="default">$new_var2 </span><span class="keyword">){<br />&nbsp; <br />&nbsp; &nbsp; &nbsp; </span><span class="comment">//code...<br />&nbsp; <br />&nbsp; &nbsp; </span><span class="keyword">}<br />&nbsp; &nbsp; function </span><span class="default">edit</span><span class="keyword">( </span><span class="default">$id</span><span class="keyword">, </span><span class="default">$other_var </span><span class="keyword">){<br />&nbsp; <br />&nbsp; &nbsp; &nbsp; </span><span class="comment">//code...<br />&nbsp; <br />&nbsp; &nbsp; </span><span class="keyword">} <br />&nbsp; &nbsp; function </span><span class="default">delete</span><span class="keyword">( </span><span class="default">$id </span><span class="keyword">){<br />&nbsp; <br />&nbsp; &nbsp; &nbsp; </span><span class="comment">//code...<br />&nbsp; <br />&nbsp; &nbsp; </span><span class="keyword">}<br />&nbsp; }<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="87537">  <div class="votes">
    <div id="Vu87537">
    <a href="/manual/vote-note.php?id=87537&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd87537">
    <a href="/manual/vote-note.php?id=87537&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V87537" title="52% like this...">
    2
    </div>
  </div>
  <a href="#87537" class="name">
  <strong class="user"><em>Keil</em></strong></a><a class="genanchor" href="#87537"> &para;</a><div class="date" title="2008-12-09 08:06"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom87537">
<div class="phpcode"><code><span class="html">
As follow-up to ben dot lancaster at holler dot co dot uk's post:<br /><br />'continue' ends the switch, not the case, just as it would with any other flow control. Think of it as putting the execution pointer right before the ending accolade (that is, the }) because that is essentially what happens. In the case of a for loop, this would cause the iteration clause to execute, and if applicable, the loop to begin again. However, switches do not loop, which is why (as noted above, in the manual!) a continue statement essentially acts as a break when within a switch.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="95896">  <div class="votes">
    <div id="Vu95896">
    <a href="/manual/vote-note.php?id=95896&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd95896">
    <a href="/manual/vote-note.php?id=95896&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V95896" title="51% like this...">
    2
    </div>
  </div>
  <a href="#95896" class="name">
  <strong class="user"><em>lchanady at gmail dot com</em></strong></a><a class="genanchor" href="#95896"> &para;</a><div class="date" title="2010-01-27 09:56"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom95896">
<div class="phpcode"><code><span class="html">
Something fairly simple (and maybe obvious) that I didn't see mentioned is that the default case WILL be executed even if the switched variable does not exist or is undefined.<br /><br />For example:<br /><br /><span class="default">&lt;?php<br /><br />$a </span><span class="keyword">= </span><span class="string">"abc"</span><span class="keyword">;<br /></span><span class="default">$b </span><span class="keyword">= </span><span class="string">"def"</span><span class="keyword">;<br /><br />switch(</span><span class="default">$c</span><span class="keyword">){<br />&nbsp; &nbsp; case </span><span class="string">"a"</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"a"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; case </span><span class="string">"b"</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"b"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; default:<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"default"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />Will output: default<br /><br />Even though $c was never declared or defined, the default case will still be executed rather than PHP throwing an error.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="86911">  <div class="votes">
    <div id="Vu86911">
    <a href="/manual/vote-note.php?id=86911&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86911">
    <a href="/manual/vote-note.php?id=86911&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86911" title="51% like this...">
    1
    </div>
  </div>
  <a href="#86911" class="name">
  <strong class="user"><em>richard</em></strong></a><a class="genanchor" href="#86911"> &para;</a><div class="date" title="2008-11-10 01:32"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86911">
<div class="phpcode"><code><span class="html">
Just a word of warning about using switch don't try and compare variables that contain numbers with strings like so:<br /><br /><span class="default">&lt;?php<br />$i</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">;<br /><br />switch(</span><span class="default">$i</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; case </span><span class="string">'TEST'</span><span class="keyword">: print </span><span class="string">"Test"</span><span class="keyword">;break; <br />&nbsp; &nbsp; case </span><span class="default">0</span><span class="keyword">: print </span><span class="string">"0"</span><span class="keyword">;break;<br />}<br /></span><span class="default">?&gt;<br /></span><br />The output will be: Test and not 0.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116191">  <div class="votes">
    <div id="Vu116191">
    <a href="/manual/vote-note.php?id=116191&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116191">
    <a href="/manual/vote-note.php?id=116191&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116191" title="50% like this...">
    0
    </div>
  </div>
  <a href="#116191" class="name">
  <strong class="user"><em>info at maisuma dot jp</em></strong></a><a class="genanchor" href="#116191"> &para;</a><div class="date" title="2014-11-20 06:26"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom116191">
<div class="phpcode"><code><span class="html">
If you want to avoid numeric compare for numeric strings in switch statement, try prepending something non-numeric.<br /><br />e.g. <br /><span class="default">&lt;?php<br />$val</span><span class="keyword">=</span><span class="string">'2'</span><span class="keyword">;<br />switch(</span><span class="default">$val</span><span class="keyword">){<br />case </span><span class="string">'2.0' </span><span class="keyword">: echo </span><span class="string">'2.0!??'</span><span class="keyword">; break;<br />case </span><span class="string">'2' </span><span class="keyword">: echo </span><span class="string">'2.'</span><span class="keyword">; break;<br />}<br /></span><span class="default">?&gt;<br /></span>echoes '2.0!??' ; while prepended version<br /><span class="default">&lt;?php<br />$val</span><span class="keyword">=</span><span class="string">'2'</span><span class="keyword">;<br />switch(</span><span class="string">'#' </span><span class="keyword">. </span><span class="default">$val</span><span class="keyword">){<br />case </span><span class="string">'#2.0' </span><span class="keyword">: echo </span><span class="string">'2.0!??'</span><span class="keyword">; break;<br />case </span><span class="string">'#2' </span><span class="keyword">: echo </span><span class="string">'2.'</span><span class="keyword">; break;<br />}<br /></span><span class="default">?&gt;<br /></span>echoes '2.'.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="88643">  <div class="votes">
    <div id="Vu88643">
    <a href="/manual/vote-note.php?id=88643&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd88643">
    <a href="/manual/vote-note.php?id=88643&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V88643" title="49% like this...">
    -1
    </div>
  </div>
  <a href="#88643" class="name">
  <strong class="user"><em>sedativchunk at gmail dot com</em></strong></a><a class="genanchor" href="#88643"> &para;</a><div class="date" title="2009-02-01 09:22"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom88643">
<div class="phpcode"><code><span class="html">
Not sure if this has been posted or not, but I found the switch statement useful for finding ranges of data.<br /><br />This script creates web 2.0 style links in different font sizes (popular on blogs) using a randomizer and switch statement. I used links from within a database for a mod I made for a Simple Machines forums, but this example uses arrays for links if you wanted to add your own custom links:<br /><span class="default">&lt;?php<br /></span><span class="comment">// Create set of links<br /></span><span class="default">$link </span><span class="keyword">= array();<br /></span><span class="default">$link</span><span class="keyword">[] = </span><span class="string">'&lt;a href="whatever.html"&gt;page 1&lt;/a&gt;'</span><span class="keyword">;<br /></span><span class="default">$link</span><span class="keyword">[] = </span><span class="string">'&lt;a href="whatever.html"&gt;page 2&lt;/a&gt;'</span><span class="keyword">;<br /></span><span class="default">$link</span><span class="keyword">[] = </span><span class="string">'&lt;a href="whatever.html"&gt;page 3&lt;/a&gt;'</span><span class="keyword">;<br /></span><span class="default">$link</span><span class="keyword">[] = </span><span class="string">'&lt;a href="whatever.html"&gt;page 4&lt;/a&gt;'</span><span class="keyword">;<br /></span><span class="default">$link</span><span class="keyword">[] = </span><span class="string">'&lt;a href="whatever.html"&gt;page 5&lt;/a&gt;'</span><span class="keyword">;<br /></span><span class="default">$link</span><span class="keyword">[] = </span><span class="string">'&lt;a href="whatever.html"&gt;page 6&lt;/a&gt;'</span><span class="keyword">;<br /></span><span class="default">$link</span><span class="keyword">[] = </span><span class="string">'&lt;a href="whatever.html"&gt;page 7&lt;/a&gt;'</span><span class="keyword">;<br /></span><span class="default">$link</span><span class="keyword">[] = </span><span class="string">'&lt;a href="whatever.html"&gt;page 8&lt;/a&gt;'</span><span class="keyword">;<br /><br /></span><span class="comment">// Create loop to display links<br /></span><span class="keyword">for(</span><span class="default">$i </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">; </span><span class="default">$i </span><span class="keyword">&lt; </span><span class="default">count</span><span class="keyword">(</span><span class="default">$link</span><span class="keyword">); ++</span><span class="default">$i</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="comment">// Create randomizer<br />&nbsp; &nbsp; // Use switch statement to find font size<br />&nbsp; &nbsp; </span><span class="default">$randomizer </span><span class="keyword">= </span><span class="default">rand</span><span class="keyword">(</span><span class="default">1</span><span class="keyword">,</span><span class="default">50</span><span class="keyword">);<br />&nbsp; &nbsp; switch(</span><span class="default">$randomizer</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; case (</span><span class="default">$randomizer </span><span class="keyword">&lt;= </span><span class="default">20</span><span class="keyword">):<br />&nbsp; &nbsp; </span><span class="default">$font_size </span><span class="keyword">= </span><span class="string">"11"</span><span class="keyword">;<br />&nbsp; &nbsp; break;<br /><br />&nbsp; &nbsp; case (</span><span class="default">$randomizer </span><span class="keyword">&lt;= </span><span class="default">30</span><span class="keyword">):<br />&nbsp; &nbsp; </span><span class="default">$font_size </span><span class="keyword">= </span><span class="string">"16"</span><span class="keyword">;<br />&nbsp; &nbsp; break;<br /><br />&nbsp; &nbsp; case (</span><span class="default">$randomizer </span><span class="keyword">&lt;= </span><span class="default">40</span><span class="keyword">):<br />&nbsp; &nbsp; </span><span class="default">$font_size </span><span class="keyword">= </span><span class="string">"18"</span><span class="keyword">;<br />&nbsp; &nbsp; break;<br /><br />&nbsp; &nbsp; case (</span><span class="default">$randomizer </span><span class="keyword">&lt;= </span><span class="default">50</span><span class="keyword">):<br />&nbsp; &nbsp; </span><span class="default">$font_size </span><span class="keyword">= </span><span class="string">"20"</span><span class="keyword">;<br />&nbsp; &nbsp; break;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">// Display the link<br />&nbsp; &nbsp; </span><span class="keyword">echo </span><span class="string">'&lt;span style="font-size: ' </span><span class="keyword">.</span><span class="default">$font_size</span><span class="keyword">. </span><span class="string">';"&gt;' </span><span class="keyword">.</span><span class="default">$link</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">]. </span><span class="string">'&lt;/span&gt;&amp;nbsp;&amp;nbsp;'</span><span class="keyword">;<br /><br /></span><span class="comment">// Loop the next link<br /></span><span class="keyword">}<br /></span><span class="default">?&gt;<br /></span><br />Using this type of range randomizer is useful for game development and it can be useful on the web too, for things where you don't want to use a randomizer just for things like (1-5) where you wanted a more then likely result for one thing over another. The switch statement saves from writing spaghetti code if statements.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="86283">  <div class="votes">
    <div id="Vu86283">
    <a href="/manual/vote-note.php?id=86283&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86283">
    <a href="/manual/vote-note.php?id=86283&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86283" title="48% like this...">
    -1
    </div>
  </div>
  <a href="#86283" class="name">
  <strong class="user"><em>mar dot czapla at gmail dot com</em></strong></a><a class="genanchor" href="#86283"> &para;</a><div class="date" title="2008-10-10 02:17"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86283">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="comment">/* script 1&nbsp; */<br />&nbsp; &nbsp; </span><span class="default">$foo </span><span class="keyword">= </span><span class="string">"not a number"</span><span class="keyword">;<br />&nbsp; &nbsp; switch(</span><span class="default">false</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">"1"</span><span class="keyword">:&nbsp; &nbsp; {&nbsp; &nbsp; </span><span class="default">$foo </span><span class="keyword">= </span><span class="string">"1"</span><span class="keyword">;&nbsp; &nbsp; break;&nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">"2"</span><span class="keyword">:&nbsp; &nbsp; {&nbsp; &nbsp; </span><span class="default">$foo </span><span class="keyword">= </span><span class="string">"2"</span><span class="keyword">;&nbsp; &nbsp; break;&nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; default:&nbsp; &nbsp; {&nbsp; &nbsp; </span><span class="default">$foo </span><span class="keyword">= </span><span class="string">"0"</span><span class="keyword">;&nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; echo </span><span class="default">$foo</span><span class="keyword">;&nbsp; &nbsp; </span><span class="comment">// will produce "not a number"<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; /* script 2&nbsp; */<br />&nbsp; &nbsp; </span><span class="default">$foo </span><span class="keyword">= </span><span class="string">"not a number"</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$arr </span><span class="keyword">= array(</span><span class="string">"not a number"</span><span class="keyword">); </span><span class="comment">// 1 element only !<br />&nbsp; &nbsp; </span><span class="keyword">switch(</span><span class="default">$arr</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">])&nbsp; &nbsp; </span><span class="comment">// element $foo[1] doesn't defined <br />&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">"1"</span><span class="keyword">:&nbsp; &nbsp; {&nbsp; &nbsp; </span><span class="default">$foo </span><span class="keyword">= </span><span class="string">"1"</span><span class="keyword">;&nbsp; &nbsp; break;&nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">"2"</span><span class="keyword">:&nbsp; &nbsp; {&nbsp; &nbsp; </span><span class="default">$foo </span><span class="keyword">= </span><span class="string">"2"</span><span class="keyword">;&nbsp; &nbsp; break;&nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; default:&nbsp; &nbsp; {&nbsp; &nbsp; </span><span class="default">$foo </span><span class="keyword">= </span><span class="string">"0"</span><span class="keyword">;&nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; echo </span><span class="default">$foo</span><span class="keyword">;&nbsp; &nbsp; </span><span class="comment">// will produce "not a number" ( not 0 ! )<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; /* script 3&nbsp; */<br />&nbsp; &nbsp; </span><span class="default">$foo </span><span class="keyword">= </span><span class="string">"not a number"</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$arr </span><span class="keyword">= array(</span><span class="string">"not a number"</span><span class="keyword">); </span><span class="comment">// 1 element only !<br />&nbsp; &nbsp; </span><span class="keyword">switch(</span><span class="default">$arr</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]?</span><span class="default">$arr</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]:</span><span class="string">"1"</span><span class="keyword">)&nbsp; &nbsp; </span><span class="comment">// element $foo[1] doesn't defined <br />&nbsp; &nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">"1"</span><span class="keyword">:&nbsp; &nbsp; {&nbsp; &nbsp; </span><span class="default">$foo </span><span class="keyword">= </span><span class="string">"1"</span><span class="keyword">;&nbsp; &nbsp; break;&nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">"2"</span><span class="keyword">:&nbsp; &nbsp; {&nbsp; &nbsp; </span><span class="default">$foo </span><span class="keyword">= </span><span class="string">"2"</span><span class="keyword">;&nbsp; &nbsp; break;&nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; default:&nbsp; &nbsp; {&nbsp; &nbsp; </span><span class="default">$foo </span><span class="keyword">= </span><span class="string">"0"</span><span class="keyword">;&nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; echo </span><span class="default">$foo</span><span class="keyword">;&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">// will produce :<br />&nbsp; &nbsp; // 1 if $arr[1] isn't set<br />&nbsp; &nbsp; // 1 if $arr[1]=1<br />&nbsp; &nbsp; // 2 if $arr[1]=2<br />&nbsp; &nbsp; // 0 if none of above<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="115425">  <div class="votes">
    <div id="Vu115425">
    <a href="/manual/vote-note.php?id=115425&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115425">
    <a href="/manual/vote-note.php?id=115425&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115425" title="47% like this...">
    -2
    </div>
  </div>
  <a href="#115425" class="name">
  <strong class="user"><em>druellan at sfidastudios dot com</em></strong></a><a class="genanchor" href="#115425"> &para;</a><div class="date" title="2014-07-21 09:27"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115425">
<div class="phpcode"><code><span class="html">
Be careful if you have mixed types of values in the switch statement. Explicitly cast your variables where possible to avoid mismatch:<br /><br /><span class="default">&lt;?php<br />$var </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br /><br /></span><span class="comment">// This match case #1<br />// switch ( $var )<br /><br />// This works as expected<br /></span><span class="keyword">switch ( (string)</span><span class="default">$var </span><span class="keyword">)<br />{<br />&nbsp; case </span><span class="string">"0string"</span><span class="keyword">:<br />&nbsp; &nbsp; echo </span><span class="string">"0string match"</span><span class="keyword">;<br />&nbsp; &nbsp; break;<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="39155">  <div class="votes">
    <div id="Vu39155">
    <a href="/manual/vote-note.php?id=39155&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd39155">
    <a href="/manual/vote-note.php?id=39155&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V39155" title="48% like this...">
    -1
    </div>
  </div>
  <a href="#39155" class="name">
  <strong class="user"><em>gmgiles at pacbell dot net</em></strong></a><a class="genanchor" href="#39155"> &para;</a><div class="date" title="2004-01-19 01:07"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom39155">
<div class="phpcode"><code><span class="html">
Did you know that switch() and case() can also accomodate things like basic math calculations and counter incrementing? They do. In this example, I use a switch statement (which is inside of a while loop) to alternate the background color of a table row. It gives me a cool spool-printer-paper effect.<br /><br /><span class="default">&lt;?php<br />$rows_per_color </span><span class="keyword">= </span><span class="default">5</span><span class="keyword">;&nbsp; </span><span class="comment">// change bgcolor every 5 rows<br /></span><span class="keyword">switch(</span><span class="default">$ctr</span><span class="keyword">++) {<br />&nbsp; &nbsp; case </span><span class="default">0</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$bgcolor </span><span class="keyword">= </span><span class="string">"#ffffff"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; case (</span><span class="default">$rows_per_color</span><span class="keyword">):<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$bgcolor </span><span class="keyword">= </span><span class="string">"#ff0000"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; break;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; case (</span><span class="default">$rows_per_color </span><span class="keyword">* </span><span class="default">2</span><span class="keyword">):<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$bgcolor </span><span class="keyword">= </span><span class="string">"#ffffff"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$ctr </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; break;&nbsp; &nbsp; &nbsp; &nbsp; <br />}<br /></span><span class="default">?&gt;<br /></span><br />As you can see, I increment $ctr by 1 in the switch() itself, and the final case() does a simple calculation. Simple, but powerful. [Remember, the above example is inside of a while() loop... each time it iterates, switch increments $ctr.]</span>
</code></div>
  </div>
 </div>
  <div class="note" id="98225">  <div class="votes">
    <div id="Vu98225">
    <a href="/manual/vote-note.php?id=98225&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd98225">
    <a href="/manual/vote-note.php?id=98225&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V98225" title="46% like this...">
    -2
    </div>
  </div>
  <a href="#98225" class="name">
  <strong class="user"><em>theimp at iinet dot net dot au</em></strong></a><a class="genanchor" href="#98225"> &para;</a><div class="date" title="2010-06-02 01:04"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom98225">
<div class="phpcode"><code><span class="html">
It's easy to abuse the switch syntax to do some very useful things. As this example will show, the possibilities can go beyond even Duff's Device-style craziness (not that this example is nearly as clever as Duff's Device, but it demonstrates how you can do certain things other than simply the increment/decrement/assignment that's possible in C).<br /><br />Fundamentally, this works mostly due to the fact that, from the point of view of the assembler/interpreter, a switch block is hardly any different from a bunch of GOTO labels and&nbsp; if()&nbsp; evaluations. But, like an&nbsp; if() evaluation, the line of a case: statement is evaluated as an expression. So, in this case, we can perform an assignment and match the result of that assignment, because the return value of an assignment is the data that was assigned (and not the value of the variable it was assigned to, as you might expect).<br /><br />So far, this is not actually amazing, even if it is a bit unintuitive. From a language point-of-view, it would be the same as an&nbsp; if($var = "string")&nbsp; statement which is using an assignment (=) rather than a comparison (==) operator. When you look at the pre-processing optimization, because a normal assignment of $var = "string" will always equal "string", it makes sense to have the result of that expression simply be equal to the right side of the expression (the right side is used rather than the left to let the assembler/interpreter work faster, on account of how they traditionally simply change the memory location for the assigned variable rather than copy the memory around unnecessarily).<br /><br />Where this becomes more interesting is where, in PHP, you have language constructs that behave like functions but are used like statements. An&nbsp; $array[] = "string"&nbsp; expression is actually a language construct that just happens to behave a lot like a function, but you use it in the same way that you use an assignment expression, and like an expression, it always evaluates to the right side of the expression; in this case,&nbsp; "string"&nbsp; and not&nbsp; array() .<br /><br />The assembler/interpreter can't use the right side of the expression as a shortcut for the result of a function, so you can't use functions in this way in a case statement. You also can't get around this limit on calling functions from the case line by using variable functions, because they are used in the same way as functions.<br /><br />But imagine what you could do with other language constructs, like eval() or include() !<br /><br />Consider the following:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">flavor</span><span class="keyword">(</span><span class="default">$type </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; switch (</span><span class="default">$type</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">/* Note the isolation of break; statements and the fact that default: is at the top */<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">default:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$type </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">$array</span><span class="keyword">[] = </span><span class="string">"chocolate"</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$type </span><span class="keyword">!= </span><span class="default">null</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$array </span><span class="keyword">= array(</span><span class="default">$type</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">$array</span><span class="keyword">[] = </span><span class="string">"strawberry"</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$type </span><span class="keyword">!= </span><span class="default">null</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$array </span><span class="keyword">= array(</span><span class="default">$type</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">$array</span><span class="keyword">[] = </span><span class="string">"vanilla"</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$type </span><span class="keyword">!= </span><span class="default">null</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$array </span><span class="keyword">= array(</span><span class="default">$type</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; if ( (</span><span class="default">count</span><span class="keyword">(</span><span class="default">$array</span><span class="keyword">) != </span><span class="default">1</span><span class="keyword">) ) {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">"Flavors available: " </span><span class="keyword">. </span><span class="default">implode</span><span class="keyword">(</span><span class="string">", "</span><span class="keyword">, </span><span class="default">$array</span><span class="keyword">);<br />&nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">"Flavor selected: " </span><span class="keyword">. </span><span class="default">implode</span><span class="keyword">(</span><span class="string">", "</span><span class="keyword">, </span><span class="default">$array</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /><br />echo </span><span class="default">flavor</span><span class="keyword">() . </span><span class="string">"&lt;br&gt;"</span><span class="keyword">;<br /></span><span class="comment">/* Flavors available: chocolate, strawberry, vanilla */<br /><br /></span><span class="keyword">echo </span><span class="default">flavor</span><span class="keyword">(</span><span class="string">"banana"</span><span class="keyword">) . </span><span class="string">"&lt;br&gt;"</span><span class="keyword">;<br /></span><span class="comment">/* Flavors available: chocolate, strawberry, vanilla */<br /><br /></span><span class="keyword">echo </span><span class="default">flavor</span><span class="keyword">(</span><span class="string">"chocolate"</span><span class="keyword">) . </span><span class="string">"&lt;br&gt;"</span><span class="keyword">;<br /></span><span class="comment">/* Flavor selected: chocolate */<br /></span><span class="default">?&gt;<br /></span><br />What makes this example useful is that you don't need a variable somewhere that contains the available options (even within the function itself), so to support new options, you only ever have to change the code to add the new option - you don't need to update some variable somewhere that controls whether or not it works or whether or not people can tell that there's a new option.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="87959">  <div class="votes">
    <div id="Vu87959">
    <a href="/manual/vote-note.php?id=87959&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd87959">
    <a href="/manual/vote-note.php?id=87959&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V87959" title="46% like this...">
    -2
    </div>
  </div>
  <a href="#87959" class="name">
  <strong class="user"><em>hamiltont at gmail dot com</em></strong></a><a class="genanchor" href="#87959"> &para;</a><div class="date" title="2009-01-02 11:32"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom87959">
<div class="phpcode"><code><span class="html">
Example of default NOT included as the last item<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">switch(</span><span class="default">5</span><span class="keyword">) {<br />&nbsp; case </span><span class="default">1</span><span class="keyword">:<br />&nbsp; &nbsp; echo </span><span class="string">"1"</span><span class="keyword">;<br />&nbsp; &nbsp; break;<br />&nbsp; case </span><span class="default">2</span><span class="keyword">:<br />&nbsp; default:<br />&nbsp; &nbsp; echo </span><span class="string">"2, default"</span><span class="keyword">;<br />&nbsp; &nbsp; break;<br />&nbsp; case </span><span class="default">3</span><span class="keyword">;<br />&nbsp; &nbsp; echo </span><span class="string">"3"</span><span class="keyword">;<br />&nbsp; &nbsp; break;<br />}<br /></span><span class="default">?&gt;<br /></span><br />Outputs '2,default'<br /><br />very useful if you want your cases to be presented in a logical order in the code (as in, not saying case 1, case 3, case 2/default) and your cases are very long so you do not want to repeat the entire case code at the bottom for the default<br /><br />Hamy</span>
</code></div>
  </div>
 </div>
  <div class="note" id="39185">  <div class="votes">
    <div id="Vu39185">
    <a href="/manual/vote-note.php?id=39185&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd39185">
    <a href="/manual/vote-note.php?id=39185&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V39185" title="47% like this...">
    -1
    </div>
  </div>
  <a href="#39185" class="name">
  <strong class="user"><em>php dot net dot 1 at yogelements dot com</em></strong></a><a class="genanchor" href="#39185"> &para;</a><div class="date" title="2004-01-19 10:39"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom39185">
<div class="phpcode"><code><span class="html">
Declaring a variable (actually an array) as static w/in a switch{} spun my wool for a while:<br />don't:<br />&lt;?<br />function ss() {<br />&nbsp; &nbsp; switch ("bug") {<br />&nbsp; &nbsp; &nbsp; &nbsp; case "bug" :<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; static $test = "xyz";<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; default :<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; static $test = "abc";<br />&nbsp; &nbsp; }<br /> echo $test;<br />}<br />ss(); //abc<br />?&gt;<br />do:<br />&lt;?<br />function tt() {<br />&nbsp; &nbsp; static $test;<br />&nbsp; &nbsp; switch ("fix") {<br />&nbsp; &nbsp; &nbsp; &nbsp; case "fix" :<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; $test = "xyz";<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; default :<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; $test = "abc";<br />&nbsp; &nbsp; }<br /> echo $test;<br />}<br />tt(); // xyz<br />?&gt;</span>
</code></div>
  </div>
 </div>
  <div class="note" id="28778">  <div class="votes">
    <div id="Vu28778">
    <a href="/manual/vote-note.php?id=28778&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd28778">
    <a href="/manual/vote-note.php?id=28778&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V28778" title="46% like this...">
    -1
    </div>
  </div>
  <a href="#28778" class="name">
  <strong class="user"><em>rmunn at pobox dot com</em></strong></a><a class="genanchor" href="#28778"> &para;</a><div class="date" title="2003-01-23 11:21"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom28778">
<div class="phpcode"><code><span class="html">
In answer to njones at fredesign dot com, what you're seeing is the way the switch statement is supposed to work. The switch statement evaluates the cases, top to bottom, until it finds the first one that matches the value being switch()ed on. So, for example, if you had:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">switch(</span><span class="default">2</span><span class="keyword">) {<br />case </span><span class="default">1</span><span class="keyword">: echo </span><span class="string">"One\n"</span><span class="keyword">; break;<br />case </span><span class="default">2</span><span class="keyword">: echo </span><span class="string">"Two\n"</span><span class="keyword">; break;<br />case </span><span class="default">3</span><span class="keyword">: echo </span><span class="string">"Three\n"</span><span class="keyword">; break;<br />case </span><span class="default">2</span><span class="keyword">: echo </span><span class="string">"Two again\n"</span><span class="keyword">; break;<br />}<br /></span><span class="default">?&gt;<br /></span><br />Only "Two" would get echoed. "Two again" would NOT get echoed, because once the first case matches, the rest of them do NOT get evaluated. As soon as a matching case is found, the statements starting at that case get executed until the first break, then control flows out the bottom of the switch block.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="97832">  <div class="votes">
    <div id="Vu97832">
    <a href="/manual/vote-note.php?id=97832&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd97832">
    <a href="/manual/vote-note.php?id=97832&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V97832" title="45% like this...">
    -3
    </div>
  </div>
  <a href="#97832" class="name">
  <strong class="user"><em>mr at bwsolution dot de</em></strong></a><a class="genanchor" href="#97832"> &para;</a><div class="date" title="2010-05-11 02:29"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom97832">
<div class="phpcode"><code><span class="html">
"loose comparison" means that switch won't check the type. <br />switch will only compare values:<br /><span class="default">&lt;?php <br /></span><span class="keyword">if(</span><span class="string">'a string' </span><span class="keyword">== </span><span class="default">0</span><span class="keyword">) echo </span><span class="string">'a string is 0' </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;<br />if(</span><span class="string">'a string' </span><span class="keyword">=== </span><span class="default">0</span><span class="keyword">) echo </span><span class="string">'but you will never see this' </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;<br />switch(</span><span class="default">0</span><span class="keyword">){<br />&nbsp; &nbsp; case </span><span class="string">'a string'</span><span class="keyword">: echo </span><span class="string">'a string' </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;<br />&nbsp; &nbsp; case </span><span class="string">'another string'</span><span class="keyword">: echo </span><span class="string">'another string' </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;<br />}<br /><br />if(</span><span class="string">'a string' </span><span class="keyword">== </span><span class="default">true</span><span class="keyword">) echo </span><span class="string">'a string is TRUE' </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;<br />if(</span><span class="string">'a string' </span><span class="keyword">=== </span><span class="default">true</span><span class="keyword">) echo </span><span class="string">'but you will never see this' </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;<br />switch(</span><span class="default">true</span><span class="keyword">){<br />&nbsp; &nbsp; case </span><span class="string">'a string'</span><span class="keyword">: echo </span><span class="string">'a string' </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;<br />&nbsp; &nbsp; case </span><span class="string">'another string'</span><span class="keyword">: echo </span><span class="string">'another string' </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />will output:<br />a string is 0<br />a string<br />another string<br />a string is TRUE<br />a string<br />another string</span>
</code></div>
  </div>
 </div>
  <div class="note" id="21808">  <div class="votes">
    <div id="Vu21808">
    <a href="/manual/vote-note.php?id=21808&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd21808">
    <a href="/manual/vote-note.php?id=21808&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V21808" title="46% like this...">
    -1
    </div>
  </div>
  <a href="#21808" class="name">
  <strong class="user"><em>chernyshevsky at hotmail dot com</em></strong></a><a class="genanchor" href="#21808"> &para;</a><div class="date" title="2002-05-28 03:45"><strong>15 years ago</strong></div>
  <div class="text" id="Hcom21808">
<div class="phpcode"><code><span class="html">
Be very careful when you're using text strings as cases. If the variable supplied to switch() is an integer, the cases would be converted to integer before the comparison is made (usually to zero). The following snippet prints "hello".<br /><br /><span class="default">&lt;?php<br />$a </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />switch(</span><span class="default">$a</span><span class="keyword">) {<br /> case </span><span class="string">'Hello'</span><span class="keyword">: echo </span><span class="string">"Hello"</span><span class="keyword">;<br /> break;<br /> }<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="107530">  <div class="votes">
    <div id="Vu107530">
    <a href="/manual/vote-note.php?id=107530&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd107530">
    <a href="/manual/vote-note.php?id=107530&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V107530" title="44% like this...">
    -2
    </div>
  </div>
  <a href="#107530" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#107530"> &para;</a><div class="date" title="2012-02-15 06:29"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom107530">
<div class="phpcode"><code><span class="html">
Regarding [php_net at mcdragonsoftware dot com 17-Jun-2011 09:53]; the elegant function and syntax provided for an "inline switch" statement is more readable and about 25% faster than this alternative (that uses existing builtin functions), which produces the same result:<br /><br /><span class="default">&lt;?php </span><span class="keyword">echo </span><span class="default">array_pop</span><span class="keyword">(</span><span class="default">array_slice</span><span class="keyword">(array( </span><span class="string">'rock'</span><span class="keyword">, </span><span class="string">'paper'</span><span class="keyword">, </span><span class="string">'scissors' </span><span class="keyword">), --</span><span class="default">$roll</span><span class="keyword">, </span><span class="default">1</span><span class="keyword">)); </span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="86049">  <div class="votes">
    <div id="Vu86049">
    <a href="/manual/vote-note.php?id=86049&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86049">
    <a href="/manual/vote-note.php?id=86049&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86049" title="44% like this...">
    -3
    </div>
  </div>
  <a href="#86049" class="name">
  <strong class="user"><em>cretz</em></strong></a><a class="genanchor" href="#86049"> &para;</a><div class="date" title="2008-09-30 05:56"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86049">
<div class="phpcode"><code><span class="html">
Haven't seen it mentioned here, but at least in my version (PHP 5.2.5) and I'm sure all of PHP 5, the switch statement is a great way to check type safe enumerates that are otherwise missing in the PHP language. Example:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">WannabeEnum </span><span class="keyword">{<br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * @var WannabeEnum<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">public static </span><span class="default">$FOO</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * @var WannabeEnum<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">public static </span><span class="default">$BAR</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * @var WannabeEnum<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">public static </span><span class="default">$FOOBAR</span><span class="keyword">;<br />&nbsp; &nbsp; private </span><span class="default">$_ordinal</span><span class="keyword">;<br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$ordinal</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">_ordinal </span><span class="keyword">= </span><span class="default">$ordinal</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">WannabeEnum</span><span class="keyword">::</span><span class="default">$FOO </span><span class="keyword">= new </span><span class="default">WannabeEnum</span><span class="keyword">(</span><span class="default">1</span><span class="keyword">);<br /></span><span class="default">WannabeEnum</span><span class="keyword">::</span><span class="default">$BAR </span><span class="keyword">= new </span><span class="default">WannabeEnum</span><span class="keyword">(</span><span class="default">2</span><span class="keyword">);<br /></span><span class="default">WannabeEnum</span><span class="keyword">::</span><span class="default">$FOOBAR </span><span class="keyword">= new </span><span class="default">WannabeEnum</span><span class="keyword">(</span><span class="default">3</span><span class="keyword">);<br /><br />function </span><span class="default">testSwitch</span><span class="keyword">(</span><span class="default">WannabeEnum $wannabeEnum</span><span class="keyword">) {<br />&nbsp; &nbsp; switch(</span><span class="default">$wannabeEnum</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">WannabeEnum</span><span class="keyword">::</span><span class="default">$FOO</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo(</span><span class="string">'Foo!' </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">WannabeEnum</span><span class="keyword">::</span><span class="default">$BAR</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo(</span><span class="string">'Bar!' </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; default:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo(</span><span class="string">'Default!' </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">);<br />&nbsp; &nbsp; }&nbsp; &nbsp; <br />}<br /></span><span class="default">testSwitch</span><span class="keyword">(</span><span class="default">WannabeEnum</span><span class="keyword">::</span><span class="default">$FOO</span><span class="keyword">);<br /></span><span class="default">testSwitch</span><span class="keyword">(</span><span class="default">WannabeEnum</span><span class="keyword">::</span><span class="default">$FOOBAR</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />Outputs:<br /><br />Foo!<br />Default!<br /><br />Don't forget it uses loose comparisons!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="70788">  <div class="votes">
    <div id="Vu70788">
    <a href="/manual/vote-note.php?id=70788&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd70788">
    <a href="/manual/vote-note.php?id=70788&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V70788" title="44% like this...">
    -2
    </div>
  </div>
  <a href="#70788" class="name"><strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#70788"> &para;</a><div class="date" title="2006-10-27 03:29"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom70788">
<div class="phpcode"><code><span class="html">
I could have used a swich for this, but I found that using the array was much faster.<br /><br />&nbsp; &nbsp; $action = $_GET['action'];<br /><br />&nbsp; &nbsp; $pages = array<br />&nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; 'edit'&nbsp;&nbsp; =&gt; './edit.php',<br />&nbsp; &nbsp; &nbsp; 'search' =&gt; './search.php'<br />&nbsp; &nbsp; );<br /><br />&nbsp; &nbsp; if(strlen($pages[$action]) &gt; 0)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; require $pages[$action];<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; else<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; require './default.php';<br />&nbsp; &nbsp; }</span>
</code></div>
  </div>
 </div>
  <div class="note" id="92635">  <div class="votes">
    <div id="Vu92635">
    <a href="/manual/vote-note.php?id=92635&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd92635">
    <a href="/manual/vote-note.php?id=92635&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V92635" title="44% like this...">
    -3
    </div>
  </div>
  <a href="#92635" class="name">
  <strong class="user"><em>Ukuser</em></strong></a><a class="genanchor" href="#92635"> &para;</a><div class="date" title="2009-08-01 07:48"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom92635">
<div class="phpcode"><code><span class="html">
Again, just to re-iterate, if you supply 0 as the switched element, only the first statement will run if the comparison is with text.<br /><br /><span class="default">&lt;?php<br /><br />$in </span><span class="keyword">= array(</span><span class="string">'first'</span><span class="keyword">,</span><span class="default">0</span><span class="keyword">,</span><span class="string">"second"</span><span class="keyword">);<br /><br />foreach (</span><span class="default">$in </span><span class="keyword">as </span><span class="default">$a</span><span class="keyword">){<br />&nbsp; switch (</span><span class="default">$a</span><span class="keyword">){<br />&nbsp; &nbsp; case </span><span class="string">"first"</span><span class="keyword">: print </span><span class="string">"first&lt;br&gt;"</span><span class="keyword">; break;<br />&nbsp; &nbsp; case </span><span class="string">"second"</span><span class="keyword">: print </span><span class="string">"second&lt;br&gt;"</span><span class="keyword">; break;<br />&nbsp; }<br />} <br /><br /></span><span class="default">?&gt;<br /></span><br />This is annoying if you're using an array where you've got key's which could be text or numbers, so I'm using the suggested idea of:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">switch (</span><span class="default">true</span><span class="keyword">){<br />&nbsp; case (</span><span class="default">$a</span><span class="keyword">===</span><span class="string">"first"</span><span class="keyword">): print </span><span class="string">"first&lt;br&gt;"</span><span class="keyword">; break;<br />&nbsp; case (</span><span class="default">$a</span><span class="keyword">===</span><span class="string">"second"</span><span class="keyword">): print </span><span class="string">"second&lt;br&gt;"</span><span class="keyword">; break;<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />The reason for this as mentioned on <a href="http://uk3.php.net/ternary" rel="nofollow" target="_blank">http://uk3.php.net/ternary</a> is that: "If you compare an integer with a string, the string is converted to a number. If you compare two numerical strings, they are compared as integers. These rules also apply to the switch statement." Effectively it's saying if ($a=="first") which becomes does ($a (0) == 0) which is yes.<br /><br />In my example this mean't a date had a regular expression of an email applied to it which didnt help!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="21520">  <div class="votes">
    <div id="Vu21520">
    <a href="/manual/vote-note.php?id=21520&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd21520">
    <a href="/manual/vote-note.php?id=21520&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V21520" title="44% like this...">
    -3
    </div>
  </div>
  <a href="#21520" class="name">
  <strong class="user"><em>paz at spiralon dot com</em></strong></a><a class="genanchor" href="#21520"> &para;</a><div class="date" title="2002-05-15 07:44"><strong>15 years ago</strong></div>
  <div class="text" id="Hcom21520">
<div class="phpcode"><code><span class="html">
In case : ) it helps someone, I was able to clean up some hairball code by using nested switches (didn't see it mentioned here).&nbsp; Thanks to all those who are writing examples - I love this site!<br /><br /><span class="default">&lt;?php<br />$string_match</span><span class="keyword">=</span><span class="string">"second"</span><span class="keyword">;<br />switch (</span><span class="default">$string_match</span><span class="keyword">) {<br />case </span><span class="string">"first"</span><span class="keyword">:<br />case </span><span class="string">"second"</span><span class="keyword">:<br />case </span><span class="string">"third"</span><span class="keyword">:<br />&nbsp; &nbsp; print </span><span class="string">"&lt;H3&gt;Something for all three&lt;/H3&gt;&lt;br&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; switch (</span><span class="default">$string_match</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; case </span><span class="string">"first"</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; print </span><span class="string">"something for first only"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; case </span><span class="string">"second"</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; case </span><span class="string">"third"</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; print </span><span class="string">"something for the other two"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; }<br />break;<br />default:<br />print </span><span class="string">"&lt;H3&gt;no match&lt;/H3&gt;"</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="38106">  <div class="votes">
    <div id="Vu38106">
    <a href="/manual/vote-note.php?id=38106&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd38106">
    <a href="/manual/vote-note.php?id=38106&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V38106" title="41% like this...">
    -2
    </div>
  </div>
  <a href="#38106" class="name">
  <strong class="user"><em>jon</em></strong></a><a class="genanchor" href="#38106"> &para;</a><div class="date" title="2003-12-08 12:48"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom38106">
<div class="phpcode"><code><span class="html">
In response to the entry by "kriek at jonkriek dot com", I think you would probably be better of doing this:<br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="comment">// ensure $_GET['go'] is set, an integer, and not 0<br />&nbsp; &nbsp; // then, set nav number; default to 1<br />&nbsp; &nbsp; </span><span class="default">$nav </span><span class="keyword">= ( isset(</span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">'go'</span><span class="keyword">]) &amp;&amp; (</span><span class="default">intval</span><span class="keyword">(</span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">'go'</span><span class="keyword">]) == </span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">'go'</span><span class="keyword">]) &amp;&amp; </span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">'go'</span><span class="keyword">] ) ?<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">intval</span><span class="keyword">(</span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">'go'</span><span class="keyword">]) : </span><span class="default">1</span><span class="keyword">;<br /><br />&nbsp; &nbsp; </span><span class="comment">// format navigation string and include<br />&nbsp; &nbsp; </span><span class="keyword">include(</span><span class="default">sprintf</span><span class="keyword">(</span><span class="string">"Page%02d.php"</span><span class="keyword">,</span><span class="default">$nav</span><span class="keyword">));&nbsp; &nbsp; <br /></span><span class="default">?&gt;<br /></span><br />... as oppposed to the switch setup you recommended, which is limited to the number of cases you specify...</span>
</code></div>
  </div>
 </div>
  <div class="note" id="108080">  <div class="votes">
    <div id="Vu108080">
    <a href="/manual/vote-note.php?id=108080&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd108080">
    <a href="/manual/vote-note.php?id=108080&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V108080" title="40% like this...">
    -5
    </div>
  </div>
  <a href="#108080" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#108080"> &para;</a><div class="date" title="2012-03-27 11:34"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom108080">
<div class="phpcode"><code><span class="html">
Switch usage for make some actions with all of cases<br /><br /><span class="default">&lt;?php<br />$out </span><span class="keyword">= </span><span class="string">' '</span><span class="keyword">;<br />for (</span><span class="default">$i</span><span class="keyword">=</span><span class="default">1</span><span class="keyword">;</span><span class="default">$i</span><span class="keyword">&lt;</span><span class="default">10</span><span class="keyword">:</span><span class="default">$i</span><span class="keyword">++) {<br />&nbsp;&nbsp; switch (</span><span class="default">$i</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; case </span><span class="default">true</span><span class="keyword">: </span><span class="default">$out </span><span class="keyword">.= </span><span class="string">'test_'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; case </span><span class="default">1</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; case </span><span class="default">2</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; case </span><span class="default">3</span><span class="keyword">: </span><span class="default">$out </span><span class="keyword">.= </span><span class="default">$i</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; default: </span><span class="default">$out </span><span class="keyword">.= </span><span class="string">' '</span><span class="keyword">;<br />&nbsp;&nbsp; }<br />}<br />echo </span><span class="default">$out</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />That sample out:<br /><br />" test_1 test_2 test_3 "</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114274">  <div class="votes">
    <div id="Vu114274">
    <a href="/manual/vote-note.php?id=114274&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114274">
    <a href="/manual/vote-note.php?id=114274&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114274" title="39% like this...">
    -5
    </div>
  </div>
  <a href="#114274" class="name">
  <strong class="user"><em>Gutza</em></strong></a><a class="genanchor" href="#114274"> &para;</a><div class="date" title="2014-01-31 10:05"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114274">
<div class="phpcode"><code><span class="html">
Sometimes you need to execute a common piece of code for several cases, and then execute some special code for each of those cases in particular. You'd then be tempted to duplicate "case" entries, like so:<br /><br /><span class="default">&lt;?php<br /><br />$health </span><span class="keyword">= </span><span class="default">50</span><span class="keyword">;<br /></span><span class="default">$prevActionType </span><span class="keyword">= </span><span class="string">"none"</span><span class="keyword">;<br /><br /></span><span class="default">$action </span><span class="keyword">= </span><span class="string">"kill"</span><span class="keyword">;<br /><br />switch(</span><span class="default">$action</span><span class="keyword">) {<br /><br />case </span><span class="string">"heal"</span><span class="keyword">:<br />&nbsp; </span><span class="default">$prevActionType </span><span class="keyword">= </span><span class="string">"good"</span><span class="keyword">;<br />&nbsp; </span><span class="default">$health </span><span class="keyword">+= </span><span class="default">10</span><span class="keyword">;<br />&nbsp; break;<br /><br />case </span><span class="string">"hurt"</span><span class="keyword">:<br />case </span><span class="string">"kill"</span><span class="keyword">:<br />&nbsp; </span><span class="default">$prevActionType </span><span class="keyword">= </span><span class="string">"bad"</span><span class="keyword">;<br />&nbsp; break;<br /><br />case </span><span class="string">"hurt"</span><span class="keyword">:<br />&nbsp; </span><span class="default">$health </span><span class="keyword">-= </span><span class="default">10</span><span class="keyword">;<br />&nbsp; break;<br /><br />case </span><span class="string">"kill"</span><span class="keyword">:<br />&nbsp; </span><span class="default">$health </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />&nbsp; break;<br /><br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />That won't work as intended -- you'll enter at the first case that matches ($prevActionType = "bad") and then exit the switch altogether.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="28637">  <div class="votes">
    <div id="Vu28637">
    <a href="/manual/vote-note.php?id=28637&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd28637">
    <a href="/manual/vote-note.php?id=28637&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V28637" title="40% like this...">
    -2
    </div>
  </div>
  <a href="#28637" class="name">
  <strong class="user"><em>theonly dot mcseven at gmx dot net</em></strong></a><a class="genanchor" href="#28637"> &para;</a><div class="date" title="2003-01-18 08:44"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom28637">
<div class="phpcode"><code><span class="html">
working a bit around with it I found out that it is not possible to<br />compare the variable with two different values in one step like this<br />(system running a w2k server, apache2.0.43 &amp; php430):<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">switch (</span><span class="default">$myvar</span><span class="keyword">) {<br /> case (</span><span class="string">"foo" </span><span class="keyword">|| </span><span class="string">"bar"</span><span class="keyword">): </span><span class="comment">//do something<br /> </span><span class="keyword">break;<br /> case (</span><span class="string">"other"</span><span class="keyword">): </span><span class="comment">//do another thing<br /> </span><span class="keyword">break;<br /> default: <br />}<br /></span><span class="default">?&gt;<br /></span><br />rather use:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">switch (</span><span class="default">$myvar</span><span class="keyword">) {<br /> case (</span><span class="string">"foo"</span><span class="keyword">):<br /> case (</span><span class="string">"bar"</span><span class="keyword">): </span><span class="comment">//do something<br /> </span><span class="keyword">break;<br /> case (</span><span class="string">"other"</span><span class="keyword">): </span><span class="comment">//do another thing<br /> </span><span class="keyword">break;<br /> default:<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="97112">  <div class="votes">
    <div id="Vu97112">
    <a href="/manual/vote-note.php?id=97112&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd97112">
    <a href="/manual/vote-note.php?id=97112&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V97112" title="38% like this...">
    -4
    </div>
  </div>
  <a href="#97112" class="name">
  <strong class="user"><em>hackajar  yahoo  com</em></strong></a><a class="genanchor" href="#97112"> &para;</a><div class="date" title="2010-04-01 03:21"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom97112">
<div class="phpcode"><code><span class="html">
Apparently you need to be extra careful with "0" (zero) in your case statements when mixing int and string values:<br /><br />switch($key) {<br />&nbsp; &nbsp;&nbsp; case 0: echo "only if I am zero";break;<br />&nbsp; &nbsp;&nbsp; case 1: echo "I'm one";break;<br />&nbsp; &nbsp;&nbsp; case "E1": echo "Why don't you output me?";break;<br />&nbsp; &nbsp;&nbsp; default: echo "No value Found";<br />}<br /><br />Switch will be convinced that you mean "0" when you really mean "E1" unless you wrap it in quotes:<br /><br />switch($key) {<br />&nbsp; &nbsp;&nbsp; case '0': echo "only if I am zero";break;<br />&nbsp; &nbsp;&nbsp; case 1: echo "I'm one";break;<br />&nbsp; &nbsp;&nbsp; case "E1":echo "Yay! I'm back!";break;<br />&nbsp; &nbsp;&nbsp; default: echo "No value Found";<br />}<br /><br />Maybe this is what they mean by "loose comparison" with True, False operators?</span>
</code></div>
  </div>
 </div>
  <div class="note" id="86408">  <div class="votes">
    <div id="Vu86408">
    <a href="/manual/vote-note.php?id=86408&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86408">
    <a href="/manual/vote-note.php?id=86408&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86408" title="38% like this...">
    -4
    </div>
  </div>
  <a href="#86408" class="name">
  <strong class="user"><em>ben dot lancaster at holler dot co dot uk</em></strong></a><a class="genanchor" href="#86408"> &para;</a><div class="date" title="2008-10-16 03:46"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86408">
<div class="phpcode"><code><span class="html">
Following on from bensphpnetemail at supernaut dot org's post, it would seem that 'continue' doesn't really continue at all. Consider the following:<br /><br /><span class="default">&lt;?php<br />$foo </span><span class="keyword">= </span><span class="string">'bar'</span><span class="keyword">;<br /></span><span class="default">$bar </span><span class="keyword">= </span><span class="default">true</span><span class="keyword">;<br /><br />switch(</span><span class="default">$foo</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; case </span><span class="string">'bar'</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">$bar</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; continue;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'$bar is false'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br /><br />&nbsp; &nbsp; case </span><span class="string">'bar'</span><span class="keyword">:<br />&nbsp; &nbsp; case </span><span class="string">'foo'</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'$bar is true, or $foo is foo'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; default:<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"You shouldnt ever get here"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />I would expect the above to output "$bar is true, or $foo is foo", but it doesn't output anything. The continue statement acts as a break and stops evaluating the rest of the matching cases.<br /><br />Instead, you should issue a 'break' statement conditionally to achieve the desired result.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="70652">  <div class="votes">
    <div id="Vu70652">
    <a href="/manual/vote-note.php?id=70652&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd70652">
    <a href="/manual/vote-note.php?id=70652&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V70652" title="38% like this...">
    -3
    </div>
  </div>
  <a href="#70652" class="name">
  <strong class="user"><em>sneskid at hotmail dot com</em></strong></a><a class="genanchor" href="#70652"> &para;</a><div class="date" title="2006-10-23 04:38"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom70652">
<div class="phpcode"><code><span class="html">
In regard to what dohpaz at kennethpaul dot com wrote.<br /><br />If you ever have time you may want to test out having a premade associative array with the required elements eaqualing the needed value. Then assign the value based on the array element.<br /><br />in dohpaz's month example it would look like this:<br /><span class="default">&lt;?php<br />$arr_month </span><span class="keyword">= array(<br /></span><span class="string">'January' </span><span class="keyword">=&gt; </span><span class="default">1</span><span class="keyword">,<br /></span><span class="string">'February' </span><span class="keyword">=&gt; </span><span class="default">2</span><span class="keyword">,<br /></span><span class="string">'March' </span><span class="keyword">=&gt; </span><span class="default">3</span><span class="keyword">,<br /></span><span class="string">'April' </span><span class="keyword">=&gt; </span><span class="default">4</span><span class="keyword">,<br /></span><span class="string">'May' </span><span class="keyword">=&gt; </span><span class="default">5</span><span class="keyword">,<br /></span><span class="string">'June' </span><span class="keyword">=&gt; </span><span class="default">6</span><span class="keyword">,<br /></span><span class="string">'July' </span><span class="keyword">=&gt; </span><span class="default">7</span><span class="keyword">,<br /></span><span class="string">'August' </span><span class="keyword">=&gt; </span><span class="default">8</span><span class="keyword">,<br /></span><span class="string">'September' </span><span class="keyword">=&gt; </span><span class="default">9</span><span class="keyword">,<br /></span><span class="string">'October' </span><span class="keyword">=&gt; </span><span class="default">10</span><span class="keyword">,<br /></span><span class="string">'November' </span><span class="keyword">=&gt; </span><span class="default">11</span><span class="keyword">,<br /></span><span class="string">'December' </span><span class="keyword">=&gt; </span><span class="default">12</span><span class="keyword">);<br />foreach(</span><span class="default">$arr_month </span><span class="keyword">as </span><span class="default">$k </span><span class="keyword">=&gt; </span><span class="default">$v</span><span class="keyword">) {</span><span class="default">$arr_month</span><span class="keyword">[</span><span class="default">substr</span><span class="keyword">(</span><span class="default">$k</span><span class="keyword">,</span><span class="default">0</span><span class="keyword">,</span><span class="default">3</span><span class="keyword">)] = </span><span class="default">$v</span><span class="keyword">;} </span><span class="comment">// autogen a 3 letter version<br /><br />//note that the overall size will be 23 because May will only exist once<br /><br /></span><span class="default">$month </span><span class="keyword">= </span><span class="string">'Jan'</span><span class="keyword">;<br /></span><span class="default">$month </span><span class="keyword">= </span><span class="default">$arr_months</span><span class="keyword">[</span><span class="default">$month</span><span class="keyword">];<br />echo </span><span class="default">$month</span><span class="keyword">; </span><span class="comment">// outputs: 1<br /></span><span class="default">?&gt;<br /></span><br />It beats a switch in this case.<br /><br />I did some benchmarking.<br />The array system is faster than the switch system.<br /><br />Here were my average time results of 1000 itterations of assigning the numeric value to the month.<br />The value was randomized between each itteration (this was not added to the benchmark value), so each method was simulated with various data to stress different points.<br /><br />array:<br />'avg' =&gt; 1.09958648682E-6<br />switch:<br />'avg' =&gt; 4.32157516479E-6<br />switch (true):<br />'avg' =&gt; 6.90913200378E-6<br /><br />Contrary to what dohpaz suggested I found that a normal switch was faster than a switch(true) version.<br /><br />I repeated these test several times to take into acount server load variations. The ratios were always consistent.<br /><br />The array way is notably faster.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="105125">  <div class="votes">
    <div id="Vu105125">
    <a href="/manual/vote-note.php?id=105125&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd105125">
    <a href="/manual/vote-note.php?id=105125&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V105125" title="37% like this...">
    -4
    </div>
  </div>
  <a href="#105125" class="name">
  <strong class="user"><em>Bas Vijfwinkel</em></strong></a><a class="genanchor" href="#105125"> &para;</a><div class="date" title="2011-07-28 06:03"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom105125">
<div class="phpcode"><code><span class="html">
If you want to avoid problems with loose comparison and strings in case statements (0 matching the first string case), you can use an explicit string cast in the switch statement:<br /><br />switch((string)$switchkey) {...}<br /><br />If $switchkey is 0 then the switch statement will either jump to the 'default' case or execute nothing at all (if there is no 'default' case present).<br /><br /><span class="default">&lt;?php<br /><br />$switchkey </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br /><br />if(</span><span class="string">'a string' </span><span class="keyword">== </span><span class="default">$switchkey</span><span class="keyword">) echo </span><span class="string">'a string is 0' </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;<br />if(</span><span class="string">'a string' </span><span class="keyword">=== </span><span class="default">$switchkey</span><span class="keyword">) echo </span><span class="string">'but you will never see this' </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;<br /><br />switch(</span><span class="default">$switchkey</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; case </span><span class="string">'a string'</span><span class="keyword">: echo </span><span class="string">'switch string test without explicit cast:'</span><span class="keyword">.</span><span class="default">$switchkey</span><span class="keyword">.</span><span class="string">' is a string (this is not what we want to see)' </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;break;<br />&nbsp; &nbsp; case </span><span class="string">'another string'</span><span class="keyword">: echo </span><span class="string">'switch string test without explicit cast: '</span><span class="keyword">.</span><span class="default">$switchkey</span><span class="keyword">.</span><span class="string">' is another string' </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;break;<br />&nbsp; &nbsp; default: echo </span><span class="string">'switch string test without explicit cast: default :'</span><span class="keyword">.</span><span class="default">$switchkey</span><span class="keyword">.</span><span class="string">' is somethign else (this is the correct choice)' </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;break;<br />}<br />switch((string)</span><span class="default">$switchkey</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; case </span><span class="string">'a string'</span><span class="keyword">: echo </span><span class="string">'switch string test with explicit cast:'</span><span class="keyword">.</span><span class="default">$switchkey</span><span class="keyword">.</span><span class="string">' is a string (this is not what we want to see)' </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;break;<br />&nbsp; &nbsp; case </span><span class="string">'another string'</span><span class="keyword">: echo </span><span class="string">'switch string test with explicit cast: '</span><span class="keyword">.</span><span class="default">$switchkey</span><span class="keyword">.</span><span class="string">' is another string' </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;break;<br />&nbsp; &nbsp; default: echo </span><span class="string">'switch string test with explicit cast: default :'</span><span class="keyword">.</span><span class="default">$switchkey</span><span class="keyword">.</span><span class="string">' is something else (this is the correct choice)' </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;break;<br />}<br /><br /></span><span class="default">$switchkey </span><span class="keyword">= </span><span class="default">true</span><span class="keyword">;<br /><br />if(</span><span class="string">'a string' </span><span class="keyword">== </span><span class="default">$switchkey</span><span class="keyword">) echo </span><span class="string">'a string is TRUE' </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;<br />if(</span><span class="string">'a string' </span><span class="keyword">=== </span><span class="default">$switchkey</span><span class="keyword">) echo </span><span class="string">'but you will never see this' </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;<br /><br />switch(</span><span class="default">$switchkey</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; case </span><span class="string">'a string'</span><span class="keyword">: echo </span><span class="string">'Switch boolean test without explicit cast:'</span><span class="keyword">.</span><span class="default">$switchkey</span><span class="keyword">.</span><span class="string">' is a string (this is not what we want to see)' </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;break;<br />&nbsp; &nbsp; case </span><span class="string">'another string'</span><span class="keyword">: echo </span><span class="string">'Switch boolean test without explicit cast: '</span><span class="keyword">.</span><span class="default">$switchkey</span><span class="keyword">.</span><span class="string">' is another string' </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;break;<br />&nbsp; &nbsp; default : echo </span><span class="string">'Switch boolean test : default without explicit cast: '</span><span class="keyword">.</span><span class="default">$switchkey</span><span class="keyword">.</span><span class="string">' is something else (this is the correct choice)' </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;break;<br />}<br />switch((string)</span><span class="default">$switchkey</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; case </span><span class="string">'a string'</span><span class="keyword">: echo </span><span class="string">'Switch boolean test with explicit cast:'</span><span class="keyword">.</span><span class="default">$switchkey</span><span class="keyword">.</span><span class="string">' is a string (this is not what we want to see)' </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;break;<br />&nbsp; &nbsp; case </span><span class="string">'another string'</span><span class="keyword">: echo </span><span class="string">'Switch boolean test with explicit cast: '</span><span class="keyword">.</span><span class="default">$switchkey</span><span class="keyword">.</span><span class="string">' is another string' </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;break;<br />&nbsp; &nbsp; default : echo </span><span class="string">'Switch boolean test&nbsp; with explicit cast: default:s '</span><span class="keyword">.</span><span class="default">$switchkey</span><span class="keyword">.</span><span class="string">' is something else (this is the correct choice)' </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;break;<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />The script will output :<br /><br />a string is 0<br />switch string test without explicit cast:0 is a string (this is not what we want to see)<br />switch string test with explicit cast: default :0 is something else (this is the correct choice)<br />a string is TRUE<br />Switch boolean test without explicit cast:1 is a string (this is not what we want to see)<br />Switch boolean test with explicit cast: default:s 1 is something else (this is the correct choice)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116332">  <div class="votes">
    <div id="Vu116332">
    <a href="/manual/vote-note.php?id=116332&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116332">
    <a href="/manual/vote-note.php?id=116332&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116332" title="36% like this...">
    -3
    </div>
  </div>
  <a href="#116332" class="name">
  <strong class="user"><em>farzan dot fx at outlook dot com</em></strong></a><a class="genanchor" href="#116332"> &para;</a><div class="date" title="2014-12-14 09:24"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom116332">
<div class="phpcode"><code><span class="html">
if and switch statement :&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; <span class="default">&lt;?php<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $gender </span><span class="keyword">= </span><span class="string">"male"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$nam </span><span class="keyword">=</span><span class="string">"johnson"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$gender</span><span class="keyword">===</span><span class="string">"male"</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"hello Mr. </span><span class="keyword">{</span><span class="default">$nam</span><span class="keyword">}</span><span class="string">"</span><span class="keyword">;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }elseif (</span><span class="default">$gender </span><span class="keyword">=== </span><span class="string">"female"</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"hello Mrs. </span><span class="keyword">{</span><span class="default">$nam</span><span class="keyword">}</span><span class="string">"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }elseif (</span><span class="default">$gender</span><span class="keyword">=== </span><span class="string">"Doc"</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"hello Dr.</span><span class="keyword">{</span><span class="default">$nam</span><span class="keyword">}</span><span class="string">"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Hello Human!"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">?&gt;<br /></span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &lt;hr&gt;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &lt;!--<br />===========================================<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; --&gt;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <span class="default">&lt;?php<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">switch (</span><span class="default">$gender</span><span class="keyword">){ <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">"female"&nbsp; </span><span class="keyword">:echo&nbsp; </span><span class="string">"hello Mrs. </span><span class="keyword">{</span><span class="default">$nam</span><span class="keyword">}</span><span class="string">"</span><span class="keyword">;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">"male"&nbsp; &nbsp; &nbsp; </span><span class="keyword">:echo </span><span class="string">"hello Mr. </span><span class="keyword">{</span><span class="default">$nam</span><span class="keyword">}</span><span class="string">"</span><span class="keyword">;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">"Doc"&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">:echo </span><span class="string">"hello Dr. </span><span class="keyword">{</span><span class="default">$nam</span><span class="keyword">}</span><span class="string">" </span><span class="keyword">;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; default : </span><span class="string">"Hello Human!"</span><span class="keyword">;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; break;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; } <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="31800">  <div class="votes">
    <div id="Vu31800">
    <a href="/manual/vote-note.php?id=31800&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd31800">
    <a href="/manual/vote-note.php?id=31800&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V31800" title="38% like this...">
    -3
    </div>
  </div>
  <a href="#31800" class="name">
  <strong class="user"><em>shawn at evilest dot net</em></strong></a><a class="genanchor" href="#31800"> &para;</a><div class="date" title="2003-05-04 02:50"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom31800">
<div class="phpcode"><code><span class="html">
You can also nest switch statements inside case statements:<br /><br /><span class="default">&lt;?php<br />&nbsp;&nbsp; </span><span class="comment">// Set argument handlers<br />&nbsp; &nbsp; </span><span class="default">$argv </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">(</span><span class="string">","</span><span class="keyword">, </span><span class="default">urldecode</span><span class="keyword">(</span><span class="default">getenv</span><span class="keyword">(</span><span class="string">'QUERY_STRING'</span><span class="keyword">)));<br />&nbsp; &nbsp; </span><span class="default">$argc </span><span class="keyword">= </span><span class="default">array_shift</span><span class="keyword">(</span><span class="default">$argv</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$argd </span><span class="keyword">= </span><span class="default">array_shift</span><span class="keyword">(</span><span class="default">$argv</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$arge </span><span class="keyword">= </span><span class="default">array_shift</span><span class="keyword">(</span><span class="default">$argv</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />&nbsp;&nbsp; // Begin switching<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">switch (</span><span class="default">$argc</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">'home'</span><span class="keyword">: {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; print(</span><span class="string">'This is $argc, home case.'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">'subsection'</span><span class="keyword">: {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; switch (</span><span class="default">$argd</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; case </span><span class="string">'links'</span><span class="keyword">: {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; switch(</span><span class="default">$arge</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">'display'</span><span class="keyword">: {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; print(</span><span class="string">'This is $arge, subsection,links,display case.'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="20090">  <div class="votes">
    <div id="Vu20090">
    <a href="/manual/vote-note.php?id=20090&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd20090">
    <a href="/manual/vote-note.php?id=20090&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V20090" title="38% like this...">
    -4
    </div>
  </div>
  <a href="#20090" class="name">
  <strong class="user"><em>gray dot quinn at catch-e dot com dot au</em></strong></a><a class="genanchor" href="#20090"> &para;</a><div class="date" title="2002-03-21 10:00"><strong>15 years ago</strong></div>
  <div class="text" id="Hcom20090">
<div class="phpcode"><code><span class="html">
To get the conditional statement to work for the above example use this:<br /><br /><span class="default">&lt;?php<br />$chr </span><span class="keyword">= </span><span class="default">substr</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">,</span><span class="default">$i</span><span class="keyword">,</span><span class="default">1</span><span class="keyword">);<br />switch (</span><span class="default">TRUE</span><span class="keyword">) {<br /><br />case </span><span class="default">$chr </span><span class="keyword">== </span><span class="string">"�" </span><span class="keyword">|| </span><span class="default">$chr </span><span class="keyword">== </span><span class="string">"�" </span><span class="keyword">|| </span><span class="default">$chr </span><span class="keyword">== </span><span class="string">"�" </span><span class="keyword">|| </span><span class="default">$chr </span><span class="keyword">== </span><span class="string">"�"</span><span class="keyword">:<br /></span><span class="default">$a </span><span class="keyword">= </span><span class="default">str_replace</span><span class="keyword">(</span><span class="default">substr</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">,</span><span class="default">$i</span><span class="keyword">,</span><span class="default">1</span><span class="keyword">),</span><span class="string">"a"</span><span class="keyword">,</span><span class="default">$a</span><span class="keyword">);<br />break;<br /><br />case </span><span class="default">$chr </span><span class="keyword">== </span><span class="string">"�" </span><span class="keyword">|| </span><span class="default">$chr </span><span class="keyword">== </span><span class="string">"�" </span><span class="keyword">|| </span><span class="default">$chr </span><span class="keyword">== </span><span class="string">"�"</span><span class="keyword">:<br /></span><span class="default">$a </span><span class="keyword">= </span><span class="default">str_replace</span><span class="keyword">(</span><span class="default">substr</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">,</span><span class="default">$i</span><span class="keyword">,</span><span class="default">1</span><span class="keyword">),</span><span class="string">"e"</span><span class="keyword">,</span><span class="default">$a</span><span class="keyword">);<br />break;<br /></span><span class="default">?&gt;<br /></span><br />}</span>
</code></div>
  </div>
 </div>
  <div class="note" id="14301">  <div class="votes">
    <div id="Vu14301">
    <a href="/manual/vote-note.php?id=14301&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd14301">
    <a href="/manual/vote-note.php?id=14301&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V14301" title="38% like this...">
    -3
    </div>
  </div>
  <a href="#14301" class="name">
  <strong class="user"><em>x@x</em></strong></a><a class="genanchor" href="#14301"> &para;</a><div class="date" title="2001-07-25 02:29"><strong>16 years ago</strong></div>
  <div class="text" id="Hcom14301">
<div class="phpcode"><code><span class="html">
often you will have to perform multiple actions in sequence, but this sequence must be broken once one of them detects a stop condition (such as an error, when validating form request variables).<br />One way is to use:<br /><br />if (check1()<br />&amp;&amp; check2()<br />&amp;&amp; check3()<br />) valid();<br />else error();<br /><br />But when the sequence is long and must reordered, this can be errorprone because not all line of check have the same syntax (imagine that you want to comment one of them).<br /><br />Another way is to rewrite it as:<br /><br />check1() and<br />check2() and<br />check3() and<br />...<br />valid() or<br />error();<br /><br />The above syntax does not fit well when the valid() code must be several statements.<br />An alternative syntax can be:<br /><br />switch (false) {<br />case check1():<br />case check2():<br />case check3():<br />&nbsp; error();<br />&nbsp; break;<br />default:<br />&nbsp; valid();<br />}<br /><br />This last equivalent sample show you that each case expressions is evaluated, until one of them evaluates to a value equal (==) to the switch expression. Above, the error() code will only be called if one of the check evaluates to false. And the valid() code will only be evaluated only if the switch reach the default, which means that none of the above check returned false...</span>
</code></div>
  </div>
 </div>
  <div class="note" id="51179">  <div class="votes">
    <div id="Vu51179">
    <a href="/manual/vote-note.php?id=51179&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd51179">
    <a href="/manual/vote-note.php?id=51179&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V51179" title="37% like this...">
    -4
    </div>
  </div>
  <a href="#51179" class="name">
  <strong class="user"><em>Bruno Feu</em></strong></a><a class="genanchor" href="#51179"> &para;</a><div class="date" title="2005-03-22 01:22"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom51179">
<div class="phpcode"><code><span class="html">
You can solve the problem by just writing the following piece of code:<br /><br /><span class="default">&lt;?php<br />$x </span><span class="keyword">= </span><span class="default">18</span><span class="keyword">;<br /></span><span class="default">$y </span><span class="keyword">= </span><span class="default">6</span><span class="keyword">;<br /><br />switch (</span><span class="default">$x</span><span class="keyword">) {<br />&nbsp;&nbsp; case (</span><span class="default">$y </span><span class="keyword">* </span><span class="default">4</span><span class="keyword">):<br />&nbsp;&nbsp; case (</span><span class="default">9 </span><span class="keyword">* </span><span class="default">3</span><span class="keyword">):<br />&nbsp; &nbsp; &nbsp;&nbsp; echo </span><span class="string">"Member"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp;&nbsp; break;<br />&nbsp;&nbsp; default:<br />&nbsp; &nbsp; &nbsp;&nbsp; echo </span><span class="string">"Not a member"</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="34020">  <div class="votes">
    <div id="Vu34020">
    <a href="/manual/vote-note.php?id=34020&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd34020">
    <a href="/manual/vote-note.php?id=34020&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V34020" title="36% like this...">
    -5
    </div>
  </div>
  <a href="#34020" class="name">
  <strong class="user"><em>bishop</em></strong></a><a class="genanchor" href="#34020"> &para;</a><div class="date" title="2003-07-14 12:26"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom34020">
<div class="phpcode"><code><span class="html">
As jason at devnetwork dot net and others have pointed out, using switch() when you wish to compare against strings can be dangerous:<br /><br /><span class="default">&lt;?php<br />$bug </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />switch (</span><span class="default">$bug</span><span class="keyword">) {<br />&nbsp; &nbsp; case </span><span class="string">'fly'</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'flies buzz'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br /><br />&nbsp; &nbsp; case </span><span class="string">'mantis'</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'mantes pray'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br /><br />&nbsp; &nbsp; default:<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'swat, splat, you are dead'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br />}<br /></span><span class="default">?&gt;<br /></span><br />Will print "flies buzz", NOT "swat, splat, you are dead".<br />Remember PHP says that 'fly' == 0, or in general string == 0 is true.<br /><br />Anyway, avoid that with:<br /><br /><span class="default">&lt;?php<br />$bug </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />switch (</span><span class="default">$bug </span><span class="keyword">=== </span><span class="default">0 </span><span class="keyword">? </span><span class="string">'' </span><span class="keyword">: </span><span class="default">$bug</span><span class="keyword">) {<br />&nbsp; &nbsp; case </span><span class="string">'fly'</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'flies buzz'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br /><br />&nbsp; &nbsp; case </span><span class="string">'mantis'</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'mantes pray'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br /><br />&nbsp; &nbsp; default:<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'swat, splat, you are dead'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br />}<br /></span><span class="default">?&gt;<br /></span><br />Prints out what you expect:<br /><br />Swat<br />Splat<br />You are dead<br /><br />P.S.: that's an empty string (single quote single quote), not a spurious double quote.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="76440">  <div class="votes">
    <div id="Vu76440">
    <a href="/manual/vote-note.php?id=76440&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd76440">
    <a href="/manual/vote-note.php?id=76440&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V76440" title="33% like this...">
    -3
    </div>
  </div>
  <a href="#76440" class="name">
  <strong class="user"><em>Drake</em></strong></a><a class="genanchor" href="#76440"> &para;</a><div class="date" title="2007-07-15 10:51"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom76440">
<div class="phpcode"><code><span class="html">
Also,<br /> when using switch for mode selecting on websites like:<br /><br />switch($_GET['mode']) {<br />&nbsp; case "gallery":<br />&nbsp; &nbsp; //code<br />&nbsp; break;<br />&nbsp; case "news":<br />&nbsp; &nbsp; //code<br />&nbsp; break;<br />&nbsp; case "stuff":<br />&nbsp; &nbsp; //code<br />&nbsp; break;<br />&nbsp; default, etc etc<br />}<br /><br />Will NOT trigger the string == 0 bug, because $_GET automatically parse anything passed to them as strings.<br />(same applies for all browser variables: SESSION, POST etc)<br /><br />so passing:<br />mode=0 <br />into the address bar is the same as:<br />$_GET['mode'] = "0"; //not $_GET['mode'] = 0;<br /><br />thought it may help.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="38890">  <div class="votes">
    <div id="Vu38890">
    <a href="/manual/vote-note.php?id=38890&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd38890">
    <a href="/manual/vote-note.php?id=38890&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V38890" title="33% like this...">
    -2
    </div>
  </div>
  <a href="#38890" class="name">
  <strong class="user"><em>phpmanual at nos-pam dot sadlittleboy dot com</em></strong></a><a class="genanchor" href="#38890"> &para;</a><div class="date" title="2004-01-10 05:32"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom38890">
<div class="phpcode"><code><span class="html">
Regarding bishop's comment below, although using: <br />&nbsp;&nbsp; switch($bug === 0 ? '' : $bug) {<br />may work, ( and although I do like the ternary operator, :) it might be more intuitive/readable to use this instead:<br />&nbsp;&nbsp; switch( (string)$bug ) { <br />which typecasts the variable to a string to ensure that "0" will be handled correctly.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="76591">  <div class="votes">
    <div id="Vu76591">
    <a href="/manual/vote-note.php?id=76591&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd76591">
    <a href="/manual/vote-note.php?id=76591&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V76591" title="30% like this...">
    -5
    </div>
  </div>
  <a href="#76591" class="name">
  <strong class="user"><em>juraj5</em></strong></a><a class="genanchor" href="#76591"> &para;</a><div class="date" title="2007-07-21 12:00"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom76591">
<div class="phpcode"><code><span class="html">
In response to 'i luv spam',<br /><br />when you enter 07, you tell PHP to interpret a number as an octal number (much like '0x' for hex numbers). Octal numbering system uses only 8 digits, i.e. 0-7. <a href="http://en.wikipedia.org/wiki/Octal" rel="nofollow" target="_blank">http://en.wikipedia.org/wiki/Octal</a><br /><br />The number 8 does not exist in octal numbering system. The comparison works because the octal numbers 0 to 7 have identical counterparts in decimal system.<br /><br />So, in order to get a number compared as decimal 8, you would have to enter 010 in the case.<br /><br />BTW this behavior obviously isn't specific to switch, it's a part of PHP.<br /><br />(I personally stumbled into this when trying to make my code nicely indented while declaring an array)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="59991">  <div class="votes">
    <div id="Vu59991">
    <a href="/manual/vote-note.php?id=59991&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd59991">
    <a href="/manual/vote-note.php?id=59991&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V59991" title="31% like this...">
    -6
    </div>
  </div>
  <a href="#59991" class="name">
  <strong class="user"><em>scott at firefallpro dot com</em></strong></a><a class="genanchor" href="#59991"> &para;</a><div class="date" title="2005-12-22 12:01"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom59991">
<div class="phpcode"><code><span class="html">
It's has already been mentioned indirectly in a few posts, but it is important to realize that switch statements evaluate each case with the "==" operator by default. This can lead to unexpected results when comparing strings to integers, because PHP will convert the string to an integer. In many cases this means a string can be equivalent to the integer 0.<br /><br />Example:<br /><span class="default">&lt;?php<br />$x </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br /><br />switch(</span><span class="default">$x</span><span class="keyword">) {<br />case </span><span class="string">"a"</span><span class="keyword">:<br />&nbsp; &nbsp; echo </span><span class="string">"a"</span><span class="keyword">;<br />&nbsp; &nbsp; break;<br />case </span><span class="string">"b"</span><span class="keyword">:<br />&nbsp; &nbsp; echo </span><span class="string">"b"</span><span class="keyword">;<br />&nbsp; &nbsp; break;<br />default<br />&nbsp; &nbsp; echo </span><span class="string">"default"</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />The result will be an "a" echoed out. What PHP does in this instance, is once it realizes that it's attempting to compare string ("a") to an integer (0), it converts "a" into an integer which ends up satisfying the first case.<br /><br />The rules for string conversion into integers is available at:<br /><a href="http://us3.php.net/manual/en/language.types.string.php" rel="nofollow" target="_blank">http://us3.php.net/manual/en/language.types.string.php</a><br /><br />The easiest way to combat this issue is to force type comparison by using the "===" operator. This makes PHP forego the string to integer conversion.<br /><br />Example:<br /><span class="default">&lt;?php<br /></span><span class="keyword">switch(</span><span class="default">true</span><span class="keyword">) {<br />case </span><span class="default">$x </span><span class="keyword">=== </span><span class="string">"a"</span><span class="keyword">:<br />&nbsp; &nbsp; echo </span><span class="string">"a"</span><span class="keyword">;<br />&nbsp; &nbsp; break;<br />case </span><span class="default">$x </span><span class="keyword">=== </span><span class="string">"b"</span><span class="keyword">:<br />&nbsp; &nbsp; echo </span><span class="string">"b"</span><span class="keyword">;<br />&nbsp; &nbsp; break;<br />default<br />&nbsp; &nbsp; echo </span><span class="string">"default"</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />Or the switch input can be type-casted to always be a string, etc.<br /><br />Also note that even though a conditional statement needs to be explicitly set in each case to gain expected behavior, the switch can still execute faster then an "ifelse" block because PHP will not continue to evaluate conditions once a case has been satisfied.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="50927">  <div class="votes">
    <div id="Vu50927">
    <a href="/manual/vote-note.php?id=50927&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd50927">
    <a href="/manual/vote-note.php?id=50927&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V50927" title="31% like this...">
    -7
    </div>
  </div>
  <a href="#50927" class="name">
  <strong class="user"><em>ach aat bitfabrik doot de</em></strong></a><a class="genanchor" href="#50927"> &para;</a><div class="date" title="2005-03-14 03:21"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom50927">
<div class="phpcode"><code><span class="html">
So instead of writing the code shown below it would have to be like this:<br /><br /><span class="default">&lt;?php<br />$x </span><span class="keyword">= </span><span class="default">18</span><span class="keyword">;<br /></span><span class="default">$y </span><span class="keyword">= </span><span class="default">6</span><span class="keyword">;<br /><br />switch (</span><span class="default">$x</span><span class="keyword">) {<br />&nbsp;&nbsp; case (((</span><span class="default">$y </span><span class="keyword">* </span><span class="default">4</span><span class="keyword">) || (</span><span class="default">9 </span><span class="keyword">* </span><span class="default">3</span><span class="keyword">))?</span><span class="default">$x</span><span class="keyword">:</span><span class="default">false</span><span class="keyword">):<br />&nbsp; &nbsp; &nbsp;&nbsp; echo </span><span class="string">"Member"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp;&nbsp; break;<br />&nbsp;&nbsp; default:<br />&nbsp; &nbsp; &nbsp;&nbsp; echo </span><span class="string">"Not a member"</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />So now the case expression contains an if statement in simplified notation which either returns the value of $x if the expression is true (so the case matches) or false, if the expression was false (so the case does not match).<br />Be aware that it only works if $x never actually is "false" because then it would match in either case. So the "false" in the above code should always be any random value which is not a possible value for $x.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="13706">  <div class="votes">
    <div id="Vu13706">
    <a href="/manual/vote-note.php?id=13706&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd13706">
    <a href="/manual/vote-note.php?id=13706&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V13706" title="30% like this...">
    -5
    </div>
  </div>
  <a href="#13706" class="name">
  <strong class="user"><em>bensphpnetemail at supernaut dot org</em></strong></a><a class="genanchor" href="#13706"> &para;</a><div class="date" title="2001-06-29 11:14"><strong>16 years ago</strong></div>
  <div class="text" id="Hcom13706">
<div class="phpcode"><code><span class="html">
It's obvious, but might still bear explicit mention that you can conditionally execute the BREAK statement in order to allow a CASE to fall through to the next CASE.&nbsp; <br /><br />e.g.:-&gt; Here, CASE 1 will fall through and the DEFAULT CASE statements will also be executed unless $somevar is true.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">switch (</span><span class="default">$i</span><span class="keyword">) {<br />&nbsp; &nbsp; case </span><span class="default">0</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; print </span><span class="string">"i equals 0"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; case </span><span class="default">1</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; print </span><span class="string">"i equals 1"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$somevar</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; }<br />&nbsp; &nbsp; default;<br />&nbsp; &nbsp; &nbsp;&nbsp; echo </span><span class="string">'Some Default Statements'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br />}<br /></span><span class="default">?&gt;<br /></span><br />Cheers,<br />Ben Nardone</span>
</code></div>
  </div>
 </div>
  <div class="note" id="40982">  <div class="votes">
    <div id="Vu40982">
    <a href="/manual/vote-note.php?id=40982&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd40982">
    <a href="/manual/vote-note.php?id=40982&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V40982" title="25% like this...">
    -4
    </div>
  </div>
  <a href="#40982" class="name">
  <strong class="user"><em>ezekiel at superquenelles dot com</em></strong></a><a class="genanchor" href="#40982"> &para;</a><div class="date" title="2004-03-25 05:40"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom40982">
<div class="phpcode"><code><span class="html">
In reply to Alex Fung :<br />The following code doesn't work :<br /><br /><span class="default">&lt;?php<br />$x </span><span class="keyword">= </span><span class="default">18</span><span class="keyword">;<br /></span><span class="default">$y </span><span class="keyword">= </span><span class="default">6</span><span class="keyword">;<br /><br />switch (</span><span class="default">$x</span><span class="keyword">) {<br />&nbsp;&nbsp; case ((</span><span class="default">$y </span><span class="keyword">* </span><span class="default">4</span><span class="keyword">) || (</span><span class="default">9 </span><span class="keyword">* </span><span class="default">3</span><span class="keyword">)):<br />&nbsp; &nbsp; &nbsp;&nbsp; echo </span><span class="string">"Member"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp;&nbsp; break;<br />&nbsp;&nbsp; default:<br />&nbsp; &nbsp; &nbsp;&nbsp; echo </span><span class="string">"Not a member"</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />Why :<br />&lt;design at hyperoptix dot com&gt; want to test if $x == $y*4 or $x == 9*3 ($x == (($y*4)||(9*3))<br />However the case statement evaluate the value of (($y*4)||(9*3)) that is always true because 9*3=27 (!=0)<br />That's why this code always return true when $x != 0.<br />The correct code would be :<br /><br /><span class="default">&lt;?php<br />$x </span><span class="keyword">= </span><span class="default">18</span><span class="keyword">;<br /></span><span class="default">$y </span><span class="keyword">= </span><span class="default">6</span><span class="keyword">;<br /><br />switch (</span><span class="default">$x</span><span class="keyword">) {<br />&nbsp;&nbsp; case ((</span><span class="default">$y </span><span class="keyword">* </span><span class="default">4</span><span class="keyword">)):<br />&nbsp;&nbsp; case ((</span><span class="default">9</span><span class="keyword">*</span><span class="default">3</span><span class="keyword">)):<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Member"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp;&nbsp; default:<br />&nbsp; &nbsp; &nbsp;&nbsp; echo </span><span class="string">"Not a member"</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />Boolean logic work inside case statement, you just need to know that the expression in the case statement is first evaluated then compared with the evaluated value in the switch statement.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119854">  <div class="votes">
    <div id="Vu119854">
    <a href="/manual/vote-note.php?id=119854&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119854">
    <a href="/manual/vote-note.php?id=119854&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119854" title="14% like this...">
    -5
    </div>
  </div>
  <a href="#119854" class="name">
  <strong class="user"><em>Bill</em></strong></a><a class="genanchor" href="#119854"> &para;</a><div class="date" title="2016-09-07 12:50"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119854">
<div class="phpcode"><code><span class="html">
Note the case statement does not have to compare with the switch statement.<br /><br />I sometimes use the switch statement to make complex logic more readable:<br /><br /><span class="default">&lt;?php<br />&nbsp; define</span><span class="keyword">(</span><span class="string">'TRACK_CPI'</span><span class="keyword">, </span><span class="default">true</span><span class="keyword">);<br />&nbsp; </span><span class="default">define</span><span class="keyword">(</span><span class="string">'TRACK_INV'</span><span class="keyword">, </span><span class="default">true</span><span class="keyword">);<br />&nbsp; </span><span class="default">define</span><span class="keyword">(</span><span class="string">'PREFER_CPI_OVER_SINV'</span><span class="keyword">, </span><span class="default">false</span><span class="keyword">);<br />&nbsp; .<br />&nbsp; .<br />&nbsp; switch (</span><span class="default">1</span><span class="keyword">) {<br />&nbsp; &nbsp; case (</span><span class="default">TRACK_CPI </span><span class="keyword">and </span><span class="default">PREFER_CPI_OVER_SINV </span><span class="keyword">and (</span><span class="default">$data_row</span><span class="keyword">[</span><span class="string">'CPI_id'</span><span class="keyword">] != </span><span class="default">0</span><span class="keyword">)): {<br />&nbsp; &nbsp; &nbsp; .<br />&nbsp; &nbsp; &nbsp; .<br />&nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; case (</span><span class="default">TRACK_CPI </span><span class="keyword">and (!</span><span class="default">PREFER_CPI_OVER_SINV</span><span class="keyword">) and (</span><span class="default">$data_row</span><span class="keyword">[</span><span class="string">'SInv_id'</span><span class="keyword">] != </span><span class="default">0</span><span class="keyword">)): {<br />&nbsp; &nbsp; &nbsp; .<br />&nbsp; &nbsp; &nbsp; .<br />&nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; case (</span><span class="default">TRACK_CPI </span><span class="keyword">and (</span><span class="default">$data_row</span><span class="keyword">[</span><span class="string">'CPI_id'</span><span class="keyword">] != </span><span class="default">0</span><span class="keyword">)): {<br />&nbsp; &nbsp; &nbsp; .<br />&nbsp; &nbsp; &nbsp; .<br />&nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; case (</span><span class="default">TRACK_INV </span><span class="keyword">and </span><span class="default">$data_row</span><span class="keyword">[</span><span class="string">'SInv_id'</span><span class="keyword">] != </span><span class="default">0</span><span class="keyword">): {<br />&nbsp; &nbsp; &nbsp; .<br />&nbsp; &nbsp; &nbsp; .<br />&nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; }<br />&nbsp; }<br /></span><span class="default">?&gt;<br /></span>Hope this helps.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121347">  <div class="votes">
    <div id="Vu121347">
    <a href="/manual/vote-note.php?id=121347&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121347">
    <a href="/manual/vote-note.php?id=121347&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121347" title="0% like this...">
    -8
    </div>
  </div>
  <a href="#121347" class="name">
  <strong class="user"><em>thiswouter at gmail dot com</em></strong></a><a class="genanchor" href="#121347"> &para;</a><div class="date" title="2017-07-10 02:09"><strong>5 months ago</strong></div>
  <div class="text" id="Hcom121347">
<div class="phpcode"><code><span class="html">
date_default_timezone_set('CET');<br />date_default_timezone_set('CET');<br />date_default_timezone_set('CET');<br />date_default_timezone_set('CET');<br />oke</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119638">  <div class="votes">
    <div id="Vu119638">
    <a href="/manual/vote-note.php?id=119638&amp;page=control-structures.switch&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119638">
    <a href="/manual/vote-note.php?id=119638&amp;page=control-structures.switch&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119638" title="0% like this...">
    -11
    </div>
  </div>
  <a href="#119638" class="name">
  <strong class="user"><em>lawrencestewart1 at gmail dot com</em></strong></a><a class="genanchor" href="#119638"> &para;</a><div class="date" title="2016-07-22 09:43"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119638">
<div class="phpcode"><code><span class="html">
just a warning / note I found with a bit of unexpected behavior<br /><br />switch(abs($x)) {<br />&nbsp; &nbsp; &nbsp; case(0 &gt;= 1):<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; echo 'this evaluates to true';<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; break;<br />}</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=control-structures.switch&amp;redirect=http://php.net/manual/en/control-structures.switch.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.control-structures.php">Control Structures</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="control-structures.intro.php" title="Introduction">Introduction</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.if.php" title="if">if</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.else.php" title="else">else</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.elseif.php" title="elseif/else if">elseif/else if</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.alternative-syntax.php" title="Alternative syntax for control structures">Alternative syntax for control structures</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.while.php" title="while">while</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.do.while.php" title="do-&#8203;while">do-&#8203;while</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.for.php" title="for">for</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.foreach.php" title="foreach">foreach</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.break.php" title="break">break</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.continue.php" title="continue">continue</a>
                        </li>
                          
                        <li class="current">
                            <a href="control-structures.switch.php" title="switch">switch</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.declare.php" title="declare">declare</a>
                        </li>
                          
                        <li class="">
                            <a href="function.return.php" title="return">return</a>
                        </li>
                          
                        <li class="">
                            <a href="function.require.php" title="require">require</a>
                        </li>
                          
                        <li class="">
                            <a href="function.include.php" title="include">include</a>
                        </li>
                          
                        <li class="">
                            <a href="function.require-once.php" title="require_&#8203;once">require_&#8203;once</a>
                        </li>
                          
                        <li class="">
                            <a href="function.include-once.php" title="include_&#8203;once">include_&#8203;once</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.goto.php" title="goto">goto</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

