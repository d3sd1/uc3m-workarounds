<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: foreach - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/control-structures.foreach.php">
 <link rel="shorturl" href="http://php.net/foreach">
 <link rel="alternate" href="http://php.net/foreach" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.control-structures.php">
 <link rel="prev" href="http://php.net/manual/en/control-structures.for.php">
 <link rel="next" href="http://php.net/manual/en/control-structures.break.php">

 <link rel="alternate" href="http://php.net/manual/en/control-structures.foreach.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/control-structures.foreach.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/control-structures.foreach.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/control-structures.foreach.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/control-structures.foreach.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/control-structures.foreach.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/control-structures.foreach.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/control-structures.foreach.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/control-structures.foreach.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/control-structures.foreach.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/control-structures.foreach.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="control-structures.break.php">
          break &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="control-structures.for.php">
          &laquo; for        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.control-structures.php'>Control Structures</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/control-structures.foreach.php' selected="selected">English</option>
            <option value='pt_BR/control-structures.foreach.php'>Brazilian Portuguese</option>
            <option value='zh/control-structures.foreach.php'>Chinese (Simplified)</option>
            <option value='fr/control-structures.foreach.php'>French</option>
            <option value='de/control-structures.foreach.php'>German</option>
            <option value='ja/control-structures.foreach.php'>Japanese</option>
            <option value='ro/control-structures.foreach.php'>Romanian</option>
            <option value='ru/control-structures.foreach.php'>Russian</option>
            <option value='es/control-structures.foreach.php'>Spanish</option>
            <option value='tr/control-structures.foreach.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/control-structures.foreach.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=control-structures.foreach">Report a Bug</a>
    </div>
  </div><div id="control-structures.foreach" class="sect1">
 <h2 class="title"><em>foreach</em></h2>
 <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p>
 <p class="para">
  The <em>foreach</em> construct provides an easy way to
  iterate over arrays. <em>foreach</em> works only on arrays
  and objects, and will issue an error when you try to use it on a variable
  with a different data type or an uninitialized variable. There are two
  syntaxes:
  <div class="informalexample">
   <div class="example-contents">
<div class="cdata"><pre>
foreach (array_expression as $value)
    statement
foreach (array_expression as $key =&gt; $value)
    statement
</pre></div>
   </div>

  </div>
 </p>
 <p class="simpara">
  The first form loops over the array given by
  <em>array_expression</em>. On each iteration, the value of
  the current element is assigned to <em>$value</em> and
  the internal array pointer is advanced by one (so on the next
  iteration, you&#039;ll be looking at the next element).
 </p>
 <p class="simpara">
  The second form will additionally assign the current element&#039;s key to
  the <em>$key</em> variable on each iteration.
 </p>
 <p class="simpara">
  It is possible to
  <a href="language.oop5.iterations.php" class="link">customize object iteration</a>.
 </p>
 <p class="para">
  <blockquote class="note"><p><strong class="note">Note</strong>: 
   <p class="para">
    In PHP 5, when <em>foreach</em> first starts executing, the
    internal array pointer is automatically reset to the first element of the
    array. This means that you do not need to call <span class="function"><a href="function.reset.php" class="function">reset()</a></span>
    before a <em>foreach</em> loop.
   </p>
   <p class="para">
    As <em>foreach</em> relies on the internal array pointer in PHP
    5, changing it within the loop may lead to unexpected behavior.
   </p>
   <p class="para">
    In PHP 7, <em>foreach</em> does not use the internal array
    pointer.
   </p>
  </p></blockquote>
 </p>
 <p class="para">
  In order to be able to directly modify array elements within the loop precede
 <em>$value</em> with &amp;. In that case the value will be assigned by
 <a href="language.references.php" class="link">reference</a>.
  <div class="informalexample">
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$arr&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">3</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">4</span><span style="color: #007700">);<br />foreach&nbsp;(</span><span style="color: #0000BB">$arr&nbsp;</span><span style="color: #007700">as&nbsp;&amp;</span><span style="color: #0000BB">$value</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$value&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$value&nbsp;</span><span style="color: #007700">*&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">;<br />}<br /></span><span style="color: #FF8000">//&nbsp;$arr&nbsp;is&nbsp;now&nbsp;array(2,&nbsp;4,&nbsp;6,&nbsp;8)<br /></span><span style="color: #007700">unset(</span><span style="color: #0000BB">$value</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;break&nbsp;the&nbsp;reference&nbsp;with&nbsp;the&nbsp;last&nbsp;element<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>
 </p>
 <div class="warning"><strong class="warning">Warning</strong>
  <p class="para">
   Reference of a <em>$value</em> and the last array element
   remain even after the <em>foreach</em> loop. It is recommended
   to destroy it by <span class="function"><a href="function.unset.php" class="function">unset()</a></span>.
   Otherwise you will experience the following behavior:
  </p>
  <div class="informalexample">
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$arr&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">3</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">4</span><span style="color: #007700">);<br />foreach&nbsp;(</span><span style="color: #0000BB">$arr&nbsp;</span><span style="color: #007700">as&nbsp;&amp;</span><span style="color: #0000BB">$value</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$value&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$value&nbsp;</span><span style="color: #007700">*&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">;<br />}<br /></span><span style="color: #FF8000">//&nbsp;$arr&nbsp;is&nbsp;now&nbsp;array(2,&nbsp;4,&nbsp;6,&nbsp;8)<br /><br />//&nbsp;without&nbsp;an&nbsp;unset($value),&nbsp;$value&nbsp;is&nbsp;still&nbsp;a&nbsp;reference&nbsp;to&nbsp;the&nbsp;last&nbsp;item:&nbsp;$arr[3]<br /><br /></span><span style="color: #007700">foreach&nbsp;(</span><span style="color: #0000BB">$arr&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">$key&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #0000BB">$value</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$arr[3]&nbsp;will&nbsp;be&nbsp;updated&nbsp;with&nbsp;each&nbsp;value&nbsp;from&nbsp;$arr...<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"</span><span style="color: #007700">{</span><span style="color: #0000BB">$key</span><span style="color: #007700">}</span><span style="color: #DD0000">&nbsp;=&gt;&nbsp;</span><span style="color: #007700">{</span><span style="color: #0000BB">$value</span><span style="color: #007700">}</span><span style="color: #DD0000">&nbsp;"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">print_r</span><span style="color: #007700">(</span><span style="color: #0000BB">$arr</span><span style="color: #007700">);<br />}<br /></span><span style="color: #FF8000">//&nbsp;...until&nbsp;ultimately&nbsp;the&nbsp;second-to-last&nbsp;value&nbsp;is&nbsp;copied&nbsp;onto&nbsp;the&nbsp;last&nbsp;value<br /><br />//&nbsp;output:<br />//&nbsp;0&nbsp;=&gt;&nbsp;2&nbsp;Array&nbsp;(&nbsp;[0]&nbsp;=&gt;&nbsp;2,&nbsp;[1]&nbsp;=&gt;&nbsp;4,&nbsp;[2]&nbsp;=&gt;&nbsp;6,&nbsp;[3]&nbsp;=&gt;&nbsp;2&nbsp;)<br />//&nbsp;1&nbsp;=&gt;&nbsp;4&nbsp;Array&nbsp;(&nbsp;[0]&nbsp;=&gt;&nbsp;2,&nbsp;[1]&nbsp;=&gt;&nbsp;4,&nbsp;[2]&nbsp;=&gt;&nbsp;6,&nbsp;[3]&nbsp;=&gt;&nbsp;4&nbsp;)<br />//&nbsp;2&nbsp;=&gt;&nbsp;6&nbsp;Array&nbsp;(&nbsp;[0]&nbsp;=&gt;&nbsp;2,&nbsp;[1]&nbsp;=&gt;&nbsp;4,&nbsp;[2]&nbsp;=&gt;&nbsp;6,&nbsp;[3]&nbsp;=&gt;&nbsp;6&nbsp;)<br />//&nbsp;3&nbsp;=&gt;&nbsp;6&nbsp;Array&nbsp;(&nbsp;[0]&nbsp;=&gt;&nbsp;2,&nbsp;[1]&nbsp;=&gt;&nbsp;4,&nbsp;[2]&nbsp;=&gt;&nbsp;6,&nbsp;[3]&nbsp;=&gt;&nbsp;6&nbsp;)<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>
 </div>
 <p class="para">
  Before PHP 5.5.0, referencing <em>$value</em> is only possible if the iterated array can be
  referenced (i.e. if it is a variable). The following code works only as of PHP 5.5.0:
  <div class="informalexample">
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">foreach&nbsp;(array(</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">3</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">4</span><span style="color: #007700">)&nbsp;as&nbsp;&amp;</span><span style="color: #0000BB">$value</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$value&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$value&nbsp;</span><span style="color: #007700">*&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>
 </p>
 <p class="para">
  <blockquote class="note"><p><strong class="note">Note</strong>: 
   <p class="para">
    <em>foreach</em> does not support the ability to
    suppress error messages using &#039;@&#039;.
   </p>
  </p></blockquote>
 </p>
 <p class="para">
  You may have noticed that the following are functionally
  identical:
  <div class="informalexample">
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$arr&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">"one"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"two"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"three"</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">reset</span><span style="color: #007700">(</span><span style="color: #0000BB">$arr</span><span style="color: #007700">);<br />while&nbsp;(list(,&nbsp;</span><span style="color: #0000BB">$value</span><span style="color: #007700">)&nbsp;=&nbsp;</span><span style="color: #0000BB">each</span><span style="color: #007700">(</span><span style="color: #0000BB">$arr</span><span style="color: #007700">))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"Value:&nbsp;</span><span style="color: #0000BB">$value</span><span style="color: #DD0000">&lt;br&nbsp;/&gt;\n"</span><span style="color: #007700">;<br />}<br /><br />foreach&nbsp;(</span><span style="color: #0000BB">$arr&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">$value</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"Value:&nbsp;</span><span style="color: #0000BB">$value</span><span style="color: #DD0000">&lt;br&nbsp;/&gt;\n"</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>
 </p>
 <p class="para">
  The following are also functionally identical:
  <div class="informalexample">
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$arr&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">"one"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"two"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"three"</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">reset</span><span style="color: #007700">(</span><span style="color: #0000BB">$arr</span><span style="color: #007700">);<br />while&nbsp;(list(</span><span style="color: #0000BB">$key</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$value</span><span style="color: #007700">)&nbsp;=&nbsp;</span><span style="color: #0000BB">each</span><span style="color: #007700">(</span><span style="color: #0000BB">$arr</span><span style="color: #007700">))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"Key:&nbsp;</span><span style="color: #0000BB">$key</span><span style="color: #DD0000">;&nbsp;Value:&nbsp;</span><span style="color: #0000BB">$value</span><span style="color: #DD0000">&lt;br&nbsp;/&gt;\n"</span><span style="color: #007700">;<br />}<br /><br />foreach&nbsp;(</span><span style="color: #0000BB">$arr&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">$key&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #0000BB">$value</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"Key:&nbsp;</span><span style="color: #0000BB">$key</span><span style="color: #DD0000">;&nbsp;Value:&nbsp;</span><span style="color: #0000BB">$value</span><span style="color: #DD0000">&lt;br&nbsp;/&gt;\n"</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>
 </p>
 <p class="para">
  Some more examples to demonstrate usage:
  <div class="informalexample">
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #FF8000">/*&nbsp;foreach&nbsp;example&nbsp;1:&nbsp;value&nbsp;only&nbsp;*/<br /><br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">3</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">17</span><span style="color: #007700">);<br /><br />foreach&nbsp;(</span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">$v</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"Current&nbsp;value&nbsp;of&nbsp;\$a:&nbsp;</span><span style="color: #0000BB">$v</span><span style="color: #DD0000">.\n"</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #FF8000">/*&nbsp;foreach&nbsp;example&nbsp;2:&nbsp;value&nbsp;(with&nbsp;its&nbsp;manual&nbsp;access&nbsp;notation&nbsp;printed&nbsp;for&nbsp;illustration)&nbsp;*/<br /><br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">3</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">17</span><span style="color: #007700">);<br /><br /></span><span style="color: #0000BB">$i&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">0</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">/*&nbsp;for&nbsp;illustrative&nbsp;purposes&nbsp;only&nbsp;*/<br /><br /></span><span style="color: #007700">foreach&nbsp;(</span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">$v</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"\$a[</span><span style="color: #0000BB">$i</span><span style="color: #DD0000">]&nbsp;=&gt;&nbsp;</span><span style="color: #0000BB">$v</span><span style="color: #DD0000">.\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$i</span><span style="color: #007700">++;<br />}<br /><br /></span><span style="color: #FF8000">/*&nbsp;foreach&nbsp;example&nbsp;3:&nbsp;key&nbsp;and&nbsp;value&nbsp;*/<br /><br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;array(<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"one"&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"two"&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"three"&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #0000BB">3</span><span style="color: #007700">,<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #DD0000">"seventeen"&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #0000BB">17<br /></span><span style="color: #007700">);<br /><br />foreach&nbsp;(</span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">$k&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #0000BB">$v</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"\$a[</span><span style="color: #0000BB">$k</span><span style="color: #DD0000">]&nbsp;=&gt;&nbsp;</span><span style="color: #0000BB">$v</span><span style="color: #DD0000">.\n"</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #FF8000">/*&nbsp;foreach&nbsp;example&nbsp;4:&nbsp;multi-dimensional&nbsp;arrays&nbsp;*/<br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;array();<br /></span><span style="color: #0000BB">$a</span><span style="color: #007700">[</span><span style="color: #0000BB">0</span><span style="color: #007700">][</span><span style="color: #0000BB">0</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #DD0000">"a"</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$a</span><span style="color: #007700">[</span><span style="color: #0000BB">0</span><span style="color: #007700">][</span><span style="color: #0000BB">1</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #DD0000">"b"</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$a</span><span style="color: #007700">[</span><span style="color: #0000BB">1</span><span style="color: #007700">][</span><span style="color: #0000BB">0</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #DD0000">"y"</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$a</span><span style="color: #007700">[</span><span style="color: #0000BB">1</span><span style="color: #007700">][</span><span style="color: #0000BB">1</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #DD0000">"z"</span><span style="color: #007700">;<br /><br />foreach&nbsp;(</span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">$v1</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;foreach&nbsp;(</span><span style="color: #0000BB">$v1&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">$v2</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"</span><span style="color: #0000BB">$v2</span><span style="color: #DD0000">\n"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br /></span><span style="color: #FF8000">/*&nbsp;foreach&nbsp;example&nbsp;5:&nbsp;dynamic&nbsp;arrays&nbsp;*/<br /><br /></span><span style="color: #007700">foreach&nbsp;(array(</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">3</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">4</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">5</span><span style="color: #007700">)&nbsp;as&nbsp;</span><span style="color: #0000BB">$v</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"</span><span style="color: #0000BB">$v</span><span style="color: #DD0000">\n"</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>
 </p>

 <div class="sect2" id="control-structures.foreach.list">
  <h3 class="title">Unpacking nested arrays with list()</h3>
  <p class="verinfo">(PHP 5 &gt;= 5.5.0, PHP 7)</p>

  <p class="para">
   PHP 5.5 added the ability to iterate over an array of arrays and unpack the
   nested array into loop variables by providing a <span class="function"><a href="function.list.php" class="function">list()</a></span>
   as the value.
  </p>

  <p class="para">
   For example:

   <div class="informalexample">
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$array&nbsp;</span><span style="color: #007700">=&nbsp;[<br />&nbsp;&nbsp;&nbsp;&nbsp;[</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">],<br />&nbsp;&nbsp;&nbsp;&nbsp;[</span><span style="color: #0000BB">3</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">4</span><span style="color: #007700">],<br />];<br /><br />foreach&nbsp;(</span><span style="color: #0000BB">$array&nbsp;</span><span style="color: #007700">as&nbsp;list(</span><span style="color: #0000BB">$a</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$b</span><span style="color: #007700">))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;$a&nbsp;contains&nbsp;the&nbsp;first&nbsp;element&nbsp;of&nbsp;the&nbsp;nested&nbsp;array,<br />&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;and&nbsp;$b&nbsp;contains&nbsp;the&nbsp;second&nbsp;element.<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"A:&nbsp;</span><span style="color: #0000BB">$a</span><span style="color: #DD0000">;&nbsp;B:&nbsp;</span><span style="color: #0000BB">$b</span><span style="color: #DD0000">\n"</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

    <p class="para">The above example will output:</p>
    <div class="example-contents screen">
<div class="cdata"><pre>
A: 1; B: 2
A: 3; B: 4
</pre></div>
    </div>
   </div>
  </p>

  <p class="para">
   You can provide fewer elements in the <span class="function"><a href="function.list.php" class="function">list()</a></span> than there
   are in the nested array, in which case the leftover array values will be
   ignored:

   <div class="informalexample">
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$array&nbsp;</span><span style="color: #007700">=&nbsp;[<br />&nbsp;&nbsp;&nbsp;&nbsp;[</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">],<br />&nbsp;&nbsp;&nbsp;&nbsp;[</span><span style="color: #0000BB">3</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">4</span><span style="color: #007700">],<br />];<br /><br />foreach&nbsp;(</span><span style="color: #0000BB">$array&nbsp;</span><span style="color: #007700">as&nbsp;list(</span><span style="color: #0000BB">$a</span><span style="color: #007700">))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;Note&nbsp;that&nbsp;there&nbsp;is&nbsp;no&nbsp;$b&nbsp;here.<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">"</span><span style="color: #0000BB">$a</span><span style="color: #DD0000">\n"</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

    <p class="para">The above example will output:</p>
    <div class="example-contents screen">
<div class="cdata"><pre>
1
3
</pre></div>
    </div>
   </div>
  </p>

  <p class="para">
   A notice will be generated if there aren&#039;t enough array elements to fill
   the <span class="function"><a href="function.list.php" class="function">list()</a></span>:

   <div class="informalexample">
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$array&nbsp;</span><span style="color: #007700">=&nbsp;[<br />&nbsp;&nbsp;&nbsp;&nbsp;[</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">],<br />&nbsp;&nbsp;&nbsp;&nbsp;[</span><span style="color: #0000BB">3</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">4</span><span style="color: #007700">],<br />];<br /><br />foreach&nbsp;(</span><span style="color: #0000BB">$array&nbsp;</span><span style="color: #007700">as&nbsp;list(</span><span style="color: #0000BB">$a</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$b</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$c</span><span style="color: #007700">))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"A:&nbsp;</span><span style="color: #0000BB">$a</span><span style="color: #DD0000">;&nbsp;B:&nbsp;</span><span style="color: #0000BB">$b</span><span style="color: #DD0000">;&nbsp;C:&nbsp;</span><span style="color: #0000BB">$c</span><span style="color: #DD0000">\n"</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

    <p class="para">The above example will output:</p>
    <div class="example-contents screen">
<div class="cdata"><pre>

Notice: Undefined offset: 2 in example.php on line 7
A: 1; B: 2; C: 

Notice: Undefined offset: 2 in example.php on line 7
A: 3; B: 4; C: 
</pre></div>
    </div>
   </div>
  </p>
 </div>

 <div class="sect2">
  <h3 class="title">Changelog</h3>
  <p class="para">
   <table class="doctable informaltable">
    
     <thead>
      <tr>
       <th>Version</th>
       <th>Description</th>
      </tr>

     </thead>

     <tbody class="tbody">
      <tr>
       <td>7.0.0</td>
       <td>
        <em>foreach</em> does not use the internal array pointer anymore.
       </td>
      </tr>

      <tr>
       <td>5.5.0</td>
       <td>
        Referencing of <em>$value</em> is supported for expressions.
        Formerly, only variables have been supported.
       </td>
      </tr>

      <tr>
       <td>5.5.0</td>
       <td>
        Unpacking nested arrays with <span class="function"><a href="function.list.php" class="function">list()</a></span> is supported.
       </td>
      </tr>

     </tbody>
    
   </table>

  </p>
 </div>

</div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=control-structures.foreach&amp;redirect=http://php.net/manual/en/control-structures.foreach.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">25 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="82511">  <div class="votes">
    <div id="Vu82511">
    <a href="/manual/vote-note.php?id=82511&amp;page=control-structures.foreach&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd82511">
    <a href="/manual/vote-note.php?id=82511&amp;page=control-structures.foreach&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V82511" title="64% like this...">
    192
    </div>
  </div>
  <a href="#82511" class="name">
  <strong class="user"><em>adam dot sindelar at gmail dot com</em></strong></a><a class="genanchor" href="#82511"> &para;</a><div class="date" title="2008-04-14 06:45"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom82511">
<div class="phpcode"><code><span class="html">
You can also use the alternative syntax for the foreach cycle:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">foreach(</span><span class="default">$array </span><span class="keyword">as </span><span class="default">$element</span><span class="keyword">):<br />&nbsp; </span><span class="comment">#do something<br /></span><span class="keyword">endforeach;<br /></span><span class="default">?&gt;<br /></span><br />Just thought it worth mentioning.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="111688">  <div class="votes">
    <div id="Vu111688">
    <a href="/manual/vote-note.php?id=111688&amp;page=control-structures.foreach&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd111688">
    <a href="/manual/vote-note.php?id=111688&amp;page=control-structures.foreach&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V111688" title="61% like this...">
    97
    </div>
  </div>
  <a href="#111688" class="name">
  <strong class="user"><em>php at darkain dot com</em></strong></a><a class="genanchor" href="#111688"> &para;</a><div class="date" title="2013-03-16 09:56"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom111688">
<div class="phpcode"><code><span class="html">
"Reference of a $value and the last array element remain even after the foreach loop. It is recommended to destroy it by unset()."<br /><br />I cannot stress this point of the documentation enough! Here is a simple example of exactly why this must be done:<br /><br /><span class="default">&lt;?php<br />$arr1 </span><span class="keyword">= array(</span><span class="string">"a" </span><span class="keyword">=&gt; </span><span class="default">1</span><span class="keyword">, </span><span class="string">"b" </span><span class="keyword">=&gt; </span><span class="default">2</span><span class="keyword">, </span><span class="string">"c" </span><span class="keyword">=&gt; </span><span class="default">3</span><span class="keyword">);<br /></span><span class="default">$arr2 </span><span class="keyword">= array(</span><span class="string">"x" </span><span class="keyword">=&gt; </span><span class="default">4</span><span class="keyword">, </span><span class="string">"y" </span><span class="keyword">=&gt; </span><span class="default">5</span><span class="keyword">, </span><span class="string">"z" </span><span class="keyword">=&gt; </span><span class="default">6</span><span class="keyword">);<br /><br />foreach (</span><span class="default">$arr1 </span><span class="keyword">as </span><span class="default">$key </span><span class="keyword">=&gt; &amp;</span><span class="default">$val</span><span class="keyword">) {}<br />foreach (</span><span class="default">$arr2 </span><span class="keyword">as </span><span class="default">$key </span><span class="keyword">=&gt; </span><span class="default">$val</span><span class="keyword">) {}<br /><br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$arr1</span><span class="keyword">);<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$arr2</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />The output is:<br />array(3) { ["a"]=&gt; int(1) ["b"]=&gt; int(2) ["c"]=&gt; &amp;int(6) }<br />array(3) { ["x"]=&gt; int(4) ["y"]=&gt; int(5) ["z"]=&gt; int(6) }<br /><br />Notice how the last index in $arr1 is now the value from the last index in $arr2!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120710">  <div class="votes">
    <div id="Vu120710">
    <a href="/manual/vote-note.php?id=120710&amp;page=control-structures.foreach&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120710">
    <a href="/manual/vote-note.php?id=120710&amp;page=control-structures.foreach&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120710" title="60% like this...">
    13
    </div>
  </div>
  <a href="#120710" class="name">
  <strong class="user"><em>John</em></strong></a><a class="genanchor" href="#120710"> &para;</a><div class="date" title="2017-02-26 03:24"><strong>9 months ago</strong></div>
  <div class="text" id="Hcom120710">
<div class="phpcode"><code><span class="html">
WARNING: Looping through "values by reference" for "extra performance" is an old myth. It's actually WORSE!<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">one</span><span class="keyword">(</span><span class="default">$arr</span><span class="keyword">) {<br />&nbsp; &nbsp; foreach(</span><span class="default">$arr </span><span class="keyword">as </span><span class="default">$val</span><span class="keyword">) { </span><span class="comment">// Normal Variable<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">echo </span><span class="default">$val</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />function </span><span class="default">two</span><span class="keyword">(</span><span class="default">$arr</span><span class="keyword">) {<br />&nbsp; &nbsp; foreach(</span><span class="default">$arr </span><span class="keyword">as &amp;</span><span class="default">$val</span><span class="keyword">) { </span><span class="comment">// Reference To Value<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">echo </span><span class="default">$val</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$a </span><span class="keyword">= array( </span><span class="string">'a'</span><span class="keyword">, </span><span class="string">'b'</span><span class="keyword">, </span><span class="string">'c' </span><span class="keyword">);<br /></span><span class="default">one</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">);<br /></span><span class="default">two</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">);<br /><br /></span><span class="default">?&gt;<br /></span><br />Which do you think is faster?<br /><br />Lots of people think the answer is two() because it uses "reference to value, which it doesn't have to copy each value when it loops".<br /><br />Well, that's totally wrong!<br /><br />Here's what actually happens:<br /><br />* one():<br /><br />- This function takes an array as argument ($arr).<br />- The array function argument itself isn't passed by reference, so the function knows it isn't allowed to modify the original at all.<br />- Then the foreach loop happens. The array itself wasn't passed by reference to the function, so PHP knows that it isn't allowed to modify the outside array, so it therefore makes a copy of the array's internal iteration offset state (that's just a simple number which says which item you are currently at during things like foreach()), which costs almost no performance or memory at all since it's just a small number.<br />- Next, it uses that copied iteration offset to loop through all key/value pairs of the array (ie 0th key, 1st key, 2nd key, etc...). And the value at the current offset (a PHP "zval") is assigned to a variable called $val.<br />- Does $val make a COPY of the value? That's what MANY people think. But the answer is NO. It DOESN'T. It re-uses the existing value in memory. With zero performance cost. It's called "copy-on-write" and means that PHP doesn't make any copies unless you try to MODIFY the value.<br />- If you try to MODIFY $val, THEN it will allocate a NEW zval in memory and store $val there instead (but it still won't modify the original array, so you can rest assured).<br /><br />Alright, so what's the second version doing? The beloved "iterate values by reference"?<br /><br />* two():<br /><br />- This function takes an array as argument ($arr).<br />- The array function argument itself isn't passed by reference, so the function knows it isn't allowed to modify the original at all.<br />- Then the foreach loop happens. The array itself wasn't passed by reference to the function, so PHP knows that it isn't allowed to modify the outside array.<br />- But it also sees that you want to look at all VALUES by reference (&amp;$val), so PHP says "Uh oh, this is dangerous. If we just give them references to the original array's values, and they assign some new value to their reference, they would destroy the original array which they aren't allowed to touch!".<br />- So PHP makes a FULL COPY of the ENTIRE array and ALL VALUES before it starts iterating. YIKES!<br /><br />Therefore: STOP using the old, mythological "&amp;$val" iteration method! It's almost always BAD! With worse performance, and risks of bugs and quirks as is demonstrated in the manual.<br /><br />You can always manually write array assignments explicitly, without references, like this:<br /><br /><span class="default">&lt;?php<br /><br />$a </span><span class="keyword">= array(</span><span class="default">1</span><span class="keyword">, </span><span class="default">2</span><span class="keyword">, </span><span class="default">3</span><span class="keyword">);<br />foreach(</span><span class="default">$a </span><span class="keyword">as </span><span class="default">$key </span><span class="keyword">=&gt; </span><span class="default">$val</span><span class="keyword">) {<br />&nbsp;&nbsp; </span><span class="default">$a</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">] = </span><span class="default">$val </span><span class="keyword">* </span><span class="default">10</span><span class="keyword">;<br />}<br /></span><span class="comment">// $a is now [10, 20, 30]<br /><br /></span><span class="default">?&gt;<br /></span><br />The main lesson is this: DON'T blindly iterate through values by reference! Telling PHP that you want direct references will force PHP to need to copy the WHOLE array to protect its original values! So instead, just loop normally and trust the fact that PHP *is* actually smart enough to never copy your original array's values! PHP uses "copy-on-write", which means that attempting to assign something new to $val is the ONLY thing that causes a copying, and only of that SINGLE element! :-) But you never do that anyway, when iterating without reference. If you ever want to modify something, you use the "$a[$key] = 123;" method of updating the value.<br /><br />Enjoy and good luck with your code! :-)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114759">  <div class="votes">
    <div id="Vu114759">
    <a href="/manual/vote-note.php?id=114759&amp;page=control-structures.foreach&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114759">
    <a href="/manual/vote-note.php?id=114759&amp;page=control-structures.foreach&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114759" title="57% like this...">
    21
    </div>
  </div>
  <a href="#114759" class="name">
  <strong class="user"><em>Alastair Hole</em></strong></a><a class="genanchor" href="#114759"> &para;</a><div class="date" title="2014-04-02 09:52"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114759">
<div class="phpcode"><code><span class="html">
What happened to this note:<br />"Unless the array is referenced, foreach operates on a copy of the specified array and not the array itself. foreach has some side effects on the array pointer. Don't rely on the array pointer during or after the foreach without resetting it."<br /><br />Is this no longer the case?<br />It seems only to remain in the Serbian documentation: <a href="http://php.net/manual/sr/control-structures.foreach.php" rel="nofollow" target="_blank">http://php.net/manual/sr/control-structures.foreach.php</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="88578">  <div class="votes">
    <div id="Vu88578">
    <a href="/manual/vote-note.php?id=88578&amp;page=control-structures.foreach&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd88578">
    <a href="/manual/vote-note.php?id=88578&amp;page=control-structures.foreach&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V88578" title="56% like this...">
    36
    </div>
  </div>
  <a href="#88578" class="name">
  <strong class="user"><em>tedivm at tedivm dot com</em></strong></a><a class="genanchor" href="#88578"> &para;</a><div class="date" title="2009-01-29 02:44"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom88578">
<div class="phpcode"><code><span class="html">
foreach and the while/list/each methods are not completely identical, and there are occasions where one way is beneficial over the other.<br /><br /><span class="default">&lt;?php<br />$arr </span><span class="keyword">= array(</span><span class="default">1</span><span class="keyword">,</span><span class="default">2</span><span class="keyword">,</span><span class="default">3</span><span class="keyword">,</span><span class="default">4</span><span class="keyword">,</span><span class="default">5</span><span class="keyword">,</span><span class="default">6</span><span class="keyword">,</span><span class="default">7</span><span class="keyword">,</span><span class="default">8</span><span class="keyword">,</span><span class="default">9</span><span class="keyword">);<br /><br />foreach(</span><span class="default">$arr </span><span class="keyword">as </span><span class="default">$key</span><span class="keyword">=&gt;</span><span class="default">$value</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; unset(</span><span class="default">$arr</span><span class="keyword">[</span><span class="default">$key </span><span class="keyword">+ </span><span class="default">1</span><span class="keyword">]);<br />&nbsp; &nbsp; echo </span><span class="default">$value </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span>Output:<br />1 2 3 4 5 6 7 8 9 <br /><br /><span class="default">&lt;?php<br />$arr </span><span class="keyword">= array(</span><span class="default">1</span><span class="keyword">,</span><span class="default">2</span><span class="keyword">,</span><span class="default">3</span><span class="keyword">,</span><span class="default">4</span><span class="keyword">,</span><span class="default">5</span><span class="keyword">,</span><span class="default">6</span><span class="keyword">,</span><span class="default">7</span><span class="keyword">,</span><span class="default">8</span><span class="keyword">,</span><span class="default">9</span><span class="keyword">);<br /><br />while (list(</span><span class="default">$key</span><span class="keyword">, </span><span class="default">$value</span><span class="keyword">) = </span><span class="default">each</span><span class="keyword">(</span><span class="default">$arr</span><span class="keyword">))<br />{<br />&nbsp; &nbsp; unset(</span><span class="default">$arr</span><span class="keyword">[</span><span class="default">$key </span><span class="keyword">+ </span><span class="default">1</span><span class="keyword">]);<br />&nbsp; &nbsp; echo </span><span class="default">$value </span><span class="keyword">. </span><span class="default">PHP_EOL</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span>Output:<br />1 3 5 7 9<br /><br /><br />[EDIT BY danbrown AT php DOT net: Contains a typofix by (scissor AT phplabs DOT pl) on 30-JAN-2009.]</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120201">  <div class="votes">
    <div id="Vu120201">
    <a href="/manual/vote-note.php?id=120201&amp;page=control-structures.foreach&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120201">
    <a href="/manual/vote-note.php?id=120201&amp;page=control-structures.foreach&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120201" title="58% like this...">
    6
    </div>
  </div>
  <a href="#120201" class="name">
  <strong class="user"><em>mustaroad</em></strong></a><a class="genanchor" href="#120201"> &para;</a><div class="date" title="2016-11-22 06:38"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom120201">
<div class="phpcode"><code><span class="html">
in foreach if you want to iterate through a specific column in a nested arrays for example:<br /><br />$arr = array(<br />&nbsp; &nbsp;&nbsp; [1, 2, 3,&nbsp;&nbsp; 4],<br />&nbsp; &nbsp;&nbsp; [14, 6, 7,&nbsp; 6],<br />&nbsp; &nbsp;&nbsp; [10, 2 ,3 , 2],<br />);<br /><br />when we want to iterate on the third column we can use:<br /><br />foreach( $arr as list( , , $a)) {<br />&nbsp; &nbsp; echo "$a\n";<br />}<br /><br />this will print:<br />3<br />7<br />3</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116350">  <div class="votes">
    <div id="Vu116350">
    <a href="/manual/vote-note.php?id=116350&amp;page=control-structures.foreach&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116350">
    <a href="/manual/vote-note.php?id=116350&amp;page=control-structures.foreach&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116350" title="56% like this...">
    12
    </div>
  </div>
  <a href="#116350" class="name">
  <strong class="user"><em>Fred</em></strong></a><a class="genanchor" href="#116350"> &para;</a><div class="date" title="2014-12-16 08:53"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom116350">
<div class="phpcode"><code><span class="html">
If you want to use the list for multidimension arrays, you can nest several lists:<br /><br /><span class="default">&lt;?php<br />$array </span><span class="keyword">= [<br />&nbsp; &nbsp; [</span><span class="default">1</span><span class="keyword">, </span><span class="default">2</span><span class="keyword">, array(</span><span class="default">3</span><span class="keyword">, </span><span class="default">4</span><span class="keyword">)],<br />&nbsp; &nbsp; [</span><span class="default">3</span><span class="keyword">, </span><span class="default">4</span><span class="keyword">, array(</span><span class="default">5</span><span class="keyword">, </span><span class="default">6</span><span class="keyword">)],<br />];<br /><br />foreach (</span><span class="default">$array </span><span class="keyword">as list(</span><span class="default">$a</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">, list(</span><span class="default">$c</span><span class="keyword">, </span><span class="default">$d</span><span class="keyword">))) {<br />&nbsp; &nbsp; echo </span><span class="string">"A: </span><span class="default">$a</span><span class="string">; B: </span><span class="default">$b</span><span class="string">; C: </span><span class="default">$c</span><span class="string">; D: </span><span class="default">$d</span><span class="string">;&lt;br&gt;"</span><span class="keyword">;<br />};<br /></span><span class="default">?&gt;<br /></span><br />Will output:<br />A: 1; B: 2; C: 3; D: 4;<br />A: 3; B: 4; C: 5; D: 6;<br /><br />And:<br /><br /><span class="default">&lt;?php<br />$array </span><span class="keyword">= [<br />&nbsp; &nbsp; [</span><span class="default">1</span><span class="keyword">, </span><span class="default">2</span><span class="keyword">, array(</span><span class="default">3</span><span class="keyword">, array(</span><span class="default">4</span><span class="keyword">, </span><span class="default">5</span><span class="keyword">))],<br />&nbsp; &nbsp; [</span><span class="default">3</span><span class="keyword">, </span><span class="default">4</span><span class="keyword">, array(</span><span class="default">5</span><span class="keyword">, array(</span><span class="default">6</span><span class="keyword">, </span><span class="default">7</span><span class="keyword">))],<br />];<br /><br />foreach (</span><span class="default">$array </span><span class="keyword">as list(</span><span class="default">$a</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">, list(</span><span class="default">$c</span><span class="keyword">, list(</span><span class="default">$d</span><span class="keyword">, </span><span class="default">$e</span><span class="keyword">)))) {<br />&nbsp; &nbsp; echo </span><span class="string">"A: </span><span class="default">$a</span><span class="string">; B: </span><span class="default">$b</span><span class="string">; C: </span><span class="default">$c</span><span class="string">; D: </span><span class="default">$d</span><span class="string">; E: </span><span class="default">$e</span><span class="string">;&lt;br&gt;"</span><span class="keyword">;<br />};<br /></span><span class="default">Will output</span><span class="keyword">:<br /></span><span class="default">A</span><span class="keyword">: </span><span class="default">1</span><span class="keyword">; </span><span class="default">B</span><span class="keyword">: </span><span class="default">2</span><span class="keyword">; </span><span class="default">C</span><span class="keyword">: </span><span class="default">3</span><span class="keyword">; </span><span class="default">D</span><span class="keyword">: </span><span class="default">4</span><span class="keyword">; </span><span class="default">E</span><span class="keyword">: </span><span class="default">5</span><span class="keyword">;<br /></span><span class="default">A</span><span class="keyword">: </span><span class="default">3</span><span class="keyword">; </span><span class="default">B</span><span class="keyword">: </span><span class="default">4</span><span class="keyword">; </span><span class="default">C</span><span class="keyword">: </span><span class="default">5</span><span class="keyword">; </span><span class="default">D</span><span class="keyword">: </span><span class="default">6</span><span class="keyword">; </span><span class="default">E</span><span class="keyword">: </span><span class="default">7</span><span class="keyword">;<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="99909">  <div class="votes">
    <div id="Vu99909">
    <a href="/manual/vote-note.php?id=99909&amp;page=control-structures.foreach&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd99909">
    <a href="/manual/vote-note.php?id=99909&amp;page=control-structures.foreach&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V99909" title="55% like this...">
    14
    </div>
  </div>
  <a href="#99909" class="name">
  <strong class="user"><em>Oleg englishman at bigmir dot net</em></strong></a><a class="genanchor" href="#99909"> &para;</a><div class="date" title="2010-09-14 07:12"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom99909">
<div class="phpcode"><code><span class="html">
For those who'd like to traverse an array including just added elements (within this very foreach), here's a workaround:<br /><br /><span class="default">&lt;?php<br />$values </span><span class="keyword">= array(</span><span class="default">1 </span><span class="keyword">=&gt; </span><span class="string">'a'</span><span class="keyword">, </span><span class="default">2 </span><span class="keyword">=&gt; </span><span class="string">'b'</span><span class="keyword">, </span><span class="default">3 </span><span class="keyword">=&gt; </span><span class="string">'c'</span><span class="keyword">);<br />while (list(</span><span class="default">$key</span><span class="keyword">, </span><span class="default">$value</span><span class="keyword">) = </span><span class="default">each</span><span class="keyword">(</span><span class="default">$values</span><span class="keyword">)) {<br />&nbsp; &nbsp; echo </span><span class="string">"</span><span class="default">$key</span><span class="string"> =&gt; </span><span class="default">$value</span><span class="string"> \r\n"</span><span class="keyword">;<br />&nbsp; &nbsp; if (</span><span class="default">$key </span><span class="keyword">== </span><span class="default">3</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$values</span><span class="keyword">[</span><span class="default">4</span><span class="keyword">] = </span><span class="string">'d'</span><span class="keyword">; <br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; if (</span><span class="default">$key </span><span class="keyword">== </span><span class="default">4</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$values</span><span class="keyword">[</span><span class="default">5</span><span class="keyword">] = </span><span class="string">'e'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />the code above will output:<br /><br />1 =&gt; a<br />2 =&gt; b<br />3 =&gt; c<br />4 =&gt; d<br />5 =&gt; e</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116473">  <div class="votes">
    <div id="Vu116473">
    <a href="/manual/vote-note.php?id=116473&amp;page=control-structures.foreach&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116473">
    <a href="/manual/vote-note.php?id=116473&amp;page=control-structures.foreach&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116473" title="55% like this...">
    6
    </div>
  </div>
  <a href="#116473" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#116473"> &para;</a><div class="date" title="2015-01-08 12:38"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom116473">
<div class="phpcode"><code><span class="html">
modifying array while foreach'ing it(yeah, such slime code;-)<br />if elements were added on last iteration or into array with 1 element, then added elements wont be iterated as foreach checks for pointer before iteration cycle<br />so it just quit and added elements wont be treated</span>
</code></div>
  </div>
 </div>
  <div class="note" id="112590">  <div class="votes">
    <div id="Vu112590">
    <a href="/manual/vote-note.php?id=112590&amp;page=control-structures.foreach&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd112590">
    <a href="/manual/vote-note.php?id=112590&amp;page=control-structures.foreach&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V112590" title="52% like this...">
    5
    </div>
  </div>
  <a href="#112590" class="name">
  <strong class="user"><em>Delian Krustev</em></strong></a><a class="genanchor" href="#112590"> &para;</a><div class="date" title="2013-07-02 01:43"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom112590">
<div class="phpcode"><code><span class="html">
I want to add some inline comments to dtowell's piece of code about the iteration by reference:<br /><br /><span class="default">&lt;?php<br /><br />$a </span><span class="keyword">= array(</span><span class="string">'abe'</span><span class="keyword">,</span><span class="string">'ben'</span><span class="keyword">,</span><span class="string">'cam'</span><span class="keyword">);<br /><br />foreach (</span><span class="default">$a </span><span class="keyword">as </span><span class="default">$k</span><span class="keyword">=&gt;&amp;</span><span class="default">$n</span><span class="keyword">)<br />&nbsp; &nbsp; </span><span class="default">$n </span><span class="keyword">= </span><span class="default">strtoupper</span><span class="keyword">(</span><span class="default">$n</span><span class="keyword">);<br /><br /></span><span class="comment"># At the end of this cycle the variable $n refers to the same memory as $a[2]<br /># So when the second "foreach" assigns a value to $n :<br /><br /></span><span class="keyword">foreach (</span><span class="default">$a </span><span class="keyword">as </span><span class="default">$k</span><span class="keyword">=&gt;</span><span class="default">$n</span><span class="keyword">) </span><span class="comment">// notice NO reference here!<br />&nbsp; &nbsp; </span><span class="keyword">echo </span><span class="string">"</span><span class="default">$n</span><span class="string">\n"</span><span class="keyword">;<br /><br /></span><span class="comment"># it is also modifying $a[2] .<br /># So on the three repetitions of the second "foreach" the array will look like:<br /># 1. ('abe','ben','abe') - assigned the value of the first element to the last element<br /># 2. ('abe','ben','ben') - assigned the value of the second element to the last element<br /># 3. ('abe','ben','ben') - assigned the value of the third element to itself<br /><br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">);<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118405">  <div class="votes">
    <div id="Vu118405">
    <a href="/manual/vote-note.php?id=118405&amp;page=control-structures.foreach&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118405">
    <a href="/manual/vote-note.php?id=118405&amp;page=control-structures.foreach&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118405" title="52% like this...">
    2
    </div>
  </div>
  <a href="#118405" class="name">
  <strong class="user"><em>sebastian dot goendoer at NOSPAM dot telekom dot de</em></strong></a><a class="genanchor" href="#118405"> &para;</a><div class="date" title="2015-12-01 02:08"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom118405">
<div class="phpcode"><code><span class="html">
String keys of associative arrays, for which is_numeric() is true and which can be type-juggled to an int will be cast to an int! If the key is on the other hand a string that can be type-juggled into a float, it will stay a string. (Observed on PHP 7.0.0RC8)<br /><br /><span class="default">&lt;?php<br />$arr </span><span class="keyword">= array();<br /></span><span class="default">$arr</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">] = </span><span class="string">"zero"</span><span class="keyword">;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// will stay an int<br /></span><span class="default">$arr</span><span class="keyword">[</span><span class="string">"1"</span><span class="keyword">] = </span><span class="string">"one"</span><span class="keyword">;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// will be cast to an int !<br /></span><span class="default">$arr</span><span class="keyword">[</span><span class="string">"two"</span><span class="keyword">] = </span><span class="string">"2"</span><span class="keyword">;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// will stay a string<br /></span><span class="default">$arr</span><span class="keyword">[</span><span class="string">"3.5"</span><span class="keyword">] = </span><span class="string">"threeandahalf"</span><span class="keyword">;&nbsp; &nbsp; </span><span class="comment">// will stay a string<br /><br /></span><span class="keyword">foreach(</span><span class="default">$arr </span><span class="keyword">as </span><span class="default">$key </span><span class="keyword">=&gt; </span><span class="default">$value</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$key</span><span class="keyword">);<br />}<br /></span><span class="default">?&gt;<br /></span><br />The output will be<br /><br />int(0)<br />int(1)<br />string(3) "two"<br />string(3) "3.5"</span>
</code></div>
  </div>
 </div>
  <div class="note" id="109698">  <div class="votes">
    <div id="Vu109698">
    <a href="/manual/vote-note.php?id=109698&amp;page=control-structures.foreach&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd109698">
    <a href="/manual/vote-note.php?id=109698&amp;page=control-structures.foreach&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V109698" title="51% like this...">
    6
    </div>
  </div>
  <a href="#109698" class="name">
  <strong class="user"><em>dtowell</em></strong></a><a class="genanchor" href="#109698"> &para;</a><div class="date" title="2012-08-11 12:44"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom109698">
<div class="phpcode"><code><span class="html">
References created by foreach hang around past their best-used-by date. For example, the following:<br /><br /><span class="default">&lt;?php<br />$a </span><span class="keyword">= array(</span><span class="string">'abe'</span><span class="keyword">,</span><span class="string">'ben'</span><span class="keyword">,</span><span class="string">'cam'</span><span class="keyword">);<br />foreach (</span><span class="default">$a </span><span class="keyword">as </span><span class="default">$k</span><span class="keyword">=&gt;&amp;</span><span class="default">$n</span><span class="keyword">)<br />&nbsp; &nbsp; </span><span class="default">$n </span><span class="keyword">= </span><span class="default">strtoupper</span><span class="keyword">(</span><span class="default">$n</span><span class="keyword">);<br />foreach (</span><span class="default">$a </span><span class="keyword">as </span><span class="default">$k</span><span class="keyword">=&gt;</span><span class="default">$n</span><span class="keyword">) </span><span class="comment">// notice NO reference here!<br />&nbsp; &nbsp; </span><span class="keyword">echo </span><span class="string">"</span><span class="default">$n</span><span class="string">\n"</span><span class="keyword">;<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />will result in:<br /><br />ABE<br />BEN<br />BEN<br />Array<br />(<br />&nbsp; &nbsp; [0] =&gt; ABE<br />&nbsp; &nbsp; [1] =&gt; BEN<br />&nbsp; &nbsp; [2] =&gt; BEN<br />)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121581">  <div class="votes">
    <div id="Vu121581">
    <a href="/manual/vote-note.php?id=121581&amp;page=control-structures.foreach&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121581">
    <a href="/manual/vote-note.php?id=121581&amp;page=control-structures.foreach&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121581" title="100% like this...">
    1
    </div>
  </div>
  <a href="#121581" class="name">
  <strong class="user"><em>peter georgiev</em></strong></a><a class="genanchor" href="#121581"> &para;</a><div class="date" title="2017-08-31 07:50"><strong>3 months ago</strong></div>
  <div class="text" id="Hcom121581">
<div class="phpcode"><code><span class="html">
I want just to mention that John is not entirely true.<br /><br />Simple field test:<br /><br />$m = microtime(1); $array = range(1,1000000); foreach ($array as &amp;$i) { $i = 4; } echo microtime(1) - $m;<br /><br />Result: 0.21731400489807<br /><br />$m = microtime(1); $array = range(1,1000000); foreach ($array as $k =&gt; $i) { $array[$k] = 4; } echo microtime(1) - $m;<br /><br />Result: 0.51596283912659<br /><br />PHP Version: PHP 5.6.30 (cli) (built: Jan 18 2017 19:47:36)<br /><br />Conclusion: Working with reference, although a bit dangerous is &gt;2 times faster. You just need to know well what are you doing.<br /><br />Best of luck and happy coding all</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121733">  <div class="votes">
    <div id="Vu121733">
    <a href="/manual/vote-note.php?id=121733&amp;page=control-structures.foreach&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121733">
    <a href="/manual/vote-note.php?id=121733&amp;page=control-structures.foreach&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121733" title="50% like this...">
    0
    </div>
  </div>
  <a href="#121733" class="name">
  <strong class="user"><em>KEINOS</em></strong></a><a class="genanchor" href="#121733"> &para;</a><div class="date" title="2017-10-07 02:21"><strong>2 months ago</strong></div>
  <div class="text" id="Hcom121733">
<div class="phpcode"><code><span class="html">
Even though it is not mentioned in this article, you can use "break" control structure to exit from the "foreach" loop.<br /><br /><span class="default">&lt;?php<br /><br />$array </span><span class="keyword">= [ </span><span class="string">'one'</span><span class="keyword">, </span><span class="string">'two'</span><span class="keyword">, </span><span class="string">'three'</span><span class="keyword">, </span><span class="string">'four'</span><span class="keyword">, </span><span class="string">'five' </span><span class="keyword">];<br /><br />foreach( </span><span class="default">$array </span><span class="keyword">as </span><span class="default">$value </span><span class="keyword">){<br />&nbsp; &nbsp; if( </span><span class="default">$value </span><span class="keyword">== </span><span class="string">'three' </span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Number three was found!"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="106971">  <div class="votes">
    <div id="Vu106971">
    <a href="/manual/vote-note.php?id=106971&amp;page=control-structures.foreach&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd106971">
    <a href="/manual/vote-note.php?id=106971&amp;page=control-structures.foreach&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V106971" title="48% like this...">
    -6
    </div>
  </div>
  <a href="#106971" class="name">
  <strong class="user"><em>nobody at nobody dot com</em></strong></a><a class="genanchor" href="#106971"> &para;</a><div class="date" title="2011-12-22 01:11"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom106971">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br />$d3 </span><span class="keyword">= array(</span><span class="string">'a'</span><span class="keyword">=&gt;array(</span><span class="string">'b'</span><span class="keyword">=&gt;</span><span class="string">'c'</span><span class="keyword">));<br />foreach(</span><span class="default">$d3</span><span class="keyword">[</span><span class="string">'a'</span><span class="keyword">] as &amp;</span><span class="default">$v4</span><span class="keyword">){}<br />foreach(</span><span class="default">$d3 </span><span class="keyword">as </span><span class="default">$v4</span><span class="keyword">){}<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$d3</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span>will get something look like this:<br />array(1) {<br />&nbsp; ["a"]=&gt;<br />&nbsp; array(1) {<br />&nbsp; &nbsp; ["b"]=&gt;<br />&nbsp; &nbsp; &amp;array(1) {<br />&nbsp; &nbsp; &nbsp; ["b"]=&gt;<br />&nbsp; &nbsp; &nbsp; *RECURSION*<br />&nbsp; &nbsp; }<br />&nbsp; }<br />}<br />then you try to walk some data with this array.<br />the script run out of memory and connect reset by peer<br /><br />the document says:<br />Warning<br />Reference of a $value and the last array element remain even after the foreach loop. It is recommended to destroy it by unset().<br /><br />so what I learn is that NEVER ignore """Warning""" in document....</span>
</code></div>
  </div>
 </div>
  <div class="note" id="104060">  <div class="votes">
    <div id="Vu104060">
    <a href="/manual/vote-note.php?id=104060&amp;page=control-structures.foreach&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd104060">
    <a href="/manual/vote-note.php?id=104060&amp;page=control-structures.foreach&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V104060" title="47% like this...">
    -6
    </div>
  </div>
  <a href="#104060" class="name">
  <strong class="user"><em>billardmchl at aol dot com</em></strong></a><a class="genanchor" href="#104060"> &para;</a><div class="date" title="2011-05-20 01:20"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom104060">
<div class="phpcode"><code><span class="html">
This function find well the words, add well adds a () around short words, but the <br />array at the end of th function is the same as at the beginning.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">isole_mots</span><span class="keyword">(</span><span class="default">$chaine</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="default">$chaine </span><span class="keyword">= </span><span class="string">"le petit chat est fou"</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$mots </span><span class="keyword">= </span><span class="default">preg_split</span><span class="keyword">(</span><span class="string">'/[!,-.;?:()[ ]/'</span><span class="keyword">, </span><span class="default">$chaine</span><span class="keyword">, -</span><span class="default">1</span><span class="keyword">, </span><span class="default">PREG_SPLIT_NO_EMPTY</span><span class="keyword">);<br />&nbsp; &nbsp; foreach (</span><span class="default">$mots </span><span class="keyword">as </span><span class="default">$mot</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$mot</span><span class="keyword">) &lt;= </span><span class="default">3</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$mot </span><span class="keyword">= </span><span class="string">"("</span><span class="keyword">.</span><span class="default">$mot</span><span class="keyword">.</span><span class="string">")"</span><span class="keyword">;<br />&nbsp; &nbsp; print </span><span class="string">" inside foreach </span><span class="default">$mot</span><span class="string"> &lt;br&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />print </span><span class="string">"after foreach array mots"</span><span class="keyword">;&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$mots</span><span class="keyword">);<br />&nbsp; &nbsp; die();<br />&nbsp; &nbsp; return </span><span class="default">$mots</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />inside foreach (le)<br />inside foreach petit<br />inside foreach chat<br />inside foreach (est)<br />inside foreach (fou)<br />after foreach array motsArray ( [0] =&gt; le [1] =&gt; petit [2] =&gt; chat [3] =&gt; est [4] =&gt; fou )</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118028">  <div class="votes">
    <div id="Vu118028">
    <a href="/manual/vote-note.php?id=118028&amp;page=control-structures.foreach&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118028">
    <a href="/manual/vote-note.php?id=118028&amp;page=control-structures.foreach&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118028" title="42% like this...">
    -9
    </div>
  </div>
  <a href="#118028" class="name">
  <strong class="user"><em>pnc at balintx dot me</em></strong></a><a class="genanchor" href="#118028"> &para;</a><div class="date" title="2015-09-21 10:14"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom118028">
<div class="phpcode"><code><span class="html">
Just a simple strange behavior I have ran into:<br /><br />If you accidentally put a semicolon after the foreach statement, you get no errors, but the loop will only run on the last element of the array:<br /><span class="default">&lt;?php<br />$array </span><span class="keyword">= array(</span><span class="default">1</span><span class="keyword">,</span><span class="default">2</span><span class="keyword">,</span><span class="default">3</span><span class="keyword">);<br />foreach (</span><span class="default">$array </span><span class="keyword">as </span><span class="default">$key</span><span class="keyword">);<br />{<br />&nbsp; &nbsp; echo </span><span class="default">$key</span><span class="keyword">;<br />}<br /></span><span class="comment">// output: 3<br /></span><span class="default">?&gt;<br /></span><br />Correctly:<br /><span class="default">&lt;?php<br />$array </span><span class="keyword">= array(</span><span class="default">1</span><span class="keyword">,</span><span class="default">2</span><span class="keyword">,</span><span class="default">3</span><span class="keyword">);<br />foreach (</span><span class="default">$array </span><span class="keyword">as </span><span class="default">$key</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; echo </span><span class="default">$key</span><span class="keyword">;<br />}<br /></span><span class="comment">// output: 123<br /></span><span class="default">?&gt;<br /></span><br />It took me a while to find that semicolon.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114880">  <div class="votes">
    <div id="Vu114880">
    <a href="/manual/vote-note.php?id=114880&amp;page=control-structures.foreach&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114880">
    <a href="/manual/vote-note.php?id=114880&amp;page=control-structures.foreach&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114880" title="42% like this...">
    -11
    </div>
  </div>
  <a href="#114880" class="name">
  <strong class="user"><em>nehuen</em></strong></a><a class="genanchor" href="#114880"> &para;</a><div class="date" title="2014-04-20 03:27"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114880">
<div class="phpcode"><code><span class="html">
foreach by reference internally deleted and created a new reference in each iteration, so it is not possible to directly use this value as a variable parameter values​​, look at the following example where the problem is observed and a possible solution:<br /><br /><span class="default">&lt;?php<br /> </span><span class="keyword">class </span><span class="default">test<br /> </span><span class="keyword">{<br />&nbsp; &nbsp; private </span><span class="default">$a </span><span class="keyword">= </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp; private </span><span class="default">$r </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; public function </span><span class="default">show</span><span class="keyword">(&amp;</span><span class="default">$v</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; if(!</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">a</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">a </span><span class="keyword">= </span><span class="default">true</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">r </span><span class="keyword">= &amp;</span><span class="default">$v</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">r</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public function </span><span class="default">reset</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">a </span><span class="keyword">= </span><span class="default">false</span><span class="keyword">;&nbsp; &nbsp; <br />&nbsp; &nbsp; }<br /> }<br /> <br /> </span><span class="default">$t </span><span class="keyword">= new </span><span class="default">test</span><span class="keyword">();<br /> <br /> </span><span class="default">$a </span><span class="keyword">= array(array(</span><span class="default">1</span><span class="keyword">,</span><span class="default">2</span><span class="keyword">),array(</span><span class="default">3</span><span class="keyword">,</span><span class="default">4</span><span class="keyword">),array(</span><span class="default">5</span><span class="keyword">,</span><span class="default">6</span><span class="keyword">));<br /> foreach(</span><span class="default">$a </span><span class="keyword">as &amp;</span><span class="default">$p</span><span class="keyword">)<br />&nbsp; &nbsp; </span><span class="default">$t</span><span class="keyword">-&gt;</span><span class="default">show</span><span class="keyword">(</span><span class="default">$p</span><span class="keyword">);<br />&nbsp; &nbsp; <br /> </span><span class="comment">/* Output obtain:<br />&nbsp; &nbsp; array (size=2)<br />&nbsp; &nbsp; &nbsp; 0 =&gt; int 1<br />&nbsp; &nbsp; &nbsp; 1 =&gt; int 2<br />&nbsp; &nbsp; array (size=2)<br />&nbsp; &nbsp; &nbsp; 0 =&gt; int 1<br />&nbsp; &nbsp; &nbsp; 1 =&gt; int 2<br />&nbsp; &nbsp; array (size=2)<br />&nbsp; &nbsp; &nbsp; 0 =&gt; int 1<br />&nbsp; &nbsp; &nbsp; 1 =&gt; int 2<br /> */<br />&nbsp; <br />&nbsp; </span><span class="default">$t</span><span class="keyword">-&gt;</span><span class="default">reset</span><span class="keyword">();<br />&nbsp; foreach(</span><span class="default">$a </span><span class="keyword">as </span><span class="default">$p</span><span class="keyword">)<br />&nbsp; {<br />&nbsp; &nbsp; </span><span class="default">$b </span><span class="keyword">= &amp;</span><span class="default">$p</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$t</span><span class="keyword">-&gt;</span><span class="default">show</span><span class="keyword">(</span><span class="default">$b</span><span class="keyword">);<br />&nbsp; }<br />&nbsp; <br /> </span><span class="comment">/* Output obtain:<br />&nbsp; &nbsp; array (size=2)<br />&nbsp; &nbsp; &nbsp; 0 =&gt; int 1<br />&nbsp; &nbsp; &nbsp; 1 =&gt; int 2<br />&nbsp; &nbsp; array (size=2)<br />&nbsp; &nbsp; &nbsp; 0 =&gt; int 3<br />&nbsp; &nbsp; &nbsp; 1 =&gt; int 4<br />&nbsp; &nbsp; array (size=2)<br />&nbsp; &nbsp; &nbsp; 0 =&gt; int 5<br />&nbsp; &nbsp; &nbsp; 1 =&gt; int 6<br /> */</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120916">  <div class="votes">
    <div id="Vu120916">
    <a href="/manual/vote-note.php?id=120916&amp;page=control-structures.foreach&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120916">
    <a href="/manual/vote-note.php?id=120916&amp;page=control-structures.foreach&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120916" title="33% like this...">
    -6
    </div>
  </div>
  <a href="#120916" class="name">
  <strong class="user"><em>ahmad dot mayahi at gmail dot com</em></strong></a><a class="genanchor" href="#120916"> &para;</a><div class="date" title="2017-03-31 12:20"><strong>8 months ago</strong></div>
  <div class="text" id="Hcom120916">
<div class="phpcode"><code><span class="html">
foreach retains the state of internal defined variable:<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">/**<br />Result for this array is:<br />Hello World<br />Hello World<br />Hello World<br />*/<br /></span><span class="default">$arr </span><span class="keyword">= [</span><span class="string">"a"</span><span class="keyword">, </span><span class="string">"b"</span><span class="keyword">, </span><span class="string">"c"</span><span class="keyword">];<br /></span><span class="default">$title </span><span class="keyword">= </span><span class="string">""</span><span class="keyword">;<br />foreach (</span><span class="default">$arr </span><span class="keyword">as </span><span class="default">$r</span><span class="keyword">) {<br />&nbsp; &nbsp; if (</span><span class="default">$r </span><span class="keyword">== </span><span class="string">"a"</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$title </span><span class="keyword">= </span><span class="string">"Hello World"</span><span class="keyword">;&nbsp;&nbsp; <br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; echo </span><span class="default">$title</span><span class="keyword">.</span><span class="string">"&lt;br&gt;"</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />in this case, all we need to do is to add an else statement:<br /><span class="default">&lt;?php<br />$arr </span><span class="keyword">= [</span><span class="string">"a"</span><span class="keyword">, </span><span class="string">"b"</span><span class="keyword">, </span><span class="string">"c"</span><span class="keyword">];<br /></span><span class="default">$title </span><span class="keyword">= </span><span class="string">""</span><span class="keyword">;<br /></span><span class="comment">/**<br />This prints:<br />Hello World<br />*/<br /></span><span class="keyword">foreach (</span><span class="default">$arr </span><span class="keyword">as </span><span class="default">$r</span><span class="keyword">) {<br />&nbsp; &nbsp; if (</span><span class="default">$r </span><span class="keyword">== </span><span class="string">"a"</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$title </span><span class="keyword">= </span><span class="string">"Hello World"</span><span class="keyword">;&nbsp;&nbsp; <br />&nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$title </span><span class="keyword">= </span><span class="string">""</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; echo </span><span class="default">$title</span><span class="keyword">.</span><span class="string">"&lt;br&gt;"</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119284">  <div class="votes">
    <div id="Vu119284">
    <a href="/manual/vote-note.php?id=119284&amp;page=control-structures.foreach&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119284">
    <a href="/manual/vote-note.php?id=119284&amp;page=control-structures.foreach&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119284" title="30% like this...">
    -10
    </div>
  </div>
  <a href="#119284" class="name">
  <strong class="user"><em>till at etill dot net</em></strong></a><a class="genanchor" href="#119284"> &para;</a><div class="date" title="2016-05-03 09:39"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119284">
<div class="phpcode"><code><span class="html">
Note: Empty arrays are handled just fine by foreach, but for fail-safe code, you should always check that what is passed in fact is an array, like this:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">if( </span><span class="default">is_array</span><span class="keyword">( </span><span class="default">$a</span><span class="keyword">) ) {<br />&nbsp; foreach( </span><span class="default">$a </span><span class="keyword">as </span><span class="default">$v</span><span class="keyword">) { ... }<br />} else <br /></span><span class="comment">// $a is not an array<br /></span><span class="keyword">;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116434">  <div class="votes">
    <div id="Vu116434">
    <a href="/manual/vote-note.php?id=116434&amp;page=control-structures.foreach&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116434">
    <a href="/manual/vote-note.php?id=116434&amp;page=control-structures.foreach&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116434" title="30% like this...">
    -21
    </div>
  </div>
  <a href="#116434" class="name">
  <strong class="user"><em>Anteaus</em></strong></a><a class="genanchor" href="#116434"> &para;</a><div class="date" title="2015-01-02 09:35"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom116434">
<div class="phpcode"><code><span class="html">
"In order to be able to directly modify array elements within the loop precede $value with &amp;. In that case the value will be assigned by reference. "<br /><br />PLEASE CLARIFY! -Does this still hold true in php5.4+, where explicit passing by reference is seemingly forbidden- or is this now illegal syntax?</span>
</code></div>
  </div>
 </div>
  <div class="note" id="111825">  <div class="votes">
    <div id="Vu111825">
    <a href="/manual/vote-note.php?id=111825&amp;page=control-structures.foreach&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd111825">
    <a href="/manual/vote-note.php?id=111825&amp;page=control-structures.foreach&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V111825" title="33% like this...">
    -39
    </div>
  </div>
  <a href="#111825" class="name">
  <strong class="user"><em>Ashus</em></strong></a><a class="genanchor" href="#111825"> &para;</a><div class="date" title="2013-04-02 01:25"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom111825">
<div class="phpcode"><code><span class="html">
If you wondered how to create a list of all possible combinations of variable amount of arrays (multiple foreach), you might use this:<br /><br /><span class="default">&lt;?php<br /><br />$a</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">] = array(</span><span class="string">'a1'</span><span class="keyword">,</span><span class="string">'a2'</span><span class="keyword">);<br /></span><span class="default">$a</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">] = array(</span><span class="string">'b1'</span><span class="keyword">,</span><span class="string">'b2'</span><span class="keyword">,</span><span class="string">'b3'</span><span class="keyword">);<br /></span><span class="default">$a</span><span class="keyword">[</span><span class="default">2</span><span class="keyword">] = array(</span><span class="string">'c1'</span><span class="keyword">,</span><span class="string">'c2'</span><span class="keyword">);<br /><br />function </span><span class="default">getAllCombinations</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">,</span><span class="default">$i</span><span class="keyword">,</span><span class="default">$s</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; foreach (</span><span class="default">$a</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">] as </span><span class="default">$v</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (!isset(</span><span class="default">$a</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">+</span><span class="default">1</span><span class="keyword">]))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">$s</span><span class="keyword">.</span><span class="default">$v</span><span class="keyword">.</span><span class="string">"\n"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">getAllCombinations</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">,</span><span class="default">$i</span><span class="keyword">+</span><span class="default">1</span><span class="keyword">,</span><span class="default">$s</span><span class="keyword">.</span><span class="default">$v</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; return </span><span class="default">$s</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />echo </span><span class="default">getAllCombinations</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">,</span><span class="default">0</span><span class="keyword">,</span><span class="string">''</span><span class="keyword">);<br /><br /></span><span class="default">?&gt;<br /></span><br />the result:<br /><br />a1b1c1<br />a1b1c2<br />a1b2c1<br />a1b2c2<br />a1b3c1<br />a1b3c2<br />a2b1c1<br />a2b1c2<br />a2b2c1<br />a2b2c2<br />a2b3c1<br />a2b3c2</span>
</code></div>
  </div>
 </div>
  <div class="note" id="71854">  <div class="votes">
    <div id="Vu71854">
    <a href="/manual/vote-note.php?id=71854&amp;page=control-structures.foreach&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd71854">
    <a href="/manual/vote-note.php?id=71854&amp;page=control-structures.foreach&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V71854" title="33% like this...">
    -47
    </div>
  </div>
  <a href="#71854" class="name">
  <strong class="user"><em>simplex</em></strong></a><a class="genanchor" href="#71854"> &para;</a><div class="date" title="2006-12-19 12:12"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom71854">
<div class="phpcode"><code><span class="html">
"As of PHP 5, you can easily modify array's elements by preceding $value with &amp;. This will assign reference instead of copying the value."<br /><br />There are cases where array_walk or array_map are inadequate (conditional required) or you're just too lazy to write a function and pass values to it for use with array_map...<br /><br />My solution to foreach for php 4 and 5 to modify values of an array directly:<br /><br /><span class="default">&lt;?php<br /><br />$testarr </span><span class="keyword">= array(</span><span class="string">"a" </span><span class="keyword">=&gt; </span><span class="default">1</span><span class="keyword">, </span><span class="string">"b" </span><span class="keyword">=&gt; </span><span class="default">2</span><span class="keyword">, </span><span class="string">"c" </span><span class="keyword">=&gt; </span><span class="default">3</span><span class="keyword">, </span><span class="string">"d" </span><span class="keyword">=&gt; </span><span class="default">4</span><span class="keyword">);<br /><br /></span><span class="default">$testarr_keys </span><span class="keyword">= </span><span class="default">array_keys</span><span class="keyword">(</span><span class="default">$testarr</span><span class="keyword">);<br /></span><span class="default">$testarr_values </span><span class="keyword">= </span><span class="default">array_values</span><span class="keyword">(</span><span class="default">$testarr</span><span class="keyword">);<br /><br />for (</span><span class="default">$i </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">; </span><span class="default">$i </span><span class="keyword">&lt;= </span><span class="default">count</span><span class="keyword">(</span><span class="default">$testarr</span><span class="keyword">) - </span><span class="default">1</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">++) {<br />&nbsp; &nbsp; </span><span class="default">$testarr</span><span class="keyword">[</span><span class="default">$testarr_keys</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">]] = </span><span class="default">$testarr_values</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">] * </span><span class="default">2</span><span class="keyword">;<br />}<br /><br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$testarr</span><span class="keyword">);<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="115207">  <div class="votes">
    <div id="Vu115207">
    <a href="/manual/vote-note.php?id=115207&amp;page=control-structures.foreach&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115207">
    <a href="/manual/vote-note.php?id=115207&amp;page=control-structures.foreach&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115207" title="23% like this...">
    -20
    </div>
  </div>
  <a href="#115207" class="name">
  <strong class="user"><em>liam666 at donnelly-house dot net</em></strong></a><a class="genanchor" href="#115207"> &para;</a><div class="date" title="2014-06-12 01:12"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115207">
<div class="phpcode"><code><span class="html">
This is a decent, simple, and easy way to reference other values of an associative array when using foreach. (effective "next", "prev", etc.)<br />The only care that needs to be taken is if the array is HUGE in size, so you don't run into memory use problems. (and potential speed issues)<br /><br />This example uses the 'primary' array, $aPublishSeq, which is ksort-ed to put the array in order according to the associative keys. The array is then copied using a foreach loop to make a duplicate array where the key and value order correspond to the first array, but the keys are sequential numeric starting at zero.<br /><br />ksort ($aPublishSeq, SORT_STRING);&nbsp; &nbsp;&nbsp; // put them all in the right order keeping array keys<br />foreach ($aPublishSeq as $aValue)<br />&nbsp;&nbsp; $aPublishIdx[] = $aValue;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; // duplicate array using corresponding sequential numeric keys<br /><br />Now, in the usage foreach loop, an index variable is used to keep in sync with the associative array.<br /><br />$PubIdx = -1;&nbsp; &nbsp;&nbsp; // start at -1 to start at 0 below<br /><br />foreach ($aPublishSeq as $sKey =&gt; $sValue) {<br /><br />&nbsp; &nbsp; &nbsp; ++$PubIdx;&nbsp; &nbsp;&nbsp; // index into $aPublishIdx array of corresponding element in $aPublishSeq array (for "next" element check, etc.)<br /><br />&nbsp;&nbsp; echo $aPublishIdx[$PubIdx&nbsp; - 1]&nbsp; &nbsp;&nbsp; // previous array value<br />&nbsp;&nbsp; echo $aPublishIdx[$PubIdx]&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; // current array value<br />&nbsp;&nbsp; echo $aPublishIdx[$PubIdx&nbsp; + 1]&nbsp; &nbsp;&nbsp; // next array value<br /><br />....<br /><br />It's simple, but it works, and without much muss or fuss.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="107533">  <div class="votes">
    <div id="Vu107533">
    <a href="/manual/vote-note.php?id=107533&amp;page=control-structures.foreach&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd107533">
    <a href="/manual/vote-note.php?id=107533&amp;page=control-structures.foreach&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V107533" title="29% like this...">
    -48
    </div>
  </div>
  <a href="#107533" class="name">
  <strong class="user"><em>Voitcus at wp dot pl</em></strong></a><a class="genanchor" href="#107533"> &para;</a><div class="date" title="2012-02-15 08:55"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom107533">
<div class="phpcode"><code><span class="html">
You can even iterate through "dynamic" arrays that do not physically exist, but are objects that implement Iterator interface. They don't need to be stored in memory when foreach starts.<br /><br />Consider the array that contains some values (I called it $allValues in the example below) and we want to have only some of them (eg. the ones that are dividable by 2). I create an object that would serve as dynamic array, that means it would "dynamically update" its values together with $allValues. The main advantage is that I store only one array, and it's the only array I serialize.<br /><br />An object of MyIter class will not contain any values itself:<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">MyIter </span><span class="keyword">implements </span><span class="default">Iterator </span><span class="keyword">{ </span><span class="comment">// you can implement ArrayAccess and Countable interfaces too, this will make class MyIter behave like a "real" array<br />&nbsp; </span><span class="keyword">private </span><span class="default">$position </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">; </span><span class="comment">// an internal position of the current element<br />&nbsp; // please note that $position has nothing common with $allValues!<br /><br />&nbsp; </span><span class="keyword">private function </span><span class="default">getTable</span><span class="keyword">(){ </span><span class="comment">// prepare a temporary "static" table of all objects in the class<br />&nbsp; &nbsp; </span><span class="keyword">global </span><span class="default">$allValues</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$result</span><span class="keyword">=array(); </span><span class="comment">// temporary variable<br />&nbsp; &nbsp; </span><span class="keyword">foreach(</span><span class="default">$allValues </span><span class="keyword">as </span><span class="default">$obj</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; if(</span><span class="default">$obj </span><span class="keyword">% </span><span class="default">2 </span><span class="keyword">== </span><span class="default">0</span><span class="keyword">) </span><span class="comment">// check if the value is even<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$result</span><span class="keyword">[]=</span><span class="default">$obj</span><span class="keyword">; </span><span class="comment">// if yes, I want it<br />&nbsp; &nbsp; &nbsp; </span><span class="keyword">}<br />&nbsp; &nbsp; return </span><span class="default">$result</span><span class="keyword">;<br />&nbsp; }&nbsp; &nbsp; <br /><br />&nbsp; </span><span class="comment">// the all below declared methods are public and belong to the Iterator interface<br />&nbsp; </span><span class="keyword">function </span><span class="default">rewind</span><span class="keyword">() { </span><span class="comment">// a method to start iterating<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">position </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">; </span><span class="comment">// just move to the beginning<br />&nbsp; </span><span class="keyword">}<br /><br />&nbsp; function </span><span class="default">current</span><span class="keyword">() { </span><span class="comment">// retrieves the current element<br />&nbsp; &nbsp; </span><span class="default">$table</span><span class="keyword">=</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">getTable</span><span class="keyword">(); </span><span class="comment">// let us prepare a table<br />&nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">$table</span><span class="keyword">[</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">position</span><span class="keyword">]; </span><span class="comment">// and return the current element<br />&nbsp; </span><span class="keyword">}<br /><br />&nbsp; function </span><span class="default">key</span><span class="keyword">() { </span><span class="comment">// retrieves the current element's key<br />&nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">position</span><span class="keyword">; </span><span class="comment">// this is used by foreach(... as $key=&gt;$value), not important here<br />&nbsp; </span><span class="keyword">}<br /><br />&nbsp; function </span><span class="default">next</span><span class="keyword">() { </span><span class="comment">// move to next element<br />&nbsp; &nbsp; </span><span class="keyword">++</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">position</span><span class="keyword">;<br />&nbsp; }<br /><br />&nbsp; function </span><span class="default">valid</span><span class="keyword">() { </span><span class="comment">// check if the current element is valid (ie. if it exists)<br />&nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">array_key_exists</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">position</span><span class="keyword">, </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">getTable</span><span class="keyword">());<br />&nbsp; }<br />} </span><span class="comment">// end of class<br /><br />// now prepare the array of 12 elements<br /></span><span class="default">$allValues</span><span class="keyword">=array(</span><span class="default">0</span><span class="keyword">,</span><span class="default">1</span><span class="keyword">,</span><span class="default">2</span><span class="keyword">,</span><span class="default">3</span><span class="keyword">,</span><span class="default">4</span><span class="keyword">,</span><span class="default">5</span><span class="keyword">,</span><span class="default">6</span><span class="keyword">,</span><span class="default">7</span><span class="keyword">,</span><span class="default">8</span><span class="keyword">,</span><span class="default">9</span><span class="keyword">,</span><span class="default">10</span><span class="keyword">,</span><span class="default">11</span><span class="keyword">);<br /><br /></span><span class="comment">//we would like to have a dynamic array of all even values<br /></span><span class="default">$iterator</span><span class="keyword">=new </span><span class="default">MyIter</span><span class="keyword">();<br /><br />foreach(</span><span class="default">$iterator </span><span class="keyword">as </span><span class="default">$value</span><span class="keyword">){<br />&nbsp; echo </span><span class="default">$value</span><span class="keyword">.</span><span class="string">"&lt;br /&gt;"</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span>This will result in:<br />0<br />2<br />4<br />6<br />8<br />10<br /><br />(You may also like to see what var_dump($iterator) produces).<br /><br />Another great advantage is that you can modify the main table "on-the-fly" and it has its impact. Let us modify the last foreach loop:<br /><span class="default">&lt;?php<br /></span><span class="comment">// ...all above shall stay as it was<br /></span><span class="keyword">foreach(</span><span class="default">$iterator </span><span class="keyword">as </span><span class="default">$value</span><span class="keyword">){<br />&nbsp; echo </span><span class="default">$value</span><span class="keyword">.</span><span class="string">"&lt;br /&gt;"</span><span class="keyword">;<br />&nbsp; if(</span><span class="default">$value</span><span class="keyword">==</span><span class="default">6</span><span class="keyword">){<br />&nbsp; &nbsp; </span><span class="default">$allValues</span><span class="keyword">=array(</span><span class="default">2</span><span class="keyword">,</span><span class="default">3</span><span class="keyword">);<br />&nbsp; &nbsp; echo </span><span class="string">"I modified source array!&lt;br /&gt;"</span><span class="keyword">;<br />&nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span>This produces now:<br />0<br />2<br />4<br />6<br />I modified source array!<br /><br />However, if you feel it is rather a catastrophic disadvantage (maybe for example, it shows the values 0, 4, and 6 which were removed when we reached 6), and wish to have a "static" array that will iterate even in modified objects, just call getTable() in rewind() method and save it in temporary (private perhaps) field. In my example getTable() is called every iteration, and it calls another foreach through $allValues, which together might be time-consuming. Consider what you need.</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=control-structures.foreach&amp;redirect=http://php.net/manual/en/control-structures.foreach.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.control-structures.php">Control Structures</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="control-structures.intro.php" title="Introduction">Introduction</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.if.php" title="if">if</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.else.php" title="else">else</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.elseif.php" title="elseif/else if">elseif/else if</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.alternative-syntax.php" title="Alternative syntax for control structures">Alternative syntax for control structures</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.while.php" title="while">while</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.do.while.php" title="do-&#8203;while">do-&#8203;while</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.for.php" title="for">for</a>
                        </li>
                          
                        <li class="current">
                            <a href="control-structures.foreach.php" title="foreach">foreach</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.break.php" title="break">break</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.continue.php" title="continue">continue</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.switch.php" title="switch">switch</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.declare.php" title="declare">declare</a>
                        </li>
                          
                        <li class="">
                            <a href="function.return.php" title="return">return</a>
                        </li>
                          
                        <li class="">
                            <a href="function.require.php" title="require">require</a>
                        </li>
                          
                        <li class="">
                            <a href="function.include.php" title="include">include</a>
                        </li>
                          
                        <li class="">
                            <a href="function.require-once.php" title="require_&#8203;once">require_&#8203;once</a>
                        </li>
                          
                        <li class="">
                            <a href="function.include-once.php" title="include_&#8203;once">include_&#8203;once</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.goto.php" title="goto">goto</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

