<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: $_SERVER - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/reserved.variables.server.php">
 <link rel="shorturl" href="http://php.net/manual/en/reserved.variables.server.php">
 <link rel="alternate" href="http://php.net/manual/en/reserved.variables.server.php" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/reserved.variables.php">
 <link rel="prev" href="http://php.net/manual/en/reserved.variables.globals.php">
 <link rel="next" href="http://php.net/manual/en/reserved.variables.get.php">

 <link rel="alternate" href="http://php.net/manual/en/reserved.variables.server.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/reserved.variables.server.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/reserved.variables.server.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/reserved.variables.server.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/reserved.variables.server.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/reserved.variables.server.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/reserved.variables.server.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/reserved.variables.server.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/reserved.variables.server.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/reserved.variables.server.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/reserved.variables.server.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="reserved.variables.get.php">
          $_GET &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="reserved.variables.globals.php">
          &laquo; $GLOBALS        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='reserved.variables.php'>Predefined Variables</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/reserved.variables.server.php' selected="selected">English</option>
            <option value='pt_BR/reserved.variables.server.php'>Brazilian Portuguese</option>
            <option value='zh/reserved.variables.server.php'>Chinese (Simplified)</option>
            <option value='fr/reserved.variables.server.php'>French</option>
            <option value='de/reserved.variables.server.php'>German</option>
            <option value='ja/reserved.variables.server.php'>Japanese</option>
            <option value='ro/reserved.variables.server.php'>Romanian</option>
            <option value='ru/reserved.variables.server.php'>Russian</option>
            <option value='es/reserved.variables.server.php'>Spanish</option>
            <option value='tr/reserved.variables.server.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/reserved.variables.server.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=reserved.variables.server">Report a Bug</a>
    </div>
  </div><div id="reserved.variables.server" class="refentry">
 <div class="refnamediv">
  <h1 class="refname">$_SERVER</h1>
  <h1 class="refname">$HTTP_SERVER_VARS [removed]</h1>
  <p class="verinfo">(PHP 4 &gt;= 4.1.0, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">$_SERVER</span> -- <span class="refname">$HTTP_SERVER_VARS [removed]</span> &mdash; <span class="dc-title">Server and execution environment information</span></p>

 </div>
 
 <div class="refsect1 description" id="refsect1-reserved.variables.server-description">
  <h3 class="title">Description</h3>
  <p class="para">
   <var class="varname"><var class="varname">$_SERVER</var></var> is an array containing information
   such as headers, paths, and script locations. The entries in this
   array are created by the web server. There is no guarantee that
   every web server will provide any of these; servers may omit some,
   or provide others not listed here. That said, a large number of
   these variables are accounted for in the <a href="http://www.faqs.org/rfcs/rfc3875" class="link external">&raquo;&nbsp;CGI/1.1 specification</a>, so you should
   be able to expect those.
  </p>
  <blockquote class="note"><p><strong class="note">Note</strong>: 
   <span class="simpara">
     Prior to PHP 5.4.0, <var class="varname"><var class="varname">$HTTP_SERVER_VARS</var></var> contained the same initial
     information, but was not a <a href="language.variables.superglobals.php" class="link">superglobal</a>.
     (Note that <var class="varname"><var class="varname">$HTTP_SERVER_VARS</var></var> and <var class="varname"><var class="varname">$_SERVER</var></var>
     were different variables and that PHP handled them as such.)
   </span>
  </p></blockquote>
 </div>


 <div class="refsect1 indices" id="refsect1-reserved.variables.server-indices">
  <h3 class="title">Indices</h3>

  <p class="simpara">
   You may or may not find any of the following elements in
   <var class="varname"><var class="varname">$_SERVER</var></var>. Note that few, if any, of these will be
   available (or indeed have any meaning) if running PHP on the
   <a href="features.commandline.php" class="link">command line</a>.
  </p>

  <p class="para">
   <dl>

    
     <dt>
&#039;<var class="varname"><var class="varname">PHP_SELF</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       The filename of the currently executing script, relative to
       the document root. For instance,
       <var class="varname"><var class="varname">$_SERVER['PHP_SELF']</var></var> in a script at the
       address <var class="filename">http://example.com/foo/bar.php</var>
       would be <var class="filename">/foo/bar.php</var>.
       The <a href="language.constants.predefined.php" class="link">__FILE__</a>
       constant contains the full path and filename of the current (i.e.
       included) file.
      </span>
      <span class="simpara">
       If PHP is running as a command-line processor this variable contains
       the script name since PHP 4.3.0. Previously it was not available.
      </span>
     </dd>

    

    
     <dt>
&#039;<a href="reserved.variables.argv.php" class="link">argv</a>&#039;</dt>

     <dd>

      <span class="simpara">
       Array of arguments passed to the script. When the script is
       run on the command line, this gives C-style access to the
       command line parameters. When called via the GET method, this
       will contain the query string.
      </span>
     </dd>

    

    
     <dt>
&#039;<a href="reserved.variables.argc.php" class="link">argc</a>&#039;</dt>

     <dd>

      <span class="simpara">
       Contains the number of command line parameters passed to the
       script (if run on the command line).
      </span>
     </dd>

    

    
     <dt>
&#039;<var class="varname"><var class="varname">GATEWAY_INTERFACE</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       What revision of the CGI specification the server is using;
       i.e. &#039;<em>CGI/1.1</em>&#039;.
      </span>
     </dd>

    

    
     <dt>
&#039;<var class="varname"><var class="varname">SERVER_ADDR</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       The IP address of the server under which the current script is
       executing.
      </span>
     </dd>

    

    
     <dt>
&#039;<var class="varname"><var class="varname">SERVER_NAME</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       The name of the server host under which the current script is
       executing. If the script is running on a virtual host, this
       will be the value defined for that virtual host.
      </span>
      <blockquote class="note"><p><strong class="note">Note</strong>: 
       <span class="simpara">
        Under Apache 2, you must set <em>UseCanonicalName = On</em>
        and <em>ServerName</em>. Otherwise, this value reflects the
        hostname supplied by the client, which can be spoofed.
        It is not safe to rely on this value in security-dependent contexts.
       </span>
      </p></blockquote>
     </dd>

    

    
     <dt>
&#039;<var class="varname"><var class="varname">SERVER_SOFTWARE</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       Server identification string, given in the headers when
       responding to requests.
      </span>
     </dd>

    

    
     <dt>
&#039;<var class="varname"><var class="varname">SERVER_PROTOCOL</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       Name and revision of the information protocol via which the
       page was requested; i.e. &#039;<em>HTTP/1.0</em>&#039;;
      </span>
     </dd>

    
    
    
     <dt>
&#039;<var class="varname"><var class="varname">REQUEST_METHOD</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       Which request method was used to access the page; i.e. &#039;<em>GET</em>&#039;,
       &#039;<em>HEAD</em>&#039;, &#039;<em>POST</em>&#039;, &#039;<em>PUT</em>&#039;.
      </span>
      <blockquote class="note"><p><strong class="note">Note</strong>: 
       <p class="para">
        PHP script is terminated after sending headers (it means after
        producing any output without output buffering) if the request method
        was <em>HEAD</em>.
       </p>
      </p></blockquote>
     </dd>

    

    
     <dt>
&#039;<var class="varname"><var class="varname">REQUEST_TIME</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       The timestamp of the start of the request. Available since PHP 5.1.0.
      </span>
     </dd>

    
    
    
     <dt>
&#039;<var class="varname"><var class="varname">REQUEST_TIME_FLOAT</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       The timestamp of the start of the request, with microsecond precision.
       Available since PHP 5.4.0.
      </span>
     </dd>

    

    
     <dt>
&#039;<var class="varname"><var class="varname">QUERY_STRING</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       The query string, if any, via which the page was accessed.
      </span>
     </dd>

    

    
     <dt>
&#039;<var class="varname"><var class="varname">DOCUMENT_ROOT</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       The document root directory under which the current script is
       executing, as defined in the server&#039;s configuration file.
      </span>
     </dd>

    

    
     <dt>
&#039;<var class="varname"><var class="varname">HTTP_ACCEPT</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       Contents of the <em>Accept:</em> header from the
       current request, if there is one.
      </span>
     </dd>

    

    
     <dt>
&#039;<var class="varname"><var class="varname">HTTP_ACCEPT_CHARSET</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       Contents of the <em>Accept-Charset:</em> header
       from the current request, if there is one. Example:
       &#039;<em>iso-8859-1,*,utf-8</em>&#039;.
      </span>
     </dd>

    

    
     <dt>
&#039;<var class="varname"><var class="varname">HTTP_ACCEPT_ENCODING</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       Contents of the <em>Accept-Encoding:</em> header
       from the current request, if there is one. Example: &#039;<em>gzip</em>&#039;.
      </span>
     </dd>

    
    
    
     <dt>
&#039;<var class="varname"><var class="varname">HTTP_ACCEPT_LANGUAGE</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       Contents of the <em>Accept-Language:</em> header
       from the current request, if there is one. Example: &#039;<em>en</em>&#039;.
      </span>
     </dd>

    
    
    
     <dt>
&#039;<var class="varname"><var class="varname">HTTP_CONNECTION</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       Contents of the <em>Connection:</em> header from
       the current request, if there is one. Example: &#039;<em>Keep-Alive</em>&#039;.
      </span>
     </dd>

    

    
     <dt>
&#039;<var class="varname"><var class="varname">HTTP_HOST</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       Contents of the <em>Host:</em> header from the
       current request, if there is one.
      </span>
     </dd>

    

    
     <dt>
&#039;<var class="varname"><var class="varname">HTTP_REFERER</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       The address of the page (if any) which referred the user
       agent to the current page. This is set by the user agent. Not
       all user agents will set this, and some provide the ability
       to modify <var class="varname"><var class="varname">HTTP_REFERER</var></var> as a feature. In
       short, it cannot really be trusted.
      </span>
     </dd>

    

    
     <dt>
&#039;<var class="varname"><var class="varname">HTTP_USER_AGENT</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       Contents of the <em>User-Agent:</em> header from
       the current request, if there is one. This is a string
       denoting the user agent being which is accessing the page. A
       typical example is: <span class="computeroutput">Mozilla/4.5 [en] (X11; U;
       Linux 2.2.9 i586)</span>. Among other things, you
       can use this value with <span class="function"><a href="function.get-browser.php" class="function">get_browser()</a></span> to
       tailor your page&#039;s output to the capabilities of the user
       agent.
      </span>
     </dd>

    

    
     <dt>
&#039;<var class="varname"><var class="varname">HTTPS</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       Set to a non-empty value if the script was queried through the HTTPS
       protocol.
      </span>
      <blockquote class="note"><p><strong class="note">Note</strong>: 
       <span class="simpara">
        Note that when using ISAPI with IIS, the value will be 
        <em>off</em> if the request was not made through the HTTPS
        protocol.
       </span>
      </p></blockquote>
     </dd>

    

    
     <dt>
&#039;<var class="varname"><var class="varname">REMOTE_ADDR</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       The IP address from which the user is viewing the current
       page.
      </span>
     </dd>

    

    
     <dt>
&#039;<var class="varname"><var class="varname">REMOTE_HOST</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       The Host name from which the user is viewing the current
       page.  The reverse dns lookup is based off the 
       <var class="varname"><var class="varname">REMOTE_ADDR</var></var> of the user.
      </span>
      <blockquote class="note"><p><strong class="note">Note</strong>: 
       <span class="simpara">
        Your web server must be configured to create this variable. For
        example in Apache you&#039;ll need <em>HostnameLookups On</em>
        inside <var class="filename">httpd.conf</var> for it to exist.  See also
        <span class="function"><a href="function.gethostbyaddr.php" class="function">gethostbyaddr()</a></span>.
       </span>
      </p></blockquote>
     </dd>

    

    
     <dt>
&#039;<var class="varname"><var class="varname">REMOTE_PORT</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       The port being used on the user&#039;s machine to communicate with
       the web server.
      </span>
     </dd>

    

    
     <dt>
&#039;<var class="varname"><var class="varname">REMOTE_USER</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
        The authenticated user.
      </span>
     </dd>

    

    
     <dt>
&#039;<var class="varname"><var class="varname">REDIRECT_REMOTE_USER</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
        The authenticated user if the request is internally redirected.
      </span>
     </dd>

    

    
     <dt>
&#039;<var class="varname"><var class="varname">SCRIPT_FILENAME</var></var>&#039;</dt>

     <dd>

      <p class="para">
       The absolute pathname of the currently executing script.
       <blockquote class="note"><p><strong class="note">Note</strong>: 
        <p class="para">
         If a script is executed with the CLI, as a relative path,
         such as <var class="filename">file.php</var> or 
         <var class="filename">../file.php</var>, 
         <var class="varname"><var class="varname">$_SERVER['SCRIPT_FILENAME']</var></var> will 
         contain the relative path specified by the user.
        </p>
       </p></blockquote>
      </p>
     </dd>

    

    
     <dt>
&#039;<var class="varname"><var class="varname">SERVER_ADMIN</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       The value given to the SERVER_ADMIN (for Apache) directive in
       the web server configuration file. If the script is running
       on a virtual host, this will be the value defined for that
       virtual host.
      </span>
     </dd>

    
    
    
     <dt>
&#039;<var class="varname"><var class="varname">SERVER_PORT</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       The port on the server machine being used by the web server
       for communication. For default setups, this will be &#039;<em>80</em>&#039;;
       using SSL, for instance, will change this to whatever your
       defined secure HTTP port is.
      </span>
      <blockquote class="note"><p><strong class="note">Note</strong>: 
       <span class="simpara">
        Under the Apache 2, you must set <em>UseCanonicalName = On</em>, 
        as well as <em>UseCanonicalPhysicalPort = On</em> in order to
        get the physical (real) port, otherwise, this value can be spoofed and it
        may or may not return the physical port value.
        It is not safe to rely on this value in security-dependent contexts.
       </span>
      </p></blockquote>
     </dd>

    

    
     <dt>
&#039;<var class="varname"><var class="varname">SERVER_SIGNATURE</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       String containing the server version and virtual host name
       which are added to server-generated pages, if enabled.
      </span>
     </dd>

    

    
     <dt>
&#039;<var class="varname"><var class="varname">PATH_TRANSLATED</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       Filesystem- (not document root-) based path to the current
       script, after the server has done any virtual-to-real
       mapping.
      </span>
      <blockquote class="note"><p><strong class="note">Note</strong>: 
       <span class="simpara">
        As of PHP 4.3.2, <span class="envar">PATH_TRANSLATED</span> is no longer set 
        implicitly under the Apache 2 <acronym title="Server Application Programming Interface">SAPI</acronym> in contrast 
        to the situation in Apache 1, where it&#039;s set to the same value as 
        the <span class="envar">SCRIPT_FILENAME</span> server variable when it&#039;s not 
        populated by Apache.  This change was made to comply with the 
        <acronym title="Common Gateway Interface">CGI</acronym> specification that 
        <span class="envar">PATH_TRANSLATED</span> should only exist if 
        <span class="envar">PATH_INFO</span> is defined.
       </span>
       <span class="simpara">
        Apache 2 users may use <em>AcceptPathInfo = On</em> inside
        <var class="filename">httpd.conf</var> to define <span class="envar">PATH_INFO</span>.
       </span>
      </p></blockquote>
     </dd>

    

    
     <dt>
&#039;<var class="varname"><var class="varname">SCRIPT_NAME</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       Contains the current script&#039;s path. This is useful for pages
       which need to point to themselves.
       The <a href="language.constants.predefined.php" class="link">__FILE__</a>
       constant contains the full path and filename of the current (i.e.
       included) file.
      </span>
     </dd>

    

    
     <dt>
&#039;<var class="varname"><var class="varname">REQUEST_URI</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       The URI which was given in order to access this page; for
       instance, &#039;<em>/index.html</em>&#039;.
      </span>
     </dd>

    

    
     <dt>
&#039;<var class="varname"><var class="varname">PHP_AUTH_DIGEST</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       When doing Digest HTTP authentication this variable is set 
       to the &#039;Authorization&#039; header sent by the client (which you 
       should then use to make the appropriate validation).
      </span>
     </dd>

    

    
     <dt>
&#039;<var class="varname"><var class="varname">PHP_AUTH_USER</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       When doing HTTP authentication this variable is set to the 
       username provided by the user.
      </span>
     </dd>

    

    
     <dt>
&#039;<var class="varname"><var class="varname">PHP_AUTH_PW</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       When doing HTTP authentication this variable is set to the 
       password provided by the user.
      </span>
     </dd>

    

    
     <dt>
&#039;<var class="varname"><var class="varname">AUTH_TYPE</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       When doing HTTP authentication this variable is set to the 
       authentication type.
      </span>
     </dd>

    

    
     <dt>
&#039;<var class="varname"><var class="varname">PATH_INFO</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       Contains any client-provided pathname information trailing the
       actual script filename but preceding the query string, if
       available. For instance, if the current script was accessed via
       the
       URL <var class="filename">http://www.example.com/php/path_info.php/some/stuff?foo=bar</var>,
       then <var class="varname"><var class="varname">$_SERVER['PATH_INFO']</var></var> would
       contain <em>/some/stuff</em>.
      </span>
     </dd>

    

    
     <dt>
&#039;<var class="varname"><var class="varname">ORIG_PATH_INFO</var></var>&#039;</dt>

     <dd>

      <span class="simpara">
       Original version of &#039;<var class="varname"><var class="varname">PATH_INFO</var></var>&#039; before processed by
       PHP.
      </span>
     </dd>

    

   </dl>

  </p>
 </div>

 
 <div class="refsect1 changelog" id="refsect1-reserved.variables.server-changelog">
  <h3 class="title">Changelog</h3>
  <p class="para">
   <table class="doctable informaltable">
    
     <thead>
      <tr>
       <th>Version</th>
       <th>Description</th>
      </tr>

     </thead>

     <tbody class="tbody">
      <tr>
       <td>5.4.0</td>
       <td>
        <var class="varname"><var class="varname">$HTTP_SERVER_VARS</var></var> isn&#039;t available anymore due to
        the removal of long arrays registering.
       </td>
      </tr>

      <tr>
       <td>5.3.0</td>
       <td>
        Directive <a href="ini.core.php#ini.register-long-arrays" class="link">register_long_arrays</a>
        which caused <var class="varname"><var class="varname">$HTTP_SERVER_VARS</var></var> to be available has been
        deprecated.
       </td>
      </tr>

      <tr>
       <td>4.1.0</td>
       <td>
        Introduced <var class="varname"><var class="varname">$_SERVER</var></var> that deprecated
        <var class="varname"><var class="varname">$HTTP_SERVER_VARS</var></var>.
       </td>
      </tr>

     </tbody>
    
   </table>

  </p>
 </div>

 
 <div class="refsect1 examples" id="refsect1-reserved.variables.server-examples">
  <h3 class="title">Examples</h3>
  <p class="para">
   <div class="example" id="example-296">
    <p><strong>Example #1 <var class="varname"><var class="varname">$_SERVER</var></var> example</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #0000BB">$_SERVER</span><span style="color: #007700">[</span><span style="color: #DD0000">'SERVER_NAME'</span><span style="color: #007700">];<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

    <div class="example-contents"><p>The above example will output
something similar to:</p></div>
    <div class="example-contents screen">
<div class="cdata"><pre>
www.example.com
</pre></div>
    </div>
   </div>
  </p>
 </div>

 
 <div class="refsect1 notes" id="refsect1-reserved.variables.server-notes">
  <h3 class="title">Notes</h3>
  <blockquote class="note"><p><strong class="note">Note</strong>: <p class="para">This is a &#039;superglobal&#039;, or
automatic global, variable. This simply means that it is available in
all scopes throughout a script. There is no need to do
<strong class="command">global $variable;</strong> to access it within functions or methods.
</p></p></blockquote>
 </div>


 <div class="refsect1 seealso" id="refsect1-reserved.variables.server-seealso">
  <h3 class="title">See Also</h3>
  <p class="para">
   <ul class="simplelist">
    <li class="member"><a href="book.filter.php" class="link">The filter extension</a></li>
   </ul>
  </p>
 </div>


</div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=reserved.variables.server&amp;redirect=http://php.net/manual/en/reserved.variables.server.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">63 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="111471">  <div class="votes">
    <div id="Vu111471">
    <a href="/manual/vote-note.php?id=111471&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd111471">
    <a href="/manual/vote-note.php?id=111471&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V111471" title="72% like this...">
    258
    </div>
  </div>
  <a href="#111471" class="name">
  <strong class="user"><em>zeufonlinux at gmail dot com</em></strong></a><a class="genanchor" href="#111471"> &para;</a><div class="date" title="2013-02-22 02:24"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom111471">
<div class="phpcode"><code><span class="html">
Just a PHP file to put on your local server (as I don't have enough memory)<br /><br /> <span class="default">&lt;?php<br /> $indicesServer </span><span class="keyword">= array(</span><span class="string">'PHP_SELF'</span><span class="keyword">,<br /></span><span class="string">'argv'</span><span class="keyword">,<br /></span><span class="string">'argc'</span><span class="keyword">,<br /></span><span class="string">'GATEWAY_INTERFACE'</span><span class="keyword">,<br /></span><span class="string">'SERVER_ADDR'</span><span class="keyword">,<br /></span><span class="string">'SERVER_NAME'</span><span class="keyword">,<br /></span><span class="string">'SERVER_SOFTWARE'</span><span class="keyword">,<br /></span><span class="string">'SERVER_PROTOCOL'</span><span class="keyword">,<br /></span><span class="string">'REQUEST_METHOD'</span><span class="keyword">,<br /></span><span class="string">'REQUEST_TIME'</span><span class="keyword">,<br /></span><span class="string">'REQUEST_TIME_FLOAT'</span><span class="keyword">,<br /></span><span class="string">'QUERY_STRING'</span><span class="keyword">,<br /></span><span class="string">'DOCUMENT_ROOT'</span><span class="keyword">,<br /></span><span class="string">'HTTP_ACCEPT'</span><span class="keyword">,<br /></span><span class="string">'HTTP_ACCEPT_CHARSET'</span><span class="keyword">,<br /></span><span class="string">'HTTP_ACCEPT_ENCODING'</span><span class="keyword">,<br /></span><span class="string">'HTTP_ACCEPT_LANGUAGE'</span><span class="keyword">,<br /></span><span class="string">'HTTP_CONNECTION'</span><span class="keyword">,<br /></span><span class="string">'HTTP_HOST'</span><span class="keyword">,<br /></span><span class="string">'HTTP_REFERER'</span><span class="keyword">,<br /></span><span class="string">'HTTP_USER_AGENT'</span><span class="keyword">,<br /></span><span class="string">'HTTPS'</span><span class="keyword">,<br /></span><span class="string">'REMOTE_ADDR'</span><span class="keyword">,<br /></span><span class="string">'REMOTE_HOST'</span><span class="keyword">,<br /></span><span class="string">'REMOTE_PORT'</span><span class="keyword">,<br /></span><span class="string">'REMOTE_USER'</span><span class="keyword">,<br /></span><span class="string">'REDIRECT_REMOTE_USER'</span><span class="keyword">,<br /></span><span class="string">'SCRIPT_FILENAME'</span><span class="keyword">,<br /></span><span class="string">'SERVER_ADMIN'</span><span class="keyword">,<br /></span><span class="string">'SERVER_PORT'</span><span class="keyword">,<br /></span><span class="string">'SERVER_SIGNATURE'</span><span class="keyword">,<br /></span><span class="string">'PATH_TRANSLATED'</span><span class="keyword">,<br /></span><span class="string">'SCRIPT_NAME'</span><span class="keyword">,<br /></span><span class="string">'REQUEST_URI'</span><span class="keyword">,<br /></span><span class="string">'PHP_AUTH_DIGEST'</span><span class="keyword">,<br /></span><span class="string">'PHP_AUTH_USER'</span><span class="keyword">,<br /></span><span class="string">'PHP_AUTH_PW'</span><span class="keyword">,<br /></span><span class="string">'AUTH_TYPE'</span><span class="keyword">,<br /></span><span class="string">'PATH_INFO'</span><span class="keyword">,<br /></span><span class="string">'ORIG_PATH_INFO'</span><span class="keyword">) ;<br /><br />echo </span><span class="string">'&lt;table cellpadding="10"&gt;' </span><span class="keyword">;<br />foreach (</span><span class="default">$indicesServer </span><span class="keyword">as </span><span class="default">$arg</span><span class="keyword">) {<br />&nbsp; &nbsp; if (isset(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="default">$arg</span><span class="keyword">])) {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'&lt;tr&gt;&lt;td&gt;'</span><span class="keyword">.</span><span class="default">$arg</span><span class="keyword">.</span><span class="string">'&lt;/td&gt;&lt;td&gt;' </span><span class="keyword">. </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="default">$arg</span><span class="keyword">] . </span><span class="string">'&lt;/td&gt;&lt;/tr&gt;' </span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; else {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'&lt;tr&gt;&lt;td&gt;'</span><span class="keyword">.</span><span class="default">$arg</span><span class="keyword">.</span><span class="string">'&lt;/td&gt;&lt;td&gt;-&lt;/td&gt;&lt;/tr&gt;' </span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br />echo </span><span class="string">'&lt;/table&gt;' </span><span class="keyword">;<br /><br /></span><span class="comment">/*<br /><br />That will give you the result of each variable like (if the file is server_indices.php at the root and Apache Web directory is in E:\web) : <br /><br />PHP_SELF&nbsp; &nbsp; /server_indices.php<br />argv&nbsp; &nbsp; -<br />argc&nbsp; &nbsp; -<br />GATEWAY_INTERFACE&nbsp; &nbsp; CGI/1.1<br />SERVER_ADDR&nbsp; &nbsp; 127.0.0.1<br />SERVER_NAME&nbsp; &nbsp; localhost<br />SERVER_SOFTWARE&nbsp; &nbsp; Apache/2.2.22 (Win64) PHP/5.3.13<br />SERVER_PROTOCOL&nbsp; &nbsp; HTTP/1.1<br />REQUEST_METHOD&nbsp; &nbsp; GET<br />REQUEST_TIME&nbsp; &nbsp; 1361542579<br />REQUEST_TIME_FLOAT&nbsp; &nbsp; -<br />QUERY_STRING&nbsp; &nbsp; <br />DOCUMENT_ROOT&nbsp; &nbsp; E:/web/<br />HTTP_ACCEPT&nbsp; &nbsp; text/html,application/xhtml+xml,application/xml;q=0.9,*/</span><span class="keyword">*;</span><span class="default">q</span><span class="keyword">=</span><span class="default">0.8<br />HTTP_ACCEPT_CHARSET&nbsp; &nbsp; ISO</span><span class="keyword">-</span><span class="default">8859</span><span class="keyword">-</span><span class="default">1</span><span class="keyword">,</span><span class="default">utf</span><span class="keyword">-</span><span class="default">8</span><span class="keyword">;</span><span class="default">q</span><span class="keyword">=</span><span class="default">0.7</span><span class="keyword">,*;</span><span class="default">q</span><span class="keyword">=</span><span class="default">0.3<br />HTTP_ACCEPT_ENCODING&nbsp; &nbsp; gzip</span><span class="keyword">,</span><span class="default">deflate</span><span class="keyword">,</span><span class="default">sdch<br />HTTP_ACCEPT_LANGUAGE&nbsp; &nbsp; fr</span><span class="keyword">-</span><span class="default">FR</span><span class="keyword">,</span><span class="default">fr</span><span class="keyword">;</span><span class="default">q</span><span class="keyword">=</span><span class="default">0.8</span><span class="keyword">,</span><span class="default">en</span><span class="keyword">-</span><span class="default">US</span><span class="keyword">;</span><span class="default">q</span><span class="keyword">=</span><span class="default">0.6</span><span class="keyword">,</span><span class="default">en</span><span class="keyword">;</span><span class="default">q</span><span class="keyword">=</span><span class="default">0.4<br />HTTP_CONNECTION&nbsp; &nbsp; keep</span><span class="keyword">-</span><span class="default">alive<br />HTTP_HOST&nbsp; &nbsp; localhost<br />HTTP_REFERER&nbsp; &nbsp; http</span><span class="keyword">:</span><span class="comment">//localhost/<br /></span><span class="default">HTTP_USER_AGENT&nbsp; &nbsp; Mozilla</span><span class="keyword">/</span><span class="default">5.0 </span><span class="keyword">(</span><span class="default">Windows NT 6.1</span><span class="keyword">; </span><span class="default">WOW64</span><span class="keyword">) </span><span class="default">AppleWebKit</span><span class="keyword">/</span><span class="default">537.17 </span><span class="keyword">(</span><span class="default">KHTML</span><span class="keyword">, </span><span class="default">like Gecko</span><span class="keyword">) </span><span class="default">Chrome</span><span class="keyword">/</span><span class="default">24.0.1312.57 Safari</span><span class="keyword">/</span><span class="default">537.17<br />HTTPS&nbsp; &nbsp; </span><span class="keyword">-<br /></span><span class="default">REMOTE_ADDR&nbsp; &nbsp; 127.0.0.1<br />REMOTE_HOST&nbsp; &nbsp; </span><span class="keyword">-<br /></span><span class="default">REMOTE_PORT&nbsp; &nbsp; 65037<br />REMOTE_USER&nbsp; &nbsp; </span><span class="keyword">-<br /></span><span class="default">REDIRECT_REMOTE_USER&nbsp; &nbsp; </span><span class="keyword">-<br /></span><span class="default">SCRIPT_FILENAME&nbsp; &nbsp; E</span><span class="keyword">:/</span><span class="default">web</span><span class="keyword">/</span><span class="default">server_indices</span><span class="keyword">.</span><span class="default">php<br />SERVER_ADMIN&nbsp; &nbsp; myemail</span><span class="keyword">@</span><span class="default">personal</span><span class="keyword">.</span><span class="default">us<br />SERVER_PORT&nbsp; &nbsp; 80<br />SERVER_SIGNATURE&nbsp; &nbsp; <br />PATH_TRANSLATED&nbsp; &nbsp; </span><span class="keyword">-<br /></span><span class="default">SCRIPT_NAME&nbsp; &nbsp; </span><span class="keyword">/</span><span class="default">server_indices</span><span class="keyword">.</span><span class="default">php<br />REQUEST_URI&nbsp; &nbsp; </span><span class="keyword">/</span><span class="default">server_indices</span><span class="keyword">.</span><span class="default">php<br />PHP_AUTH_DIGEST&nbsp; &nbsp; </span><span class="keyword">-<br /></span><span class="default">PHP_AUTH_USER&nbsp; &nbsp; </span><span class="keyword">-<br /></span><span class="default">PHP_AUTH_PW&nbsp; &nbsp; </span><span class="keyword">-<br /></span><span class="default">AUTH_TYPE&nbsp; &nbsp; </span><span class="keyword">-<br /></span><span class="default">PATH_INFO&nbsp; &nbsp; </span><span class="keyword">-<br /></span><span class="default">ORIG_PATH_INFO&nbsp; &nbsp; </span><span class="keyword">-<br /><br />*/<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="89567">  <div class="votes">
    <div id="Vu89567">
    <a href="/manual/vote-note.php?id=89567&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd89567">
    <a href="/manual/vote-note.php?id=89567&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V89567" title="69% like this...">
    78
    </div>
  </div>
  <a href="#89567" class="name">
  <strong class="user"><em>Vladimir Kornea</em></strong></a><a class="genanchor" href="#89567"> &para;</a><div class="date" title="2009-03-13 05:06"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom89567">
<div class="phpcode"><code><span class="html">
1. All elements of the $_SERVER array whose keys begin with 'HTTP_' come from HTTP request headers and are not to be trusted.<br /><br />2. All HTTP headers sent to the script are made available through the $_SERVER array, with names prefixed by 'HTTP_'.<br /><br />3. $_SERVER['PHP_SELF'] is dangerous if misused. If login.php/nearly_arbitrary_string is requested, $_SERVER['PHP_SELF'] will contain not just login.php, but the entire login.php/nearly_arbitrary_string. If you've printed $_SERVER['PHP_SELF'] as the value of the action attribute of your form tag without performing HTML encoding, an attacker can perform XSS attacks by offering users a link to your site such as this:<br /><br />&lt;a href='<a href="http://www.example.com/login.php/" rel="nofollow" target="_blank">http://www.example.com/login.php/</a>"&gt;&lt;script type="text/javascript"&gt;...&lt;/script&gt;&lt;span a="'&gt;Example.com&lt;/a&gt;<br /><br />The javascript block would define an event handler function and bind it to the form's submit event. This event handler would load via an &lt;img&gt; tag an external file, with the submitted username and password as parameters.<br /><br />Use $_SERVER['SCRIPT_NAME'] instead of $_SERVER['PHP_SELF']. HTML encode every string sent to the browser that should not be interpreted as HTML, unless you are absolutely certain that it cannot contain anything that the browser can interpret as HTML.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121469">  <div class="votes">
    <div id="Vu121469">
    <a href="/manual/vote-note.php?id=121469&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121469">
    <a href="/manual/vote-note.php?id=121469&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121469" title="75% like this...">
    2
    </div>
  </div>
  <a href="#121469" class="name">
  <strong class="user"><em>ywarnier at beeznest dot org</em></strong></a><a class="genanchor" href="#121469"> &para;</a><div class="date" title="2017-08-02 08:35"><strong>4 months ago</strong></div>
  <div class="text" id="Hcom121469">
<div class="phpcode"><code><span class="html">
Note that $_SERVER['REQUEST_URI'] might include the scheme and domain in certain cases.<br /><br />This happens, for example, when calling the page through a call to stream_context_create() with a HTTP header of 'request_fulluri' set to 1.<br /><br />For example:<br /><br />$http = ['request_fulluri' =&gt; 1, /* other params here */];<br />$context = stream_context_create(array( 'http' =&gt; $http ));<br />$fp = fopen($some_url, 'rb', false, $context);<br /><br />When outputting $_SERVER['REQUEST_URI'] on the server at $some_url, you will get<br /><a href="https://some_url/some_script.php" rel="nofollow" target="_blank">https://some_url/some_script.php</a><br /><br />Remove the request_fulluri =&gt; 1 option, and $_SERVER['REQUEST_URI'] gets back to its "normal":<br />/some_script.php<br /><br />Apparently, request_fulluri is useful when using some proxy servers.<br /><br />In this case, there is no proper way to "detect" if this option was set or not, and you should probably use a combination of other $_SERVER[] elements (like REQUEST_SCHEME, SERVER_NAME and SERVER_PORT) to determine if this was the case.<br /><br />One quick (and improvable) way to detect it would be to compare the start of the REQUEST_URI with REQUEST_SCHEME:<br /><br />$scheme = $_SERVER['REQUEST_SCHEME'] . '://';<br />if (strcmp(substr($_SERVER['REQUEST_URI'], 0, strlen($scheme)), $scheme) === 0) {<br />&nbsp; &nbsp; // request_fulluri was set<br />}</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121008">  <div class="votes">
    <div id="Vu121008">
    <a href="/manual/vote-note.php?id=121008&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121008">
    <a href="/manual/vote-note.php?id=121008&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121008" title="70% like this...">
    4
    </div>
  </div>
  <a href="#121008" class="name">
  <strong class="user"><em>pierstoval at example dot com</em></strong></a><a class="genanchor" href="#121008"> &para;</a><div class="date" title="2017-04-22 10:13"><strong>7 months ago</strong></div>
  <div class="text" id="Hcom121008">
<div class="phpcode"><code><span class="html">
As PHP $_SERVER var is populated with a lot of vars, I think it's important to say that it's also populated with environment vars.<br /><br />For example, with a PHP script, we can have this:<br /><br />&nbsp; &nbsp; MY_ENV_VAR=Hello php -r 'echo $_SERVER["MY_ENV_VAR"];'<br />&nbsp; &nbsp; <br />Will show "Hello".<br /><br />But, internally, PHP makes sure that "internal" keys in $_SERVER are not overriden, so you wouldn't be able to do something like this:<br /><br />&nbsp; &nbsp; REQUEST_TIME=Hello php -r 'var_dump($_SERVER["REQUEST_TIME"]);'<br />&nbsp; &nbsp; <br />Will show something like 1492897785<br /><br />However, a lot of vars are still vulnerable from environment injection.<br /><br />I created a gist here ( <a href="https://gist.github.com/Pierstoval/f287d3e61252e791a943dd73874ab5ee" rel="nofollow" target="_blank">https://gist.github.com/Pierstoval/f287d3e61252e791a943dd73874ab5ee</a> ) with my PHP configuration on windows with PHP7.0.15 on WSL with bash, the results are that the only "safe" vars are the following:<br /><br />PHP_SELF<br />SCRIPT_NAME<br />SCRIPT_FILENAME<br />PATH_TRANSLATED<br />DOCUMENT_ROOT<br />REQUEST_TIME_FLOAT<br />REQUEST_TIME<br />argv<br />argc<br /><br />All the rest can be overriden with environment vars, which is not very cool actually because it can break PHP applications sometimes...<br /><br />(and I only tested on CLI, I had no patience to test with Apache mod_php or Nginx + PHP-FPM, but I can imagine that not a lot of $_SERVER properties are "that" secure...)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="94070">  <div class="votes">
    <div id="Vu94070">
    <a href="/manual/vote-note.php?id=94070&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd94070">
    <a href="/manual/vote-note.php?id=94070&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V94070" title="65% like this...">
    36
    </div>
  </div>
  <a href="#94070" class="name">
  <strong class="user"><em>Lord Mac</em></strong></a><a class="genanchor" href="#94070"> &para;</a><div class="date" title="2009-10-14 07:56"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom94070">
<div class="phpcode"><code><span class="html">
An even *more* improved version...<br /><br /><span class="default">&lt;?php<br />phpinfo</span><span class="keyword">(</span><span class="default">32</span><span class="keyword">);<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120980">  <div class="votes">
    <div id="Vu120980">
    <a href="/manual/vote-note.php?id=120980&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120980">
    <a href="/manual/vote-note.php?id=120980&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120980" title="66% like this...">
    3
    </div>
  </div>
  <a href="#120980" class="name">
  <strong class="user"><em>chris at ocproducts dot com</em></strong></a><a class="genanchor" href="#120980"> &para;</a><div class="date" title="2017-04-12 11:44"><strong>8 months ago</strong></div>
  <div class="text" id="Hcom120980">
<div class="phpcode"><code><span class="html">
Guide to script parameters...<br /><br />Data: $_GET<br />Data type: Array (map)<br />Purpose: Contains all GET parameters (i.e. a parsed URL query string).<br />Caveat: GET parameter names have to be compliant with PHP variable naming, e.g. dots are not allowed and get substituted.<br />Works on web mode: Yes<br />Works on CLI mode: No<br /><br />Data: $_SERVER['QUERY_STRING']<br />Data type: String<br />Purpose: Gets an unparsed URL query string.<br />Caveat: Not set on all PHP environments, may need setting via http_build_query($_GET).<br />Works on web mode: Yes<br />Works on CLI mode: No<br /><br />Data: $_SERVER['argv']<br />Data type: Array (list)<br />Purpose: Get CLI call parameters.<br />Works on web mode: Tenuous (just contains a single parameter, the query string)<br />Works on CLI mode: Yes</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120979">  <div class="votes">
    <div id="Vu120979">
    <a href="/manual/vote-note.php?id=120979&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120979">
    <a href="/manual/vote-note.php?id=120979&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120979" title="63% like this...">
    3
    </div>
  </div>
  <a href="#120979" class="name">
  <strong class="user"><em>chris at ocproducts dot com</em></strong></a><a class="genanchor" href="#120979"> &para;</a><div class="date" title="2017-04-12 11:44"><strong>8 months ago</strong></div>
  <div class="text" id="Hcom120979">
<div class="phpcode"><code><span class="html">
Guide to URL paths...<br /><br />Data: $_SERVER['PHP_SELF']<br />Data type: String<br />Purpose: The URL path name of the current PHP file, including path-info (see $_SERVER['PATH_INFO']) and excluding URL query string. Includes leading slash.<br />Caveat: This is after URL rewrites (i.e. it's as seen by PHP, not necessarily the original call URL).<br />Works on web mode: Yes<br />Works on CLI mode: Tenuous (emulated to contain just the exact call path of the CLI script, with whatever exotic relative pathname you may call with, not made absolute and not normalised or pre-resolved)<br /><br />Data: $_SERVER['SCRIPT_NAME']<br />Data type: String<br />Purpose: The URL path name of the current PHP file, excluding path-info and excluding URL query string. Includes leading slash.<br />Caveat: This is after URL rewrites (i.e. it's as seen by PHP, not necessarily the original call URL).<br />Caveat: Not set on all PHP environments, may need setting via preg_replace('#\.php/.*#', '.php', $_SERVER['PHP_SELF']).<br />Works on web mode: Yes<br />Works on CLI mode: Tenuous (emulated to contain just the exact call path of the CLI script, with whatever exotic relative pathname you may call with, not made absolute and not normalised or pre-resolved)<br /><br />Data: $_SERVER['REDIRECT_URL']<br />Data type: String<br />Purpose: The URL path name of the current PHP file, path-info is N/A and excluding URL query string. Includes leading slash.<br />Caveat: This is before URL rewrites (i.e. it's as per the original call URL).<br />Caveat: Not set on all PHP environments, and definitely only ones with URL rewrites.<br />Works on web mode: Yes<br />Works on CLI mode: No<br /><br />Data: $_SERVER['REQUEST_URI']<br />Data type: String<br />Purpose: The URL path name of the current PHP file, including path-info and including URL query string. Includes leading slash.<br />Caveat: This is before URL rewrites (i.e. it's as per the original call URL). *<br />*: I've seen at least one situation where this is not true (there was another $_SERVER variable to use instead supplied by the URL rewriter), but the author of the URL rewriter later fixed it so probably fair to dismiss this particular note.<br />Caveat: Not set on all PHP environments, may need setting via $_SERVER['REDIRECT_URL'] . '?' . http_build_query($_GET) [if $_SERVER['REDIRECT_URL'] is set, and imperfect as we don't know what GET parameters were originally passed vs which were injected in the URL rewrite] --otherwise-- $_SERVER['PHP_SELF'] . '?' . http_build_query($_GET).<br />Works on web mode: Yes<br />Works on CLI mode: No<br /><br />Data: $_SERVER['PATH_INFO']<br />Data type: String<br />Purpose: Find the path-info, which is data after the .php filename in the URL call. It's a strange concept.<br />Caveat: Some environments may not support it, it is best avoided unless you have complete server control<br />Works on web mode: Yes<br />Works on CLI mode: No<br /><br />Note that if something is not set it may be missing from $_SERVER, or it may be blank, so use PHP's 'empty' function for your test.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120978">  <div class="votes">
    <div id="Vu120978">
    <a href="/manual/vote-note.php?id=120978&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120978">
    <a href="/manual/vote-note.php?id=120978&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120978" title="63% like this...">
    3
    </div>
  </div>
  <a href="#120978" class="name">
  <strong class="user"><em>chris at ocproducts dot com</em></strong></a><a class="genanchor" href="#120978"> &para;</a><div class="date" title="2017-04-12 11:44"><strong>8 months ago</strong></div>
  <div class="text" id="Hcom120978">
<div class="phpcode"><code><span class="html">
Guide to absolute paths...<br /><br />Data: __FILE__<br />Data type: String<br />Purpose: The absolute pathname of the running PHP file, including the filename.<br />Caveat: This is not the file called by the PHP processor, it's what is running. So if you are inside an include, it's the include.<br />Caveat: Symbolic links are pre-resolved, so don't trust comparison of paths to be accurate.<br />Caveat: Don't assume all operating systems use '/' for the directory separator.<br />Works on web mode: Yes<br />Works on CLI mode: Yes<br /><br />Data: __DIR__<br />Data type: String<br />Purpose: The absolute pathname to the running PHP file, excluding the filename<br />Caveat: This is not the file called by the PHP processor, it's what is running. So if you are inside an include, it's the include.<br />Caveat: Symbolic links are pre-resolved, so don't trust comparison of paths to be accurate.<br />Caveat: Don't assume all operating systems use '/' for the directory separator.<br />Works on web mode: Yes<br />Works on CLI mode: Yes<br /><br />Data: $_SERVER['SCRIPT_FILENAME']<br />Data type: String<br />Purpose: The absolute pathname of the origin PHP file, including the filename<br />Caveat: Not set on all PHP environments, may need setting by copying from __FILE__ before other files are included.<br />Caveat: Symbolic links are not pre-resolved, use PHP's 'realpath' function if you need it resolved.<br />Caveat: Don't assume all operating systems use '/' for the directory separator.<br />Caveat: "Filename" makes you think it is just a filename, but it really is the full absolute pathname. Read the identifier as "Script's filesystem (path)name".<br />Works on web mode: Yes<br />Works on CLI mode: Yes<br /><br />Data: $_SERVER['PATH_TRANSLATED']<br />Data type: String<br />Purpose: The absolute pathname of the origin PHP file, including the filename<br />Caveat: It's probably not set, best to just not use it. Just use realpath($_SERVER['SCRIPT_FILENAME']) (and be aware that itself may need to have been emulated).<br />Caveat: Symbolic links are pre-resolved, so don't trust comparison of paths to be accurate.<br />Caveat: Don't assume all operating systems use '/' for the directory separator.<br />Works on web mode: Yes<br />Works on CLI mode: No<br /><br />Data: $_SERVER['DOCUMENT_ROOT']<br />Data type: String<br />Purpose: Get the absolute path to the web server's document root. No trailing slash.<br />Caveat: Don't trust this to be set, or set correctly, unless you control the server environment.<br />Caveat: May or may not have symbolic links pre-resolved, use PHP's 'realpath' function if you need it resolved.<br />Caveat: Don't assume all operating systems use '/' for the directory separator.<br />Works on web mode: Yes<br />Works on CLI mode: No<br /><br />Note that if something is not set it may be missing from $_SERVER, or it may be blank, so use PHP's 'empty' function for your test.<br /><br />Note that if you call "php --info" on the command line then naturally some of these settings are going to be blank, as no PHP file is involved.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="85759">  <div class="votes">
    <div id="Vu85759">
    <a href="/manual/vote-note.php?id=85759&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd85759">
    <a href="/manual/vote-note.php?id=85759&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V85759" title="62% like this...">
    10
    </div>
  </div>
  <a href="#85759" class="name">
  <strong class="user"><em>Tonin</em></strong></a><a class="genanchor" href="#85759"> &para;</a><div class="date" title="2008-09-16 10:43"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom85759">
<div class="phpcode"><code><span class="html">
When using the $_SERVER['SERVER_NAME'] variable in an apache virtual host setup with a ServerAlias directive, be sure to check the UseCanonicalName apache directive.&nbsp; If it is On, this variable will always have the apache ServerName value.&nbsp; If it is Off, it will have the value given by the headers sent by the browser.<br /><br />Depending on what you want to do the content of this variable, put in On or Off.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="109961">  <div class="votes">
    <div id="Vu109961">
    <a href="/manual/vote-note.php?id=109961&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd109961">
    <a href="/manual/vote-note.php?id=109961&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V109961" title="60% like this...">
    10
    </div>
  </div>
  <a href="#109961" class="name">
  <strong class="user"><em>Tom</em></strong></a><a class="genanchor" href="#109961"> &para;</a><div class="date" title="2012-09-06 08:28"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom109961">
<div class="phpcode"><code><span class="html">
Be warned that most contents of the Server-Array (even $_SERVER['SERVER_NAME']) are provided by the client and can be manipulated. They can also be used for injections and thus MUST be checked and treated like any other user input.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="93599">  <div class="votes">
    <div id="Vu93599">
    <a href="/manual/vote-note.php?id=93599&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd93599">
    <a href="/manual/vote-note.php?id=93599&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V93599" title="59% like this...">
    19
    </div>
  </div>
  <a href="#93599" class="name">
  <strong class="user"><em>steve at sc-fa dot com</em></strong></a><a class="genanchor" href="#93599"> &para;</a><div class="date" title="2009-09-17 12:20"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom93599">
<div class="phpcode"><code><span class="html">
If you are serving from behind a proxy server, you will almost certainly save time by looking at what these $_SERVER variables do on your machine behind the proxy.&nbsp;&nbsp; <br /><br />$_SERVER['HTTP_X_FORWARDED_FOR'] in place of $_SERVER['REMOTE_ADDR']<br /><br />$_SERVER['HTTP_X_FORWARDED_HOST'] and <br />$_SERVER['HTTP_X_FORWARDED_SERVER'] in place of (at least in our case,) $_SERVER['SERVER_NAME']</span>
</code></div>
  </div>
 </div>
  <div class="note" id="87195">  <div class="votes">
    <div id="Vu87195">
    <a href="/manual/vote-note.php?id=87195&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd87195">
    <a href="/manual/vote-note.php?id=87195&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V87195" title="59% like this...">
    11
    </div>
  </div>
  <a href="#87195" class="name">
  <strong class="user"><em>jonbarnett at gmail dot com</em></strong></a><a class="genanchor" href="#87195"> &para;</a><div class="date" title="2008-11-23 09:13"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom87195">
<div class="phpcode"><code><span class="html">
It's worth noting that $_SERVER variables get created for any HTTP request headers, including those you might invent:<br /><br />If the browser sends an HTTP request header of:<br />X-Debug-Custom: some string<br /><br />Then:<br /><br /><span class="default">&lt;?php<br />$_SERVER</span><span class="keyword">[</span><span class="string">'HTTP_X_DEBUG_CUSTOM'</span><span class="keyword">]; </span><span class="comment">// "some string"<br /></span><span class="default">?&gt;<br /></span><br />There are better ways to identify the HTTP request headers sent by the browser, but this is convenient if you know what to expect from, for example, an AJAX script with custom headers.<br /><br />Works in PHP5 on Apache with mod_php.&nbsp; Don't know if this is true from other environments.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="92121">  <div class="votes">
    <div id="Vu92121">
    <a href="/manual/vote-note.php?id=92121&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd92121">
    <a href="/manual/vote-note.php?id=92121&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V92121" title="58% like this...">
    12
    </div>
  </div>
  <a href="#92121" class="name">
  <strong class="user"><em>Richard York</em></strong></a><a class="genanchor" href="#92121"> &para;</a><div class="date" title="2009-07-09 11:19"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom92121">
<div class="phpcode"><code><span class="html">
Not documented here is the fact that $_SERVER is populated with some pretty useful information when accessing PHP via the shell.<br /><br /> ["_SERVER"]=&gt;<br />&nbsp; array(24) {<br />&nbsp; &nbsp; ["MANPATH"]=&gt;<br />&nbsp; &nbsp; string(48) "/usr/share/man:/usr/local/share/man:/usr/X11/man"<br />&nbsp; &nbsp; ["TERM"]=&gt;<br />&nbsp; &nbsp; string(11) "xterm-color"<br />&nbsp; &nbsp; ["SHELL"]=&gt;<br />&nbsp; &nbsp; string(9) "/bin/bash"<br />&nbsp; &nbsp; ["SSH_CLIENT"]=&gt;<br />&nbsp; &nbsp; string(20) "127.0.0.1 41242 22"<br />&nbsp; &nbsp; ["OLDPWD"]=&gt;<br />&nbsp; &nbsp; string(60) "/Library/WebServer/Domains/www.example.com/private"<br />&nbsp; &nbsp; ["SSH_TTY"]=&gt;<br />&nbsp; &nbsp; string(12) "/dev/ttys000"<br />&nbsp; &nbsp; ["USER"]=&gt;<br />&nbsp; &nbsp; string(5) "username"<br />&nbsp; &nbsp; ["MAIL"]=&gt;<br />&nbsp; &nbsp; string(15) "/var/mail/username"<br />&nbsp; &nbsp; ["PATH"]=&gt;<br />&nbsp; &nbsp; string(57) "/usr/bin:/bin:/usr/sbin:/sbin:/usr/local/bin:/usr/X11/bin"<br />&nbsp; &nbsp; ["PWD"]=&gt;<br />&nbsp; &nbsp; string(56) "/Library/WebServer/Domains/www.example.com/www"<br />&nbsp; &nbsp; ["SHLVL"]=&gt;<br />&nbsp; &nbsp; string(1) "1"<br />&nbsp; &nbsp; ["HOME"]=&gt;<br />&nbsp; &nbsp; string(12) "/Users/username"<br />&nbsp; &nbsp; ["LOGNAME"]=&gt;<br />&nbsp; &nbsp; string(5) "username"<br />&nbsp; &nbsp; ["SSH_CONNECTION"]=&gt;<br />&nbsp; &nbsp; string(31) "127.0.0.1 41242 10.0.0.1 22"<br />&nbsp; &nbsp; ["_"]=&gt;<br />&nbsp; &nbsp; string(12) "/usr/bin/php"<br />&nbsp; &nbsp; ["__CF_USER_TEXT_ENCODING"]=&gt;<br />&nbsp; &nbsp; string(9) "0x1F5:0:0"<br />&nbsp; &nbsp; ["PHP_SELF"]=&gt;<br />&nbsp; &nbsp; string(10) "Shell.php"<br />&nbsp; &nbsp; ["SCRIPT_NAME"]=&gt;<br />&nbsp; &nbsp; string(10) "Shell.php"<br />&nbsp; &nbsp; ["SCRIPT_FILENAME"]=&gt;<br />&nbsp; &nbsp; string(10) "Shell.php"<br />&nbsp; &nbsp; ["PATH_TRANSLATED"]=&gt;<br />&nbsp; &nbsp; string(10) "Shell.php"<br />&nbsp; &nbsp; ["DOCUMENT_ROOT"]=&gt;<br />&nbsp; &nbsp; string(0) ""<br />&nbsp; &nbsp; ["REQUEST_TIME"]=&gt;<br />&nbsp; &nbsp; int(1247162183)<br />&nbsp; &nbsp; ["argv"]=&gt;<br />&nbsp; &nbsp; array(1) {<br />&nbsp; &nbsp; &nbsp; [0]=&gt;<br />&nbsp; &nbsp; &nbsp; string(10) "Shell.php"<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; ["argc"]=&gt;<br />&nbsp; &nbsp; int(1)<br />&nbsp; }</span>
</code></div>
  </div>
 </div>
  <div class="note" id="100964">  <div class="votes">
    <div id="Vu100964">
    <a href="/manual/vote-note.php?id=100964&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd100964">
    <a href="/manual/vote-note.php?id=100964&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V100964" title="57% like this...">
    10
    </div>
  </div>
  <a href="#100964" class="name">
  <strong class="user"><em>rulerof at gmail dot com</em></strong></a><a class="genanchor" href="#100964"> &para;</a><div class="date" title="2010-11-17 10:12"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom100964">
<div class="phpcode"><code><span class="html">
I needed to get the full base directory of my script local to my webserver, IIS 7 on Windows 2008.<br /><br />I ended up using this:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">GetBasePath</span><span class="keyword">() {<br />&nbsp; &nbsp; return </span><span class="default">substr</span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'SCRIPT_FILENAME'</span><span class="keyword">], </span><span class="default">0</span><span class="keyword">, </span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'SCRIPT_FILENAME'</span><span class="keyword">]) - </span><span class="default">strlen</span><span class="keyword">(</span><span class="default">strrchr</span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'SCRIPT_FILENAME'</span><span class="keyword">], </span><span class="string">"\\"</span><span class="keyword">)));<br />}<br /></span><span class="default">?&gt;<br /></span><br />And it returned C:\inetpub\wwwroot\&lt;applicationfolder&gt; as I had hoped.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="110763">  <div class="votes">
    <div id="Vu110763">
    <a href="/manual/vote-note.php?id=110763&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd110763">
    <a href="/manual/vote-note.php?id=110763&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V110763" title="57% like this...">
    7
    </div>
  </div>
  <a href="#110763" class="name">
  <strong class="user"><em>krinklemail at gmail dot com</em></strong></a><a class="genanchor" href="#110763"> &para;</a><div class="date" title="2012-12-05 11:39"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom110763">
<div class="phpcode"><code><span class="html">
If requests to your PHP script send a header "Content-Type" or/ "Content-Length" it will, contrary to regular HTTP headers, not appear in $_SERVER as $_SERVER['HTTP_CONTENT_TYPE']. PHP removes these (per CGI/1.1 specification[1]) from the HTTP_ match group.<br /><br />They are still accessible, but only if the request was a POST request. When it is, it'll be available as:<br />$_SERVER['CONTENT_LENGTH']<br />$_SERVER['CONTENT_TYPE']<br /><br />[1] <a href="https://www.ietf.org/rfc/rfc3875" rel="nofollow" target="_blank">https://www.ietf.org/rfc/rfc3875</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="116934">  <div class="votes">
    <div id="Vu116934">
    <a href="/manual/vote-note.php?id=116934&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116934">
    <a href="/manual/vote-note.php?id=116934&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116934" title="56% like this...">
    4
    </div>
  </div>
  <a href="#116934" class="name">
  <strong class="user"><em>plugwash at p10link dot net</em></strong></a><a class="genanchor" href="#116934"> &para;</a><div class="date" title="2015-03-24 01:38"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom116934">
<div class="phpcode"><code><span class="html">
Be aware that it's a bad idea to access x-forwarded-for and similar headers through this array. The header names are mangled when populating the array and this mangling can introduce spoofing vulnerabilities.<br /><br />See <a href="http://en.wikipedia.org/wiki/User:Brion_VIBBER/Cool_Cat_incident_report" rel="nofollow" target="_blank">http://en.wikipedia.org/wiki/User:Brion_VIBBER/Cool_Cat_incident_report</a> for details of a real world exploit of this.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="97106">  <div class="votes">
    <div id="Vu97106">
    <a href="/manual/vote-note.php?id=97106&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd97106">
    <a href="/manual/vote-note.php?id=97106&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V97106" title="57% like this...">
    6
    </div>
  </div>
  <a href="#97106" class="name">
  <strong class="user"><em>php at isnoop dot net</em></strong></a><a class="genanchor" href="#97106"> &para;</a><div class="date" title="2010-04-01 09:38"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom97106">
<div class="phpcode"><code><span class="html">
Use the apache SetEnv directive to set arbitrary $_SERVER variables in your vhost or apache config.<br /><br />SetEnv varname "variable value"</span>
</code></div>
  </div>
 </div>
  <div class="note" id="86740">  <div class="votes">
    <div id="Vu86740">
    <a href="/manual/vote-note.php?id=86740&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86740">
    <a href="/manual/vote-note.php?id=86740&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86740" title="57% like this...">
    6
    </div>
  </div>
  <a href="#86740" class="name">
  <strong class="user"><em>jette at nerdgirl dot dk</em></strong></a><a class="genanchor" href="#86740"> &para;</a><div class="date" title="2008-11-01 11:43"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86740">
<div class="phpcode"><code><span class="html">
Windows running IIS v6 does not include $_SERVER['SERVER_ADDR']<br /><br />If you need to get the IP addresse, use this instead:<br /><br /><span class="default">&lt;?php<br />$ipAddress </span><span class="keyword">= </span><span class="default">gethostbyname</span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'SERVER_NAME'</span><span class="keyword">]);<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="92829">  <div class="votes">
    <div id="Vu92829">
    <a href="/manual/vote-note.php?id=92829&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd92829">
    <a href="/manual/vote-note.php?id=92829&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V92829" title="57% like this...">
    5
    </div>
  </div>
  <a href="#92829" class="name">
  <strong class="user"><em>jarrod at squarecrow dot com</em></strong></a><a class="genanchor" href="#92829"> &para;</a><div class="date" title="2009-08-10 08:31"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom92829">
<div class="phpcode"><code><span class="html">
$_SERVER['DOCUMENT_ROOT'] is incredibly useful especially when working in your development environment. If you're working on large projects you'll likely be including a large number of files into your pages. For example:<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">//Defines constants to use for "include" URLS - helps keep our paths clean<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">define</span><span class="keyword">(</span><span class="string">"REGISTRY_CLASSES"</span><span class="keyword">,&nbsp; </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'DOCUMENT_ROOT'</span><span class="keyword">].</span><span class="string">"/SOAP/classes/"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">define</span><span class="keyword">(</span><span class="string">"REGISTRY_CONTROLS"</span><span class="keyword">, </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'DOCUMENT_ROOT'</span><span class="keyword">].</span><span class="string">"/SOAP/controls/"</span><span class="keyword">);<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">define</span><span class="keyword">(</span><span class="string">"STRING_BUILDER"</span><span class="keyword">,&nbsp; &nbsp;&nbsp; </span><span class="default">REGISTRY_CLASSES</span><span class="keyword">. </span><span class="string">"stringbuilder.php"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">define</span><span class="keyword">(</span><span class="string">"SESSION_MANAGER"</span><span class="keyword">,&nbsp; &nbsp;&nbsp; </span><span class="default">REGISTRY_CLASSES</span><span class="keyword">. </span><span class="string">"sessionmanager.php"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">define</span><span class="keyword">(</span><span class="string">"STANDARD_CONTROLS"</span><span class="keyword">,&nbsp; &nbsp; </span><span class="default">REGISTRY_CONTROLS</span><span class="keyword">.</span><span class="string">"standardcontrols.php"</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />In development environments, you're rarely working with your root folder, especially if you're running PHP locally on your box and using DOCUMENT_ROOT is a great way to maintain URL conformity. This will save you hours of work preparing your application for deployment from your box to a production server (not to mention save you the headache of include path failures).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="105602">  <div class="votes">
    <div id="Vu105602">
    <a href="/manual/vote-note.php?id=105602&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd105602">
    <a href="/manual/vote-note.php?id=105602&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V105602" title="55% like this...">
    10
    </div>
  </div>
  <a href="#105602" class="name">
  <strong class="user"><em>MarkAgius at markagius dot co dot uk</em></strong></a><a class="genanchor" href="#105602"> &para;</a><div class="date" title="2011-08-31 02:18"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom105602">
<div class="phpcode"><code><span class="html">
You have missed 'REDIRECT_STATUS'<br /><br />Very useful if you point all your error pages to the same file.<br /><br />File; .htaccess<br /># .htaccess file.<br /><br />ErrorDocument 404 /error-msg.php<br />ErrorDocument 500 /error-msg.php<br />ErrorDocument 400 /error-msg.php<br />ErrorDocument 401 /error-msg.php<br />ErrorDocument 403 /error-msg.php<br /># End of file.<br /><br />File; error-msg.php<br /><span class="default">&lt;?php<br />&nbsp; $HttpStatus </span><span class="keyword">= </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">"REDIRECT_STATUS"</span><span class="keyword">] ;<br />&nbsp; if(</span><span class="default">$HttpStatus</span><span class="keyword">==</span><span class="default">200</span><span class="keyword">) {print </span><span class="string">"Document has been processed and sent to you."</span><span class="keyword">;}<br />&nbsp; if(</span><span class="default">$HttpStatus</span><span class="keyword">==</span><span class="default">400</span><span class="keyword">) {print </span><span class="string">"Bad HTTP request "</span><span class="keyword">;}<br />&nbsp; if(</span><span class="default">$HttpStatus</span><span class="keyword">==</span><span class="default">401</span><span class="keyword">) {print </span><span class="string">"Unauthorized - Iinvalid password"</span><span class="keyword">;}<br />&nbsp; if(</span><span class="default">$HttpStatus</span><span class="keyword">==</span><span class="default">403</span><span class="keyword">) {print </span><span class="string">"Forbidden"</span><span class="keyword">;}<br />&nbsp; if(</span><span class="default">$HttpStatus</span><span class="keyword">==</span><span class="default">500</span><span class="keyword">) {print </span><span class="string">"Internal Server Error"</span><span class="keyword">;}<br />&nbsp; if(</span><span class="default">$HttpStatus</span><span class="keyword">==</span><span class="default">418</span><span class="keyword">) {print </span><span class="string">"I'm a teapot! - This is a real value, defined in 1998"</span><span class="keyword">;}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="94237">  <div class="votes">
    <div id="Vu94237">
    <a href="/manual/vote-note.php?id=94237&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd94237">
    <a href="/manual/vote-note.php?id=94237&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V94237" title="55% like this...">
    10
    </div>
  </div>
  <a href="#94237" class="name">
  <strong class="user"><em>mirko dot steiner at slashdevslashnull dot de</em></strong></a><a class="genanchor" href="#94237"> &para;</a><div class="date" title="2009-10-24 02:43"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom94237">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br /><br /></span><span class="comment">// RFC 2616 compatible Accept Language Parser<br />// <a href="http://www.ietf.org/rfc/rfc2616.txt," rel="nofollow" target="_blank">http://www.ietf.org/rfc/rfc2616.txt,</a> 14.4 Accept-Language, Page 104<br />// Hypertext Transfer Protocol -- HTTP/1.1<br /><br /></span><span class="keyword">foreach (</span><span class="default">explode</span><span class="keyword">(</span><span class="string">','</span><span class="keyword">, </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'HTTP_ACCEPT_LANGUAGE'</span><span class="keyword">]) as </span><span class="default">$lang</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$pattern </span><span class="keyword">= </span><span class="string">'/^(?P&lt;primarytag&gt;[a-zA-Z]{2,8})'</span><span class="keyword">.<br />&nbsp; &nbsp; </span><span class="string">'(?:-(?P&lt;subtag&gt;[a-zA-Z]{2,8}))?(?:(?:;q=)'</span><span class="keyword">.<br />&nbsp; &nbsp; </span><span class="string">'(?P&lt;quantifier&gt;\d\.\d))?$/'</span><span class="keyword">;<br /><br />&nbsp; &nbsp; </span><span class="default">$splits </span><span class="keyword">= array();<br /><br />&nbsp; &nbsp; </span><span class="default">printf</span><span class="keyword">(</span><span class="string">"Lang:,,%s''\n"</span><span class="keyword">, </span><span class="default">$lang</span><span class="keyword">);<br />&nbsp; &nbsp; if (</span><span class="default">preg_match</span><span class="keyword">(</span><span class="default">$pattern</span><span class="keyword">, </span><span class="default">$lang</span><span class="keyword">, </span><span class="default">$splits</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$splits</span><span class="keyword">);<br />&nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"\nno match\n"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />example output:<br /><br />Google Chrome 3.0.195.27 Windows xp<br /><br />Lang:,,de-DE''<br />Array<br />(<br />&nbsp; &nbsp; [0] =&gt; de-DE<br />&nbsp; &nbsp; [primarytag] =&gt; de<br />&nbsp; &nbsp; [1] =&gt; de<br />&nbsp; &nbsp; [subtag] =&gt; DE<br />&nbsp; &nbsp; [2] =&gt; DE<br />)<br />Lang:,,de;q=0.8''<br />Array<br />(<br />&nbsp; &nbsp; [0] =&gt; de;q=0.8<br />&nbsp; &nbsp; [primarytag] =&gt; de<br />&nbsp; &nbsp; [1] =&gt; de<br />&nbsp; &nbsp; [subtag] =&gt; <br />&nbsp; &nbsp; [2] =&gt; <br />&nbsp; &nbsp; [quantifier] =&gt; 0.8<br />&nbsp; &nbsp; [3] =&gt; 0.8<br />)<br />Lang:,,en-US;q=0.6''<br />Array<br />(<br />&nbsp; &nbsp; [0] =&gt; en-US;q=0.6<br />&nbsp; &nbsp; [primarytag] =&gt; en<br />&nbsp; &nbsp; [1] =&gt; en<br />&nbsp; &nbsp; [subtag] =&gt; US<br />&nbsp; &nbsp; [2] =&gt; US<br />&nbsp; &nbsp; [quantifier] =&gt; 0.6<br />&nbsp; &nbsp; [3] =&gt; 0.6<br />)<br />Lang:,,en;q=0.4''<br />Array<br />(<br />&nbsp; &nbsp; [0] =&gt; en;q=0.4<br />&nbsp; &nbsp; [primarytag] =&gt; en<br />&nbsp; &nbsp; [1] =&gt; en<br />&nbsp; &nbsp; [subtag] =&gt; <br />&nbsp; &nbsp; [2] =&gt; <br />&nbsp; &nbsp; [quantifier] =&gt; 0.4<br />&nbsp; &nbsp; [3] =&gt; 0.4<br />)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="90656">  <div class="votes">
    <div id="Vu90656">
    <a href="/manual/vote-note.php?id=90656&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd90656">
    <a href="/manual/vote-note.php?id=90656&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V90656" title="56% like this...">
    6
    </div>
  </div>
  <a href="#90656" class="name">
  <strong class="user"><em>pudding06 at gmail dot com</em></strong></a><a class="genanchor" href="#90656"> &para;</a><div class="date" title="2009-05-02 02:44"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom90656">
<div class="phpcode"><code><span class="html">
Here's a simple, quick but effective way to block unwanted external visitors to your local server:<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">// only local requests<br /></span><span class="keyword">if (</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'REMOTE_ADDR'</span><span class="keyword">] !== </span><span class="string">'127.0.0.1'</span><span class="keyword">) die(</span><span class="default">header</span><span class="keyword">(</span><span class="string">"Location: /"</span><span class="keyword">));<br /></span><span class="default">?&gt;<br /></span><br />This will direct all external traffic to your home page. Of course you could send a 404 or other custom error. Best practice is not to stay on the page with a custom error message as you acknowledge that the page does exist. That's why I redirect unwanted calls to (for example) phpmyadmin.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="99395">  <div class="votes">
    <div id="Vu99395">
    <a href="/manual/vote-note.php?id=99395&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd99395">
    <a href="/manual/vote-note.php?id=99395&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V99395" title="55% like this...">
    3
    </div>
  </div>
  <a href="#99395" class="name">
  <strong class="user"><em>dtomasiewicz at gmail dot com</em></strong></a><a class="genanchor" href="#99395"> &para;</a><div class="date" title="2010-08-14 08:03"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom99395">
<div class="phpcode"><code><span class="html">
To get an associative array of HTTP request headers formatted similarly to get_headers(), this will do the trick:<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">/**<br /> * Transforms $_SERVER HTTP headers into a nice associative array. For example:<br /> *&nbsp;&nbsp; array(<br /> *&nbsp; &nbsp; &nbsp;&nbsp; 'Referer' =&gt; 'example.com',<br /> *&nbsp; &nbsp; &nbsp;&nbsp; 'X-Requested-With' =&gt; 'XMLHttpRequest'<br /> *&nbsp;&nbsp; )<br /> */<br /></span><span class="keyword">function </span><span class="default">get_request_headers</span><span class="keyword">() {<br />&nbsp; &nbsp; </span><span class="default">$headers </span><span class="keyword">= array();<br />&nbsp; &nbsp; foreach(</span><span class="default">$_SERVER </span><span class="keyword">as </span><span class="default">$key </span><span class="keyword">=&gt; </span><span class="default">$value</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">strpos</span><span class="keyword">(</span><span class="default">$key</span><span class="keyword">, </span><span class="string">'HTTP_'</span><span class="keyword">) === </span><span class="default">0</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$headers</span><span class="keyword">[</span><span class="default">str_replace</span><span class="keyword">(</span><span class="string">' '</span><span class="keyword">, </span><span class="string">'-'</span><span class="keyword">, </span><span class="default">ucwords</span><span class="keyword">(</span><span class="default">str_replace</span><span class="keyword">(</span><span class="string">'_'</span><span class="keyword">, </span><span class="string">' '</span><span class="keyword">, </span><span class="default">strtolower</span><span class="keyword">(</span><span class="default">substr</span><span class="keyword">(</span><span class="default">$key</span><span class="keyword">, </span><span class="default">5</span><span class="keyword">)))))] = </span><span class="default">$value</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; return </span><span class="default">$headers</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="91964">  <div class="votes">
    <div id="Vu91964">
    <a href="/manual/vote-note.php?id=91964&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd91964">
    <a href="/manual/vote-note.php?id=91964&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V91964" title="54% like this...">
    7
    </div>
  </div>
  <a href="#91964" class="name">
  <strong class="user"><em>chris</em></strong></a><a class="genanchor" href="#91964"> &para;</a><div class="date" title="2009-07-02 04:01"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom91964">
<div class="phpcode"><code><span class="html">
A table of everything in the $_SERVER array can be found near the bottom of the output of phpinfo();</span>
</code></div>
  </div>
 </div>
  <div class="note" id="112425">  <div class="votes">
    <div id="Vu112425">
    <a href="/manual/vote-note.php?id=112425&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd112425">
    <a href="/manual/vote-note.php?id=112425&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V112425" title="52% like this...">
    2
    </div>
  </div>
  <a href="#112425" class="name">
  <strong class="user"><em>pomat at live dot it</em></strong></a><a class="genanchor" href="#112425"> &para;</a><div class="date" title="2013-06-15 02:12"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom112425">
<div class="phpcode"><code><span class="html">
$_SERVER['DOCUMENT_ROOT'] may contain backslashes on windows systems, and of course it may or may not have a trailing slash (backslash).<br />I saw the following as an example of the proper way we're supposed to deal with this issue:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">include(</span><span class="default">dirname</span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'DOCUMENT_ROOT'</span><span class="keyword">]) . </span><span class="default">DIRECTORY_SEPARATOR </span><span class="keyword">. </span><span class="string">'file.php'</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />Ok, the latter may be used to access a file inside the parent directory of the document root, but actually does not properly address the issue.<br />In the end, don't warry about. It should be safe to use forward slashes and append a trailing slash in all cases.<br />Let's say we have this:<br /><br /><span class="default">&lt;?php<br />$path </span><span class="keyword">= </span><span class="string">'subdir/file.php'</span><span class="keyword">;<br /></span><span class="default">$result </span><span class="keyword">= </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'DOCUMENT_ROOT'</span><span class="keyword">] . </span><span class="string">'/' </span><span class="keyword">. </span><span class="default">$path</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />On linux $result might be something like<br />1) "/var/www/subdir/file.php"<br />2) "/var/www//subdir/file.php"<br />String 2 is parsed the same as string 1 (have a try with command 'cd').<br /><br />On windows $result might be something like<br />1) "C:/apache/htdocs/subdir/file.php"<br />2) "C:/apache/htdocs//subdir/file.php"<br />3) "C:\apache\htdocs/subdir/file.php"<br />4) "C:\apache\htdocs\/subdir/file.php"<br />All those strings are parsed as "C:\apache\htdocs\subdir\file.php" (have a try with 'cd').</span>
</code></div>
  </div>
 </div>
  <div class="note" id="88418">  <div class="votes">
    <div id="Vu88418">
    <a href="/manual/vote-note.php?id=88418&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd88418">
    <a href="/manual/vote-note.php?id=88418&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V88418" title="54% like this...">
    3
    </div>
  </div>
  <a href="#88418" class="name">
  <strong class="user"><em>info at mtprod dot com</em></strong></a><a class="genanchor" href="#88418"> &para;</a><div class="date" title="2009-01-23 02:13"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom88418">
<div class="phpcode"><code><span class="html">
On Windows IIS 7 you must use $_SERVER['LOCAL_ADDR'] rather than $_SERVER['SERVER_ADDR'] to get the server's IP address.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114370">  <div class="votes">
    <div id="Vu114370">
    <a href="/manual/vote-note.php?id=114370&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114370">
    <a href="/manual/vote-note.php?id=114370&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114370" title="52% like this...">
    2
    </div>
  </div>
  <a href="#114370" class="name">
  <strong class="user"><em>jit_chavan at yahoo dot com</em></strong></a><a class="genanchor" href="#114370"> &para;</a><div class="date" title="2014-02-13 07:26"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114370">
<div class="phpcode"><code><span class="html">
searched $_SERVER["REDIRECT_URL"] for a while and noted that it is not mentioned in php documentation page itself. look like this is only generated by apache server(not others) and using&nbsp;&nbsp; $_SERVER["REQUEST_URI"] will be useful in some cases as mine.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="98408">  <div class="votes">
    <div id="Vu98408">
    <a href="/manual/vote-note.php?id=98408&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd98408">
    <a href="/manual/vote-note.php?id=98408&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V98408" title="53% like this...">
    3
    </div>
  </div>
  <a href="#98408" class="name">
  <strong class="user"><em>wbeaumo1 at gmail dot com</em></strong></a><a class="genanchor" href="#98408"> &para;</a><div class="date" title="2010-06-13 08:43"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom98408">
<div class="phpcode"><code><span class="html">
Don't forget $_SERVER['HTTP_COOKIE']. It contains the raw value of the 'Cookie' header sent by the user agent.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="112693">  <div class="votes">
    <div id="Vu112693">
    <a href="/manual/vote-note.php?id=112693&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd112693">
    <a href="/manual/vote-note.php?id=112693&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V112693" title="52% like this...">
    1
    </div>
  </div>
  <a href="#112693" class="name">
  <strong class="user"><em>wyattstorch42 at outlook dot com</em></strong></a><a class="genanchor" href="#112693"> &para;</a><div class="date" title="2013-07-13 06:18"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom112693">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br /></span><span class="comment">/*<br /> * I wrote this because I was including a file with classes in it. Let's say that<br /> * I have a contact page at mysite.com/contact/index.php and a Form class at<br /> * mysite.com/classes/Form.php. So in index.php, I have this statement:<br /> * require '../classes/Form.php';<br /> * The Form class includes a method to generate the HTML markup for a number of<br /> * form elements, including a CAPTCHA image and associated text field. To do so,<br /> * it must generate an &lt;img /&gt; element and give it a src of Form.php?captcha.<br /> * But I wanted it to automatically generate a src attribute without index.php<br /> * giving it a relative path. This script comes in handy by automatically<br /> * locating the directory that contains the included file (Form.php) and converting<br /> * it from an absolute path to a relative path that could be used for an img src,<br /> * an a href, a link href, etc.<br /> */ <br /></span><span class="keyword">function </span><span class="default">relativeURL </span><span class="keyword">() {<br />&nbsp; &nbsp; </span><span class="default">$dir </span><span class="keyword">= </span><span class="default">str_replace</span><span class="keyword">(</span><span class="string">'\\'</span><span class="keyword">, </span><span class="string">'/'</span><span class="keyword">, </span><span class="default">__DIR__</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Resolves inconsistency with PATH_SEPARATOR on Windows vs. Linux<br />&nbsp; &nbsp; &nbsp; &nbsp; // Use dirname(__FILE__) in place of __DIR__ for older PHP versions<br />&nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">substr</span><span class="keyword">(</span><span class="default">$dir</span><span class="keyword">, </span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'DOCUMENT_ROOT'</span><span class="keyword">]));<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Clip off the part of the path outside of the document root<br /></span><span class="keyword">}<br /><br /></span><span class="comment">/*<br /> *contact/index.php<br /> */<br /></span><span class="keyword">require </span><span class="string">'../classes/Form.php'</span><span class="keyword">;<br />new </span><span class="default">Form</span><span class="keyword">()-&gt;</span><span class="default">drawCaptchaField</span><span class="keyword">();<br />&nbsp; &nbsp; </span><span class="comment">// Writes: &lt;img src="/classes/Form.php?captcha" /&gt;<br /><br />&nbsp; &nbsp; <br />/*<br /> * classes/Form.php<br /> */<br /></span><span class="keyword">if (isset(</span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">'captcha'</span><span class="keyword">])) {<br />&nbsp; &nbsp; </span><span class="comment">// generate/return CAPTCHA image<br /></span><span class="keyword">}<br /><br />class </span><span class="default">Form </span><span class="keyword">{<br />&nbsp; &nbsp; </span><span class="comment">// ...<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">drawCaptchaField </span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'&lt;img src="'</span><span class="keyword">.</span><span class="default">relativeURL</span><span class="keyword">().</span><span class="string">'?captcha" /&gt;'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="100881">  <div class="votes">
    <div id="Vu100881">
    <a href="/manual/vote-note.php?id=100881&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd100881">
    <a href="/manual/vote-note.php?id=100881&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V100881" title="52% like this...">
    2
    </div>
  </div>
  <a href="#100881" class="name">
  <strong class="user"><em>Stefano (info at sarchittu dot org)</em></strong></a><a class="genanchor" href="#100881"> &para;</a><div class="date" title="2010-11-12 06:07"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom100881">
<div class="phpcode"><code><span class="html">
A way to get the absolute path of your page, independent from the site position (so works both on local machine and on server without setting anything) and from the server OS (works both on Unix systems and Windows systems).<br /><br />The only parameter it requires is the folder in which you place this script<br />So, for istance, I'll place this into my SCRIPT folder, and I'll write SCRIPT word length in $conflen<br /><br /><span class="default">&lt;?php<br />$conflen</span><span class="keyword">=</span><span class="default">strlen</span><span class="keyword">(</span><span class="string">'SCRIPT'</span><span class="keyword">);<br /></span><span class="default">$B</span><span class="keyword">=</span><span class="default">substr</span><span class="keyword">(</span><span class="default">__FILE__</span><span class="keyword">,</span><span class="default">0</span><span class="keyword">,</span><span class="default">strrpos</span><span class="keyword">(</span><span class="default">__FILE__</span><span class="keyword">,</span><span class="string">'/'</span><span class="keyword">));<br /></span><span class="default">$A</span><span class="keyword">=</span><span class="default">substr</span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'DOCUMENT_ROOT'</span><span class="keyword">], </span><span class="default">strrpos</span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'DOCUMENT_ROOT'</span><span class="keyword">], </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_SELF'</span><span class="keyword">]));<br /></span><span class="default">$C</span><span class="keyword">=</span><span class="default">substr</span><span class="keyword">(</span><span class="default">$B</span><span class="keyword">,</span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$A</span><span class="keyword">));<br /></span><span class="default">$posconf</span><span class="keyword">=</span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$C</span><span class="keyword">)-</span><span class="default">$conflen</span><span class="keyword">-</span><span class="default">1</span><span class="keyword">;<br /></span><span class="default">$D</span><span class="keyword">=</span><span class="default">substr</span><span class="keyword">(</span><span class="default">$C</span><span class="keyword">,</span><span class="default">1</span><span class="keyword">,</span><span class="default">$posconf</span><span class="keyword">);<br /></span><span class="default">$host</span><span class="keyword">=</span><span class="string">'<a href="http://" rel="nofollow" target="_blank">http://</a>'</span><span class="keyword">.</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'SERVER_NAME'</span><span class="keyword">].</span><span class="string">'/'</span><span class="keyword">.</span><span class="default">$D</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />$host will finally contain the absolute path.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121487">  <div class="votes">
    <div id="Vu121487">
    <a href="/manual/vote-note.php?id=121487&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121487">
    <a href="/manual/vote-note.php?id=121487&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121487" title="50% like this...">
    0
    </div>
  </div>
  <a href="#121487" class="name">
  <strong class="user"><em>bilgus at bilgus dot com</em></strong></a><a class="genanchor" href="#121487"> &para;</a><div class="date" title="2017-08-06 03:51"><strong>4 months ago</strong></div>
  <div class="text" id="Hcom121487">
<div class="phpcode"><code><span class="html">
I liked pulling the names and values directly from the $_SERVER array better than naming all arguments<br /><br /><span class="default">&lt;?php <br /></span><span class="keyword">echo </span><span class="string">'&lt;table cellpadding="10"&gt;' </span><span class="keyword">; <br />foreach(</span><span class="default">$_SERVER </span><span class="keyword">as </span><span class="default">$paramName </span><span class="keyword">=&gt; </span><span class="default">$varServer</span><span class="keyword">) {<br />&nbsp; &nbsp; if (isset(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="default">$paramName</span><span class="keyword">])) { <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">ob_start</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$varServer</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$varDump </span><span class="keyword">= </span><span class="default">ob_get_clean</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'&lt;tr&gt;&lt;td&gt;'</span><span class="keyword">.</span><span class="default">$paramName</span><span class="keyword">.</span><span class="string">'&lt;/td&gt;&lt;td&gt;'</span><span class="keyword">.</span><span class="default">$varDump</span><span class="keyword">.</span><span class="string">'&lt;/td&gt;&lt;/tr&gt;' </span><span class="keyword">; <br />&nbsp; &nbsp; } <br />&nbsp; &nbsp; else { <br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'&lt;tr&gt;&lt;td&gt;'</span><span class="keyword">.</span><span class="default">$paramName</span><span class="keyword">.</span><span class="string">'&lt;/td&gt;&lt;td&gt;-&lt;/td&gt;&lt;/tr&gt;' </span><span class="keyword">; <br />&nbsp; &nbsp; } <br />} <br />echo </span><span class="string">'&lt;/table&gt;' </span><span class="keyword">;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121147">  <div class="votes">
    <div id="Vu121147">
    <a href="/manual/vote-note.php?id=121147&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121147">
    <a href="/manual/vote-note.php?id=121147&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121147" title="no votes...">
    0
    </div>
  </div>
  <a href="#121147" class="name">
  <strong class="user"><em>centurianii at yahoo dot co dot uk</em></strong></a><a class="genanchor" href="#121147"> &para;</a><div class="date" title="2017-05-28 10:18"><strong>6 months ago</strong></div>
  <div class="text" id="Hcom121147">
<div class="phpcode"><code><span class="html">
If you apply redirection in ALL your requests using commands at the Apache virtual host file like:<br />RewriteEngine On<br />RewriteCond "%{REQUEST_URI}" "!=/index.php"<br />RewriteRule "^/(.*)$" "index.php?$1" [NC,NE,L,QSA]<br />you should expect some deviations in your $_SERVER global.<br /><br />Say, you send a url of: [hostname here]/a/b?x=1&amp;y=2<br />which makes Apache to modify to: /index.php?/a/b?x=1&amp;y=2<br /><br />Now your $_SERVER global contains among others:<br />'REQUEST_URI' =&gt; '/a/b?x=1&amp;y=2', it retains the initial url after the host<br /> 'QUERY_STRING' =&gt; 'a/b&amp;x=1&amp;y=2', notice how php replaces '?' with '&amp;'<br /> 'SCRIPT_NAME' =&gt; '/index.php', as it was intended to be.<br /><br />To test your $_SERVER global:<br />function serverArray(){<br />&nbsp;&nbsp; $arr = array();<br />&nbsp;&nbsp; foreach($_SERVER as $key=&gt;$value)<br />&nbsp; &nbsp; &nbsp; $arr[] = '&amp;nbsp;&amp;nbsp;&amp;nbsp;\'' . $key . '\' =&gt; \'' . (isset($value)? $value : '-') . '\'';<br />&nbsp;&nbsp; return @\sort($arr)? '$_SERVER = array(&lt;br /&gt;' . implode($arr, ',&lt;br /&gt;') . '&lt;br /&gt;);' : false;<br />}<br />echo serverArray();</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121676">  <div class="votes">
    <div id="Vu121676">
    <a href="/manual/vote-note.php?id=121676&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121676">
    <a href="/manual/vote-note.php?id=121676&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121676" title="0% like this...">
    -1
    </div>
  </div>
  <a href="#121676" class="name">
  <strong class="user"><em>Luigi</em></strong></a><a class="genanchor" href="#121676"> &para;</a><div class="date" title="2017-09-23 08:11"><strong>2 months ago</strong></div>
  <div class="text" id="Hcom121676">
<div class="phpcode"><code><span class="html">
Hey guys, I by far have very little experience. I'm looking to enable SERVER_NAME value on my VPS. How do I go about? Thanks!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121255">  <div class="votes">
    <div id="Vu121255">
    <a href="/manual/vote-note.php?id=121255&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121255">
    <a href="/manual/vote-note.php?id=121255&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121255" title="0% like this...">
    -2
    </div>
  </div>
  <a href="#121255" class="name">
  <strong class="user"><em>camadmin@CAMserver</em></strong></a><a class="genanchor" href="#121255"> &para;</a><div class="date" title="2017-06-21 01:52"><strong>5 months ago</strong></div>
  <div class="text" id="Hcom121255">
<div class="phpcode"><code><span class="html">
You can try: a) save this script into .php file (global_server.php, by example)<br /><span class="default">&lt;?php<br /></span><span class="keyword">foreach (</span><span class="default">$_SERVER </span><span class="keyword">as </span><span class="default">$key </span><span class="keyword">=&gt; </span><span class="default">$value</span><span class="keyword">) {<br />&nbsp;&nbsp; echo </span><span class="string">"</span><span class="default">$key</span><span class="string"> &lt;pre&gt; </span><span class="default">$value</span><span class="string"> &lt;/pre&gt;"</span><span class="keyword">;<br />&nbsp;&nbsp; echo </span><span class="string">"&lt;br&gt;"</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span>b) on Linux console, execute: php global_server.php &gt; global_server.html<br />c) edit global_server.html and adds the missing tags "html" and "body". Save the changes.<br />d) view the contents by <a href="http://localhost/global_server.html" rel="nofollow" target="_blank">http://localhost/global_server.html</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="106142">  <div class="votes">
    <div id="Vu106142">
    <a href="/manual/vote-note.php?id=106142&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd106142">
    <a href="/manual/vote-note.php?id=106142&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V106142" title="51% like this...">
    1
    </div>
  </div>
  <a href="#106142" class="name">
  <strong class="user"><em>picov at e-link dot it</em></strong></a><a class="genanchor" href="#106142"> &para;</a><div class="date" title="2011-10-13 10:59"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom106142">
<div class="phpcode"><code><span class="html">
A simple function to detect if the current page address was rewritten by mod_rewrite:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">public function </span><span class="default">urlWasRewritten</span><span class="keyword">() {<br />&nbsp; </span><span class="default">$realScriptName</span><span class="keyword">=</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'SCRIPT_NAME'</span><span class="keyword">];<br />&nbsp; </span><span class="default">$virtualScriptName</span><span class="keyword">=</span><span class="default">reset</span><span class="keyword">(</span><span class="default">explode</span><span class="keyword">(</span><span class="string">"?"</span><span class="keyword">, </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'REQUEST_URI'</span><span class="keyword">]));<br />&nbsp; return !(</span><span class="default">$realScriptName</span><span class="keyword">==</span><span class="default">$virtualScriptName</span><span class="keyword">);<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="86609">  <div class="votes">
    <div id="Vu86609">
    <a href="/manual/vote-note.php?id=86609&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86609">
    <a href="/manual/vote-note.php?id=86609&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86609" title="52% like this...">
    1
    </div>
  </div>
  <a href="#86609" class="name">
  <strong class="user"><em>geoffrey dot hoffman at gmail dot com</em></strong></a><a class="genanchor" href="#86609"> &para;</a><div class="date" title="2008-10-25 05:13"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86609">
<div class="phpcode"><code><span class="html">
If you are looking at $_SERVER['HTTP_USER_AGENT'] to determine whether your user is on a mobile device, you may want to visit these resources:<br /><br /><a href="http://wurfl.sourceforge.net/" rel="nofollow" target="_blank">http://wurfl.sourceforge.net/</a><br /><br /><a href="http://www.zytrax.com/tech/web/mobile_ids.html" rel="nofollow" target="_blank">http://www.zytrax.com/tech/web/mobile_ids.html</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="116921">  <div class="votes">
    <div id="Vu116921">
    <a href="/manual/vote-note.php?id=116921&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116921">
    <a href="/manual/vote-note.php?id=116921&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116921" title="50% like this...">
    0
    </div>
  </div>
  <a href="#116921" class="name">
  <strong class="user"><em>answer at question dot forever</em></strong></a><a class="genanchor" href="#116921"> &para;</a><div class="date" title="2015-03-21 12:14"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom116921">
<div class="phpcode"><code><span class="html">
I'm lazy but rigorous:<br /><span class="default">&lt;?php<br /></span><span class="keyword">while (list(</span><span class="default">$var</span><span class="keyword">,</span><span class="default">$value</span><span class="keyword">) = </span><span class="default">each </span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">)) {<br />echo </span><span class="default">$var</span><span class="keyword">.</span><span class="string">" Val:"</span><span class="keyword">.</span><span class="default">$value</span><span class="keyword">.</span><span class="string">"&lt;br /&gt;"</span><span class="keyword">;<br />}<br />&lt;</span><span class="default">a href</span><span class="keyword">=</span><span class="string">"<a href="https://blog.sinatranetwork.com/2011/07/20/php-how-to-print-all-_server-variables/" rel="nofollow" target="_blank">https://blog.sinatranetwork.com/2011/07/20/php-how-to-print-all-_server-variables/</a>"</span><span class="keyword">&gt;</span><span class="default">Thank you sir</span><span class="keyword">!&lt;/</span><span class="default">a</span><span class="keyword">&gt;<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="93046">  <div class="votes">
    <div id="Vu93046">
    <a href="/manual/vote-note.php?id=93046&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd93046">
    <a href="/manual/vote-note.php?id=93046&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V93046" title="51% like this...">
    1
    </div>
  </div>
  <a href="#93046" class="name">
  <strong class="user"><em>cupy at email dot cz</em></strong></a><a class="genanchor" href="#93046"> &para;</a><div class="date" title="2009-08-20 08:24"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom93046">
<div class="phpcode"><code><span class="html">
Tech note:<br />$_SERVER['argc'] and $_SERVER['argv'][] has some funny behaviour,<br />used from linux (bash) commandline, when called like <br />"php ./script_name.php 0x020B" <br />there is everything correct, but <br />"./script_name.php 0x020B"<br />is not correct - "0" is passed instead of "0x020B" as $_SERVER['argv'][1] - see the script below.<br />Looks like the parameter is not passed well from bash to PHP.<br />(but, inspected on the level of bash, 0x020B is understood well as $1)<br /><br />try this example:<br /><br />-------------&gt;8------------------<br />cat ./script_name.php<br />#! /usr/bin/php<br /><br />if( $_SERVER['argc'] == 2)<br />&nbsp; {<br />&nbsp; &nbsp; // funny... we have to do this trick to pass e.g. 0x020B from parameters<br />&nbsp; &nbsp; // ignore this: "PHP Notice:&nbsp; Undefined offset:&nbsp; 2 in ..."<br />&nbsp; &nbsp; $EID = $_SERVER['argv'][1] + $_SERVER['argv'][2] + $_SERVER['argv'][3];<br />&nbsp; }<br /> else<br />&nbsp;&nbsp; {&nbsp; &nbsp; &nbsp; &nbsp; // default<br />&nbsp; &nbsp;&nbsp; $EID = 0x0210; // PPS failure<br />&nbsp;&nbsp; }</span>
</code></div>
  </div>
 </div>
  <div class="note" id="84919">  <div class="votes">
    <div id="Vu84919">
    <a href="/manual/vote-note.php?id=84919&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd84919">
    <a href="/manual/vote-note.php?id=84919&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V84919" title="51% like this...">
    1
    </div>
  </div>
  <a href="#84919" class="name">
  <strong class="user"><em>silverquick at gmail dot com</em></strong></a><a class="genanchor" href="#84919"> &para;</a><div class="date" title="2008-08-05 05:55"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom84919">
<div class="phpcode"><code><span class="html">
I think the HTTPS element will only be present under Apache 2.x. It's not in the list of "special" variables here:<br /><a href="http://httpd.apache.org/docs/1.3/mod/mod_rewrite.html#RewriteCond" rel="nofollow" target="_blank">http://httpd.apache.org/docs/1.3/mod/mod_rewrite.html#RewriteCond</a><br />But it is here:<br /><a href="http://httpd.apache.org/docs/2.0/mod/mod_rewrite.html#rewritecond" rel="nofollow" target="_blank">http://httpd.apache.org/docs/2.0/mod/mod_rewrite.html#rewritecond</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="108329">  <div class="votes">
    <div id="Vu108329">
    <a href="/manual/vote-note.php?id=108329&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd108329">
    <a href="/manual/vote-note.php?id=108329&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V108329" title="50% like this...">
    0
    </div>
  </div>
  <a href="#108329" class="name">
  <strong class="user"><em>dii3g0</em></strong></a><a class="genanchor" href="#108329"> &para;</a><div class="date" title="2012-04-17 04:43"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom108329">
<div class="phpcode"><code><span class="html">
Proccess path_info<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">get_path_info</span><span class="keyword">()<br />{<br />&nbsp; &nbsp; if( ! </span><span class="default">array_key_exists</span><span class="keyword">(</span><span class="string">'PATH_INFO'</span><span class="keyword">, </span><span class="default">$_SERVER</span><span class="keyword">) )<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$pos </span><span class="keyword">= </span><span class="default">strpos</span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'REQUEST_URI'</span><span class="keyword">], </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'QUERY_STRING'</span><span class="keyword">]);<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$asd </span><span class="keyword">= </span><span class="default">substr</span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'REQUEST_URI'</span><span class="keyword">], </span><span class="default">0</span><span class="keyword">, </span><span class="default">$pos </span><span class="keyword">- </span><span class="default">2</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$asd </span><span class="keyword">= </span><span class="default">substr</span><span class="keyword">(</span><span class="default">$asd</span><span class="keyword">, </span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'SCRIPT_NAME'</span><span class="keyword">]) + </span><span class="default">1</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$asd</span><span class="keyword">;&nbsp; &nbsp; <br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; else<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">trim</span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PATH_INFO'</span><span class="keyword">], </span><span class="string">'/'</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="95672">  <div class="votes">
    <div id="Vu95672">
    <a href="/manual/vote-note.php?id=95672&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd95672">
    <a href="/manual/vote-note.php?id=95672&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V95672" title="48% like this...">
    -1
    </div>
  </div>
  <a href="#95672" class="name">
  <strong class="user"><em>admin at NOSpAM dot sinfocol dot org</em></strong></a><a class="genanchor" href="#95672"> &para;</a><div class="date" title="2010-01-14 10:31"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom95672">
<div class="phpcode"><code><span class="html">
I was testing with the $_SERVER variable and some request method, and I found that with apache I can put an arbitrary method.<br /><br />For example, I have an script called "server.php" in my example webpage with the next code:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">echo </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'REQUEST_METHOD'</span><span class="keyword">];<br /></span><span class="default">?&gt;<br /></span><br />And I made this request:<br />c:\&gt;nc -vv www.example.com 80<br />example.com [x.x.x.x] 80 (http) open<br />ArbitratyMethod /server.php HTTP/1.1<br />Host: wow.sinfocol.org<br />Connection: Close<br /><br />The response of the server is the next:<br />HTTP/1.1 200 OK<br />Date: Fri, 15 Jan 2010 05:14:09 GMT<br />Server: Apache<br />Connection: close<br />Transfer-Encoding: chunked<br />Content-Type: text/html<br /><br />ArbitratyMethod<br /><br />So, be carefully when include the $_SERVER['REQUEST_METHOD'] in any script, this kind of "bug" is old and could be dangerous.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="85045">  <div class="votes">
    <div id="Vu85045">
    <a href="/manual/vote-note.php?id=85045&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd85045">
    <a href="/manual/vote-note.php?id=85045&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V85045" title="48% like this...">
    -1
    </div>
  </div>
  <a href="#85045" class="name">
  <strong class="user"><em>jeff at example dot com</em></strong></a><a class="genanchor" href="#85045"> &para;</a><div class="date" title="2008-08-12 11:24"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom85045">
<div class="phpcode"><code><span class="html">
Note that, in Apache 2, the server settings will affect the variables available in $_SERVER. For example, if you are using SSL, the following directive will dump SSL-related status information, along with the server certificate and client certificate (if present) into the $_SERVER variables:<br /><br />SSLOptions +StdEnvVars +ExportCertData</span>
</code></div>
  </div>
 </div>
  <div class="note" id="101490">  <div class="votes">
    <div id="Vu101490">
    <a href="/manual/vote-note.php?id=101490&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd101490">
    <a href="/manual/vote-note.php?id=101490&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V101490" title="46% like this...">
    -3
    </div>
  </div>
  <a href="#101490" class="name">
  <strong class="user"><em>Josh Fremer</em></strong></a><a class="genanchor" href="#101490"> &para;</a><div class="date" title="2010-12-20 10:47"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom101490">
<div class="phpcode"><code><span class="html">
HTTPS<br /><br />Set to a non-empty value if the script was queried through the HTTPS protocol.<br /><br />Note: Note that when using ISAPI with IIS, the value will be off if the request was not made through the HTTPS protocol.<br /><br />=-=-=<br /><br />To clarify this, the value is the string "off", so a specific non-empty value rather than an empty value as in Apache.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117528">  <div class="votes">
    <div id="Vu117528">
    <a href="/manual/vote-note.php?id=117528&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117528">
    <a href="/manual/vote-note.php?id=117528&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117528" title="42% like this...">
    -2
    </div>
  </div>
  <a href="#117528" class="name">
  <strong class="user"><em>doublecompile at gmail dot com</em></strong></a><a class="genanchor" href="#117528"> &para;</a><div class="date" title="2015-06-24 08:32"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117528">
<div class="phpcode"><code><span class="html">
I've used the SplPriorityQueue to determine an HTTP client's preferred MIME types that are in $_SERVER['HTTP_ACCEPT'].<br /><br /><span class="default">&lt;?php<br />$queue </span><span class="keyword">= new \</span><span class="default">SplPriorityQueue</span><span class="keyword">();<br />foreach (</span><span class="default">preg_split</span><span class="keyword">(</span><span class="string">'#,\s*#'</span><span class="keyword">, </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'HTTP_ACCEPT'</span><span class="keyword">]) as </span><span class="default">$accept</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$split </span><span class="keyword">= </span><span class="default">preg_split</span><span class="keyword">(</span><span class="string">'#;\s*q=#'</span><span class="keyword">, </span><span class="default">$accept</span><span class="keyword">, </span><span class="default">2</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$queue</span><span class="keyword">-&gt;</span><span class="default">insert</span><span class="keyword">(</span><span class="default">$split</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">], isset(</span><span class="default">$split</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]) ? (float)</span><span class="default">$split</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">] : </span><span class="default">1.0</span><span class="keyword">);<br />}<br />foreach (</span><span class="default">$queue </span><span class="keyword">as </span><span class="default">$mime</span><span class="keyword">) {<br />&nbsp; &nbsp; echo </span><span class="default">$mime</span><span class="keyword">, </span><span class="default">PHP_EOL</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />My browser sends:<br />Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8<br /><br />And this script outputs:<br />text/html<br />application/xhtml+xml<br />application/xml<br />*/*<br /><br />A better example:<br />Accept: text/html, application/xml,text/css;q=0.4,text/plain; q=0.9, application/json;q=0.8<br /><br />And this script outputs:<br />text/html<br />application/xml<br />text/plain<br />application/json<br />text/css</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118364">  <div class="votes">
    <div id="Vu118364">
    <a href="/manual/vote-note.php?id=118364&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118364">
    <a href="/manual/vote-note.php?id=118364&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118364" title="42% like this...">
    -3
    </div>
  </div>
  <a href="#118364" class="name">
  <strong class="user"><em>office at peername dot com</em></strong></a><a class="genanchor" href="#118364"> &para;</a><div class="date" title="2015-11-23 10:39"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom118364">
<div class="phpcode"><code><span class="html">
Keep in mind that if the user is using proxy server (like PAC), REQUEST_URI will include the full request URL like <a href="http://example.com/path/" rel="nofollow" target="_blank">http://example.com/path/</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="111396">  <div class="votes">
    <div id="Vu111396">
    <a href="/manual/vote-note.php?id=111396&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd111396">
    <a href="/manual/vote-note.php?id=111396&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V111396" title="40% like this...">
    -6
    </div>
  </div>
  <a href="#111396" class="name">
  <strong class="user"><em>Dean Jenkins</em></strong></a><a class="genanchor" href="#111396"> &para;</a><div class="date" title="2013-02-15 07:02"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom111396">
<div class="phpcode"><code><span class="html">
To get the name and web path of the current script<br /><br /><span class="default">&lt;?php<br />$scriptname</span><span class="keyword">=</span><span class="default">end</span><span class="keyword">(</span><span class="default">explode</span><span class="keyword">(</span><span class="string">'/'</span><span class="keyword">,</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_SELF'</span><span class="keyword">]));<br /></span><span class="default">$scriptpath</span><span class="keyword">=</span><span class="default">str_replace</span><span class="keyword">(</span><span class="default">$scriptname</span><span class="keyword">,</span><span class="string">''</span><span class="keyword">,</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PHP_SELF'</span><span class="keyword">]);<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113697">  <div class="votes">
    <div id="Vu113697">
    <a href="/manual/vote-note.php?id=113697&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113697">
    <a href="/manual/vote-note.php?id=113697&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113697" title="38% like this...">
    -7
    </div>
  </div>
  <a href="#113697" class="name">
  <strong class="user"><em>sendmailz1987 at gmail dot com</em></strong></a><a class="genanchor" href="#113697"> &para;</a><div class="date" title="2013-11-18 09:13"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113697">
<div class="phpcode"><code><span class="html">
Example:<br /><br />$current = $_SERVER['SERVER_NAME'] . $_SERVER['PHP_SELF'];<br /><br />echo $current;<br /><br />will output the root to the current page, including url and document root, something like:<br /><br />example.com/users/profile.php</span>
</code></div>
  </div>
 </div>
  <div class="note" id="96356">  <div class="votes">
    <div id="Vu96356">
    <a href="/manual/vote-note.php?id=96356&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd96356">
    <a href="/manual/vote-note.php?id=96356&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V96356" title="38% like this...">
    -8
    </div>
  </div>
  <a href="#96356" class="name">
  <strong class="user"><em>Megan Mickelson</em></strong></a><a class="genanchor" href="#96356"> &para;</a><div class="date" title="2010-02-22 03:36"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom96356">
<div class="phpcode"><code><span class="html">
It makes sense to want to paste the $_SERVER['REQUEST_URI'] on to a page (like on a footer), but be sure to clean it up first with htmlspecialchars() otherwise it poses a cross-site scripting vulnerability.<br /><br />htmlspecialchars($_SERVER['REQUEST_URI']);<br /><br />e.g.<br /><a href="http://www.example.com/foo?&lt;script&gt;..." rel="nofollow" target="_blank">http://www.example.com/foo?&lt;script&gt;...</a><br /><br />becomes<br /><a href="http://www.example.com/foo?&amp;lt;script&amp;gt;..." rel="nofollow" target="_blank">http://www.example.com/foo?&amp;lt;script&amp;gt;...</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="115970">  <div class="votes">
    <div id="Vu115970">
    <a href="/manual/vote-note.php?id=115970&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115970">
    <a href="/manual/vote-note.php?id=115970&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115970" title="36% like this...">
    -6
    </div>
  </div>
  <a href="#115970" class="name">
  <strong class="user"><em>Gary Mathis</em></strong></a><a class="genanchor" href="#115970"> &para;</a><div class="date" title="2014-10-20 09:40"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115970">
<div class="phpcode"><code><span class="html">
The best way to see all variables within the $_SERVER array, that I have found, is as follows:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">foreach(</span><span class="default">$_SERVER </span><span class="keyword">as </span><span class="default">$key </span><span class="keyword">=&gt; </span><span class="default">$value</span><span class="keyword">){<br />echo </span><span class="string">'$_SERVER["'</span><span class="keyword">.</span><span class="default">$key</span><span class="keyword">.</span><span class="string">'"] = '</span><span class="keyword">.</span><span class="default">$value</span><span class="keyword">.</span><span class="string">"&lt;br /&gt;"</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />This will tell you which ones are available on your server and what they are set to.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="97351">  <div class="votes">
    <div id="Vu97351">
    <a href="/manual/vote-note.php?id=97351&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd97351">
    <a href="/manual/vote-note.php?id=97351&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V97351" title="36% like this...">
    -9
    </div>
  </div>
  <a href="#97351" class="name">
  <strong class="user"><em>kamazee at gmail dot com</em></strong></a><a class="genanchor" href="#97351"> &para;</a><div class="date" title="2010-04-15 06:41"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom97351">
<div class="phpcode"><code><span class="html">
$_SERVER['DOCUMENT_ROOT'] in different environments may has trailing slash or not, so be careful when including files from $_SERVER['DOCUMENT_ROOT']:<br /><span class="default">&lt;?php<br /></span><span class="keyword">include(</span><span class="default">dirname</span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'DOCUMENT_ROOT'</span><span class="keyword">]) . </span><span class="default">DIRECTORY_SEPARATOR </span><span class="keyword">. </span><span class="string">'file.php'</span><span class="keyword">)<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117307">  <div class="votes">
    <div id="Vu117307">
    <a href="/manual/vote-note.php?id=117307&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117307">
    <a href="/manual/vote-note.php?id=117307&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117307" title="33% like this...">
    -3
    </div>
  </div>
  <a href="#117307" class="name">
  <strong class="user"><em>joerg dot reinholz at fastix dot org</em></strong></a><a class="genanchor" href="#117307"> &para;</a><div class="date" title="2015-05-19 08:29"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117307">
<div class="phpcode"><code><span class="html">
On a few of servers (e.g, Strato AG Germany, shared hosting)&nbsp; $_SERVER["DOCUMENT_ROOT"] follow symlinks (while so configured by admins)<br /><br />This is a problem while __DIR__ give the realpath.&nbsp; Try the error with this small script inside of&nbsp; DOCUMENT_ROOT:<br /><br /><span class="default">&lt;?php<br />header</span><span class="keyword">(</span><span class="string">'Content-type: text/plain'</span><span class="keyword">);<br />echo </span><span class="string">'__DIR__&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; : '</span><span class="keyword">, </span><span class="default">__DIR__ </span><span class="keyword">, </span><span class="string">"\n"</span><span class="keyword">;<br />echo </span><span class="string">'$_SERVER["DOCUMENT_ROOT"]&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; : '</span><span class="keyword">, </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">"DOCUMENT_ROOT"</span><span class="keyword">] , </span><span class="string">"\n"</span><span class="keyword">;<br />echo </span><span class="string">'realpath($_SERVER["DOCUMENT_ROOT"]): '</span><span class="keyword">, </span><span class="default">realpath</span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">"DOCUMENT_ROOT"</span><span class="keyword">]), </span><span class="string">"\n"</span><span class="keyword">;<br /><br /></span><span class="comment">## file 'include_me.php'<br /><br /># Exit, wenn in document_root, weil dann Sicherheitsproblem auftreten kann:<br /></span><span class="keyword">if (-</span><span class="default">1 </span><span class="keyword">&lt; </span><span class="default">strpos</span><span class="keyword">(</span><span class="default">__DIR__</span><span class="keyword">, </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">"DOCUMENT_ROOT"</span><span class="keyword">]) ) {<br />&nbsp; &nbsp; </span><span class="default">trigger_error</span><span class="keyword">(</span><span class="string">'Fatal: '</span><span class="keyword">. </span><span class="default">__FILE__<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="keyword">. </span><span class="string">' darf nicht in oder unterhalb von DOCUMENT_ROOT ('<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="keyword">. </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">"DOCUMENT_ROOT"</span><span class="keyword">] . </span><span class="string">') liegen!'</span><span class="keyword">, </span><span class="default">E_USER_ERROR</span><span class="keyword">);<br />&nbsp; &nbsp; exit;<br />}<br /></span><span class="default">?&gt;<br /></span>This will never trigger the error!<br /><br />Use better:<br /><span class="default">&lt;?php<br />header</span><span class="keyword">(</span><span class="string">'Content-type: text/plain'</span><span class="keyword">);<br />echo </span><span class="string">'__DIR__&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; : '</span><span class="keyword">, </span><span class="default">__DIR__ </span><span class="keyword">, </span><span class="string">"\n"</span><span class="keyword">;<br />echo </span><span class="string">'$_SERVER["DOCUMENT_ROOT"]&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; : '</span><span class="keyword">, </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">"DOCUMENT_ROOT"</span><span class="keyword">] , </span><span class="string">"\n"</span><span class="keyword">;<br />echo </span><span class="string">'realpath($_SERVER["DOCUMENT_ROOT"]): '</span><span class="keyword">, </span><span class="default">realpath</span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">"DOCUMENT_ROOT"</span><span class="keyword">]), </span><span class="string">"\n"</span><span class="keyword">;<br /><br /></span><span class="comment">## file 'include_me.php'<br /><br /># Exit, wenn in document_root, weil dann Sicherheitsproblem auftreten kann:<br /></span><span class="keyword">if (-</span><span class="default">1 </span><span class="keyword">&lt; </span><span class="default">strpos</span><span class="keyword">(</span><span class="default">__DIR__</span><span class="keyword">, </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">"DOCUMENT_ROOT"</span><span class="keyword">]) ) {<br />&nbsp; &nbsp; </span><span class="default">trigger_error</span><span class="keyword">(</span><span class="string">'Fatal: '</span><span class="keyword">. </span><span class="default">__FILE__<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="keyword">. </span><span class="string">' darf nicht in oder unterhalb von DOCUMENT_ROOT ('<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="keyword">. </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">"DOCUMENT_ROOT"</span><span class="keyword">] . </span><span class="string">') liegen!'</span><span class="keyword">, </span><span class="default">E_USER_ERROR</span><span class="keyword">);<br />&nbsp; &nbsp; exit;<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="111901">  <div class="votes">
    <div id="Vu111901">
    <a href="/manual/vote-note.php?id=111901&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd111901">
    <a href="/manual/vote-note.php?id=111901&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V111901" title="33% like this...">
    -8
    </div>
  </div>
  <a href="#111901" class="name">
  <strong class="user"><em>sabas88 at gmail dot com</em></strong></a><a class="genanchor" href="#111901"> &para;</a><div class="date" title="2013-04-10 10:46"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom111901">
<div class="phpcode"><code><span class="html">
I'm the author of this note<br /><a href="http://www.php.net/manual/en/reserved.variables.server.php#100881" rel="nofollow" target="_blank">http://www.php.net/manual/en/reserved.variables.server.php#100881</a><br /><br />I optimized since that note the path function, basically added detection of windows slashes and a partial option<br /><br />Now is released on github<br /><br /><a href="https://github.com/sabas/magicpath" rel="nofollow" target="_blank">https://github.com/sabas/magicpath</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="86309">  <div class="votes">
    <div id="Vu86309">
    <a href="/manual/vote-note.php?id=86309&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86309">
    <a href="/manual/vote-note.php?id=86309&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86309" title="34% like this...">
    -8
    </div>
  </div>
  <a href="#86309" class="name">
  <strong class="user"><em>Taomyn</em></strong></a><a class="genanchor" href="#86309"> &para;</a><div class="date" title="2008-10-12 07:21"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86309">
<div class="phpcode"><code><span class="html">
'HTTPS'<br />&nbsp; &nbsp; Set to a non-empty value if the script was queried through the HTTPS protocol. Note that when using ISAPI with IIS, the value will be off if the request was not made through the HTTPS protocol. <br /><br />Does the same for IIS7 running PHP as a Fast-CGI application.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="100877">  <div class="votes">
    <div id="Vu100877">
    <a href="/manual/vote-note.php?id=100877&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd100877">
    <a href="/manual/vote-note.php?id=100877&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V100877" title="34% like this...">
    -14
    </div>
  </div>
  <a href="#100877" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#100877"> &para;</a><div class="date" title="2010-11-12 04:22"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom100877">
<div class="phpcode"><code><span class="html">
Use Strict-Transport-Security (STS) to force the use of SSL.<br /><span class="default">&lt;?php<br />$use_sts </span><span class="keyword">= </span><span class="default">TRUE</span><span class="keyword">;<br /><br />if (</span><span class="default">$use_sts </span><span class="keyword">&amp;&amp; isset(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'HTTPS'</span><span class="keyword">]) {<br />&nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">'Strict-Transport-Security: max-age=500'</span><span class="keyword">);<br />} elseif (</span><span class="default">$use_sts </span><span class="keyword">&amp;&amp; !isset(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'HTTPS'</span><span class="keyword">]) {<br />&nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">'Status-Code: 301'</span><span class="keyword">);<br />&nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">'Location: <a href="https://" rel="nofollow" target="_blank">https://</a>'</span><span class="keyword">.</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">"HTTP_HOST"</span><span class="keyword">].</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'REQUEST_URI'</span><span class="keyword">]);<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="90592">  <div class="votes">
    <div id="Vu90592">
    <a href="/manual/vote-note.php?id=90592&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd90592">
    <a href="/manual/vote-note.php?id=90592&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V90592" title="34% like this...">
    -12
    </div>
  </div>
  <a href="#90592" class="name">
  <strong class="user"><em>dragon[dot]dionysius[at]gmail[dot]com</em></strong></a><a class="genanchor" href="#90592"> &para;</a><div class="date" title="2009-04-29 10:53"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom90592">
<div class="phpcode"><code><span class="html">
I've updated the function of my previous poster and putted it into my class.<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * Checking HTTP-Header for language<br />&nbsp; &nbsp;&nbsp; * needed for various system classes<br />&nbsp; &nbsp;&nbsp; * <br />&nbsp; &nbsp;&nbsp; * @return&nbsp; &nbsp; boolean&nbsp; &nbsp; true/false <br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">private function </span><span class="default">_checkClientLanguage</span><span class="keyword">()<br />&nbsp; &nbsp; {&nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$langcode </span><span class="keyword">= (!empty(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'HTTP_ACCEPT_LANGUAGE'</span><span class="keyword">])) ? </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'HTTP_ACCEPT_LANGUAGE'</span><span class="keyword">] : </span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$langcode </span><span class="keyword">= (!empty(</span><span class="default">$langcode</span><span class="keyword">)) ? </span><span class="default">explode</span><span class="keyword">(</span><span class="string">";"</span><span class="keyword">, </span><span class="default">$langcode</span><span class="keyword">) : </span><span class="default">$langcode</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$langcode </span><span class="keyword">= (!empty(</span><span class="default">$langcode</span><span class="keyword">[</span><span class="string">'0'</span><span class="keyword">])) ? </span><span class="default">explode</span><span class="keyword">(</span><span class="string">","</span><span class="keyword">, </span><span class="default">$langcode</span><span class="keyword">[</span><span class="string">'0'</span><span class="keyword">]) : </span><span class="default">$langcode</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$langcode </span><span class="keyword">= (!empty(</span><span class="default">$langcode</span><span class="keyword">[</span><span class="string">'0'</span><span class="keyword">])) ? </span><span class="default">explode</span><span class="keyword">(</span><span class="string">"-"</span><span class="keyword">, </span><span class="default">$langcode</span><span class="keyword">[</span><span class="string">'0'</span><span class="keyword">]) : </span><span class="default">$langcode</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$langcode</span><span class="keyword">[</span><span class="string">'0'</span><span class="keyword">];<br />&nbsp; &nbsp; }<br /></span><span class="default">?&gt;<br /></span><br />Please note, you have to check additional the result! Because the header may be missing or another possible thing, it is malformed. So check the result with a list with languages you support and perhaps you have to load a default language.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="comment">// if result isn't one of my defined languages<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">if(!</span><span class="default">in_array</span><span class="keyword">(</span><span class="default">$lang</span><span class="keyword">, </span><span class="default">$language_list</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$lang </span><span class="keyword">= </span><span class="default">$language_default</span><span class="keyword">; </span><span class="comment">// load default<br /><br /></span><span class="default">?&gt;<br /></span><br />My HTTP_ACCEPT_LANGUAGE string:<br />FF3: de-de,de;q=0.8,en-us;q=0.5,en;q=0.3 <br />IE7: de-ch<br /><br />So, take care of it!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114048">  <div class="votes">
    <div id="Vu114048">
    <a href="/manual/vote-note.php?id=114048&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114048">
    <a href="/manual/vote-note.php?id=114048&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114048" title="32% like this...">
    -10
    </div>
  </div>
  <a href="#114048" class="name">
  <strong class="user"><em>info at salientdigital dot com</em></strong></a><a class="genanchor" href="#114048"> &para;</a><div class="date" title="2014-01-06 08:46"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114048">
<div class="phpcode"><code><span class="html">
A word of caution...<br /><br />If you have some PHP code or file that is included from within a web request via Apache + PHP, as well as from a command line script, be very careful to inspect the keys inside of $_SERVER that you intend to use.<br /><br />The keys and values are different, and in fact, it also matters if you are running as your_user, sudo php from your_user, or from root. <br /><br />For example, I just found out that $_SERVER['PWD'] is not available if you run from the command line via sudo (PHP 5.2x, CentOS, YMMV).<br /><br />To make a test, create a file called server.php with the following content:<br /><br /><span class="default">&lt;?php<br />var_dump</span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />Then from the commandline:<br />your_account/dir #$ php server.php &gt; your_account_server.txt<br />your_account/dir #$ sudo php server.php &gt; your_account_sudo_server.txt<br />your_account/dir #$ sudo bash<br />root/dir #$ php server.php &gt; root_server.txt<br /><br />Now you can diff the output of each of these three files and inspect against what you get when viewing the $_SERVER section of phpinfo() from a web request. You may find the differences to be quite striking, in all, four different ways to run the same PHP file!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="85611">  <div class="votes">
    <div id="Vu85611">
    <a href="/manual/vote-note.php?id=85611&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd85611">
    <a href="/manual/vote-note.php?id=85611&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V85611" title="34% like this...">
    -12
    </div>
  </div>
  <a href="#85611" class="name">
  <strong class="user"><em>Andrew B</em></strong></a><a class="genanchor" href="#85611"> &para;</a><div class="date" title="2008-09-08 04:26"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom85611">
<div class="phpcode"><code><span class="html">
Please note on Windows/IIS - the variable 'USER_AUTH' will return the username/identity of the user accessing the page, i.e. if anonymous access is off, you would normally get back "$domain\$username".</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114777">  <div class="votes">
    <div id="Vu114777">
    <a href="/manual/vote-note.php?id=114777&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114777">
    <a href="/manual/vote-note.php?id=114777&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114777" title="32% like this...">
    -14
    </div>
  </div>
  <a href="#114777" class="name">
  <strong class="user"><em>Rodolfo Gonzalez Costa Rica</em></strong></a><a class="genanchor" href="#114777"> &para;</a><div class="date" title="2014-04-04 09:11"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114777">
<div class="phpcode"><code><span class="html">
This is a short script to know what values are defined <br /><br /><span class="default">&lt;?php <br /><br /></span><span class="keyword">echo </span><span class="string">"&lt;textarea&gt;"</span><span class="keyword">;<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">);<br />echo </span><span class="string">"&lt;/textarea&gt;"</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="83439">  <div class="votes">
    <div id="Vu83439">
    <a href="/manual/vote-note.php?id=83439&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd83439">
    <a href="/manual/vote-note.php?id=83439&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V83439" title="32% like this...">
    -12
    </div>
  </div>
  <a href="#83439" class="name">
  <strong class="user"><em>emailfire at gmail dot com</em></strong></a><a class="genanchor" href="#83439"> &para;</a><div class="date" title="2008-05-26 07:49"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom83439">
<div class="phpcode"><code><span class="html">
REQUEST_URI is useful, but if you want to get just the file name use:<br /><br /><span class="default">&lt;?php<br />$this_page </span><span class="keyword">= </span><span class="default">basename</span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'REQUEST_URI'</span><span class="keyword">]);<br />if (</span><span class="default">strpos</span><span class="keyword">(</span><span class="default">$this_page</span><span class="keyword">, </span><span class="string">"?"</span><span class="keyword">) !== </span><span class="default">false</span><span class="keyword">) </span><span class="default">$this_page </span><span class="keyword">= </span><span class="default">reset</span><span class="keyword">(</span><span class="default">explode</span><span class="keyword">(</span><span class="string">"?"</span><span class="keyword">, </span><span class="default">$this_page</span><span class="keyword">));<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="86495">  <div class="votes">
    <div id="Vu86495">
    <a href="/manual/vote-note.php?id=86495&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86495">
    <a href="/manual/vote-note.php?id=86495&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86495" title="33% like this...">
    -21
    </div>
  </div>
  <a href="#86495" class="name">
  <strong class="user"><em>Thomas Urban</em></strong></a><a class="genanchor" href="#86495"> &para;</a><div class="date" title="2008-10-22 01:19"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86495">
<div class="phpcode"><code><span class="html">
Maybe you're missing information on $_SERVER['CONTENT_TYPE'] or $_SERVER['CONTENT_LENGTH'] as I did. On POST-requests these are available in addition to those listed above.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114260">  <div class="votes">
    <div id="Vu114260">
    <a href="/manual/vote-note.php?id=114260&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114260">
    <a href="/manual/vote-note.php?id=114260&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114260" title="29% like this...">
    -19
    </div>
  </div>
  <a href="#114260" class="name">
  <strong class="user"><em>derniereclasse at gmail dot com</em></strong></a><a class="genanchor" href="#114260"> &para;</a><div class="date" title="2014-01-30 10:44"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114260">
<div class="phpcode"><code><span class="html">
About $_SERVER['REQUEST_METHOD']<br />return one of this values : <br /> 'GET', 'HEAD', 'POST', 'PUT'.&nbsp; <br />but can also return :<br />'OPTION'</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116015">  <div class="votes">
    <div id="Vu116015">
    <a href="/manual/vote-note.php?id=116015&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116015">
    <a href="/manual/vote-note.php?id=116015&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116015" title="27% like this...">
    -10
    </div>
  </div>
  <a href="#116015" class="name">
  <strong class="user"><em>softontherocks at gmail dot com</em></strong></a><a class="genanchor" href="#116015"> &para;</a><div class="date" title="2014-10-29 06:24"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom116015">
<div class="phpcode"><code><span class="html">
I want to share with you a full function to get the remote IP that calls a PHP url using the $_SERVER array.<br /><br />function getRealIP(){<br /> if( $_SERVER['HTTP_X_FORWARDED_FOR'] != '' ){<br />  $client_ip =<br />   ( !empty($_SERVER['REMOTE_ADDR']) ) ?<br />    $_SERVER['REMOTE_ADDR']<br />   :<br />            ( ( !empty($_ENV['REMOTE_ADDR']) ) ?<br />    $_ENV['REMOTE_ADDR']<br />    :<br />    "unknown" );<br /> <br />  $entries = split('[, ]', $_SERVER['HTTP_X_FORWARDED_FOR']);<br /> <br />  reset($entries);<br />  while (list(, $entry) = each($entries)){<br />   $entry = trim($entry);<br />   if ( preg_match("/^([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)/", $entry, $ip_list) ){<br />    // <a href="http://www.faqs.org/rfcs/rfc1918.html" rel="nofollow" target="_blank">http://www.faqs.org/rfcs/rfc1918.html</a><br />    $private_ip = array(<br />     '/^0\./',<br />     '/^127\.0\.0\.1/',<br />     '/^192\.168\..*/',<br />     '/^172\.((1[6-9])|(2[0-9])|(3[0-1]))\..*/',<br />     '/^10\..*/');<br /> <br />    $found_ip = preg_replace($private_ip, $client_ip, $ip_list[1]);<br /> <br />    if ($client_ip != $found_ip){<br />     $client_ip = $found_ip;<br />     break;<br />    }<br />   }<br />  }<br /> } else {<br />  $client_ip =<br />   ( !empty($_SERVER['REMOTE_ADDR']) ) ?<br />    $_SERVER['REMOTE_ADDR']<br />   :<br />    ( ( !empty($_ENV['REMOTE_ADDR']) ) ?<br />    $_ENV['REMOTE_ADDR']<br />    :<br />    "unknown" );<br /> }<br /> return $client_ip;<br />}<br /><br />This function was found in <a href="http://softontherocks.blogspot.com/2013/07/obtener-la-direccion-ip-que-solicita.html" rel="nofollow" target="_blank">http://softontherocks.blogspot.com/2013/07/obtener-la-direccion-ip-que-solicita.html</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="108186">  <div class="votes">
    <div id="Vu108186">
    <a href="/manual/vote-note.php?id=108186&amp;page=reserved.variables.server&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd108186">
    <a href="/manual/vote-note.php?id=108186&amp;page=reserved.variables.server&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V108186" title="25% like this...">
    -27
    </div>
  </div>
  <a href="#108186" class="name">
  <strong class="user"><em>LOL</em></strong></a><a class="genanchor" href="#108186"> &para;</a><div class="date" title="2012-04-05 01:26"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom108186">
<div class="phpcode"><code><span class="html">
For an hosting that use windows I have used this script to make REQUEST_URI to be correctly setted on IIS<br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">request_URI</span><span class="keyword">() {<br />&nbsp; &nbsp; if(!isset(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'REQUEST_URI'</span><span class="keyword">])) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'REQUEST_URI'</span><span class="keyword">] = </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'SCRIPT_NAME'</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'QUERY_STRING'</span><span class="keyword">]) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'REQUEST_URI'</span><span class="keyword">] .= </span><span class="string">'?' </span><span class="keyword">. </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'QUERY_STRING'</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; return </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'REQUEST_URI'</span><span class="keyword">];<br />}<br /></span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'REQUEST_URI'</span><span class="keyword">] = </span><span class="default">request_URI</span><span class="keyword">();<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=reserved.variables.server&amp;redirect=http://php.net/manual/en/reserved.variables.server.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="reserved.variables.php">Predefined Variables</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.variables.superglobals.php" title="Superglobals">Superglobals</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.globals.php" title="$GLOBALS">$GLOBALS</a>
                        </li>
                          
                        <li class="current">
                            <a href="reserved.variables.server.php" title="$_&#8203;SERVER">$_&#8203;SERVER</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.get.php" title="$_&#8203;GET">$_&#8203;GET</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.post.php" title="$_&#8203;POST">$_&#8203;POST</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.files.php" title="$_&#8203;FILES">$_&#8203;FILES</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.request.php" title="$_&#8203;REQUEST">$_&#8203;REQUEST</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.session.php" title="$_&#8203;SESSION">$_&#8203;SESSION</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.environment.php" title="$_&#8203;ENV">$_&#8203;ENV</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.cookies.php" title="$_&#8203;COOKIE">$_&#8203;COOKIE</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.phperrormsg.php" title="$php_&#8203;errormsg">$php_&#8203;errormsg</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.httprawpostdata.php" title="$HTTP_&#8203;RAW_&#8203;POST_&#8203;DATA">$HTTP_&#8203;RAW_&#8203;POST_&#8203;DATA</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.httpresponseheader.php" title="$http_&#8203;response_&#8203;header">$http_&#8203;response_&#8203;header</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.argc.php" title="$argc">$argc</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.argv.php" title="$argv">$argv</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

