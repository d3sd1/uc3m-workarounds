<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Type Hinting - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.oop5.typehinting.php">
 <link rel="shorturl" href="http://php.net/oop5.typehinting">
 <link rel="alternate" href="http://php.net/oop5.typehinting" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.oop5.php">
 <link rel="prev" href="http://php.net/manual/en/language.oop5.object-comparison.php">
 <link rel="next" href="http://php.net/manual/en/language.oop5.late-static-bindings.php">

 <link rel="alternate" href="http://php.net/manual/en/language.oop5.typehinting.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.oop5.typehinting.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.oop5.typehinting.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.oop5.typehinting.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.oop5.typehinting.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.oop5.typehinting.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.oop5.typehinting.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.oop5.typehinting.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.oop5.typehinting.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.oop5.typehinting.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.oop5.typehinting.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.oop5.late-static-bindings.php">
          Late Static Bindings &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.oop5.object-comparison.php">
          &laquo; Comparing Objects        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.oop5.php'>Classes and Objects</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.oop5.typehinting.php' selected="selected">English</option>
            <option value='pt_BR/language.oop5.typehinting.php'>Brazilian Portuguese</option>
            <option value='zh/language.oop5.typehinting.php'>Chinese (Simplified)</option>
            <option value='fr/language.oop5.typehinting.php'>French</option>
            <option value='de/language.oop5.typehinting.php'>German</option>
            <option value='ja/language.oop5.typehinting.php'>Japanese</option>
            <option value='ro/language.oop5.typehinting.php'>Romanian</option>
            <option value='ru/language.oop5.typehinting.php'>Russian</option>
            <option value='es/language.oop5.typehinting.php'>Spanish</option>
            <option value='tr/language.oop5.typehinting.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.oop5.typehinting.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.oop5.typehinting">Report a Bug</a>
    </div>
  </div><div id="language.oop5.typehinting" class="sect1">
 <h2 class="title">Type Hinting</h2>

 <p class="para">
  This documentation has moved to the
  <a href="functions.arguments.php#functions.arguments.type-declaration" class="link">function reference</a>.
 </p>
</div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.oop5.typehinting&amp;redirect=http://php.net/manual/en/language.oop5.typehinting.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">20 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="83442">  <div class="votes">
    <div id="Vu83442">
    <a href="/manual/vote-note.php?id=83442&amp;page=language.oop5.typehinting&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd83442">
    <a href="/manual/vote-note.php?id=83442&amp;page=language.oop5.typehinting&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V83442" title="68% like this...">
    65
    </div>
  </div>
  <a href="#83442" class="name">
  <strong class="user"><em>Daniel dot L dot Wood at Gmail dot Com</em></strong></a><a class="genanchor" href="#83442"> &para;</a><div class="date" title="2008-05-26 11:00"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom83442">
<div class="phpcode"><code><span class="html">
People often ask about scalar/basic typehints.&nbsp; Here is a drop in class that I use in my MVC framework that will enable typehints through the use of a custom error handler.<br /><br />Note: You should include this code above all other code in your include headers and if you are the using set_error_handler() function you should be aware that this uses it as well.&nbsp; You may need to chain your set_error_handlers()<br /><br />Why?<br />1) Because people are sick of using the is_* functions to validate parameters.<br />2) Reduction of redundant coding for defensive coders.<br />3) Functions/Methods are self defining/documenting as to required input.<br /><br />Also..<br />Follow the discussion for typehints in PHP 6.0 on the PHP Internals boards.<br /><br /><span class="default">&lt;?php<br /><br />define</span><span class="keyword">(</span><span class="string">'TYPEHINT_PCRE'&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">,</span><span class="string">'/^Argument (\d)+ passed to (?:(\w+)::)?(\w+)\(\) must be an instance of (\w+), (\w+) given/'</span><span class="keyword">);<br /><br />class </span><span class="default">Typehint<br /></span><span class="keyword">{<br /><br />&nbsp; &nbsp; private static </span><span class="default">$Typehints </span><span class="keyword">= array(<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'boolean'&nbsp;&nbsp; </span><span class="keyword">=&gt; </span><span class="string">'is_bool'</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'integer'&nbsp;&nbsp; </span><span class="keyword">=&gt; </span><span class="string">'is_int'</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'float'&nbsp; &nbsp;&nbsp; </span><span class="keyword">=&gt; </span><span class="string">'is_float'</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'string'&nbsp; &nbsp; </span><span class="keyword">=&gt; </span><span class="string">'is_string'</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'resrouce'&nbsp; </span><span class="keyword">=&gt; </span><span class="string">'is_resource'<br />&nbsp; &nbsp; </span><span class="keyword">);<br /><br />&nbsp; &nbsp; private function </span><span class="default">__Constrct</span><span class="keyword">() {}<br /><br />&nbsp; &nbsp; public static function </span><span class="default">initializeHandler</span><span class="keyword">()<br />&nbsp; &nbsp; {<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">set_error_handler</span><span class="keyword">(</span><span class="string">'Typehint::handleTypehint'</span><span class="keyword">);<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">TRUE</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; private static function </span><span class="default">getTypehintedArgument</span><span class="keyword">(</span><span class="default">$ThBackTrace</span><span class="keyword">, </span><span class="default">$ThFunction</span><span class="keyword">, </span><span class="default">$ThArgIndex</span><span class="keyword">, &amp;</span><span class="default">$ThArgValue</span><span class="keyword">)<br />&nbsp; &nbsp; {<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; foreach (</span><span class="default">$ThBackTrace </span><span class="keyword">as </span><span class="default">$ThTrace</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Match the function; Note we could do more defensive error checking.<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">if (isset(</span><span class="default">$ThTrace</span><span class="keyword">[</span><span class="string">'function'</span><span class="keyword">]) &amp;&amp; </span><span class="default">$ThTrace</span><span class="keyword">[</span><span class="string">'function'</span><span class="keyword">] == </span><span class="default">$ThFunction</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$ThArgValue </span><span class="keyword">= </span><span class="default">$ThTrace</span><span class="keyword">[</span><span class="string">'args'</span><span class="keyword">][</span><span class="default">$ThArgIndex </span><span class="keyword">- </span><span class="default">1</span><span class="keyword">];<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">TRUE</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">FALSE</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public static function </span><span class="default">handleTypehint</span><span class="keyword">(</span><span class="default">$ErrLevel</span><span class="keyword">, </span><span class="default">$ErrMessage</span><span class="keyword">)<br />&nbsp; &nbsp; {<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$ErrLevel </span><span class="keyword">== </span><span class="default">E_RECOVERABLE_ERROR</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">preg_match</span><span class="keyword">(</span><span class="default">TYPEHINT_PCRE</span><span class="keyword">, </span><span class="default">$ErrMessage</span><span class="keyword">, </span><span class="default">$ErrMatches</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; list(</span><span class="default">$ErrMatch</span><span class="keyword">, </span><span class="default">$ThArgIndex</span><span class="keyword">, </span><span class="default">$ThClass</span><span class="keyword">, </span><span class="default">$ThFunction</span><span class="keyword">, </span><span class="default">$ThHint</span><span class="keyword">, </span><span class="default">$ThType</span><span class="keyword">) = </span><span class="default">$ErrMatches</span><span class="keyword">;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (isset(</span><span class="default">self</span><span class="keyword">::</span><span class="default">$Typehints</span><span class="keyword">[</span><span class="default">$ThHint</span><span class="keyword">]))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$ThBacktrace </span><span class="keyword">= </span><span class="default">debug_backtrace</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$ThArgValue&nbsp; </span><span class="keyword">= </span><span class="default">NULL</span><span class="keyword">;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">self</span><span class="keyword">::</span><span class="default">getTypehintedArgument</span><span class="keyword">(</span><span class="default">$ThBacktrace</span><span class="keyword">, </span><span class="default">$ThFunction</span><span class="keyword">, </span><span class="default">$ThArgIndex</span><span class="keyword">, </span><span class="default">$ThArgValue</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">call_user_func</span><span class="keyword">(</span><span class="default">self</span><span class="keyword">::</span><span class="default">$Typehints</span><span class="keyword">[</span><span class="default">$ThHint</span><span class="keyword">], </span><span class="default">$ThArgValue</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">TRUE</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">FALSE</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">Typehint</span><span class="keyword">::</span><span class="default">initializeHandler</span><span class="keyword">();<br /><br /></span><span class="default">?&gt;<br /></span><br />An are some examples of the class in use:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">teststring</span><span class="keyword">(</span><span class="default">string $string</span><span class="keyword">) { echo </span><span class="default">$string</span><span class="keyword">; }<br />function </span><span class="default">testinteger</span><span class="keyword">(</span><span class="default">integer $integer</span><span class="keyword">) { echo </span><span class="default">$integer</span><span class="keyword">; }<br />function </span><span class="default">testfloat</span><span class="keyword">(</span><span class="default">float $float</span><span class="keyword">) { echo </span><span class="default">$float</span><span class="keyword">; }<br /><br /></span><span class="comment">// This will work for class methods as well.<br /><br /></span><span class="default">?&gt;<br /></span><br />You get the picture..</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120442">  <div class="votes">
    <div id="Vu120442">
    <a href="/manual/vote-note.php?id=120442&amp;page=language.oop5.typehinting&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120442">
    <a href="/manual/vote-note.php?id=120442&amp;page=language.oop5.typehinting&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120442" title="100% like this...">
    3
    </div>
  </div>
  <a href="#120442" class="name">
  <strong class="user"><em>MiChAeLoKGB</em></strong></a><a class="genanchor" href="#120442"> &para;</a><div class="date" title="2017-01-10 05:23"><strong>11 months ago</strong></div>
  <div class="text" id="Hcom120442">
<div class="phpcode"><code><span class="html">
Please note, that with PHP 7, type hinting is faster than normal implementation.<br />This has to do with type hinting before PHP 7 allowing only objects and arrays and anything else (scalars) would throw an error.<br /><br />I did some using code "doom at doom dot pl" posted 2 years ago <br /><br />Here are results from couple of test runs using PHP 7 (200.000 loops)<br />- teststringNormal took: 0.01799488067627<br />- teststringOverhead took: 0.012195825576782<br /><br />- teststringNormal took: 0.027030944824219<br />- teststringOverhead took: 0.012197017669678<br /><br />- teststringNormal took: 0.017856121063232<br />- teststringOverhead took: 0.012274980545044<br /><br />As you can see, the overhead is faster and much more consistent.<br /><br />Here is one run with the is_string check removed from Normal:<br />- teststringNormal took: 0.010342836380005<br />- teststringOverhead took: 0.012849092483521</span>
</code></div>
  </div>
 </div>
  <div class="note" id="111411">  <div class="votes">
    <div id="Vu111411">
    <a href="/manual/vote-note.php?id=111411&amp;page=language.oop5.typehinting&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd111411">
    <a href="/manual/vote-note.php?id=111411&amp;page=language.oop5.typehinting&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V111411" title="80% like this...">
    33
    </div>
  </div>
  <a href="#111411" class="name">
  <strong class="user"><em>michaelrfairhurst at gmail dot com</em></strong></a><a class="genanchor" href="#111411"> &para;</a><div class="date" title="2013-02-17 09:46"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom111411">
<div class="phpcode"><code><span class="html">
The scalar type hinting solutions are all overthinking it. I provided the optimized regex version, as well as the fastest implementation I've come up with, which just uses strpos. Then I benchmark both against the TypeHint class.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">optimized_strpos</span><span class="keyword">(</span><span class="default">$ErrLevel</span><span class="keyword">, </span><span class="default">$ErrMessage</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$ErrLevel </span><span class="keyword">== </span><span class="default">E_RECOVERABLE_ERROR<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// order this according to what your app uses most<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">strpos</span><span class="keyword">(</span><span class="default">$ErrMessage</span><span class="keyword">, </span><span class="string">'must be an instance of string, string'</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; || </span><span class="default">strpos</span><span class="keyword">(</span><span class="default">$ErrMessage</span><span class="keyword">, </span><span class="string">'must be an instance of integer, integer'</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; || </span><span class="default">strpos</span><span class="keyword">(</span><span class="default">$ErrMessage</span><span class="keyword">, </span><span class="string">'must be an instance of float, double'</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; || </span><span class="default">strpos</span><span class="keyword">(</span><span class="default">$ErrMessage</span><span class="keyword">, </span><span class="string">'must be an instance of boolean, boolean'</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; || </span><span class="default">strpos</span><span class="keyword">(</span><span class="default">$ErrMessage</span><span class="keyword">, </span><span class="string">'must be an instance of resource, resource'</span><span class="keyword">);<br />}<br /><br />function </span><span class="default">optimized_regex</span><span class="keyword">(</span><span class="default">$ErrLevel</span><span class="keyword">, </span><span class="default">$ErrMessage</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$ErrLevel </span><span class="keyword">== </span><span class="default">E_RECOVERABLE_ERROR</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">preg_match</span><span class="keyword">(</span><span class="string">'/^Argument \d+ passed to (?:\w+::)?\w+\(\) must be an instance of (\w+), (\w+) given/'</span><span class="keyword">, </span><span class="default">$ErrMessage</span><span class="keyword">, </span><span class="default">$matches</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$matches</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">] == (</span><span class="default">$matches</span><span class="keyword">[</span><span class="default">2</span><span class="keyword">] == </span><span class="string">'double' </span><span class="keyword">? </span><span class="string">'float' </span><span class="keyword">: </span><span class="default">$matches</span><span class="keyword">[</span><span class="default">2</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />BENCHMARKING Typehint::handleTypehint()<br />string type hint.....[function it(string $var) {}]............2.1588530540466 seconds<br />float type hint......[function it(float $var) {}].............2.1563150882721 seconds<br />integer type hint....[function it(integer $var) {}]...........2.1579530239105 seconds<br />boolean type hint....[function it(boolean $var) {}]...........2.1590459346771 seconds<br /><br />BENCHMARKING optimized_regex()<br />string type hint.....[function it(string $var) {}]............0.88872504234314 seconds<br />float type hint......[function it(float $var) {}].............0.88528990745544 seconds<br />integer type hint....[function it(integer $var) {}]...........0.89038777351379 seconds<br />boolean type hint....[function it(boolean $var) {}]...........0.89061188697815 seconds<br /><br />BENCHMARKING optimized_strpos()<br />string type hint.....[function it(string $var) {}]............0.52635812759399 seconds<br />float type hint......[function it(float $var) {}].............0.74228310585022 seconds<br />integer type hint....[function it(integer $var) {}]...........0.63721108436584 seconds<br />boolean type hint....[function it(boolean $var) {}]...........0.8429491519928 seconds</span>
</code></div>
  </div>
 </div>
  <div class="note" id="79014">  <div class="votes">
    <div id="Vu79014">
    <a href="/manual/vote-note.php?id=79014&amp;page=language.oop5.typehinting&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd79014">
    <a href="/manual/vote-note.php?id=79014&amp;page=language.oop5.typehinting&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V79014" title="83% like this...">
    4
    </div>
  </div>
  <a href="#79014" class="name">
  <strong class="user"><em>jesdisciple @t gmail -dot- com</em></strong></a><a class="genanchor" href="#79014"> &para;</a><div class="date" title="2007-11-06 07:50"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom79014">
<div class="phpcode"><code><span class="html">
The manual's sample code says:<br /><span class="default">&lt;?php<br /></span><span class="comment">//...<br />// Fatal Error: Argument 1 must not be null<br /></span><span class="default">$myclass</span><span class="keyword">-&gt;</span><span class="default">test</span><span class="keyword">(</span><span class="default">null</span><span class="keyword">);<br /></span><span class="comment">//...<br /></span><span class="default">?&gt;<br /></span><br />And this is true, unless a default value of NULL is given; in fact, this is the only way to give a default value for object arguments (as a default value must be a constant expression):<br /><span class="default">&lt;?php<br />$mine </span><span class="keyword">= new </span><span class="default">MyClass</span><span class="keyword">();<br /></span><span class="default">$mine</span><span class="keyword">-&gt;</span><span class="default">test</span><span class="keyword">(</span><span class="default">NULL</span><span class="keyword">);<br />class </span><span class="default">MyClass</span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">OtherClass $arg </span><span class="keyword">= </span><span class="default">NULL</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">is_null</span><span class="keyword">(</span><span class="default">$arg</span><span class="keyword">)){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//Apply default value here.<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">}<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; public function </span><span class="default">test</span><span class="keyword">(array </span><span class="default">$arr </span><span class="keyword">= </span><span class="default">NULL</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$arr</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br />class </span><span class="default">OtherClass</span><span class="keyword">{<br />&nbsp; &nbsp; <br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114559">  <div class="votes">
    <div id="Vu114559">
    <a href="/manual/vote-note.php?id=114559&amp;page=language.oop5.typehinting&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114559">
    <a href="/manual/vote-note.php?id=114559&amp;page=language.oop5.typehinting&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114559" title="80% like this...">
    3
    </div>
  </div>
  <a href="#114559" class="name">
  <strong class="user"><em>doom at doom dot pl</em></strong></a><a class="genanchor" href="#114559"> &para;</a><div class="date" title="2014-03-06 09:16"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114559">
<div class="phpcode"><code><span class="html">
I've done some tests of the overhead that class Typehint&nbsp; gives us.<br />At my PC it goes as follows:<br />teststringNormal took: 0.041965961456299<br />teststringOverhead took: 0.48374915122986<br />It's like 10x longer time (not mention about memory usage), it's just because exception is thrown EVERY SINGLE TIME, along with expensive preg_match() and debug_backtrace() calls.<br />I think that using class in bigger applications will increase overhead like 100% or more.<br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">teststringOverhead</span><span class="keyword">(</span><span class="default">string $string</span><span class="keyword">) { <br />&nbsp; &nbsp; return </span><span class="default">$string</span><span class="keyword">;<br />}<br />function </span><span class="default">teststringNormal</span><span class="keyword">(</span><span class="default">$string</span><span class="keyword">){<br />&nbsp; &nbsp; if(!</span><span class="default">is_string</span><span class="keyword">(</span><span class="default">$string</span><span class="keyword">)){<br />&nbsp; &nbsp; &nbsp; &nbsp; return;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; return </span><span class="default">$string</span><span class="keyword">; <br />}<br /></span><span class="default">$loopTimes </span><span class="keyword">= </span><span class="default">20000</span><span class="keyword">;<br /><br /></span><span class="comment">/////////// test of overhead implementation vs normal<br /></span><span class="default">$t1 </span><span class="keyword">= </span><span class="default">microtime</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">);<br />for(</span><span class="default">$i </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">; </span><span class="default">$i </span><span class="keyword">&lt;= </span><span class="default">$loopTimes</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">++)&nbsp; </span><span class="default">teststringNormal</span><span class="keyword">(</span><span class="string">"xxx"</span><span class="keyword">);<br />echo </span><span class="string">"&lt;br&gt;teststringNormal took: " </span><span class="keyword">. (</span><span class="default">microtime</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">) - </span><span class="default">$t1</span><span class="keyword">);<br /><br /></span><span class="default">$t2 </span><span class="keyword">= </span><span class="default">microtime</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">);<br />for(</span><span class="default">$i </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">; </span><span class="default">$i </span><span class="keyword">&lt;= </span><span class="default">$loopTimes</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">++)&nbsp; </span><span class="default">teststringOverhead</span><span class="keyword">(</span><span class="string">"xxx"</span><span class="keyword">);<br />echo </span><span class="string">"&lt;br&gt;teststringOverhead took: " </span><span class="keyword">. (</span><span class="default">microtime</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">) - </span><span class="default">$t2</span><span class="keyword">);<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="88015">  <div class="votes">
    <div id="Vu88015">
    <a href="/manual/vote-note.php?id=88015&amp;page=language.oop5.typehinting&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd88015">
    <a href="/manual/vote-note.php?id=88015&amp;page=language.oop5.typehinting&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V88015" title="72% like this...">
    8
    </div>
  </div>
  <a href="#88015" class="name">
  <strong class="user"><em>bantam at banime dot com</em></strong></a><a class="genanchor" href="#88015"> &para;</a><div class="date" title="2009-01-06 02:53"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom88015">
<div class="phpcode"><code><span class="html">
Daniel's typehint implementation was just what I was looking for but performance in production wasn't going to cut it. Calling a backtrace every time hurts performance. For my implementation I didn't use it, after all, PHP tells us what the data type is in the error message, I don't feel I need to evaluate the argument where I am using typehinting. Here is the cut down version I use in my error handling class:<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">public static function </span><span class="default">typehint</span><span class="keyword">(</span><span class="default">$level</span><span class="keyword">, </span><span class="default">$message</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">$level </span><span class="keyword">== </span><span class="default">E_RECOVERABLE_ERROR</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">preg_match</span><span class="keyword">(</span><span class="string">'/^Argument (\d)+ passed to (?:(\w+)::)?(\w+)\(\) must be an instance of (\w+), (\w+) given/'</span><span class="keyword">, </span><span class="default">$message</span><span class="keyword">, </span><span class="default">$match</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">$match</span><span class="keyword">[</span><span class="default">4</span><span class="keyword">] == </span><span class="default">$match</span><span class="keyword">[</span><span class="default">5</span><span class="keyword">])<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">true</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /></span><span class="default">?&gt;<br /></span><br />Hope this can be of use to somebody.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="85527">  <div class="votes">
    <div id="Vu85527">
    <a href="/manual/vote-note.php?id=85527&amp;page=language.oop5.typehinting&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd85527">
    <a href="/manual/vote-note.php?id=85527&amp;page=language.oop5.typehinting&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V85527" title="75% like this...">
    4
    </div>
  </div>
  <a href="#85527" class="name">
  <strong class="user"><em>kalkamar at web dot de</em></strong></a><a class="genanchor" href="#85527"> &para;</a><div class="date" title="2008-09-04 02:24"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom85527">
<div class="phpcode"><code><span class="html">
I really like the Daniel`s Typehinting-Class, but you please not that it may be relevant for the performance if you use Typehinting for scalar values very often.<br /><br />Here is my performance-test:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">notypehinting</span><span class="keyword">(</span><span class="default">$x</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="default">is_string</span><span class="keyword">(</span><span class="default">$x</span><span class="keyword">);&nbsp;&nbsp; </span><span class="comment">//checking the type manually instead<br /></span><span class="keyword">}<br /><br />function </span><span class="default">typehinting</span><span class="keyword">(</span><span class="default">string $x</span><span class="keyword">)<br />{<br />}<br /><br /></span><span class="default">$test</span><span class="keyword">=new </span><span class="default">timer</span><span class="keyword">;<br />for(</span><span class="default">$i</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">;</span><span class="default">$i</span><span class="keyword">&lt;</span><span class="default">10000</span><span class="keyword">;</span><span class="default">$i</span><span class="keyword">++)<br />{<br />try{<br />&nbsp; &nbsp; </span><span class="default">notypehinting</span><span class="keyword">(</span><span class="string">'test'</span><span class="keyword">);<br />}<br />catch(</span><span class="default">Exception $e</span><span class="keyword">){}<br />}<br />echo </span><span class="default">$test</span><span class="keyword">.</span><span class="string">'&lt;br&gt;'</span><span class="keyword">;<br /><br /></span><span class="default">$test2</span><span class="keyword">=new </span><span class="default">timer</span><span class="keyword">;<br />for(</span><span class="default">$i</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">;</span><span class="default">$i</span><span class="keyword">&lt;</span><span class="default">10000</span><span class="keyword">;</span><span class="default">$i</span><span class="keyword">++)<br />{<br />try{<br />&nbsp; &nbsp; </span><span class="default">typehinting</span><span class="keyword">(</span><span class="string">'test'</span><span class="keyword">);<br />}<br />catch(</span><span class="default">Exception $e</span><span class="keyword">){}<br />}<br />echo </span><span class="default">$test2</span><span class="keyword">.</span><span class="string">'&lt;br&gt;'</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />Output:<br /><br />0.0088460445404053<br />0.21634602546692<br /><br />Result:<br />typehinting() ist more than 20 times slower than notypehinting()<br /><br />You see: typehinting for scalar types (like suggested by Daniel) is not the best thing for the performance if you use it very often.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="112033">  <div class="votes">
    <div id="Vu112033">
    <a href="/manual/vote-note.php?id=112033&amp;page=language.oop5.typehinting&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd112033">
    <a href="/manual/vote-note.php?id=112033&amp;page=language.oop5.typehinting&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V112033" title="66% like this...">
    3
    </div>
  </div>
  <a href="#112033" class="name">
  <strong class="user"><em>sorin dot badea91 at gmail dot com</em></strong></a><a class="genanchor" href="#112033"> &para;</a><div class="date" title="2013-04-25 03:05"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom112033">
<div class="phpcode"><code><span class="html">
I've implemented a basic function to ensure argument's type.<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">/**<br /> * Primary types<br /> */<br /></span><span class="keyword">class </span><span class="default">Type<br /></span><span class="keyword">{<br />&nbsp; &nbsp; const </span><span class="default">SKIP&nbsp; &nbsp;&nbsp; </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />&nbsp; &nbsp; const </span><span class="default">INT&nbsp; &nbsp; &nbsp; </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; const </span><span class="default">STRING&nbsp;&nbsp; </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">;<br />&nbsp; &nbsp; const </span><span class="default">BOOLEAN&nbsp; </span><span class="keyword">= </span><span class="default">3</span><span class="keyword">;<br />&nbsp; &nbsp; const </span><span class="default">CALLBACK </span><span class="keyword">= </span><span class="default">4</span><span class="keyword">;<br />&nbsp; &nbsp; const </span><span class="default">FLOAT&nbsp; &nbsp; </span><span class="keyword">= </span><span class="default">5</span><span class="keyword">;<br />&nbsp; &nbsp; const </span><span class="default">RESOURCE </span><span class="keyword">= </span><span class="default">6</span><span class="keyword">;<br />}<br /><br /></span><span class="comment">/**<br /> * @throws InvalidArgumentException<br /> */<br /></span><span class="keyword">function </span><span class="default">ensureType</span><span class="keyword">()<br />{<br />&nbsp; &nbsp; </span><span class="default">$debugStack </span><span class="keyword">= </span><span class="default">debug_backtrace</span><span class="keyword">();<br />&nbsp; &nbsp; </span><span class="default">$argv&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="keyword">= </span><span class="default">$debugStack</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">][</span><span class="string">'args'</span><span class="keyword">];<br />&nbsp; &nbsp; </span><span class="default">$types&nbsp; &nbsp; &nbsp; </span><span class="keyword">= </span><span class="default">func_get_args</span><span class="keyword">();<br />&nbsp; &nbsp; foreach (</span><span class="default">$argv </span><span class="keyword">as </span><span class="default">$key </span><span class="keyword">=&gt; </span><span class="default">$value</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$message </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">is_null</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; continue;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; switch (</span><span class="default">$types</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">]) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">Type</span><span class="keyword">::</span><span class="default">INT</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (!</span><span class="default">is_int</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$message </span><span class="keyword">= </span><span class="string">'Argument ' </span><span class="keyword">. </span><span class="default">$key </span><span class="keyword">. </span><span class="string">' passed to ' </span><span class="keyword">. </span><span class="default">$debugStack</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">][</span><span class="string">'function'</span><span class="keyword">] . </span><span class="string">'() must be of type int'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">Type</span><span class="keyword">::</span><span class="default">STRING</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (!</span><span class="default">is_string</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$message </span><span class="keyword">= </span><span class="string">'Argument ' </span><span class="keyword">. </span><span class="default">$key </span><span class="keyword">. </span><span class="string">' passed to ' </span><span class="keyword">. </span><span class="default">$debugStack</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">][</span><span class="string">'function'</span><span class="keyword">] . </span><span class="string">'() must be of type string'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">Type</span><span class="keyword">::</span><span class="default">BOOLEAN</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (!</span><span class="default">is_bool</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$message </span><span class="keyword">= </span><span class="string">'Argument ' </span><span class="keyword">. </span><span class="default">$key </span><span class="keyword">. </span><span class="string">' passed to ' </span><span class="keyword">. </span><span class="default">$debugStack</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">][</span><span class="string">'function'</span><span class="keyword">] . </span><span class="string">'() must be of type boolean'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">Type</span><span class="keyword">::</span><span class="default">CALLBACK</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (!</span><span class="default">is_callable</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$message </span><span class="keyword">= </span><span class="string">'Argument ' </span><span class="keyword">. </span><span class="default">$key </span><span class="keyword">. </span><span class="string">' passed to ' </span><span class="keyword">. </span><span class="default">$debugStack</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">][</span><span class="string">'function'</span><span class="keyword">] . </span><span class="string">'() must be a valid callback'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">Type</span><span class="keyword">::</span><span class="default">FLOAT</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (!</span><span class="default">is_float</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$message </span><span class="keyword">= </span><span class="string">'Argument ' </span><span class="keyword">. </span><span class="default">$key </span><span class="keyword">. </span><span class="string">' passed to ' </span><span class="keyword">. </span><span class="default">$debugStack</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">][</span><span class="string">'function'</span><span class="keyword">] . </span><span class="string">'() must be of type float'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">Type</span><span class="keyword">::</span><span class="default">RESOURCE</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (!</span><span class="default">is_resource</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$message </span><span class="keyword">= </span><span class="string">'Argument ' </span><span class="keyword">. </span><span class="default">$key </span><span class="keyword">. </span><span class="string">' passed to ' </span><span class="keyword">. </span><span class="default">$debugStack</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">][</span><span class="string">'function'</span><span class="keyword">] . </span><span class="string">'() must be of type resource'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; if (!</span><span class="default">is_null</span><span class="keyword">(</span><span class="default">$message</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">is_object</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$message </span><span class="keyword">.= </span><span class="string">', instance of ' </span><span class="keyword">. </span><span class="default">get_class</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">) . </span><span class="string">' given'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$message </span><span class="keyword">.= </span><span class="string">', ' </span><span class="keyword">. </span><span class="default">gettype</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">) . </span><span class="string">' given'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">InvalidArgumentException</span><span class="keyword">(</span><span class="default">$message</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />}<br /><br />function </span><span class="default">dummyFunction</span><span class="keyword">(</span><span class="default">$var1</span><span class="keyword">, </span><span class="default">$var2</span><span class="keyword">, </span><span class="default">$var3</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="default">ensureType</span><span class="keyword">(</span><span class="default">Type</span><span class="keyword">::</span><span class="default">BOOLEAN</span><span class="keyword">, </span><span class="default">Type</span><span class="keyword">::</span><span class="default">INT</span><span class="keyword">, </span><span class="default">Type</span><span class="keyword">::</span><span class="default">STRING</span><span class="keyword">);<br />}<br /><br /></span><span class="default">$object </span><span class="keyword">= new </span><span class="default">ReflectionClass</span><span class="keyword">(</span><span class="string">'ReflectionClass'</span><span class="keyword">);<br /><br /></span><span class="default">dummyFunction</span><span class="keyword">(</span><span class="default">1</span><span class="keyword">, </span><span class="default">$object</span><span class="keyword">, </span><span class="string">'Hello there'</span><span class="keyword">);</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="93405">  <div class="votes">
    <div id="Vu93405">
    <a href="/manual/vote-note.php?id=93405&amp;page=language.oop5.typehinting&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd93405">
    <a href="/manual/vote-note.php?id=93405&amp;page=language.oop5.typehinting&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V93405" title="60% like this...">
    1
    </div>
  </div>
  <a href="#93405" class="name">
  <strong class="user"><em>dpariyskiy at netatwork dot com</em></strong></a><a class="genanchor" href="#93405"> &para;</a><div class="date" title="2009-09-08 08:36"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom93405">
<div class="phpcode"><code><span class="html">
Daniel, thank you for the type hinting class. Very useful.<br />For anyone having a problem where php isn't setting Daniel's error handler, as was the case for me, try changing initializeHandler function to the following:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">public static function </span><span class="default">initializeHandler</span><span class="keyword">() <br />{<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="default">set_error_handler</span><span class="keyword">(array(</span><span class="string">'Typehint'</span><span class="keyword">,</span><span class="string">'handleTypehint'</span><span class="keyword">)); <br />&nbsp; &nbsp; <br />&nbsp; &nbsp; return </span><span class="default">TRUE</span><span class="keyword">; <br />}<br /></span><span class="default">?&gt;<br /></span><br />Hope this helps,<br />--Dmitriy</span>
</code></div>
  </div>
 </div>
  <div class="note" id="54501">  <div class="votes">
    <div id="Vu54501">
    <a href="/manual/vote-note.php?id=54501&amp;page=language.oop5.typehinting&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd54501">
    <a href="/manual/vote-note.php?id=54501&amp;page=language.oop5.typehinting&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V54501" title="60% like this...">
    1
    </div>
  </div>
  <a href="#54501" class="name">
  <strong class="user"><em>mlovett at morpace dot com</em></strong></a><a class="genanchor" href="#54501"> &para;</a><div class="date" title="2005-07-06 03:54"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom54501">
<div class="phpcode"><code><span class="html">
Type hinting works with interfaces too. In other words, you can specify the name of an interface for a function parameter, and the object passed in must implement that interface, or else type hinting throws an exception.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="84436">  <div class="votes">
    <div id="Vu84436">
    <a href="/manual/vote-note.php?id=84436&amp;page=language.oop5.typehinting&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd84436">
    <a href="/manual/vote-note.php?id=84436&amp;page=language.oop5.typehinting&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V84436" title="57% like this...">
    1
    </div>
  </div>
  <a href="#84436" class="name">
  <strong class="user"><em>marcus at ignorethis netweblogic dot com</em></strong></a><a class="genanchor" href="#84436"> &para;</a><div class="date" title="2008-07-14 06:18"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom84436">
<div class="phpcode"><code><span class="html">
Love the typehint object Daniel. Great effort!<br /><br />However, it still throws catchable fatal errors, which is not what I want, so I added one line to handleTypehint() so it throws an Exception.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">public static function </span><span class="default">handleTypehint</span><span class="keyword">(</span><span class="default">$ErrLevel</span><span class="keyword">, </span><span class="default">$ErrMessage</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$ErrLevel </span><span class="keyword">== </span><span class="default">E_RECOVERABLE_ERROR</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">preg_match </span><span class="keyword">( </span><span class="default">TYPEHINT_PCRE</span><span class="keyword">, </span><span class="default">$ErrMessage</span><span class="keyword">, </span><span class="default">$ErrMatches </span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; list ( </span><span class="default">$ErrMatch</span><span class="keyword">, </span><span class="default">$ThArgIndex</span><span class="keyword">, </span><span class="default">$ThClass</span><span class="keyword">, </span><span class="default">$ThFunction</span><span class="keyword">, </span><span class="default">$ThHint</span><span class="keyword">, </span><span class="default">$ThType </span><span class="keyword">) = </span><span class="default">$ErrMatches</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (isset ( </span><span class="default">self</span><span class="keyword">::</span><span class="default">$Typehints </span><span class="keyword">[</span><span class="default">$ThHint</span><span class="keyword">] )) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$ThBacktrace </span><span class="keyword">= </span><span class="default">debug_backtrace </span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$ThArgValue </span><span class="keyword">= </span><span class="default">NULL</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">self</span><span class="keyword">::</span><span class="default">getTypehintedArgument </span><span class="keyword">( </span><span class="default">$ThBacktrace</span><span class="keyword">, </span><span class="default">$ThFunction</span><span class="keyword">, </span><span class="default">$ThArgIndex</span><span class="keyword">, </span><span class="default">$ThArgValue </span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">call_user_func </span><span class="keyword">( </span><span class="default">self</span><span class="keyword">::</span><span class="default">$Typehints </span><span class="keyword">[</span><span class="default">$ThHint</span><span class="keyword">], </span><span class="default">$ThArgValue </span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">TRUE</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">Exception</span><span class="keyword">(</span><span class="default">$ErrMessage</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">FALSE</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119208">  <div class="votes">
    <div id="Vu119208">
    <a href="/manual/vote-note.php?id=119208&amp;page=language.oop5.typehinting&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119208">
    <a href="/manual/vote-note.php?id=119208&amp;page=language.oop5.typehinting&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119208" title="100% like this...">
    2
    </div>
  </div>
  <a href="#119208" class="name">
  <strong class="user"><em>mrice at rcs dot us</em></strong></a><a class="genanchor" href="#119208"> &para;</a><div class="date" title="2016-04-19 01:31"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119208">
<div class="phpcode"><code><span class="html">
In regards to <a href="http://php.net/manual/en/language.oop5.typehinting.php#103729" rel="nofollow" target="_blank">http://php.net/manual/en/language.oop5.typehinting.php#103729</a> , when using PHP in Eclipse, the best way to typehint is already available in Eclipse natively. <br /><br />The format is /* @var $variable ObjectName */<br /><br />The single /* is important. You can also use namespaces, IE <br /><br />/* @var $variable \Some\Namespace */<br /><br />In short, there is no reason to create functions that return itself.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117907">  <div class="votes">
    <div id="Vu117907">
    <a href="/manual/vote-note.php?id=117907&amp;page=language.oop5.typehinting&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117907">
    <a href="/manual/vote-note.php?id=117907&amp;page=language.oop5.typehinting&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117907" title="no votes...">
    0
    </div>
  </div>
  <a href="#117907" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#117907"> &para;</a><div class="date" title="2015-08-30 01:52"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117907">
<div class="phpcode"><code><span class="html">
i think this is pretty close.<br /><br />$lines=hhb_mustbe('array',file("foofile"));<br />//either file succeeds, and returns an array, or file returns FALSE which is not an array, which throws an unexpectedValueException.<br /><br />$socket=hhb_mustbe('Socket',socket_create(AF_INET,SOCK_STREAM,getprotobyname('tcp')));<br />//either socket_create succeeds, and returns a Socket, or socket_create returns False, which is not a resource of type Socket, and you get an UnexpectedValueException<br /><br />$size=hhb_mustbe('int',filesize(somefile));<br />//either filesize() returns an integer, or returns FALSE wich is not an int, and you'll get UnexpectedValueException.<br /><br />&nbsp; &nbsp; function hhb_mustbe(/*string*/$type,/*mixed*/$variable){<br />&nbsp; &nbsp; &nbsp; &nbsp; //should it be UnexpectedValueException or InvalidArgumentException?<br />&nbsp; &nbsp; &nbsp; &nbsp; //going with UnexpectedValueException for now...<br />&nbsp; &nbsp; &nbsp; &nbsp; $actual_type=gettype($variable);<br />&nbsp; &nbsp; &nbsp; &nbsp; if($actual_type==='unknown type'){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; //i dont know how this can happen, but it is documented as a possible return value of gettype...<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw new Exception('could not determine the type of the variable!');<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; if($actual_type==='object'){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(!is_a($variable,$type)){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $dbg=get_class($variable);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw new UnexpectedValueException('variable is an object which does NOT implement class: '.$type.'. it is of class: '.$dbg);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return $variable;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; if($actual_type==='resource'){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $dbg=get_resource_type($variable);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if($dbg!==$type){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw new UnexpectedValueException('variable is a resource, which is NOT of type: '.$type.'. it is of type: '.$dbg);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return $variable;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; //now a few special cases<br />&nbsp; &nbsp; &nbsp; &nbsp; if($type==='bool'){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $parsed_type='boolean';&nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; } else if($type==='int'){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $parsed_type='integer';<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; } else if($type==='float'){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $parsed_type='double';<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; } else if($type==='null'){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $parsed_type='NULL';<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; } else{<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $parsed_type=$type;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; if($parsed_type!==$actual_type &amp;&amp; $type!==$actual_type){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw new UnexpectedValueException('variable is NOT of type: '.$type.'. it is of type: '.$actual_type);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; //ok, variable passed all tests.<br />&nbsp; &nbsp; &nbsp; &nbsp; return $variable;<br />&nbsp; &nbsp; }</span>
</code></div>
  </div>
 </div>
  <div class="note" id="100543">  <div class="votes">
    <div id="Vu100543">
    <a href="/manual/vote-note.php?id=100543&amp;page=language.oop5.typehinting&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd100543">
    <a href="/manual/vote-note.php?id=100543&amp;page=language.oop5.typehinting&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V100543" title="100% like this...">
    1
    </div>
  </div>
  <a href="#100543" class="name">
  <strong class="user"><em>gdecad at NOSPAM dot example dot com</em></strong></a><a class="genanchor" href="#100543"> &para;</a><div class="date" title="2010-10-22 06:02"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom100543">
<div class="phpcode"><code><span class="html">
I have made a little bench between three method of type hinting for native type (string, integer, ...).<br /><br />First method : by test type in function like :<br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">testTest</span><span class="keyword">(</span><span class="default">$arg</span><span class="keyword">) {<br />&nbsp; &nbsp; if (!</span><span class="default">is_string</span><span class="keyword">(</span><span class="default">$arg</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">trigger_error</span><span class="keyword">(</span><span class="string">'Argument $arg passed to test must be an instance of string, other given'</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; return </span><span class="default">$arg</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />Second method : by object representing native type :<br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">testObject</span><span class="keyword">(</span><span class="default">StringObj $arg</span><span class="keyword">) {<br />&nbsp; &nbsp; return </span><span class="default">$arg</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />Third method : by class TypeHint proposed by Daniel :<br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">testHint</span><span class="keyword">(</span><span class="default">string $arg</span><span class="keyword">) {<br />&nbsp; &nbsp; return </span><span class="default">$arg</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />the results are here :<br />bench for 100000 iterations,&nbsp; in seconds<br />&nbsp; &nbsp; &nbsp; &nbsp; avg&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; min&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; max&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; total<br />test&nbsp; &nbsp; 5.3275489807129E-6&nbsp; &nbsp; 2.8610229492188E-6&nbsp; &nbsp; 0.0033020973205566&nbsp; &nbsp; 0.53275895118713<br />object&nbsp; &nbsp; 4.9089097976685E-6&nbsp; &nbsp; 3.814697265625E-6&nbsp; &nbsp; 0.0025870800018311&nbsp; &nbsp; 0.49089503288269<br />hint&nbsp; &nbsp; 3.2338891029358E-5&nbsp; &nbsp; 2.9802322387695E-5&nbsp; &nbsp; 0.0025920867919922&nbsp; &nbsp; 3.2338931560516<br /><br />As you can see, the method by object is the best<br />now you know...</span>
</code></div>
  </div>
 </div>
  <div class="note" id="103729">  <div class="votes">
    <div id="Vu103729">
    <a href="/manual/vote-note.php?id=103729&amp;page=language.oop5.typehinting&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd103729">
    <a href="/manual/vote-note.php?id=103729&amp;page=language.oop5.typehinting&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V103729" title="50% like this...">
    0
    </div>
  </div>
  <a href="#103729" class="name">
  <strong class="user"><em>john at cast dot com</em></strong></a><a class="genanchor" href="#103729"> &para;</a><div class="date" title="2011-04-29 06:33"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom103729">
<div class="phpcode"><code><span class="html">
i use eclipse ganymede as an IDE and it offers "intellisense" where it can, i.e. when variables are "declared" via type hinting or a "new"-statement . i found using the following pattern helps eclipse along as well:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">MyClass</span><span class="keyword">{<br /><br />&nbsp; public static function </span><span class="default">Cast</span><span class="keyword">(</span><span class="default">MyClass </span><span class="keyword">&amp;</span><span class="default">$object</span><span class="keyword">=</span><span class="default">NULL</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp;&nbsp; return </span><span class="default">$object</span><span class="keyword">;<br />&nbsp; }<br /><br />&nbsp; public </span><span class="default">method CallMe</span><span class="keyword">(){<br />&nbsp; }<br />}<br /><br /></span><span class="default">$x</span><span class="keyword">=</span><span class="default">unserialize</span><span class="keyword">(</span><span class="default">$someContent</span><span class="keyword">);<br /></span><span class="default">$x</span><span class="keyword">=</span><span class="default">MyObject</span><span class="keyword">::</span><span class="default">Cast</span><span class="keyword">(</span><span class="default">$x</span><span class="keyword">);<br /></span><span class="default">$x</span><span class="keyword">-&gt;</span><span class="default">CallMe</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span><br />after calling Cast(), due to the type hinting, eclipse offers me the "CallMe" function in a dropdown when i type "$x-&gt;" in the code afterwards.<br /><br />i found this very practical und included the Cast() function in my code template for new classes. i've been wondering, if there is a drawback i oversaw, but i haven't noticed any negative effects so far... maybe some of you will find this just as handy as i do ;o)<br /><br />p.s. do note: when used in inherited classes a STRICT-notice comes up, because the function definition of the inherited class doesn't match the parent's definition (different type hinting) - but it works great!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="85613">  <div class="votes">
    <div id="Vu85613">
    <a href="/manual/vote-note.php?id=85613&amp;page=language.oop5.typehinting&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd85613">
    <a href="/manual/vote-note.php?id=85613&amp;page=language.oop5.typehinting&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V85613" title="100% like this...">
    1
    </div>
  </div>
  <a href="#85613" class="name">
  <strong class="user"><em>DanielLWood [at] Gmail [dot] Com</em></strong></a><a class="genanchor" href="#85613"> &para;</a><div class="date" title="2008-09-08 05:59"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom85613">
<div class="phpcode"><code><span class="html">
To follow up on my original post dealing with the type hinting class I provided:<br /><br />Kalkamar is absolutely correct, it is slow and is a hack.&nbsp; Everyone who uses it and wants to see this type of syntax native needs to post on the 'php internals' development thread in support.<br /><br />Thanks,<br /><br />Dan</span>
</code></div>
  </div>
 </div>
  <div class="note" id="86592">  <div class="votes">
    <div id="Vu86592">
    <a href="/manual/vote-note.php?id=86592&amp;page=language.oop5.typehinting&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86592">
    <a href="/manual/vote-note.php?id=86592&amp;page=language.oop5.typehinting&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86592" title="50% like this...">
    0
    </div>
  </div>
  <a href="#86592" class="name">
  <strong class="user"><em>wickedmuso at gmail dot com</em></strong></a><a class="genanchor" href="#86592"> &para;</a><div class="date" title="2008-10-24 08:26"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86592">
<div class="phpcode"><code><span class="html">
One useful thing with Type Hinting that I could not find in the documentation (but tested) is that you can also use an Interface in the hint (versus a Class).&nbsp; This is a very useful tool if you are trying to code to Interfaces rather than Classes (which is common in Test Driven Development and Dependency Injection paradigms).&nbsp; It means your external class can present itself into the method as long as it implements the nominated Interface (obviously).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="86216">  <div class="votes">
    <div id="Vu86216">
    <a href="/manual/vote-note.php?id=86216&amp;page=language.oop5.typehinting&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86216">
    <a href="/manual/vote-note.php?id=86216&amp;page=language.oop5.typehinting&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86216" title="50% like this...">
    0
    </div>
  </div>
  <a href="#86216" class="name">
  <strong class="user"><em>info at thewebsiteguy dot com dot au</em></strong></a><a class="genanchor" href="#86216"> &para;</a><div class="date" title="2008-10-08 06:30"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86216">
<div class="phpcode"><code><span class="html">
I find it rather frustrating that PHP has internal data types but doesn't allow optional hinting for it.&nbsp; I REALLY needed it for something, so I found a way around it.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">abstract class </span><span class="default">DataType<br /></span><span class="keyword">{<br />&nbsp; &nbsp; protected </span><span class="default">$length</span><span class="keyword">;<br />&nbsp; &nbsp; protected </span><span class="default">$precision</span><span class="keyword">;<br />&nbsp; &nbsp; protected </span><span class="default">$number</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; public function </span><span class="default">__construct</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">number </span><span class="keyword">= </span><span class="default">false</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">precision </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br />&nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">GetLength</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">length</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">IsNumber</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">number</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">GetPrecision</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">precision</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">Integer </span><span class="keyword">extends </span><span class="default">DataType<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$length </span><span class="keyword">= </span><span class="default">12</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">parent</span><span class="keyword">::</span><span class="default">__construct</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">number </span><span class="keyword">= </span><span class="default">true</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">length </span><span class="keyword">= </span><span class="default">$length</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">precision </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">Float </span><span class="keyword">extends </span><span class="default">DataType<br /></span><span class="keyword">{<br />&nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$length </span><span class="keyword">= </span><span class="default">12</span><span class="keyword">, </span><span class="default">$precision </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">)<br />&nbsp; {<br />&nbsp; &nbsp; </span><span class="default">parent</span><span class="keyword">::</span><span class="default">__construct</span><span class="keyword">();<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">number </span><span class="keyword">= </span><span class="default">true</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">length </span><span class="keyword">= </span><span class="default">$length</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">precision </span><span class="keyword">= </span><span class="default">$precision</span><span class="keyword">;<br />&nbsp; }<br />}<br /><br />class </span><span class="default">String </span><span class="keyword">extends </span><span class="default">DataType<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$length </span><span class="keyword">= </span><span class="default">255</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">parent</span><span class="keyword">::</span><span class="default">__constructor</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">length </span><span class="keyword">= </span><span class="default">$length</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="comment">//etc etc through the types...<br /></span><span class="default">?&gt;<br /></span><br />then later I can do this...<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">final class </span><span class="default">Field<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$Name</span><span class="keyword">;<br />&nbsp; &nbsp; public </span><span class="default">$Mandatory</span><span class="keyword">;<br />&nbsp; &nbsp; public </span><span class="default">$Hidden</span><span class="keyword">;<br />&nbsp; &nbsp; public </span><span class="default">$ListField</span><span class="keyword">;<br />&nbsp; &nbsp; public </span><span class="default">$Value</span><span class="keyword">;<br />&nbsp; &nbsp; public </span><span class="default">$ForeignClass</span><span class="keyword">;<br />&nbsp; &nbsp; public </span><span class="default">$ReadOnly</span><span class="keyword">;<br />&nbsp; &nbsp; public </span><span class="default">$DataType</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">, </span><span class="default">DataType $dataType</span><span class="keyword">, </span><span class="default">$mandatory </span><span class="keyword">= </span><span class="default">false</span><span class="keyword">, </span><span class="default">$listField </span><span class="keyword">= </span><span class="default">true</span><span class="keyword">, </span><span class="default">$value </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">, </span><span class="default">$readOnly </span><span class="keyword">= </span><span class="default">false</span><span class="keyword">, </span><span class="default">BaseCBO $foreignClass </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">Name </span><span class="keyword">= </span><span class="default">$name</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">DataType </span><span class="keyword">= </span><span class="default">$dataType</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">Mandatory </span><span class="keyword">= </span><span class="default">$mandatory</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">ListField </span><span class="keyword">= </span><span class="default">$listField</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">Value </span><span class="keyword">= </span><span class="default">$value</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">ReadOnly </span><span class="keyword">= </span><span class="default">$readOnly</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">ForeignClass </span><span class="keyword">= </span><span class="default">$foreignClass</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="comment">// ....<br /><br /></span><span class="keyword">class </span><span class="default">DoSomeStuff<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">DoGenericThings</span><span class="keyword">(</span><span class="default">Field $field</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$field</span><span class="keyword">-&gt;</span><span class="default">DataType </span><span class="keyword">instanceof </span><span class="default">Integer</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// do things for an integer field...<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">}<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="86074">  <div class="votes">
    <div id="Vu86074">
    <a href="/manual/vote-note.php?id=86074&amp;page=language.oop5.typehinting&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd86074">
    <a href="/manual/vote-note.php?id=86074&amp;page=language.oop5.typehinting&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V86074" title="50% like this...">
    0
    </div>
  </div>
  <a href="#86074" class="name">
  <strong class="user"><em>wbcarts at juno dot com</em></strong></a><a class="genanchor" href="#86074"> &para;</a><div class="date" title="2008-10-01 06:20"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom86074">
<div class="phpcode"><code><span class="html">
TYPE-HINTING and VISIBILITY<br /><br />Type-hinting is just one more small piece of PHP that protects our objects when visibility cannot.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">Point </span><span class="keyword">{<br />&nbsp; public </span><span class="default">$x</span><span class="keyword">, </span><span class="default">$y</span><span class="keyword">;<br /><br />&nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$xVal </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">, </span><span class="default">$yVal </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">x </span><span class="keyword">= </span><span class="default">$xVal</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">y </span><span class="keyword">= </span><span class="default">$yVal</span><span class="keyword">;<br />&nbsp; }<br />}<br /><br />class </span><span class="default">Polyline </span><span class="keyword">{<br />&nbsp; protected </span><span class="default">$points </span><span class="keyword">= array();<br /><br />&nbsp; public function </span><span class="default">addPoint</span><span class="keyword">(</span><span class="default">Point $p</span><span class="keyword">) {&nbsp; </span><span class="comment">// the line we're interested in...<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">points</span><span class="keyword">[] = </span><span class="default">$p</span><span class="keyword">;<br />&nbsp; }<br />}<br /><br /></span><span class="default">$point1 </span><span class="keyword">= new </span><span class="default">Point</span><span class="keyword">(</span><span class="default">15</span><span class="keyword">, </span><span class="default">12</span><span class="keyword">);<br /></span><span class="default">$polyline </span><span class="keyword">= new </span><span class="default">Polyline</span><span class="keyword">();<br /></span><span class="default">$polyline</span><span class="keyword">-&gt;</span><span class="default">addPoint</span><span class="keyword">(</span><span class="default">$point1</span><span class="keyword">);<br /></span><span class="default">$polyline</span><span class="keyword">-&gt;</span><span class="default">addPoint</span><span class="keyword">(new </span><span class="default">Point</span><span class="keyword">(</span><span class="default">55</span><span class="keyword">, </span><span class="default">22</span><span class="keyword">));<br /></span><span class="default">$polyline</span><span class="keyword">-&gt;</span><span class="default">addPoint</span><span class="keyword">(new </span><span class="default">Point</span><span class="keyword">(</span><span class="default">33</span><span class="keyword">, </span><span class="default">31</span><span class="keyword">));<br /><br /></span><span class="default">$polyline</span><span class="keyword">-&gt;</span><span class="default">addPoint</span><span class="keyword">(new </span><span class="default">stdClass</span><span class="keyword">());&nbsp; &nbsp; </span><span class="comment">// PHP will throw an error for us!&nbsp; <br /><br /></span><span class="default">?&gt;<br /></span><br />Since our Polyline::addPoint() function has to be public, any outside code can try to pass anything. But, when type-hinting is declared, PHP throws an error when phoney data tries to sneak by.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="100550">  <div class="votes">
    <div id="Vu100550">
    <a href="/manual/vote-note.php?id=100550&amp;page=language.oop5.typehinting&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd100550">
    <a href="/manual/vote-note.php?id=100550&amp;page=language.oop5.typehinting&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V100550" title="33% like this...">
    -1
    </div>
  </div>
  <a href="#100550" class="name">
  <strong class="user"><em>alejosimon at gmail dot com</em></strong></a><a class="genanchor" href="#100550"> &para;</a><div class="date" title="2010-10-22 11:55"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom100550">
<div class="phpcode"><code><span class="html">
For PHP 5.3 version and namespaces support.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">phpErrorHandler</span><span class="keyword">( </span><span class="default">$code</span><span class="keyword">, </span><span class="default">$message</span><span class="keyword">, </span><span class="default">$file</span><span class="keyword">, </span><span class="default">$line </span><span class="keyword">) {<br /><br />&nbsp; &nbsp; if ( </span><span class="default">error_reporting</span><span class="keyword">() &amp; </span><span class="default">$code </span><span class="keyword">) {<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; if ( </span><span class="default">$code </span><span class="keyword">== </span><span class="default">E_RECOVERABLE_ERROR </span><span class="keyword">) { </span><span class="comment">// Scalar Type-Hinting patch.<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$regexp </span><span class="keyword">= </span><span class="string">'/^Argument (\d)+ passed to (.+) must be an instance of (?&lt;hint&gt;.+), (?&lt;given&gt;.+) given/i' </span><span class="keyword">;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if ( </span><span class="default">preg_match</span><span class="keyword">( </span><span class="default">$regexp</span><span class="keyword">, </span><span class="default">$message</span><span class="keyword">, </span><span class="default">$match </span><span class="keyword">) ) {<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$given </span><span class="keyword">= </span><span class="default">$match</span><span class="keyword">[ </span><span class="string">'given' </span><span class="keyword">] ;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$hint&nbsp; </span><span class="keyword">= </span><span class="default">end</span><span class="keyword">( </span><span class="default">explode</span><span class="keyword">( </span><span class="string">'\\'</span><span class="keyword">, </span><span class="default">$match</span><span class="keyword">[ </span><span class="string">'hint' </span><span class="keyword">] ) ) ; </span><span class="comment">// namespaces support.<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">if ( </span><span class="default">$hint </span><span class="keyword">== </span><span class="default">$given </span><span class="keyword">) return </span><span class="default">true </span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">false </span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">set_error_handler</span><span class="keyword">( </span><span class="string">'phpErrorHandler' </span><span class="keyword">) ;<br /><br /></span><span class="comment">/************************************/<br /><br /></span><span class="keyword">function </span><span class="default">typeHintTest</span><span class="keyword">( </span><span class="default">integer $arg1 </span><span class="keyword">) {<br /><br />&nbsp; &nbsp; </span><span class="default">print_r</span><span class="keyword">( </span><span class="default">$arg1 </span><span class="keyword">) ;<br />}<br /><br /></span><span class="default">typeHintTest</span><span class="keyword">( </span><span class="default">true </span><span class="keyword">) ; </span><span class="comment">// Error throw because not integer type.<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.oop5.typehinting&amp;redirect=http://php.net/manual/en/language.oop5.typehinting.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.oop5.php">Classes and Objects</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="oop5.intro.php" title="Introduction">Introduction</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.basic.php" title="The Basics">The Basics</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.properties.php" title="Properties">Properties</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.constants.php" title="Class Constants">Class Constants</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.autoload.php" title="Autoloading Classes">Autoloading Classes</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.decon.php" title="Constructors and Destructors">Constructors and Destructors</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.visibility.php" title="Visibility">Visibility</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.inheritance.php" title="Object Inheritance">Object Inheritance</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.paamayim-nekudotayim.php" title="Scope Resolution Operator (::)">Scope Resolution Operator (::)</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.static.php" title="Static Keyword">Static Keyword</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.abstract.php" title="Class Abstraction">Class Abstraction</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.interfaces.php" title="Object Interfaces">Object Interfaces</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.traits.php" title="Traits">Traits</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.anonymous.php" title="Anonymous classes">Anonymous classes</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.overloading.php" title="Overloading">Overloading</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.iterations.php" title="Object Iteration">Object Iteration</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.magic.php" title="Magic Methods">Magic Methods</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.final.php" title="Final Keyword">Final Keyword</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.cloning.php" title="Object Cloning">Object Cloning</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.object-comparison.php" title="Comparing Objects">Comparing Objects</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.oop5.typehinting.php" title="Type Hinting">Type Hinting</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.late-static-bindings.php" title="Late Static Bindings">Late Static Bindings</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.references.php" title="Objects and references">Objects and references</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.serialization.php" title="Object Serialization">Object Serialization</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.changelog.php" title="OOP Changelog">OOP Changelog</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

