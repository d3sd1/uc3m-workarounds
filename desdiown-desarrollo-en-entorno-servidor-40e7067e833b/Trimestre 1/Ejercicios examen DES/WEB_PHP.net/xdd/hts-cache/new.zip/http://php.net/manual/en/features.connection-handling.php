<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Connection handling - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/features.connection-handling.php">
 <link rel="shorturl" href="http://php.net/connection-handling">
 <link rel="alternate" href="http://php.net/connection-handling" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/features.php">
 <link rel="prev" href="http://php.net/manual/en/features.remote-files.php">
 <link rel="next" href="http://php.net/manual/en/features.persistent-connections.php">

 <link rel="alternate" href="http://php.net/manual/en/features.connection-handling.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/features.connection-handling.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/features.connection-handling.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/features.connection-handling.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/features.connection-handling.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/features.connection-handling.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/features.connection-handling.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/features.connection-handling.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/features.connection-handling.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/features.connection-handling.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/features.connection-handling.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="features.persistent-connections.php">
          Persistent Database Connections &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="features.remote-files.php">
          &laquo; Using remote files        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='features.php'>Features</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/features.connection-handling.php' selected="selected">English</option>
            <option value='pt_BR/features.connection-handling.php'>Brazilian Portuguese</option>
            <option value='zh/features.connection-handling.php'>Chinese (Simplified)</option>
            <option value='fr/features.connection-handling.php'>French</option>
            <option value='de/features.connection-handling.php'>German</option>
            <option value='ja/features.connection-handling.php'>Japanese</option>
            <option value='ro/features.connection-handling.php'>Romanian</option>
            <option value='ru/features.connection-handling.php'>Russian</option>
            <option value='es/features.connection-handling.php'>Spanish</option>
            <option value='tr/features.connection-handling.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/features.connection-handling.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=features.connection-handling">Report a Bug</a>
    </div>
  </div><div id="features.connection-handling" class="chapter">
  <h1>Connection handling</h1>


  <p class="para">
   Internally in PHP a connection status is maintained.  There are 4
   possible states:
   <ul class="itemizedlist">
    <li class="listitem"><span class="simpara">0 - NORMAL</span></li>
    <li class="listitem"><span class="simpara">1 - ABORTED</span></li>
    <li class="listitem"><span class="simpara">2 - TIMEOUT</span></li>
    <li class="listitem"><span class="simpara">3 - ABORTED and TIMEOUT</span></li>
   </ul>
  </p>

  <p class="simpara">
   When a PHP script is running normally, the NORMAL state is active.
   If the remote client disconnects, the ABORTED state flag is
   turned on.  A remote client disconnect is usually caused by the
   user hitting his STOP button.  If the PHP-imposed time limit (see
   <span class="function"><a href="function.set-time-limit.php" class="function">set_time_limit()</a></span>) is hit, the TIMEOUT state flag
   is turned on.</p>

  <p class="simpara">
   You can decide whether or not you want a client disconnect to cause
   your script to be aborted.  Sometimes it is handy to always have your
   scripts run to completion even if there is no remote browser receiving
   the output.  The default behaviour is however for your script to be
   aborted when the remote client disconnects.  This behaviour can be
   set via the ignore_user_abort <var class="filename">php.ini</var> directive as well as through
   the corresponding <em>php_value ignore_user_abort</em> Apache 
   <var class="filename">httpd.conf</var> directive or
   with the <span class="function"><a href="function.ignore-user-abort.php" class="function">ignore_user_abort()</a></span> function.  If you do
   not tell PHP to ignore a user abort and the user aborts, your script
   will terminate.  The one exception is if you have registered a shutdown
   function using <span class="function"><a href="function.register-shutdown-function.php" class="function">register_shutdown_function()</a></span>.  With a
   shutdown function, when the remote user hits his STOP button, the
   next time your script tries to output something PHP will detect that
   the connection has been aborted and the shutdown function is called.
   This shutdown function will also get called at the end of your script
   terminating normally, so to do something different in case of a client
   disconnect you can use the <span class="function"><a href="function.connection-aborted.php" class="function">connection_aborted()</a></span>
   function.  This function will return <strong><code>TRUE</code></strong> if the connection was
   aborted.</p>

  <p class="simpara">
   Your script can also be terminated by the built-in script timer.
   The default timeout is 30 seconds.  It can be changed using
   the <strong class="option unknown">max_execution_time</strong>
 <var class="filename">php.ini</var> directive or the corresponding
   <em>php_value max_execution_time</em> Apache <var class="filename">httpd.conf</var>
   directive as well as with
   the <span class="function"><a href="function.set-time-limit.php" class="function">set_time_limit()</a></span> function.  When the timer
   expires the script will be aborted and as with the above client
   disconnect case, if a shutdown function has been registered it will
   be called.  Within this shutdown function you can check to see if
   a timeout caused the shutdown function to be called by calling the
   <span class="function"><a href="function.connection-status.php" class="function">connection_status()</a></span> function.  This function will
   return 2 if a timeout caused the shutdown function to be called.
  </p>

  <p class="simpara">
   One thing to note is that both the ABORTED and the TIMEOUT states
   can be active at the same time.  This is possible if you tell
   PHP to ignore user aborts.  PHP will still note the fact that
   a user may have broken the connection, but the script will keep
   running.  If it then hits the time limit it will be aborted and
   your shutdown function, if any, will be called.  At this point
   you will find that <span class="function"><a href="function.connection-status.php" class="function">connection_status()</a></span>
   returns 3.
  </p>
 </div>

<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=features.connection-handling&amp;redirect=http://php.net/manual/en/features.connection-handling.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">12 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="93441">  <div class="votes">
    <div id="Vu93441">
    <a href="/manual/vote-note.php?id=93441&amp;page=features.connection-handling&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd93441">
    <a href="/manual/vote-note.php?id=93441&amp;page=features.connection-handling&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V93441" title="69% like this...">
    27
    </div>
  </div>
  <a href="#93441" class="name">
  <strong class="user"><em>tom lgold2003 at gmail dot com</em></strong></a><a class="genanchor" href="#93441"> &para;</a><div class="date" title="2009-09-09 11:43"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom93441">
<div class="phpcode"><code><span class="html">
hey, thanks to arr1, and it is very useful for me, when I need to return to the user fast and then do something else.<br /><br />When using the codes, it nearly drive me mad and I found another thing that may affect the codes:<br /><br />Content-Encoding: gzip<br /><br />This is because the zlib is on and the content will be compressed. But this will not output the buffer until all output is over.<br /><br />So, it may need to send the header to prevent this problem.<br /><br />now, the code becomes:<br /><br /><span class="default">&lt;?php<br />ob_end_clean</span><span class="keyword">();<br /></span><span class="default">header</span><span class="keyword">(</span><span class="string">"Connection: close\r\n"</span><span class="keyword">);<br /></span><span class="default">header</span><span class="keyword">(</span><span class="string">"Content-Encoding: none\r\n"</span><span class="keyword">);<br /></span><span class="default">ignore_user_abort</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">); </span><span class="comment">// optional<br /></span><span class="default">ob_start</span><span class="keyword">();<br />echo (</span><span class="string">'Text user will see'</span><span class="keyword">);<br /></span><span class="default">$size </span><span class="keyword">= </span><span class="default">ob_get_length</span><span class="keyword">();<br /></span><span class="default">header</span><span class="keyword">(</span><span class="string">"Content-Length: </span><span class="default">$size</span><span class="string">"</span><span class="keyword">);<br /></span><span class="default">ob_end_flush</span><span class="keyword">();&nbsp; &nbsp;&nbsp; </span><span class="comment">// Strange behaviour, will not work<br /></span><span class="default">flush</span><span class="keyword">();&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Unless both are called !<br /></span><span class="default">ob_end_clean</span><span class="keyword">();<br /><br /></span><span class="comment">//do processing here<br /></span><span class="default">sleep</span><span class="keyword">(</span><span class="default">5</span><span class="keyword">);<br /><br />echo(</span><span class="string">'Text user will never see'</span><span class="keyword">);<br /></span><span class="comment">//do some processing<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="112843">  <div class="votes">
    <div id="Vu112843">
    <a href="/manual/vote-note.php?id=112843&amp;page=features.connection-handling&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd112843">
    <a href="/manual/vote-note.php?id=112843&amp;page=features.connection-handling&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V112843" title="68% like this...">
    16
    </div>
  </div>
  <a href="#112843" class="name">
  <strong class="user"><em>mheumann at comciencia dot cl</em></strong></a><a class="genanchor" href="#112843"> &para;</a><div class="date" title="2013-07-29 02:38"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom112843">
<div class="phpcode"><code><span class="html">
I had a lot of problems getting a redirect to work, after which my script was intended to keep working in the background. The redirect to another page of my site simply would only work once the original page had finished processing.<br /><br />I finally found out what was wrong:<br />The session only gets closed by PHP at the very end of the script, and since access to the session data is locked to prevent more than one page writing to it simultaneously, the new page cannot load until the original processing has finished.<br /><br />Solution:<br />Close the session manually when redirecting using session_write_close():<br /><br /><span class="default">&lt;?php<br />ignore_user_abort</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">);<br /></span><span class="default">set_time_limit</span><span class="keyword">(</span><span class="default">0</span><span class="keyword">);<br /><br /></span><span class="default">$strURL </span><span class="keyword">= </span><span class="string">"PUT YOUR REDIRCT HERE"</span><span class="keyword">;<br /></span><span class="default">header</span><span class="keyword">(</span><span class="string">"Location: </span><span class="default">$strURL</span><span class="string">"</span><span class="keyword">, </span><span class="default">true</span><span class="keyword">);<br /></span><span class="default">header</span><span class="keyword">(</span><span class="string">"Connection: close"</span><span class="keyword">, </span><span class="default">true</span><span class="keyword">);<br /></span><span class="default">header</span><span class="keyword">(</span><span class="string">"Content-Encoding: none\r\n"</span><span class="keyword">);<br /></span><span class="default">header</span><span class="keyword">(</span><span class="string">"Content-Length: 0"</span><span class="keyword">, </span><span class="default">true</span><span class="keyword">);<br /><br /></span><span class="default">flush</span><span class="keyword">();<br /></span><span class="default">ob_flush</span><span class="keyword">();<br /><br /></span><span class="default">session_write_close</span><span class="keyword">();<br /><br /></span><span class="comment">// Continue processing...<br /><br /></span><span class="default">sleep</span><span class="keyword">(</span><span class="default">100</span><span class="keyword">);<br />exit;<br /></span><span class="default">?&gt;<br /></span><br />But careful:<br />Make sure that your script doesn't write to the session after session_write_close(), i.e. in your background processing code.&nbsp; That won't work.&nbsp; Also avoid reading, remember, the next script may already have modified the data.<br /><br />So try to read out the data you need prior to redirecting.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="71172">  <div class="votes">
    <div id="Vu71172">
    <a href="/manual/vote-note.php?id=71172&amp;page=features.connection-handling&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd71172">
    <a href="/manual/vote-note.php?id=71172&amp;page=features.connection-handling&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V71172" title="63% like this...">
    15
    </div>
  </div>
  <a href="#71172" class="name">
  <strong class="user"><em>arr1 at hotmail dot co dot uk</em></strong></a><a class="genanchor" href="#71172"> &para;</a><div class="date" title="2006-11-14 11:51"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom71172">
<div class="phpcode"><code><span class="html">
Closing the users browser connection whilst keeping your php script running has been an issue since 4.1, when the behaviour of register_shutdown_function() was modified so that it would not automatically close the users connection.<br /><br />sts at mail dot xubion dot hu<br />Posted the original solution:<br /><br /><span class="default">&lt;?php<br />header</span><span class="keyword">(</span><span class="string">"Connection: close"</span><span class="keyword">);<br /></span><span class="default">ob_start</span><span class="keyword">();<br /></span><span class="default">phpinfo</span><span class="keyword">();<br /></span><span class="default">$size</span><span class="keyword">=</span><span class="default">ob_get_length</span><span class="keyword">();<br /></span><span class="default">header</span><span class="keyword">(</span><span class="string">"Content-Length: </span><span class="default">$size</span><span class="string">"</span><span class="keyword">);<br /></span><span class="default">ob_end_flush</span><span class="keyword">();<br /></span><span class="default">flush</span><span class="keyword">();<br /></span><span class="default">sleep</span><span class="keyword">(</span><span class="default">13</span><span class="keyword">);<br /></span><span class="default">error_log</span><span class="keyword">(</span><span class="string">"do something in the background"</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />Which works fine until you substitute phpinfo() for <br />echo ('text I want user to see'); in which case the headers are never sent!<br /><br />The solution is to explicitly turn off output buffering and clear the buffer prior to sending your header information.<br /><br />example:<br /><br /><span class="default">&lt;?php<br /> ob_end_clean</span><span class="keyword">();<br /> </span><span class="default">header</span><span class="keyword">(</span><span class="string">"Connection: close"</span><span class="keyword">);<br /> </span><span class="default">ignore_user_abort</span><span class="keyword">(); </span><span class="comment">// optional<br /> </span><span class="default">ob_start</span><span class="keyword">();<br /> echo (</span><span class="string">'Text the user will see'</span><span class="keyword">);<br /> </span><span class="default">$size </span><span class="keyword">= </span><span class="default">ob_get_length</span><span class="keyword">();<br /> </span><span class="default">header</span><span class="keyword">(</span><span class="string">"Content-Length: </span><span class="default">$size</span><span class="string">"</span><span class="keyword">);<br /> </span><span class="default">ob_end_flush</span><span class="keyword">(); </span><span class="comment">// Strange behaviour, will not work<br /> </span><span class="default">flush</span><span class="keyword">();&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Unless both are called !<br /> // Do processing here <br /> </span><span class="default">sleep</span><span class="keyword">(</span><span class="default">30</span><span class="keyword">);<br /> echo(</span><span class="string">'Text user will never see'</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span> <br />Just spent 3 hours trying to figure this one out, hope it helps someone :)<br /><br />Tested in:<br />IE 7.5730.11<br />Mozilla Firefox 1.81</span>
</code></div>
  </div>
 </div>
  <div class="note" id="95087">  <div class="votes">
    <div id="Vu95087">
    <a href="/manual/vote-note.php?id=95087&amp;page=features.connection-handling&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd95087">
    <a href="/manual/vote-note.php?id=95087&amp;page=features.connection-handling&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V95087" title="62% like this...">
    7
    </div>
  </div>
  <a href="#95087" class="name">
  <strong class="user"><em>a1n2ton at gmail dot com</em></strong></a><a class="genanchor" href="#95087"> &para;</a><div class="date" title="2009-12-12 01:09"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom95087">
<div class="phpcode"><code><span class="html">
PHP changes directory on connection abort so code like this will not do what you want:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">abort</span><span class="keyword">()<br />{<br />&nbsp; &nbsp;&nbsp; if(</span><span class="default">connection_aborted</span><span class="keyword">())<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">unlink</span><span class="keyword">(</span><span class="string">'file.ini'</span><span class="keyword">);<br />}<br /></span><span class="default">register_shutdown_function</span><span class="keyword">(</span><span class="string">'abort'</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />actually it will delete file in apaches's root dir so if you want to unlink file in your script's dir on abort or write to it you have to store directory<br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">abort</span><span class="keyword">()<br />{<br />&nbsp; &nbsp;&nbsp; global </span><span class="default">$dsd</span><span class="keyword">;<br />&nbsp; &nbsp;&nbsp; if(</span><span class="default">connection_aborted</span><span class="keyword">())<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">unlink</span><span class="keyword">(</span><span class="default">$dsd</span><span class="keyword">.</span><span class="string">'/file.ini'</span><span class="keyword">);<br />}<br /></span><span class="default">register_shutdown_function</span><span class="keyword">(</span><span class="string">'abort'</span><span class="keyword">);<br /></span><span class="default">$dsd</span><span class="keyword">=</span><span class="default">getcwd</span><span class="keyword">();<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="45779">  <div class="votes">
    <div id="Vu45779">
    <a href="/manual/vote-note.php?id=45779&amp;page=features.connection-handling&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd45779">
    <a href="/manual/vote-note.php?id=45779&amp;page=features.connection-handling&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V45779" title="57% like this...">
    4
    </div>
  </div>
  <a href="#45779" class="name">
  <strong class="user"><em>Lee</em></strong></a><a class="genanchor" href="#45779"> &para;</a><div class="date" title="2004-09-18 03:16"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom45779">
<div class="phpcode"><code><span class="html">
The point mentioned in the last comment isn't always the case.<br /><br />If a user's connection is lost half way through an order processing script is confirming a user's credit card/adding them to a DB, etc (due to their ISP going down, network trouble... whatever) and your script tries to send back output (such as, "pre-processing order" or any other type of confirmation), then your script will abort -- and this could cause problems for your process.<br /><br />I have an order script that adds data to a InnoDB database (through MySQL) and only commits the transactions upon successful completion. Without ignore_user_abort(), I have had times when a user's connection dropped during the processing phase... and their card was charged, but they weren't added to my local DB.<br /><br />So, it's always safe to ignore any aborts if you are processing sensitive transactions that should go ahead, whether your user is "watching" on the other end or not.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="79134">  <div class="votes">
    <div id="Vu79134">
    <a href="/manual/vote-note.php?id=79134&amp;page=features.connection-handling&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd79134">
    <a href="/manual/vote-note.php?id=79134&amp;page=features.connection-handling&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V79134" title="53% like this...">
    3
    </div>
  </div>
  <a href="#79134" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#79134"> &para;</a><div class="date" title="2007-11-13 02:06"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom79134">
<div class="phpcode"><code><span class="html">
in regards of posting from:<br />arr1 at hotmail dot co dot uk<br /><br />if you use/write sessions you need to do this before:<br />(otherwise it does not work)<br /><br />session_write_close();<br /><br />and if wanted:<br /><br />ignore_user_abort(TRUE);<br />instead of ignore_user_abort();</span>
</code></div>
  </div>
 </div>
  <div class="note" id="107027">  <div class="votes">
    <div id="Vu107027">
    <a href="/manual/vote-note.php?id=107027&amp;page=features.connection-handling&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd107027">
    <a href="/manual/vote-note.php?id=107027&amp;page=features.connection-handling&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V107027" title="52% like this...">
    2
    </div>
  </div>
  <a href="#107027" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#107027"> &para;</a><div class="date" title="2011-12-29 05:52"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom107027">
<div class="phpcode"><code><span class="html">
This simple function outputs a string and closes the connection. It considers compression using "ob_gzhandler"<br /><br />It took me a little while to put this all together, mostly because setting the encoding to none, as some people noted here, didn't work.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">outputStringAndCloseConnection2</span><span class="keyword">(</span><span class="default">$stringToOutput</span><span class="keyword">)<br />{&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="default">set_time_limit</span><span class="keyword">(</span><span class="default">0</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">ignore_user_abort</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">);&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">// buffer all upcoming output - make sure we care about compression:<br />&nbsp; &nbsp; </span><span class="keyword">if(!</span><span class="default">ob_start</span><span class="keyword">(</span><span class="string">"ob_gzhandler"</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">ob_start</span><span class="keyword">();&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; <br />&nbsp; &nbsp; echo </span><span class="default">$stringToOutput</span><span class="keyword">;&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">// get the size of the output<br />&nbsp; &nbsp; </span><span class="default">$size </span><span class="keyword">= </span><span class="default">ob_get_length</span><span class="keyword">();&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">// send headers to tell the browser to close the connection&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">"Content-Length: </span><span class="default">$size</span><span class="string">"</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">'Connection: close'</span><span class="keyword">);&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">// flush all output<br />&nbsp; &nbsp; </span><span class="default">ob_end_flush</span><span class="keyword">();<br />&nbsp; &nbsp; </span><span class="default">ob_flush</span><span class="keyword">();<br />&nbsp; &nbsp; </span><span class="default">flush</span><span class="keyword">();&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">// close current session<br />&nbsp; &nbsp; </span><span class="keyword">if (</span><span class="default">session_id</span><span class="keyword">()) </span><span class="default">session_write_close</span><span class="keyword">();<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="34800">  <div class="votes">
    <div id="Vu34800">
    <a href="/manual/vote-note.php?id=34800&amp;page=features.connection-handling&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd34800">
    <a href="/manual/vote-note.php?id=34800&amp;page=features.connection-handling&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V34800" title="50% like this...">
    0
    </div>
  </div>
  <a href="#34800" class="name">
  <strong class="user"><em>pulstar at mail dot com</em></strong></a><a class="genanchor" href="#34800"> &para;</a><div class="date" title="2003-08-06 11:32"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom34800">
<div class="phpcode"><code><span class="html">
These functions are very useful for example if you need to control when a visitor in your website place an order and you need to check if he/she didn't clicked the submit button twice or cancelled the submit just after have clicked the submit button. <br />If your visitor click the stop button just after have submitted it, your script may stop in the middle of the process of registering the products and do not finish the list, generating inconsistency in your database.<br />With the ignore_user_abort() function you can make your script finish everything fine and after you can check with register_shutdown_function() and connection_aborted() if the visitor cancelled the submission or lost his/her connection. If he/she did, you can set the order as not confirmed and when the visitor came back, you can present the old order again.<br />To prevent a double click of the submit button, you can disable it with javascript or in your script you can set a flag for that order, which will be recorded into the database. Before accept a new submission, the script will check if the same order was not placed before and reject it. This will work fine, as the script have finished the job before.<br />Note that if you use ob_start("callback_function") in the begin of your script, you can specify a callback function that will act like the shutdown function when our script ends and also will let you to work on the generated page before send it to the visitor.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="110184">  <div class="votes">
    <div id="Vu110184">
    <a href="/manual/vote-note.php?id=110184&amp;page=features.connection-handling&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd110184">
    <a href="/manual/vote-note.php?id=110184&amp;page=features.connection-handling&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V110184" title="47% like this...">
    -2
    </div>
  </div>
  <a href="#110184" class="name">
  <strong class="user"><em>Ilya Penyaev</em></strong></a><a class="genanchor" href="#110184"> &para;</a><div class="date" title="2012-09-27 06:25"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom110184">
<div class="phpcode"><code><span class="html">
I was quite stuck when trying to make my script redirect the client to another URL and then continue processing. The reason was php-fpm. All possible buffer flushes did not work, unless I called fastcgi_finish_request();<br /><br />For example:<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="comment">// redirecting...<br />&nbsp; &nbsp; </span><span class="default">ignore_user_abort</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">"Location: "</span><span class="keyword">.</span><span class="default">$redirectUrl</span><span class="keyword">, </span><span class="default">true</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">"Connection: close"</span><span class="keyword">, </span><span class="default">true</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">header</span><span class="keyword">(</span><span class="string">"Content-Length: 0"</span><span class="keyword">, </span><span class="default">true</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">ob_end_flush</span><span class="keyword">();<br />&nbsp; &nbsp; </span><span class="default">flush</span><span class="keyword">();<br />&nbsp; &nbsp; </span><span class="default">fastcgi_finish_request</span><span class="keyword">(); </span><span class="comment">// important when using php-fpm!<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="default">sleep </span><span class="keyword">(</span><span class="default">5</span><span class="keyword">); </span><span class="comment">// User won't feel this sleep because he'll already be away<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; // do some work after user has been redirected<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120770">  <div class="votes">
    <div id="Vu120770">
    <a href="/manual/vote-note.php?id=120770&amp;page=features.connection-handling&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120770">
    <a href="/manual/vote-note.php?id=120770&amp;page=features.connection-handling&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120770" title="33% like this...">
    -1
    </div>
  </div>
  <a href="#120770" class="name">
  <strong class="user"><em>Marco</em></strong></a><a class="genanchor" href="#120770"> &para;</a><div class="date" title="2017-03-08 05:58"><strong>9 months ago</strong></div>
  <div class="text" id="Hcom120770">
<div class="phpcode"><code><span class="html">
The CONNECTION_XXX constants that are not listed here for some reason are:<br /><br />0 = CONNECTION_NORMAL<br />1 = CONNECTION_ABORTED<br />2 = CONNECTION_TIMEOUT<br />3 = CONNECTION_ABORTED &amp; CONNECTION_TIMEOUT<br /><br />Number 3 is effectively tested like this:<br />if (CONNECTION_ABORTED &amp; CONNECTION_TIMEOUT)<br />&nbsp; &nbsp; echo 'Connection both aborted and timed out';</span>
</code></div>
  </div>
 </div>
  <div class="note" id="82225">  <div class="votes">
    <div id="Vu82225">
    <a href="/manual/vote-note.php?id=82225&amp;page=features.connection-handling&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd82225">
    <a href="/manual/vote-note.php?id=82225&amp;page=features.connection-handling&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V82225" title="38% like this...">
    -6
    </div>
  </div>
  <a href="#82225" class="name">
  <strong class="user"><em>Jean Charles MAMMANA</em></strong></a><a class="genanchor" href="#82225"> &para;</a><div class="date" title="2008-04-01 01:25"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom82225">
<div class="phpcode"><code><span class="html">
connection_status() return ABORTED state ONLY if the client disconnects gracefully (with STOP button). In this case the browser send the RST TCP packet that notify PHP the connection is closed.<br />But.... If the connection is stopped by networs troubles (wifi link down by exemple) the script doesn't know that the client is disconnected :(<br /><br />I've tried to use fopen("php://output") with stream_select() on writting to detect write locks (due to full buffer) but php give me this error : "cannot represent a stream of type Output as a select()able descriptor"<br /><br />So I don't know how to detect correctly network trouble connection...</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119170">  <div class="votes">
    <div id="Vu119170">
    <a href="/manual/vote-note.php?id=119170&amp;page=features.connection-handling&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119170">
    <a href="/manual/vote-note.php?id=119170&amp;page=features.connection-handling&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119170" title="15% like this...">
    -23
    </div>
  </div>
  <a href="#119170" class="name">
  <strong class="user"><em>robert at go dot rw</em></strong></a><a class="genanchor" href="#119170"> &para;</a><div class="date" title="2016-04-14 01:54"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119170">
<div class="phpcode"><code><span class="html">
01<br />02<br />03<br />04<br />05<br />06<br />07<br />08<br />09<br />10<br />11<br />12<br />13<br />14<br />15<br />16<br />17<br />18<br />/*<br /> * Anti-Pattern<br /> */<br /> <br /># Connect<br />mysql_connect('localhost', 'username', 'password') or die('Could not connect: ' . mysql_error());<br /> <br /># Choose a database<br />mysql_select_db('someDatabase') or die('Could not select database');<br /> <br /># Perform database query<br />$query = "SELECT * from someTable";<br />$result = mysql_query($query) or die('Query failed: ' . mysql_error());<br /> <br /># Filter through rows and echo desired information<br />while ($row = mysql_fetch_object($result)) {<br />&nbsp; &nbsp; echo $row-&gt;name;<br />}</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=features.connection-handling&amp;redirect=http://php.net/manual/en/features.connection-handling.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="features.php">Features</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="features.http-auth.php" title="HTTP authentication with PHP">HTTP authentication with PHP</a>
                        </li>
                          
                        <li class="">
                            <a href="features.cookies.php" title="Cookies">Cookies</a>
                        </li>
                          
                        <li class="">
                            <a href="features.sessions.php" title="Sessions">Sessions</a>
                        </li>
                          
                        <li class="">
                            <a href="features.xforms.php" title="Dealing with XForms">Dealing with XForms</a>
                        </li>
                          
                        <li class="">
                            <a href="features.file-upload.php" title="Handling file uploads">Handling file uploads</a>
                        </li>
                          
                        <li class="">
                            <a href="features.remote-files.php" title="Using remote files">Using remote files</a>
                        </li>
                          
                        <li class="current">
                            <a href="features.connection-handling.php" title="Connection handling">Connection handling</a>
                        </li>
                          
                        <li class="">
                            <a href="features.persistent-connections.php" title="Persistent Database Connections">Persistent Database Connections</a>
                        </li>
                          
                        <li class="">
                            <a href="features.safe-mode.php" title="Safe Mode">Safe Mode</a>
                        </li>
                          
                        <li class="">
                            <a href="features.commandline.php" title="Command line usage">Command line usage</a>
                        </li>
                          
                        <li class="">
                            <a href="features.gc.php" title="Garbage Collection">Garbage Collection</a>
                        </li>
                          
                        <li class="">
                            <a href="features.dtrace.php" title="DTrace Dynamic Tracing">DTrace Dynamic Tracing</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

