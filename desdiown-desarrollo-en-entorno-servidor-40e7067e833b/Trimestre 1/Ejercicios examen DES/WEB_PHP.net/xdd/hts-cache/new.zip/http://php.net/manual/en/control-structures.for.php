<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: for - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/control-structures.for.php">
 <link rel="shorturl" href="http://php.net/for">
 <link rel="alternate" href="http://php.net/for" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.control-structures.php">
 <link rel="prev" href="http://php.net/manual/en/control-structures.do.while.php">
 <link rel="next" href="http://php.net/manual/en/control-structures.foreach.php">

 <link rel="alternate" href="http://php.net/manual/en/control-structures.for.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/control-structures.for.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/control-structures.for.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/control-structures.for.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/control-structures.for.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/control-structures.for.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/control-structures.for.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/control-structures.for.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/control-structures.for.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/control-structures.for.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/control-structures.for.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="control-structures.foreach.php">
          foreach &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="control-structures.do.while.php">
          &laquo; do-while        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.control-structures.php'>Control Structures</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/control-structures.for.php' selected="selected">English</option>
            <option value='pt_BR/control-structures.for.php'>Brazilian Portuguese</option>
            <option value='zh/control-structures.for.php'>Chinese (Simplified)</option>
            <option value='fr/control-structures.for.php'>French</option>
            <option value='de/control-structures.for.php'>German</option>
            <option value='ja/control-structures.for.php'>Japanese</option>
            <option value='ro/control-structures.for.php'>Romanian</option>
            <option value='ru/control-structures.for.php'>Russian</option>
            <option value='es/control-structures.for.php'>Spanish</option>
            <option value='tr/control-structures.for.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/control-structures.for.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=control-structures.for">Report a Bug</a>
    </div>
  </div><div id="control-structures.for" class="sect1">
 <h2 class="title"><em>for</em></h2>
 <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p>
 <p class="para">
  <em>for</em> loops are the most complex loops in PHP.
  They behave like their C counterparts.  The syntax of a
  <em>for</em> loop is:
  <div class="informalexample">
   <div class="example-contents">
<div class="cdata"><pre>
for (expr1; expr2; expr3)
    statement
</pre></div>
   </div>

  </div>
 </p>
 <p class="simpara">
  The first expression (<var class="varname"><var class="varname">expr1</var></var>) is
  evaluated (executed) once unconditionally at the beginning of the
  loop.
 </p>
 <p class="simpara">
  In the beginning of each iteration,
  <var class="varname"><var class="varname">expr2</var></var> is evaluated.  If it evaluates to
  <strong><code>TRUE</code></strong>, the loop continues and the nested
  statement(s) are executed.  If it evaluates to
  <strong><code>FALSE</code></strong>, the execution of the loop ends.
 </p>
 <p class="simpara">
  At the end of each iteration, <var class="varname"><var class="varname">expr3</var></var> is
  evaluated (executed).
 </p>
 <p class="simpara">
  Each of the expressions can be empty or contain multiple
  expressions separated by commas. In <var class="varname"><var class="varname">expr2</var></var>, all
  expressions separated by a comma are evaluated but the result is taken
  from the last part.
  <var class="varname"><var class="varname">expr2</var></var> being empty means the loop should
  be run indefinitely (PHP implicitly considers it as
  <strong><code>TRUE</code></strong>, like C).  This may not be as useless as
  you might think, since often you&#039;d want to end the loop using a
  conditional <a href="control-structures.break.php" class="link"><em>break</em></a>
  statement instead of using the <em>for</em> truth
  expression.
 </p>
 <p class="para">
  Consider the following examples.  All of them display the numbers
  1 through 10:
  <div class="informalexample">
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #FF8000">/*&nbsp;example&nbsp;1&nbsp;*/<br /><br /></span><span style="color: #007700">for&nbsp;(</span><span style="color: #0000BB">$i&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">;&nbsp;</span><span style="color: #0000BB">$i&nbsp;</span><span style="color: #007700">&lt;=&nbsp;</span><span style="color: #0000BB">10</span><span style="color: #007700">;&nbsp;</span><span style="color: #0000BB">$i</span><span style="color: #007700">++)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #0000BB">$i</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #FF8000">/*&nbsp;example&nbsp;2&nbsp;*/<br /><br /></span><span style="color: #007700">for&nbsp;(</span><span style="color: #0000BB">$i&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">;&nbsp;;&nbsp;</span><span style="color: #0000BB">$i</span><span style="color: #007700">++)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(</span><span style="color: #0000BB">$i&nbsp;</span><span style="color: #007700">&gt;&nbsp;</span><span style="color: #0000BB">10</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #0000BB">$i</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #FF8000">/*&nbsp;example&nbsp;3&nbsp;*/<br /><br /></span><span style="color: #0000BB">$i&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">;<br />for&nbsp;(;&nbsp;;&nbsp;)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(</span><span style="color: #0000BB">$i&nbsp;</span><span style="color: #007700">&gt;&nbsp;</span><span style="color: #0000BB">10</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;break;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #0000BB">$i</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$i</span><span style="color: #007700">++;<br />}<br /><br /></span><span style="color: #FF8000">/*&nbsp;example&nbsp;4&nbsp;*/<br /><br /></span><span style="color: #007700">for&nbsp;(</span><span style="color: #0000BB">$i&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$j&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">0</span><span style="color: #007700">;&nbsp;</span><span style="color: #0000BB">$i&nbsp;</span><span style="color: #007700">&lt;=&nbsp;</span><span style="color: #0000BB">10</span><span style="color: #007700">;&nbsp;</span><span style="color: #0000BB">$j&nbsp;</span><span style="color: #007700">+=&nbsp;</span><span style="color: #0000BB">$i</span><span style="color: #007700">,&nbsp;print&nbsp;</span><span style="color: #0000BB">$i</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$i</span><span style="color: #007700">++);<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>
 </p>
 <p class="simpara">
  Of course, the first example appears to be the nicest one (or
  perhaps the fourth), but you may find that being able to use empty
  expressions in <em>for</em> loops comes in handy in many
  occasions.
 </p>
 <p class="para">
  PHP also supports the alternate &quot;colon syntax&quot; for
  <em>for</em> loops.
  <div class="informalexample">
   <div class="example-contents">
<div class="cdata"><pre>
for (expr1; expr2; expr3):
    statement
    ...
endfor;
</pre></div>
   </div>

  </div>
 </p>
 <p class="simpara">
  It&#039;s a common thing to many users to iterate through arrays like in the
  example below.
 </p>
 <p class="para">
  <div class="informalexample">
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #FF8000">/*<br />&nbsp;*&nbsp;This&nbsp;is&nbsp;an&nbsp;array&nbsp;with&nbsp;some&nbsp;data&nbsp;we&nbsp;want&nbsp;to&nbsp;modify<br />&nbsp;*&nbsp;when&nbsp;running&nbsp;through&nbsp;the&nbsp;for&nbsp;loop.<br />&nbsp;*/<br /></span><span style="color: #0000BB">$people&nbsp;</span><span style="color: #007700">=&nbsp;array(<br />&nbsp;&nbsp;&nbsp;&nbsp;array(</span><span style="color: #DD0000">'name'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'Kalle'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'salt'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #0000BB">856412</span><span style="color: #007700">),<br />&nbsp;&nbsp;&nbsp;&nbsp;array(</span><span style="color: #DD0000">'name'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'Pierre'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'salt'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #0000BB">215863</span><span style="color: #007700">)<br />);<br /><br />for(</span><span style="color: #0000BB">$i&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">0</span><span style="color: #007700">;&nbsp;</span><span style="color: #0000BB">$i&nbsp;</span><span style="color: #007700">&lt;&nbsp;</span><span style="color: #0000BB">count</span><span style="color: #007700">(</span><span style="color: #0000BB">$people</span><span style="color: #007700">);&nbsp;++</span><span style="color: #0000BB">$i</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$people</span><span style="color: #007700">[</span><span style="color: #0000BB">$i</span><span style="color: #007700">][</span><span style="color: #DD0000">'salt'</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #0000BB">mt_rand</span><span style="color: #007700">(</span><span style="color: #0000BB">000000</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">999999</span><span style="color: #007700">);<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>
 </p>
 <p class="simpara">
  The above code can be slow, because the array size is fetched on
  every iteration. Since the size never changes, the loop be easily
  optimized by using an intermediate variable to store the size instead
  of repeatedly calling <span class="function"><a href="function.count.php" class="function">count()</a></span>:
 </p>
 <p class="para">
  <div class="informalexample">
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$people&nbsp;</span><span style="color: #007700">=&nbsp;array(<br />&nbsp;&nbsp;&nbsp;&nbsp;array(</span><span style="color: #DD0000">'name'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'Kalle'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'salt'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #0000BB">856412</span><span style="color: #007700">),<br />&nbsp;&nbsp;&nbsp;&nbsp;array(</span><span style="color: #DD0000">'name'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #DD0000">'Pierre'</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">'salt'&nbsp;</span><span style="color: #007700">=&gt;&nbsp;</span><span style="color: #0000BB">215863</span><span style="color: #007700">)<br />);<br /><br />for(</span><span style="color: #0000BB">$i&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">0</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$size&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">count</span><span style="color: #007700">(</span><span style="color: #0000BB">$people</span><span style="color: #007700">);&nbsp;</span><span style="color: #0000BB">$i&nbsp;</span><span style="color: #007700">&lt;&nbsp;</span><span style="color: #0000BB">$size</span><span style="color: #007700">;&nbsp;++</span><span style="color: #0000BB">$i</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$people</span><span style="color: #007700">[</span><span style="color: #0000BB">$i</span><span style="color: #007700">][</span><span style="color: #DD0000">'salt'</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #0000BB">mt_rand</span><span style="color: #007700">(</span><span style="color: #0000BB">000000</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">999999</span><span style="color: #007700">);<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
   </div>

  </div>
 </p>
</div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=control-structures.for&amp;redirect=http://php.net/manual/en/control-structures.for.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">18 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="107427">  <div class="votes">
    <div id="Vu107427">
    <a href="/manual/vote-note.php?id=107427&amp;page=control-structures.for&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd107427">
    <a href="/manual/vote-note.php?id=107427&amp;page=control-structures.for&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V107427" title="67% like this...">
    162
    </div>
  </div>
  <a href="#107427" class="name">
  <strong class="user"><em>matthiaz</em></strong></a><a class="genanchor" href="#107427"> &para;</a><div class="date" title="2012-02-08 02:37"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom107427">
<div class="phpcode"><code><span class="html">
Looping through letters is possible. I'm amazed at how few people know that.<br /><br />for($col = 'R'; $col != 'AD'; $col++) {<br />&nbsp; &nbsp; echo $col.' ';<br />}<br /><br />returns: R S T U V W X Y Z AA AB AC<br /><br />Take note that you can't use $col &lt; 'AD'. It only works with !=<br />Very convenient when working with excel columns.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="13463">  <div class="votes">
    <div id="Vu13463">
    <a href="/manual/vote-note.php?id=13463&amp;page=control-structures.for&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd13463">
    <a href="/manual/vote-note.php?id=13463&amp;page=control-structures.for&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V13463" title="57% like this...">
    34
    </div>
  </div>
  <a href="#13463" class="name">
  <strong class="user"><em>nzamani at cyberworldz dot de</em></strong></a><a class="genanchor" href="#13463"> &para;</a><div class="date" title="2001-06-17 11:47"><strong>16 years ago</strong></div>
  <div class="text" id="Hcom13463">
<div class="phpcode"><code><span class="html">
The point about the speed in loops is, that the middle and the last expression are executed EVERY time it loops.<br />So you should try to take everything that doesn't change out of the loop.<br />Often you use a function to check the maximum of times it should loop. Like here:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">for (</span><span class="default">$i </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">; </span><span class="default">$i </span><span class="keyword">&lt;= </span><span class="default">somewhat_calcMax</span><span class="keyword">(); </span><span class="default">$i</span><span class="keyword">++) {<br />&nbsp; </span><span class="default">somewhat_doSomethingWith</span><span class="keyword">(</span><span class="default">$i</span><span class="keyword">);<br />}<br /></span><span class="default">?&gt;<br /></span><br />Faster would be:<br /><br /><span class="default">&lt;?php<br />$maxI </span><span class="keyword">= </span><span class="default">somewhat_calcMax</span><span class="keyword">();<br />for (</span><span class="default">$i </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">; </span><span class="default">$i </span><span class="keyword">&lt;= </span><span class="default">$maxI</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">++) {<br />&nbsp; </span><span class="default">somewhat_doSomethingWith</span><span class="keyword">(</span><span class="default">$i</span><span class="keyword">);<br />}<br /></span><span class="default">?&gt;<br /></span><br />And here a little trick:<br /><br /><span class="default">&lt;?php<br />$maxI </span><span class="keyword">= </span><span class="default">somewhat_calcMax</span><span class="keyword">();<br />for (</span><span class="default">$i </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">; </span><span class="default">$i </span><span class="keyword">&lt;= </span><span class="default">$maxI</span><span class="keyword">; </span><span class="default">somewhat_doSomethingWith</span><span class="keyword">(</span><span class="default">$i</span><span class="keyword">++)) ;<br /></span><span class="default">?&gt;<br /></span><br />The $i gets changed after the copy for the function (post-increment).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114135">  <div class="votes">
    <div id="Vu114135">
    <a href="/manual/vote-note.php?id=114135&amp;page=control-structures.for&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114135">
    <a href="/manual/vote-note.php?id=114135&amp;page=control-structures.for&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114135" title="51% like this...">
    7
    </div>
  </div>
  <a href="#114135" class="name">
  <strong class="user"><em>Andrew</em></strong></a><a class="genanchor" href="#114135"> &para;</a><div class="date" title="2014-01-15 11:07"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114135">
<div class="phpcode"><code><span class="html">
You can use strtotime with for loops to loop through dates<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">for (</span><span class="default">$date </span><span class="keyword">= </span><span class="default">strtotime</span><span class="keyword">(</span><span class="string">"2014-01-01"</span><span class="keyword">); </span><span class="default">$date </span><span class="keyword">&lt; </span><span class="default">strtotime</span><span class="keyword">(</span><span class="string">"2014-02-01"</span><span class="keyword">); </span><span class="default">$date </span><span class="keyword">= </span><span class="default">strtotime</span><span class="keyword">(</span><span class="string">"+1 day"</span><span class="keyword">, </span><span class="default">$date</span><span class="keyword">)) {<br />&nbsp; &nbsp; echo </span><span class="default">date</span><span class="keyword">(</span><span class="string">"Y-m-d"</span><span class="keyword">, </span><span class="default">$date</span><span class="keyword">).</span><span class="string">"&lt;br /&gt;"</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114318">  <div class="votes">
    <div id="Vu114318">
    <a href="/manual/vote-note.php?id=114318&amp;page=control-structures.for&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114318">
    <a href="/manual/vote-note.php?id=114318&amp;page=control-structures.for&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114318" title="50% like this...">
    0
    </div>
  </div>
  <a href="#114318" class="name">
  <strong class="user"><em>Warbo</em></strong></a><a class="genanchor" href="#114318"> &para;</a><div class="date" title="2014-02-06 05:37"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114318">
<div class="phpcode"><code><span class="html">
Remember that for-loops don't always need to go 'forwards'. For example, let's say I have the following code:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">for (</span><span class="default">$i </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">; </span><span class="default">$i </span><span class="keyword">&lt; </span><span class="default">calculateLoopLength</span><span class="keyword">(); </span><span class="default">$i</span><span class="keyword">++) {<br />&nbsp; </span><span class="default">doSomethingWith</span><span class="keyword">(</span><span class="default">$i</span><span class="keyword">);<br />}<br />&gt;?<br /><br />As </span><span class="default">other comments have pointed out</span><span class="keyword">, if </span><span class="string">"calculateLoopLength" </span><span class="default">will keep giving back the same value</span><span class="keyword">, </span><span class="default">it can be moved outside the loop</span><span class="keyword">:<br /><br />&lt;?</span><span class="default">php<br />$loopLength </span><span class="keyword">= </span><span class="default">calculateLoopLength</span><span class="keyword">();<br />for (</span><span class="default">$i</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">; </span><span class="default">$i </span><span class="keyword">&lt; </span><span class="default">$loopLength</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">++) {<br />&nbsp; </span><span class="default">doSomethingWith</span><span class="keyword">(</span><span class="default">$i</span><span class="keyword">);<br />}<br /></span><span class="default">?&gt;<br /></span><br />However, if the order the looping doesn't matter (ie. each iteration is independent) then we don't need to use an extra variable either, we can just count down (ie. loop 'backwards') instead:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">for (</span><span class="default">$i</span><span class="keyword">=</span><span class="default">calculateLoopLength</span><span class="keyword">(); </span><span class="default">$i </span><span class="keyword">&gt; </span><span class="default">0</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">--) {<br />&nbsp; </span><span class="default">doSomething</span><span class="keyword">(</span><span class="default">$i</span><span class="keyword">);<br />}<br /></span><span class="default">?&gt;<br /></span><br />In fact, we can simplify this even more, since "$i &gt; 0" is equivalent to "$i" (due to type casting):<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">for (</span><span class="default">$i</span><span class="keyword">=</span><span class="default">calculateLoopLength</span><span class="keyword">(); </span><span class="default">$i</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">--) {<br />&nbsp; </span><span class="default">doSomething</span><span class="keyword">(</span><span class="default">$i</span><span class="keyword">);<br />}<br /></span><span class="default">?&gt;<br /></span><br />Finally, we can switch to a 'pre-decrement' instead of a 'post-decrement' to be slightly more efficient (see, for example, <a href="http://dfox.me/2011/04/php-most-common-mistakes-part-2-using-post-increment-instead-of-pre-increment/" rel="nofollow" target="_blank">http://dfox.me/2011/04/php-most-common-mistakes-part-2-using-post-increment-instead-of-pre-increment/</a> ):<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">for (</span><span class="default">$i </span><span class="keyword">= </span><span class="default">calculateLoopLength</span><span class="keyword">(); </span><span class="default">$i</span><span class="keyword">; --</span><span class="default">$i</span><span class="keyword">) {<br />&nbsp; </span><span class="default">doSomething</span><span class="keyword">(</span><span class="default">$i</span><span class="keyword">);<br />}<br /></span><span class="default">?&gt;<br /></span><br />In this case we could also replace the entire loop with a map, which might make your algorithm clearer (although this won't work if calculateLoopLength() == 0):<br /><br /><span class="default">&lt;?php<br />array_map</span><span class="keyword">(</span><span class="string">'doSomething'</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">range</span><span class="keyword">(</span><span class="default">0</span><span class="keyword">, </span><span class="default">calculateLoopLength</span><span class="keyword">() - </span><span class="default">1</span><span class="keyword">));<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120455">  <div class="votes">
    <div id="Vu120455">
    <a href="/manual/vote-note.php?id=120455&amp;page=control-structures.for&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120455">
    <a href="/manual/vote-note.php?id=120455&amp;page=control-structures.for&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120455" title="40% like this...">
    -5
    </div>
  </div>
  <a href="#120455" class="name">
  <strong class="user"><em>dx at e-mogensen dot dk</em></strong></a><a class="genanchor" href="#120455"> &para;</a><div class="date" title="2017-01-12 07:31"><strong>11 months ago</strong></div>
  <div class="text" id="Hcom120455">
<div class="phpcode"><code><span class="html">
Warning about using the function "strlen" i a for-loop:<br /><br />This note should might be under the "strlen" manual page, but there is a better chance for more paying attention here (nevertheless I have made a short note over there allso).<br /><br />A loop function that test for the string length at each iteration takes forever (possibly due to "strlen" searches for the C-style string terminator - a binary 0 - every time..<br /><br />So loops like this, using&nbsp; "strlen" in the for...<br /><br />for&nbsp; ($i = 0;&nbsp; $i &lt; strlen($crc); $i++) .....<br /><br />Will benefit tremendously in speed by a short step that saves the string length once and use that in the loop.<br /><br />$clen = strlen($crc);<br /><br />for&nbsp; ($i = 0;&nbsp; $i &lt; $clen ; $i++) .....<br /><br />Note: as a real hard-core programmer You are aware, that this is only valid if you don't change the string content inside the loop (and hereby allso the length). If the change is only occationly , You could just refresh the length variable or else just live with a quite slow loop.<br /><br />This "discovery" was made from using an example of 16 bit crc calculation over at the "crc32" function manual page, that do exactly that..</span>
</code></div>
  </div>
 </div>
  <div class="note" id="115368">  <div class="votes">
    <div id="Vu115368">
    <a href="/manual/vote-note.php?id=115368&amp;page=control-structures.for&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115368">
    <a href="/manual/vote-note.php?id=115368&amp;page=control-structures.for&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115368" title="39% like this...">
    -8
    </div>
  </div>
  <a href="#115368" class="name">
  <strong class="user"><em>AoKMiKeY</em></strong></a><a class="genanchor" href="#115368"> &para;</a><div class="date" title="2014-07-13 06:36"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115368">
<div class="phpcode"><code><span class="html">
As a note for people just starting out and wanting to know if you can do some thing like this...<br /><br /><span class="default">&lt;?php </span><span class="keyword">For( </span><span class="default">$a </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">; </span><span class="default">$a </span><span class="keyword">&lt; </span><span class="default">10</span><span class="keyword">; </span><span class="default">$a</span><span class="keyword">++ ) { </span><span class="default">?&gt;<br /></span><br />//Random html elements you would like to duplicate.<br /><br /><span class="default">&lt;?php </span><span class="keyword">} </span><span class="default">?&gt;<br /></span><br />Then yes you can. It works like a charm.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="41670">  <div class="votes">
    <div id="Vu41670">
    <a href="/manual/vote-note.php?id=41670&amp;page=control-structures.for&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd41670">
    <a href="/manual/vote-note.php?id=41670&amp;page=control-structures.for&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V41670" title="42% like this...">
    -18
    </div>
  </div>
  <a href="#41670" class="name">
  <strong class="user"><em>user at host dot com</em></strong></a><a class="genanchor" href="#41670"> &para;</a><div class="date" title="2004-04-19 03:53"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom41670">
<div class="phpcode"><code><span class="html">
Also acceptable:<br /><br /><span class="default">&lt;?php<br />&nbsp; </span><span class="keyword">for(</span><span class="default">$letter </span><span class="keyword">= </span><span class="default">ord</span><span class="keyword">(</span><span class="string">'a'</span><span class="keyword">); </span><span class="default">$letter </span><span class="keyword">&lt;= </span><span class="default">ord</span><span class="keyword">(</span><span class="string">'z'</span><span class="keyword">); </span><span class="default">$letter</span><span class="keyword">++)<br />&nbsp;&nbsp; print </span><span class="default">chr</span><span class="keyword">(</span><span class="default">$letter</span><span class="keyword">);<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="69525">  <div class="votes">
    <div id="Vu69525">
    <a href="/manual/vote-note.php?id=69525&amp;page=control-structures.for&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd69525">
    <a href="/manual/vote-note.php?id=69525&amp;page=control-structures.for&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V69525" title="40% like this...">
    -15
    </div>
  </div>
  <a href="#69525" class="name">
  <strong class="user"><em>lishevita at yahoo dot co (notcom) .uk</em></strong></a><a class="genanchor" href="#69525"> &para;</a><div class="date" title="2006-09-08 12:33"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom69525">
<div class="phpcode"><code><span class="html">
On the combination problem again...<br /><br /> It seems to me like it would make more sense to go through systematically. That would take nested for loops, where each number was put through all of it's potentials sequentially. <br /><br />The following would give you all of the potential combinations of a four-digit decimal combination, printed in a comma delimited format:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">for(</span><span class="default">$a</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">;</span><span class="default">$a</span><span class="keyword">&lt;</span><span class="default">10</span><span class="keyword">;</span><span class="default">$a</span><span class="keyword">++){<br />&nbsp; &nbsp; for(</span><span class="default">$b</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">;</span><span class="default">$b</span><span class="keyword">&lt;</span><span class="default">10</span><span class="keyword">;</span><span class="default">$b</span><span class="keyword">++){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; for(</span><span class="default">$c</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">;</span><span class="default">$c</span><span class="keyword">&lt;</span><span class="default">10</span><span class="keyword">;</span><span class="default">$c</span><span class="keyword">++){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; for(</span><span class="default">$d</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">;</span><span class="default">$d</span><span class="keyword">&lt;</span><span class="default">10</span><span class="keyword">;</span><span class="default">$d</span><span class="keyword">++){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">$a</span><span class="keyword">.</span><span class="default">$b</span><span class="keyword">.</span><span class="default">$c</span><span class="keyword">.</span><span class="default">$d</span><span class="keyword">.</span><span class="string">", "</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; }<br />&nbsp; &nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />Of course, if you know that the numbers you had used were in a smaller subset, you could just plunk your possible numbers into arrays $a, $b, $c, and $d and then do nested foreach loops as above.<br /><br />- Elizabeth</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114730">  <div class="votes">
    <div id="Vu114730">
    <a href="/manual/vote-note.php?id=114730&amp;page=control-structures.for&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114730">
    <a href="/manual/vote-note.php?id=114730&amp;page=control-structures.for&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114730" title="40% like this...">
    -21
    </div>
  </div>
  <a href="#114730" class="name">
  <strong class="user"><em>Vincenzo Raco</em></strong></a><a class="genanchor" href="#114730"> &para;</a><div class="date" title="2014-03-30 04:59"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114730">
<div class="phpcode"><code><span class="html">
In this code:<br /><br /><span class="default">&lt;?php<br /><br />&nbsp; &nbsp; $array </span><span class="keyword">= array(<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'pop0'</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'pop1'</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'pop2'</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'pop3'</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'pop4'</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'pop5'</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'pop6'</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'pop7'</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'pop8'<br />&nbsp; &nbsp; </span><span class="keyword">);<br />&nbsp; &nbsp; echo </span><span class="string">"Tot Before: "</span><span class="keyword">.</span><span class="default">count</span><span class="keyword">(</span><span class="default">$array</span><span class="keyword">).</span><span class="string">"&lt;br&gt;&lt;br&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; for (</span><span class="default">$i</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">&lt;</span><span class="default">count</span><span class="keyword">(</span><span class="default">$array</span><span class="keyword">); </span><span class="default">$i</span><span class="keyword">++) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$i </span><span class="keyword">=== </span><span class="default">3</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; unset(</span><span class="default">$array</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Count: "</span><span class="keyword">.</span><span class="default">count</span><span class="keyword">(</span><span class="default">$array</span><span class="keyword">). </span><span class="string">" - Position: "</span><span class="keyword">.</span><span class="default">$i</span><span class="keyword">.</span><span class="string">"&lt;br&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; echo </span><span class="string">"&lt;br&gt; Tot After: "</span><span class="keyword">.</span><span class="default">count</span><span class="keyword">(</span><span class="default">$array</span><span class="keyword">).</span><span class="string">"&lt;br&gt;"</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;<br /></span><br />The result is:<br /><br />---<br /><br />Tot Before: 9<br /><br />Count: 9 - Position: 0<br />Count: 9 - Position: 1<br />Count: 9 - Position: 2<br />Count: 8 - Position: 3<br />Count: 8 - Position: 4<br />Count: 8 - Position: 5<br />Count: 8 - Position: 6<br />Count: 8 - Position: 7<br /><br />Tot After: 8<br /><br />---<br /><br />The position 8 is skipped, because the "expr2" {{ $i&lt;count($array) }} is evaluated again, for each cycle.<br /><br />The solution is:<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; $array </span><span class="keyword">= array(<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'pop0'</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'pop1'</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'pop2'</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'pop3'</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'pop4'</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'pop5'</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'pop6'</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'pop7'</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'pop8'<br />&nbsp; &nbsp; </span><span class="keyword">);<br />&nbsp; &nbsp; echo </span><span class="string">"Tot Before: "</span><span class="keyword">.</span><span class="default">count</span><span class="keyword">(</span><span class="default">$array</span><span class="keyword">).</span><span class="string">"&lt;br&gt;&lt;br&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$count </span><span class="keyword">= </span><span class="default">count</span><span class="keyword">(</span><span class="default">$array</span><span class="keyword">);<br />&nbsp; &nbsp; for (</span><span class="default">$i</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">&lt;</span><span class="default">$count</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">++) {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$i </span><span class="keyword">=== </span><span class="default">3</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; unset(</span><span class="default">$array</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"Count: "</span><span class="keyword">.</span><span class="default">count</span><span class="keyword">(</span><span class="default">$array</span><span class="keyword">). </span><span class="string">" - Position: "</span><span class="keyword">.</span><span class="default">$i</span><span class="keyword">.</span><span class="string">"&lt;br&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; echo </span><span class="string">"&lt;br&gt; Tot After: "</span><span class="keyword">.</span><span class="default">count</span><span class="keyword">(</span><span class="default">$array</span><span class="keyword">).</span><span class="string">"&lt;br&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; <br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="110573">  <div class="votes">
    <div id="Vu110573">
    <a href="/manual/vote-note.php?id=110573&amp;page=control-structures.for&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd110573">
    <a href="/manual/vote-note.php?id=110573&amp;page=control-structures.for&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V110573" title="37% like this...">
    -17
    </div>
  </div>
  <a href="#110573" class="name">
  <strong class="user"><em>Philipp Trommler</em></strong></a><a class="genanchor" href="#110573"> &para;</a><div class="date" title="2012-11-08 04:34"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom110573">
<div class="phpcode"><code><span class="html">
Note, that, because the first line is executed everytime, it is not only slow to put a function there, it can also lead to problems like:<br /><br /><span class="default">&lt;?php<br /><br />$array </span><span class="keyword">= array(</span><span class="default">0 </span><span class="keyword">=&gt; </span><span class="string">"a"</span><span class="keyword">, </span><span class="default">1 </span><span class="keyword">=&gt; </span><span class="string">"b"</span><span class="keyword">, </span><span class="default">2 </span><span class="keyword">=&gt; </span><span class="string">"c"</span><span class="keyword">, </span><span class="default">3 </span><span class="keyword">=&gt; </span><span class="string">"d"</span><span class="keyword">);<br /><br />for(</span><span class="default">$i </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">; </span><span class="default">$i </span><span class="keyword">&lt; </span><span class="default">count</span><span class="keyword">(</span><span class="default">$array</span><span class="keyword">); </span><span class="default">$i</span><span class="keyword">++){<br /><br />echo </span><span class="default">$array</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">];<br /><br />unset(</span><span class="default">$array</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">]);<br /><br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />This will only output the half of the elements, because the array is becoming shorter everytime the for-expression counts it.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="75754">  <div class="votes">
    <div id="Vu75754">
    <a href="/manual/vote-note.php?id=75754&amp;page=control-structures.for&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd75754">
    <a href="/manual/vote-note.php?id=75754&amp;page=control-structures.for&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V75754" title="40% like this...">
    -24
    </div>
  </div>
  <a href="#75754" class="name">
  <strong class="user"><em>eduardofleury at uol dot com dot br</em></strong></a><a class="genanchor" href="#75754"> &para;</a><div class="date" title="2007-06-14 06:18"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom75754">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br /></span><span class="comment">//this is a different way to use the 'for'<br />//Essa é uma maneira diferente de usar o 'for'<br /></span><span class="keyword">for(</span><span class="default">$i </span><span class="keyword">= </span><span class="default">$x </span><span class="keyword">= </span><span class="default">$z </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">; </span><span class="default">$i </span><span class="keyword">&lt;= </span><span class="default">10</span><span class="keyword">;</span><span class="default">$i</span><span class="keyword">++,</span><span class="default">$x</span><span class="keyword">+=</span><span class="default">2</span><span class="keyword">,</span><span class="default">$z</span><span class="keyword">=&amp;</span><span class="default">$p</span><span class="keyword">){<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="default">$p </span><span class="keyword">= </span><span class="default">$i </span><span class="keyword">+ </span><span class="default">$x</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; print </span><span class="string">"\$i = </span><span class="default">$i</span><span class="string"> , \$x = </span><span class="default">$x</span><span class="string"> , \$z = </span><span class="default">$z</span><span class="string"> &lt;br /&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; <br />}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119459">  <div class="votes">
    <div id="Vu119459">
    <a href="/manual/vote-note.php?id=119459&amp;page=control-structures.for&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119459">
    <a href="/manual/vote-note.php?id=119459&amp;page=control-structures.for&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119459" title="34% like this...">
    -13
    </div>
  </div>
  <a href="#119459" class="name">
  <strong class="user"><em>htroyo</em></strong></a><a class="genanchor" href="#119459"> &para;</a><div class="date" title="2016-06-10 11:04"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119459">
<div class="phpcode"><code><span class="html">
when iterating a multidimentional array like this:<br />for ($i = 0; $i &lt; $size_x; $i++) {<br />&nbsp; &nbsp; for ($j = 0; $j &lt; $size_y; $j++) {<br />&nbsp; &nbsp; &nbsp; &nbsp; do_something($a[$i][$j]);<br />&nbsp; &nbsp; }<br />}<br />it is faster to use $a[$i][$j] than using $a[$j][$i]<br />for ($i = 0; $i &lt; $size_x; $i++) {<br />&nbsp; &nbsp; for ($j = 0; $j &lt; $size_y; $j++) {<br />&nbsp; &nbsp; &nbsp; &nbsp; do_something($a[$j][$i]);<br />&nbsp; &nbsp; }<br />}<br />if you know about how RAM works you understand why</span>
</code></div>
  </div>
 </div>
  <div class="note" id="55494">  <div class="votes">
    <div id="Vu55494">
    <a href="/manual/vote-note.php?id=55494&amp;page=control-structures.for&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd55494">
    <a href="/manual/vote-note.php?id=55494&amp;page=control-structures.for&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V55494" title="34% like this...">
    -18
    </div>
  </div>
  <a href="#55494" class="name">
  <strong class="user"><em>JustinB at harvest dot org</em></strong></a><a class="genanchor" href="#55494"> &para;</a><div class="date" title="2005-08-04 04:23"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom55494">
<div class="phpcode"><code><span class="html">
For those who are having issues with needing to evaluate multiple items in expression two, please note that it cannot be chained like expressions one and three can.&nbsp; Although many have stated this fact, most have not stated that there is still a way to do this:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">for(</span><span class="default">$i </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">, </span><span class="default">$x </span><span class="keyword">= </span><span class="default">$nums</span><span class="keyword">[</span><span class="string">'x_val'</span><span class="keyword">], </span><span class="default">$n </span><span class="keyword">= </span><span class="default">15</span><span class="keyword">; (</span><span class="default">$i </span><span class="keyword">&lt; </span><span class="default">23 </span><span class="keyword">&amp;&amp; </span><span class="default">$number </span><span class="keyword">!= </span><span class="default">24</span><span class="keyword">); </span><span class="default">$i</span><span class="keyword">++, </span><span class="default">$x </span><span class="keyword">+ </span><span class="default">5</span><span class="keyword">;) {<br />&nbsp; &nbsp; </span><span class="comment">// Do Something with All Those Fun Numbers<br /></span><span class="keyword">}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="34178">  <div class="votes">
    <div id="Vu34178">
    <a href="/manual/vote-note.php?id=34178&amp;page=control-structures.for&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd34178">
    <a href="/manual/vote-note.php?id=34178&amp;page=control-structures.for&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V34178" title="32% like this...">
    -21
    </div>
  </div>
  <a href="#34178" class="name">
  <strong class="user"><em>bishop</em></strong></a><a class="genanchor" href="#34178"> &para;</a><div class="date" title="2003-07-17 01:23"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom34178">
<div class="phpcode"><code><span class="html">
If you're already using the fastest algorithms you can find (on the order of O(1), O(n), or O(n log n)), and you're still worried about loop speed, unroll your loops using e.g., Duff's Device:<br /><br /><span class="default">&lt;?php<br />$n </span><span class="keyword">= </span><span class="default">$ITERATIONS </span><span class="keyword">% </span><span class="default">8</span><span class="keyword">;<br />while (</span><span class="default">$n</span><span class="keyword">--) </span><span class="default">$val</span><span class="keyword">++;<br /></span><span class="default">$n </span><span class="keyword">= (int)(</span><span class="default">$ITERATIONS </span><span class="keyword">/ </span><span class="default">8</span><span class="keyword">);<br />while (</span><span class="default">$n</span><span class="keyword">--) {<br />&nbsp; &nbsp; </span><span class="default">$val</span><span class="keyword">++;<br />&nbsp; &nbsp; </span><span class="default">$val</span><span class="keyword">++;<br />&nbsp; &nbsp; </span><span class="default">$val</span><span class="keyword">++;<br />&nbsp; &nbsp; </span><span class="default">$val</span><span class="keyword">++;<br />&nbsp; &nbsp; </span><span class="default">$val</span><span class="keyword">++;<br />&nbsp; &nbsp; </span><span class="default">$val</span><span class="keyword">++;<br />&nbsp; &nbsp; </span><span class="default">$val</span><span class="keyword">++;<br />&nbsp; &nbsp; </span><span class="default">$val</span><span class="keyword">++;<br />}<br /></span><span class="default">?&gt;<br /></span><br />(This is a modified form of Duff's original device, because PHP doesn't understand the original's egregious syntax.)<br /><br />That's algorithmically equivalent to the common form:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">for (</span><span class="default">$i </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">; </span><span class="default">$i </span><span class="keyword">&lt; </span><span class="default">$ITERATIONS</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">++) {<br />&nbsp; &nbsp; </span><span class="default">$val</span><span class="keyword">++;<br />}<br /></span><span class="default">?&gt;<br /></span><br />$val++ can be whatever operation you need to perform ITERATIONS number of times.<br /><br />On my box, with no users, average run time across 100 samples with ITERATIONS = 10000000 (10 million) is:<br />Duff version:&nbsp; &nbsp; &nbsp;&nbsp; 7.9857 s<br />Obvious version: 27.608 s</span>
</code></div>
  </div>
 </div>
  <div class="note" id="115601">  <div class="votes">
    <div id="Vu115601">
    <a href="/manual/vote-note.php?id=115601&amp;page=control-structures.for&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115601">
    <a href="/manual/vote-note.php?id=115601&amp;page=control-structures.for&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115601" title="25% like this...">
    -18
    </div>
  </div>
  <a href="#115601" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#115601"> &para;</a><div class="date" title="2014-08-23 11:39"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115601">
<div class="phpcode"><code><span class="html">
You can also work with arrays. For example, say you want to generate an array of 12 unique 2-letter strings:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">for (</span><span class="default">$names </span><span class="keyword">= array(); </span><span class="default">count</span><span class="keyword">(</span><span class="default">$names</span><span class="keyword">) &lt; </span><span class="default">12</span><span class="keyword">; </span><span class="default">$names </span><span class="keyword">= </span><span class="default">array_unique</span><span class="keyword">(</span><span class="default">$names</span><span class="keyword">)) {<br />&nbsp; &nbsp; </span><span class="comment">/**<br />&nbsp; &nbsp;&nbsp; * we assume here we have some $faker object<br />&nbsp; &nbsp;&nbsp; * which generates n-letter strings<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="default">$names</span><span class="keyword">[] = </span><span class="default">$faker</span><span class="keyword">-&gt;</span><span class="default">word</span><span class="keyword">(</span><span class="default">2</span><span class="keyword">);<br />}<br /><br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$names</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />will print something like:<br /><br />Array<br />(<br />&nbsp; &nbsp; [0] =&gt; cc<br />&nbsp; &nbsp; [1] =&gt; cb<br />&nbsp; &nbsp; [2] =&gt; dd<br />&nbsp; &nbsp; [3] =&gt; db<br />&nbsp; &nbsp; [4] =&gt; bb<br />&nbsp; &nbsp; [6] =&gt; cd<br />&nbsp; &nbsp; [8] =&gt; aa<br />&nbsp; &nbsp; [9] =&gt; ad<br />&nbsp; &nbsp; [10] =&gt; ca<br />&nbsp; &nbsp; [11] =&gt; ac<br />&nbsp; &nbsp; [12] =&gt; dc<br />&nbsp; &nbsp; [15] =&gt; ab<br />)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="96892">  <div class="votes">
    <div id="Vu96892">
    <a href="/manual/vote-note.php?id=96892&amp;page=control-structures.for&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd96892">
    <a href="/manual/vote-note.php?id=96892&amp;page=control-structures.for&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V96892" title="28% like this...">
    -33
    </div>
  </div>
  <a href="#96892" class="name">
  <strong class="user"><em>kanirockz at gmail dot com</em></strong></a><a class="genanchor" href="#96892"> &para;</a><div class="date" title="2010-03-21 11:48"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom96892">
<div class="phpcode"><code><span class="html">
Here is another simple example for " for loops"<br /><br /><span class="default">&lt;?php<br /><br />$text</span><span class="keyword">=</span><span class="string">"Welcome to PHP"</span><span class="keyword">;<br /></span><span class="default">$searchchar</span><span class="keyword">=</span><span class="string">"e"</span><span class="keyword">;<br /></span><span class="default">$count</span><span class="keyword">=</span><span class="string">"0"</span><span class="keyword">; </span><span class="comment">//zero<br /><br /></span><span class="keyword">for(</span><span class="default">$i</span><span class="keyword">=</span><span class="string">"0"</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">&lt;</span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$text</span><span class="keyword">); </span><span class="default">$i</span><span class="keyword">=</span><span class="default">$i</span><span class="keyword">+</span><span class="default">1</span><span class="keyword">){<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; if(</span><span class="default">substr</span><span class="keyword">(</span><span class="default">$text</span><span class="keyword">,</span><span class="default">$i</span><span class="keyword">,</span><span class="default">1</span><span class="keyword">)==</span><span class="default">$searchchar</span><span class="keyword">){<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$count</span><span class="keyword">=</span><span class="default">$count</span><span class="keyword">+</span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />}<br /><br />echo </span><span class="default">$count<br /><br />?&gt;<br /></span><br />this will be count how many "e" characters in that text (Welcome to PHP)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121394">  <div class="votes">
    <div id="Vu121394">
    <a href="/manual/vote-note.php?id=121394&amp;page=control-structures.for&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121394">
    <a href="/manual/vote-note.php?id=121394&amp;page=control-structures.for&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121394" title="11% like this...">
    -7
    </div>
  </div>
  <a href="#121394" class="name">
  <strong class="user"><em>epicxmoe at gmail dot com</em></strong></a><a class="genanchor" href="#121394"> &para;</a><div class="date" title="2017-07-18 05:21"><strong>4 months ago</strong></div>
  <div class="text" id="Hcom121394">
<div class="phpcode"><code><span class="html">
Adding Letters from A to Z inside an array.<br /><br />You should test it out.<br /><br />&lt;!DOCTYPE html&gt;<br />&lt;html&gt;<br />&lt;body&gt;<br /><span class="default">&lt;?php<br />$letter </span><span class="keyword">= array();<br />for (</span><span class="default">$letters </span><span class="keyword">= </span><span class="string">'A'</span><span class="keyword">; </span><span class="default">$letters </span><span class="keyword">!= </span><span class="string">'AA'</span><span class="keyword">; </span><span class="default">$letters</span><span class="keyword">++)<br />{<br />&nbsp; &nbsp; </span><span class="default">array_push</span><span class="keyword">(</span><span class="default">$letter</span><span class="keyword">, </span><span class="default">$letters</span><span class="keyword">);<br />}<br />echo </span><span class="string">'&lt;pre&gt;' </span><span class="keyword">. </span><span class="default">var_export</span><span class="keyword">(</span><span class="default">$letter</span><span class="keyword">, </span><span class="default">true</span><span class="keyword">) . </span><span class="string">'&lt;/pre&gt;'</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span>&lt;/body&gt;<br />&lt;/html&gt;</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121395">  <div class="votes">
    <div id="Vu121395">
    <a href="/manual/vote-note.php?id=121395&amp;page=control-structures.for&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121395">
    <a href="/manual/vote-note.php?id=121395&amp;page=control-structures.for&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121395" title="9% like this...">
    -9
    </div>
  </div>
  <a href="#121395" class="name">
  <strong class="user"><em>epicxmoe at gmail dot com</em></strong></a><a class="genanchor" href="#121395"> &para;</a><div class="date" title="2017-07-18 05:41"><strong>4 months ago</strong></div>
  <div class="text" id="Hcom121395">
<div class="phpcode"><code><span class="html">
I've tried to search for a results on internet for a basic array which contain letters A to Z inside<br /><br />&lt;!DOCTYPE html&gt;<br />&lt;html&gt;<br />&lt;body&gt;<br /><span class="default">&lt;?php<br />$letter </span><span class="keyword">= array();<br />for (</span><span class="default">$letters </span><span class="keyword">= </span><span class="string">'A'</span><span class="keyword">; </span><span class="default">$letters </span><span class="keyword">!= </span><span class="string">'AA'</span><span class="keyword">; </span><span class="default">$letters</span><span class="keyword">++)<br />{<br />&nbsp; &nbsp; </span><span class="default">array_push</span><span class="keyword">(</span><span class="default">$letter</span><span class="keyword">, </span><span class="default">$letters</span><span class="keyword">);<br />}<br />echo </span><span class="string">'&lt;pre&gt;' </span><span class="keyword">. </span><span class="default">var_export</span><span class="keyword">(</span><span class="default">$letter</span><span class="keyword">, </span><span class="default">true</span><span class="keyword">) . </span><span class="string">'&lt;/pre&gt;'</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span>&lt;/body&gt;<br />&lt;/html&gt;</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=control-structures.for&amp;redirect=http://php.net/manual/en/control-structures.for.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.control-structures.php">Control Structures</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="control-structures.intro.php" title="Introduction">Introduction</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.if.php" title="if">if</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.else.php" title="else">else</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.elseif.php" title="elseif/else if">elseif/else if</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.alternative-syntax.php" title="Alternative syntax for control structures">Alternative syntax for control structures</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.while.php" title="while">while</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.do.while.php" title="do-&#8203;while">do-&#8203;while</a>
                        </li>
                          
                        <li class="current">
                            <a href="control-structures.for.php" title="for">for</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.foreach.php" title="foreach">foreach</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.break.php" title="break">break</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.continue.php" title="continue">continue</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.switch.php" title="switch">switch</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.declare.php" title="declare">declare</a>
                        </li>
                          
                        <li class="">
                            <a href="function.return.php" title="return">return</a>
                        </li>
                          
                        <li class="">
                            <a href="function.require.php" title="require">require</a>
                        </li>
                          
                        <li class="">
                            <a href="function.include.php" title="include">include</a>
                        </li>
                          
                        <li class="">
                            <a href="function.require-once.php" title="require_&#8203;once">require_&#8203;once</a>
                        </li>
                          
                        <li class="">
                            <a href="function.include-once.php" title="include_&#8203;once">include_&#8203;once</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.goto.php" title="goto">goto</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

