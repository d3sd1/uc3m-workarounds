<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Events: December 2017</title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/cal.php">
 <link rel="shorturl" href="http://php.net/cal">
 <link rel="alternate" href="http://php.net/cal" hreflang="x-default">



<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/styles/calendar.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/cal.php">

</head>
<body class="community ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class=""><a href="/docs.php">Documentation</a></li>
      <li class="active"><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>





<div id="layout" class="clearfix">
  <section id="layout-content">
<div class="tip">
 <p>
  If you would like to suggest an upcoming event to be listed on this
  calendar, you can use <a href="submit-event.php">our event submission
  form</a>.
 </p>
 <p>
  You can click on each of the events for details, or on the number for a day
  to get the details for all of the events taking place that day.
 </p>
</div>
<br><table id="calnav" width="100%" border="0" cellspacing="0" cellpadding="3">
<tr><td align="left" width="33%"><a href="/cal.php?cm=11&amp;cy=2017">November, 2017</a></td><td align="center" width="33%"><b>December, 2017</b></td><td align="right" width="33%"><a href="/cal.php?cm=01&amp;cy=2018">January, 2018</a></td></tr>
</table>
<table id="cal" width="100%" border="1" cellspacing="0" cellpadding="3">
<tr>
<th width="14%">Sunday</th>
<th width="14%">Monday</th>
<th width="14%">Tuesday</th>
<th width="14%">Wednesday</th>
<th width="14%">Thursday</th>
<th width="14%">Friday</th>
<th width="14%">Saturday</th>
</tr>
<tr><td class="notaday">&nbsp;</td><td class="notaday">&nbsp;</td><td class="notaday">&nbsp;</td><td class="notaday">&nbsp;</td><td class="notaday">&nbsp;</td><td><a class="day" href="/cal.php?cm=12&amp;cd=1&amp;cy=2017">1</a><div class="event"><a class="cat1" href="/cal.php?id=6106&amp;cm=12&amp;cy=2017">SweetlakePHP</a></div><div class="event"><a class="cat3" href="/cal.php?id=6393&amp;cm=12&amp;cy=2017">Core and Advanced PHP Training</a></div></td><td><a class="day" href="/cal.php?cm=12&amp;cd=2&amp;cy=2017">2</a><div class="event"><a class="cat1" href="/cal.php?id=5955&amp;cm=12&amp;cy=2017">PHP Dorset</a></div><div class="event"><a class="cat3" href="/cal.php?id=3560&amp;cm=12&amp;cy=2017">Core and Advanced PHP Workshop</a></div></td></tr>
<tr><td><a class="day" href="/cal.php?cm=12&amp;cd=3&amp;cy=2017">3</a><div class="event"><a class="cat1" href="/cal.php?id=1923&amp;cm=12&amp;cy=2017">PHP meeting online in China</a></div><div class="event"><a class="cat1" href="/cal.php?id=2540&amp;cm=12&amp;cy=2017">meeting de LAMPistas en La Paz</a></div><div class="event"><a class="cat1" href="/cal.php?id=6117&amp;cm=12&amp;cy=2017">PHP User Group Meeting</a></div></td><td><a class="day" href="/cal.php?cm=12&amp;cd=4&amp;cy=2017">4</a><div class="event"><a class="cat2" href="/cal.php?id=5377&amp;cm=12&amp;cy=2017">PHP with YII Training Event</a></div><div class="event"><a class="cat3" href="/cal.php?id=1981&amp;cm=12&amp;cy=2017">Curso on-line de PHP</a></div><div class="event"><a class="cat3" href="/cal.php?id=5298&amp;cm=12&amp;cy=2017">Basic PHP Course</a></div><div class="event"><a class="cat3" href="/cal.php?id=5798&amp;cm=12&amp;cy=2017">Formation Zend Framework</a></div></td><td><a class="day" href="/cal.php?cm=12&amp;cd=5&amp;cy=2017">5</a><div class="event"><a class="cat1" href="/cal.php?id=1745&amp;cm=12&amp;cy=2017">SW Florida Linux Users Group</a></div><div class="event"><a class="cat1" href="/cal.php?id=2814&amp;cm=12&amp;cy=2017">Berlin PHP Usergroup Meeting</a></div><div class="event"><a class="cat1" href="/cal.php?id=3294&amp;cm=12&amp;cy=2017">PHPNW: PHP North West user group</a></div><div class="event"><a class="cat1" href="/cal.php?id=5527&amp;cm=12&amp;cy=2017">Greater Toronto Area PHP UG</a></div><div class="event"><a class="cat1" href="/cal.php?id=5952&amp;cm=12&amp;cy=2017">PHP London</a></div><div class="event"><a class="cat1" href="/cal.php?id=5971&amp;cm=12&amp;cy=2017">PHPem: PHP East Midlands</a></div><div class="event"><a class="cat1" href="/cal.php?id=6090&amp;cm=12&amp;cy=2017">GroningenPHP</a></div><div class="event"><a class="cat3" href="/cal.php?id=841&amp;cm=12&amp;cy=2017">Curso on-line de PHP-MySQL</a></div><div class="event"><a class="cat3" href="/cal.php?id=1490&amp;cm=12&amp;cy=2017">PHP Class at CalTek</a></div></td><td><a class="day" href="/cal.php?cm=12&amp;cd=6&amp;cy=2017">6</a><div class="event"><a class="cat1" href="/cal.php?id=2682&amp;cm=12&amp;cy=2017">BostonPHP</a></div><div class="event"><a class="cat1" href="/cal.php?id=3793&amp;cm=12&amp;cy=2017">Pittsburgh PHP Meetup Group</a></div><div class="event"><a class="cat1" href="/cal.php?id=5473&amp;cm=12&amp;cy=2017">Kuala Lumpur PHP</a></div><div class="event"><a class="cat3" href="/cal.php?id=5305&amp;cm=12&amp;cy=2017">PHP: Web-sites and MySQL</a></div><div class="event"><a class="cat3" href="/cal.php?id=6416&amp;cm=12&amp;cy=2017">Basic Laravel and PHP Course</a></div></td><td><a class="day" href="/cal.php?cm=12&amp;cd=7&amp;cy=2017">7</a><div class="event"><a class="cat1" href="/cal.php?id=272&amp;cm=12&amp;cy=2017">Hannover</a></div><div class="event"><a class="cat1" href="/cal.php?id=561&amp;cm=12&amp;cy=2017">Meetup Day</a></div><div class="event"><a class="cat1" href="/cal.php?id=1304&amp;cm=12&amp;cy=2017">PHP London</a></div><div class="event"><a class="cat1" href="/cal.php?id=1632&amp;cm=12&amp;cy=2017">Boston PHP Meetup</a></div><div class="event"><a class="cat1" href="/cal.php?id=1706&amp;cm=12&amp;cy=2017">Atlanta PHP User Group</a></div><div class="event"><a class="cat1" href="/cal.php?id=2418&amp;cm=12&amp;cy=2017">Seattle PHP Meetup Group</a></div><div class="event"><a class="cat1" href="/cal.php?id=2932&amp;cm=12&amp;cy=2017">SF PHP Meetup</a></div><div class="event"><a class="cat1" href="/cal.php?id=3861&amp;cm=12&amp;cy=2017">Minnesota PHP User Group</a></div><div class="event"><a class="cat1" href="/cal.php?id=4014&amp;cm=12&amp;cy=2017">OrlandoPHP User Group</a></div><div class="event"><a class="cat1" href="/cal.php?id=5519&amp;cm=12&amp;cy=2017">PHPTwente Meetup</a></div><div class="event"><a class="cat1" href="/cal.php?id=5685&amp;cm=12&amp;cy=2017">Vilnius PHP community meetup</a></div></td><td><a class="day" href="/cal.php?cm=12&amp;cd=8&amp;cy=2017">8</a><div class="event"><a class="cat3" href="/cal.php?id=6291&amp;cm=12&amp;cy=2017">PHP Training in Rajkot</a></div></td><td><a class="day" href="/cal.php?cm=12&amp;cd=9&amp;cy=2017">9</a><div class="event"><a class="cat1" href="/cal.php?id=4258&amp;cm=12&amp;cy=2017">Nezahualcoyotl PHP Ramptors</a></div></td></tr>
<tr><td><a class="day" href="/cal.php?cm=12&amp;cd=10&amp;cy=2017">10</a><div class="event"><a class="cat1" href="/cal.php?id=3760&amp;cm=12&amp;cy=2017">Los Angeles PHP Developers Group</a></div><div class="event"><a class="cat3" href="/cal.php?id=6392&amp;cm=12&amp;cy=2017">PHP Training center in rajkot</a></div></td><td><a class="day" href="/cal.php?cm=12&amp;cd=11&amp;cy=2017">11</a><div class="event"><a class="cat1" href="/cal.php?id=4308&amp;cm=12&amp;cy=2017">Queen City (Charlotte) PHP</a></div><div class="event"><a class="cat3" href="/cal.php?id=5700&amp;cm=12&amp;cy=2017">Formation PHP MySQL - France</a></div></td><td><a class="day" href="/cal.php?cm=12&amp;cd=12&amp;cy=2017">12</a><div class="event"><a class="cat1" href="/cal.php?id=1385&amp;cm=12&amp;cy=2017">Hamburg</a></div><div class="event"><a class="cat1" href="/cal.php?id=1523&amp;cm=12&amp;cy=2017">Dallas PHP/MySQL Users Group</a></div><div class="event"><a class="cat1" href="/cal.php?id=1670&amp;cm=12&amp;cy=2017">Dallas PHP Users Group (DPUG)</a></div><div class="event"><a class="cat1" href="/cal.php?id=1665&amp;cm=12&amp;cy=2017">OKC PHP Meetup</a></div><div class="event"><a class="cat1" href="/cal.php?id=1847&amp;cm=12&amp;cy=2017">Nashville PHP User Group</a></div><div class="event"><a class="cat1" href="/cal.php?id=3643&amp;cm=12&amp;cy=2017">Oklahoma City PHP User Group</a></div><div class="event"><a class="cat1" href="/cal.php?id=3980&amp;cm=12&amp;cy=2017">Buffalo PHP Meetup</a></div><div class="event"><a class="cat1" href="/cal.php?id=5701&amp;cm=12&amp;cy=2017">Milwaukee PHP User\&#039;s Group</a></div><div class="event"><a class="cat1" href="/cal.php?id=6148&amp;cm=12&amp;cy=2017">PHP Amersfoort</a></div></td><td><a class="day" href="/cal.php?cm=12&amp;cd=13&amp;cy=2017">13</a><div class="event"><a class="cat1" href="/cal.php?id=3684&amp;cm=12&amp;cy=2017">PHP User Group Stuttgart</a></div><div class="event"><a class="cat1" href="/cal.php?id=4222&amp;cm=12&amp;cy=2017">South Florida PHP Users Group</a></div><div class="event"><a class="cat1" href="/cal.php?id=5910&amp;cm=12&amp;cy=2017">PHP Hampshire meetup</a></div><div class="event"><a class="cat1" href="/cal.php?id=5212&amp;cm=12&amp;cy=2017">DC PHP Developer&#039;s Community</a></div><div class="event"><a class="cat1" href="/cal.php?id=5388&amp;cm=12&amp;cy=2017">VenturaPHP Developers Meetup</a></div><div class="event"><a class="cat1" href="/cal.php?id=6940&amp;cm=12&amp;cy=2017">Peak PHP</a></div></td><td><a class="day" href="/cal.php?cm=12&amp;cd=14&amp;cy=2017">14</a><div class="event"><a class="cat1" href="/cal.php?id=1652&amp;cm=12&amp;cy=2017">Austin PHP Meetup</a></div><div class="event"><a class="cat1" href="/cal.php?id=1848&amp;cm=12&amp;cy=2017">Meeting usergroup Dortmund</a></div><div class="event"><a class="cat1" href="/cal.php?id=1946&amp;cm=12&amp;cy=2017">PHP Usergroup Frankfurt/Main</a></div><div class="event"><a class="cat1" href="/cal.php?id=5322&amp;cm=12&amp;cy=2017">Seattle PHP Meetup/Users Group</a></div><div class="event"><a class="cat1" href="/cal.php?id=5839&amp;cm=12&amp;cy=2017">010PHP Rotterdam User Group</a></div></td><td><a class="day" href="/cal.php?cm=12&amp;cd=15&amp;cy=2017">15</a><div class="event"><a class="cat3" href="/cal.php?id=6391&amp;cm=12&amp;cy=2017">PHP Training</a></div></td><td><a class="day" href="/cal.php?cm=12&amp;cd=16&amp;cy=2017">16</a><div class="event"><a class="cat1" href="/cal.php?id=2449&amp;cm=12&amp;cy=2017">Los Angeles LAMPsig</a></div><div class="event"><a class="cat1" href="/cal.php?id=5401&amp;cm=12&amp;cy=2017">Kansas City</a></div><div class="event"><a class="cat1" href="/cal.php?id=6176&amp;cm=12&amp;cy=2017">PHPKonf: PHP User Group</a></div><div class="event"><a class="cat1" href="/cal.php?id=6456&amp;cm=12&amp;cy=2017">UpstatePHP</a></div></td></tr>
<tr><td><a class="day" href="/cal.php?cm=12&amp;cd=17&amp;cy=2017">17</a><div class="event"><a class="cat1" href="/cal.php?id=6118&amp;cm=12&amp;cy=2017">PHP User Group Hack Night</a></div><div class="event"><a class="cat1" href="/cal.php?id=6400&amp;cm=12&amp;cy=2017">Kaunas PHP community meetup</a></div><div class="event"><a class="cat3" href="/cal.php?id=5978&amp;cm=12&amp;cy=2017">Formation Zend Framework</a></div></td><td><a class="day" href="/cal.php?cm=12&amp;cd=18&amp;cy=2017">18</a><div class="event"><a class="cat1" href="/cal.php?id=5533&amp;cm=12&amp;cy=2017">BrightonPHP User Group</a></div><div class="event"><a class="cat1" href="/cal.php?id=5992&amp;cm=12&amp;cy=2017">Symfony User Group Cologne</a></div><div class="event"><a class="cat1" href="/cal.php?id=6396&amp;cm=12&amp;cy=2017">PHPMinds User Group</a></div></td><td><a class="day" href="/cal.php?cm=12&amp;cd=19&amp;cy=2017">19</a><div class="event"><a class="cat1" href="/cal.php?id=2246&amp;cm=12&amp;cy=2017">PHP Brisbane Meetup Group</a></div><div class="event"><a class="cat1" href="/cal.php?id=3761&amp;cm=12&amp;cy=2017">Chattanooga PHP Developers</a></div><div class="event"><a class="cat1" href="/cal.php?id=4725&amp;cm=12&amp;cy=2017">PHP North-East User Group</a></div><div class="event"><a class="cat1" href="/cal.php?id=5222&amp;cm=12&amp;cy=2017">NWO-PUG User Group Meeting</a></div><div class="event"><a class="cat1" href="/cal.php?id=5370&amp;cm=12&amp;cy=2017">Lake / Kenosha PHP User Group</a></div><div class="event"><a class="cat1" href="/cal.php?id=5474&amp;cm=12&amp;cy=2017">Tallahassee PHP User Group</a></div><div class="event"><a class="cat1" href="/cal.php?id=5831&amp;cm=12&amp;cy=2017">Melbourne PHP Users Group</a></div><div class="event"><a class="cat1" href="/cal.php?id=5797&amp;cm=12&amp;cy=2017">Edinburgh PHP User Group</a></div><div class="event"><a class="cat1" href="/cal.php?id=5963&amp;cm=12&amp;cy=2017">Oklahoma PHP User Group</a></div><div class="event"><a class="cat1" href="/cal.php?id=5953&amp;cm=12&amp;cy=2017">Zagreb PHP Meetup</a></div><div class="event"><a class="cat1" href="/cal.php?id=6226&amp;cm=12&amp;cy=2017">PHP.FRL Monthly Meeting</a></div></td><td><a class="day" href="/cal.php?cm=12&amp;cd=20&amp;cy=2017">20</a></td><td><a class="day" href="/cal.php?cm=12&amp;cd=21&amp;cy=2017">21</a><div class="event"><a class="cat1" href="/cal.php?id=1719&amp;cm=12&amp;cy=2017">OINK-PUG (Cincinnati, Ohio)</a></div><div class="event"><a class="cat1" href="/cal.php?id=1820&amp;cm=12&amp;cy=2017">Utah PHP Users Group Meeting</a></div><div class="event"><a class="cat1" href="/cal.php?id=4507&amp;cm=12&amp;cy=2017">Denver - FRPUG</a></div><div class="event"><a class="cat1" href="/cal.php?id=5372&amp;cm=12&amp;cy=2017">San Diego PHP</a></div><div class="event"><a class="cat1" href="/cal.php?id=5343&amp;cm=12&amp;cy=2017">AmsterdamPHP Meetup</a></div><div class="event"><a class="cat1" href="/cal.php?id=5427&amp;cm=12&amp;cy=2017">UPHPU Utah PHP Users</a></div><div class="event"><a class="cat1" href="/cal.php?id=5723&amp;cm=12&amp;cy=2017">Kent PHP User Group</a></div><div class="event"><a class="cat1" href="/cal.php?id=6538&amp;cm=12&amp;cy=2017">PHP North East</a></div></td><td><a class="day" href="/cal.php?cm=12&amp;cd=22&amp;cy=2017">22</a></td><td><a class="day" href="/cal.php?cm=12&amp;cd=23&amp;cy=2017">23</a></td></tr>
<tr><td><a class="day" href="/cal.php?cm=12&amp;cd=24&amp;cy=2017">24</a></td><td><a class="day" href="/cal.php?cm=12&amp;cd=25&amp;cy=2017">25</a><div class="event"><a class="cat1" href="/cal.php?id=4648&amp;cm=12&amp;cy=2017">Tampa Bay Florida PHP</a></div><div class="event"><a class="cat1" href="/cal.php?id=5985&amp;cm=12&amp;cy=2017">PHP Cambridge</a></div><div class="event"><a class="cat3" href="/cal.php?id=2421&amp;cm=12&amp;cy=2017">Basic PHP Course</a></div><div class="event"><a class="cat3" href="/cal.php?id=5699&amp;cm=12&amp;cy=2017">Formation PHP expert - France</a></div><div class="event"><a class="cat3" href="/cal.php?id=5384&amp;cm=12&amp;cy=2017">Formation PHP 7</a></div></td><td><a class="day" href="/cal.php?cm=12&amp;cd=26&amp;cy=2017">26</a><div class="event"><a class="cat1" href="/cal.php?id=409&amp;cm=12&amp;cy=2017">New York</a></div><div class="event"><a class="cat1" href="/cal.php?id=384&amp;cm=12&amp;cy=2017">AzPHP</a></div><div class="event"><a class="cat1" href="/cal.php?id=2660&amp;cm=12&amp;cy=2017">PHPUG Wuerzburg</a></div><div class="event"><a class="cat1" href="/cal.php?id=3653&amp;cm=12&amp;cy=2017">Brisbane PHP User Group</a></div><div class="event"><a class="cat1" href="/cal.php?id=4626&amp;cm=12&amp;cy=2017">PHP User Group Roma</a></div><div class="event"><a class="cat1" href="/cal.php?id=5276&amp;cm=12&amp;cy=2017">PHPUBSP</a></div></td><td><a class="day" href="/cal.php?cm=12&amp;cd=27&amp;cy=2017">27</a></td><td><a class="day" href="/cal.php?cm=12&amp;cd=28&amp;cy=2017">28</a><div class="event"><a class="cat1" href="/cal.php?id=4256&amp;cm=12&amp;cy=2017">Memphis PHP</a></div><div class="event"><a class="cat1" href="/cal.php?id=6245&amp;cm=12&amp;cy=2017">PHP UserGroup Erlangen-N&uuml;rnberg</a></div></td><td><a class="day" href="/cal.php?cm=12&amp;cd=29&amp;cy=2017">29</a></td><td><a class="day" href="/cal.php?cm=12&amp;cd=30&amp;cy=2017">30</a></td></tr>
<tr><td><a class="day" href="/cal.php?cm=12&amp;cd=31&amp;cy=2017">31</a></td><td class="notaday">&nbsp;</td><td class="notaday">&nbsp;</td><td class="notaday">&nbsp;</td><td class="notaday">&nbsp;</td><td class="notaday">&nbsp;</td><td class="notaday">&nbsp;</td></tr>
</table>
    </section><!-- layout-content -->
    

  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

