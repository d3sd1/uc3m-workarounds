<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: $_GET - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/reserved.variables.get.php">
 <link rel="shorturl" href="http://php.net/manual/en/reserved.variables.get.php">
 <link rel="alternate" href="http://php.net/manual/en/reserved.variables.get.php" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/reserved.variables.php">
 <link rel="prev" href="http://php.net/manual/en/reserved.variables.server.php">
 <link rel="next" href="http://php.net/manual/en/reserved.variables.post.php">

 <link rel="alternate" href="http://php.net/manual/en/reserved.variables.get.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/reserved.variables.get.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/reserved.variables.get.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/reserved.variables.get.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/reserved.variables.get.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/reserved.variables.get.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/reserved.variables.get.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/reserved.variables.get.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/reserved.variables.get.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/reserved.variables.get.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/reserved.variables.get.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="reserved.variables.post.php">
          $_POST &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="reserved.variables.server.php">
          &laquo; $_SERVER        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='reserved.variables.php'>Predefined Variables</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/reserved.variables.get.php' selected="selected">English</option>
            <option value='pt_BR/reserved.variables.get.php'>Brazilian Portuguese</option>
            <option value='zh/reserved.variables.get.php'>Chinese (Simplified)</option>
            <option value='fr/reserved.variables.get.php'>French</option>
            <option value='de/reserved.variables.get.php'>German</option>
            <option value='ja/reserved.variables.get.php'>Japanese</option>
            <option value='ro/reserved.variables.get.php'>Romanian</option>
            <option value='ru/reserved.variables.get.php'>Russian</option>
            <option value='es/reserved.variables.get.php'>Spanish</option>
            <option value='tr/reserved.variables.get.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/reserved.variables.get.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=reserved.variables.get">Report a Bug</a>
    </div>
  </div><div id="reserved.variables.get" class="refentry">
 <div class="refnamediv">
  <h1 class="refname">$_GET</h1>
  <h1 class="refname">$HTTP_GET_VARS [deprecated]</h1>
  <p class="verinfo">(PHP 4 &gt;= 4.1.0, PHP 5, PHP 7)</p><p class="refpurpose"><span class="refname">$_GET</span> -- <span class="refname">$HTTP_GET_VARS [deprecated]</span> &mdash; <span class="dc-title">HTTP GET variables</span></p>

 </div>
 
 <div class="refsect1 description" id="refsect1-reserved.variables.get-description">
  <h3 class="title">Description</h3>
  <p class="para">
   An associative array of variables passed to the current script
   via the URL parameters.
  </p>

  <p class="simpara">
   <var class="varname"><var class="varname">$HTTP_GET_VARS</var></var> contains the same initial
   information, but is not a <a href="language.variables.superglobals.php" class="link">superglobal</a>.
   (Note that <var class="varname"><var class="varname">$HTTP_GET_VARS</var></var> and <var class="varname"><var class="varname">$_GET</var></var>
   are different variables and that PHP handles them as such)
  </p>

 </div>

 

 <div class="refsect1 changelog" id="refsect1-reserved.variables.get-changelog">
  <h3 class="title">Changelog</h3>
  <p class="para">
   <table class="doctable informaltable">
    
     <thead>
      <tr>
       <th>Version</th>
       <th>Description</th>
      </tr>

     </thead>

     <tbody class="tbody">
      <tr>
       <td>4.1.0</td>
       <td>
        Introduced <var class="varname"><var class="varname">$_GET</var></var> that deprecated
        <var class="varname"><var class="varname">$HTTP_GET_VARS</var></var>.
       </td>
      </tr>

     </tbody>
    
   </table>

  </p>
 </div>

 
 <div class="refsect1 examples" id="refsect1-reserved.variables.get-examples">
  <h3 class="title">Examples</h3>
  <p class="para">
   <div class="example" id="example-297">
    <p><strong>Example #1 <var class="varname"><var class="varname">$_GET</var></var> example</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #DD0000">'Hello&nbsp;'&nbsp;</span><span style="color: #007700">.&nbsp;</span><span style="color: #0000BB">htmlspecialchars</span><span style="color: #007700">(</span><span style="color: #0000BB">$_GET</span><span style="color: #007700">[</span><span style="color: #DD0000">"name"</span><span style="color: #007700">])&nbsp;.&nbsp;</span><span style="color: #DD0000">'!'</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

    <div class="example-contents"><p>
     Assuming the user entered http://example.com/?name=Hannes
    </p></div>
    <div class="example-contents"><p>The above example will output
something similar to:</p></div>
    <div class="example-contents screen">
<div class="cdata"><pre>
Hello Hannes!
</pre></div>
    </div>
   </div>
  </p>
 </div>

 
 <div class="refsect1 notes" id="refsect1-reserved.variables.get-notes">
  <h3 class="title">Notes</h3>
  <blockquote class="note"><p><strong class="note">Note</strong>: <p class="para">This is a &#039;superglobal&#039;, or
automatic global, variable. This simply means that it is available in
all scopes throughout a script. There is no need to do
<strong class="command">global $variable;</strong> to access it within functions or methods.
</p></p></blockquote>
  <blockquote class="note"><p><strong class="note">Note</strong>: 
   <p class="para">
    The GET variables are passed through <span class="function"><a href="function.urldecode.php" class="function">urldecode()</a></span>.
   </p>
  </p></blockquote>
 </div>


 <div class="refsect1 seealso" id="refsect1-reserved.variables.get-seealso">
  <h3 class="title">See Also</h3>
  <p class="para">
   <ul class="simplelist">
    <li class="member"><a href="language.variables.external.php" class="link">Handling external variables</a></li>
    <li class="member"><a href="book.filter.php" class="link">The filter extension</a></li>
   </ul>
  </p>
 </div>


</div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=reserved.variables.get&amp;redirect=http://php.net/manual/en/reserved.variables.get.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">14 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="98419">  <div class="votes">
    <div id="Vu98419">
    <a href="/manual/vote-note.php?id=98419&amp;page=reserved.variables.get&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd98419">
    <a href="/manual/vote-note.php?id=98419&amp;page=reserved.variables.get&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V98419" title="69% like this...">
    169
    </div>
  </div>
  <a href="#98419" class="name">
  <strong class="user"><em>John Galt</em></strong></a><a class="genanchor" href="#98419"> &para;</a><div class="date" title="2010-06-14 05:57"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom98419">
<div class="phpcode"><code><span class="html">
Just a note, because I didn't know for sure until I tested it.<br /><br />If you have a query string that contains a parameter but no value (not even an equals sign), like so:<br /><a href="http://path/to/script.php?a" rel="nofollow" target="_blank">http://path/to/script.php?a</a><br /><br />The following script is a good test to determine how a is valued:<br />&lt;pre&gt;<br /><span class="default">&lt;?php<br /> print_r</span><span class="keyword">(</span><span class="default">$_GET</span><span class="keyword">);<br /> if(</span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">"a"</span><span class="keyword">] === </span><span class="string">""</span><span class="keyword">) echo </span><span class="string">"a is an empty string\n"</span><span class="keyword">;<br /> if(</span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">"a"</span><span class="keyword">] === </span><span class="default">false</span><span class="keyword">) echo </span><span class="string">"a is false\n"</span><span class="keyword">;<br /> if(</span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">"a"</span><span class="keyword">] === </span><span class="default">null</span><span class="keyword">) echo </span><span class="string">"a is null\n"</span><span class="keyword">;<br /> if(isset(</span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">"a"</span><span class="keyword">])) echo </span><span class="string">"a is set\n"</span><span class="keyword">;<br /> if(!empty(</span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">"a"</span><span class="keyword">])) echo </span><span class="string">"a is not empty"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span>&lt;/pre&gt;<br /><br />I tested this with script.php?a, and it returned:<br /><br />a is an empty string<br />a is set<br /><br />So note that a parameter with no value associated with, even without an equals sign, is considered to be an empty string (""), isset() returns true for it, and it is considered empty, but not false or null. Seems obvious after the first test, but I just had to make sure.<br /><br />Of course, if I do not include it in my browser query, the script returns<br />Array<br />(<br />)<br />a is null</span>
</code></div>
  </div>
 </div>
  <div class="note" id="83200">  <div class="votes">
    <div id="Vu83200">
    <a href="/manual/vote-note.php?id=83200&amp;page=reserved.variables.get&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd83200">
    <a href="/manual/vote-note.php?id=83200&amp;page=reserved.variables.get&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V83200" title="51% like this...">
    5
    </div>
  </div>
  <a href="#83200" class="name">
  <strong class="user"><em>timberspine _AT_ gmail _DOT_ com</em></strong></a><a class="genanchor" href="#83200"> &para;</a><div class="date" title="2008-05-14 04:38"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom83200">
<div class="phpcode"><code><span class="html">
Note that named anchors are not part of the query string and are never submitted by the browser to the server.<br /><br />Eg.<br /><a href="http://www.xyz-abc.kz/index.php?title=apocalypse.php#doom" rel="nofollow" target="_blank">http://www.xyz-abc.kz/index.php?title=apocalypse.php#doom</a><br /><br />echo $_GET['title']; <br /><br />// returns "apocalypse.php" and NOT "apocalypse.php#doom"<br /><br />you would be better off treating the named anchor as another query string variable like so:<br /><a href="http://www.xyz-abc.kz/index.php?title=apocalypse.php&amp;na=doom" rel="nofollow" target="_blank">http://www.xyz-abc.kz/index.php?title=apocalypse.php&amp;na=doom</a><br /><br />...and then retrieve it using something like this:<br />$url = $_GET['title']."#".$_GET['na'];<br /><br />Hope this helps someone...</span>
</code></div>
  </div>
 </div>
  <div class="note" id="101469">  <div class="votes">
    <div id="Vu101469">
    <a href="/manual/vote-note.php?id=101469&amp;page=reserved.variables.get&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd101469">
    <a href="/manual/vote-note.php?id=101469&amp;page=reserved.variables.get&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V101469" title="49% like this...">
    -1
    </div>
  </div>
  <a href="#101469" class="name">
  <strong class="user"><em>chris at bjelleklang dot org</em></strong></a><a class="genanchor" href="#101469"> &para;</a><div class="date" title="2010-12-18 02:40"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom101469">
<div class="phpcode"><code><span class="html">
Please note that PHP setups with the suhosin patch installed will have a default limit of 512 characters for get parameters. Although bad practice, most browsers (including IE) supports URLs up to around 2000 characters, while Apache has a default of 8000. <br /><br />To add support for long parameters with suhosin, add <br />suhosin.get.max_value_length = &lt;limit&gt; in php.ini</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120722">  <div class="votes">
    <div id="Vu120722">
    <a href="/manual/vote-note.php?id=120722&amp;page=reserved.variables.get&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120722">
    <a href="/manual/vote-note.php?id=120722&amp;page=reserved.variables.get&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120722" title="46% like this...">
    -2
    </div>
  </div>
  <a href="#120722" class="name">
  <strong class="user"><em>nggit at anggit dot com</em></strong></a><a class="genanchor" href="#120722"> &para;</a><div class="date" title="2017-03-02 05:58"><strong>9 months ago</strong></div>
  <div class="text" id="Hcom120722">
<div class="phpcode"><code><span class="html">
Sometimes I do not want to use isset() or array_key_exists() to check the index exists or not, but rather choose to define in advance. Union array operator&nbsp; is pretty handy for me:<br /><br /><span class="default">&lt;?php<br /><br />$_GET </span><span class="keyword">+= array(</span><span class="string">'foo' </span><span class="keyword">=&gt; </span><span class="default">null</span><span class="keyword">, </span><span class="string">'bar' </span><span class="keyword">=&gt; </span><span class="default">null</span><span class="keyword">); </span><span class="comment">// define<br /><br /></span><span class="keyword">echo </span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">'foo'</span><span class="keyword">];<br />echo </span><span class="default">$_GET</span><span class="keyword">[</span><span class="string">'baz'</span><span class="keyword">]; </span><span class="comment">// Notice: Undefined index: baz in...<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="115890">  <div class="votes">
    <div id="Vu115890">
    <a href="/manual/vote-note.php?id=115890&amp;page=reserved.variables.get&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115890">
    <a href="/manual/vote-note.php?id=115890&amp;page=reserved.variables.get&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115890" title="47% like this...">
    -9
    </div>
  </div>
  <a href="#115890" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#115890"> &para;</a><div class="date" title="2014-10-10 01:11"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115890">
<div class="phpcode"><code><span class="html">
There is a smart way to protect the $ _GET input from malicious injection and options for inserting default values:<br /><span class="default">&lt;?php <br /></span><span class="comment">// Smart GET function<br /></span><span class="keyword">public function </span><span class="default">GET</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">=</span><span class="default">NULL</span><span class="keyword">, </span><span class="default">$value</span><span class="keyword">=</span><span class="default">false</span><span class="keyword">, </span><span class="default">$option</span><span class="keyword">=</span><span class="string">"default"</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="default">$option</span><span class="keyword">=</span><span class="default">false</span><span class="keyword">; </span><span class="comment">// Old version depricated part<br />&nbsp; &nbsp; </span><span class="default">$content</span><span class="keyword">=(!empty(</span><span class="default">$_GET</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">]) ? </span><span class="default">trim</span><span class="keyword">(</span><span class="default">$_GET</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">]) : (!empty(</span><span class="default">$value</span><span class="keyword">) &amp;&amp; !</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">) ? </span><span class="default">trim</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">) : </span><span class="default">false</span><span class="keyword">));<br />&nbsp; &nbsp; if(</span><span class="default">is_numeric</span><span class="keyword">(</span><span class="default">$content</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">preg_replace</span><span class="keyword">(</span><span class="string">"@([^0-9])@Ui"</span><span class="keyword">, </span><span class="string">""</span><span class="keyword">, </span><span class="default">$content</span><span class="keyword">);<br />&nbsp; &nbsp; else if(</span><span class="default">is_bool</span><span class="keyword">(</span><span class="default">$content</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; return (</span><span class="default">$content</span><span class="keyword">?</span><span class="default">true</span><span class="keyword">:</span><span class="default">false</span><span class="keyword">);<br />&nbsp; &nbsp; else if(</span><span class="default">is_float</span><span class="keyword">(</span><span class="default">$content</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">preg_replace</span><span class="keyword">(</span><span class="string">"@([^0-9\,\.\+\-])@Ui"</span><span class="keyword">, </span><span class="string">""</span><span class="keyword">, </span><span class="default">$content</span><span class="keyword">);<br />&nbsp; &nbsp; else if(</span><span class="default">is_string</span><span class="keyword">(</span><span class="default">$content</span><span class="keyword">))<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">filter_var </span><span class="keyword">(</span><span class="default">$content</span><span class="keyword">, </span><span class="default">FILTER_VALIDATE_URL</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$content</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; else if(</span><span class="default">filter_var </span><span class="keyword">(</span><span class="default">$content</span><span class="keyword">, </span><span class="default">FILTER_VALIDATE_EMAIL</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$content</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; else if(</span><span class="default">filter_var </span><span class="keyword">(</span><span class="default">$content</span><span class="keyword">, </span><span class="default">FILTER_VALIDATE_IP</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$content</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; else if(</span><span class="default">filter_var </span><span class="keyword">(</span><span class="default">$content</span><span class="keyword">, </span><span class="default">FILTER_VALIDATE_FLOAT</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$content</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">preg_replace</span><span class="keyword">(</span><span class="string">"@([^a-zA-Z0-9\+\-\_\*\@\$\!\;\.\?\#\:\=\%\/\ ]+)@Ui"</span><span class="keyword">, </span><span class="string">""</span><span class="keyword">, </span><span class="default">$content</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; else </span><span class="default">false</span><span class="keyword">;<br />}<br /></span><span class="comment">/*<br /> DEFAULT: $_GET['page'];<br /> SMART: GET('page'); // return value or false if is null or bad input<br />*/<br /></span><span class="default">?&gt;<br /></span>I hope this is helpful. Cheers ;)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="93877">  <div class="votes">
    <div id="Vu93877">
    <a href="/manual/vote-note.php?id=93877&amp;page=reserved.variables.get&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd93877">
    <a href="/manual/vote-note.php?id=93877&amp;page=reserved.variables.get&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V93877" title="46% like this...">
    -10
    </div>
  </div>
  <a href="#93877" class="name">
  <strong class="user"><em>Alberto Lepe dev at alepe dot com</em></strong></a><a class="genanchor" href="#93877"> &para;</a><div class="date" title="2009-10-04 09:23"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom93877">
<div class="phpcode"><code><span class="html">
This Function will help you to manage your GET parameters to facilitate coding and prevent duplication. This is a basic version but it can be easily extended.<br /><br /><span class="default">&lt;?php<br />&nbsp;&nbsp; </span><span class="comment">// Author: Alberto Lepe (www.alepe.com)<br />&nbsp; &nbsp; /* Process $_GET to preserve user custom parameters<br />&nbsp; &nbsp;&nbsp; * the arguments is a list of URL parameters that should be removed/changed from URL<br />&nbsp; &nbsp;&nbsp; * for example:<br />&nbsp; &nbsp;&nbsp; *<br />&nbsp; &nbsp;&nbsp; * URL = "index.php?s=1&amp;fi=2&amp;m=4&amp;p=3<br />&nbsp; &nbsp;&nbsp; *<br />&nbsp; &nbsp;&nbsp; * if called: fixGet("s"); the result has to be: ?fi=2&amp;m=4&amp;p=3<br />&nbsp; &nbsp;&nbsp; * if called: fixGet("s&amp;m"); the result has to be: ?fi=2&amp;p=3<br />&nbsp; &nbsp;&nbsp; * if called: fixGet("s=4"); the result has to be: ?s=4&amp;fi=2&amp;m=4&amp;p=3<br />&nbsp; &nbsp;&nbsp; * if called: fixGet("s=2&amp;m"); the result has to be: ?s=2&amp;fi=2&amp;p=3<br />&nbsp; &nbsp;&nbsp; * if called: fixGet("s=&amp;m=3"); the result has to be: ?s=&amp;fi=2&amp;m=3&amp;p=3<br />&nbsp; &nbsp;&nbsp; * if called: fixGet("s=2&amp;m="); the result has to be: ?s=2&amp;fi=2&amp;m=&amp;p=3<br />&nbsp; &nbsp;&nbsp; * Special: when it ends with a =":" its to leave it open at the end<br />&nbsp; &nbsp;&nbsp; * (just first occurrence) to facilitate concatenation:<br />&nbsp; &nbsp;&nbsp; * if called: fixGet("s=2&amp;m:"); the result has to be: ?s=2&amp;fi=2&amp;p=3&amp;m<br />&nbsp; &nbsp;&nbsp; * if called: fixGet("s=2&amp;m:="); the result has to be: ?s=2&amp;fi=2&amp;p=3&amp;m=<br />&nbsp; &nbsp;&nbsp; * <br />&nbsp; &nbsp;&nbsp; * Usage with HTML (using the URL example above and $id = 99):<br />&nbsp; &nbsp;&nbsp; * <br />&nbsp; &nbsp;&nbsp; * &lt;a href="index.php&lt;?php echo fixGet('m=2&amp;s&amp;fi:=').$id ?&gt;" &gt;Link&lt;/a&gt;<br />&nbsp; &nbsp;&nbsp; * Explanation: change "m" to 2, delete "s" and "fi" gets the $id value. ("p" is kept as it is not specified)<br />&nbsp; &nbsp;&nbsp; * will output: &lt;a href='index.php?m=2&amp;p=3&amp;fi=99'&gt;Link&lt;/a&gt;<br />&nbsp; &nbsp;&nbsp; */<br />&nbsp; &nbsp; </span><span class="keyword">public function </span><span class="default">fixGet</span><span class="keyword">(</span><span class="default">$args</span><span class="keyword">) { <br />&nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">count</span><span class="keyword">(</span><span class="default">$_GET</span><span class="keyword">) &gt; </span><span class="default">0</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(!empty(</span><span class="default">$args</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$lastkey </span><span class="keyword">= </span><span class="string">""</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$pairs </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">(</span><span class="string">"&amp;"</span><span class="keyword">,</span><span class="default">$args</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; foreach(</span><span class="default">$pairs </span><span class="keyword">as </span><span class="default">$pair</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">strpos</span><span class="keyword">(</span><span class="default">$pair</span><span class="keyword">,</span><span class="string">":"</span><span class="keyword">) !== </span><span class="default">false</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; list(</span><span class="default">$key</span><span class="keyword">,</span><span class="default">$value</span><span class="keyword">) = </span><span class="default">explode</span><span class="keyword">(</span><span class="string">":"</span><span class="keyword">,</span><span class="default">$pair</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; unset(</span><span class="default">$_GET</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$lastkey </span><span class="keyword">= </span><span class="string">"&amp;</span><span class="default">$key$value</span><span class="string">"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; } elseif(</span><span class="default">strpos</span><span class="keyword">(</span><span class="default">$pair</span><span class="keyword">,</span><span class="string">"="</span><span class="keyword">) === </span><span class="default">false</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; unset(</span><span class="default">$_GET</span><span class="keyword">[</span><span class="default">$pair</span><span class="keyword">]);<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; list(</span><span class="default">$key</span><span class="keyword">, </span><span class="default">$value</span><span class="keyword">) = </span><span class="default">explode</span><span class="keyword">(</span><span class="string">"="</span><span class="keyword">,</span><span class="default">$pair</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$_GET</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">] = </span><span class="default">$value</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; } <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="string">"?"</span><span class="keyword">.((</span><span class="default">count</span><span class="keyword">(</span><span class="default">$_GET</span><span class="keyword">) &gt; </span><span class="default">0</span><span class="keyword">)?</span><span class="default">http_build_query</span><span class="keyword">(</span><span class="default">$_GET</span><span class="keyword">).</span><span class="default">$lastkey</span><span class="keyword">:</span><span class="string">""</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /></span><span class="default">?&gt;<br /></span><br />To test, copy+paste the following code into testFixGet.php<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">/*<br /> * Unit Test for fixGet()<br /> */<br /></span><span class="default">$cases </span><span class="keyword">= array (<br />&nbsp; &nbsp; </span><span class="default">0 </span><span class="keyword">=&gt; array(</span><span class="string">"s" </span><span class="keyword">=&gt; </span><span class="default">1</span><span class="keyword">, </span><span class="string">"fi" </span><span class="keyword">=&gt; </span><span class="default">2</span><span class="keyword">, </span><span class="string">"m" </span><span class="keyword">=&gt; </span><span class="default">4</span><span class="keyword">, </span><span class="string">"p" </span><span class="keyword">=&gt; </span><span class="default">3</span><span class="keyword">),<br />&nbsp; &nbsp; </span><span class="default">1 </span><span class="keyword">=&gt; array(</span><span class="string">"s" </span><span class="keyword">=&gt; </span><span class="string">""</span><span class="keyword">, </span><span class="string">"fi" </span><span class="keyword">=&gt; </span><span class="string">""</span><span class="keyword">, </span><span class="string">"m" </span><span class="keyword">=&gt; </span><span class="default">4</span><span class="keyword">, </span><span class="string">"p" </span><span class="keyword">=&gt; </span><span class="default">3</span><span class="keyword">),<br />);<br /><br /></span><span class="default">$test</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">] = array(<br />&nbsp; &nbsp; </span><span class="string">"s" </span><span class="keyword">=&gt; </span><span class="string">"fi=2&amp;m=4&amp;p=3"</span><span class="keyword">,<br />&nbsp; &nbsp; </span><span class="string">"s&amp;m" </span><span class="keyword">=&gt; </span><span class="string">"fi=2&amp;p=3"</span><span class="keyword">,<br />&nbsp; &nbsp; </span><span class="string">"s=4" </span><span class="keyword">=&gt; </span><span class="string">"s=4&amp;fi=2&amp;m=4&amp;p=3"</span><span class="keyword">,<br />&nbsp; &nbsp; </span><span class="string">"s=2&amp;m" </span><span class="keyword">=&gt; </span><span class="string">"s=2&amp;fi=2&amp;p=3"</span><span class="keyword">,<br />&nbsp; &nbsp; </span><span class="string">"s=&amp;m=3" </span><span class="keyword">=&gt; </span><span class="string">"s=&amp;fi=2&amp;m=3&amp;p=3"</span><span class="keyword">,<br />&nbsp; &nbsp; </span><span class="string">"s=2&amp;m=" </span><span class="keyword">=&gt; </span><span class="string">"s=2&amp;fi=2&amp;m=&amp;p=3"</span><span class="keyword">,<br />&nbsp; &nbsp; </span><span class="string">"s=2&amp;m:=" </span><span class="keyword">=&gt; </span><span class="string">"s=2&amp;fi=2&amp;p=3&amp;m="</span><span class="keyword">,<br />&nbsp; &nbsp; </span><span class="string">"z=9" </span><span class="keyword">=&gt; </span><span class="string">"s=1&amp;fi=2&amp;m=4&amp;p=3&amp;z=9"</span><span class="keyword">,<br />&nbsp; &nbsp; </span><span class="string">"z:" </span><span class="keyword">=&gt; </span><span class="string">"s=1&amp;fi=2&amp;m=4&amp;p=3&amp;z"</span><span class="keyword">,<br />&nbsp; &nbsp; </span><span class="string">"s:&amp;m=3" </span><span class="keyword">=&gt; </span><span class="string">"fi=2&amp;m=3&amp;p=3&amp;s"</span><span class="keyword">,<br />&nbsp; &nbsp; </span><span class="string">"s&amp;m=3" </span><span class="keyword">=&gt; </span><span class="string">"fi=2&amp;m=3&amp;p=3"</span><span class="keyword">,<br />);<br /></span><span class="default">$test</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">] = array(<br />&nbsp; &nbsp; </span><span class="string">"s" </span><span class="keyword">=&gt; </span><span class="string">"fi=&amp;m=4&amp;p=3"</span><span class="keyword">,<br />&nbsp; &nbsp; </span><span class="string">"s&amp;m" </span><span class="keyword">=&gt; </span><span class="string">"fi=&amp;p=3"</span><span class="keyword">,<br />&nbsp; &nbsp; </span><span class="string">"s=4" </span><span class="keyword">=&gt; </span><span class="string">"s=4&amp;fi=&amp;m=4&amp;p=3"</span><span class="keyword">,<br />&nbsp; &nbsp; </span><span class="string">"s=2&amp;m" </span><span class="keyword">=&gt; </span><span class="string">"s=2&amp;fi=&amp;p=3"</span><span class="keyword">,<br />&nbsp; &nbsp; </span><span class="string">"s=&amp;m=3" </span><span class="keyword">=&gt; </span><span class="string">"s=&amp;fi=&amp;m=3&amp;p=3"</span><span class="keyword">,<br />&nbsp; &nbsp; </span><span class="string">"s=2&amp;m=" </span><span class="keyword">=&gt; </span><span class="string">"s=2&amp;fi=&amp;m=&amp;p=3"</span><span class="keyword">,<br />&nbsp; &nbsp; </span><span class="string">"s=2&amp;m:=" </span><span class="keyword">=&gt; </span><span class="string">"s=2&amp;fi=&amp;p=3&amp;m="</span><span class="keyword">,<br />&nbsp; &nbsp; </span><span class="string">"z=9" </span><span class="keyword">=&gt; </span><span class="string">"s=&amp;fi=&amp;m=4&amp;p=3&amp;z=9"</span><span class="keyword">,<br />&nbsp; &nbsp; </span><span class="string">"z:" </span><span class="keyword">=&gt; </span><span class="string">"s=&amp;fi=&amp;m=4&amp;p=3&amp;z"</span><span class="keyword">,<br />);<br /><br />foreach(</span><span class="default">$cases </span><span class="keyword">as </span><span class="default">$x </span><span class="keyword">=&gt; </span><span class="default">$value</span><span class="keyword">) {<br />&nbsp; &nbsp; echo </span><span class="string">"&lt;hr&gt; CASE: </span><span class="default">$x</span><span class="string"> &lt;hr&gt;\n"</span><span class="keyword">;<br />&nbsp; &nbsp; foreach(</span><span class="default">$test</span><span class="keyword">[</span><span class="default">$x</span><span class="keyword">] as </span><span class="default">$arg </span><span class="keyword">=&gt; </span><span class="default">$expected</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$_GET </span><span class="keyword">= </span><span class="default">$cases</span><span class="keyword">[</span><span class="default">$x</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$res </span><span class="keyword">= </span><span class="default">myForm</span><span class="keyword">::</span><span class="default">fixGet</span><span class="keyword">(</span><span class="default">$arg</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; echo ((</span><span class="default">$res </span><span class="keyword">=== </span><span class="string">"?"</span><span class="keyword">.</span><span class="default">$expected</span><span class="keyword">)?</span><span class="string">"OK"</span><span class="keyword">:</span><span class="string">"NG (</span><span class="default">$res</span><span class="string">)"</span><span class="keyword">).</span><span class="string">" [</span><span class="default">$arg</span><span class="string">]&lt;br&gt;\n"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="105061">  <div class="votes">
    <div id="Vu105061">
    <a href="/manual/vote-note.php?id=105061&amp;page=reserved.variables.get&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd105061">
    <a href="/manual/vote-note.php?id=105061&amp;page=reserved.variables.get&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V105061" title="42% like this...">
    -16
    </div>
  </div>
  <a href="#105061" class="name">
  <strong class="user"><em>Maarten Schroeven</em></strong></a><a class="genanchor" href="#105061"> &para;</a><div class="date" title="2011-07-25 01:09"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom105061">
<div class="phpcode"><code><span class="html">
You can use this function to remove any $_GET variables out of your URL, it takes an array off strings(the names keys of the $_GET you wish to remove) and returns the url with the ones specified removed<br /><br /><span class="default">&lt;?php<br />&nbsp; </span><span class="keyword">function </span><span class="default">getUrlWithout</span><span class="keyword">(</span><span class="default">$getNames</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$url </span><span class="keyword">= </span><span class="string">"http" </span><span class="keyword">. ((!empty(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'HTTPS'</span><span class="keyword">])) ? </span><span class="string">"s" </span><span class="keyword">: </span><span class="string">""</span><span class="keyword">) . </span><span class="string">"://"</span><span class="keyword">.</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'SERVER_NAME'</span><span class="keyword">].</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'REQUEST_URI'</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$questionMarkExp </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">(</span><span class="string">"?"</span><span class="keyword">, </span><span class="default">$url</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$urlArray </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">(</span><span class="string">"&amp;"</span><span class="keyword">, </span><span class="default">$questionMarkExp</span><span class="keyword">[</span><span class="default">1</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$retUrl</span><span class="keyword">=</span><span class="default">$questionMarkExp</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$retGet</span><span class="keyword">=</span><span class="string">""</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$found</span><span class="keyword">=array();<br />&nbsp; &nbsp; &nbsp; foreach(</span><span class="default">$getNames </span><span class="keyword">as </span><span class="default">$id </span><span class="keyword">=&gt; </span><span class="default">$name</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; foreach (</span><span class="default">$urlArray </span><span class="keyword">as </span><span class="default">$key</span><span class="keyword">=&gt;</span><span class="default">$value</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(isset(</span><span class="default">$_GET</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">]) &amp;&amp; </span><span class="default">$value</span><span class="keyword">==</span><span class="default">$name</span><span class="keyword">.</span><span class="string">"="</span><span class="keyword">.</span><span class="default">$_GET</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">])<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; unset(</span><span class="default">$urlArray</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$urlArray </span><span class="keyword">= </span><span class="default">array_values</span><span class="keyword">(</span><span class="default">$urlArray</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; foreach (</span><span class="default">$urlArray </span><span class="keyword">as </span><span class="default">$key </span><span class="keyword">=&gt; </span><span class="default">$value</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(</span><span class="default">$key</span><span class="keyword">&lt;</span><span class="default">sizeof</span><span class="keyword">(</span><span class="default">$urlArray</span><span class="keyword">) &amp;&amp; </span><span class="default">$retGet</span><span class="keyword">!==</span><span class="string">""</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$retGet</span><span class="keyword">.=</span><span class="string">"&amp;"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$retGet</span><span class="keyword">.=</span><span class="default">$value</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; return </span><span class="default">$retUrl</span><span class="keyword">.</span><span class="string">"?"</span><span class="keyword">.</span><span class="default">$retGet</span><span class="keyword">;<br />&nbsp; }<br /></span><span class="default">?&gt;<br /></span><br />Example<br />current url is <a href="http://www.example.net/index.php?getVar1=Something&amp;getVar2=10&amp;getVar3=ok" rel="nofollow" target="_blank">http://www.example.net/index.php?getVar1=Something&amp;getVar2=10&amp;getVar3=ok</a><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">echo </span><span class="default">getUrlWithout</span><span class="keyword">(array(</span><span class="string">"getVar1"</span><span class="keyword">,</span><span class="string">"getVar3"</span><span class="keyword">));<br />&nbsp; &nbsp; </span><span class="comment">//result will be "<a href="http://www.example.net/index.php?getVar2=10" rel="nofollow" target="_blank">http://www.example.net/index.php?getVar2=10</a>"<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="92439">  <div class="votes">
    <div id="Vu92439">
    <a href="/manual/vote-note.php?id=92439&amp;page=reserved.variables.get&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd92439">
    <a href="/manual/vote-note.php?id=92439&amp;page=reserved.variables.get&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V92439" title="42% like this...">
    -15
    </div>
  </div>
  <a href="#92439" class="name">
  <strong class="user"><em>robotreply at gmail dot com</em></strong></a><a class="genanchor" href="#92439"> &para;</a><div class="date" title="2009-07-24 12:17"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom92439">
<div class="phpcode"><code><span class="html">
Parsing of GET/POST drops duplicate variables unless those variables have "[]" (PHP bugs #10502, #15498 and #16195). Adding "[]" makes a mess of your javascript code, so here is a small workaround to it. <br /><br />This function basically scans your raw POST and GET input and tries to fix the same. This function must be called near the top of your script. Optimizations are welcome.<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">function </span><span class="default">php_fix_raw_query</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$post </span><span class="keyword">= </span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Try globals array<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">if (!</span><span class="default">$post </span><span class="keyword">&amp;&amp; isset(</span><span class="default">$_GLOBALS</span><span class="keyword">) &amp;&amp; isset(</span><span class="default">$_GLOBALS</span><span class="keyword">[</span><span class="string">"HTTP_RAW_POST_DATA"</span><span class="keyword">]))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$post </span><span class="keyword">= </span><span class="default">$_GLOBALS</span><span class="keyword">[</span><span class="string">"HTTP_RAW_POST_DATA"</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Try globals variable<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">if (!</span><span class="default">$post </span><span class="keyword">&amp;&amp; isset(</span><span class="default">$HTTP_RAW_POST_DATA</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$post </span><span class="keyword">= </span><span class="default">$HTTP_RAW_POST_DATA</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Try stream<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">if (!</span><span class="default">$post</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (!</span><span class="default">function_exists</span><span class="keyword">(</span><span class="string">'file_get_contents'</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$fp </span><span class="keyword">= </span><span class="default">fopen</span><span class="keyword">(</span><span class="string">"php://input"</span><span class="keyword">, </span><span class="string">"r"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$fp</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$post </span><span class="keyword">= </span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; while (!</span><span class="default">feof</span><span class="keyword">(</span><span class="default">$fp</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$post </span><span class="keyword">= </span><span class="default">fread</span><span class="keyword">(</span><span class="default">$fp</span><span class="keyword">, </span><span class="default">1024</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">fclose</span><span class="keyword">(</span><span class="default">$fp</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$post </span><span class="keyword">= </span><span class="string">"" </span><span class="keyword">. </span><span class="default">file_get_contents</span><span class="keyword">(</span><span class="string">"php://input"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$raw </span><span class="keyword">= !empty(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'QUERY_STRING'</span><span class="keyword">]) ? </span><span class="default">sprintf</span><span class="keyword">(</span><span class="string">'%s&amp;%s'</span><span class="keyword">, </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'QUERY_STRING'</span><span class="keyword">], </span><span class="default">$post</span><span class="keyword">) : </span><span class="default">$post</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$arr </span><span class="keyword">= array();<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$pairs </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">(</span><span class="string">'&amp;'</span><span class="keyword">, </span><span class="default">$raw</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; foreach (</span><span class="default">$pairs </span><span class="keyword">as </span><span class="default">$i</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (!empty(</span><span class="default">$i</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; list(</span><span class="default">$name</span><span class="keyword">, </span><span class="default">$value</span><span class="keyword">) = </span><span class="default">explode</span><span class="keyword">(</span><span class="string">'='</span><span class="keyword">, </span><span class="default">$i</span><span class="keyword">, </span><span class="default">2</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (isset(</span><span class="default">$arr</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">]) ) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$arr</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">]) ) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$arr</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">][] = </span><span class="default">$value</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$arr</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">] = array(</span><span class="default">$arr</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">], </span><span class="default">$value</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; } else {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$arr</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">] = </span><span class="default">$value</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; foreach ( </span><span class="default">$_POST </span><span class="keyword">as </span><span class="default">$key </span><span class="keyword">=&gt; </span><span class="default">$value </span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$arr</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">]) ) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$_POST</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">] = </span><span class="default">$arr</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$_REQUEST</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">] = </span><span class="default">$arr</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; foreach ( </span><span class="default">$_GET </span><span class="keyword">as </span><span class="default">$key </span><span class="keyword">=&gt; </span><span class="default">$value </span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$arr</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">]) ) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$_GET</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">] = </span><span class="default">$arr</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$_REQUEST</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">] = </span><span class="default">$arr</span><span class="keyword">[</span><span class="default">$name</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment"># optionally return result array <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">$arr</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /> <br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="101856">  <div class="votes">
    <div id="Vu101856">
    <a href="/manual/vote-note.php?id=101856&amp;page=reserved.variables.get&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd101856">
    <a href="/manual/vote-note.php?id=101856&amp;page=reserved.variables.get&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V101856" title="38% like this...">
    -18
    </div>
  </div>
  <a href="#101856" class="name">
  <strong class="user"><em>Daniel M</em></strong></a><a class="genanchor" href="#101856"> &para;</a><div class="date" title="2011-01-14 04:35"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom101856">
<div class="phpcode"><code><span class="html">
If you need to find out whether any GET variables have been specified, you can use the empty() function.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">if(empty(</span><span class="default">$_GET</span><span class="keyword">))<br />&nbsp; &nbsp; echo </span><span class="string">"No GET variables"</span><span class="keyword">;<br />else<br />&nbsp; &nbsp; </span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$_GET</span><span class="keyword">);<br /><br /></span><span class="default">?&gt;<br /></span><br />empty() - <a href="http://php.net/manual/en/function.empty.php" rel="nofollow" target="_blank">http://php.net/manual/en/function.empty.php</a><br />print_r() - <a href="http://php.net/manual/en/function.print-r.php" rel="nofollow" target="_blank">http://php.net/manual/en/function.print-r.php</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="105335">  <div class="votes">
    <div id="Vu105335">
    <a href="/manual/vote-note.php?id=105335&amp;page=reserved.variables.get&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd105335">
    <a href="/manual/vote-note.php?id=105335&amp;page=reserved.variables.get&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V105335" title="40% like this...">
    -32
    </div>
  </div>
  <a href="#105335" class="name">
  <strong class="user"><em>zgold</em></strong></a><a class="genanchor" href="#105335"> &para;</a><div class="date" title="2011-08-10 01:58"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom105335">
<div class="phpcode"><code><span class="html">
I don't directly use $_GET due to security concerns, instead I create a new array called $_CLEAN which contains cleaned superglobal variables.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">clean</span><span class="keyword">(</span><span class="default">$elem</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; if(!</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$elem</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$elem </span><span class="keyword">= </span><span class="default">htmlentities</span><span class="keyword">(</span><span class="default">$elem</span><span class="keyword">,</span><span class="default">ENT_QUOTES</span><span class="keyword">,</span><span class="string">"UTF-8"</span><span class="keyword">);<br />&nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach (</span><span class="default">$elem </span><span class="keyword">as </span><span class="default">$key </span><span class="keyword">=&gt; </span><span class="default">$value</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$elem</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">] = </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">clean</span><span class="keyword">(</span><span class="default">$value</span><span class="keyword">);<br />&nbsp; &nbsp; return </span><span class="default">$elem</span><span class="keyword">;<br />}<br /><br /></span><span class="default">$_CLEAN</span><span class="keyword">[</span><span class="string">'GET'</span><span class="keyword">] = </span><span class="default">clean</span><span class="keyword">(</span><span class="default">$_GET</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />I also do this for $_POST, as followed:<br /><span class="default">&lt;?php $_CLEAN</span><span class="keyword">[</span><span class="string">'POST'</span><span class="keyword">] = </span><span class="default">clean</span><span class="keyword">(</span><span class="default">$_POST</span><span class="keyword">); </span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119874">  <div class="votes">
    <div id="Vu119874">
    <a href="/manual/vote-note.php?id=119874&amp;page=reserved.variables.get&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119874">
    <a href="/manual/vote-note.php?id=119874&amp;page=reserved.variables.get&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119874" title="31% like this...">
    -7
    </div>
  </div>
  <a href="#119874" class="name">
  <strong class="user"><em>PHP Notes</em></strong></a><a class="genanchor" href="#119874"> &para;</a><div class="date" title="2016-09-11 05:37"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119874">
<div class="phpcode"><code><span class="html">
I like to use the following as a method to make sure data is not provided as an array before I try and use it, resulting in "Array" warning.<br /><br />if(!in_array(false, array_map("is_string", $_POST)))<br />{<br />&nbsp; All data has been submitted as string.<br />}<br /><br />Naturally, this is only applicable if all data is supposed to be a string, but it's far easier and cleaner than using is_string on up to 20 elements</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117650">  <div class="votes">
    <div id="Vu117650">
    <a href="/manual/vote-note.php?id=117650&amp;page=reserved.variables.get&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117650">
    <a href="/manual/vote-note.php?id=117650&amp;page=reserved.variables.get&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117650" title="31% like this...">
    -15
    </div>
  </div>
  <a href="#117650" class="name">
  <strong class="user"><em>dirk dot lze at gmail dot com</em></strong></a><a class="genanchor" href="#117650"> &para;</a><div class="date" title="2015-07-14 06:55"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117650">
<div class="phpcode"><code><span class="html">
Make $_GET and $_POST more like in Perl.<br />This function also disable magic_quotes.<br />Will be better to handle.<br /><br />function param($name){<br />&nbsp; if(is_string($name)){<br />&nbsp; &nbsp; if((bool) get_magic_quotes_gpc()){<br />&nbsp; &nbsp; set_magic_quotes_runtime(0);<br />&nbsp; &nbsp; $param = isset($_POST[$name]) ? stripslashes($_POST[$name]) : false;<br />&nbsp; &nbsp; $param = isset($_GET[$name]) ? stripslashes($_GET[$name]) : $param;<br />&nbsp; &nbsp; &nbsp; }else{<br />&nbsp; &nbsp; $param = isset($_POST[$name]) ? $_POST[$name] : false;<br />&nbsp; &nbsp; $param = isset($_GET[$name]) ? $_GET[$name] : $param;<br />&nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; return $param;<br />&nbsp; &nbsp; }else{<br />&nbsp; &nbsp; return $name;<br />&nbsp; }<br />}<br /><br />if(param('foo')){<br />echo "bar";<br />}</span>
</code></div>
  </div>
 </div>
  <div class="note" id="111567">  <div class="votes">
    <div id="Vu111567">
    <a href="/manual/vote-note.php?id=111567&amp;page=reserved.variables.get&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd111567">
    <a href="/manual/vote-note.php?id=111567&amp;page=reserved.variables.get&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V111567" title="28% like this...">
    -29
    </div>
  </div>
  <a href="#111567" class="name">
  <strong class="user"><em>Z80user</em></strong></a><a class="genanchor" href="#111567"> &para;</a><div class="date" title="2013-03-04 11:40"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom111567">
<div class="phpcode"><code><span class="html">
in MySQLi<br /><br />I need write<br />-. $_GET[actor]<br />instead of<br />-. $_GET["actor"]<br />or<br />-. $_GET['actor']<br /><br />NOTE: IIS 7.5 (On Windows Server 2008 R2 Datacenter) with PHP Version 5.4.12 and mysqlnd 5.0.10<br />Version of MySQL 5.6.10<br /><br />This code show a Movies with an actor ID_Actor<br />E.G. URL "<a href="http://127.0.0.1/test2.php?actor=14" rel="nofollow" target="_blank">http://127.0.0.1/test2.php?actor=14</a>"<br /><span class="default">&lt;?php<br /></span><span class="comment">// CONNECT TO THE DATABASE<br />&nbsp; &nbsp; </span><span class="default">$DB_HOST </span><span class="keyword">= </span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$DB_USER </span><span class="keyword">= </span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$DB_PASS </span><span class="keyword">= </span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$DB_NAME </span><span class="keyword">= </span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="default">$mysqli </span><span class="keyword">= new </span><span class="default">mysqli</span><span class="keyword">(</span><span class="default">$DB_HOST</span><span class="keyword">, </span><span class="default">$DB_USER</span><span class="keyword">, </span><span class="default">$DB_PASS</span><span class="keyword">, </span><span class="default">$DB_NAME</span><span class="keyword">);<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; if (</span><span class="default">mysqli_connect_errno</span><span class="keyword">()) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">printf</span><span class="keyword">(</span><span class="string">"Connect failed: %s\n"</span><span class="keyword">, </span><span class="default">mysqli_connect_error</span><span class="keyword">());<br />&nbsp; &nbsp; &nbsp; &nbsp; exit();<br />&nbsp; &nbsp; }<br /><br /></span><span class="comment">// A QUICK QUERY ON A FAKE USER TABLE<br /><br />&nbsp; &nbsp; </span><span class="default">$query </span><span class="keyword">= </span><span class="string">"SELECT DISTINCT Title FROM movie WHERE ID_movie IN ( SELECT DISTINCT ID_Movie FROM actor_scene WHERE ID_actor=</span><span class="default">$_GET</span><span class="keyword">[</span><span class="default">actor</span><span class="keyword">]</span><span class="string">) "</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$result </span><span class="keyword">= </span><span class="default">$mysqli</span><span class="keyword">-&gt;</span><span class="default">query</span><span class="keyword">(</span><span class="default">$query</span><span class="keyword">) or die(</span><span class="default">$mysqli</span><span class="keyword">-&gt;</span><span class="default">error</span><span class="keyword">.</span><span class="default">__LINE__</span><span class="keyword">);<br /><br /></span><span class="comment">// GOING THROUGH THE DATA<br />&nbsp; &nbsp; </span><span class="keyword">if(</span><span class="default">$result</span><span class="keyword">-&gt;</span><span class="default">num_rows </span><span class="keyword">&gt; </span><span class="default">0</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; while(</span><span class="default">$row </span><span class="keyword">= </span><span class="default">$result</span><span class="keyword">-&gt;</span><span class="default">fetch_assoc</span><span class="keyword">()) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">stripslashes</span><span class="keyword">(</span><span class="default">$row</span><span class="keyword">[</span><span class="string">'Title'</span><span class="keyword">]).</span><span class="string">"&lt;br&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">" "</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; else {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'NO RESULTS'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /></span><span class="comment">// CLOSE CONNECTION<br />&nbsp; &nbsp; </span><span class="default">mysqli_close</span><span class="keyword">(</span><span class="default">$mysqli</span><span class="keyword">);<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="89692">  <div class="votes">
    <div id="Vu89692">
    <a href="/manual/vote-note.php?id=89692&amp;page=reserved.variables.get&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd89692">
    <a href="/manual/vote-note.php?id=89692&amp;page=reserved.variables.get&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V89692" title="29% like this...">
    -28
    </div>
  </div>
  <a href="#89692" class="name">
  <strong class="user"><em>slavik0329</em></strong></a><a class="genanchor" href="#89692"> &para;</a><div class="date" title="2009-03-19 07:01"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom89692">
<div class="phpcode"><code><span class="html">
the addget function below actually has more use when you dont use the recursive merge as such:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">AddGet</span><span class="keyword">(</span><span class="default">$ArrayOrString</span><span class="keyword">){<br />if(</span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$ArrayOrString</span><span class="keyword">))<br />return </span><span class="default">http_build_query</span><span class="keyword">(</span><span class="default">array_merge</span><span class="keyword">(</span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">'_GET'</span><span class="keyword">], </span><span class="default">$ArrayOrString</span><span class="keyword">));<br /></span><span class="default">parse_str</span><span class="keyword">(</span><span class="default">$ArrayOrString</span><span class="keyword">, </span><span class="default">$output</span><span class="keyword">);<br />return </span><span class="default">http_build_query</span><span class="keyword">(</span><span class="default">array_merge</span><span class="keyword">(</span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">'_GET'</span><span class="keyword">], </span><span class="default">$output</span><span class="keyword">));<br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />In this case, if the key is added again with a different value it will be replaced with the new value.<br /><br />addget("change=true"); // ?change=true<br />addget("change=false"); // ?change=false</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=reserved.variables.get&amp;redirect=http://php.net/manual/en/reserved.variables.get.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="reserved.variables.php">Predefined Variables</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.variables.superglobals.php" title="Superglobals">Superglobals</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.globals.php" title="$GLOBALS">$GLOBALS</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.server.php" title="$_&#8203;SERVER">$_&#8203;SERVER</a>
                        </li>
                          
                        <li class="current">
                            <a href="reserved.variables.get.php" title="$_&#8203;GET">$_&#8203;GET</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.post.php" title="$_&#8203;POST">$_&#8203;POST</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.files.php" title="$_&#8203;FILES">$_&#8203;FILES</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.request.php" title="$_&#8203;REQUEST">$_&#8203;REQUEST</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.session.php" title="$_&#8203;SESSION">$_&#8203;SESSION</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.environment.php" title="$_&#8203;ENV">$_&#8203;ENV</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.cookies.php" title="$_&#8203;COOKIE">$_&#8203;COOKIE</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.phperrormsg.php" title="$php_&#8203;errormsg">$php_&#8203;errormsg</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.httprawpostdata.php" title="$HTTP_&#8203;RAW_&#8203;POST_&#8203;DATA">$HTTP_&#8203;RAW_&#8203;POST_&#8203;DATA</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.httpresponseheader.php" title="$http_&#8203;response_&#8203;header">$http_&#8203;response_&#8203;header</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.argc.php" title="$argc">$argc</a>
                        </li>
                          
                        <li class="">
                            <a href="reserved.variables.argv.php" title="$argv">$argv</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

