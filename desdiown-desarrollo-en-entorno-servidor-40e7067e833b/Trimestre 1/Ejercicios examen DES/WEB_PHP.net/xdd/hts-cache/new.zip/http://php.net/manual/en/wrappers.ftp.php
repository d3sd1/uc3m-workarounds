<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: ftp:// - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/wrappers.ftp.php">
 <link rel="shorturl" href="http://php.net/manual/en/wrappers.ftp.php">
 <link rel="alternate" href="http://php.net/manual/en/wrappers.ftp.php" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/wrappers.php">
 <link rel="prev" href="http://php.net/manual/en/wrappers.http.php">
 <link rel="next" href="http://php.net/manual/en/wrappers.php.php">

 <link rel="alternate" href="http://php.net/manual/en/wrappers.ftp.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/wrappers.ftp.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/wrappers.ftp.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/wrappers.ftp.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/wrappers.ftp.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/wrappers.ftp.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/wrappers.ftp.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/wrappers.ftp.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/wrappers.ftp.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/wrappers.ftp.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/wrappers.ftp.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="wrappers.php.php">
          php:// &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="wrappers.http.php">
          &laquo; http://        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='wrappers.php'>Supported Protocols and Wrappers</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/wrappers.ftp.php' selected="selected">English</option>
            <option value='pt_BR/wrappers.ftp.php'>Brazilian Portuguese</option>
            <option value='zh/wrappers.ftp.php'>Chinese (Simplified)</option>
            <option value='fr/wrappers.ftp.php'>French</option>
            <option value='de/wrappers.ftp.php'>German</option>
            <option value='ja/wrappers.ftp.php'>Japanese</option>
            <option value='ro/wrappers.ftp.php'>Romanian</option>
            <option value='ru/wrappers.ftp.php'>Russian</option>
            <option value='es/wrappers.ftp.php'>Spanish</option>
            <option value='tr/wrappers.ftp.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/wrappers.ftp.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=wrappers.ftp">Report a Bug</a>
    </div>
  </div><div id="wrappers.ftp" class="refentry">
 <div class="refnamediv">
  <h1 class="refname">ftp://</h1>
  <h1 class="refname">ftps://</h1>
  <p class="refpurpose"><span class="refname">ftp://</span> -- <span class="refname">ftps://</span> &mdash; <span class="dc-title">Accessing FTP(s) URLs</span></p>

 </div>

 <div class="refsect1 description" id="refsect1-wrappers.ftp-description">
  <h3 class="title">Description</h3>
  <p class="para">
   Allows read access to existing files and creation of new files
   via FTP.  If the server does not support passive mode ftp, the
   connection will fail.
  </p>
  <p class="simpara">
   You can open files for either reading or writing, but not both
   simultaneously.  If the remote file already exists on the ftp
   server and you attempt to open it for writing but have not specified
   the context option <em>overwrite</em>, the connection
   will fail.  If you need to overwrite existing files over ftp,
   specify the <em>overwrite</em> option in the context
   and open the file for writing.  Alternatively, you can
   use the <a href="ref.ftp.php" class="link">FTP extension</a>.
  </p>
  <p class="simpara">
   If you have set the <a href="filesystem.configuration.php#ini.from" class="link">from</a> directive
   in <var class="filename">php.ini</var>, then this value will be sent as the anonymous FTP
   password.
  </p>
 </div>


 <div class="refsect1 usage" id="refsect1-wrappers.ftp-usage"> 
  <h3 class="title">Usage</h3>
  <ul class="itemizedlist">
   <li class="listitem"><span class="simpara"><var class="filename">ftp://example.com/pub/file.txt</var></span></li>
   <li class="listitem"><span class="simpara"><var class="filename">ftp://user:password@example.com/pub/file.txt</var></span></li>
   <li class="listitem"><span class="simpara"><var class="filename">ftps://example.com/pub/file.txt</var></span></li>
   <li class="listitem"><span class="simpara"><var class="filename">ftps://user:password@example.com/pub/file.txt</var></span></li>
  </ul>
 </div>
 

 <div class="refsect1 options" id="refsect1-wrappers.ftp-options">
  <h3 class="title">Options</h3>
  <p class="para">
   <table class="doctable table">
    <caption><strong>Wrapper Summary</strong></caption>
    
     <thead>
      <tr>
       <th>Attribute</th>
       <th>PHP 4</th>
       <th>PHP 5</th>
      </tr>

     </thead>

     <tbody class="tbody">
      <tr>
       <td>Restricted by <a href="filesystem.configuration.php#ini.allow-url-fopen" class="link">allow_url_fopen</a></td>
       <td>Yes</td>
       <td>Yes</td>
      </tr>

      <tr>
       <td>Allows Reading</td>
       <td>Yes</td>
       <td>Yes</td>
      </tr>

      <tr>
       <td>Allows Writing</td>
       <td>Yes (new files only)</td>
       <td>Yes (new files/existing files with <code class="parameter">overwrite</code>)</td>
      </tr>

      <tr>
       <td>Allows Appending</td>
       <td>No</td>
       <td>Yes</td>
      </tr>

      <tr>
       <td>Allows Simultaneous Reading and Writing</td>
       <td>No</td>
       <td>No</td>
      </tr>

      <tr>
       <td>Supports <span class="function"><a href="function.stat.php" class="function">stat()</a></span></td>
       <td>No</td>
       <td>
        As of PHP 5.0.0: <span class="function"><a href="function.filesize.php" class="function">filesize()</a></span>,
        <span class="function"><a href="function.filetype.php" class="function">filetype()</a></span>, <span class="function"><a href="function.file-exists.php" class="function">file_exists()</a></span>,
        <span class="function"><a href="function.is-file.php" class="function">is_file()</a></span>, and <span class="function"><a href="function.is-dir.php" class="function">is_dir()</a></span> elements only.
        As of PHP 5.1.0: <span class="function"><a href="function.filemtime.php" class="function">filemtime()</a></span>.
       </td>
      </tr>

      <tr>
       <td>Supports <span class="function"><a href="function.unlink.php" class="function">unlink()</a></span></td>
       <td>No</td>
       <td>Yes</td>
      </tr>

      <tr>
       <td>Supports <span class="function"><a href="function.rename.php" class="function">rename()</a></span></td>
       <td>No</td>
       <td>Yes</td>
      </tr>

      <tr>
       <td>Supports <span class="function"><a href="function.mkdir.php" class="function">mkdir()</a></span></td>
       <td>No</td>
       <td>Yes</td>
      </tr>

      <tr>
       <td>Supports <span class="function"><a href="function.rmdir.php" class="function">rmdir()</a></span></td>
       <td>No</td>
       <td>Yes</td>
      </tr>

     </tbody>
    
   </table>

  </p>
 </div>
 

 <div class="refsect1 changelog" id="refsect1-wrappers.ftp-changelog">
  <h3 class="title">Changelog</h3>
  <p class="para">
   <table class="doctable informaltable">
    
     <thead>
      <tr>
       <th>Version</th>
       <th>Description</th>
      </tr>

     </thead>

     <tbody class="tbody">
      <tr>
       <td>4.3.0</td>
       <td>
        Added <em>ftps://</em>.
       </td>
      </tr>

     </tbody>
    
   </table>

  </p>
 </div>


 <div class="refsect1 notes" id="refsect1-wrappers.ftp-notes">
  <h3 class="title">Notes</h3>
  <blockquote class="note"><p><strong class="note">Note</strong>: 
   <p class="para">
    FTPS is only supported when the <a href="book.openssl.php" class="link">openssl</a>
    extension is enabled.
   </p>
   <span class="simpara">
    If the server does not support SSL, then the connection falls back
    to regular unencrypted ftp.
   </span>
  </p></blockquote>
  <blockquote class="note"><p><strong class="note">Note</strong>: 
   <strong>Appending</strong><br />
   <span class="simpara">
    As of PHP 5.0.0 files may be appended via the
    <em>ftp://</em> URL wrapper.  In prior versions, attempting
    to append to a file via <em>ftp://</em> will result in failure.
   </span>
  </p></blockquote>
 </div>


 <div class="refsect1 seealso" id="refsect1-wrappers.ftp-seealso">
  <h3 class="title">See Also</h3>
  <ul class="simplelist">
   <li class="member"><a href="context.ftp.php" class="xref">FTP context options</a></li>
  </ul>
 </div>


</div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=wrappers.ftp&amp;redirect=http://php.net/manual/en/wrappers.ftp.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">3 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="43797">  <div class="votes">
    <div id="Vu43797">
    <a href="/manual/vote-note.php?id=43797&amp;page=wrappers.ftp&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd43797">
    <a href="/manual/vote-note.php?id=43797&amp;page=wrappers.ftp&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V43797" title="57% like this...">
    1
    </div>
  </div>
  <a href="#43797" class="name">
  <strong class="user"><em>php at f00n dot com</em></strong></a><a class="genanchor" href="#43797"> &para;</a><div class="date" title="2004-07-04 12:39"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom43797">
<div class="phpcode"><code><span class="html">
For Intranet purposes I found I preferred to move my file via ftp functions to match the session user's ftp account and put the file in a holding bay so I knew who it was from.<br /><br />The FTP wrapper method will NOT do this if your ftp server does NOT support passive mode.<br /><br />eg.&nbsp; an ftp server behind NAT/routing</span>
</code></div>
  </div>
 </div>
  <div class="note" id="57168">  <div class="votes">
    <div id="Vu57168">
    <a href="/manual/vote-note.php?id=57168&amp;page=wrappers.ftp&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd57168">
    <a href="/manual/vote-note.php?id=57168&amp;page=wrappers.ftp&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V57168" title="47% like this...">
    -1
    </div>
  </div>
  <a href="#57168" class="name"><strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#57168"> &para;</a><div class="date" title="2005-09-25 08:33"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom57168">
<div class="phpcode"><code><span class="html">
&lt;?<br />$str ="replace all contenents";<br />$filew="<a href="ftp://gufo:gufo@192.168.1.55:21/jj.php" rel="nofollow" target="_blank">ftp://gufo:gufo@192.168.1.55:21/jj.php</a>";<br />$opts = array('ftp' =&gt; array('overwrite' =&gt; true));<br />$context = stream_context_create($opts);<br />$strwri = file_put_contents($filew,$str,LOCK_EX,$context);<br />?&gt;</span>
</code></div>
  </div>
 </div>
  <div class="note" id="82794">  <div class="votes">
    <div id="Vu82794">
    <a href="/manual/vote-note.php?id=82794&amp;page=wrappers.ftp&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd82794">
    <a href="/manual/vote-note.php?id=82794&amp;page=wrappers.ftp&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V82794" title="16% like this...">
    -8
    </div>
  </div>
  <a href="#82794" class="name">
  <strong class="user"><em>fazil dot stormhammer dot nospam at gmail dot com</em></strong></a><a class="genanchor" href="#82794"> &para;</a><div class="date" title="2008-04-25 01:41"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom82794">
<div class="phpcode"><code><span class="html">
Document says "Allows read access to existing files and creation of new files via FTP. If the server does not support passive mode ftp, the connection will fail. "<br /><br />As of version 5.2.5 at least fopen("<a href="ftp://..." rel="nofollow" target="_blank">ftp://...</a>") uses an ACTIVE mode connection by default (it issues an FTP PORT command but not a PASV command).&nbsp; To force passive mode:<br /><br />$f = fopen("<a href="ftp://..." rel="nofollow" target="_blank">ftp://...</a>");<br />ftp_pasv($f, true);</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=wrappers.ftp&amp;redirect=http://php.net/manual/en/wrappers.ftp.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="wrappers.php">Supported Protocols and Wrappers</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="wrappers.file.php" title="file://">file://</a>
                        </li>
                          
                        <li class="">
                            <a href="wrappers.http.php" title="http://">http://</a>
                        </li>
                          
                        <li class="current">
                            <a href="wrappers.ftp.php" title="ftp://">ftp://</a>
                        </li>
                          
                        <li class="">
                            <a href="wrappers.php.php" title="php://">php://</a>
                        </li>
                          
                        <li class="">
                            <a href="wrappers.compression.php" title="zlib://">zlib://</a>
                        </li>
                          
                        <li class="">
                            <a href="wrappers.data.php" title="data://">data://</a>
                        </li>
                          
                        <li class="">
                            <a href="wrappers.glob.php" title="glob://">glob://</a>
                        </li>
                          
                        <li class="">
                            <a href="wrappers.phar.php" title="phar://">phar://</a>
                        </li>
                          
                        <li class="">
                            <a href="wrappers.ssh2.php" title="ssh2://">ssh2://</a>
                        </li>
                          
                        <li class="">
                            <a href="wrappers.rar.php" title="rar://">rar://</a>
                        </li>
                          
                        <li class="">
                            <a href="wrappers.audio.php" title="ogg://">ogg://</a>
                        </li>
                          
                        <li class="">
                            <a href="wrappers.expect.php" title="expect://">expect://</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

