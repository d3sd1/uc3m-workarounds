<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Using Register Globals - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/security.globals.php">
 <link rel="shorturl" href="http://php.net/manual/en/security.globals.php">
 <link rel="alternate" href="http://php.net/manual/en/security.globals.php" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/security.php">
 <link rel="prev" href="http://php.net/manual/en/security.errors.php">
 <link rel="next" href="http://php.net/manual/en/security.variables.php">

 <link rel="alternate" href="http://php.net/manual/en/security.globals.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/security.globals.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/security.globals.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/security.globals.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/security.globals.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/security.globals.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/security.globals.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/security.globals.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/security.globals.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/security.globals.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/security.globals.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="security.variables.php">
          User Submitted Data &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="security.errors.php">
          &laquo; Error Reporting        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='security.php'>Security</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/security.globals.php' selected="selected">English</option>
            <option value='pt_BR/security.globals.php'>Brazilian Portuguese</option>
            <option value='zh/security.globals.php'>Chinese (Simplified)</option>
            <option value='fr/security.globals.php'>French</option>
            <option value='de/security.globals.php'>German</option>
            <option value='ja/security.globals.php'>Japanese</option>
            <option value='ro/security.globals.php'>Romanian</option>
            <option value='ru/security.globals.php'>Russian</option>
            <option value='es/security.globals.php'>Spanish</option>
            <option value='tr/security.globals.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/security.globals.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=security.globals">Report a Bug</a>
    </div>
  </div><div id="security.globals" class="chapter">
   <h1>Using Register Globals</h1>

   <div class="warning"><strong class="warning">Warning</strong><p class="simpara">This feature has been
<em class="emphasis">DEPRECATED</em> as of PHP 5.3.0 and <em class="emphasis">REMOVED</em>
as of PHP 5.4.0.</p></div>
   <p class="para">
    Perhaps the most controversial change in <acronym title="PHP: Hypertext Preprocessor">PHP</acronym> is when the default value
    for the <acronym title="PHP: Hypertext Preprocessor">PHP</acronym> directive <a href="ini.core.php#ini.register-globals" class="link">
    register_globals</a> went from ON to OFF in <acronym title="PHP: Hypertext Preprocessor">PHP</acronym> 
    <a href="http://www.php.net/releases/4_2_0.php" class="link external">&raquo;&nbsp;4.2.0</a>.  Reliance on this
    directive was quite common and many people didn&#039;t even know it existed
    and assumed it&#039;s just how <acronym title="PHP: Hypertext Preprocessor">PHP</acronym> works.  This page will explain how one can
    write insecure code with this directive but keep in mind that the
    directive itself isn&#039;t insecure but rather it&#039;s the misuse of it.
   </p>
   <p class="para">
    When on, register_globals will inject your scripts with all
    sorts of variables, like request variables from <acronym title="Hyper Text Markup Language">HTML</acronym> forms.  This
    coupled with the fact that <acronym title="PHP: Hypertext Preprocessor">PHP</acronym> doesn&#039;t require variable initialization
    means writing insecure code is that much easier.  It was a difficult
    decision, but the <acronym title="PHP: Hypertext Preprocessor">PHP</acronym> community decided to disable this directive by 
    default.  When on, people use variables yet really don&#039;t know for sure
    where they come from and can only assume.  Internal variables that are
    defined in the script itself get mixed up with request data sent by
    users and disabling register_globals changes this.  Let&#039;s demonstrate
    with an example misuse of register_globals: 
   </p>
   <p class="para">
    <div class="example" id="example-369">
     <p><strong>Example #1 Example misuse with register_globals = on</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #FF8000">//&nbsp;define&nbsp;$authorized&nbsp;=&nbsp;true&nbsp;only&nbsp;if&nbsp;user&nbsp;is&nbsp;authenticated<br /></span><span style="color: #007700">if&nbsp;(</span><span style="color: #0000BB">authenticated_user</span><span style="color: #007700">())&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$authorized&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">true</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #FF8000">//&nbsp;Because&nbsp;we&nbsp;didn't&nbsp;first&nbsp;initialize&nbsp;$authorized&nbsp;as&nbsp;false,&nbsp;this&nbsp;might&nbsp;be<br />//&nbsp;defined&nbsp;through&nbsp;register_globals,&nbsp;like&nbsp;from&nbsp;GET&nbsp;auth.php?authorized=1<br />//&nbsp;So,&nbsp;anyone&nbsp;can&nbsp;be&nbsp;seen&nbsp;as&nbsp;authenticated!<br /></span><span style="color: #007700">if&nbsp;(</span><span style="color: #0000BB">$authorized</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;include&nbsp;</span><span style="color: #DD0000">"/highly/sensitive/data.php"</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>
   <p class="para">
    When register_globals = on, our logic above may be compromised.  When
    off, <var class="varname"><var class="varname">$authorized</var></var> can&#039;t be set via request so it&#039;ll
    be fine, although it really is generally a good programming practice to
    initialize variables first.  For example, in our example above we might
    have first done <em>$authorized = false</em>.  Doing this
    first means our above code would work with register_globals on or off as
    users by default would be unauthorized.
   </p>
   <p class="para">
    Another example is that of <a href="ref.session.php" class="link">sessions</a>.
    When register_globals = on, we could also use
    <var class="varname"><var class="varname">$username</var></var> in our example below but again you must
    realize that <var class="varname"><var class="varname">$username</var></var> could also come from other
    means, such as GET (through the <acronym title="Uniform Resource Locator">URL</acronym>).
   </p>
   <p class="para">
    <div class="example" id="example-370">
     <p><strong>Example #2 Example use of sessions with register_globals on or off</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #FF8000">//&nbsp;We&nbsp;wouldn't&nbsp;know&nbsp;where&nbsp;$username&nbsp;came&nbsp;from&nbsp;but&nbsp;do&nbsp;know&nbsp;$_SESSION&nbsp;is<br />//&nbsp;for&nbsp;session&nbsp;data<br /></span><span style="color: #007700">if&nbsp;(isset(</span><span style="color: #0000BB">$_SESSION</span><span style="color: #007700">[</span><span style="color: #DD0000">'username'</span><span style="color: #007700">]))&nbsp;{<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"Hello&nbsp;&lt;b&gt;</span><span style="color: #007700">{</span><span style="color: #0000BB">$_SESSION</span><span style="color: #007700">[</span><span style="color: #DD0000">'username'</span><span style="color: #007700">]}</span><span style="color: #DD0000">&lt;/b&gt;"</span><span style="color: #007700">;<br /><br />}&nbsp;else&nbsp;{<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"Hello&nbsp;&lt;b&gt;Guest&lt;/b&gt;&lt;br&nbsp;/&gt;"</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"Would&nbsp;you&nbsp;like&nbsp;to&nbsp;login?"</span><span style="color: #007700">;<br /><br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>
   <p class="para">
    It&#039;s even possible to take preventative measures to warn when forging is
    being attempted. If you know ahead of time exactly where a variable
    should be coming from, you can check to see if the submitted data is
    coming from an inappropriate kind of submission.  While it doesn&#039;t
    guarantee that data has not been forged, it does require an attacker to
    guess the right kind of forging.  If you don&#039;t care where the request
    data comes from, you can use <var class="varname"><var class="varname"><a href="reserved.variables.request.php" class="classname">$_REQUEST</a></var></var> as it contains
    a mix of GET, POST and COOKIE data.  See also the manual section on
    using <a href="language.variables.external.php" class="link">variables from external
    sources</a>.
   </p>
   <p class="para">
    <div class="example" id="example-371">
     <p><strong>Example #3 Detecting simple variable poisoning</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">if&nbsp;(isset(</span><span style="color: #0000BB">$_COOKIE</span><span style="color: #007700">[</span><span style="color: #DD0000">'MAGIC_COOKIE'</span><span style="color: #007700">]))&nbsp;{<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;MAGIC_COOKIE&nbsp;comes&nbsp;from&nbsp;a&nbsp;cookie.<br />&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;Be&nbsp;sure&nbsp;to&nbsp;validate&nbsp;the&nbsp;cookie&nbsp;data!<br /><br /></span><span style="color: #007700">}&nbsp;elseif&nbsp;(isset(</span><span style="color: #0000BB">$_GET</span><span style="color: #007700">[</span><span style="color: #DD0000">'MAGIC_COOKIE'</span><span style="color: #007700">])&nbsp;||&nbsp;isset(</span><span style="color: #0000BB">$_POST</span><span style="color: #007700">[</span><span style="color: #DD0000">'MAGIC_COOKIE'</span><span style="color: #007700">]))&nbsp;{<br /><br />&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">mail</span><span style="color: #007700">(</span><span style="color: #DD0000">"admin@example.com"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"Possible&nbsp;breakin&nbsp;attempt"</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$_SERVER</span><span style="color: #007700">[</span><span style="color: #DD0000">'REMOTE_ADDR'</span><span style="color: #007700">]);<br />&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"Security&nbsp;violation,&nbsp;admin&nbsp;has&nbsp;been&nbsp;alerted."</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;exit;<br /><br />}&nbsp;else&nbsp;{<br /><br />&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;MAGIC_COOKIE&nbsp;isn't&nbsp;set&nbsp;through&nbsp;this&nbsp;REQUEST<br /><br /></span><span style="color: #007700">}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>
   <p class="para">
    Of course, simply turning off register_globals does not mean your code
    is secure.  For every piece of data that is submitted, it should also be
    checked in other ways.  Always validate your user data and initialize
    your variables!  To check for uninitialized variables you may turn up
    <span class="function"><a href="function.error-reporting.php" class="function">error_reporting()</a></span> to show
    <strong><code>E_NOTICE</code></strong> level errors.
   </p>
   <p class="para">
    For information about emulating register_globals being On or Off, see this <a href="faq.misc.php#faq.misc.registerglobals" class="link">FAQ</a>.
   </p>
  </div>

<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=security.globals&amp;redirect=http://php.net/manual/en/security.globals.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">12 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="89787">  <div class="votes">
    <div id="Vu89787">
    <a href="/manual/vote-note.php?id=89787&amp;page=security.globals&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd89787">
    <a href="/manual/vote-note.php?id=89787&amp;page=security.globals&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V89787" title="73% like this...">
    69
    </div>
  </div>
  <a href="#89787" class="name">
  <strong class="user"><em>lester burlap</em></strong></a><a class="genanchor" href="#89787"> &para;</a><div class="date" title="2009-03-23 09:00"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom89787">
<div class="phpcode"><code><span class="html">
It would make this whole issue a lot less confusing for less-experienced PHP programmers if you just explained:<br /><br />- $myVariable no longer works by default<br />- $_GET['myVariable'] works just fine<br /><br />I'm embarrassed to say it's taken me six months since my ISP upgraded to PHP5 figure this out.&nbsp; I've completely rewritten scripts to stop using GET variables altogether.<br /><br />I'm dumb.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="88209">  <div class="votes">
    <div id="Vu88209">
    <a href="/manual/vote-note.php?id=88209&amp;page=security.globals&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd88209">
    <a href="/manual/vote-note.php?id=88209&amp;page=security.globals&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V88209" title="65% like this...">
    16
    </div>
  </div>
  <a href="#88209" class="name">
  <strong class="user"><em>claude dot pache at gmail dot com</em></strong></a><a class="genanchor" href="#88209"> &para;</a><div class="date" title="2009-01-15 05:52"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom88209">
<div class="phpcode"><code><span class="html">
Beware that all the solutions given in the comments below for emulating register_global being off are bogus, because they can destroy predefined variables you should not unset. For example, suppose that you have<br /><br /><span class="default">&lt;?php $_GET</span><span class="keyword">[</span><span class="string">'_COOKIE'</span><span class="keyword">] == </span><span class="string">'foo'</span><span class="keyword">; </span><span class="default">?&gt;<br /></span><br />Then the simplistic solutions of the previous comments let you lose all the cookies registered in the superglobal "$_COOKIE"! (Note that in this situation, even with register_global set to "on", PHP is smart enough to not mess predefined variables such as&nbsp; $_COOKIE.)<br /><br />A proper solution for emulating register_global being off is given in the FAQ, as stated in the documentation above.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120184">  <div class="votes">
    <div id="Vu120184">
    <a href="/manual/vote-note.php?id=120184&amp;page=security.globals&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120184">
    <a href="/manual/vote-note.php?id=120184&amp;page=security.globals&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120184" title="62% like this...">
    4
    </div>
  </div>
  <a href="#120184" class="name">
  <strong class="user"><em>tomas at hauso dot sk</em></strong></a><a class="genanchor" href="#120184"> &para;</a><div class="date" title="2016-11-18 01:30"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom120184">
<div class="phpcode"><code><span class="html">
for PHP5.4+ you can use registry pattern instead global<br /><br />final class MyGlobal {<br />&nbsp; &nbsp; private static $data = array();<br /><br />&nbsp; &nbsp; public static function get($key) {<br />&nbsp; &nbsp; &nbsp; &nbsp; return (isset(static::$data[$key]) ? static::$data[$key] : null);<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public static function set($key, $value) {<br />&nbsp; &nbsp; &nbsp; &nbsp; static::$data[$key] = $value;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public static function has($key) {<br />&nbsp; &nbsp; &nbsp; &nbsp; return isset(static::$data[$key]);<br />&nbsp; &nbsp; }<br /><br />}<br />// END OF CLASS<br /><br />$var1 = 'I wanna be global';<br /><br />MyGlobal::set('bar', $var1 ); // set var to registry<br /><br />function foo(){<br />&nbsp; &nbsp; echo MyGlobal::get('bar'); // get var from registry<br />}<br /><br />foo();</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113106">  <div class="votes">
    <div id="Vu113106">
    <a href="/manual/vote-note.php?id=113106&amp;page=security.globals&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113106">
    <a href="/manual/vote-note.php?id=113106&amp;page=security.globals&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113106" title="56% like this...">
    9
    </div>
  </div>
  <a href="#113106" class="name">
  <strong class="user"><em>elitescripts2000 at yahoo dot com</em></strong></a><a class="genanchor" href="#113106"> &para;</a><div class="date" title="2013-08-30 04:23"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113106">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br /><br /></span><span class="comment">/* Forces all GET and POST globals to register and be magically quoted.<br /> * This forced register_globals and magic_quotes_gpc both act as if<br /> * they were turned ON even if turned off in your php.ini file.<br /> *<br /> * Reason behind forcing register_globals and magic_quotes is for legacy<br /> * PHP scripts that need to run with PHP 5.4 and higher.&nbsp; PHP 5.4+ no longer<br /> * support register_globals and magic_quotes, which breaks legacy PHP code.<br /> *<br /> * This is used as a workaround, while you upgrade your PHP code, yet still<br /> * allows you to run in a PHP 5.4+ environment.<br /> *<br /> * Licenced under the GPLv2. Matt Kukowski Sept. 2013<br /> */<br /><br /></span><span class="keyword">if (! isset(</span><span class="default">$PXM_REG_GLOB</span><span class="keyword">)) {<br /><br />&nbsp; </span><span class="default">$PXM_REG_GLOB </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br /><br />&nbsp; if (! </span><span class="default">ini_get</span><span class="keyword">(</span><span class="string">'register_globals'</span><span class="keyword">)) {<br />&nbsp; &nbsp; foreach (</span><span class="default">array_merge</span><span class="keyword">(</span><span class="default">$_GET</span><span class="keyword">, </span><span class="default">$_POST</span><span class="keyword">) as </span><span class="default">$key </span><span class="keyword">=&gt; </span><span class="default">$val</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; global $</span><span class="default">$key</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; $</span><span class="default">$key </span><span class="keyword">= (</span><span class="default">get_magic_quotes_gpc</span><span class="keyword">()) ? </span><span class="default">$val </span><span class="keyword">: </span><span class="default">addslashes</span><span class="keyword">(</span><span class="default">$val</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; }<br />&nbsp; if (! </span><span class="default">get_magic_quotes_gpc</span><span class="keyword">()) {<br />&nbsp; &nbsp; foreach (</span><span class="default">$_POST </span><span class="keyword">as </span><span class="default">$key </span><span class="keyword">=&gt; </span><span class="default">$val</span><span class="keyword">) </span><span class="default">$_POST</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">] = </span><span class="default">addslashes</span><span class="keyword">(</span><span class="default">$val</span><span class="keyword">);<br />&nbsp; &nbsp; foreach (</span><span class="default">$_GET </span><span class="keyword">as </span><span class="default">$key </span><span class="keyword">=&gt; </span><span class="default">$val</span><span class="keyword">)&nbsp; </span><span class="default">$_GET</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">]&nbsp; = </span><span class="default">addslashes</span><span class="keyword">(</span><span class="default">$val</span><span class="keyword">);<br />&nbsp; }<br />}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="115632">  <div class="votes">
    <div id="Vu115632">
    <a href="/manual/vote-note.php?id=115632&amp;page=security.globals&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115632">
    <a href="/manual/vote-note.php?id=115632&amp;page=security.globals&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115632" title="57% like this...">
    5
    </div>
  </div>
  <a href="#115632" class="name">
  <strong class="user"><em>arman_y_92 at yahoo dot com</em></strong></a><a class="genanchor" href="#115632"> &para;</a><div class="date" title="2014-08-28 02:44"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115632">
<div class="phpcode"><code><span class="html">
To all those fans of this insecure functionality (which I'm glad is now turned off by default) , you can just use extract() to achieve a similar goal more securely (unless you overwrite local variables with $_GET or $_POST data).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117098">  <div class="votes">
    <div id="Vu117098">
    <a href="/manual/vote-note.php?id=117098&amp;page=security.globals&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117098">
    <a href="/manual/vote-note.php?id=117098&amp;page=security.globals&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117098" title="52% like this...">
    2
    </div>
  </div>
  <a href="#117098" class="name">
  <strong class="user"><em>thewordsmith at hotmail dot com</em></strong></a><a class="genanchor" href="#117098"> &para;</a><div class="date" title="2015-04-14 10:09"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117098">
<div class="phpcode"><code><span class="html">
//Some servers do not have register globals turned on. This loop converts $_BLAH into global variables.<br />foreach($_COOKIE as $key =&gt; $value) {<br />&nbsp; &nbsp; if(!is_array($value)){<br />&nbsp; &nbsp; &nbsp; &nbsp; ${$key} = trim(rawurldecode($value));<br />&nbsp; &nbsp; &nbsp; &nbsp; //echo "$key $value&lt;br&gt;";<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; else{<br />&nbsp; &nbsp; &nbsp; &nbsp; ${$key} = $value;<br />&nbsp; &nbsp; }<br />}<br />foreach($_GET as $key =&gt; $value) { <br />&nbsp; &nbsp; if(!is_array($value)){<br />&nbsp; &nbsp; &nbsp; &nbsp; ${$key} = trim(rawurldecode($value));<br />&nbsp; &nbsp; &nbsp; &nbsp; //echo "$key $value&lt;br&gt;";<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; else{<br />&nbsp; &nbsp; &nbsp; &nbsp; ${$key} = $value;<br />&nbsp; &nbsp; }<br />}<br />foreach($_POST as $key =&gt; $value) { <br />&nbsp; &nbsp; if(!is_array($value)){<br />&nbsp; &nbsp; &nbsp; &nbsp; ${$key} = trim(rawurldecode($value));<br />&nbsp; &nbsp; &nbsp; &nbsp; //echo "$key $value&lt;br&gt;";<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; else{<br />&nbsp; &nbsp; &nbsp; &nbsp; ${$key} = $value;<br />&nbsp; &nbsp; }<br />}<br />foreach($_REQUEST as $key =&gt; $value) { <br />&nbsp; &nbsp; if(!is_array($value)){<br />&nbsp; &nbsp; &nbsp; &nbsp; ${$key} = trim(rawurldecode($value));<br />&nbsp; &nbsp; &nbsp; &nbsp; //echo "$key $value&lt;br&gt;";<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; else{<br />&nbsp; &nbsp; &nbsp; &nbsp; ${$key} = $value;<br />&nbsp; &nbsp; }<br />}<br />foreach($_SERVER as $key =&gt; $value) { <br />&nbsp; &nbsp; if(!is_array($value)){<br />&nbsp; &nbsp; &nbsp; &nbsp; ${$key} = trim(rawurldecode($value));<br />&nbsp; &nbsp; &nbsp; &nbsp; //echo "$key $value&lt;br&gt;";<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; else{<br />&nbsp; &nbsp; &nbsp; &nbsp; ${$key} = $value;<br />&nbsp; &nbsp; }<br />}</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116735">  <div class="votes">
    <div id="Vu116735">
    <a href="/manual/vote-note.php?id=116735&amp;page=security.globals&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116735">
    <a href="/manual/vote-note.php?id=116735&amp;page=security.globals&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116735" title="48% like this...">
    -1
    </div>
  </div>
  <a href="#116735" class="name">
  <strong class="user"><em>chirag176 at yahoo dot com dot au</em></strong></a><a class="genanchor" href="#116735"> &para;</a><div class="date" title="2015-02-20 09:52"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom116735">
<div class="phpcode"><code><span class="html">
$mypost = secure($_POST);<br /><br />function AddBatch($mypost,$Session_Prefix){<br />...<br />}</span>
</code></div>
  </div>
 </div>
  <div class="note" id="82213">  <div class="votes">
    <div id="Vu82213">
    <a href="/manual/vote-note.php?id=82213&amp;page=security.globals&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd82213">
    <a href="/manual/vote-note.php?id=82213&amp;page=security.globals&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V82213" title="45% like this...">
    -6
    </div>
  </div>
  <a href="#82213" class="name">
  <strong class="user"><em>Ruquay K Calloway</em></strong></a><a class="genanchor" href="#82213"> &para;</a><div class="date" title="2008-04-01 05:59"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom82213">
<div class="phpcode"><code><span class="html">
While we all appreciate the many helpful posts to get rid of register_globals, maybe you're one of those who just loves it.&nbsp; More likely, your boss says you just have to live with it because he thinks it's a great feature.<br /><br />No problem, just call (below defined):<br /><br /><span class="default">&lt;?php register_globals</span><span class="keyword">(); </span><span class="default">?&gt;<br /></span><br />anywhere, as often as you want.&nbsp; Or update your scripts!<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">/**<br /> * function to emulate the register_globals setting in PHP<br /> * for all of those diehard fans of possibly harmful PHP settings :-)<br /> * @author Ruquay K Calloway<br /> * @param string $order order in which to register the globals, e.g. 'egpcs' for default<br /> */<br /></span><span class="keyword">function </span><span class="default">register_globals</span><span class="keyword">(</span><span class="default">$order </span><span class="keyword">= </span><span class="string">'egpcs'</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="comment">// define a subroutine<br />&nbsp; &nbsp; </span><span class="keyword">if(!</span><span class="default">function_exists</span><span class="keyword">(</span><span class="string">'register_global_array'</span><span class="keyword">))<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; function </span><span class="default">register_global_array</span><span class="keyword">(array </span><span class="default">$superglobal</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; foreach(</span><span class="default">$superglobal </span><span class="keyword">as </span><span class="default">$varname </span><span class="keyword">=&gt; </span><span class="default">$value</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; global $</span><span class="default">$varname</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $</span><span class="default">$varname </span><span class="keyword">= </span><span class="default">$value</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="default">$order </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">(</span><span class="string">"\r\n"</span><span class="keyword">, </span><span class="default">trim</span><span class="keyword">(</span><span class="default">chunk_split</span><span class="keyword">(</span><span class="default">$order</span><span class="keyword">, </span><span class="default">1</span><span class="keyword">)));<br />&nbsp; &nbsp; foreach(</span><span class="default">$order </span><span class="keyword">as </span><span class="default">$k</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; switch(</span><span class="default">strtolower</span><span class="keyword">(</span><span class="default">$k</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">'e'</span><span class="keyword">:&nbsp; &nbsp; </span><span class="default">register_global_array</span><span class="keyword">(</span><span class="default">$_ENV</span><span class="keyword">);&nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">'g'</span><span class="keyword">:&nbsp; &nbsp; </span><span class="default">register_global_array</span><span class="keyword">(</span><span class="default">$_GET</span><span class="keyword">);&nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">'p'</span><span class="keyword">:&nbsp; &nbsp; </span><span class="default">register_global_array</span><span class="keyword">(</span><span class="default">$_POST</span><span class="keyword">);&nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">'c'</span><span class="keyword">:&nbsp; &nbsp; </span><span class="default">register_global_array</span><span class="keyword">(</span><span class="default">$_COOKIE</span><span class="keyword">);&nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">'s'</span><span class="keyword">:&nbsp; &nbsp; </span><span class="default">register_global_array</span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">);&nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="84444">  <div class="votes">
    <div id="Vu84444">
    <a href="/manual/vote-note.php?id=84444&amp;page=security.globals&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd84444">
    <a href="/manual/vote-note.php?id=84444&amp;page=security.globals&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V84444" title="44% like this...">
    -5
    </div>
  </div>
  <a href="#84444" class="name">
  <strong class="user"><em>moore at hs-furtwangen dot de</em></strong></a><a class="genanchor" href="#84444"> &para;</a><div class="date" title="2008-07-14 01:19"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom84444">
<div class="phpcode"><code><span class="html">
I had a look at the post from Dice, in which he suggested the function unregister_globals(). It didn't seem to work - only tested php 4.4.8 and 5.2.1 - so I made some tweaking to get it running. (I had to use $GLOBALS due to the fact that $$name won't work with superglobals).<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">//Undo register_globals<br /></span><span class="keyword">function </span><span class="default">unregister_globals</span><span class="keyword">() {<br />&nbsp; &nbsp; if (</span><span class="default">ini_get</span><span class="keyword">(</span><span class="string">'register_globals'</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$array </span><span class="keyword">= array(</span><span class="string">'_REQUEST'</span><span class="keyword">, </span><span class="string">'_FILES'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach (</span><span class="default">$array </span><span class="keyword">as </span><span class="default">$value</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if(isset(</span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="default">$value</span><span class="keyword">])){<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; foreach (</span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="default">$value</span><span class="keyword">] as </span><span class="default">$key </span><span class="keyword">=&gt; </span><span class="default">$var</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (isset(</span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">]) &amp;&amp; </span><span class="default">$var </span><span class="keyword">=== </span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">]) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//echo 'found '.$key.' = '.$var.' in $'.$value."\n";&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">unset(</span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />The echo was for debuging, thought it might come in handy.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119855">  <div class="votes">
    <div id="Vu119855">
    <a href="/manual/vote-note.php?id=119855&amp;page=security.globals&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119855">
    <a href="/manual/vote-note.php?id=119855&amp;page=security.globals&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119855" title="40% like this...">
    -3
    </div>
  </div>
  <a href="#119855" class="name">
  <strong class="user"><em>steve at dbnsystems dot com</em></strong></a><a class="genanchor" href="#119855"> &para;</a><div class="date" title="2016-09-07 02:23"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119855">
<div class="phpcode"><code><span class="html">
The following version could be even faster, unless anyone may come with a good reason why this wouldn't be a good practice:<br /><br />&lt;pre&gt;<br />function unregister_globals() {<br />&nbsp; &nbsp; if (ini_get(register_globals)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; $array = array('_REQUEST', '_SESSION', '_SERVER', '_ENV', '_FILES');<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach ($array as $value) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $$value = [];<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />}<br />&lt;/pre&gt;</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116736">  <div class="votes">
    <div id="Vu116736">
    <a href="/manual/vote-note.php?id=116736&amp;page=security.globals&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116736">
    <a href="/manual/vote-note.php?id=116736&amp;page=security.globals&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116736" title="33% like this...">
    -10
    </div>
  </div>
  <a href="#116736" class="name">
  <strong class="user"><em>chirag</em></strong></a><a class="genanchor" href="#116736"> &para;</a><div class="date" title="2015-02-21 01:26"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom116736">
<div class="phpcode"><code><span class="html">
Fatal error: Cannot re-assign auto-global variable _POST<br /><br />Final Solution for php 5.4 and above version<br /><br />$a =&nbsp; $_POST;<br />function add($_POST;){<br /> echo $_POST['a'];<br /> echo $_POST['b'];<br />}<br />add($a);</span>
</code></div>
  </div>
 </div>
  <div class="note" id="82542">  <div class="votes">
    <div id="Vu82542">
    <a href="/manual/vote-note.php?id=82542&amp;page=security.globals&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd82542">
    <a href="/manual/vote-note.php?id=82542&amp;page=security.globals&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V82542" title="38% like this...">
    -19
    </div>
  </div>
  <a href="#82542" class="name">
  <strong class="user"><em>Dice</em></strong></a><a class="genanchor" href="#82542"> &para;</a><div class="date" title="2008-04-15 09:46"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom82542">
<div class="phpcode"><code><span class="html">
To expand on the nice bit of code Mike Willbanks wrote and Alexander tidied up, I turned the whole thing in a function that removes all the globals added by register_globals so it can be implemented in an included functions.php and doesn't litter the main pages too much.<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">//Undo register_globals<br /></span><span class="keyword">function </span><span class="default">unregister_globals</span><span class="keyword">() {<br />&nbsp; &nbsp; if (</span><span class="default">ini_get</span><span class="keyword">(</span><span class="default">register_globals</span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$array </span><span class="keyword">= array(</span><span class="string">'_REQUEST'</span><span class="keyword">, </span><span class="string">'_SESSION'</span><span class="keyword">, </span><span class="string">'_SERVER'</span><span class="keyword">, </span><span class="string">'_ENV'</span><span class="keyword">, </span><span class="string">'_FILES'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach (</span><span class="default">$array </span><span class="keyword">as </span><span class="default">$value</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; foreach (</span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="default">$value</span><span class="keyword">] as </span><span class="default">$key </span><span class="keyword">=&gt; </span><span class="default">$var</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">$var </span><span class="keyword">=== </span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">]) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; unset(</span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="default">$key</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=security.globals&amp;redirect=http://php.net/manual/en/security.globals.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="security.php">Security</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="security.intro.php" title="Introduction">Introduction</a>
                        </li>
                          
                        <li class="">
                            <a href="security.general.php" title="General considerations">General considerations</a>
                        </li>
                          
                        <li class="">
                            <a href="security.cgi-bin.php" title="Installed as CGI binary">Installed as CGI binary</a>
                        </li>
                          
                        <li class="">
                            <a href="security.apache.php" title="Installed as an Apache module">Installed as an Apache module</a>
                        </li>
                          
                        <li class="">
                            <a href="security.sessions.php" title="Session Security">Session Security</a>
                        </li>
                          
                        <li class="">
                            <a href="security.filesystem.php" title="Filesystem Security">Filesystem Security</a>
                        </li>
                          
                        <li class="">
                            <a href="security.database.php" title="Database Security">Database Security</a>
                        </li>
                          
                        <li class="">
                            <a href="security.errors.php" title="Error Reporting">Error Reporting</a>
                        </li>
                          
                        <li class="current">
                            <a href="security.globals.php" title="Using Register Globals">Using Register Globals</a>
                        </li>
                          
                        <li class="">
                            <a href="security.variables.php" title="User Submitted Data">User Submitted Data</a>
                        </li>
                          
                        <li class="">
                            <a href="security.magicquotes.php" title="Magic Quotes">Magic Quotes</a>
                        </li>
                          
                        <li class="">
                            <a href="security.hiding.php" title="Hiding PHP">Hiding PHP</a>
                        </li>
                          
                        <li class="">
                            <a href="security.current.php" title="Keeping Current">Keeping Current</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

