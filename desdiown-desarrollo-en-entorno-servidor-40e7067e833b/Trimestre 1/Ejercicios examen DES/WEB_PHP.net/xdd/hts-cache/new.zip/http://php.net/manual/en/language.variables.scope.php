<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Variable scope - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.variables.scope.php">
 <link rel="shorturl" href="http://php.net/variables.scope">
 <link rel="alternate" href="http://php.net/variables.scope" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.variables.php">
 <link rel="prev" href="http://php.net/manual/en/language.variables.predefined.php">
 <link rel="next" href="http://php.net/manual/en/language.variables.variable.php">

 <link rel="alternate" href="http://php.net/manual/en/language.variables.scope.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.variables.scope.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.variables.scope.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.variables.scope.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.variables.scope.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.variables.scope.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.variables.scope.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.variables.scope.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.variables.scope.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.variables.scope.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.variables.scope.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.variables.variable.php">
          Variable variables &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.variables.predefined.php">
          &laquo; Predefined Variables        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.variables.php'>Variables</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.variables.scope.php' selected="selected">English</option>
            <option value='pt_BR/language.variables.scope.php'>Brazilian Portuguese</option>
            <option value='zh/language.variables.scope.php'>Chinese (Simplified)</option>
            <option value='fr/language.variables.scope.php'>French</option>
            <option value='de/language.variables.scope.php'>German</option>
            <option value='ja/language.variables.scope.php'>Japanese</option>
            <option value='ro/language.variables.scope.php'>Romanian</option>
            <option value='ru/language.variables.scope.php'>Russian</option>
            <option value='es/language.variables.scope.php'>Spanish</option>
            <option value='tr/language.variables.scope.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.variables.scope.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.variables.scope">Report a Bug</a>
    </div>
  </div><div id="language.variables.scope" class="sect1">
   <h2 class="title">Variable scope</h2>

   <p class="simpara">
    The scope of a variable is the context within which it is defined.
    For the most part all PHP variables only have a single scope.
    This single scope spans included and required files as well.  For
    example:
   </p>
   <div class="informalexample">
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$a&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">;<br />include&nbsp;</span><span style="color: #DD0000">'b.inc'</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
   <p class="simpara">
    Here the <var class="varname"><var class="varname">$a</var></var> variable will be available within
    the included <var class="filename">b.inc</var> script.  However, within
    user-defined functions a local function scope is introduced.  Any
    variable used inside a function is by default limited to the local
    function scope.  For example:
   </p>
    
   <div class="informalexample">
    <div class="example-contents"> 
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$a&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">/*&nbsp;global&nbsp;scope&nbsp;*/&nbsp;<br /><br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">test</span><span style="color: #007700">()<br />{&nbsp;<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #0000BB">$a</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">/*&nbsp;reference&nbsp;to&nbsp;local&nbsp;scope&nbsp;variable&nbsp;*/&nbsp;<br /></span><span style="color: #007700">}&nbsp;<br /><br /></span><span style="color: #0000BB">test</span><span style="color: #007700">();<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>

   <p class="simpara">
    This script will not produce any output because the echo statement
    refers to a local version of the <var class="varname"><var class="varname">$a</var></var> variable,
    and it has not been assigned a value within this scope.  You may
    notice that this is a little bit different from the C language in
    that global variables in C are automatically available to
    functions unless specifically overridden by a local definition.
    This can cause some problems in that people may inadvertently
    change a global variable.  In PHP global variables must be
    declared global inside a function if they are going to be used in
    that function.
   </p>
       
   <div class="sect2" id="language.variables.scope.global">
    <h3 class="title">The <em>global</em> keyword</h3>
    <p class="simpara">
     First, an example use of <em>global</em>:
    </p>
    <p class="para">
     <div class="example" id="example-78">
      <p><strong>Example #1 Using <em>global</em></strong></p>
      <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$a&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$b&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">;<br /><br />function&nbsp;</span><span style="color: #0000BB">Sum</span><span style="color: #007700">()<br />{<br />&nbsp;&nbsp;&nbsp;&nbsp;global&nbsp;</span><span style="color: #0000BB">$a</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$b</span><span style="color: #007700">;<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$b&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">+&nbsp;</span><span style="color: #0000BB">$b</span><span style="color: #007700">;<br />}&nbsp;<br /><br /></span><span style="color: #0000BB">Sum</span><span style="color: #007700">();<br />echo&nbsp;</span><span style="color: #0000BB">$b</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
      </div>

     </div>
    </p>

   <p class="simpara">
    The above script will output <em>3</em>.  By declaring
    <var class="varname"><var class="varname">$a</var></var> and <var class="varname"><var class="varname">$b</var></var> global within the
    function, all references to either variable will refer to the
    global version.  There is no limit to the number of global
    variables that can be manipulated by a function.
   </p>

   <p class="simpara">
    A second way to access variables from the global scope is to use
    the special PHP-defined <var class="varname"><var class="varname"><a href="reserved.variables.globals.php" class="classname">$GLOBALS</a></var></var> array.  The
    previous example can be rewritten as:
   </p>
   <p class="para">
    <div class="example" id="language.types.array.examples.loop">
     <p><strong>Example #2 Using <var class="varname"><var class="varname"><a href="reserved.variables.globals.php" class="classname">$GLOBALS</a></var></var> instead of global</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$a&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$b&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">;<br /><br />function&nbsp;</span><span style="color: #0000BB">Sum</span><span style="color: #007700">()<br />{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$GLOBALS</span><span style="color: #007700">[</span><span style="color: #DD0000">'b'</span><span style="color: #007700">]&nbsp;=&nbsp;</span><span style="color: #0000BB">$GLOBALS</span><span style="color: #007700">[</span><span style="color: #DD0000">'a'</span><span style="color: #007700">]&nbsp;+&nbsp;</span><span style="color: #0000BB">$GLOBALS</span><span style="color: #007700">[</span><span style="color: #DD0000">'b'</span><span style="color: #007700">];<br />}&nbsp;<br /><br /></span><span style="color: #0000BB">Sum</span><span style="color: #007700">();<br />echo&nbsp;</span><span style="color: #0000BB">$b</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>

   <p class="simpara">
    The <var class="varname"><var class="varname"><a href="reserved.variables.globals.php" class="classname">$GLOBALS</a></var></var> array is an associative array with
    the name of the global variable being the key and the contents of
    that variable being the value of the array element.
    Notice how <var class="varname"><var class="varname"><a href="reserved.variables.globals.php" class="classname">$GLOBALS</a></var></var> exists in any scope, this 
    is because <var class="varname"><var class="varname"><a href="reserved.variables.globals.php" class="classname">$GLOBALS</a></var></var> is a <a href="language.variables.superglobals.php" class="link">superglobal</a>.
    Here&#039;s an example demonstrating the power of superglobals: 
   </p>
   <p class="para">
    <div class="example" id="language.types.array.examples.changeloop">
     <p><strong>Example #3 Example demonstrating superglobals and scope</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">test_global</span><span style="color: #007700">()<br />{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;Most&nbsp;predefined&nbsp;variables&nbsp;aren't&nbsp;"super"&nbsp;and&nbsp;require&nbsp;<br />&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;'global'&nbsp;to&nbsp;be&nbsp;available&nbsp;to&nbsp;the&nbsp;functions&nbsp;local&nbsp;scope.<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">global&nbsp;</span><span style="color: #0000BB">$HTTP_POST_VARS</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #0000BB">$HTTP_POST_VARS</span><span style="color: #007700">[</span><span style="color: #DD0000">'name'</span><span style="color: #007700">];<br />&nbsp;&nbsp;&nbsp;&nbsp;<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;Superglobals&nbsp;are&nbsp;available&nbsp;in&nbsp;any&nbsp;scope&nbsp;and&nbsp;do&nbsp;<br />&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;not&nbsp;require&nbsp;'global'.&nbsp;Superglobals&nbsp;are&nbsp;available&nbsp;<br />&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;as&nbsp;of&nbsp;PHP&nbsp;4.1.0,&nbsp;and&nbsp;HTTP_POST_VARS&nbsp;is&nbsp;now<br />&nbsp;&nbsp;&nbsp;&nbsp;//&nbsp;deemed&nbsp;deprecated.<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">echo&nbsp;</span><span style="color: #0000BB">$_POST</span><span style="color: #007700">[</span><span style="color: #DD0000">'name'</span><span style="color: #007700">];<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>
   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <p class="para">
     Using <em>global</em> keyword outside a function is not an
     error. It can be used if the file is included from inside a function.
    </p>
   </p></blockquote>
  </div>
 
  <div class="sect2" id="language.variables.scope.static">
   <h3 class="title">Using <em>static</em> variables</h3>
   <p class="simpara">
    Another important feature of variable scoping is the
    <em class="emphasis">static</em> variable.  A static variable exists
    only in a local function scope, but it does not lose its value
    when program execution leaves this scope.  Consider the following
    example:
   </p>
   <p class="para">
    <div class="example" id="example-81">
     <p><strong>Example #4 Example demonstrating need for static variables</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">test</span><span style="color: #007700">()<br />{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">0</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #0000BB">$a</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$a</span><span style="color: #007700">++;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>
   <p class="simpara">
    This function is quite useless since every time it is called it
    sets <var class="varname"><var class="varname">$a</var></var> to <em>0</em> and prints
    <em>0</em>.  The <var class="varname"><var class="varname">$a</var></var>++ which increments the
    variable serves no purpose since as soon as the function exits the
    <var class="varname"><var class="varname">$a</var></var> variable disappears.  To make a useful
    counting function which will not lose track of the current count,
    the <var class="varname"><var class="varname">$a</var></var> variable is declared static:
   </p>
   <p class="para">
    <div class="example" id="example-82">
     <p><strong>Example #5 Example use of static variables</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">test</span><span style="color: #007700">()<br />{<br />&nbsp;&nbsp;&nbsp;&nbsp;static&nbsp;</span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">0</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #0000BB">$a</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$a</span><span style="color: #007700">++;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>
   <p class="simpara">
    Now, <var class="varname"><var class="varname">$a</var></var> is initialized only in first call of function
    and every time the <em>test()</em> function is called it will print the
    value of <var class="varname"><var class="varname">$a</var></var> and increment it.
   </p>

   <p class="simpara">
    Static variables also provide one way to deal with recursive
    functions. A recursive function is one which calls itself.  Care
    must be taken when writing a recursive function because it is
    possible to make it recurse indefinitely.  You must make sure you
    have an adequate way of terminating the recursion.  The following
    simple function recursively counts to 10, using the static
    variable <var class="varname"><var class="varname">$count</var></var> to know when to stop:
   </p>
   <p class="para">
    <div class="example" id="example-83">
     <p><strong>Example #6 Static variables with recursive functions</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">test</span><span style="color: #007700">()<br />{<br />&nbsp;&nbsp;&nbsp;&nbsp;static&nbsp;</span><span style="color: #0000BB">$count&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">0</span><span style="color: #007700">;<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$count</span><span style="color: #007700">++;<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #0000BB">$count</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(</span><span style="color: #0000BB">$count&nbsp;</span><span style="color: #007700">&lt;&nbsp;</span><span style="color: #0000BB">10</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">test</span><span style="color: #007700">();<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$count</span><span style="color: #007700">--;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>

   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <p class="para">
     Static variables may be declared as seen in the examples above.
     From PHP 5.6 you can assign values to these variables which are the
     result of expressions, but you can&#039;t use any function here, what will cause a parse error.
    </p>
    <p class="para">
     <div class="example" id="example-84">
      <p><strong>Example #7 Declaring static variables</strong></p>
      <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">foo</span><span style="color: #007700">(){<br />&nbsp;&nbsp;&nbsp;&nbsp;static&nbsp;</span><span style="color: #0000BB">$int&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">0</span><span style="color: #007700">;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;correct&nbsp;<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">static&nbsp;</span><span style="color: #0000BB">$int&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">+</span><span style="color: #0000BB">2</span><span style="color: #007700">;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;correct&nbsp;(as&nbsp;of&nbsp;PHP&nbsp;5.6)<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #007700">static&nbsp;</span><span style="color: #0000BB">$int&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">sqrt</span><span style="color: #007700">(</span><span style="color: #0000BB">121</span><span style="color: #007700">);&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;wrong&nbsp;&nbsp;(as&nbsp;it&nbsp;is&nbsp;a&nbsp;function)<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$int</span><span style="color: #007700">++;<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #0000BB">$int</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
      </div>

     </div>
    </p> 
   </p></blockquote>
   <blockquote class="note"><p><strong class="note">Note</strong>: 
    <p class="para">
     Static declarations are resolved in compile-time.
    </p>
   </p></blockquote>
  </div>

  <div class="sect2" id="language.variables.scope.references">
   <h3 class="title">References with <em>global</em> and <em>static</em> variables</h3>
   <p class="simpara">
    The Zend Engine 1, driving PHP 4, implements the
    <a href="language.variables.scope.php#language.variables.scope.static" class="link">static</a> and 
    <a href="language.variables.scope.php#language.variables.scope.global" class="link">global</a> modifier 
    for variables in terms of <a href="language.references.php" class="link">
    references</a>. For example, a true global variable
    imported inside a function scope with the <em>global</em>
    statement actually creates a reference to the global variable. This can
    lead to unexpected behaviour which the following example addresses:
   </p>

   <div class="informalexample">
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">test_global_ref</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;global&nbsp;</span><span style="color: #0000BB">$obj</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$obj&nbsp;</span><span style="color: #007700">=&nbsp;&amp;new&nbsp;</span><span style="color: #0000BB">stdclass</span><span style="color: #007700">;<br />}<br /><br />function&nbsp;</span><span style="color: #0000BB">test_global_noref</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;global&nbsp;</span><span style="color: #0000BB">$obj</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$obj&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">stdclass</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #0000BB">test_global_ref</span><span style="color: #007700">();<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$obj</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">test_global_noref</span><span style="color: #007700">();<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$obj</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>

   <p class="para">The above example will output:</p>

   <div class="example-contents screen"><br />
NULL<br />
object(stdClass)(0) {<br />
}<br />
   </div>

   <p class="simpara">
    A similar behaviour applies to the <em>static</em> statement.
    References are not stored statically:
   </p>
   
   <div class="informalexample">
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;&amp;</span><span style="color: #0000BB">get_instance_ref</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;static&nbsp;</span><span style="color: #0000BB">$obj</span><span style="color: #007700">;<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">'Static&nbsp;object:&nbsp;'</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$obj</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(!isset(</span><span style="color: #0000BB">$obj</span><span style="color: #007700">))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;Assign&nbsp;a&nbsp;reference&nbsp;to&nbsp;the&nbsp;static&nbsp;variable<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$obj&nbsp;</span><span style="color: #007700">=&nbsp;&amp;new&nbsp;</span><span style="color: #0000BB">stdclass</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$obj</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">property</span><span style="color: #007700">++;<br />&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">$obj</span><span style="color: #007700">;<br />}<br /><br />function&nbsp;&amp;</span><span style="color: #0000BB">get_instance_noref</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;static&nbsp;</span><span style="color: #0000BB">$obj</span><span style="color: #007700">;<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">'Static&nbsp;object:&nbsp;'</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$obj</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;if&nbsp;(!isset(</span><span style="color: #0000BB">$obj</span><span style="color: #007700">))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;Assign&nbsp;the&nbsp;object&nbsp;to&nbsp;the&nbsp;static&nbsp;variable<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$obj&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">stdclass</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$obj</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">property</span><span style="color: #007700">++;<br />&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">$obj</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #0000BB">$obj1&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">get_instance_ref</span><span style="color: #007700">();<br /></span><span style="color: #0000BB">$still_obj1&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">get_instance_ref</span><span style="color: #007700">();<br />echo&nbsp;</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$obj2&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">get_instance_noref</span><span style="color: #007700">();<br /></span><span style="color: #0000BB">$still_obj2&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">get_instance_noref</span><span style="color: #007700">();<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
    </div>

   </div>
   <p class="para">The above example will output:</p>
   <div class="example-contents screen"><br />
Static object: NULL<br />
Static object: NULL<br />
<br />
Static object: NULL<br />
Static object: object(stdClass)(1) {<br />
  [&quot;property&quot;]=&gt;<br />
  int(1)<br />
}<br />
   </div>

   <p class="simpara">
    This example demonstrates that when assigning a reference to a static
    variable, it&#039;s not <em class="emphasis">remembered</em> when you call the
    <em>&amp;get_instance_ref()</em> function a second time.
   </p>
   </div>
  </div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.variables.scope&amp;redirect=http://php.net/manual/en/language.variables.scope.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">56 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="59676">  <div class="votes">
    <div id="Vu59676">
    <a href="/manual/vote-note.php?id=59676&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd59676">
    <a href="/manual/vote-note.php?id=59676&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V59676" title="71% like this...">
    118
    </div>
  </div>
  <a href="#59676" class="name">
  <strong class="user"><em>warhog at warhog dot net</em></strong></a><a class="genanchor" href="#59676"> &para;</a><div class="date" title="2005-12-13 12:22"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom59676">
<div class="phpcode"><code><span class="html">
Some interesting behavior (tested with PHP5), using the static-scope-keyword inside of class-methods.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">sample_class<br /></span><span class="keyword">{<br />&nbsp; public function </span><span class="default">func_having_static_var</span><span class="keyword">(</span><span class="default">$x </span><span class="keyword">= </span><span class="default">NULL</span><span class="keyword">)<br />&nbsp; {<br />&nbsp; &nbsp; static </span><span class="default">$var </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />&nbsp; &nbsp; if (</span><span class="default">$x </span><span class="keyword">=== </span><span class="default">NULL</span><span class="keyword">)<br />&nbsp; &nbsp; { return </span><span class="default">$var</span><span class="keyword">; }<br />&nbsp; &nbsp; </span><span class="default">$var </span><span class="keyword">= </span><span class="default">$x</span><span class="keyword">;<br />&nbsp; }<br />}<br /><br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">sample_class</span><span class="keyword">();<br /></span><span class="default">$b </span><span class="keyword">= new </span><span class="default">sample_class</span><span class="keyword">();<br /><br />echo </span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">func_having_static_var</span><span class="keyword">().</span><span class="string">"\n"</span><span class="keyword">;<br />echo </span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">func_having_static_var</span><span class="keyword">().</span><span class="string">"\n"</span><span class="keyword">;<br /></span><span class="comment">// this will output (as expected):<br />//&nbsp; 0<br />//&nbsp; 0<br /><br /></span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">func_having_static_var</span><span class="keyword">(</span><span class="default">3</span><span class="keyword">);<br /><br />echo </span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">func_having_static_var</span><span class="keyword">().</span><span class="string">"\n"</span><span class="keyword">;<br />echo </span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">func_having_static_var</span><span class="keyword">().</span><span class="string">"\n"</span><span class="keyword">;<br /></span><span class="comment">// this will output:<br />//&nbsp; 3<br />//&nbsp; 3<br />// maybe you expected:<br />//&nbsp; 3<br />//&nbsp; 0<br /><br /></span><span class="default">?&gt;<br /></span><br />One could expect "3 0" to be outputted, as you might think that $a-&gt;func_having_static_var(3); only alters the value of the static $var of the function "in" $a - but as the name says, these are class-methods. Having an object is just a collection of properties, the functions remain at the class. So if you declare a variable as static inside a function, it's static for the whole class and all of its instances, not for each object.<br /><br />Maybe it's senseless to post that.. cause if you want to have the behaviour that I expected, you can simply use a variable of the object itself:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">sample_class<br /></span><span class="keyword">{ protected </span><span class="default">$var </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">; <br />&nbsp; function </span><span class="default">func</span><span class="keyword">(</span><span class="default">$x </span><span class="keyword">= </span><span class="default">NULL</span><span class="keyword">)<br />&nbsp; { </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">var </span><span class="keyword">= </span><span class="default">$x</span><span class="keyword">; }<br />} </span><span class="default">?&gt;<br /></span><br />I believe that all normal-thinking people would never even try to make this work with the static-keyword, for those who try (like me), this note maybe helpfull.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="105925">  <div class="votes">
    <div id="Vu105925">
    <a href="/manual/vote-note.php?id=105925&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd105925">
    <a href="/manual/vote-note.php?id=105925&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V105925" title="70% like this...">
    62
    </div>
  </div>
  <a href="#105925" class="name">
  <strong class="user"><em>dodothedreamer at gmail dot com</em></strong></a><a class="genanchor" href="#105925"> &para;</a><div class="date" title="2011-09-25 11:56"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom105925">
<div class="phpcode"><code><span class="html">
Note that unlike Java and C++, variables declared inside blocks such as loops or if's, will also be recognized and accessible outside of the block, so:<br /><span class="default">&lt;?php<br /></span><span class="keyword">for(</span><span class="default">$j</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">; </span><span class="default">$j</span><span class="keyword">&lt;</span><span class="default">3</span><span class="keyword">; </span><span class="default">$j</span><span class="keyword">++)<br />{<br />&nbsp; &nbsp;&nbsp; if(</span><span class="default">$j </span><span class="keyword">== </span><span class="default">1</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$a </span><span class="keyword">= </span><span class="default">4</span><span class="keyword">;<br />}<br />echo </span><span class="default">$a</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />Would print 4.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="98811">  <div class="votes">
    <div id="Vu98811">
    <a href="/manual/vote-note.php?id=98811&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd98811">
    <a href="/manual/vote-note.php?id=98811&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V98811" title="66% like this...">
    37
    </div>
  </div>
  <a href="#98811" class="name">
  <strong class="user"><em>HOSSEIN doesn&amp;#39;t want spam at TAKI.IR</em></strong></a><a class="genanchor" href="#98811"> &para;</a><div class="date" title="2010-07-09 12:26"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom98811">
<div class="phpcode"><code><span class="html">
Please note for using global variable in child functions:<br /><br />This won't work correctly...<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">foo</span><span class="keyword">(){<br />&nbsp; &nbsp; </span><span class="default">$f_a </span><span class="keyword">= </span><span class="string">'a'</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">bar</span><span class="keyword">(){<br />&nbsp; &nbsp; &nbsp; &nbsp; global </span><span class="default">$f_a</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'"f_a" in BAR is: ' </span><span class="keyword">. </span><span class="default">$f_a </span><span class="keyword">. </span><span class="string">'&lt;br /&gt;'</span><span class="keyword">;&nbsp; </span><span class="comment">// doesn't work, var is empty!<br />&nbsp; &nbsp; </span><span class="keyword">}<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="default">bar</span><span class="keyword">();<br />&nbsp; &nbsp; echo </span><span class="string">'"f_a" in FOO is: ' </span><span class="keyword">. </span><span class="default">$f_a </span><span class="keyword">. </span><span class="string">'&lt;br /&gt;'</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />This will...<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">foo</span><span class="keyword">(){<br />&nbsp; &nbsp; global </span><span class="default">$f_a</span><span class="keyword">;&nbsp;&nbsp; </span><span class="comment">// &lt;- Notice to this<br />&nbsp; &nbsp; </span><span class="default">$f_a </span><span class="keyword">= </span><span class="string">'a'</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; function </span><span class="default">bar</span><span class="keyword">(){<br />&nbsp; &nbsp; &nbsp; &nbsp; global </span><span class="default">$f_a</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'"f_a" in BAR is: ' </span><span class="keyword">. </span><span class="default">$f_a </span><span class="keyword">. </span><span class="string">'&lt;br /&gt;'</span><span class="keyword">;&nbsp; </span><span class="comment">// work!, var is 'a'<br />&nbsp; &nbsp; </span><span class="keyword">}<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="default">bar</span><span class="keyword">();<br />&nbsp; &nbsp; echo </span><span class="string">'"f_a" in FOO is: ' </span><span class="keyword">. </span><span class="default">$f_a </span><span class="keyword">. </span><span class="string">'&lt;br /&gt;'</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="63500">  <div class="votes">
    <div id="Vu63500">
    <a href="/manual/vote-note.php?id=63500&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd63500">
    <a href="/manual/vote-note.php?id=63500&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V63500" title="69% like this...">
    9
    </div>
  </div>
  <a href="#63500" class="name">
  <strong class="user"><em>larax at o2 dot pl</em></strong></a><a class="genanchor" href="#63500"> &para;</a><div class="date" title="2006-03-22 03:38"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom63500">
<div class="phpcode"><code><span class="html">
About more complex situation using global variables..<br /><br />Let's say we have two files:<br />a.php<br /><span class="default">&lt;?php <br />&nbsp; &nbsp; </span><span class="keyword">function </span><span class="default">a</span><span class="keyword">() { <br />&nbsp; &nbsp; &nbsp; &nbsp; include(</span><span class="string">"b.php"</span><span class="keyword">); <br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; </span><span class="default">a</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span><br />b.php<br /><span class="default">&lt;?php<br />&nbsp; &nbsp; $b </span><span class="keyword">= </span><span class="string">"something"</span><span class="keyword">;<br />&nbsp; &nbsp; function </span><span class="default">b</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; global </span><span class="default">$b</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$b </span><span class="keyword">= </span><span class="string">"something new"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; </span><span class="default">b</span><span class="keyword">();<br />&nbsp; &nbsp; echo </span><span class="default">$b</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />You could expect that this script will return "something new" but no, it will return "something". To make it working properly, you must add global keyword in $b definition, in above example it will be:<br /><br />global $b;<br />$b = "something";</span>
</code></div>
  </div>
 </div>
  <div class="note" id="45282">  <div class="votes">
    <div id="Vu45282">
    <a href="/manual/vote-note.php?id=45282&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd45282">
    <a href="/manual/vote-note.php?id=45282&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V45282" title="71% like this...">
    3
    </div>
  </div>
  <a href="#45282" class="name">
  <strong class="user"><em>info AT SyPlex DOT net</em></strong></a><a class="genanchor" href="#45282"> &para;</a><div class="date" title="2004-08-31 05:35"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom45282">
<div class="phpcode"><code><span class="html">
Some times you need to access the same static in more than one function. There is an easy way to solve this problem:<br /><br /><span class="default">&lt;?php<br />&nbsp; </span><span class="comment">// We need a way to get a reference of our static<br />&nbsp; </span><span class="keyword">function &amp;</span><span class="default">getStatic</span><span class="keyword">() {<br />&nbsp; &nbsp; static </span><span class="default">$staticVar</span><span class="keyword">;<br />&nbsp; &nbsp; return </span><span class="default">$staticVar</span><span class="keyword">;<br />&nbsp; }<br /><br />&nbsp; </span><span class="comment">// Now we can access the static in any method by using it's reference<br />&nbsp; </span><span class="keyword">function </span><span class="default">fooCount</span><span class="keyword">() {<br />&nbsp; &nbsp; </span><span class="default">$ref2static </span><span class="keyword">= &amp; </span><span class="default">getStatic</span><span class="keyword">();<br />&nbsp; &nbsp; echo </span><span class="default">$ref2static</span><span class="keyword">++;<br />&nbsp; }<br /><br />&nbsp; </span><span class="default">fooCount</span><span class="keyword">(); </span><span class="comment">// 0<br />&nbsp; </span><span class="default">fooCount</span><span class="keyword">(); </span><span class="comment">// 1<br />&nbsp; </span><span class="default">fooCount</span><span class="keyword">(); </span><span class="comment">// 2<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="88689">  <div class="votes">
    <div id="Vu88689">
    <a href="/manual/vote-note.php?id=88689&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd88689">
    <a href="/manual/vote-note.php?id=88689&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V88689" title="65% like this...">
    15
    </div>
  </div>
  <a href="#88689" class="name">
  <strong class="user"><em>andrew at planetubh dot com</em></strong></a><a class="genanchor" href="#88689"> &para;</a><div class="date" title="2009-02-03 12:16"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom88689">
<div class="phpcode"><code><span class="html">
Took me longer than I expected to figure this out, and thought others might find it useful.<br /><br />I created a function (safeinclude), which I use to include files; it does processing before the file is actually included (determine full path, check it exists, etc).<br /><br />Problem: Because the include was occurring inside the function, all of the variables inside the included file were inheriting the variable scope of the function; since the included files may or may not require global variables that are declared else where, it creates a problem.<br /><br />Most places (including here) seem to address this issue by something such as:<br /><span class="default">&lt;?php<br /></span><span class="comment">//declare this before include<br /></span><span class="keyword">global </span><span class="default">$myVar</span><span class="keyword">;<br /></span><span class="comment">//or declare this inside the include file<br /></span><span class="default">$nowglobal </span><span class="keyword">= </span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">'myVar'</span><span class="keyword">];<br /></span><span class="default">?&gt;<br /></span><br />But, to make this work in this situation (where a standard PHP file is included within a function, being called from another PHP script; where it is important to have access to whatever global variables there may be)... it is not practical to employ the above method for EVERY variable in every PHP file being included by 'safeinclude', nor is it practical to staticly name every possible variable in the "global $this" approach. (namely because the code is modulized, and 'safeinclude' is meant to be generic)<br /><br />My solution: Thus, to make all my global variables available to the files included with my safeinclude function, I had to add the following code to my safeinclude function (before variables are used or file is included)<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">foreach (</span><span class="default">$GLOBALS </span><span class="keyword">as </span><span class="default">$key </span><span class="keyword">=&gt; </span><span class="default">$val</span><span class="keyword">) { global $</span><span class="default">$key</span><span class="keyword">; }<br /></span><span class="default">?&gt;<br /></span><br />Thus, complete code looks something like the following (very basic model):<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">safeinclude</span><span class="keyword">(</span><span class="default">$filename</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="comment">//This line takes all the global variables, and sets their scope within the function:<br />&nbsp; &nbsp; </span><span class="keyword">foreach (</span><span class="default">$GLOBALS </span><span class="keyword">as </span><span class="default">$key </span><span class="keyword">=&gt; </span><span class="default">$val</span><span class="keyword">) { global $</span><span class="default">$key</span><span class="keyword">; }<br />&nbsp; &nbsp; </span><span class="comment">/* Pre-Processing here: validate filename input, determine full path<br />&nbsp; &nbsp; &nbsp; &nbsp; of file, check that file exists, etc. This is obviously not<br />&nbsp; &nbsp; &nbsp; &nbsp; necessary, but steps I found useful. */<br />&nbsp; &nbsp; </span><span class="keyword">if (</span><span class="default">$exists</span><span class="keyword">==</span><span class="default">true</span><span class="keyword">) { include(</span><span class="string">"</span><span class="default">$file</span><span class="string">"</span><span class="keyword">); }<br />&nbsp; &nbsp; return </span><span class="default">$exists</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />In the above, 'exists' &amp; 'file' are determined in the pre-processing. File is the full server path to the file, and exists is set to true if the file exists. This basic model can be expanded of course.&nbsp; In my own, I added additional optional parameters so that I can call safeinclude to see if a file exists without actually including it (to take advantage of my path/etc preprocessing, verses just calling the file exists function).<br /><br />Pretty simple approach that I could not find anywhere online; only other approach I could find was using PHP's eval().</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120750">  <div class="votes">
    <div id="Vu120750">
    <a href="/manual/vote-note.php?id=120750&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120750">
    <a href="/manual/vote-note.php?id=120750&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120750" title="66% like this...">
    5
    </div>
  </div>
  <a href="#120750" class="name">
  <strong class="user"><em>dexen dot devries at gmail dot com</em></strong></a><a class="genanchor" href="#120750"> &para;</a><div class="date" title="2017-03-06 03:54"><strong>9 months ago</strong></div>
  <div class="text" id="Hcom120750">
<div class="phpcode"><code><span class="html">
If you have a static variable in a method of a class, all DIRECT instances of that class share that one static variable.<br /><br />However if you create a derived class, all DIRECT instances of that derived class will share one, but DISTINCT, copy of that static variable in method.<br /><br />To put it the other way around, a static variable in a method is bound to a class (not to instance). Each subclass has own copy of that variable, to be shared among its instances.<br /><br />To put it yet another way around, when you create a derived class, it 'seems&nbsp; to' create a copy of methods from the base class, and thusly create copy of the static variables in those methods.<br /><br />Tested with PHP 7.0.16.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">require </span><span class="string">'libs.php'</span><span class="keyword">;<br />require </span><span class="string">'setup.php'</span><span class="keyword">;<br /><br />class </span><span class="default">Base </span><span class="keyword">{<br />&nbsp; &nbsp; function </span><span class="default">test</span><span class="keyword">(</span><span class="default">$delta </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; static </span><span class="default">$v </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$v </span><span class="keyword">+= </span><span class="default">$delta</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$v</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">Derived </span><span class="keyword">extends </span><span class="default">Base </span><span class="keyword">{}<br /><br /></span><span class="default">$base1 </span><span class="keyword">= new </span><span class="default">Base</span><span class="keyword">();<br /></span><span class="default">$base2 </span><span class="keyword">= new </span><span class="default">Base</span><span class="keyword">();<br /></span><span class="default">$derived1 </span><span class="keyword">= new </span><span class="default">Derived</span><span class="keyword">();<br /></span><span class="default">$derived2 </span><span class="keyword">= new </span><span class="default">Derived</span><span class="keyword">();<br /><br /></span><span class="default">$base1</span><span class="keyword">-&gt;</span><span class="default">test</span><span class="keyword">(</span><span class="default">3</span><span class="keyword">);<br /></span><span class="default">$base2</span><span class="keyword">-&gt;</span><span class="default">test</span><span class="keyword">(</span><span class="default">4</span><span class="keyword">);<br /></span><span class="default">$derived1</span><span class="keyword">-&gt;</span><span class="default">test</span><span class="keyword">(</span><span class="default">5</span><span class="keyword">);<br /></span><span class="default">$derived2</span><span class="keyword">-&gt;</span><span class="default">test</span><span class="keyword">(</span><span class="default">6</span><span class="keyword">);<br /><br /></span><span class="default">var_dump</span><span class="keyword">([ </span><span class="default">$base1</span><span class="keyword">-&gt;</span><span class="default">test</span><span class="keyword">(), </span><span class="default">$base2</span><span class="keyword">-&gt;</span><span class="default">test</span><span class="keyword">(), </span><span class="default">$derived1</span><span class="keyword">-&gt;</span><span class="default">test</span><span class="keyword">(), </span><span class="default">$derived2</span><span class="keyword">-&gt;</span><span class="default">test</span><span class="keyword">() ]);<br /><br /></span><span class="comment"># =&gt; array(4) { [0]=&gt; int(7) [1]=&gt; int(7) [2]=&gt; int(11) [3]=&gt; int(11) }<br /><br /># $base1 and $base2 share one copy of static variable $v<br /># derived1 and $derived2 share another copy of static variable $v</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="109310">  <div class="votes">
    <div id="Vu109310">
    <a href="/manual/vote-note.php?id=109310&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd109310">
    <a href="/manual/vote-note.php?id=109310&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V109310" title="65% like this...">
    10
    </div>
  </div>
  <a href="#109310" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#109310"> &para;</a><div class="date" title="2012-07-04 11:54"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom109310">
<div class="phpcode"><code><span class="html">
It will be obvious for most of you: changing value of a static in one instance changes value in all instances.<br /><br /><span class="default">&lt;?php<br /><br />&nbsp; &nbsp; </span><span class="keyword">class </span><span class="default">example </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; public static </span><span class="default">$s </span><span class="keyword">= </span><span class="string">'unchanged'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; public function </span><span class="default">set</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">::</span><span class="default">$s </span><span class="keyword">= </span><span class="string">'changed'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="default">$o </span><span class="keyword">= new </span><span class="default">example</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$p </span><span class="keyword">= new </span><span class="default">example</span><span class="keyword">;<br /><br />&nbsp; &nbsp; </span><span class="default">$o</span><span class="keyword">-&gt;</span><span class="default">set</span><span class="keyword">();<br /><br />&nbsp; &nbsp; print </span><span class="string">"</span><span class="default">$o</span><span class="string"> static: </span><span class="keyword">{</span><span class="default">$o</span><span class="keyword">::</span><span class="default">$i</span><span class="keyword">}</span><span class="string">\n</span><span class="default">$p</span><span class="string"> static: </span><span class="keyword">{</span><span class="default">$p</span><span class="keyword">::</span><span class="default">$i</span><span class="keyword">}</span><span class="string">"</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;<br /></span><br />Output will be:<br /><br />$o static: changed<br />$p static: changed</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120112">  <div class="votes">
    <div id="Vu120112">
    <a href="/manual/vote-note.php?id=120112&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120112">
    <a href="/manual/vote-note.php?id=120112&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120112" title="66% like this...">
    2
    </div>
  </div>
  <a href="#120112" class="name">
  <strong class="user"><em>simon dot barotte at gmail dot com</em></strong></a><a class="genanchor" href="#120112"> &para;</a><div class="date" title="2016-11-03 10:46"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom120112">
<div class="phpcode"><code><span class="html">
To be vigilant, unlike Java or C++, variables declared inside blocks such as loops (for, while,...) or if's, will also be recognized and accessible outside of the block, the only valid block is the BLOCK function so:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">for(</span><span class="default">$j</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">; </span><span class="default">$j</span><span class="keyword">&lt;</span><span class="default">5</span><span class="keyword">; </span><span class="default">$j</span><span class="keyword">++)<br />{<br />&nbsp; &nbsp;&nbsp; if(</span><span class="default">$j </span><span class="keyword">== </span><span class="default">1</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$a </span><span class="keyword">= </span><span class="default">6</span><span class="keyword">;<br />&nbsp; &nbsp;&nbsp; }<br />}<br /><br />echo </span><span class="default">$a</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />Would print 6.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118666">  <div class="votes">
    <div id="Vu118666">
    <a href="/manual/vote-note.php?id=118666&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118666">
    <a href="/manual/vote-note.php?id=118666&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118666" title="63% like this...">
    3
    </div>
  </div>
  <a href="#118666" class="name">
  <strong class="user"><em>gried at NOSPAM dot nsys dot by</em></strong></a><a class="genanchor" href="#118666"> &para;</a><div class="date" title="2016-01-16 09:12"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom118666">
<div class="phpcode"><code><span class="html">
In fact all variables represent pointers that hold address of memory area with data that was assigned to this variable. When you assign some variable value by reference you in fact write address of source variable to recepient variable. Same happens when you declare some variable as global in function, it receives same address as global variable outside of function. If you consider forementioned explanation it's obvious that mixing usage of same variable declared with keyword global and via superglobal array at the same time is very bad idea. In some cases they can point to different memory areas, giving you headache. Consider code below:<br /><br /><span class="default">&lt;?php<br /><br />error_reporting</span><span class="keyword">(</span><span class="default">E_ALL</span><span class="keyword">);<br /><br /></span><span class="default">$GLOB </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br /><br />function </span><span class="default">test_references</span><span class="keyword">() {<br />&nbsp; &nbsp; global </span><span class="default">$GLOB</span><span class="keyword">; </span><span class="comment">// get reference to global variable using keyword global, at this point local variable $GLOB points to same address as global variable $GLOB<br />&nbsp; &nbsp; </span><span class="default">$test </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">; </span><span class="comment">// declare some local var<br />&nbsp; &nbsp; </span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">'GLOB'</span><span class="keyword">] = &amp;</span><span class="default">$test</span><span class="keyword">; </span><span class="comment">// make global variable reference to this local variable using superglobal array, at this point global variable $GLOB points to new memory address, same as local variable $test<br /><br />&nbsp; &nbsp; </span><span class="default">$GLOB </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">; </span><span class="comment">// set new value to global variable via earlier set local representation, write to old address<br /><br />&nbsp; &nbsp; </span><span class="keyword">echo </span><span class="string">"Value of global variable (via local representation set by keyword global): </span><span class="default">$GLOB</span><span class="string"> &lt;hr&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="comment">// check global variable via local representation =&gt; 2 (OK, got value that was just written to it, cause old address was used to get value) <br /><br />&nbsp; &nbsp; </span><span class="keyword">echo </span><span class="string">"Value of global variable (via superglobal array GLOBALS): </span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="default">GLOB</span><span class="keyword">]</span><span class="string"> &lt;hr&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="comment">// check global variable using superglobal array =&gt; 1 (got value of local variable $test, new address was used)<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="keyword">echo </span><span class="string">"Value ol local variable \$test: </span><span class="default">$test</span><span class="string"> &lt;hr&gt;"</span><span class="keyword">; <br />&nbsp; &nbsp; </span><span class="comment">// check local variable that was linked with global using superglobal array =&gt; 1 (its value was not affected)<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="keyword">global </span><span class="default">$GLOB</span><span class="keyword">; </span><span class="comment">// update reference to global variable using keyword global, at this point we update address that held in local variable $GLOB and it gets same address as local variable $test<br />&nbsp; &nbsp; </span><span class="keyword">echo </span><span class="string">"Value of global variable (via updated local representation set by keyword global): </span><span class="default">$GLOB</span><span class="string"> &lt;hr&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="comment">// check global variable via local representation =&gt; 1 (also value of local variable $test, new address was used) <br /></span><span class="keyword">}<br /><br /></span><span class="default">test_references</span><span class="keyword">();<br />echo </span><span class="string">"Value of global variable outside of function: </span><span class="default">$GLOB</span><span class="string"> &lt;hr&gt;"</span><span class="keyword">;<br /></span><span class="comment">// check global variable outside function =&gt; 1 (equal to value of local variable $test from function, global variable also points to new address)<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="100884">  <div class="votes">
    <div id="Vu100884">
    <a href="/manual/vote-note.php?id=100884&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd100884">
    <a href="/manual/vote-note.php?id=100884&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V100884" title="62% like this...">
    9
    </div>
  </div>
  <a href="#100884" class="name">
  <strong class="user"><em>php at keith tyler dot com</em></strong></a><a class="genanchor" href="#100884"> &para;</a><div class="date" title="2010-11-12 10:37"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom100884">
<div class="phpcode"><code><span class="html">
Sometimes a variable available in global scope is not accessible via the 'global' keyword or the $GLOBALS superglobal array. I have not been able to replicate it in original code, but it occurs when a script is run under PHPUnit.<br /><br />PHPUnit provides a variable "$filename" that reflects the name of the file loaded on its command line. This is available in global scope, but not in object scope. For example, the following phpUnit script (call it GlobalScope.php):<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">print </span><span class="string">"Global scope FILENAME [</span><span class="default">$filename</span><span class="string">]\n"</span><span class="keyword">;<br />class </span><span class="default">MyTestClass </span><span class="keyword">extends </span><span class="default">PHPUnit_Framework_TestCase </span><span class="keyword">{<br />&nbsp; function </span><span class="default">testMyTest</span><span class="keyword">() {<br />&nbsp; &nbsp; global </span><span class="default">$filename</span><span class="keyword">;<br />&nbsp; &nbsp; print </span><span class="string">"Method scope global FILENAME [</span><span class="default">$filename</span><span class="string">]\n"</span><span class="keyword">;<br />&nbsp; &nbsp; print </span><span class="string">"Method scope GLOBALS[FILENAME] ["</span><span class="keyword">.</span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">"filename"</span><span class="keyword">].</span><span class="string">"]\n"</span><span class="keyword">;<br />&nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />If you run this script via "phpunit GlobalScope.php", you will get:<br /><br />Global scope FILENAME [/home/ktyler/GlobalScope.php]<br />PHPUnit 3.4.5 by Sebastian Bergmann.<br /><br />Method scope global FILENAME []<br />Method scope GLOBALS[FILENAME] []<br />.<br /><br />You have to -- strange as it seems -- do the following:<br /><br /><span class="default">&lt;?php<br />$GLOBALS</span><span class="keyword">[</span><span class="string">"filename"</span><span class="keyword">]=</span><span class="default">$filename</span><span class="keyword">;<br />print </span><span class="string">"Global scope FILENAME [</span><span class="default">$filename</span><span class="string">]\n"</span><span class="keyword">;<br />class </span><span class="default">MyTestClass </span><span class="keyword">extends </span><span class="default">PHPUnit_Framework_TestCase </span><span class="keyword">{<br />&nbsp; function </span><span class="default">testMyTest</span><span class="keyword">() {<br />&nbsp; &nbsp; global </span><span class="default">$filename</span><span class="keyword">;<br />&nbsp; &nbsp; print </span><span class="string">"Method scope global FILENAME [</span><span class="default">$filename</span><span class="string">]\n"</span><span class="keyword">;<br />&nbsp; &nbsp; print </span><span class="string">"Method scope GLOBALS[FILENAME] ["</span><span class="keyword">.</span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">"filename"</span><span class="keyword">].</span><span class="string">"]\n"</span><span class="keyword">;<br />&nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />By doing this, both "global" and $GLOBALS work!<br /><br />I don't know what it is that PHPUnit does (I know it uses Reflection) that causes a globally available variable to be implicitly unavailable via "global" or $GLOBALS. But there it is.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="42955">  <div class="votes">
    <div id="Vu42955">
    <a href="/manual/vote-note.php?id=42955&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd42955">
    <a href="/manual/vote-note.php?id=42955&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V42955" title="64% like this...">
    7
    </div>
  </div>
  <a href="#42955" class="name">
  <strong class="user"><em>Michael Bailey (jinxidoru at byu dot net)</em></strong></a><a class="genanchor" href="#42955"> &para;</a><div class="date" title="2004-06-04 11:43"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom42955">
<div class="phpcode"><code><span class="html">
Static variables do not hold through inheritance.&nbsp; Let class A have a function Z with a static variable.&nbsp; Let class B extend class A in which function Z is not overwritten.&nbsp; Two static variables will be created, one for class A and one for class B.<br /><br />Look at this example:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">A </span><span class="keyword">{<br />&nbsp; &nbsp; function </span><span class="default">Z</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; static </span><span class="default">$count </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">printf</span><span class="keyword">(</span><span class="string">"%s: %d\n"</span><span class="keyword">, </span><span class="default">get_class</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">), ++</span><span class="default">$count</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />}<br /><br />class </span><span class="default">B </span><span class="keyword">extends </span><span class="default">A </span><span class="keyword">{}<br /><br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">();<br /></span><span class="default">$b </span><span class="keyword">= new </span><span class="default">B</span><span class="keyword">();<br /></span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">Z</span><span class="keyword">();<br /></span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">Z</span><span class="keyword">();<br /></span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">Z</span><span class="keyword">();<br /></span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">Z</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span><br />This code returns:<br /><br />A: 1<br />A: 2<br />B: 1<br />A: 3<br /><br />As you can see, class A and B are using different static variables even though the same function was being used.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="14251">  <div class="votes">
    <div id="Vu14251">
    <a href="/manual/vote-note.php?id=14251&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd14251">
    <a href="/manual/vote-note.php?id=14251&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V14251" title="64% like this...">
    5
    </div>
  </div>
  <a href="#14251" class="name">
  <strong class="user"><em>danno at wpi dot edu</em></strong></a><a class="genanchor" href="#14251"> &para;</a><div class="date" title="2001-07-24 12:28"><strong>16 years ago</strong></div>
  <div class="text" id="Hcom14251">
<div class="phpcode"><code><span class="html">
WARNING!&nbsp; If you create a local variable in a function and then within that function assign it to a global variable by reference the object will be destroyed when the function exits and the global var will contain NOTHING!&nbsp; This main sound obvious but it can be quite tricky you have a large script (like a phpgtk-based gui app ;-) ).<br /><br />example:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">foo </span><span class="keyword">()<br />{<br />&nbsp;&nbsp; global </span><span class="default">$testvar</span><span class="keyword">;<br /><br />&nbsp;&nbsp; </span><span class="default">$localvar </span><span class="keyword">= new </span><span class="default">Object </span><span class="keyword">();<br />&nbsp;&nbsp; </span><span class="default">$testvar </span><span class="keyword">= &amp;</span><span class="default">$localvar</span><span class="keyword">;<br />}<br /><br /></span><span class="default">foo </span><span class="keyword">();<br /></span><span class="default">print_r </span><span class="keyword">(</span><span class="default">$testvar</span><span class="keyword">);&nbsp;&nbsp; </span><span class="comment">// produces NOTHING!!!!<br /></span><span class="default">?&gt;<br /></span><br />hope this helps someone before they lose all their hair</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113913">  <div class="votes">
    <div id="Vu113913">
    <a href="/manual/vote-note.php?id=113913&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113913">
    <a href="/manual/vote-note.php?id=113913&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113913" title="61% like this...">
    5
    </div>
  </div>
  <a href="#113913" class="name">
  <strong class="user"><em>Jonathan Kenigson</em></strong></a><a class="genanchor" href="#113913"> &para;</a><div class="date" title="2013-12-16 11:09"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom113913">
<div class="phpcode"><code><span class="html">
Just a note about static properties declared at class level:<br /><br />class Test_Class {<br />&nbsp; static $a = 0;<br />&nbsp; public function ReturnVar(){<br />&nbsp; &nbsp; return $this-&gt;a;<br />&nbsp; }<br />&nbsp; }<br />&nbsp; $b = new Test_Class();<br />&nbsp; echo $b-&gt;ReturnVar();<br /><br />Will not output "0"&nbsp; because $a is declared static. Changing "static" to "public" or "private" will produce the output "0".</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117267">  <div class="votes">
    <div id="Vu117267">
    <a href="/manual/vote-note.php?id=117267&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117267">
    <a href="/manual/vote-note.php?id=117267&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117267" title="61% like this...">
    4
    </div>
  </div>
  <a href="#117267" class="name">
  <strong class="user"><em>zweibieren at yahoo dot com</em></strong></a><a class="genanchor" href="#117267"> &para;</a><div class="date" title="2015-05-12 06:32"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117267">
<div class="phpcode"><code><span class="html">
Take to heart this hard-won rule:<br />&nbsp; &nbsp; &nbsp; &nbsp; Declare AT THE TOP any variable that is to be global. <br />&nbsp; &nbsp; &nbsp; &nbsp; Both at the top of the FILE <br />&nbsp; &nbsp; &nbsp; &nbsp; AND at the top of any FUNCTION where it appears.<br /><br />Why AT THE TOP? So it is sure to be declared before use. Otherwise a non-global version of the variable will be created and your code will fail.<br /><br />Why at the top of a FUNCTION? Because otherwise the function will refer only to its local version of the variable and your code will fail.<br /><br />Why at the top of the FILE? Because someday--a day that you cannot now imagine--you will want to "include" the file. And when you do, instances of the variable outside functions will not go in the global scope and your code will fail. (When the "include" is inside a calling function, variables in the included file go into the scope of the calling function.)<br /> <br />Example file where variable $x is used outside and inside functions:<br />&nbsp; &nbsp; |&lt;!DOCTYPE html ...&gt;<br />&nbsp; &nbsp; |&lt;html xmlns ...&gt;<br />&nbsp; &nbsp; |&nbsp; &nbsp; <span class="default">&lt;?php </span><span class="keyword">global </span><span class="default">$x</span><span class="keyword">; </span><span class="default">?&gt;<br /></span>&nbsp; &nbsp; |&lt;head&gt; <br />&nbsp; &nbsp; |&nbsp; &nbsp; Some html headers<br />&nbsp; &nbsp; |&nbsp; &nbsp; <span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">|&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$x </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; |&nbsp; &nbsp; &nbsp; &nbsp; function </span><span class="default">bump_x</span><span class="keyword">() {<br />&nbsp; &nbsp; |&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; global </span><span class="default">$x</span><span class="keyword">;<br />&nbsp; &nbsp; |&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$x </span><span class="keyword">+= </span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; |&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; |&nbsp; &nbsp; </span><span class="default">?&gt;<br /></span>&nbsp; &nbsp; |&lt;/head&gt;<br />&nbsp; &nbsp; |&lt;body&gt;<br />&nbsp; &nbsp; |&nbsp; &nbsp; More html <br />&nbsp; &nbsp; |&nbsp; &nbsp; <span class="default">&lt;?php </span><span class="keyword">echo </span><span class="default">$x</span><span class="keyword">; </span><span class="default">bump_x</span><span class="keyword">(); </span><span class="default">?&gt;<br /></span>&nbsp; &nbsp; |&nbsp; &nbsp; Yet more html.<br />&nbsp; &nbsp; |&lt;/body&gt;<br />&lt;/html&gt;</span>
</code></div>
  </div>
 </div>
  <div class="note" id="100312">  <div class="votes">
    <div id="Vu100312">
    <a href="/manual/vote-note.php?id=100312&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd100312">
    <a href="/manual/vote-note.php?id=100312&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V100312" title="61% like this...">
    4
    </div>
  </div>
  <a href="#100312" class="name">
  <strong class="user"><em>eduardo dot ferron at zeion dot net</em></strong></a><a class="genanchor" href="#100312"> &para;</a><div class="date" title="2010-10-07 06:02"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom100312">
<div class="phpcode"><code><span class="html">
There're times when global variables comes in handy, like universal read only resources you just need to create once in your application and share to the rest of your scripts. But it may become quite hard to track with "variables".</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119913">  <div class="votes">
    <div id="Vu119913">
    <a href="/manual/vote-note.php?id=119913&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119913">
    <a href="/manual/vote-note.php?id=119913&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119913" title="60% like this...">
    2
    </div>
  </div>
  <a href="#119913" class="name">
  <strong class="user"><em>pogregoire##live.fr</em></strong></a><a class="genanchor" href="#119913"> &para;</a><div class="date" title="2016-09-19 03:36"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119913">
<div class="phpcode"><code><span class="html">
writing : global $var; is exactely the samething that writing : $var =&amp; $GLOBALS['var'];<br />It creates a reference on $GLOBALS['var'];<br /><br /><span class="default">&lt;?php<br />$var </span><span class="keyword">=</span><span class="default">1</span><span class="keyword">;<br />function </span><span class="default">teste_global</span><span class="keyword">(){<br />&nbsp; &nbsp; global </span><span class="default">$var</span><span class="keyword">;<br />&nbsp; &nbsp; for (</span><span class="default">$var</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">; </span><span class="default">$var</span><span class="keyword">&lt;</span><span class="default">5</span><span class="keyword">; </span><span class="default">$var</span><span class="keyword">++){<br /><br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">teste_global</span><span class="keyword">();<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">);</span><span class="comment">// return : int(5).<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="81506">  <div class="votes">
    <div id="Vu81506">
    <a href="/manual/vote-note.php?id=81506&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd81506">
    <a href="/manual/vote-note.php?id=81506&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V81506" title="60% like this...">
    6
    </div>
  </div>
  <a href="#81506" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#81506"> &para;</a><div class="date" title="2008-03-01 11:10"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom81506">
<div class="phpcode"><code><span class="html">
I was pondering a little something regarding caching classes within a function in order to prevent the need to initiate them multiple times and not clutter the caching function's class properties with more values.<br /><br />I came here because I remembered something about references being lost. So I made a test to see if I could pull what I wanted to off anyway. Here's and example of how to get around the references lost issue. I hope it is helpful to someone else!<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">test1</span><span class="keyword">{}<br />class </span><span class="default">test2</span><span class="keyword">{}<br />class </span><span class="default">test3</span><span class="keyword">{}<br /><br />function </span><span class="default">cache</span><span class="keyword">( </span><span class="default">$class </span><span class="keyword">)<br />{<br />&nbsp; &nbsp; static </span><span class="default">$loaders </span><span class="keyword">= array();<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="default">$loaders</span><span class="keyword">[ </span><span class="default">$class </span><span class="keyword">] = new </span><span class="default">$class</span><span class="keyword">();<br /><br />&nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">( </span><span class="default">$loaders </span><span class="keyword">);<br />}<br />print </span><span class="string">'&lt;pre&gt;'</span><span class="keyword">;<br /></span><span class="default">cache</span><span class="keyword">( </span><span class="string">'test1' </span><span class="keyword">);<br /></span><span class="default">cache</span><span class="keyword">( </span><span class="string">'test2' </span><span class="keyword">);<br /></span><span class="default">cache</span><span class="keyword">( </span><span class="string">'test3' </span><span class="keyword">);<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="41213">  <div class="votes">
    <div id="Vu41213">
    <a href="/manual/vote-note.php?id=41213&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd41213">
    <a href="/manual/vote-note.php?id=41213&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V41213" title="61% like this...">
    4
    </div>
  </div>
  <a href="#41213" class="name">
  <strong class="user"><em>Randolpho</em></strong></a><a class="genanchor" href="#41213"> &para;</a><div class="date" title="2004-04-02 12:53"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom41213">
<div class="phpcode"><code><span class="html">
More on static variables:<br /><br />A static variable does not retain it's value after the script's execution. Don't count on it being available from one page request to the next; you'll have to use a database for that. <br /><br />Second, here's a good pattern to use for declaring a static variable based on some complex logic:<br /><br /><span class="default">&lt;?php<br />&nbsp; </span><span class="keyword">function </span><span class="default">buildStaticVariable</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$foo </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; </span><span class="comment">// some complex expression or set of<br />&nbsp; &nbsp; &nbsp; // expressions/statements to build<br />&nbsp; &nbsp; &nbsp; // the return variable.<br />&nbsp; &nbsp; &nbsp; </span><span class="keyword">return </span><span class="default">$foo</span><span class="keyword">;<br />&nbsp; }<br /><br />&nbsp; function </span><span class="default">functionWhichUsesStaticVar</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; &nbsp; static </span><span class="default">$foo </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; if(</span><span class="default">$foo </span><span class="keyword">=== </span><span class="default">null</span><span class="keyword">) </span><span class="default">$foo </span><span class="keyword">= </span><span class="default">buildStaticVariable</span><span class="keyword">();<br />&nbsp; &nbsp; &nbsp; </span><span class="comment">// the rest of your code goes here.<br />&nbsp; </span><span class="keyword">}<br /></span><span class="default">?&gt;<br /></span><br />Using such a pattern allows you to separate the code that creates your default static variable value from the function that uses it. Easier to maintain code is good. :)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="92868">  <div class="votes">
    <div id="Vu92868">
    <a href="/manual/vote-note.php?id=92868&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd92868">
    <a href="/manual/vote-note.php?id=92868&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V92868" title="57% like this...">
    10
    </div>
  </div>
  <a href="#92868" class="name">
  <strong class="user"><em>Stephen Dewey</em></strong></a><a class="genanchor" href="#92868"> &para;</a><div class="date" title="2009-08-12 08:06"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom92868">
<div class="phpcode"><code><span class="html">
For nested functions:<br /><br />This is probably obvious to most people, but global always refers to the variable in the global (top level) variable of that name, not just a variable in a higher-level scope. So this will not work:<br /><span class="default">&lt;?php<br /><br /></span><span class="comment">// $var1 is not declared in the global scope<br /><br /></span><span class="keyword">function </span><span class="default">a</span><span class="keyword">(</span><span class="default">$var1</span><span class="keyword">){<br /><br />&nbsp; &nbsp; function </span><span class="default">b</span><span class="keyword">(){<br />&nbsp; &nbsp; &nbsp; &nbsp; global </span><span class="default">$var1</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">$var1</span><span class="keyword">; </span><span class="comment">// there is no var1 in the global scope so nothing to echo<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="keyword">}<br /><br />&nbsp; &nbsp; </span><span class="default">b</span><span class="keyword">();<br />}<br /><br /></span><span class="default">a</span><span class="keyword">(</span><span class="string">'hello'</span><span class="keyword">);<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="85203">  <div class="votes">
    <div id="Vu85203">
    <a href="/manual/vote-note.php?id=85203&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd85203">
    <a href="/manual/vote-note.php?id=85203&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V85203" title="59% like this...">
    5
    </div>
  </div>
  <a href="#85203" class="name">
  <strong class="user"><em>ddarjany at yahoo dot com</em></strong></a><a class="genanchor" href="#85203"> &para;</a><div class="date" title="2008-08-19 08:15"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom85203">
<div class="phpcode"><code><span class="html">
Note that if you declare a variable in a function, then set it as global in that function, its value will not be retained outside of that function.&nbsp; This was tripping me up for a while so I thought it would be worth noting.<br /><br /><span class="default">&lt;?PHP<br /><br />foo</span><span class="keyword">();<br />echo </span><span class="default">$a</span><span class="keyword">; </span><span class="comment">// echoes nothing<br /><br /></span><span class="default">bar</span><span class="keyword">();<br />echo </span><span class="default">$b</span><span class="keyword">; </span><span class="comment">//echoes "b";<br /><br /></span><span class="keyword">function </span><span class="default">foo</span><span class="keyword">() {<br />&nbsp; </span><span class="default">$a </span><span class="keyword">= </span><span class="string">"a"</span><span class="keyword">; <br />&nbsp; global </span><span class="default">$a</span><span class="keyword">;<br />}<br /><br />function </span><span class="default">bar</span><span class="keyword">() {<br />&nbsp; global </span><span class="default">$b</span><span class="keyword">;<br />&nbsp; </span><span class="default">$b </span><span class="keyword">= </span><span class="string">"b"</span><span class="keyword">;<br />}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113836">  <div class="votes">
    <div id="Vu113836">
    <a href="/manual/vote-note.php?id=113836&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113836">
    <a href="/manual/vote-note.php?id=113836&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113836" title="57% like this...">
    2
    </div>
  </div>
  <a href="#113836" class="name">
  <strong class="user"><em>Ray.Paseur often uses Gmail</em></strong></a><a class="genanchor" href="#113836"> &para;</a><div class="date" title="2013-12-06 04:32"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113836">
<div class="phpcode"><code><span class="html">
Variable "Visibility" in PHP Object Oriented Programming is documented here:<br /><a href="http://php.net/manual/en/language.oop5.visibility.php" rel="nofollow" target="_blank">http://php.net/manual/en/language.oop5.visibility.php</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="52343">  <div class="votes">
    <div id="Vu52343">
    <a href="/manual/vote-note.php?id=52343&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd52343">
    <a href="/manual/vote-note.php?id=52343&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V52343" title="58% like this...">
    2
    </div>
  </div>
  <a href="#52343" class="name">
  <strong class="user"><em>kouber at php dot net</em></strong></a><a class="genanchor" href="#52343"> &para;</a><div class="date" title="2005-04-28 05:36"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom52343">
<div class="phpcode"><code><span class="html">
If you need all your global variables available in a function, you can use this:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">foo</span><span class="keyword">() {<br />&nbsp; </span><span class="default">extract</span><span class="keyword">(</span><span class="default">$GLOBALS</span><span class="keyword">);<br />&nbsp; </span><span class="comment">// here you have all global variables<br /><br /></span><span class="keyword">}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="69611">  <div class="votes">
    <div id="Vu69611">
    <a href="/manual/vote-note.php?id=69611&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd69611">
    <a href="/manual/vote-note.php?id=69611&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V69611" title="57% like this...">
    2
    </div>
  </div>
  <a href="#69611" class="name">
  <strong class="user"><em>alan</em></strong></a><a class="genanchor" href="#69611"> &para;</a><div class="date" title="2006-09-12 10:53"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom69611">
<div class="phpcode"><code><span class="html">
Using the global keyword inside a function to define a variable is essentially the same as passing the variable by reference as a parameter:<br /><br /><span class="default">&lt;?php<br />somefunction</span><span class="keyword">(){<br />&nbsp;&nbsp; global </span><span class="default">$var</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />is the same as:<br /><br /><span class="default">&lt;?php<br />somefunction</span><span class="keyword">(&amp; </span><span class="default">$a</span><span class="keyword">) {<br /><br />}<br /></span><span class="default">?&gt;<br /></span><br />The advantage to using the keyword is if you have a long list of variables&nbsp; needed by the function - you dont have to pass them every time you call the function.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="99074">  <div class="votes">
    <div id="Vu99074">
    <a href="/manual/vote-note.php?id=99074&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd99074">
    <a href="/manual/vote-note.php?id=99074&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V99074" title="55% like this...">
    2
    </div>
  </div>
  <a href="#99074" class="name">
  <strong class="user"><em>pedro at worcel dot com</em></strong></a><a class="genanchor" href="#99074"> &para;</a><div class="date" title="2010-07-26 06:34"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom99074">
<div class="phpcode"><code><span class="html">
Another way of working with a large ammount of global variables could be the following.<br /><br /><span class="default">&lt;?php<br /><br />$var </span><span class="keyword">= </span><span class="string">"3"</span><span class="keyword">;<br /></span><span class="default">$smarty </span><span class="keyword">= new </span><span class="default">Smarty</span><span class="keyword">();<br /><br />function </span><span class="default">headers_set_404</span><span class="keyword">() {<br /></span><span class="default">extract</span><span class="keyword">(</span><span class="default">$globals</span><span class="keyword">);<br /><br />echo </span><span class="default">$var </span><span class="keyword">. </span><span class="string">"&lt;br /&gt;"</span><span class="keyword">;<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$smarty</span><span class="keyword">);<br /><br />return;<br /><br />}<br /><br /></span><span class="default">?&gt;<br /></span><br />Regards,<br />Droope</span>
</code></div>
  </div>
 </div>
  <div class="note" id="37183">  <div class="votes">
    <div id="Vu37183">
    <a href="/manual/vote-note.php?id=37183&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd37183">
    <a href="/manual/vote-note.php?id=37183&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V37183" title="57% like this...">
    1
    </div>
  </div>
  <a href="#37183" class="name">
  <strong class="user"><em>flobee at gmx dot net</em></strong></a><a class="genanchor" href="#37183"> &para;</a><div class="date" title="2003-11-06 12:26"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom37183">
<div class="phpcode"><code><span class="html">
i found out that on any (still not found) reason the <span class="default">&lt;?php </span><span class="keyword">static </span><span class="default">$val </span><span class="keyword">=</span><span class="default">NULL</span><span class="keyword">; </span><span class="default">?&gt;</span> is not working when trying to extract the data form the $var with a while statment<br />e.g.:<br /><span class="default">&lt;?php<br />funktion get_data</span><span class="keyword">() {<br />static </span><span class="default">$myarray </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br />&nbsp;&nbsp; if(</span><span class="default">$myarray </span><span class="keyword">== </span><span class="default">NULL</span><span class="keyword">) {<br />&nbsp; &nbsp;&nbsp; </span><span class="comment">//get some info in an array();<br />&nbsp; &nbsp;&nbsp; </span><span class="default">$myarray </span><span class="keyword">= array(</span><span class="string">'one'</span><span class="keyword">,</span><span class="string">'two'</span><span class="keyword">);<br />&nbsp;&nbsp; }<br />&nbsp;&nbsp; while(list(</span><span class="default">$key</span><span class="keyword">,</span><span class="default">$val</span><span class="keyword">) = </span><span class="default">each</span><span class="keyword">( </span><span class="default">$myarray </span><span class="keyword">) ) {<br />&nbsp;&nbsp; </span><span class="comment">// do something<br />&nbsp;&nbsp; </span><span class="keyword">echo </span><span class="string">"x: </span><span class="default">$key</span><span class="string"> , y: </span><span class="default">$val</span><span class="string">"</span><span class="keyword">;<br />&nbsp;&nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span>when using foreach($myarray AS $key =&gt; $val) { .... instad of while then i see the result!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="94259">  <div class="votes">
    <div id="Vu94259">
    <a href="/manual/vote-note.php?id=94259&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd94259">
    <a href="/manual/vote-note.php?id=94259&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V94259" title="55% like this...">
    2
    </div>
  </div>
  <a href="#94259" class="name">
  <strong class="user"><em>moraesdno at gmail dot com</em></strong></a><a class="genanchor" href="#94259"> &para;</a><div class="date" title="2009-10-25 05:17"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom94259">
<div class="phpcode"><code><span class="html">
Use the superglobal array $GLOBALS is faster than the global keyword. See:<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">//Using the keyword global<br /></span><span class="default">$a</span><span class="keyword">=</span><span class="default">1</span><span class="keyword">;<br /></span><span class="default">$b</span><span class="keyword">=</span><span class="default">2</span><span class="keyword">;<br />function </span><span class="default">sum</span><span class="keyword">() {<br />&nbsp; &nbsp; global </span><span class="default">$a</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$a </span><span class="keyword">+= </span><span class="default">$b</span><span class="keyword">;<br />}<br /><br /> </span><span class="default">$t </span><span class="keyword">= </span><span class="default">microtime</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">);<br /> for(</span><span class="default">$i</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">&lt;</span><span class="default">1000</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">++) {<br />&nbsp; &nbsp;&nbsp; </span><span class="default">sum</span><span class="keyword">();<br /> }<br /> echo </span><span class="default">microtime</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">)-</span><span class="default">$t</span><span class="keyword">;<br /> echo </span><span class="string">" -- "</span><span class="keyword">.</span><span class="default">$a</span><span class="keyword">.</span><span class="string">"&lt;br&gt;"</span><span class="keyword">;<br /><br /></span><span class="comment">//Using the superglobal array<br /></span><span class="default">$a</span><span class="keyword">=</span><span class="default">1</span><span class="keyword">;<br /></span><span class="default">$b</span><span class="keyword">=</span><span class="default">2</span><span class="keyword">;<br />function </span><span class="default">sum2</span><span class="keyword">() {<br />&nbsp; &nbsp; </span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">'a'</span><span class="keyword">] += </span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">'b'</span><span class="keyword">];<br />}<br /><br />&nbsp; </span><span class="default">$t </span><span class="keyword">= </span><span class="default">microtime</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">);<br /> for(</span><span class="default">$i</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">&lt;</span><span class="default">1000</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">++) {<br />&nbsp; &nbsp;&nbsp; </span><span class="default">sum2</span><span class="keyword">();<br /> }<br /> echo </span><span class="default">microtime</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">)-</span><span class="default">$t</span><span class="keyword">;<br /> echo </span><span class="string">" -- "</span><span class="keyword">.</span><span class="default">$a</span><span class="keyword">.</span><span class="string">"&lt;br&gt;"</span><span class="keyword">;<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="56749">  <div class="votes">
    <div id="Vu56749">
    <a href="/manual/vote-note.php?id=56749&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd56749">
    <a href="/manual/vote-note.php?id=56749&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V56749" title="56% like this...">
    2
    </div>
  </div>
  <a href="#56749" class="name">
  <strong class="user"><em>tc underline at gmx TLD ch</em></strong></a><a class="genanchor" href="#56749"> &para;</a><div class="date" title="2005-09-14 03:06"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom56749">
<div class="phpcode"><code><span class="html">
Pay attention while unsetting variables inside functions:<br /><br /><span class="default">&lt;?php<br />$a </span><span class="keyword">= </span><span class="string">"1234"</span><span class="keyword">;<br />echo </span><span class="string">"&lt;pre&gt;"</span><span class="keyword">;<br />echo </span><span class="string">"outer: </span><span class="default">$a</span><span class="string">\n"</span><span class="keyword">;<br />function </span><span class="default">testa</span><span class="keyword">()<br />{<br />&nbsp; &nbsp; global </span><span class="default">$a</span><span class="keyword">;<br />&nbsp; &nbsp; echo </span><span class="string">"&nbsp;&nbsp; inner testa: </span><span class="default">$a</span><span class="string">\n"</span><span class="keyword">;<br />&nbsp; &nbsp; unset (</span><span class="default">$a</span><span class="keyword">);<br />&nbsp; &nbsp; echo </span><span class="string">"&nbsp;&nbsp; inner testa: </span><span class="default">$a</span><span class="string">\n"</span><span class="keyword">;<br />}<br />function </span><span class="default">testb</span><span class="keyword">()<br />{<br />&nbsp; &nbsp; global </span><span class="default">$a</span><span class="keyword">;<br />&nbsp; &nbsp; echo </span><span class="string">"&nbsp;&nbsp; inner testb: </span><span class="default">$a</span><span class="string">\n"</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$a </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; echo </span><span class="string">"&nbsp;&nbsp; inner testb: </span><span class="default">$a</span><span class="string">\n"</span><span class="keyword">;<br />}<br /></span><span class="default">testa</span><span class="keyword">();<br />echo </span><span class="string">"outer: </span><span class="default">$a</span><span class="string">\n"</span><span class="keyword">;<br /></span><span class="default">testb</span><span class="keyword">();<br />echo </span><span class="string">"outer: </span><span class="default">$a</span><span class="string">\n"</span><span class="keyword">;<br />echo </span><span class="string">"&lt;/pre&gt;"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />/***** Result:<br />outer: 1234<br />&nbsp;&nbsp; inner testa: 1234<br />&nbsp;&nbsp; inner testa: <br />outer: 1234<br />&nbsp;&nbsp; inner testb: 1234<br />&nbsp;&nbsp; inner testb: <br />outer: <br />******/<br /><br />Took me 1 hour to find out why my variable was still there after unsetting it ...<br /><br />Thomas Candrian</span>
</code></div>
  </div>
 </div>
  <div class="note" id="55595">  <div class="votes">
    <div id="Vu55595">
    <a href="/manual/vote-note.php?id=55595&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd55595">
    <a href="/manual/vote-note.php?id=55595&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V55595" title="54% like this...">
    1
    </div>
  </div>
  <a href="#55595" class="name">
  <strong class="user"><em>thomas at pixtur dot de</em></strong></a><a class="genanchor" href="#55595"> &para;</a><div class="date" title="2005-08-08 08:02"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom55595">
<div class="phpcode"><code><span class="html">
Be careful with "require", "require_once" and "include" inside functions. Even if the included file seems to define global variables, they might not be defined as such.<br /><br />consider those two files:<br /><br />---index.php------------------------------<br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">foo</span><span class="keyword">() {<br /> require_once(</span><span class="string">"class_person.inc"</span><span class="keyword">);<br /><br /> </span><span class="default">$person</span><span class="keyword">= new </span><span class="default">Person</span><span class="keyword">();<br /> echo </span><span class="default">$person</span><span class="keyword">-&gt;</span><span class="default">my_flag</span><span class="keyword">; </span><span class="comment">// should be true, but is undefined<br /></span><span class="keyword">}<br /><br /></span><span class="default">foo</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span><br />---class_person.inc----------------------------<br /><span class="default">&lt;?php<br />$seems_global</span><span class="keyword">=</span><span class="default">true</span><span class="keyword">;<br /><br />class </span><span class="default">Person </span><span class="keyword">{<br />&nbsp; public </span><span class="default">$my_flag</span><span class="keyword">;<br /><br /> public function&nbsp; </span><span class="default">__construct</span><span class="keyword">() {<br />&nbsp;&nbsp; global </span><span class="default">$seems_global</span><span class="keyword">;<br />&nbsp;&nbsp; </span><span class="default">$my_flag</span><span class="keyword">= </span><span class="default">$seems_global<br /> </span><span class="keyword">}<br />}<br /></span><span class="default">?&gt;<br /></span><br />---------------------------------<br /><br />The reason for this behavior is quiet obvious, once you figured it out. Sadly this might not be always as easy as in this example. A solution&nbsp; would be to add the line...<br /><br /><span class="default">&lt;?php </span><span class="keyword">global </span><span class="default">$seems_global</span><span class="keyword">; </span><span class="default">?&gt;<br /></span><br />at the beginning of "class_person.inc". That makes sure you set the global-var.<br /><br />&nbsp;&nbsp; best regards<br />&nbsp; &nbsp; tom<br /><br />ps: bug search time approx. 1 hour.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="53915">  <div class="votes">
    <div id="Vu53915">
    <a href="/manual/vote-note.php?id=53915&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd53915">
    <a href="/manual/vote-note.php?id=53915&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V53915" title="54% like this...">
    1
    </div>
  </div>
  <a href="#53915" class="name">
  <strong class="user"><em>jameslee at cs dot nmt dot edu</em></strong></a><a class="genanchor" href="#53915"> &para;</a><div class="date" title="2005-06-16 02:33"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom53915">
<div class="phpcode"><code><span class="html">
It should be noted that a static variable inside a method is static across all instances of that class, i.e., all objects of that class share the same static variable.&nbsp; For example the code:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">test </span><span class="keyword">{<br />&nbsp; &nbsp; function </span><span class="default">z</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; static </span><span class="default">$n </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$n</span><span class="keyword">++;<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$n</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$a </span><span class="keyword">=&amp; new </span><span class="default">test</span><span class="keyword">();<br /></span><span class="default">$b </span><span class="keyword">=&amp; new </span><span class="default">test</span><span class="keyword">();<br />print </span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">z</span><span class="keyword">();&nbsp; </span><span class="comment">// prints 1, as it should<br /></span><span class="keyword">print </span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">z</span><span class="keyword">();&nbsp; </span><span class="comment">// prints 2 because $a and $b have the same $n<br /></span><span class="default">?&gt;<br /></span><br />somewhat unexpectedly prints:<br />1<br />2</span>
</code></div>
  </div>
 </div>
  <div class="note" id="18748">  <div class="votes">
    <div id="Vu18748">
    <a href="/manual/vote-note.php?id=18748&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd18748">
    <a href="/manual/vote-note.php?id=18748&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V18748" title="53% like this...">
    1
    </div>
  </div>
  <a href="#18748" class="name">
  <strong class="user"><em>admin at essentialhost dot com</em></strong></a><a class="genanchor" href="#18748"> &para;</a><div class="date" title="2002-02-03 06:30"><strong>15 years ago</strong></div>
  <div class="text" id="Hcom18748">
<div class="phpcode"><code><span class="html">
Quick tip for beginners just to speed things up:<br />If you have a bunch of global variables to import into a function, it's best to put them into a named array like $variables[stuff].<br />When it's time to import them you just so the following;<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">here</span><span class="keyword">() { <br />&nbsp; </span><span class="default">$vars </span><span class="keyword">= </span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">'variables'</span><span class="keyword">]; <br />&nbsp; print </span><span class="default">$vars</span><span class="keyword">[</span><span class="default">stuff</span><span class="keyword">];<br /><br />}<br /></span><span class="default">?&gt;<br /></span><br />This really helps with big ugly form submissions.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="98577">  <div class="votes">
    <div id="Vu98577">
    <a href="/manual/vote-note.php?id=98577&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd98577">
    <a href="/manual/vote-note.php?id=98577&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V98577" title="52% like this...">
    1
    </div>
  </div>
  <a href="#98577" class="name">
  <strong class="user"><em>jakub dot lopuszanski at nasza-klasa dot pl</em></strong></a><a class="genanchor" href="#98577"> &para;</a><div class="date" title="2010-06-24 02:59"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom98577">
<div class="phpcode"><code><span class="html">
If you use __autoload function to load classes' definitons, beware that "static local variables are resolved at compile time" (whatever it really means) and the order in which autoloads occur may impact the semantic.<br /><br />For example if you have:<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Singleton</span><span class="keyword">{<br />&nbsp; static public function </span><span class="default">get_instance</span><span class="keyword">(){<br />&nbsp; &nbsp;&nbsp; static </span><span class="default">$instance </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp;&nbsp; if(</span><span class="default">$instance </span><span class="keyword">=== </span><span class="default">null</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$instance </span><span class="keyword">= new static();<br />&nbsp; &nbsp;&nbsp; }<br />&nbsp; &nbsp;&nbsp; return </span><span class="default">$instance</span><span class="keyword">;<br />&nbsp; }<br />}<br /></span><span class="default">?&gt;<br /></span><br />and two separate files A.php and B.php:<br />class A extends Singleton{}<br />class B extends A{}<br /><br />then depending on the order in which you access those two classes, and consequently, the order in which __autoload includes them, you can get strange results of calling B::get_instance() and A::get_instance().<br /><br />It seems that static local variables are alocated in as many copies as there are classes that inherit a method at the time of inclusion of parsing Singleton.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="122018">  <div class="votes">
    <div id="Vu122018">
    <a href="/manual/vote-note.php?id=122018&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd122018">
    <a href="/manual/vote-note.php?id=122018&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V122018" title="no votes...">
    0
    </div>
  </div>
  <a href="#122018" class="name">
  <strong class="user"><em>jordan at brownboots dot com</em></strong></a><a class="genanchor" href="#122018"> &para;</a><div class="date" title="2017-12-13 10:59"><strong>1 day ago</strong></div>
  <div class="text" id="Hcom122018">
<div class="phpcode"><code><span class="html">
Using $GLOBALS inside a function you can override all references to global variables in that function with variables passed into the function as arguments. This is useful when a function does stuff to a global object but you sometimes want it to do that stuff to a different object, and you don't want to rewrite any code.<br /><br />For example, suppose there's a global object called $user that refers to the currently-logged-in user and a function that does stuff to that user object:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">example_function</span><span class="keyword">() {<br />&nbsp; global </span><span class="default">$user</span><span class="keyword">;<br /><br />&nbsp; </span><span class="comment">// do stuff with the object<br />&nbsp; </span><span class="keyword">echo </span><span class="default">$user</span><span class="keyword">-&gt;</span><span class="default">id</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />Here's how you can make that function optionally do stuff to a different user object:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">example_function</span><span class="keyword">(&amp;</span><span class="default">$user </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">) {<br />&nbsp; if(!isset(</span><span class="default">$user</span><span class="keyword">)) {&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="comment">// if the function argument isn't provided, ...<br />&nbsp; &nbsp; </span><span class="default">$user </span><span class="keyword">= </span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">'user'</span><span class="keyword">];&nbsp;&nbsp; </span><span class="comment">// ... use the global variable<br />&nbsp; </span><span class="keyword">}<br /><br />&nbsp; </span><span class="comment">// do stuff with the object<br />&nbsp; </span><span class="keyword">echo </span><span class="default">$user</span><span class="keyword">-&gt;</span><span class="default">id</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />Example usage:<br /><br /><span class="default">&lt;?php<br />example_function</span><span class="keyword">();&nbsp; </span><span class="comment">// this will print the logged-in user's ID<br /><br /></span><span class="default">$test_user </span><span class="keyword">= </span><span class="default">load_user_by_id</span><span class="keyword">(</span><span class="default">1453</span><span class="keyword">);<br /><br /></span><span class="default">example_function</span><span class="keyword">(</span><span class="default">$test_user</span><span class="keyword">); </span><span class="comment">// this will print 1453<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121882">  <div class="votes">
    <div id="Vu121882">
    <a href="/manual/vote-note.php?id=121882&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121882">
    <a href="/manual/vote-note.php?id=121882&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121882" title="no votes...">
    0
    </div>
  </div>
  <a href="#121882" class="name">
  <strong class="user"><em>Hayley Watson</em></strong></a><a class="genanchor" href="#121882"> &para;</a><div class="date" title="2017-11-18 10:05"><strong>26 days ago</strong></div>
  <div class="text" id="Hcom121882">
<div class="phpcode"><code><span class="html">
static variables are implicitly initialised to NULL if no explicit initialisation is made.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">foo</span><span class="keyword">()<br />{<br />&nbsp; static </span><span class="default">$v</span><span class="keyword">;<br />&nbsp; echo </span><span class="default">gettype</span><span class="keyword">(</span><span class="default">$v</span><span class="keyword">);<br />}<br /><br /></span><span class="default">foo</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span><br />will echo NULL without complaining that $v is undefined.<br /><br />In short: "static $v;" is equivalent to "static $v = null;".</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121398">  <div class="votes">
    <div id="Vu121398">
    <a href="/manual/vote-note.php?id=121398&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121398">
    <a href="/manual/vote-note.php?id=121398&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121398" title="no votes...">
    0
    </div>
  </div>
  <a href="#121398" class="name">
  <strong class="user"><em>Semyon Naitur</em></strong></a><a class="genanchor" href="#121398"> &para;</a><div class="date" title="2017-07-19 09:12"><strong>4 months ago</strong></div>
  <div class="text" id="Hcom121398">
<div class="phpcode"><code><span class="html">
function f(){<br />&nbsp; &nbsp; global $a; // global $a is declared, local reference is created<br />&nbsp; &nbsp; $a = 'a';&nbsp; // global $a is set<br />&nbsp; &nbsp; unset($a); // local reference is unset, global $a remains set<br />&nbsp; &nbsp; $a = 'b';&nbsp; // local $a is declared and set<br />}<br />f();<br />echo $a; // prints 'a'<br /><br />function f(){<br />&nbsp; &nbsp; global $a; // global $a is declared, local reference is created<br />&nbsp; &nbsp; $a = 'a';&nbsp; // global $a is set<br />&nbsp; &nbsp; unset($a); // local reference $a is unset, global var $a remains set<br />&nbsp; &nbsp; global $a; // local reference is created again<br />&nbsp; &nbsp; $a .= 'b';<br />}<br />f();<br />echo $a; // prints 'ab'</span>
</code></div>
  </div>
 </div>
  <div class="note" id="91982">  <div class="votes">
    <div id="Vu91982">
    <a href="/manual/vote-note.php?id=91982&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd91982">
    <a href="/manual/vote-note.php?id=91982&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V91982" title="50% like this...">
    0
    </div>
  </div>
  <a href="#91982" class="name">
  <strong class="user"><em>emartin at sigb dot net</em></strong></a><a class="genanchor" href="#91982"> &para;</a><div class="date" title="2009-07-03 07:32"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom91982">
<div class="phpcode"><code><span class="html">
If you are used to include files which declare global variables, and if you now need to include these files in a function, you will see that those globals are declared in the function's scope and so they will be lost at the end of the function.<br /><br />You may use something like this to solve this problem:<br /><br />main_file.php :<br /><span class="default">&lt;?php <br /><br /></span><span class="comment">//Some innocent variables which exist before the problem<br /></span><span class="default">$a </span><span class="keyword">= </span><span class="default">42</span><span class="keyword">;<br /></span><span class="default">$b </span><span class="keyword">= </span><span class="default">33</span><span class="keyword">;<br /></span><span class="default">$c </span><span class="keyword">= </span><span class="default">56</span><span class="keyword">;<br /><br />function </span><span class="default">some_function</span><span class="keyword">() {<br />&nbsp; &nbsp; </span><span class="comment">//Some variables that we don't want out of the function<br />&nbsp; &nbsp; </span><span class="default">$saucisse </span><span class="keyword">= </span><span class="string">"saucisse"</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$jambon </span><span class="keyword">= </span><span class="string">"jambon"</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">//Let's include another file<br />&nbsp; &nbsp; </span><span class="default">$evalt </span><span class="keyword">= </span><span class="string">"require_once 'anothertest_include.php';"</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$before_eval_vars </span><span class="keyword">= </span><span class="default">get_defined_vars</span><span class="keyword">();<br />&nbsp; &nbsp; eval(</span><span class="default">$evalt</span><span class="keyword">);<br /><br />&nbsp; &nbsp; </span><span class="comment">//Let's extract the variables that were defined AFTER the call to 'eval'<br />&nbsp; &nbsp; </span><span class="default">$function_variable_names </span><span class="keyword">= array(</span><span class="string">"function_variable_names" </span><span class="keyword">=&gt; </span><span class="default">0</span><span class="keyword">, </span><span class="string">"before_eval_vars" </span><span class="keyword">=&gt; </span><span class="default">0</span><span class="keyword">, </span><span class="string">"created" </span><span class="keyword">=&gt; </span><span class="default">0</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="comment">//We can generate a list of the newly created variables by substracting the list of the variables of the function and the list of the variables which existed before the call to the list of current variables at this point<br />&nbsp; &nbsp; </span><span class="default">$created </span><span class="keyword">= </span><span class="default">array_diff_key</span><span class="keyword">(</span><span class="default">get_defined_vars</span><span class="keyword">(), </span><span class="default">$GLOBALS</span><span class="keyword">, </span><span class="default">$function_variable_names</span><span class="keyword">, </span><span class="default">$before_eval_vars</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="comment">//Now we globalize them<br />&nbsp; &nbsp; </span><span class="keyword">foreach (</span><span class="default">$created </span><span class="keyword">as </span><span class="default">$created_name </span><span class="keyword">=&gt; </span><span class="default">$on_sen_fiche</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; global $</span><span class="default">$created_name</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="comment">//And we affect them<br />&nbsp; &nbsp; </span><span class="default">extract</span><span class="keyword">(</span><span class="default">$created</span><span class="keyword">);<br />&nbsp; &nbsp; <br />}<br /><br /></span><span class="default">some_function</span><span class="keyword">();<br /></span><span class="default">print_r</span><span class="keyword">(</span><span class="default">get_defined_vars</span><span class="keyword">());<br /><br /></span><span class="default">?&gt;<br /></span><br />included_file.php :<br /><span class="default">&lt;?php<br /><br /></span><span class="comment">//Some variables that we want in the global scope of main_file.php<br /></span><span class="default">$included_var_one </span><span class="keyword">= </span><span class="default">123</span><span class="keyword">;<br /></span><span class="default">$included_var_two </span><span class="keyword">= </span><span class="default">465</span><span class="keyword">;<br /></span><span class="default">$included_var_three </span><span class="keyword">= </span><span class="default">789</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="88570">  <div class="votes">
    <div id="Vu88570">
    <a href="/manual/vote-note.php?id=88570&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd88570">
    <a href="/manual/vote-note.php?id=88570&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V88570" title="50% like this...">
    0
    </div>
  </div>
  <a href="#88570" class="name">
  <strong class="user"><em>nullhility at gmail dot com</em></strong></a><a class="genanchor" href="#88570"> &para;</a><div class="date" title="2009-01-29 07:17"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom88570">
<div class="phpcode"><code><span class="html">
Like functions, if you declare a variable in a class, then set it as global in that class, its value will not be retained outside of that class either.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">global_reference<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public </span><span class="default">$val</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">__construct </span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; global </span><span class="default">$var</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">val </span><span class="keyword">= </span><span class="default">$var</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">dump_it </span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">debug_zval_dump</span><span class="keyword">(</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">val</span><span class="keyword">);<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public function </span><span class="default">type_cast </span><span class="keyword">() <br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">val </span><span class="keyword">= (int) </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">val</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">$var </span><span class="keyword">= </span><span class="string">"x"</span><span class="keyword">;<br /></span><span class="default">$obj </span><span class="keyword">= new </span><span class="default">global_reference</span><span class="keyword">();<br /></span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">dump_it</span><span class="keyword">();<br /></span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">type_cast</span><span class="keyword">();<br />echo </span><span class="string">"after change "</span><span class="keyword">;<br /></span><span class="default">$obj</span><span class="keyword">-&gt;</span><span class="default">dump_it</span><span class="keyword">();<br />echo </span><span class="string">"original </span><span class="default">$var</span><span class="string">\n"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />The work-around is of course changing the assignment in the constructor to a reference assignment as such:<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="comment">//....<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">val </span><span class="keyword">= &amp;var;<br />&nbsp; &nbsp; </span><span class="comment">//....<br /></span><span class="default">?&gt;<br /></span><br />If the global you're setting is an object then no reference is necessary because of the way PHP deals with objects. If you don't want to reference to the same object however you can use the clone keyword.<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">//...<br />&nbsp; &nbsp; </span><span class="keyword">global </span><span class="default">$Obj</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">obj_copy </span><span class="keyword">= clone </span><span class="default">$Obj</span><span class="keyword">;<br /></span><span class="comment">//...<br /></span><span class="default">?&gt;<br /></span><br />[EDIT BY danbrown AT php DOT net:&nbsp; Merged all thoughts and notes by this author into a single note.]</span>
</code></div>
  </div>
 </div>
  <div class="note" id="68304">  <div class="votes">
    <div id="Vu68304">
    <a href="/manual/vote-note.php?id=68304&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd68304">
    <a href="/manual/vote-note.php?id=68304&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V68304" title="50% like this...">
    0
    </div>
  </div>
  <a href="#68304" class="name">
  <strong class="user"><em>sami doesn't want spam at no-eff-eks com</em></strong></a><a class="genanchor" href="#68304"> &para;</a><div class="date" title="2006-07-21 09:18"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom68304">
<div class="phpcode"><code><span class="html">
PHP 5.1.4 doesn't seem to care about the static keyword. It doesn't let you use $this in a static method, but you can call class methods through an instance of the class using regular -&gt; notation. You can also call instance methods as class methods through the class itself. The documentiation here is plain wrong.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Foo </span><span class="keyword">{<br />&nbsp; public static function </span><span class="default">static_fun</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; return </span><span class="string">"This is a class method!\n"</span><span class="keyword">;<br />&nbsp; }<br />&nbsp; <br />&nbsp; public function </span><span class="default">not_static_fun</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; return </span><span class="string">"This is an instance method!\n"</span><span class="keyword">;<br />&nbsp; }<br />}<br /><br />echo </span><span class="string">'&lt;pre&gt;'</span><span class="keyword">;<br />echo </span><span class="string">"From Foo:\n"</span><span class="keyword">;<br />echo </span><span class="default">Foo</span><span class="keyword">::</span><span class="default">static_fun</span><span class="keyword">();<br />echo </span><span class="default">Foo</span><span class="keyword">::</span><span class="default">not_static_fun</span><span class="keyword">();<br />echo </span><span class="string">"\n"</span><span class="keyword">;<br /><br />echo </span><span class="string">"From \$foo = new Foo():\n"</span><span class="keyword">;<br /></span><span class="default">$foo </span><span class="keyword">= new </span><span class="default">Foo</span><span class="keyword">();<br />echo </span><span class="default">$foo</span><span class="keyword">-&gt;</span><span class="default">static_fun</span><span class="keyword">();<br />echo </span><span class="default">$foo</span><span class="keyword">-&gt;</span><span class="default">not_static_fun</span><span class="keyword">();<br />echo </span><span class="string">'&lt;/pre&gt;'</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />You'll see the following output:<br /><br />From Foo:<br />This is a class method!<br />This is an instance method!<br /><br />From $foo = new Foo():<br />This is a class method!<br />This is an instance method!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="61756">  <div class="votes">
    <div id="Vu61756">
    <a href="/manual/vote-note.php?id=61756&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd61756">
    <a href="/manual/vote-note.php?id=61756&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V61756" title="50% like this...">
    0
    </div>
  </div>
  <a href="#61756" class="name">
  <strong class="user"><em>franp at free dot fr</em></strong></a><a class="genanchor" href="#61756"> &para;</a><div class="date" title="2006-02-10 04:25"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom61756">
<div class="phpcode"><code><span class="html">
If you want to access a table row using $GLOBALS, you must do it outside string delimiters or using curl braces :<br /><br /><span class="default">&lt;?php<br />$siteParams</span><span class="keyword">[</span><span class="string">"siteName"</span><span class="keyword">] = </span><span class="string">"myweb"</span><span class="keyword">;<br /><br />function </span><span class="default">foo</span><span class="keyword">() {<br /></span><span class="default">$table </span><span class="keyword">= </span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">"siteParams"</span><span class="keyword">][</span><span class="string">"siteName"</span><span class="keyword">].</span><span class="string">"articles"</span><span class="keyword">;&nbsp; </span><span class="comment">// OK<br /></span><span class="keyword">echo </span><span class="default">$table</span><span class="keyword">; </span><span class="comment">// output&nbsp; "mywebarticles"<br /></span><span class="default">$table </span><span class="keyword">= </span><span class="string">"</span><span class="keyword">{</span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">"siteParams"</span><span class="keyword">][</span><span class="string">"siteName"</span><span class="keyword">]}</span><span class="string">articles"</span><span class="keyword">; </span><span class="comment">// OK<br /></span><span class="keyword">echo </span><span class="default">$table</span><span class="keyword">; </span><span class="comment">// output&nbsp; "mywebarticles"<br /></span><span class="default">$table </span><span class="keyword">= </span><span class="string">"</span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="default">siteParams</span><span class="keyword">]</span><span class="string">[siteName]articles"</span><span class="keyword">;&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="comment">// Not OK<br /></span><span class="keyword">echo </span><span class="default">$table</span><span class="keyword">; </span><span class="comment">// output&nbsp; "Array[siteName]article"<br /><br /></span><span class="default">$result </span><span class="keyword">= </span><span class="default">mysql_query</span><span class="keyword">(</span><span class="string">"UPDATE </span><span class="default">$table</span><span class="string"> ..."</span><span class="keyword">);<br />}<br /></span><span class="default">?&gt;<br /></span><br />Or use global :<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">foo</span><span class="keyword">() {<br />global </span><span class="default">$siteParams</span><span class="keyword">;<br /></span><span class="default">$table </span><span class="keyword">= </span><span class="string">"</span><span class="default">$siteParams</span><span class="keyword">[</span><span class="default">siteName</span><span class="keyword">]</span><span class="string">articles"</span><span class="keyword">;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="comment">// OK<br /></span><span class="keyword">echo </span><span class="default">$table</span><span class="keyword">; </span><span class="comment">// output&nbsp; "mywebarticles"<br /><br /></span><span class="default">$result </span><span class="keyword">= </span><span class="default">mysql_query</span><span class="keyword">(</span><span class="string">"UPDATE </span><span class="default">$table</span><span class="string"> ..."</span><span class="keyword">);<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="27546">  <div class="votes">
    <div id="Vu27546">
    <a href="/manual/vote-note.php?id=27546&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd27546">
    <a href="/manual/vote-note.php?id=27546&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V27546" title="50% like this...">
    0
    </div>
  </div>
  <a href="#27546" class="name">
  <strong class="user"><em>wjs@sympaticoDOTca</em></strong></a><a class="genanchor" href="#27546"> &para;</a><div class="date" title="2002-12-10 09:03"><strong>15 years ago</strong></div>
  <div class="text" id="Hcom27546">
<div class="phpcode"><code><span class="html">
Becareful where you define your global variables: <br /><br />This will work:<br /><span class="default">&lt;?php <br />&nbsp; $MyArray </span><span class="keyword">= array(</span><span class="string">"Dog"</span><span class="keyword">);<br /><br />&nbsp; function </span><span class="default">SeeArray</span><span class="keyword">(){<br />&nbsp; &nbsp; global </span><span class="default">$MyArray</span><span class="keyword">;<br />&nbsp; &nbsp; if (</span><span class="default">in_array</span><span class="keyword">(</span><span class="string">"Dog"</span><span class="keyword">,</span><span class="default">$MyArray</span><span class="keyword">)){<br />&nbsp; &nbsp; &nbsp; foreach (</span><span class="default">$MyArray </span><span class="keyword">as </span><span class="default">$Element</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"</span><span class="default">$Element</span><span class="string"> &lt;hr/&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; }<br /><br />&nbsp; </span><span class="default">SeeArray</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span><br />while this will not:<br /><span class="default">&lt;?php <br />&nbsp; SeeArray</span><span class="keyword">();<br />&nbsp; </span><span class="default">$MyArray </span><span class="keyword">= array(</span><span class="string">"Dog"</span><span class="keyword">);<br /><br />&nbsp; function </span><span class="default">SeeArray</span><span class="keyword">(){<br />&nbsp; &nbsp; global </span><span class="default">$MyArray</span><span class="keyword">;<br />&nbsp; &nbsp; if (</span><span class="default">in_array</span><span class="keyword">(</span><span class="string">"Dog"</span><span class="keyword">,</span><span class="default">$MyArray</span><span class="keyword">)){ </span><span class="comment">// an error will generate here<br />&nbsp; &nbsp; &nbsp; </span><span class="keyword">foreach (</span><span class="default">$MyArray </span><span class="keyword">as </span><span class="default">$Element</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"</span><span class="default">$Element</span><span class="string"> &lt;hr/&gt;"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; }<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="18905">  <div class="votes">
    <div id="Vu18905">
    <a href="/manual/vote-note.php?id=18905&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd18905">
    <a href="/manual/vote-note.php?id=18905&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V18905" title="50% like this...">
    0
    </div>
  </div>
  <a href="#18905" class="name">
  <strong class="user"><em>steph_rondinaud at club-internet dot fr</em></strong></a><a class="genanchor" href="#18905"> &para;</a><div class="date" title="2002-02-09 04:41"><strong>15 years ago</strong></div>
  <div class="text" id="Hcom18905">
<div class="phpcode"><code><span class="html">
I'm using PHP 4.1.1<br /><br />While designing a database access class, I needed a static variable that will be incremented for all instances of the class each time the class connected to the database. The obvious solution was to declare a "connection" class variable with static scope. Unfortunatly, php doesn't allow such a declaration.<br />So I went back to defining a static variable in the connect method of my class. But it seems that the static scope is not inherited: if class "a" inherit the "db access" class, then the "connection" variable is shared among "a" instances, not among both "a" AND "db access" instances. <br />Solution is to declare the static variable out of the db access class, and declare "global" said variable in the connect method.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="3596">  <div class="votes">
    <div id="Vu3596">
    <a href="/manual/vote-note.php?id=3596&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd3596">
    <a href="/manual/vote-note.php?id=3596&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V3596" title="50% like this...">
    0
    </div>
  </div>
  <a href="#3596" class="name">
  <strong class="user"><em>shevek at anarres dot org</em></strong></a><a class="genanchor" href="#3596"> &para;</a><div class="date" title="2000-02-04 04:51"><strong>17 years ago</strong></div>
  <div class="text" id="Hcom3596">
<div class="phpcode"><code><span class="html">
If you include a file from within a function using include(), the included file inherits the function scope as its own global scope, it will not be able to see top level globals unless they are explicit in the function.<br /><br /><span class="default">&lt;?php<br />$foo </span><span class="keyword">= </span><span class="string">"bar"</span><span class="keyword">;<br />function </span><span class="default">baz</span><span class="keyword">() {<br />&nbsp; &nbsp; global </span><span class="default">$foo</span><span class="keyword">; </span><span class="comment"># NOTE THIS<br />&nbsp; &nbsp; </span><span class="keyword">include(</span><span class="string">"qux"</span><span class="keyword">);<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="12787">  <div class="votes">
    <div id="Vu12787">
    <a href="/manual/vote-note.php?id=12787&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd12787">
    <a href="/manual/vote-note.php?id=12787&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V12787" title="46% like this...">
    -1
    </div>
  </div>
  <a href="#12787" class="name">
  <strong class="user"><em>carpathia_uk at mail dot com</em></strong></a><a class="genanchor" href="#12787"> &para;</a><div class="date" title="2001-05-07 02:21"><strong>16 years ago</strong></div>
  <div class="text" id="Hcom12787">
<div class="phpcode"><code><span class="html">
On confusing aspect about global scope...<br /><br />If you want to access a variable such as a cookie inside a function, but theres a chance it may not even be defined, you need to access it using he GLOBALS array, not by defining it as global.<br /><br />This wont work correctly....<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">isLoggedin</span><span class="keyword">()<br />{<br />global </span><span class="default">$cookie_username</span><span class="keyword">;<br />if (isset(</span><span class="default">$cookie_username</span><span class="keyword">) <br />echo </span><span class="string">"blah.."</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />This will..<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">isLoggedin</span><span class="keyword">()<br />{<br />if (isset(</span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">"cookie_username"</span><span class="keyword">]))<br />echo </span><span class="string">"blah.."</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119366">  <div class="votes">
    <div id="Vu119366">
    <a href="/manual/vote-note.php?id=119366&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119366">
    <a href="/manual/vote-note.php?id=119366&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119366" title="42% like this...">
    -1
    </div>
  </div>
  <a href="#119366" class="name">
  <strong class="user"><em>Ganlv</em></strong></a><a class="genanchor" href="#119366"> &para;</a><div class="date" title="2016-05-21 04:50"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119366">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br />$var </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />function </span><span class="default">foo</span><span class="keyword">() {<br />&nbsp; &nbsp; </span><span class="default">$var </span><span class="keyword">= &amp;</span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">'var'</span><span class="keyword">];<br />&nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">);<br />}<br />function </span><span class="default">bar</span><span class="keyword">() {<br />&nbsp; &nbsp; global </span><span class="default">$var</span><span class="keyword">; </span><span class="comment">// they are the same.<br />&nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">);<br />}<br /></span><span class="default">foo</span><span class="keyword">();<br /></span><span class="default">bar</span><span class="keyword">();<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />In a function, 'global $var;' is to declare a local variant, and the local $var has the same reference to the global $var.<br /><br /><span class="default">&lt;?php<br />$var </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />function </span><span class="default">foo</span><span class="keyword">() {<br />&nbsp; &nbsp; global </span><span class="default">$var</span><span class="keyword">;<br />&nbsp; &nbsp; unset(</span><span class="default">$var</span><span class="keyword">);&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="comment">// unset local $a, the global $a is still there.<br />&nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">);&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Undefined variable: var<br />&nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">'var'</span><span class="keyword">]); </span><span class="comment">// this is ok.<br /></span><span class="keyword">}<br /></span><span class="default">foo</span><span class="keyword">();<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">);&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// this is ok.<br /></span><span class="default">?&gt;<br /></span><br /><span class="default">&lt;?php<br />$var </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />function </span><span class="default">bar</span><span class="keyword">() {<br />&nbsp; &nbsp; global </span><span class="default">$var</span><span class="keyword">;<br />&nbsp; &nbsp; unset(</span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">'var'</span><span class="keyword">]);&nbsp; &nbsp; </span><span class="comment">// unset global $a, the local $a is still here.<br />&nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">);&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// this is ok.<br />&nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">'var'</span><span class="keyword">]); </span><span class="comment">// Undefined index: var<br /></span><span class="keyword">}<br /></span><span class="default">foo</span><span class="keyword">();<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$var</span><span class="keyword">);&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// Undefined variable: var<br /></span><span class="default">?&gt;<br /></span><br />'unset($var);' is like 'var = NULL;'(var is a pointer) in the C language, instead of 'free(var);'</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113115">  <div class="votes">
    <div id="Vu113115">
    <a href="/manual/vote-note.php?id=113115&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113115">
    <a href="/manual/vote-note.php?id=113115&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113115" title="42% like this...">
    -1
    </div>
  </div>
  <a href="#113115" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#113115"> &para;</a><div class="date" title="2013-08-31 09:27"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113115">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br /><br /></span><span class="comment">// if you really want to create a variable within its own scope <br />// that does not have access to variables outside its scope create a function<br /><br /></span><span class="default">$var </span><span class="keyword">= </span><span class="string">"hello"</span><span class="keyword">;<br /><br /></span><span class="default">$func </span><span class="keyword">= function(){<br /><br />&nbsp; &nbsp; &nbsp; </span><span class="comment">// declare variables here that will only last throughout this scope<br /><br />&nbsp; &nbsp;&nbsp; </span><span class="keyword">if( !isset(</span><span class="default">$var</span><span class="keyword">) ) </span><span class="comment">// var will not be set in this scope<br />&nbsp; &nbsp;&nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$var </span><span class="keyword">= </span><span class="string">"i was out of scope"</span><span class="keyword">;<br />&nbsp; &nbsp;&nbsp; }<br />&nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; echo </span><span class="default">$var</span><span class="keyword">;<br /><br />};<br /><br />echo </span><span class="string">"</span><span class="default">$var</span><span class="string">&lt;br /&gt;"</span><span class="keyword">;<br /><br /></span><span class="default">$func</span><span class="keyword">(); </span><span class="comment">// invoke the function<br /><br /></span><span class="keyword">echo </span><span class="string">"&lt;br /&gt;"</span><span class="keyword">.</span><span class="string">'$var'</span><span class="keyword">.</span><span class="string">" never changed from </span><span class="default">$var</span><span class="string">"</span><span class="keyword">;<br /><br /></span><span class="default">?&gt;<br /></span><br />outputs :<br /><br />hello<br />i was out of scope<br />$var never changed from hello</span>
</code></div>
  </div>
 </div>
  <div class="note" id="89872">  <div class="votes">
    <div id="Vu89872">
    <a href="/manual/vote-note.php?id=89872&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd89872">
    <a href="/manual/vote-note.php?id=89872&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V89872" title="43% like this...">
    -2
    </div>
  </div>
  <a href="#89872" class="name">
  <strong class="user"><em>Leigh Harrison</em></strong></a><a class="genanchor" href="#89872"> &para;</a><div class="date" title="2009-03-26 10:31"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom89872">
<div class="phpcode"><code><span class="html">
External variables in a function<br /><br />I needed to access dynamically-created variables from an included file within a helper function. Because the list of $path_* variables I needed to access from the other file is itself dynamic, I didn't want to have to declare all possible variables within the function, and I was concerned at the overhead of declaring =all= members of $GLOBALS[] as global. However the following code worked for me:<br /><br /><span class="default">&lt;?php<br />&nbsp; </span><span class="keyword">function </span><span class="default">makePath</span><span class="keyword">(</span><span class="default">$root</span><span class="keyword">, </span><span class="default">$atom</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$pos </span><span class="keyword">= </span><span class="default">strrpos</span><span class="keyword">(</span><span class="default">$atom</span><span class="keyword">, </span><span class="string">'/'</span><span class="keyword">);<br />&nbsp; &nbsp; if (</span><span class="default">$pos </span><span class="keyword">=== </span><span class="default">false</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; global ${</span><span class="string">'path_'</span><span class="keyword">.</span><span class="default">$atom</span><span class="keyword">};&nbsp; <br />&nbsp; &nbsp; &nbsp; </span><span class="default">$path </span><span class="keyword">= ${</span><span class="string">'path_'</span><span class="keyword">.</span><span class="default">$atom</span><span class="keyword">};<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; else {<br />&nbsp; &nbsp; &nbsp; global ${</span><span class="string">'path_'</span><span class="keyword">.</span><span class="default">substr</span><span class="keyword">(</span><span class="default">$atom</span><span class="keyword">, </span><span class="default">0</span><span class="keyword">, </span><span class="default">$pos</span><span class="keyword">)};<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$path </span><span class="keyword">= ${</span><span class="string">'path_'</span><span class="keyword">.</span><span class="default">substr</span><span class="keyword">(</span><span class="default">$atom</span><span class="keyword">, </span><span class="default">0</span><span class="keyword">, </span><span class="default">$pos</span><span class="keyword">)};<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; if (</span><span class="default">$path</span><span class="keyword">) <br />&nbsp; &nbsp; &nbsp; return (</span><span class="default">$pos </span><span class="keyword">=== </span><span class="default">false</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; ? </span><span class="default">$root</span><span class="keyword">.</span><span class="default">$path<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">: </span><span class="default">$root</span><span class="keyword">.</span><span class="default">$path</span><span class="keyword">.</span><span class="default">substr</span><span class="keyword">(</span><span class="default">$atom</span><span class="keyword">, </span><span class="default">$pos </span><span class="keyword">+ </span><span class="default">1</span><span class="keyword">);<br />&nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; return </span><span class="default">NULL</span><span class="keyword">;<br />&nbsp; }<br /></span><span class="default">?&gt;<br /></span><br />Regards,<br /><br />::Leigh</span>
</code></div>
  </div>
 </div>
  <div class="note" id="26015">  <div class="votes">
    <div id="Vu26015">
    <a href="/manual/vote-note.php?id=26015&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd26015">
    <a href="/manual/vote-note.php?id=26015&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V26015" title="44% like this...">
    -1
    </div>
  </div>
  <a href="#26015" class="name">
  <strong class="user"><em>heatwave at fw dot hu</em></strong></a><a class="genanchor" href="#26015"> &para;</a><div class="date" title="2002-10-15 05:12"><strong>15 years ago</strong></div>
  <div class="text" id="Hcom26015">
<div class="phpcode"><code><span class="html">
Some people (including me) had a problem with defining a long GLOBAL variable list in functions (very error prone). Here is a possible solution. My program parses php file for functions, and compiles GLOBAL variable lists. Then you can just remove from the list those variables which need not be global.<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="comment">//parser for GLOBAL variable list<br />&nbsp; &nbsp; </span><span class="default">$pfile</span><span class="keyword">=</span><span class="default">file</span><span class="keyword">(</span><span class="string">"myfile.php4"</span><span class="keyword">);<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; for(</span><span class="default">$i</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">;</span><span class="default">$i</span><span class="keyword">&lt;</span><span class="default">sizeof</span><span class="keyword">(</span><span class="default">$pfile</span><span class="keyword">);</span><span class="default">$i</span><span class="keyword">++) {<br />&nbsp; &nbsp;&nbsp; if(</span><span class="default">eregi</span><span class="keyword">(</span><span class="string">"function"</span><span class="keyword">,</span><span class="default">$pfile</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">])) {<br />&nbsp; &nbsp; &nbsp; list(</span><span class="default">$part1</span><span class="keyword">,</span><span class="default">$part2</span><span class="keyword">)=</span><span class="default">sscanf</span><span class="keyword">(</span><span class="default">$pfile</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">],</span><span class="string">"%s %s"</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; echo </span><span class="string">"\n\n </span><span class="default">$part1</span><span class="string"> </span><span class="default">$part2</span><span class="string">:\nGLOBAL "</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; </span><span class="default">$varlist</span><span class="keyword">=array();<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$level</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">; </span><span class="default">$end</span><span class="keyword">=</span><span class="default">$i</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; do {<br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$lpar</span><span class="keyword">=</span><span class="default">explode</span><span class="keyword">(</span><span class="string">"{"</span><span class="keyword">,</span><span class="default">$pfile</span><span class="keyword">[</span><span class="default">$end</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$level</span><span class="keyword">+=</span><span class="default">sizeof</span><span class="keyword">(</span><span class="default">$lpar</span><span class="keyword">)-</span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$lpar</span><span class="keyword">=</span><span class="default">explode</span><span class="keyword">(</span><span class="string">"}"</span><span class="keyword">,</span><span class="default">$pfile</span><span class="keyword">[</span><span class="default">$end</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$level</span><span class="keyword">-=</span><span class="default">sizeof</span><span class="keyword">(</span><span class="default">$lpar</span><span class="keyword">)-</span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$end</span><span class="keyword">++;<br />&nbsp; &nbsp; &nbsp; } while((</span><span class="default">$end</span><span class="keyword">&lt;</span><span class="default">sizeof</span><span class="keyword">(</span><span class="default">$pfile</span><span class="keyword">))&amp;&amp;(</span><span class="default">$level</span><span class="keyword">&gt;</span><span class="default">0</span><span class="keyword">));<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$pstr</span><span class="keyword">=</span><span class="string">""</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; for(</span><span class="default">$j</span><span class="keyword">=</span><span class="default">$i</span><span class="keyword">;</span><span class="default">$j</span><span class="keyword">&lt;=</span><span class="default">$end</span><span class="keyword">;</span><span class="default">$j</span><span class="keyword">++) </span><span class="default">$pstr</span><span class="keyword">.=</span><span class="default">$pfile</span><span class="keyword">[</span><span class="default">$j</span><span class="keyword">];<br />&nbsp; &nbsp; &nbsp; </span><span class="default">$lpar</span><span class="keyword">=</span><span class="default">explode</span><span class="keyword">(</span><span class="string">"$"</span><span class="keyword">,</span><span class="default">$pstr</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; for(</span><span class="default">$j</span><span class="keyword">=</span><span class="default">1</span><span class="keyword">;</span><span class="default">$j</span><span class="keyword">&lt;</span><span class="default">sizeof</span><span class="keyword">(</span><span class="default">$lpar</span><span class="keyword">);</span><span class="default">$j</span><span class="keyword">++) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">eregi</span><span class="keyword">(</span><span class="string">'[a-zA-Z_][a-zA-Z0-9_]*'</span><span class="keyword">,</span><span class="default">$lpar</span><span class="keyword">[</span><span class="default">$j</span><span class="keyword">],</span><span class="default">$cvar</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$varlist</span><span class="keyword">[</span><span class="default">$cvar</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">]]=</span><span class="default">1</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; </span><span class="default">array_walk</span><span class="keyword">(</span><span class="default">$varlist</span><span class="keyword">,</span><span class="string">'var_print'</span><span class="keyword">);<br />&nbsp; &nbsp;&nbsp; }<br />&nbsp; &nbsp; }<br />function </span><span class="default">var_print </span><span class="keyword">(</span><span class="default">$item</span><span class="keyword">, </span><span class="default">$key</span><span class="keyword">) {<br />&nbsp; &nbsp;&nbsp; echo </span><span class="string">"</span><span class="default">$key</span><span class="string">,"</span><span class="keyword">;<br /> }<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="83490">  <div class="votes">
    <div id="Vu83490">
    <a href="/manual/vote-note.php?id=83490&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd83490">
    <a href="/manual/vote-note.php?id=83490&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V83490" title="41% like this...">
    -2
    </div>
  </div>
  <a href="#83490" class="name">
  <strong class="user"><em>lgrk</em></strong></a><a class="genanchor" href="#83490"> &para;</a><div class="date" title="2008-05-28 06:41"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom83490">
<div class="phpcode"><code><span class="html">
Useful function:<br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">cycle</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">, </span><span class="default">$i</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">) {<br />&nbsp; &nbsp; static </span><span class="default">$switches </span><span class="keyword">= array();<br />&nbsp; &nbsp; if (isset(</span><span class="default">$switches</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">])) </span><span class="default">$switches</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">] = !</span><span class="default">$switches</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">]; else !</span><span class="default">$switches</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">] = </span><span class="default">true</span><span class="keyword">;<br />&nbsp; &nbsp; return (</span><span class="default">$switches</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">])?</span><span class="default">$a</span><span class="keyword">:</span><span class="default">$b</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />Exeample<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">for (</span><span class="default">$i </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">&lt;</span><span class="default">3</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">++) {<br />&nbsp; &nbsp; echo </span><span class="default">$i</span><span class="keyword">.</span><span class="default">cycle</span><span class="keyword">(</span><span class="string">'a'</span><span class="keyword">, </span><span class="string">'b'</span><span class="keyword">).</span><span class="default">PHP_EOL</span><span class="keyword">;<br />&nbsp; &nbsp; for (</span><span class="default">$j </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">; </span><span class="default">$j</span><span class="keyword">&lt;</span><span class="default">5</span><span class="keyword">; </span><span class="default">$j</span><span class="keyword">++) {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">' '</span><span class="keyword">.</span><span class="default">$j</span><span class="keyword">.</span><span class="default">cycle</span><span class="keyword">(</span><span class="string">'a'</span><span class="keyword">, </span><span class="string">'b'</span><span class="keyword">, </span><span class="default">1</span><span class="keyword">).</span><span class="default">PHP_EOL</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; for (</span><span class="default">$k </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">; </span><span class="default">$k</span><span class="keyword">&lt;</span><span class="default">3</span><span class="keyword">; </span><span class="default">$k</span><span class="keyword">++) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'&nbsp; '</span><span class="keyword">.</span><span class="default">$k</span><span class="keyword">.</span><span class="default">cycle</span><span class="keyword">(</span><span class="string">'c'</span><span class="keyword">, </span><span class="string">'d'</span><span class="keyword">, </span><span class="default">2</span><span class="keyword">).</span><span class="default">PHP_EOL</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />}<br /></span><span class="comment">/**<br />Output:<br />1a<br /> 1a<br />&nbsp; 1c<br />&nbsp; 2d<br /> 2b<br />&nbsp; 1c<br />&nbsp; 2d<br /> 3a<br />&nbsp; 1c<br />&nbsp; 2d<br /> 4b<br />&nbsp; 1c<br />&nbsp; 2d<br />2b<br /> 1a<br />&nbsp; 1c<br />&nbsp; 2d<br /> 2b<br />&nbsp; 1c<br />&nbsp; 2d<br /> 3a<br />&nbsp; 1c<br />&nbsp; 2d<br /> 4b<br />&nbsp; 1c<br />&nbsp; 2d<br />*/<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="39091">  <div class="votes">
    <div id="Vu39091">
    <a href="/manual/vote-note.php?id=39091&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd39091">
    <a href="/manual/vote-note.php?id=39091&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V39091" title="40% like this...">
    -2
    </div>
  </div>
  <a href="#39091" class="name">
  <strong class="user"><em>jmarbas at hotmail dot com</em></strong></a><a class="genanchor" href="#39091"> &para;</a><div class="date" title="2004-01-16 03:34"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom39091">
<div class="phpcode"><code><span class="html">
Whats good for the goose is not always good for the iterative gander. If you declare and initialize the static variable more than once inside a function ie.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">Test</span><span class="keyword">(){<br />&nbsp;&nbsp; static </span><span class="default">$count </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />&nbsp;&nbsp; static </span><span class="default">$count </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />&nbsp;&nbsp; static </span><span class="default">$count </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">;<br />&nbsp;&nbsp; echo </span><span class="default">$count</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />the variable will take the value of the last declaration. In this case $count=2.<br /><br />But! however when you make that function recursive ie.<br /><br /><span class="default">&lt;?php<br />&nbsp; </span><span class="keyword">function </span><span class="default">Test</span><span class="keyword">(){<br />&nbsp;&nbsp; static </span><span class="default">$count </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />&nbsp;&nbsp; static </span><span class="default">$count </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />&nbsp;&nbsp; static </span><span class="default">$count </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">;<br /><br />&nbsp;&nbsp; </span><span class="default">$count</span><span class="keyword">++;<br />&nbsp;&nbsp; echo </span><span class="default">$count</span><span class="keyword">;<br />&nbsp;&nbsp; if (</span><span class="default">$count</span><span class="keyword">&lt;</span><span class="default">10</span><span class="keyword">){<br />&nbsp; &nbsp;&nbsp; </span><span class="default">Test</span><span class="keyword">();<br />&nbsp;&nbsp; }<br />&nbsp; }<br /></span><span class="default">?&gt;<br /></span><br />Every call to the function Test() is a differenct SCOPE and therefore the static declarations and initializations are NOT executed again. So what Im trying to say is that its OK to declare and initialize a static variable multiple times if you are in one function... but its NOT OK to declare and initialize a static variable multiple times if you call that same function multiple times. In other words the static variable is set once you LEAVE a function (even if you go back into that very same function).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="92166">  <div class="votes">
    <div id="Vu92166">
    <a href="/manual/vote-note.php?id=92166&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd92166">
    <a href="/manual/vote-note.php?id=92166&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V92166" title="37% like this...">
    -2
    </div>
  </div>
  <a href="#92166" class="name">
  <strong class="user"><em>akam at akameng dot com</em></strong></a><a class="genanchor" href="#92166"> &para;</a><div class="date" title="2009-07-12 07:39"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom92166">
<div class="phpcode"><code><span class="html">
Many Times Globality of variables will be the small issue, after long time I decided to use super globals.<br /><br />Super globals exists any where:<br />$_SERVER, $_GET, $_POST .....<br /><br />Now for example:<br /><br /><span class="default">&lt;?php<br />$foo</span><span class="keyword">[] = </span><span class="default">range</span><span class="keyword">(</span><span class="default">0</span><span class="keyword">, </span><span class="default">3</span><span class="keyword">);<br /></span><span class="default">$_POST</span><span class="keyword">[</span><span class="string">'foo'</span><span class="keyword">] = </span><span class="default">$foo</span><span class="keyword">;<br /></span><span class="default">a</span><span class="keyword">(); </span><span class="comment">//no parameters needed.<br /></span><span class="default">b</span><span class="keyword">();<br /></span><span class="default">$foo </span><span class="keyword">= </span><span class="default">$_POST</span><span class="keyword">[</span><span class="string">'foo'</span><span class="keyword">];<br /><br /></span><span class="default">Print_r</span><span class="keyword">(</span><span class="default">$foo</span><span class="keyword">);<br /></span><span class="comment">/* out<br /><br />Array<br />(<br />&nbsp; &nbsp; [0] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0] =&gt; 0<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [1] =&gt; 1<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [2] =&gt; 2<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [3] =&gt; 3<br />&nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />&nbsp; &nbsp; [1] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0] =&gt; 4<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [1] =&gt; 5<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [2] =&gt; 6<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [3] =&gt; 7<br />&nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />&nbsp; &nbsp; [2] =&gt; Array<br />&nbsp; &nbsp; &nbsp; &nbsp; (<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [0] =&gt; 8<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [1] =&gt; 9<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; [2] =&gt; 10<br />&nbsp; &nbsp; &nbsp; &nbsp; )<br /><br />)<br /><br />*/<br /></span><span class="keyword">function </span><span class="default">a</span><span class="keyword">(){<br />&nbsp; &nbsp; </span><span class="default">$_POST</span><span class="keyword">[</span><span class="string">'foo'</span><span class="keyword">][] = </span><span class="default">range</span><span class="keyword">(</span><span class="default">4</span><span class="keyword">, </span><span class="default">7</span><span class="keyword">);<br />}<br /><br />function </span><span class="default">b</span><span class="keyword">(){<br /></span><span class="default">$_POST</span><span class="keyword">[</span><span class="string">'foo'</span><span class="keyword">][] = </span><span class="default">range</span><span class="keyword">(</span><span class="default">8</span><span class="keyword">, </span><span class="default">10</span><span class="keyword">);<br />}<br /></span><span class="default">?&gt;<br /></span>Note: the key must not be passed by the page via _POST method by the form, else the value will be over written</span>
</code></div>
  </div>
 </div>
  <div class="note" id="60231">  <div class="votes">
    <div id="Vu60231">
    <a href="/manual/vote-note.php?id=60231&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd60231">
    <a href="/manual/vote-note.php?id=60231&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V60231" title="37% like this...">
    -2
    </div>
  </div>
  <a href="#60231" class="name">
  <strong class="user"><em>marcin</em></strong></a><a class="genanchor" href="#60231"> &para;</a><div class="date" title="2005-12-30 09:07"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom60231">
<div class="phpcode"><code><span class="html">
Sometimes in PHP 4 you need static variabiles in class. You can do it by referencing static variable in constructor to the class variable:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">test&nbsp; </span><span class="keyword">{<br /><br />&nbsp;&nbsp; var </span><span class="default">$var</span><span class="keyword">;<br />&nbsp;&nbsp; var </span><span class="default">$static_var</span><span class="keyword">;<br />&nbsp; &nbsp; function </span><span class="default">test</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; static </span><span class="default">$s</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">static_var </span><span class="keyword">=&amp; </span><span class="default">$s</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; <br />}<br /><br /> </span><span class="default">$a</span><span class="keyword">=new </span><span class="default">test</span><span class="keyword">();<br /><br /> </span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">static_var</span><span class="keyword">=</span><span class="default">4</span><span class="keyword">;<br /> </span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">var</span><span class="keyword">=</span><span class="default">4</span><span class="keyword">;<br /> <br /> </span><span class="default">$b</span><span class="keyword">=new </span><span class="default">test</span><span class="keyword">();<br /> <br /> echo </span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">static_var</span><span class="keyword">; </span><span class="comment">//this will output 4<br /> </span><span class="keyword">echo </span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">var</span><span class="keyword">; </span><span class="comment">//this will output nul<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118079">  <div class="votes">
    <div id="Vu118079">
    <a href="/manual/vote-note.php?id=118079&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118079">
    <a href="/manual/vote-note.php?id=118079&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118079" title="33% like this...">
    -1
    </div>
  </div>
  <a href="#118079" class="name">
  <strong class="user"><em>nino dot skopac at gmail dot com</em></strong></a><a class="genanchor" href="#118079"> &para;</a><div class="date" title="2015-09-30 08:01"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom118079">
<div class="phpcode"><code><span class="html">
Interesting behavior in PHP 5.6.12 and PHP 7 RC3:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Foo </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">Bar</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; static </span><span class="default">$var </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; return ++</span><span class="default">$var</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$Foo_instance </span><span class="keyword">= new </span><span class="default">Foo</span><span class="keyword">;<br /><br />print </span><span class="default">$Foo_instance</span><span class="keyword">-&gt;</span><span class="default">Bar</span><span class="keyword">(); </span><span class="comment">// prints 1<br /></span><span class="keyword">print </span><span class="default">PHP_EOL</span><span class="keyword">;<br /><br />unset(</span><span class="default">$Foo_instance</span><span class="keyword">);<br /><br /></span><span class="default">$Foo_instance2 </span><span class="keyword">= new </span><span class="default">Foo</span><span class="keyword">;<br /><br />print </span><span class="default">$Foo_instance2</span><span class="keyword">-&gt;</span><span class="default">Bar</span><span class="keyword">(); </span><span class="comment">// prints 2<br /></span><span class="keyword">print </span><span class="default">PHP_EOL</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />How can a 2 be printed, since we unseted the whole instance before?<br /><br />Consider a similar example:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">Foo </span><span class="keyword">{<br />&nbsp; &nbsp; public static </span><span class="default">$var </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; public static function </span><span class="default">Bar</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return ++</span><span class="default">self</span><span class="keyword">::</span><span class="default">$var</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$Foo_instance </span><span class="keyword">= new </span><span class="default">Foo</span><span class="keyword">;<br /><br />print </span><span class="default">$Foo_instance</span><span class="keyword">-&gt;</span><span class="default">Bar</span><span class="keyword">(); </span><span class="comment">// prints 1<br /></span><span class="keyword">print </span><span class="default">PHP_EOL</span><span class="keyword">;<br /><br />unset(</span><span class="default">$Foo_instance</span><span class="keyword">);<br /><br /></span><span class="default">$Foo_instance2 </span><span class="keyword">= new </span><span class="default">Foo</span><span class="keyword">;<br /><br />print </span><span class="default">$Foo_instance2</span><span class="keyword">-&gt;</span><span class="default">Bar</span><span class="keyword">(); </span><span class="comment">// prints 2<br /></span><span class="keyword">print </span><span class="default">PHP_EOL</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />No idea why is this happening.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="29273">  <div class="votes">
    <div id="Vu29273">
    <a href="/manual/vote-note.php?id=29273&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd29273">
    <a href="/manual/vote-note.php?id=29273&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V29273" title="33% like this...">
    -2
    </div>
  </div>
  <a href="#29273" class="name">
  <strong class="user"><em>jg at nerd-boy dot net</em></strong></a><a class="genanchor" href="#29273"> &para;</a><div class="date" title="2003-02-07 04:10"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom29273">
<div class="phpcode"><code><span class="html">
It's possible to use a variable variable when specifying a variable as global in a function. That way your function can decide what global variable to access in run-time.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">func</span><span class="keyword">(</span><span class="default">$varname</span><span class="keyword">)<br />{<br />&nbsp;&nbsp; global $</span><span class="default">$varname</span><span class="keyword">;<br /><br />&nbsp;&nbsp; echo $</span><span class="default">$varname</span><span class="keyword">;<br />}<br /><br /></span><span class="default">$hello </span><span class="keyword">= </span><span class="string">"hello world!"</span><span class="keyword">;<br /></span><span class="default">func</span><span class="keyword">(</span><span class="string">"hello"</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />This will print "hello world!", and is roughly the same as passing by reference, in the case when the variable you want to pass is global. The advantage over references is that they can't have default parameters. With the method above, you can do the following.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">func</span><span class="keyword">(</span><span class="default">$varname </span><span class="keyword">= </span><span class="default">FALSE</span><span class="keyword">)<br />{<br />&nbsp;&nbsp; if (</span><span class="default">$varname </span><span class="keyword">=== </span><span class="default">FALSE</span><span class="keyword">)<br />&nbsp; &nbsp;&nbsp; echo </span><span class="string">"No variable."</span><span class="keyword">;<br />&nbsp;&nbsp; else<br />&nbsp;&nbsp; {<br />&nbsp; &nbsp;&nbsp; global $</span><span class="default">$varname</span><span class="keyword">;<br /><br />&nbsp; &nbsp;&nbsp; echo $</span><span class="default">$varname</span><span class="keyword">;<br />&nbsp;&nbsp; }<br />}<br /><br /></span><span class="default">$hello </span><span class="keyword">= </span><span class="string">"hello world!"</span><span class="keyword">;<br /></span><span class="default">func</span><span class="keyword">(</span><span class="string">"hello"</span><span class="keyword">);&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="comment">// prints "hello world!"<br /></span><span class="default">func</span><span class="keyword">();&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// prints "No variable."<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="33832">  <div class="votes">
    <div id="Vu33832">
    <a href="/manual/vote-note.php?id=33832&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd33832">
    <a href="/manual/vote-note.php?id=33832&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V33832" title="28% like this...">
    -3
    </div>
  </div>
  <a href="#33832" class="name">
  <strong class="user"><em>ppo at beeznest dot net</em></strong></a><a class="genanchor" href="#33832"> &para;</a><div class="date" title="2003-07-08 06:59"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom33832">
<div class="phpcode"><code><span class="html">
Even if an included file return a value using return(), it's still sharing the same scope as the caller script!<br /><br /><span class="default">&lt;?php<br />$foo </span><span class="keyword">= </span><span class="string">'aaa'</span><span class="keyword">;<br /></span><span class="default">$bar </span><span class="keyword">= include(</span><span class="string">'include.php'</span><span class="keyword">);<br />echo(</span><span class="default">$foo</span><span class="keyword">.</span><span class="string">' / '</span><span class="keyword">.</span><span class="default">$bar</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />where include.php is<br /><span class="default">&lt;?php<br />$foo </span><span class="keyword">= </span><span class="string">'bbb'</span><span class="keyword">;<br />return </span><span class="default">$foo</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />The output is: bbb / bbb<br />Not: aaa / bbb</span>
</code></div>
  </div>
 </div>
  <div class="note" id="20313">  <div class="votes">
    <div id="Vu20313">
    <a href="/manual/vote-note.php?id=20313&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd20313">
    <a href="/manual/vote-note.php?id=20313&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V20313" title="20% like this...">
    -3
    </div>
  </div>
  <a href="#20313" class="name">
  <strong class="user"><em>jochen_burkhard at web dot de</em></strong></a><a class="genanchor" href="#20313"> &para;</a><div class="date" title="2002-03-29 11:47"><strong>15 years ago</strong></div>
  <div class="text" id="Hcom20313">
<div class="phpcode"><code><span class="html">
Please don't forget:<br />values of included (or required) file variables are NOT available in the local script if the included file resides on a remote server:<br /><br />remotefile.php:<br /><br /><span class="default">&lt;?PHP<br />$paramVal</span><span class="keyword">=</span><span class="default">10</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />localfile.php:<br /><br /><span class="default">&lt;?PHP<br /></span><span class="keyword">include </span><span class="string">"<a href="http://example.com/remotefile.php" rel="nofollow" target="_blank">http://example.com/remotefile.php</a>"</span><span class="keyword">;<br />echo </span><span class="string">"remote-value= </span><span class="default">$paramVal</span><span class="string">"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />Will not work (!!)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="37427">  <div class="votes">
    <div id="Vu37427">
    <a href="/manual/vote-note.php?id=37427&amp;page=language.variables.scope&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd37427">
    <a href="/manual/vote-note.php?id=37427&amp;page=language.variables.scope&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V37427" title="0% like this...">
    -3
    </div>
  </div>
  <a href="#37427" class="name">
  <strong class="user"><em>Jack at soinsincere dot com</em></strong></a><a class="genanchor" href="#37427"> &para;</a><div class="date" title="2003-11-14 10:11"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom37427">
<div class="phpcode"><code><span class="html">
Alright, so you can't set a static variable with a reference.<br />However, you can set a static variable to an array with an element that is a reference:<br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">myReference </span><span class="keyword">{<br />&nbsp; &nbsp; function </span><span class="default">getOrSet</span><span class="keyword">(</span><span class="default">$array </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; static </span><span class="default">$myValue</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; if (!</span><span class="default">$array</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$myValue</span><span class="keyword">[</span><span class="default">0</span><span class="keyword">];&nbsp; &nbsp;&nbsp; </span><span class="comment">//Return reference in array<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">}<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$myValue </span><span class="keyword">= </span><span class="default">$array</span><span class="keyword">;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//Set static variable with array<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">static </span><span class="default">$myValue</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$static </span><span class="keyword">= </span><span class="string">"Dummy"</span><span class="keyword">;<br /><br /></span><span class="default">$dummy </span><span class="keyword">= new </span><span class="default">myReference</span><span class="keyword">;<br /></span><span class="default">$dummy</span><span class="keyword">-&gt;</span><span class="default">getOrSet</span><span class="keyword">(array(&amp;</span><span class="default">$static</span><span class="keyword">));<br /><br /></span><span class="default">$static </span><span class="keyword">= </span><span class="string">"Test"</span><span class="keyword">;<br />print </span><span class="default">$dummy</span><span class="keyword">-&gt;</span><span class="default">getOrSet</span><span class="keyword">();<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.variables.scope&amp;redirect=http://php.net/manual/en/language.variables.scope.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.variables.php">Variables</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.variables.basics.php" title="Basics">Basics</a>
                        </li>
                          
                        <li class="">
                            <a href="language.variables.predefined.php" title="Predefined Variables">Predefined Variables</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.variables.scope.php" title="Variable scope">Variable scope</a>
                        </li>
                          
                        <li class="">
                            <a href="language.variables.variable.php" title="Variable variables">Variable variables</a>
                        </li>
                          
                        <li class="">
                            <a href="language.variables.external.php" title="Variables From External Sources">Variables From External Sources</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

