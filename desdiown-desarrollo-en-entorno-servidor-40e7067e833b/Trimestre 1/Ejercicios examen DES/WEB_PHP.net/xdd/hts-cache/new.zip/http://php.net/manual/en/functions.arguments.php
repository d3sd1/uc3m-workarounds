<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Function arguments - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/functions.arguments.php">
 <link rel="shorturl" href="http://php.net/manual/en/functions.arguments.php">
 <link rel="alternate" href="http://php.net/manual/en/functions.arguments.php" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.functions.php">
 <link rel="prev" href="http://php.net/manual/en/functions.user-defined.php">
 <link rel="next" href="http://php.net/manual/en/functions.returning-values.php">

 <link rel="alternate" href="http://php.net/manual/en/functions.arguments.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/functions.arguments.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/functions.arguments.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/functions.arguments.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/functions.arguments.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/functions.arguments.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/functions.arguments.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/functions.arguments.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/functions.arguments.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/functions.arguments.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/functions.arguments.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="functions.returning-values.php">
          Returning values &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="functions.user-defined.php">
          &laquo; User-defined functions        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.functions.php'>Functions</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/functions.arguments.php' selected="selected">English</option>
            <option value='pt_BR/functions.arguments.php'>Brazilian Portuguese</option>
            <option value='zh/functions.arguments.php'>Chinese (Simplified)</option>
            <option value='fr/functions.arguments.php'>French</option>
            <option value='de/functions.arguments.php'>German</option>
            <option value='ja/functions.arguments.php'>Japanese</option>
            <option value='ro/functions.arguments.php'>Romanian</option>
            <option value='ru/functions.arguments.php'>Russian</option>
            <option value='es/functions.arguments.php'>Spanish</option>
            <option value='tr/functions.arguments.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/functions.arguments.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=functions.arguments">Report a Bug</a>
    </div>
  </div><div id="functions.arguments" class="sect1">
   <h2 class="title">Function arguments</h2>
 
   <p class="simpara">
    Information may be passed to functions via the argument list,
    which is a comma-delimited list of expressions. The arguments are
    evaluated from left to right.
   </p>

   <p class="para">
    PHP supports passing arguments by value (the default), <a href="functions.arguments.php#functions.arguments.by-reference" class="link">passing by
    reference</a>, and <a href="functions.arguments.php#functions.arguments.default" class="link">default argument
    values</a>. <a href="functions.arguments.php#functions.variable-arg-list" class="link">Variable-length
    argument lists</a> are also supported.
   </p>
   <p class="para">
    <div class="example" id="example-136">
     <p><strong>Example #1 Passing arrays to functions</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">takes_array</span><span style="color: #007700">(</span><span style="color: #0000BB">$input</span><span style="color: #007700">)<br />{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">"</span><span style="color: #0000BB">$input</span><span style="color: #007700">[</span><span style="color: #0000BB">0</span><span style="color: #007700">]</span><span style="color: #DD0000">&nbsp;+&nbsp;</span><span style="color: #0000BB">$input</span><span style="color: #007700">[</span><span style="color: #0000BB">1</span><span style="color: #007700">]</span><span style="color: #DD0000">&nbsp;=&nbsp;"</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$input</span><span style="color: #007700">[</span><span style="color: #0000BB">0</span><span style="color: #007700">]+</span><span style="color: #0000BB">$input</span><span style="color: #007700">[</span><span style="color: #0000BB">1</span><span style="color: #007700">];<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>   
   <div class="sect2" id="functions.arguments.by-reference">
    <h3 class="title">Passing arguments by reference</h3>
 
    <p class="simpara">
     By default, function arguments are passed by value (so that if
     the value of the argument within the function is changed, it does
     not get changed outside of the function). To allow a function to modify its
     arguments, they must be passed by reference.
    </p>
    <p class="para">
     To have an argument to a function always passed by reference, prepend an
     ampersand (&amp;) to the argument name in the function definition:
    </p>
    <p class="para">
     <div class="example" id="example-137">
      <p><strong>Example #2 Passing function parameters by reference</strong></p>
      <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">add_some_extra</span><span style="color: #007700">(&amp;</span><span style="color: #0000BB">$string</span><span style="color: #007700">)<br />{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$string&nbsp;</span><span style="color: #007700">.=&nbsp;</span><span style="color: #DD0000">'and&nbsp;something&nbsp;extra.'</span><span style="color: #007700">;<br />}<br /></span><span style="color: #0000BB">$str&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'This&nbsp;is&nbsp;a&nbsp;string,&nbsp;'</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">add_some_extra</span><span style="color: #007700">(</span><span style="color: #0000BB">$str</span><span style="color: #007700">);<br />echo&nbsp;</span><span style="color: #0000BB">$str</span><span style="color: #007700">;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;outputs&nbsp;'This&nbsp;is&nbsp;a&nbsp;string,&nbsp;and&nbsp;something&nbsp;extra.'<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
      </div>

     </div>
    </p>
   </div>
   <div class="sect2" id="functions.arguments.default">
    <h3 class="title">Default argument values</h3>
 
    <p class="para">
     A function may define C++-style default values for scalar
     arguments as follows:
    </p>
    <p class="para">
     <div class="example" id="example-138">
      <p><strong>Example #3 Use of default parameters in functions</strong></p>
      <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">makecoffee</span><span style="color: #007700">(</span><span style="color: #0000BB">$type&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">"cappuccino"</span><span style="color: #007700">)<br />{<br />&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #DD0000">"Making&nbsp;a&nbsp;cup&nbsp;of&nbsp;</span><span style="color: #0000BB">$type</span><span style="color: #DD0000">.\n"</span><span style="color: #007700">;<br />}<br />echo&nbsp;</span><span style="color: #0000BB">makecoffee</span><span style="color: #007700">();<br />echo&nbsp;</span><span style="color: #0000BB">makecoffee</span><span style="color: #007700">(</span><span style="color: #0000BB">null</span><span style="color: #007700">);<br />echo&nbsp;</span><span style="color: #0000BB">makecoffee</span><span style="color: #007700">(</span><span style="color: #DD0000">"espresso"</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
      </div>

      <div class="example-contents"><p>The above example will output:</p></div>
      <div class="example-contents screen">
<div class="cdata"><pre>
Making a cup of cappuccino.
Making a cup of .
Making a cup of espresso.
</pre></div>
      </div>
     </div>
    </p>
    <p class="para">
     PHP also allows the use of <span class="type"><a href="language.types.array.php" class="type array">array</a></span>s and the special type <strong><code>NULL</code></strong>
     as default values, for example:
    </p>
    <p class="para">
     <div class="example" id="example-139">
      <p><strong>Example #4 Using non-scalar types as default values</strong></p>
      <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">makecoffee</span><span style="color: #007700">(</span><span style="color: #0000BB">$types&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #DD0000">"cappuccino"</span><span style="color: #007700">),&nbsp;</span><span style="color: #0000BB">$coffeeMaker&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">NULL</span><span style="color: #007700">)<br />{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$device&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">is_null</span><span style="color: #007700">(</span><span style="color: #0000BB">$coffeeMaker</span><span style="color: #007700">)&nbsp;?&nbsp;</span><span style="color: #DD0000">"hands"&nbsp;</span><span style="color: #007700">:&nbsp;</span><span style="color: #0000BB">$coffeeMaker</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #DD0000">"Making&nbsp;a&nbsp;cup&nbsp;of&nbsp;"</span><span style="color: #007700">.</span><span style="color: #0000BB">join</span><span style="color: #007700">(</span><span style="color: #DD0000">",&nbsp;"</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$types</span><span style="color: #007700">).</span><span style="color: #DD0000">"&nbsp;with&nbsp;</span><span style="color: #0000BB">$device</span><span style="color: #DD0000">.\n"</span><span style="color: #007700">;<br />}<br />echo&nbsp;</span><span style="color: #0000BB">makecoffee</span><span style="color: #007700">();<br />echo&nbsp;</span><span style="color: #0000BB">makecoffee</span><span style="color: #007700">(array(</span><span style="color: #DD0000">"cappuccino"</span><span style="color: #007700">,&nbsp;</span><span style="color: #DD0000">"lavazza"</span><span style="color: #007700">),&nbsp;</span><span style="color: #DD0000">"teapot"</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
      </div>

     </div>
    
    </p>
    <p class="simpara">
     The default value must be a constant expression, not (for
     example) a variable, a class member or a function call.
    </p>
    <p class="para">
     Note that when using default arguments, any defaults should be on
     the right side of any non-default arguments; otherwise, things
     will not work as expected. Consider the following code snippet:
    </p>
    <p class="para">
     <div class="example" id="example-140">
      <p><strong>Example #5 Incorrect usage of default function arguments</strong></p>
      <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">makeyogurt</span><span style="color: #007700">(</span><span style="color: #0000BB">$type&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">"acidophilus"</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$flavour</span><span style="color: #007700">)<br />{<br />&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #DD0000">"Making&nbsp;a&nbsp;bowl&nbsp;of&nbsp;</span><span style="color: #0000BB">$type</span><span style="color: #DD0000">&nbsp;</span><span style="color: #0000BB">$flavour</span><span style="color: #DD0000">.\n"</span><span style="color: #007700">;<br />}<br />&nbsp;<br />echo&nbsp;</span><span style="color: #0000BB">makeyogurt</span><span style="color: #007700">(</span><span style="color: #DD0000">"raspberry"</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;won't&nbsp;work&nbsp;as&nbsp;expected<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
      </div>

      <div class="example-contents"><p>The above example will output:</p></div>
      <div class="example-contents screen">
<div class="cdata"><pre>
Warning: Missing argument 2 in call to makeyogurt() in 
/usr/local/etc/httpd/htdocs/phptest/functest.html on line 41
Making a bowl of raspberry .
</pre></div>
      </div>
     </div>
    </p>
    <p class="para">
     Now, compare the above with this:
    </p>
    <p class="para">
     <div class="example" id="example-141">
      <p><strong>Example #6 Correct usage of default function arguments</strong></p>
      <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">makeyogurt</span><span style="color: #007700">(</span><span style="color: #0000BB">$flavour</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$type&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">"acidophilus"</span><span style="color: #007700">)<br />{<br />&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #DD0000">"Making&nbsp;a&nbsp;bowl&nbsp;of&nbsp;</span><span style="color: #0000BB">$type</span><span style="color: #DD0000">&nbsp;</span><span style="color: #0000BB">$flavour</span><span style="color: #DD0000">.\n"</span><span style="color: #007700">;<br />}<br />&nbsp;<br />echo&nbsp;</span><span style="color: #0000BB">makeyogurt</span><span style="color: #007700">(</span><span style="color: #DD0000">"raspberry"</span><span style="color: #007700">);&nbsp;&nbsp;&nbsp;</span><span style="color: #FF8000">//&nbsp;works&nbsp;as&nbsp;expected<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
      </div>

      <div class="example-contents"><p>The above example will output:</p></div>
      <div class="example-contents screen">
<div class="cdata"><pre>
Making a bowl of acidophilus raspberry.
</pre></div>
      </div>
     </div>
    </p>
    <blockquote class="note"><p><strong class="note">Note</strong>: 
     <span class="simpara">
      As of PHP 5, arguments that are passed by reference may have a default value.
     </span>
    </p></blockquote>
   </div>

   <div class="sect2" id="functions.arguments.type-declaration">
    <h3 class="title">Type declarations</h3>

    <blockquote class="note"><p><strong class="note">Note</strong>: 
     <p class="para">
      Type declarations were also known as type hints in PHP 5.
     </p>
    </p></blockquote>

    <p class="para">
     Type declarations allow functions to require that parameters are of a certain type at call time.
     If the given value is of the incorrect type,
     then an error is generated: in PHP 5, this will be a recoverable fatal
     error, while PHP 7 will throw a <a href="class.typeerror.php" class="classname">TypeError</a>
     exception.
    </p>

    <p class="para">
     To specify a type declaration, the type name should be added before the
     parameter name. The declaration can be made to accept <strong><code>NULL</code></strong> values if
     the default value of the parameter is set to <strong><code>NULL</code></strong>.
    </p>

    <div class="sect3" id="functions.arguments.type-declaration.types">
     <h4 class="title">Valid types</h4>
     <table class="doctable informaltable">
      
       <thead>
        <tr>
         <th>Type</th>
         <th>Description</th>
         <th>Minimum PHP version</th>
        </tr>

       </thead>

       <tbody class="tbody">
        <tr>
         <td>Class/interface name</td>
         <td>
          The parameter must be an <a href="language.operators.type.php" class="link"><em>instanceof</em></a> the given class or interface
          name.
         </td>
         <td>PHP 5.0.0</td>
        </tr>

        <tr>
         <td><em>self</em></td>
         <td>
          The parameter must be an <a href="language.operators.type.php" class="link"><em>instanceof</em></a> the same class as the one the
          method is defined on. This can only be used on class and instance
          methods.
         </td>
         <td>PHP 5.0.0</td>
        </tr>

        <tr>
         <td><span class="type"><a href="language.types.array.php" class="type array">array</a></span></td>
         <td>
          The parameter must be an <span class="type"><a href="language.types.array.php" class="type array">array</a></span>.
         </td>
         <td>PHP 5.1.0</td>
        </tr>

        <tr>
         <td><span class="type"><a href="language.types.callable.php" class="type callable">callable</a></span></td>
         <td>
          The parameter must be a valid <span class="type"><a href="language.types.callable.php" class="type callable">callable</a></span>.
         </td>
         <td>PHP 5.4.0</td>
        </tr>

        <tr>
         <td><span class="type"><a href="language.types.boolean.php" class="type bool">bool</a></span></td>
         <td>
          The parameter must be a <span class="type"><a href="language.types.boolean.php" class="type boolean">boolean</a></span> value.
         </td>
         <td>PHP 7.0.0</td>
        </tr>

        <tr>
         <td><span class="type"><a href="language.types.float.php" class="type float">float</a></span></td>
         <td>
          The parameter must be a <span class="type"><a href="language.types.float.php" class="type float">float</a></span>ing point number.
         </td>
         <td>PHP 7.0.0</td>
        </tr>

        <tr>
         <td><span class="type"><a href="language.types.integer.php" class="type int">int</a></span></td>
         <td>
          The parameter must be an <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span>.
         </td>
         <td>PHP 7.0.0</td>
        </tr>

        <tr>
         <td><span class="type"><a href="language.types.string.php" class="type string">string</a></span></td>
         <td>
          The parameter must be a <span class="type"><a href="language.types.string.php" class="type string">string</a></span>.
         </td>
         <td>PHP 7.0.0</td>
        </tr>

        <tr>
         <td><em>iterable</em></td>
         <td>
          The parameter must be either an <span class="type"><a href="language.types.array.php" class="type array">array</a></span> or an <a href="language.operators.type.php" class="link"><em>instanceof</em></a> <a href="class.traversable.php" class="classname">Traversable</a>.
         </td>
         <td>PHP 7.1.0</td>
        </tr>

       </tbody>
      
     </table>


     <div class="warning"><strong class="warning">Warning</strong>
      <p class="para">
       Aliases for the above scalar types are not supported. Instead, they are
       treated as class or interface names. For example, using
       <em>boolean</em> as a parameter or return type will require
       an argument or return value that is an <a href="language.operators.type.php" class="link"><em>instanceof</em></a> the class or
       interface <em>boolean</em>, rather than of type
       <span class="type"><a href="language.types.boolean.php" class="type bool">bool</a></span>:
      </p>
      <p class="para">
       <div class="example" id="example-142">
        <div class="example-contents">
 <div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />&nbsp;</span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">test</span><span style="color: #007700">(</span><span style="color: #0000BB">boolean&nbsp;$param</span><span style="color: #007700">)&nbsp;{}<br />&nbsp;</span><span style="color: #0000BB">test</span><span style="color: #007700">(</span><span style="color: #0000BB">true</span><span style="color: #007700">);<br />&nbsp;</span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
        </div>

        <div class="example-contents"><p>The above example will output:</p></div>
        <div class="example-contents screen">
 <div class="cdata"><pre>
 Fatal error: Uncaught TypeError: Argument 1 passed to test() must be an instance of boolean, boolean given, called in - on line 1 and defined in -:1
 </pre></div>
        </div>
       </div>
      </p>
     </div>
    </div>

    <div class="sect3" id="functions.arguments.type-declaration.examples">
     <h4 class="title">Examples</h4>
     <div class="example" id="example-143">
      <p><strong>Example #7 Basic class type declaration</strong></p>
      <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">C&nbsp;</span><span style="color: #007700">{}<br />class&nbsp;</span><span style="color: #0000BB">D&nbsp;</span><span style="color: #007700">extends&nbsp;</span><span style="color: #0000BB">C&nbsp;</span><span style="color: #007700">{}<br /><br /></span><span style="color: #FF8000">//&nbsp;This&nbsp;doesn't&nbsp;extend&nbsp;C.<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">E&nbsp;</span><span style="color: #007700">{}<br /><br />function&nbsp;</span><span style="color: #0000BB">f</span><span style="color: #007700">(</span><span style="color: #0000BB">C&nbsp;$c</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #0000BB">get_class</span><span style="color: #007700">(</span><span style="color: #0000BB">$c</span><span style="color: #007700">).</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #0000BB">f</span><span style="color: #007700">(new&nbsp;</span><span style="color: #0000BB">C</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">f</span><span style="color: #007700">(new&nbsp;</span><span style="color: #0000BB">D</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">f</span><span style="color: #007700">(new&nbsp;</span><span style="color: #0000BB">E</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
      </div>

      <div class="example-contents"><p>The above example will output:</p></div>
      <div class="example-contents screen">
<div class="cdata"><pre>
C
D

Fatal error: Uncaught TypeError: Argument 1 passed to f() must be an instance of C, instance of E given, called in - on line 14 and defined in -:8
Stack trace:
#0 -(14): f(Object(E))
#1 {main}
  thrown in - on line 8
</pre></div>
      </div>
     </div>

     <div class="example" id="example-144">
      <p><strong>Example #8 Basic interface type declaration</strong></p>
      <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">interface&nbsp;</span><span style="color: #0000BB">I&nbsp;</span><span style="color: #007700">{&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">f</span><span style="color: #007700">();&nbsp;}<br />class&nbsp;</span><span style="color: #0000BB">C&nbsp;</span><span style="color: #007700">implements&nbsp;</span><span style="color: #0000BB">I&nbsp;</span><span style="color: #007700">{&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">f</span><span style="color: #007700">()&nbsp;{}&nbsp;}<br /><br /></span><span style="color: #FF8000">//&nbsp;This&nbsp;doesn't&nbsp;implement&nbsp;I.<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">E&nbsp;</span><span style="color: #007700">{}<br /><br />function&nbsp;</span><span style="color: #0000BB">f</span><span style="color: #007700">(</span><span style="color: #0000BB">I&nbsp;$i</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #0000BB">get_class</span><span style="color: #007700">(</span><span style="color: #0000BB">$i</span><span style="color: #007700">).</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #0000BB">f</span><span style="color: #007700">(new&nbsp;</span><span style="color: #0000BB">C</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">f</span><span style="color: #007700">(new&nbsp;</span><span style="color: #0000BB">E</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
      </div>

      <div class="example-contents"><p>The above example will output:</p></div>
      <div class="example-contents screen">
<div class="cdata"><pre>
C

Fatal error: Uncaught TypeError: Argument 1 passed to f() must implement interface I, instance of E given, called in - on line 13 and defined in -:8
Stack trace:
#0 -(13): f(Object(E))
#1 {main}
  thrown in - on line 8
</pre></div>
      </div>
     </div>

     <div class="example" id="example-145">
      <p><strong>Example #9 Nullable type declaration</strong></p>
      <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">C&nbsp;</span><span style="color: #007700">{}<br /><br />function&nbsp;</span><span style="color: #0000BB">f</span><span style="color: #007700">(</span><span style="color: #0000BB">C&nbsp;$c&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">null</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">$c</span><span style="color: #007700">);<br />}<br /><br /></span><span style="color: #0000BB">f</span><span style="color: #007700">(new&nbsp;</span><span style="color: #0000BB">C</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">f</span><span style="color: #007700">(</span><span style="color: #0000BB">null</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
      </div>

      <div class="example-contents"><p>The above example will output:</p></div>
      <div class="example-contents screen">
<div class="cdata"><pre>
object(C)#1 (0) {
}
NULL
</pre></div>
      </div>
     </div>
    </div>

    <div class="sect3" id="functions.arguments.type-declaration.strict">
     <h4 class="title">Strict typing</h4>

     <p class="para">
      By default, PHP will coerce values of the wrong type into the expected
      scalar type if possible. For example, a function that is given an
      <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span> for a parameter that expects a <span class="type"><a href="language.types.string.php" class="type string">string</a></span>
      will get a variable of type <span class="type"><a href="language.types.string.php" class="type string">string</a></span>.
     </p>

     <p class="para">
      It is possible to enable strict mode on a per-file basis. In strict
      mode, only a variable of exact type of the type declaration will be
      accepted, or a <a href="class.typeerror.php" class="classname">TypeError</a> will be thrown. The
      only exception to this rule is that an <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span> may be given
      to a function expecting a <span class="type"><a href="language.types.float.php" class="type float">float</a></span>. Function calls from within
      internal functions will not be affected by the <em>strict_types</em>
      declaration.
     </p>

     <p class="para">
      To enable strict mode, the <a href="control-structures.declare.php" class="link"><em>declare</em></a> statement is used with the
      <em>strict_types</em> declaration:
     </p>

     <div class="caution"><strong class="caution">Caution</strong>
      <p class="para">
       Enabling strict mode will also affect
       <a href="functions.returning-values.php#functions.returning-values.type-declaration" class="link">return type declarations</a>.
      </p>
     </div>

     <blockquote class="note"><p><strong class="note">Note</strong>: 
      <p class="para">
       Strict typing applies to function calls made from
       <em class="emphasis">within</em> the file with strict typing enabled, not to
       the functions declared within that file. If a file without strict
       typing enabled makes a call to a function that was defined in a file
       with strict typing, the caller&#039;s preference (weak typing) will be
       respected, and the value will be coerced.
      </p>
     </p></blockquote>

     <blockquote class="note"><p><strong class="note">Note</strong>: 
      <p class="para">
       Strict typing is only defined for scalar type declarations, and as
       such, requires PHP 7.0.0 or later, as scalar type declarations were
       added in that version.
      </p>
     </p></blockquote>

     <div class="example" id="example-146">
      <p><strong>Example #10 Strict typing</strong></p>
      <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">declare(</span><span style="color: #0000BB">strict_types</span><span style="color: #007700">=</span><span style="color: #0000BB">1</span><span style="color: #007700">);<br /><br />function&nbsp;</span><span style="color: #0000BB">sum</span><span style="color: #007700">(</span><span style="color: #0000BB">int&nbsp;$a</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">int&nbsp;$b</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">+&nbsp;</span><span style="color: #0000BB">$b</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">sum</span><span style="color: #007700">(</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">));<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">sum</span><span style="color: #007700">(</span><span style="color: #0000BB">1.5</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2.5</span><span style="color: #007700">));<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
      </div>

      <div class="example-contents"><p>The above example will output:</p></div>
      <div class="example-contents screen">
<div class="cdata"><pre>
int(3)

Fatal error: Uncaught TypeError: Argument 1 passed to sum() must be of the type integer, float given, called in - on line 9 and defined in -:4
Stack trace:
#0 -(9): sum(1.5, 2.5)
#1 {main}
  thrown in - on line 4
</pre></div>
      </div>
     </div>

     <div class="example" id="example-147">
      <p><strong>Example #11 Weak typing</strong></p>
      <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">sum</span><span style="color: #007700">(</span><span style="color: #0000BB">int&nbsp;$a</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">int&nbsp;$b</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">+&nbsp;</span><span style="color: #0000BB">$b</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">sum</span><span style="color: #007700">(</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">));<br /><br /></span><span style="color: #FF8000">//&nbsp;These&nbsp;will&nbsp;be&nbsp;coerced&nbsp;to&nbsp;integers:&nbsp;note&nbsp;the&nbsp;output&nbsp;below!<br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">sum</span><span style="color: #007700">(</span><span style="color: #0000BB">1.5</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2.5</span><span style="color: #007700">));<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
      </div>

      <div class="example-contents"><p>The above example will output:</p></div>
      <div class="example-contents screen">
<div class="cdata"><pre>
int(3)
int(3)
</pre></div>
      </div>
     </div>

     <div class="example" id="example-148">
      <p><strong>Example #12 Catching <a href="class.typeerror.php" class="classname">TypeError</a></strong></p>
      <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">declare(</span><span style="color: #0000BB">strict_types</span><span style="color: #007700">=</span><span style="color: #0000BB">1</span><span style="color: #007700">);<br /><br />function&nbsp;</span><span style="color: #0000BB">sum</span><span style="color: #007700">(</span><span style="color: #0000BB">int&nbsp;$a</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">int&nbsp;$b</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">+&nbsp;</span><span style="color: #0000BB">$b</span><span style="color: #007700">;<br />}<br /><br />try&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">sum</span><span style="color: #007700">(</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">));<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(</span><span style="color: #0000BB">sum</span><span style="color: #007700">(</span><span style="color: #0000BB">1.5</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2.5</span><span style="color: #007700">));<br />}&nbsp;catch&nbsp;(</span><span style="color: #0000BB">TypeError&nbsp;$e</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">'Error:&nbsp;'</span><span style="color: #007700">.</span><span style="color: #0000BB">$e</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">getMessage</span><span style="color: #007700">();<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
      </div>

      <div class="example-contents"><p>The above example will output:</p></div>
      <div class="example-contents screen">
<div class="cdata"><pre>
int(3)
Error: Argument 1 passed to sum() must be of the type integer, float given, called in - on line 10
</pre></div>
      </div>
     </div>
    </div>
   </div>
   <div class="sect2" id="functions.variable-arg-list">
    <h3 class="title">Variable-length argument lists</h3>

    <p class="simpara">
     PHP has support for variable-length argument lists in
     user-defined functions. This is implemented using the
     <em>...</em> token in PHP 5.6 and later, and using the
     <span class="function"><a href="function.func-num-args.php" class="function">func_num_args()</a></span>,
     <span class="function"><a href="function.func-get-arg.php" class="function">func_get_arg()</a></span>, and
     <span class="function"><a href="function.func-get-args.php" class="function">func_get_args()</a></span> functions in PHP 5.5 and earlier.
    </p>

    <div class="sect3" id="functions.variable-arg-list.new">
     <h4 class="title"><em>...</em> in PHP 5.6+</h4>

     <p class="para">
      In PHP 5.6 and later, argument lists may include the
      <em>...</em> token to denote that the function accepts a
      variable number of arguments. The arguments will be passed into the
      given variable as an array; for example:

      <div class="example" id="example-149">
       <p><strong>Example #13 Using <em>...</em> to access variable arguments</strong></p>
       <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">sum</span><span style="color: #007700">(...</span><span style="color: #0000BB">$numbers</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$acc&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">0</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;foreach&nbsp;(</span><span style="color: #0000BB">$numbers&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">$n</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$acc&nbsp;</span><span style="color: #007700">+=&nbsp;</span><span style="color: #0000BB">$n</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">$acc</span><span style="color: #007700">;<br />}<br /><br />echo&nbsp;</span><span style="color: #0000BB">sum</span><span style="color: #007700">(</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">3</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">4</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
       </div>

       <div class="example-contents"><p>The above example will output:</p></div>
       <div class="example-contents screen">
<div class="cdata"><pre>
10
</pre></div>
       </div>
      </div>
     </p>

     <p class="para">
      You can also use <em>...</em> when calling functions to unpack
      an <span class="type"><a href="language.types.array.php" class="type array">array</a></span> or <a href="class.traversable.php" class="classname">Traversable</a> variable or
      literal into the argument list:

      <div class="example" id="example-150">
       <p><strong>Example #14 Using <em>...</em> to provide arguments</strong></p>
       <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">add</span><span style="color: #007700">(</span><span style="color: #0000BB">$a</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$b</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">+&nbsp;</span><span style="color: #0000BB">$b</span><span style="color: #007700">;<br />}<br /><br />echo&nbsp;</span><span style="color: #0000BB">add</span><span style="color: #007700">(...[</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">]).</span><span style="color: #DD0000">"\n"</span><span style="color: #007700">;<br /><br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;[</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">];<br />echo&nbsp;</span><span style="color: #0000BB">add</span><span style="color: #007700">(...</span><span style="color: #0000BB">$a</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
       </div>

       <div class="example-contents"><p>The above example will output:</p></div>
       <div class="example-contents screen">
<div class="cdata"><pre>
3
3
</pre></div>
       </div>
      </div>
     </p>

     <p class="para">
      You may specify normal positional arguments before the
      <em>...</em> token. In this case, only the trailing arguments
      that don&#039;t match a positional argument will be added to the array
      generated by <em>...</em>.
     </p>

     <p class="para">
      It is also possible to add a
      <a href="language.oop5.typehinting.php" class="link">type hint</a> before the
      <em>...</em> token. If this is present, then all arguments
      captured by <em>...</em> must be objects of the hinted class.

      <div class="example" id="example-151">
       <p><strong>Example #15 Type hinted variable arguments</strong></p>
       <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">total_intervals</span><span style="color: #007700">(</span><span style="color: #0000BB">$unit</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">DateInterval&nbsp;</span><span style="color: #007700">...</span><span style="color: #0000BB">$intervals</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$time&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">0</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;foreach&nbsp;(</span><span style="color: #0000BB">$intervals&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">$interval</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$time&nbsp;</span><span style="color: #007700">+=&nbsp;</span><span style="color: #0000BB">$interval</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">$unit</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">$time</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">DateInterval</span><span style="color: #007700">(</span><span style="color: #DD0000">'P1D'</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">$b&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">DateInterval</span><span style="color: #007700">(</span><span style="color: #DD0000">'P2D'</span><span style="color: #007700">);<br />echo&nbsp;</span><span style="color: #0000BB">total_intervals</span><span style="color: #007700">(</span><span style="color: #DD0000">'d'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$a</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">$b</span><span style="color: #007700">).</span><span style="color: #DD0000">'&nbsp;days'</span><span style="color: #007700">;<br /><br /></span><span style="color: #FF8000">//&nbsp;This&nbsp;will&nbsp;fail,&nbsp;since&nbsp;null&nbsp;isn't&nbsp;a&nbsp;DateInterval&nbsp;object.<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #0000BB">total_intervals</span><span style="color: #007700">(</span><span style="color: #DD0000">'d'</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">null</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
       </div>

       <div class="example-contents"><p>The above example will output:</p></div>
       <div class="example-contents screen">
<div class="cdata"><pre>
3 days
Catchable fatal error: Argument 2 passed to total_intervals() must be an instance of DateInterval, null given, called in - on line 14 and defined in - on line 2
</pre></div>
       </div>
      </div>
     </p>

     <p class="para">
      Finally, you may also pass variable arguments
      <a href="functions.arguments.php#functions.arguments.by-reference" class="link">by reference</a> by
      prefixing the <em>...</em> with an ampersand
      (<em>&amp;</em>).
     </p>
    </div>

    <div class="sect3" id="functions.variable-arg-list.old">
     <h4 class="title">Older versions of PHP</h4>

     <p class="para">
      No special syntax is required to note that a function is variadic;
      however access to the function&#039;s arguments must use
      <span class="function"><a href="function.func-num-args.php" class="function">func_num_args()</a></span>, <span class="function"><a href="function.func-get-arg.php" class="function">func_get_arg()</a></span>
      and <span class="function"><a href="function.func-get-args.php" class="function">func_get_args()</a></span>.
     </p>

     <p class="para">
      The first example above would be implemented as follows in PHP 5.5 and
      earlier:

      <div class="example" id="example-152">
       <p><strong>Example #16 Accessing variable arguments in PHP 5.5 and earlier</strong></p>
       <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">sum</span><span style="color: #007700">()&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$acc&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">0</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;foreach&nbsp;(</span><span style="color: #0000BB">func_get_args</span><span style="color: #007700">()&nbsp;as&nbsp;</span><span style="color: #0000BB">$n</span><span style="color: #007700">)&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$acc&nbsp;</span><span style="color: #007700">+=&nbsp;</span><span style="color: #0000BB">$n</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">$acc</span><span style="color: #007700">;<br />}<br /><br />echo&nbsp;</span><span style="color: #0000BB">sum</span><span style="color: #007700">(</span><span style="color: #0000BB">1</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">3</span><span style="color: #007700">,&nbsp;</span><span style="color: #0000BB">4</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
       </div>

       <div class="example-contents"><p>The above example will output:</p></div>
       <div class="example-contents screen">
<div class="cdata"><pre>
10
</pre></div>
       </div>
      </div>
     </p>
    </div>

   </div>
  </div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=functions.arguments&amp;redirect=http://php.net/manual/en/functions.arguments.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">43 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="116968">  <div class="votes">
    <div id="Vu116968">
    <a href="/manual/vote-note.php?id=116968&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116968">
    <a href="/manual/vote-note.php?id=116968&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116968" title="82% like this...">
    50
    </div>
  </div>
  <a href="#116968" class="name">
  <strong class="user"><em>php at richardneill dot org</em></strong></a><a class="genanchor" href="#116968"> &para;</a><div class="date" title="2015-03-28 07:24"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom116968">
<div class="phpcode"><code><span class="html">
To experiment on performance of pass-by-reference and pass-by-value, I used this&nbsp; script. Conclusions are below. <br /><br />#!/usr/bin/php<br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">sum</span><span class="keyword">(</span><span class="default">$array</span><span class="keyword">,</span><span class="default">$max</span><span class="keyword">){&nbsp;&nbsp; </span><span class="comment">//For Reference, use:&nbsp; "&amp;$array"<br />&nbsp; &nbsp; </span><span class="default">$sum</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">;<br />&nbsp; &nbsp; for (</span><span class="default">$i</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">&lt;</span><span class="default">2</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">++){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">#$array[$i]++;&nbsp; &nbsp; &nbsp; &nbsp; //Uncomment this line to modify the array within the function.<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$sum </span><span class="keyword">+= </span><span class="default">$array</span><span class="keyword">[</span><span class="default">$i</span><span class="keyword">];&nbsp; <br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; return (</span><span class="default">$sum</span><span class="keyword">);<br />}<br /><br /></span><span class="default">$max </span><span class="keyword">= </span><span class="default">1E7&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">//10 M data points.<br /></span><span class="default">$data </span><span class="keyword">= </span><span class="default">range</span><span class="keyword">(</span><span class="default">0</span><span class="keyword">,</span><span class="default">$max</span><span class="keyword">,</span><span class="default">1</span><span class="keyword">);<br /><br /></span><span class="default">$start </span><span class="keyword">= </span><span class="default">microtime</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">);<br />for (</span><span class="default">$x </span><span class="keyword">= </span><span class="default">0 </span><span class="keyword">; </span><span class="default">$x </span><span class="keyword">&lt; </span><span class="default">100</span><span class="keyword">; </span><span class="default">$x</span><span class="keyword">++){<br />&nbsp; &nbsp; </span><span class="default">$sum </span><span class="keyword">= </span><span class="default">sum</span><span class="keyword">(</span><span class="default">$data</span><span class="keyword">, </span><span class="default">$max</span><span class="keyword">);<br />}<br /></span><span class="default">$end </span><span class="keyword">=&nbsp; </span><span class="default">microtime</span><span class="keyword">(</span><span class="default">true</span><span class="keyword">);<br />echo </span><span class="string">"Time: "</span><span class="keyword">.(</span><span class="default">$end </span><span class="keyword">- </span><span class="default">$start</span><span class="keyword">).</span><span class="string">" s\n"</span><span class="keyword">;<br /><br /></span><span class="comment">/* Run times:<br />#&nbsp; &nbsp; PASS BY&nbsp; &nbsp; MODIFIED?&nbsp;&nbsp; Time<br />-&nbsp; &nbsp; -------&nbsp; &nbsp; ---------&nbsp;&nbsp; ----<br />1&nbsp; &nbsp; value&nbsp; &nbsp; &nbsp; no&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 56 us<br />2&nbsp; &nbsp; reference&nbsp; no&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 58 us<br /><br />3&nbsp; &nbsp; valuue&nbsp; &nbsp;&nbsp; yes&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; 129 s<br />4&nbsp; &nbsp; reference&nbsp; yes&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; 66 us<br /><br />Conclusions:<br /><br />1. PHP is already smart about zero-copy / copy-on-write. A function call does NOT copy the data unless it needs to; the data is<br />&nbsp;&nbsp; only copied on write. That's why&nbsp; #1 and #2 take similar times, whereas #3 takes 2 million times longer than #4.<br />&nbsp;&nbsp; [You never need to use &amp;$array to ask the compiler to do a zero-copy optimisation; it can work that out for itself.]<br /><br />2. You do use &amp;$array&nbsp; to tell the compiler "it is OK for the function to over-write my argument in place, I don't need the original<br />&nbsp;&nbsp; any more." This can make a huge difference to performance when we have large amounts of memory to copy.<br />&nbsp;&nbsp; (This is the only way it is done in C, arrays are always passed as pointers)<br /><br />3. The other use of &amp; is as a way to specify where data should be *returned*. (e.g. as used by exec() ).<br />&nbsp;&nbsp; (This is a C-like way of passing pointers for outputs, whereas PHP functions normally return complex types, or multiple answers<br />&nbsp;&nbsp; in an array)<br /><br />4. It's&nbsp; unhelpful that only the function definition has &amp;. The caller should have it, at least as syntactic sugar. Otherwise<br />&nbsp;&nbsp; it leads to unreadable code: because the person reading the function call doesn't expect it to pass by reference. At the moment,<br />&nbsp;&nbsp; it's necessary to write a by-reference function call with a comment, thus:<br />&nbsp; &nbsp; $sum = sum($data,$max);&nbsp; //warning, $data passed by reference, and may be modified.<br /><br />5. Sometimes, pass by reference could be at the choice of the caller, NOT the function definitition. PHP doesn't allow it, but it<br />&nbsp;&nbsp; would be meaningful for the caller to decide to pass data in as a reference. i.e. "I'm done with the variable, it's OK to stomp<br />&nbsp;&nbsp; on it in memory".<br />*/<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119724">  <div class="votes">
    <div id="Vu119724">
    <a href="/manual/vote-note.php?id=119724&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119724">
    <a href="/manual/vote-note.php?id=119724&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119724" title="80% like this...">
    18
    </div>
  </div>
  <a href="#119724" class="name">
  <strong class="user"><em>gabriel at figdice dot org</em></strong></a><a class="genanchor" href="#119724"> &para;</a><div class="date" title="2016-08-11 07:05"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119724">
<div class="phpcode"><code><span class="html">
A function's argument that is an object, will have its properties modified by the function although you don't need to pass it by reference.<br /><br /><span class="default">&lt;?php<br />$x </span><span class="keyword">= new </span><span class="default">stdClass</span><span class="keyword">();<br /></span><span class="default">$x</span><span class="keyword">-&gt;</span><span class="default">prop </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br /><br />function </span><span class="default">f </span><span class="keyword">( </span><span class="default">$o </span><span class="keyword">) </span><span class="comment">// Notice the absence of &amp;<br /></span><span class="keyword">{<br />&nbsp; </span><span class="default">$o</span><span class="keyword">-&gt;</span><span class="default">prop </span><span class="keyword">++;<br />}<br /><br /></span><span class="default">f</span><span class="keyword">(</span><span class="default">$x</span><span class="keyword">);<br /><br />echo </span><span class="default">$x</span><span class="keyword">-&gt;</span><span class="default">prop</span><span class="keyword">; </span><span class="comment">// shows: 2<br /></span><span class="default">?&gt;<br /></span><br />This is different for arrays:<br /><br /><span class="default">&lt;?php<br />$y </span><span class="keyword">= [ </span><span class="string">'prop' </span><span class="keyword">=&gt; </span><span class="default">1 </span><span class="keyword">];<br /><br />function </span><span class="default">g</span><span class="keyword">( </span><span class="default">$a </span><span class="keyword">)<br />{<br />&nbsp; </span><span class="default">$a</span><span class="keyword">[</span><span class="string">'prop'</span><span class="keyword">] ++;<br />&nbsp; echo </span><span class="default">$a</span><span class="keyword">[</span><span class="string">'prop'</span><span class="keyword">];&nbsp; </span><span class="comment">// shows: 2<br /></span><span class="keyword">}<br /><br /></span><span class="default">g</span><span class="keyword">(</span><span class="default">$y</span><span class="keyword">);<br /><br />echo </span><span class="default">$y</span><span class="keyword">[</span><span class="string">'prop'</span><span class="keyword">];&nbsp; </span><span class="comment">// shows: 1<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="98425">  <div class="votes">
    <div id="Vu98425">
    <a href="/manual/vote-note.php?id=98425&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd98425">
    <a href="/manual/vote-note.php?id=98425&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V98425" title="64% like this...">
    21
    </div>
  </div>
  <a href="#98425" class="name">
  <strong class="user"><em>carlos at wfmh dot org dot pl dot REMOVE dot COM</em></strong></a><a class="genanchor" href="#98425"> &para;</a><div class="date" title="2010-06-15 04:48"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom98425">
<div class="phpcode"><code><span class="html">
You can use (very) limited signatures for your functions, specifing type of arguments allowed. <br /><br />For example:<br /><br />public function Right( My_Class $a, array $b )<br /><br />tells first argument have to by object of My_Class, second an array. My_Class means that you can pass also object of class that either extends My_Class or implements (if My_Class is abstract class) My_Class. If you need exactly My_Class you need to either make it final, or add some code to check what $a really.<br /><br />Also note, that (unfortunately) "array" is the only built-in type you can use in signature. Any other types i.e.:<br /><br />public function Wrong( string $a, boolean $b )<br /><br />will cause an error, because PHP will complain that $a is not an *object* of class string (and $b is not an object of class boolean).<br /><br />So if you need to know if $a is a string or $b bool, you need to write some code in your function body and i.e. throw exception if you detect type mismatch (or you can try to cast if it's doable).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="58331">  <div class="votes">
    <div id="Vu58331">
    <a href="/manual/vote-note.php?id=58331&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd58331">
    <a href="/manual/vote-note.php?id=58331&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V58331" title="66% like this...">
    13
    </div>
  </div>
  <a href="#58331" class="name">
  <strong class="user"><em>Sergio Santana: ssantana at tlaloc dot imta dot mx</em></strong></a><a class="genanchor" href="#58331"> &para;</a><div class="date" title="2005-10-31 02:59"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom58331">
<div class="phpcode"><code><span class="html">
PASSING A "VARIABLE-LENGTH ARGUMENT LIST OF REFERENCES" TO A FUNCTION<br />As of PHP 5, Call-time pass-by-reference has been deprecated, this represents no problem in most cases, since instead of calling a function like this:<br />&nbsp;&nbsp; myfunction($arg1, &amp;$arg2, &amp;$arg3);<br /><br />you can call it<br />&nbsp;&nbsp; myfunction($arg1, $arg2, $arg3);<br /><br />provided you have defined your function as <br />&nbsp;&nbsp; function myfuncion($a1, &amp;$a2, &amp;$a3) { // so &amp;$a2 and &amp;$a3 are <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; // declared to be refs.<br />&nbsp; &nbsp; ... &lt;function-code&gt;<br />&nbsp;&nbsp; }<br /><br />However, what happens if you wanted to pass an undefined number of references, i.e., something like:<br />&nbsp;&nbsp; myfunction(&amp;$arg1, &amp;$arg2, ..., &amp;$arg-n);?<br />This doesn't work in PHP 5 anymore.<br /><br />In the following code I tried to amend this by using the <br />array() language-construct as the actual argument in the <br />call to the function.<br /><br /><span class="default">&lt;?php<br /><br />&nbsp; </span><span class="keyword">function </span><span class="default">aa </span><span class="keyword">(</span><span class="default">$A</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="comment">// This function increments each <br />&nbsp; &nbsp; // "pseudo-argument" by 2s<br />&nbsp; &nbsp; </span><span class="keyword">foreach (</span><span class="default">$A </span><span class="keyword">as &amp;</span><span class="default">$x</span><span class="keyword">) { <br />&nbsp; &nbsp; &nbsp; </span><span class="default">$x </span><span class="keyword">+= </span><span class="default">2</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; }<br /> <br />&nbsp; </span><span class="default">$x </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">; </span><span class="default">$y </span><span class="keyword">= </span><span class="default">2</span><span class="keyword">; </span><span class="default">$z </span><span class="keyword">= </span><span class="default">3</span><span class="keyword">;<br />&nbsp; <br />&nbsp; </span><span class="default">aa</span><span class="keyword">(array(&amp;</span><span class="default">$x</span><span class="keyword">, &amp;</span><span class="default">$y</span><span class="keyword">, &amp;</span><span class="default">$z</span><span class="keyword">));<br />&nbsp; echo </span><span class="string">"--</span><span class="default">$x</span><span class="string">--</span><span class="default">$y</span><span class="string">--</span><span class="default">$z</span><span class="string">--\n"</span><span class="keyword">;<br />&nbsp; </span><span class="comment">// This will output:<br />&nbsp; // --3--4--5--<br /></span><span class="default">?&gt;<br /></span><br />I hope this is useful.<br /><br />Sergio.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114065">  <div class="votes">
    <div id="Vu114065">
    <a href="/manual/vote-note.php?id=114065&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114065">
    <a href="/manual/vote-note.php?id=114065&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114065" title="68% like this...">
    8
    </div>
  </div>
  <a href="#114065" class="name">
  <strong class="user"><em>Horst Schirmeier</em></strong></a><a class="genanchor" href="#114065"> &para;</a><div class="date" title="2014-01-08 11:58"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114065">
<div class="phpcode"><code><span class="html">
Editor's note: what is expected here by the parser is a non-evaluated expression. An operand and two constants requires evaluation, which is not done by the parser. However, this feature is included as of PHP 5.6.0. See this page for more information: <a href="http://php.net/migration56.new-features#migration56.new-features.const-scalar-exprs" rel="nofollow" target="_blank">http://php.net/migration56.new-features#migration56.new-features.const-scalar-exprs</a><br />--------<br /><br />"The default value must be a constant expression" is misleading (or even wrong).&nbsp; PHP 5.4.4 fails to parse this function definition:<br /><br />function htmlspecialchars_latin1($s, $flags = ENT_COMPAT | ENT_HTML401) {}<br /><br />This yields a " PHP Parse error:&nbsp; syntax error, unexpected '|', expecting ')' " although ENT_COMPAT|ENT_HTML401 is certainly what a compiler-affine person would call a "constant expression".<br /><br />The obvious workaround is to use a single special value ($flags = NULL) as the default, and to set it to the desired value in the function's body (if ($flags === NULL) { $flags = ENT_COMPAT | ENT_HTML401; }).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="62803">  <div class="votes">
    <div id="Vu62803">
    <a href="/manual/vote-note.php?id=62803&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd62803">
    <a href="/manual/vote-note.php?id=62803&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V62803" title="63% like this...">
    6
    </div>
  </div>
  <a href="#62803" class="name">
  <strong class="user"><em>jcaplan at bogus dot amazon dot com</em></strong></a><a class="genanchor" href="#62803"> &para;</a><div class="date" title="2006-03-09 03:11"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom62803">
<div class="phpcode"><code><span class="html">
In function calls, PHP clearly distinguishes between missing arguments and present but empty arguments.&nbsp; Thus:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">f</span><span class="keyword">( </span><span class="default">$x </span><span class="keyword">= </span><span class="default">4 </span><span class="keyword">) { echo </span><span class="default">$x </span><span class="keyword">. </span><span class="string">"\\n"</span><span class="keyword">; }<br /></span><span class="default">f</span><span class="keyword">(); </span><span class="comment">// prints 4<br /></span><span class="default">f</span><span class="keyword">( </span><span class="default">null </span><span class="keyword">); </span><span class="comment">// prints blank line<br /></span><span class="default">f</span><span class="keyword">( </span><span class="default">$y </span><span class="keyword">); </span><span class="comment">// $y undefined, prints blank line<br /></span><span class="default">?&gt;<br /></span><br />The utility of the optional argument feature is thus somewhat diminished.&nbsp; Suppose you want to call the function f many times from function g, allowing the caller of g to specify if f should be called with a specific value or with its default value:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">f</span><span class="keyword">( </span><span class="default">$x </span><span class="keyword">= </span><span class="default">4 </span><span class="keyword">) {echo </span><span class="default">$x </span><span class="keyword">. </span><span class="string">"\\n"</span><span class="keyword">; }<br /><br /></span><span class="comment">// option 1: cut and paste the default value from f's interface into g's<br /></span><span class="keyword">function </span><span class="default">g</span><span class="keyword">( </span><span class="default">$x </span><span class="keyword">= </span><span class="default">4 </span><span class="keyword">) { </span><span class="default">f</span><span class="keyword">( </span><span class="default">$x </span><span class="keyword">); </span><span class="default">f</span><span class="keyword">( </span><span class="default">$x </span><span class="keyword">); }<br /><br /></span><span class="comment">// option 2: branch based on input to g<br /></span><span class="keyword">function </span><span class="default">g</span><span class="keyword">( </span><span class="default">$x </span><span class="keyword">= </span><span class="default">null </span><span class="keyword">) { if ( !isset( </span><span class="default">$x </span><span class="keyword">) ) { </span><span class="default">f</span><span class="keyword">(); </span><span class="default">f</span><span class="keyword">() } else { </span><span class="default">f</span><span class="keyword">( </span><span class="default">$x </span><span class="keyword">); </span><span class="default">f</span><span class="keyword">( </span><span class="default">$x </span><span class="keyword">); } }<br /></span><span class="default">?&gt;<br /></span><br />Both options suck.<br /><br />The best approach, it seems to me, is to always use a sentinel like null as the default value of an optional argument.&nbsp; This way, callers like g and g's clients have many options, and furthermore, callers always know how to omit arguments so they can omit one in the middle of the parameter list.<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">f</span><span class="keyword">( </span><span class="default">$x </span><span class="keyword">= </span><span class="default">null </span><span class="keyword">) { if ( !isset( </span><span class="default">$x </span><span class="keyword">) ) </span><span class="default">$x </span><span class="keyword">= </span><span class="default">4</span><span class="keyword">; echo </span><span class="default">$x </span><span class="keyword">. </span><span class="string">"\\n"</span><span class="keyword">; }<br /><br />function </span><span class="default">g</span><span class="keyword">( </span><span class="default">$x </span><span class="keyword">= </span><span class="default">null </span><span class="keyword">) { </span><span class="default">f</span><span class="keyword">( </span><span class="default">$x </span><span class="keyword">); </span><span class="default">f</span><span class="keyword">( </span><span class="default">$x </span><span class="keyword">); }<br /><br /></span><span class="default">f</span><span class="keyword">(); </span><span class="comment">// prints 4<br /></span><span class="default">f</span><span class="keyword">( </span><span class="default">null </span><span class="keyword">); </span><span class="comment">// prints 4<br /></span><span class="default">f</span><span class="keyword">( </span><span class="default">$y </span><span class="keyword">); </span><span class="comment">// $y undefined, prints 4<br /></span><span class="default">g</span><span class="keyword">(); </span><span class="comment">// prints 4 twice<br /></span><span class="default">g</span><span class="keyword">( </span><span class="default">null </span><span class="keyword">); </span><span class="comment">// prints 4 twice<br /></span><span class="default">g</span><span class="keyword">( </span><span class="default">5 </span><span class="keyword">); </span><span class="comment">// prints 5 twice<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="88258">  <div class="votes">
    <div id="Vu88258">
    <a href="/manual/vote-note.php?id=88258&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd88258">
    <a href="/manual/vote-note.php?id=88258&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V88258" title="60% like this...">
    9
    </div>
  </div>
  <a href="#88258" class="name">
  <strong class="user"><em>herenvardoREMOVEatSTUFFgmailINdotCAPScom</em></strong></a><a class="genanchor" href="#88258"> &para;</a><div class="date" title="2009-01-17 12:48"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom88258">
<div class="phpcode"><code><span class="html">
There is a nice trick to emulate variables/function calls/etc as default values:<br /><br /><span class="default">&lt;?php<br />$myVar </span><span class="keyword">= </span><span class="string">"Using a variable as a default value!"</span><span class="keyword">;<br /><br />function </span><span class="default">myFunction</span><span class="keyword">(</span><span class="default">$myArgument</span><span class="keyword">=</span><span class="default">null</span><span class="keyword">) {<br />&nbsp; &nbsp; if(</span><span class="default">$myArgument</span><span class="keyword">===</span><span class="default">null</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$myArgument </span><span class="keyword">= </span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">"myVar"</span><span class="keyword">];<br />&nbsp; &nbsp; echo </span><span class="default">$myArgument</span><span class="keyword">;<br />}<br /><br /></span><span class="comment">// Outputs "Hello World!":<br /></span><span class="default">myFunction</span><span class="keyword">(</span><span class="string">"Hello World!"</span><span class="keyword">);<br /></span><span class="comment">// Outputs "Using a variable as a default value!":<br /></span><span class="default">myFunction</span><span class="keyword">();<br /></span><span class="comment">// Outputs the same again:<br /></span><span class="default">myFunction</span><span class="keyword">(</span><span class="default">null</span><span class="keyword">);<br /></span><span class="comment">// Outputs "Changing the variable affects the function!":<br /></span><span class="default">$myVar </span><span class="keyword">= </span><span class="string">"Changing the variable affects the function!"</span><span class="keyword">;<br /></span><span class="default">myFunction</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span>In general, you define the default value as null (or whatever constant you like), and then check for that value at the start of the function, computing the actual default if needed, before using the argument for actual work.<br />Building upon this, it's also easy to provide fallback behaviors when the argument given is not valid: simply put a default that is known to be invalid in the prototype, and then check for general validity instead of a specific value: if the argument is not valid (either not given, so the default is used, or an invalid value was given), the function computes a (valid) default to use.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="74676">  <div class="votes">
    <div id="Vu74676">
    <a href="/manual/vote-note.php?id=74676&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd74676">
    <a href="/manual/vote-note.php?id=74676&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V74676" title="56% like this...">
    6
    </div>
  </div>
  <a href="#74676" class="name">
  <strong class="user"><em>conciseusa at yahoo[nospammm] dot com</em></strong></a><a class="genanchor" href="#74676"> &para;</a><div class="date" title="2007-04-22 08:03"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom74676">
<div class="phpcode"><code><span class="html">
With regards to:<br /><br />It is also possible to force a parameter type using this syntax. I couldn't see it in the documentation.<br />function foo(myclass par) { }<br /><br />I think you are referring to Type Hinting. It is documented here: <a href="http://ch2.php.net/language.oop5.typehinting" rel="nofollow" target="_blank">http://ch2.php.net/language.oop5.typehinting</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="71198">  <div class="votes">
    <div id="Vu71198">
    <a href="/manual/vote-note.php?id=71198&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd71198">
    <a href="/manual/vote-note.php?id=71198&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V71198" title="55% like this...">
    5
    </div>
  </div>
  <a href="#71198" class="name">
  <strong class="user"><em>John</em></strong></a><a class="genanchor" href="#71198"> &para;</a><div class="date" title="2006-11-15 03:20"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom71198">
<div class="phpcode"><code><span class="html">
This might be documented somewhere OR obvious to most, but when passing an argument by reference (as of PHP 5.04) you can assign a value to an argument variable in the function call. For example:<br /><br />function my_function($arg1, &amp;$arg2) {<br />&nbsp; if ($arg1 == true) {<br />&nbsp; &nbsp; $arg2 = true;<br />&nbsp; }<br />}<br />my_function(true, $arg2 = false);<br />echo $arg2;<br /><br />outputs 1 (true)<br /><br />my_function(false, $arg2 = false);<br />echo $arg2;<br /><br />outputs 0 (false)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="97037">  <div class="votes">
    <div id="Vu97037">
    <a href="/manual/vote-note.php?id=97037&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd97037">
    <a href="/manual/vote-note.php?id=97037&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V97037" title="53% like this...">
    2
    </div>
  </div>
  <a href="#97037" class="name">
  <strong class="user"><em>mracky at pacbell dot net</em></strong></a><a class="genanchor" href="#97037"> &para;</a><div class="date" title="2010-03-29 09:40"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom97037">
<div class="phpcode"><code><span class="html">
Nothing was written here about argument types as part of the function definition.<br /><br />When working with classes, the class name can be used as argument type.&nbsp; This acts as a reminder to the user of the class, as well as a prototype for php&nbsp; control. (At least in php 5 -- did not check 4).<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">foo </span><span class="keyword">{<br />&nbsp; public </span><span class="default">$data</span><span class="keyword">;<br />&nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$dd</span><span class="keyword">)<br />&nbsp; {<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">data </span><span class="keyword">= </span><span class="default">$dd</span><span class="keyword">;<br />&nbsp; }<br />};<br /><br />class </span><span class="default">test </span><span class="keyword">{<br />&nbsp; public </span><span class="default">$bar</span><span class="keyword">;<br /><br />&nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">foo $arg</span><span class="keyword">) </span><span class="comment">// Strict typing for argument<br />&nbsp; </span><span class="keyword">{<br />&nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">bar </span><span class="keyword">= </span><span class="default">$arg</span><span class="keyword">;<br />&nbsp; }<br />&nbsp; public function </span><span class="default">dump</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; echo </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">bar</span><span class="keyword">-&gt;</span><span class="default">data </span><span class="keyword">. </span><span class="string">"\n"</span><span class="keyword">;<br />&nbsp; }<br /><br />};<br /><br /></span><span class="default">$A </span><span class="keyword">= new </span><span class="default">foo</span><span class="keyword">(</span><span class="default">25</span><span class="keyword">);<br /></span><span class="default">$Test1 </span><span class="keyword">= new </span><span class="default">test</span><span class="keyword">(</span><span class="default">$A</span><span class="keyword">);<br /></span><span class="default">$Test1</span><span class="keyword">-&gt;</span><span class="default">dump</span><span class="keyword">();<br /></span><span class="default">$Test2 </span><span class="keyword">= new </span><span class="default">test</span><span class="keyword">(</span><span class="default">10</span><span class="keyword">); </span><span class="comment">// wrong argument for testing<br /><br /></span><span class="default">?&gt;<br /></span>outputs:<br />25<br />PHP Fatal error:&nbsp; Argument 1 passed to test::__construct() must be an object of class foo, called in testArgType.php on line 27 and defined in testArgType.php on line 13</span>
</code></div>
  </div>
 </div>
  <div class="note" id="61597">  <div class="votes">
    <div id="Vu61597">
    <a href="/manual/vote-note.php?id=61597&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd61597">
    <a href="/manual/vote-note.php?id=61597&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V61597" title="53% like this...">
    2
    </div>
  </div>
  <a href="#61597" class="name">
  <strong class="user"><em>ksamvel at gmail dot com</em></strong></a><a class="genanchor" href="#61597"> &para;</a><div class="date" title="2006-02-07 07:55"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom61597">
<div class="phpcode"><code><span class="html">
by default Classes constructor does not have any arguments. Using small trick with func_get_args() and other relative functions constructor becomes a function w/ args (tested in php 5.1.2). Check it out:<br /><br />class A {<br />&nbsp; &nbsp; public function __construct() {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo func_num_args() . "&lt;br&gt;";<br />&nbsp; &nbsp; &nbsp; &nbsp; var_dump( func_get_args());<br />&nbsp; &nbsp; &nbsp; &nbsp; echo "&lt;br&gt;";<br />&nbsp; &nbsp; }<br />}<br /><br />$oA = new A();<br />$oA = new A( 1, 2, 3, "txt");<br /><br />Output:<br /><br />0<br />array(0) { }<br />4<br />array(4) { [0]=&gt; int(1) [1]=&gt; int(2) [2]=&gt; int(3) [3]=&gt; string(3) "txt" }</span>
</code></div>
  </div>
 </div>
  <div class="note" id="89759">  <div class="votes">
    <div id="Vu89759">
    <a href="/manual/vote-note.php?id=89759&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd89759">
    <a href="/manual/vote-note.php?id=89759&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V89759" title="52% like this...">
    2
    </div>
  </div>
  <a href="#89759" class="name">
  <strong class="user"><em>allankelly at gmail dot com</em></strong></a><a class="genanchor" href="#89759"> &para;</a><div class="date" title="2009-03-21 02:34"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom89759">
<div class="phpcode"><code><span class="html">
I like to pass an associative array as an argument. This is reminiscent of a Perl technique and can be tested with is_array. For example:<br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">div</span><span class="keyword">( </span><span class="default">$opt </span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="default">$class </span><span class="keyword">= </span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$text&nbsp; </span><span class="keyword">= </span><span class="string">''</span><span class="keyword">;<br />&nbsp; &nbsp; if( </span><span class="default">is_array</span><span class="keyword">( </span><span class="default">$opt </span><span class="keyword">) )<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach( </span><span class="default">$opt </span><span class="keyword">as </span><span class="default">$k </span><span class="keyword">=&gt; </span><span class="default">$v </span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; switch( </span><span class="default">$k </span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">'class'</span><span class="keyword">: </span><span class="default">$class </span><span class="keyword">= </span><span class="string">"class = '</span><span class="default">$v</span><span class="string">'"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">'text'</span><span class="keyword">: </span><span class="default">$text </span><span class="keyword">= </span><span class="default">$v</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; else<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$text </span><span class="keyword">= </span><span class="default">$opt</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; return </span><span class="string">"&lt;div </span><span class="default">$class</span><span class="string">&gt;</span><span class="default">$text</span><span class="string">&lt;/div&gt;"</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121667">  <div class="votes">
    <div id="Vu121667">
    <a href="/manual/vote-note.php?id=121667&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121667">
    <a href="/manual/vote-note.php?id=121667&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121667" title="100% like this...">
    2
    </div>
  </div>
  <a href="#121667" class="name">
  <strong class="user"><em>info at keraweb dot nl</em></strong></a><a class="genanchor" href="#121667"> &para;</a><div class="date" title="2017-09-21 09:25"><strong>2 months ago</strong></div>
  <div class="text" id="Hcom121667">
<div class="phpcode"><code><span class="html">
You can use a class constant as a default parameter.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">A </span><span class="keyword">{<br />&nbsp; &nbsp; const </span><span class="default">FOO </span><span class="keyword">= </span><span class="string">'default'</span><span class="keyword">;<br />&nbsp; &nbsp; function </span><span class="default">bar</span><span class="keyword">( </span><span class="default">$val </span><span class="keyword">= </span><span class="default">self</span><span class="keyword">::</span><span class="default">FOO </span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">$val</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$a </span><span class="keyword">= new </span><span class="default">A</span><span class="keyword">();<br /></span><span class="default">$a</span><span class="keyword">-&gt;</span><span class="default">bar</span><span class="keyword">(); </span><span class="comment">// Will echo "default"</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121579">  <div class="votes">
    <div id="Vu121579">
    <a href="/manual/vote-note.php?id=121579&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121579">
    <a href="/manual/vote-note.php?id=121579&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121579" title="100% like this...">
    1
    </div>
  </div>
  <a href="#121579" class="name">
  <strong class="user"><em>Hayley Watson</em></strong></a><a class="genanchor" href="#121579"> &para;</a><div class="date" title="2017-08-30 11:41"><strong>3 months ago</strong></div>
  <div class="text" id="Hcom121579">
<div class="phpcode"><code><span class="html">
There are fewer restrictions on using ... to supply multiple arguments to a function call than there are on using it to declare a variadic parameter in the function declaration. In particular, it can be used more than once to unpack arguments, provided that all such uses come after any positional arguments.<br /><br /><span class="default">&lt;?php<br /><br />$array1 </span><span class="keyword">= [[</span><span class="default">1</span><span class="keyword">],[</span><span class="default">2</span><span class="keyword">],[</span><span class="default">3</span><span class="keyword">]];<br /></span><span class="default">$array2 </span><span class="keyword">= [</span><span class="default">4</span><span class="keyword">];<br /></span><span class="default">$array3 </span><span class="keyword">= [[</span><span class="default">5</span><span class="keyword">],[</span><span class="default">6</span><span class="keyword">],[</span><span class="default">7</span><span class="keyword">]];<br /><br /></span><span class="default">$result </span><span class="keyword">= </span><span class="default">array_merge</span><span class="keyword">(...</span><span class="default">$array1</span><span class="keyword">); </span><span class="comment">// Legal, of course: $result == [1,2,3];<br /></span><span class="default">$result </span><span class="keyword">= </span><span class="default">array_merge</span><span class="keyword">(</span><span class="default">$array2</span><span class="keyword">, ...</span><span class="default">$array1</span><span class="keyword">); </span><span class="comment">// $result == [4,1,2,3]<br /></span><span class="default">$result </span><span class="keyword">= </span><span class="default">array_merge</span><span class="keyword">(...</span><span class="default">$array1</span><span class="keyword">, </span><span class="default">$array2</span><span class="keyword">); </span><span class="comment">// Fatal error: Cannot use positional argument after argument unpacking.<br /></span><span class="default">$result </span><span class="keyword">= </span><span class="default">array_merge</span><span class="keyword">(...</span><span class="default">$array1</span><span class="keyword">, ...</span><span class="default">$array3</span><span class="keyword">); </span><span class="comment">// Legal! $result == [1,2,3,5,6,7]<br /></span><span class="default">?&gt;<br /></span><br />The Right Thing for the error case above would be for $result==[1,2,3,4], but this isn't yet (v7.1.8) supported.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118795">  <div class="votes">
    <div id="Vu118795">
    <a href="/manual/vote-note.php?id=118795&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118795">
    <a href="/manual/vote-note.php?id=118795&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118795" title="50% like this...">
    0
    </div>
  </div>
  <a href="#118795" class="name">
  <strong class="user"><em>catman at esteticas dot se</em></strong></a><a class="genanchor" href="#118795"> &para;</a><div class="date" title="2016-02-07 01:06"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom118795">
<div class="phpcode"><code><span class="html">
I wondered if variable length argument lists and references works together, and what the syntax might be. It is not mentioned explicitly yet in the php manual as far as I can find. But other sources mention the following syntax "&amp;...$variable" that works in php&nbsp; 5.6.16. <br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">foo</span><span class="keyword">(&amp;...</span><span class="default">$args</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="default">$i </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />&nbsp; &nbsp; foreach (</span><span class="default">$args </span><span class="keyword">as &amp;</span><span class="default">$arg</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$arg </span><span class="keyword">= ++</span><span class="default">$i</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /></span><span class="default">foo</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">, </span><span class="default">$c</span><span class="keyword">);<br />echo </span><span class="string">'a = '</span><span class="keyword">, </span><span class="default">$a</span><span class="keyword">, </span><span class="string">', b = '</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">, </span><span class="string">', c = '</span><span class="keyword">, </span><span class="default">$c</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span>Gives<br />a = 1, b = 2, c = 3</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121526">  <div class="votes">
    <div id="Vu121526">
    <a href="/manual/vote-note.php?id=121526&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121526">
    <a href="/manual/vote-note.php?id=121526&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121526" title="0% like this...">
    -1
    </div>
  </div>
  <a href="#121526" class="name">
  <strong class="user"><em>Hayley Watson</em></strong></a><a class="genanchor" href="#121526"> &para;</a><div class="date" title="2017-08-16 12:50"><strong>3 months ago</strong></div>
  <div class="text" id="Hcom121526">
<div class="phpcode"><code><span class="html">
If you use ... in a function's parameter list, you can use it only once for obvious reasons. Less obvious is that it has to be on the LAST parameter; as the manual puts it: "You may specify normal positional arguments BEFORE the ... token. (emphasis mine).<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">variadic</span><span class="keyword">(</span><span class="default">$first</span><span class="keyword">, ...</span><span class="default">$most</span><span class="keyword">, </span><span class="default">$last</span><span class="keyword">)<br />{</span><span class="comment">/*etc.*/</span><span class="keyword">}<br /><br /></span><span class="default">variadic</span><span class="keyword">(</span><span class="default">1</span><span class="keyword">, </span><span class="default">2</span><span class="keyword">, </span><span class="default">3</span><span class="keyword">, </span><span class="default">4</span><span class="keyword">, </span><span class="default">5</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span>results in a fatal error, even though it looks like the Thing To Do™ would be to set $first to 1, $most to [2, 3, 4], and $last to 5.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120580">  <div class="votes">
    <div id="Vu120580">
    <a href="/manual/vote-note.php?id=120580&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120580">
    <a href="/manual/vote-note.php?id=120580&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120580" title="0% like this...">
    -1
    </div>
  </div>
  <a href="#120580" class="name">
  <strong class="user"><em>g dot sokol99 at g-sokol dot info</em></strong></a><a class="genanchor" href="#120580"> &para;</a><div class="date" title="2017-02-03 08:55"><strong>10 months ago</strong></div>
  <div class="text" id="Hcom120580">
<div class="phpcode"><code><span class="html">
Nullable arguments:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">class </span><span class="default">C </span><span class="keyword">{}<br /><br />function </span><span class="default">foo</span><span class="keyword">(?</span><span class="default">C $a</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$a</span><span class="keyword">);<br />}<br /><br /></span><span class="default">foo</span><span class="keyword">(</span><span class="default">null</span><span class="keyword">);<br /><br /></span><span class="default">foo</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span><br />Output:<br /><br />NULL<br />PHP Warning:&nbsp; Uncaught ArgumentCountError: Too few arguments to function foo(), 0 passed in php shell code on line 1 and exactly 1 expected in php shell code:1<br />Stack trace:<br />#0 php shell code(1): foo()<br />#1 {main}<br />&nbsp; thrown in php shell code on line 1<br /><br />Usage of "?" Is also possible with "string", "int", "array" and so on primitive types (which is strange). Also unliKe "= null" "?" can be passed not only for tail of arguments, e.g.:<br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">foo</span><span class="keyword">(?</span><span class="default">string $a</span><span class="keyword">, </span><span class="default">string $b</span><span class="keyword">) {}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="96927">  <div class="votes">
    <div id="Vu96927">
    <a href="/manual/vote-note.php?id=96927&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd96927">
    <a href="/manual/vote-note.php?id=96927&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V96927" title="50% like this...">
    0
    </div>
  </div>
  <a href="#96927" class="name">
  <strong class="user"><em>pigiman at gmail dot com</em></strong></a><a class="genanchor" href="#96927"> &para;</a><div class="date" title="2010-03-23 09:37"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom96927">
<div class="phpcode"><code><span class="html">
Hey, <br /><br />I started to learn for the Zend Certificate exam a few days ago and I got stuck with one unanswered-well question. <br />This is the question: <br />“Absent any actual need for choosing one method over the other, does passing arrays by value to a read-only function reduce performance compared to passing them by reference?’<br /><br />This question answered by Zend support team at Zend.com: <br /><br />"A copy of the original $array is created within the function scope. Once the function terminates, the scope is removed and the copy of $array with it." (By massimilianoc)<br /><br />Have a nice day! <br /><br />Shaked KO</span>
</code></div>
  </div>
 </div>
  <div class="note" id="79326">  <div class="votes">
    <div id="Vu79326">
    <a href="/manual/vote-note.php?id=79326&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd79326">
    <a href="/manual/vote-note.php?id=79326&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V79326" title="50% like this...">
    0
    </div>
  </div>
  <a href="#79326" class="name">
  <strong class="user"><em>Don dot hosek at gmail dot com</em></strong></a><a class="genanchor" href="#79326"> &para;</a><div class="date" title="2007-11-20 05:50"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom79326">
<div class="phpcode"><code><span class="html">
Actually the use of class or global constants does buy us something. It helps enforce the DRY (don't repeat yourself) principle.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="56331">  <div class="votes">
    <div id="Vu56331">
    <a href="/manual/vote-note.php?id=56331&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd56331">
    <a href="/manual/vote-note.php?id=56331&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V56331" title="50% like this...">
    0
    </div>
  </div>
  <a href="#56331" class="name">
  <strong class="user"><em>nate at natemurray dot com</em></strong></a><a class="genanchor" href="#56331"> &para;</a><div class="date" title="2005-08-30 03:15"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom56331">
<div class="phpcode"><code><span class="html">
Of course you can fake a global variable for a default argument by something like this:<br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">self_url</span><span class="keyword">(</span><span class="default">$text</span><span class="keyword">, </span><span class="default">$page</span><span class="keyword">, </span><span class="default">$per_page </span><span class="keyword">= </span><span class="default">NULL</span><span class="keyword">) {<br />&nbsp; </span><span class="default">$per_page </span><span class="keyword">= (</span><span class="default">$per_page </span><span class="keyword">== </span><span class="default">NULL</span><span class="keyword">) ? </span><span class="default">$GLOBALS</span><span class="keyword">[</span><span class="string">'gPER_PAGE'</span><span class="keyword">] : </span><span class="default">$per_page</span><span class="keyword">; </span><span class="comment"># setup a default value of per page<br />&nbsp; </span><span class="keyword">return </span><span class="default">sprintf</span><span class="keyword">(</span><span class="string">"&lt;a href=%s?page=%s&amp;perpage=%s&gt;%s&lt;/a&gt;"</span><span class="keyword">, </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">"PHP_SELF"</span><span class="keyword">], </span><span class="default">$page</span><span class="keyword">, </span><span class="default">$per_page</span><span class="keyword">, </span><span class="default">$text</span><span class="keyword">);<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="97890">  <div class="votes">
    <div id="Vu97890">
    <a href="/manual/vote-note.php?id=97890&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd97890">
    <a href="/manual/vote-note.php?id=97890&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V97890" title="48% like this...">
    -1
    </div>
  </div>
  <a href="#97890" class="name">
  <strong class="user"><em>rburnap at intelligent dash imaging dot com</em></strong></a><a class="genanchor" href="#97890"> &para;</a><div class="date" title="2010-05-13 05:19"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom97890">
<div class="phpcode"><code><span class="html">
This may be helpful when you need to call an arbitrary function known only at runtime:<br /><br />You can call a function as a variable name.<br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">foo</span><span class="keyword">(){<br />&nbsp; &nbsp; echo</span><span class="string">"\nfoo()"</span><span class="keyword">;<br />}<br /><br />function </span><span class="default">callfunc</span><span class="keyword">(</span><span class="default">$x</span><span class="keyword">, </span><span class="default">$y </span><span class="keyword">= </span><span class="string">''</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; if( </span><span class="default">$y</span><span class="keyword">==</span><span class="string">'' </span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; if( </span><span class="default">$x</span><span class="keyword">==</span><span class="string">'' </span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; echo </span><span class="string">"\nempty"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; else </span><span class="default">$x</span><span class="keyword">();<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><span class="default">$y</span><span class="keyword">-&gt;</span><span class="default">$x</span><span class="keyword">();<br />}<br /><br />class </span><span class="default">cbar </span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">fcatch</span><span class="keyword">(){ echo </span><span class="string">"\nfcatch"</span><span class="keyword">; }<br />}<br /><br /></span><span class="default">$x </span><span class="keyword">= </span><span class="string">''</span><span class="keyword">;<br /></span><span class="default">callfunc</span><span class="keyword">(</span><span class="default">$x</span><span class="keyword">);<br /></span><span class="default">$x </span><span class="keyword">= </span><span class="string">'foo'</span><span class="keyword">;<br /></span><span class="default">callfunc</span><span class="keyword">(</span><span class="default">$x</span><span class="keyword">);<br /></span><span class="default">$o </span><span class="keyword">= new </span><span class="default">cbar</span><span class="keyword">();<br /></span><span class="default">$x </span><span class="keyword">= </span><span class="string">'fcatch'</span><span class="keyword">;<br /></span><span class="default">callfunc</span><span class="keyword">(</span><span class="default">$x</span><span class="keyword">, </span><span class="default">$o</span><span class="keyword">);<br />echo </span><span class="string">"\n\n"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />The code will output<br /><br />empty<br />foo()<br />fcatch</span>
</code></div>
  </div>
 </div>
  <div class="note" id="16968">  <div class="votes">
    <div id="Vu16968">
    <a href="/manual/vote-note.php?id=16968&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd16968">
    <a href="/manual/vote-note.php?id=16968&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V16968" title="47% like this...">
    -1
    </div>
  </div>
  <a href="#16968" class="name">
  <strong class="user"><em>wls at wwco dot com</em></strong></a><a class="genanchor" href="#16968"> &para;</a><div class="date" title="2001-11-20 11:29"><strong>16 years ago</strong></div>
  <div class="text" id="Hcom16968">
<div class="phpcode"><code><span class="html">
Follow up to resource passing:<br /><br />It appears that if you have defined the resource in the same file<br />as the function that uses it, you can get away with the global trick.<br /><br />Here's the failure case:<br /><br />&nbsp; include "functions_doing_globals.php"<br />&nbsp; $conn = openDatabaseConnection();<br />&nbsp; invoke_function_doing_global_conn();<br /><br />...that it fails.<br /><br />Perhaps it's some strange scoping problem with include/require, or<br />globals trying to resolve before the variable is defined, rather<br />than at function execution.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="115238">  <div class="votes">
    <div id="Vu115238">
    <a href="/manual/vote-note.php?id=115238&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115238">
    <a href="/manual/vote-note.php?id=115238&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115238" title="44% like this...">
    -1
    </div>
  </div>
  <a href="#115238" class="name">
  <strong class="user"><em>lucas dot ekrause at gmail dot com</em></strong></a><a class="genanchor" href="#115238"> &para;</a><div class="date" title="2014-06-18 08:40"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115238">
<div class="phpcode"><code><span class="html">
In addition to jcaplan@bogus.amazon.com’s comment (<a href="http://www.php.net/manual/de/functions.arguments.php#62803" rel="nofollow" target="_blank">http://www.php.net/manual/de/functions.arguments.php#62803</a>) you could also simply write<br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">f</span><span class="keyword">(</span><span class="default">$x</span><span class="keyword">=</span><span class="default">4</span><span class="keyword">){echo </span><span class="default">$x</span><span class="keyword">.</span><span class="string">"\n"</span><span class="keyword">;}<br />function </span><span class="default">g</span><span class="keyword">(</span><span class="default">$x</span><span class="keyword">=</span><span class="default">null</span><span class="keyword">){for(</span><span class="default">$i</span><span class="keyword">=</span><span class="default">0</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">&lt;</span><span class="default">2</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">++){</span><span class="default">call_user_func_array</span><span class="keyword">(</span><span class="string">"f"</span><span class="keyword">, !</span><span class="default">is_null</span><span class="keyword">(</span><span class="default">$x</span><span class="keyword">) ? array(</span><span class="default">$x</span><span class="keyword">) : array());}}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114838">  <div class="votes">
    <div id="Vu114838">
    <a href="/manual/vote-note.php?id=114838&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114838">
    <a href="/manual/vote-note.php?id=114838&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114838" title="44% like this...">
    -2
    </div>
  </div>
  <a href="#114838" class="name">
  <strong class="user"><em>aasasdasdf at yandex dot ru</em></strong></a><a class="genanchor" href="#114838"> &para;</a><div class="date" title="2014-04-12 12:34"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114838">
<div class="phpcode"><code><span class="html">
As of PHP 5.5.10, it seems that a variable will be separated from its value if defined right in a function call:<br /><br />php &gt; error_reporting(E_ALL);<br />php &gt; function a(&amp;$b) {$b = 1;}<br />php &gt; a($q = 2); var_dump($q);<br />Strict Standards: Only variables should be passed by reference in php shell code on line 1<br />int(2)<br />php &gt; $w = 3; a($w); var_dump($w);<br />int(1)<br /><br />Notice that it's still fine to use a variable that is not defined at all:<br /><br />php &gt; a($e); var_dump($e);<br />int(1)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="33559">  <div class="votes">
    <div id="Vu33559">
    <a href="/manual/vote-note.php?id=33559&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd33559">
    <a href="/manual/vote-note.php?id=33559&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V33559" title="46% like this...">
    -2
    </div>
  </div>
  <a href="#33559" class="name">
  <strong class="user"><em>thesibster at hotmail dot com</em></strong></a><a class="genanchor" href="#33559"> &para;</a><div class="date" title="2003-06-30 11:43"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom33559">
<div class="phpcode"><code><span class="html">
Call-time pass-by-ref arguments are deprecated and may not be supported later, so doing this:<br /><br />----<br />function foo($str) {<br />&nbsp; &nbsp; $str = "bar";<br />}<br /><br />$mystr = "hello world";<br />foo(&amp;$mystr);<br />----<br /><br />will produce a warning when using the recommended php.ini file.&nbsp; The way I ended up using for optional pass-by-ref args is to just pass an unused variable when you don't want to use the resulting parameter value:<br /><br />----<br />function foo(&amp;$str) {<br />&nbsp; &nbsp; $str = "bar";<br />}<br /><br />foo($_unused_);<br />----<br /><br />Note that trying to pass a value of NULL will produce an error.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="70511">  <div class="votes">
    <div id="Vu70511">
    <a href="/manual/vote-note.php?id=70511&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd70511">
    <a href="/manual/vote-note.php?id=70511&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V70511" title="42% like this...">
    -3
    </div>
  </div>
  <a href="#70511" class="name">
  <strong class="user"><em>keuleu at hotmail dot com</em></strong></a><a class="genanchor" href="#70511"> &para;</a><div class="date" title="2006-10-19 02:59"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom70511">
<div class="phpcode"><code><span class="html">
I ran into the problem that jcaplan mentionned. I had just finished building 2 handler classes and one interface. <br /><br />During my testing I realized that my handlers were not initializing their variables to their default values when my interface was calling them with 'null' values:<br /><br />this is a simplified illustration:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">some_function</span><span class="keyword">(</span><span class="default">$v1</span><span class="keyword">=</span><span class="string">'value1'</span><span class="keyword">,</span><span class="default">$v2</span><span class="keyword">=</span><span class="string">'value2'</span><span class="keyword">,</span><span class="default">$v3</span><span class="keyword">=</span><span class="string">'value3'</span><span class="keyword">){<br />&nbsp; echo </span><span class="default">$v1</span><span class="keyword">.</span><span class="string">',&nbsp; '</span><span class="keyword">;<br />&nbsp; echo </span><span class="default">$v2</span><span class="keyword">.</span><span class="string">',&nbsp; '</span><span class="keyword">;<br />&nbsp; echo </span><span class="default">$v3</span><span class="keyword">;<br />}<br /><br /></span><span class="default">some_function</span><span class="keyword">(); </span><span class="comment">//this will behave as expected, displaying 'value1,&nbsp; value2,&nbsp; value3'<br /></span><span class="default">some_function</span><span class="keyword">(</span><span class="default">null</span><span class="keyword">,</span><span class="default">null</span><span class="keyword">,</span><span class="default">null</span><span class="keyword">); </span><span class="comment">//this on the other hand will display ',&nbsp; ,' since the variables will take the null value.<br /></span><span class="default">?&gt;<br /></span><br />I came to about the same conclusion as jcaplan. To force your function parameters to take a default value when a null is passed you need to include a conditionnal assignment inside the function definition. <br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">some_function</span><span class="keyword">(</span><span class="default">$v1</span><span class="keyword">=</span><span class="string">'value1'</span><span class="keyword">,</span><span class="default">$v2</span><span class="keyword">=</span><span class="string">'value1'</span><span class="keyword">,</span><span class="default">$v3</span><span class="keyword">=</span><span class="default">null</span><span class="keyword">){<br />&nbsp; </span><span class="default">$v1</span><span class="keyword">=(</span><span class="default">is_null</span><span class="keyword">(</span><span class="default">$v1</span><span class="keyword">)?</span><span class="string">'value1'</span><span class="keyword">:</span><span class="default">$v1</span><span class="keyword">);<br />&nbsp; </span><span class="default">$v2</span><span class="keyword">=(</span><span class="default">is_null</span><span class="keyword">(</span><span class="default">$v2</span><span class="keyword">)?</span><span class="string">'value2'</span><span class="keyword">:</span><span class="default">$v2</span><span class="keyword">);<br />&nbsp; </span><span class="default">$v3</span><span class="keyword">=(</span><span class="default">is_null</span><span class="keyword">(</span><span class="default">$v3</span><span class="keyword">)?</span><span class="string">'value3'</span><span class="keyword">:</span><span class="default">$v3</span><span class="keyword">);<br />&nbsp; echo </span><span class="default">$v1</span><span class="keyword">;<br />&nbsp; echo </span><span class="default">$v2</span><span class="keyword">;<br />&nbsp; echo </span><span class="default">$v3</span><span class="keyword">;<br />}<br /></span><span class="comment">/* <br />The default value whether null or an actual value is not so important in the parameter list, what is important is that you include it to allow a default behavior. The default value in the declaration becomes more important at this point:<br />*/<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="8978">  <div class="votes">
    <div id="Vu8978">
    <a href="/manual/vote-note.php?id=8978&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd8978">
    <a href="/manual/vote-note.php?id=8978&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V8978" title="43% like this...">
    -4
    </div>
  </div>
  <a href="#8978" class="name">
  <strong class="user"><em>coop at better-mouse-trap dot com</em></strong></a><a class="genanchor" href="#8978"> &para;</a><div class="date" title="2000-10-09 08:59"><strong>17 years ago</strong></div>
  <div class="text" id="Hcom8978">
<div class="phpcode"><code><span class="html">
If you prefer to use named arguments to your functions (so you don't have to worry about the order of variable argument lists), you can do so PERL style with anonymous arrays:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">foo</span><span class="keyword">(</span><span class="default">$args</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; print </span><span class="string">"named_arg1 : " </span><span class="keyword">. </span><span class="default">$args</span><span class="keyword">[</span><span class="string">"named_arg1"</span><span class="keyword">] . </span><span class="string">"\n"</span><span class="keyword">;<br />&nbsp; &nbsp; print </span><span class="string">"named_arg2 : " </span><span class="keyword">. </span><span class="default">$args</span><span class="keyword">[</span><span class="string">"named_arg2"</span><span class="keyword">] . </span><span class="string">"\n"</span><span class="keyword">;<br />}<br /><br /></span><span class="default">foo</span><span class="keyword">(array(</span><span class="string">"named_arg1" </span><span class="keyword">=&gt; </span><span class="string">"arg1_value"</span><span class="keyword">, </span><span class="string">"named_arg2" </span><span class="keyword">=&gt; </span><span class="string">"arg2_value"</span><span class="keyword">));<br /></span><span class="default">?&gt;<br /></span><br />will output:<br />named_arg1 : arg1_value<br />named_arg2 : arg2_value</span>
</code></div>
  </div>
 </div>
  <div class="note" id="11565">  <div class="votes">
    <div id="Vu11565">
    <a href="/manual/vote-note.php?id=11565&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd11565">
    <a href="/manual/vote-note.php?id=11565&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V11565" title="40% like this...">
    -4
    </div>
  </div>
  <a href="#11565" class="name">
  <strong class="user"><em>artiebob at go dot com</em></strong></a><a class="genanchor" href="#11565"> &para;</a><div class="date" title="2001-02-25 01:48"><strong>16 years ago</strong></div>
  <div class="text" id="Hcom11565">
<div class="phpcode"><code><span class="html">
here is the code to pass a user defined function as an argument.&nbsp; Just like in the usort method.<br /><br /><span class="default">&lt;?php<br />func2</span><span class="keyword">(</span><span class="string">"func1"</span><span class="keyword">);<br />function </span><span class="default">func1 </span><span class="keyword">(</span><span class="default">$arg</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; print (</span><span class="string">"Hello </span><span class="default">$arg</span><span class="string">"</span><span class="keyword">);&nbsp; &nbsp; &nbsp; &nbsp; <br />}<br />function </span><span class="default">func2 </span><span class="keyword">(</span><span class="default">$arg1</span><span class="keyword">){&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$arg1</span><span class="keyword">(</span><span class="string">"World"</span><span class="keyword">);&nbsp; </span><span class="comment">//Does the same thing as the next line<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">call_user_func </span><span class="keyword">(</span><span class="default">$arg1</span><span class="keyword">, </span><span class="string">"World"</span><span class="keyword">);<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="112643">  <div class="votes">
    <div id="Vu112643">
    <a href="/manual/vote-note.php?id=112643&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd112643">
    <a href="/manual/vote-note.php?id=112643&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V112643" title="37% like this...">
    -4
    </div>
  </div>
  <a href="#112643" class="name">
  <strong class="user"><em>ravenswd at gmail dot com</em></strong></a><a class="genanchor" href="#112643"> &para;</a><div class="date" title="2013-07-08 02:30"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom112643">
<div class="phpcode"><code><span class="html">
Be careful when passing arguments by reference, it can cause unexpected side-effects if one is not careful.<br /><br />I had a program designed to sweep through directories and subdirectories and report on the total number of files, and the total size of all files. Since it needed to return two values, I used variables passed by reference.<br /><br />In one spot in the program, I didn't need the values of those variables after they were returned, so I just used a garbage variable named $ignore instead. This caused a curious bug which took me a while to track down, because the effects of the bug were in a different part of the program than the place where I had made a mistake.<br /><br />Since the same variable was used for both parameters passed by reference, they ended up both pointing to the same physical location in memory, so changing one of them caused both of them to change. The code below is an excerpt of my program, stripped down to just the few lines necessary to illustrate what was happening:<br /><br /><span class="default">&lt;?php<br />sweep </span><span class="keyword">(</span><span class="default">$ignore</span><span class="keyword">, </span><span class="default">$ignore</span><span class="keyword">);<br /></span><span class="comment">// no errors occur here<br /><br /></span><span class="keyword">function </span><span class="default">sweep </span><span class="keyword">( &amp;</span><span class="default">$filecount</span><span class="keyword">, &amp;</span><span class="default">$bytecount </span><span class="keyword">) {<br />&nbsp; </span><span class="default">$filecount </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">;<br />&nbsp; </span><span class="default">$bytecount </span><span class="keyword">= </span><span class="default">1024</span><span class="keyword">;<br />&nbsp; print </span><span class="string">"Files: </span><span class="default">$filecount</span><span class="string"> - Size: </span><span class="default">$bytecount</span><span class="string">"</span><span class="keyword">;&nbsp; </span><span class="comment">// prints "Files: 1024 - Size: 1024"<br /></span><span class="keyword">}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="118283">  <div class="votes">
    <div id="Vu118283">
    <a href="/manual/vote-note.php?id=118283&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd118283">
    <a href="/manual/vote-note.php?id=118283&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V118283" title="33% like this...">
    -1
    </div>
  </div>
  <a href="#118283" class="name">
  <strong class="user"><em>ohcc at 163 dot com</em></strong></a><a class="genanchor" href="#118283"> &para;</a><div class="date" title="2015-11-08 09:23"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom118283">
<div class="phpcode"><code><span class="html">
As of PHP 5.6, you can use an array as arguments when calling a function with the ... $args syntax.<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; $args </span><span class="keyword">= array(</span><span class="string">'wu'</span><span class="keyword">,</span><span class="string">'WU'</span><span class="keyword">,</span><span class="string">'wuxiancheng.cn'</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$string </span><span class="keyword">= </span><span class="default">str_replace</span><span class="keyword">(...</span><span class="default">$args</span><span class="keyword">);<br />&nbsp; &nbsp; echo </span><span class="default">$string</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />Ha ha, is that interesting and powerful? <br /><br />Also you can use it like this<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; $args </span><span class="keyword">= array(</span><span class="string">'WU'</span><span class="keyword">,</span><span class="string">'wuxiancheng.cn'</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$string </span><span class="keyword">= </span><span class="default">str_replace</span><span class="keyword">(</span><span class="string">'wu'</span><span class="keyword">, ...</span><span class="default">$args</span><span class="keyword">);<br />&nbsp; &nbsp; echo </span><span class="default">$string</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />It also can be used to define a user function.<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">function </span><span class="default">wxc </span><span class="keyword">(</span><span class="default">$arg1</span><span class="keyword">, </span><span class="default">$arg2</span><span class="keyword">, ...</span><span class="default">$otherArgs</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'&lt;pre&gt;'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$otherArgs</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">print_r</span><span class="keyword">(</span><span class="default">func_get_args</span><span class="keyword">());<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">'&lt;/pre&gt;'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; </span><span class="default">wxc </span><span class="keyword">(</span><span class="default">1</span><span class="keyword">, </span><span class="default">2</span><span class="keyword">, ...array(</span><span class="default">3</span><span class="keyword">,</span><span class="default">4</span><span class="keyword">,</span><span class="default">5</span><span class="keyword">));<br /></span><span class="default">?&gt;<br /></span><br />REMEMBER this: ... $args is not supported in PHP 5.5 and older versions.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="23498">  <div class="votes">
    <div id="Vu23498">
    <a href="/manual/vote-note.php?id=23498&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd23498">
    <a href="/manual/vote-note.php?id=23498&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V23498" title="37% like this...">
    -4
    </div>
  </div>
  <a href="#23498" class="name">
  <strong class="user"><em>guillaume dot goutaudier at eurecom dot fr</em></strong></a><a class="genanchor" href="#23498"> &para;</a><div class="date" title="2002-07-19 12:15"><strong>15 years ago</strong></div>
  <div class="text" id="Hcom23498">
<div class="phpcode"><code><span class="html">
Concerning default values for arguments passed by reference:<br />I often use that trick:<br />func($ref=$defaultValue) {<br />&nbsp; &nbsp; $ref = "new value";<br />}<br />func(&amp;$var);<br />print($var) // echo "new value"<br /><br />Setting $defaultValue to null enables you to write functions with optional arguments which, if given, are to be modified.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="13563">  <div class="votes">
    <div id="Vu13563">
    <a href="/manual/vote-note.php?id=13563&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd13563">
    <a href="/manual/vote-note.php?id=13563&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V13563" title="38% like this...">
    -5
    </div>
  </div>
  <a href="#13563" class="name">
  <strong class="user"><em>rwillmann at nocomment dot sk</em></strong></a><a class="genanchor" href="#13563"> &para;</a><div class="date" title="2001-06-21 03:05"><strong>16 years ago</strong></div>
  <div class="text" id="Hcom13563">
<div class="phpcode"><code><span class="html">
There is no way how to deal with calling by reference when variable lengths argument list are passed.<br />&lt;br&gt;Only solutions is to use construction like this:&lt;br&gt;<br />function foo($args) {&lt;br&gt;<br />&nbsp;&nbsp; ...<br />}<br /><br />foo(array(&amp;$first, &amp;$second));<br /><br />Above example pass by value a list of references to other variables :-)<br /><br />It is courios, becouse when you call a function with arguments passed via &amp;$parameter syntax, func_get_args returns array of copies :-(<br /><br />rwi</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117882">  <div class="votes">
    <div id="Vu117882">
    <a href="/manual/vote-note.php?id=117882&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117882">
    <a href="/manual/vote-note.php?id=117882&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117882" title="33% like this...">
    -4
    </div>
  </div>
  <a href="#117882" class="name">
  <strong class="user"><em>d_maley at hotmail dot com</em></strong></a><a class="genanchor" href="#117882"> &para;</a><div class="date" title="2015-08-26 09:12"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117882">
<div class="phpcode"><code><span class="html">
If you define your functions in the following way, you can call them whilst only specifying the default parameters you need<br /><br />1. Define your function with its mandatory parameters, and an optional array<br /><br />2. Declare your optional parameters as local variables<br /><br />3. The crux: replace the value of any optional parameters that you have passed via the array, using PHP's facility to interpret variable variable names. This line is identical for every function<br /><br />4. Call the function, passing its mandatory parameters, and only those optional parameters that you require<br /><br />For example,<br /><br />function test_params($a, $b, $arrOptionalParams = array()) {<br />&nbsp; $c = 'sat';<br />&nbsp; $d = 'mat';<br />&nbsp; foreach($arrOptionalParams as $key =&gt; $value) ${$key} = $value;<br />&nbsp; echo "$a $b $c on the $d";<br />}<br /><br />and then call it like this<br /><br />test_params('The', 'dog', array('c' =&gt; 'stood', 'd' =&gt; 'donkey'));<br />test_params('The', 'cat', array('d' =&gt; 'donkey'));<br />test_params('A', 'dog', array('c' =&gt; 'stood'));<br /><br />Results:<br /><br />The dog stood on the donkey<br />The cat sat on the donkey<br />A dog stood on the mat</span>
</code></div>
  </div>
 </div>
  <div class="note" id="73338">  <div class="votes">
    <div id="Vu73338">
    <a href="/manual/vote-note.php?id=73338&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd73338">
    <a href="/manual/vote-note.php?id=73338&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V73338" title="35% like this...">
    -5
    </div>
  </div>
  <a href="#73338" class="name">
  <strong class="user"><em>pdenny at magmic dot com</em></strong></a><a class="genanchor" href="#73338"> &para;</a><div class="date" title="2007-02-18 09:43"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom73338">
<div class="phpcode"><code><span class="html">
Note that constants can also be used as default argument values<br />so the following code:<br /><br />&nbsp; define('TEST_CONSTANT','Works!');<br />&nbsp; function testThis($var=TEST_CONSTANT) {<br />&nbsp; &nbsp; &nbsp; echo "Passing constants as default values $var";<br />&nbsp; }<br />&nbsp; testThis();<br /><br />will produce :<br /><br />Passing constants as default values Works!<br /><br />(I tried this in both PHP 4 and 5)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="55103">  <div class="votes">
    <div id="Vu55103">
    <a href="/manual/vote-note.php?id=55103&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd55103">
    <a href="/manual/vote-note.php?id=55103&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V55103" title="34% like this...">
    -8
    </div>
  </div>
  <a href="#55103" class="name">
  <strong class="user"><em>Angelina Bell</em></strong></a><a class="genanchor" href="#55103"> &para;</a><div class="date" title="2005-07-25 12:40"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom55103">
<div class="phpcode"><code><span class="html">
It is so easy to create a constant that the php novice might do so accidently while attempting to call a function with no arguments.&nbsp; For example:<br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">LogoutUser</span><span class="keyword">(){<br /></span><span class="comment">// destroy the session, the cookie, and the session ID<br />&nbsp; </span><span class="default">blah blah blah</span><span class="keyword">;<br />&nbsp; return </span><span class="default">true</span><span class="keyword">;<br />}<br />function </span><span class="default">SessionCheck</span><span class="keyword">(){<br />&nbsp; </span><span class="default">blah blah blah</span><span class="keyword">;<br /></span><span class="comment">// check for session timeout<br /></span><span class="keyword">...<br />&nbsp; &nbsp; if (</span><span class="default">$timeout</span><span class="keyword">) </span><span class="default">LogoutUser</span><span class="keyword">;&nbsp; </span><span class="comment">// should be LogoutUser();<br /></span><span class="keyword">}<br /></span><span class="default">?&gt;<br /></span><br />OOPS!&nbsp; I don't notice my typo, the SessionCheck function<br />doesn't work, and it takes me all afternoon to figure out why not!<br /><br /><span class="default">&lt;?php<br />LogoutUser</span><span class="keyword">;<br />print </span><span class="string">"new constant LogoutUser is " </span><span class="keyword">. </span><span class="default">LogoutUser</span><span class="keyword">;<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="57141">  <div class="votes">
    <div id="Vu57141">
    <a href="/manual/vote-note.php?id=57141&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd57141">
    <a href="/manual/vote-note.php?id=57141&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V57141" title="34% like this...">
    -9
    </div>
  </div>
  <a href="#57141" class="name">
  <strong class="user"><em>grinslives13 at hotmail dot com~=s/i/ee/g</em></strong></a><a class="genanchor" href="#57141"> &para;</a><div class="date" title="2005-09-24 10:55"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom57141">
<div class="phpcode"><code><span class="html">
Given that we have two coding styles:<br /><br />#<br /># Code (A)<br />#<br />funtion foo_a (&amp;$var)<br />{<br />&nbsp; &nbsp; $var *= 2;<br />&nbsp; &nbsp; return $var;<br />}<br />foo_a($a);<br /><br />#<br /># Code (B)<br />#<br />function foo_b ($var)<br />{<br />&nbsp; &nbsp; $var *= 2;<br />&nbsp; &nbsp; return $var;<br />}<br />foo_b(&amp;$a);<br /><br />I personally wouldn't recommend (B) - I think it strange why php would support such a convention as it would have violated foo_b's design - its use would not do justice to its function prototype. And thinking about such use, I might have to think about copying all variables instead of working directly on them... <br /><br />Coding that respects function prototypes strictly would, I believe, result in code that is more intuitive to read. Of course, in php &lt;=4, not being able to use default values with references, we can't do this that we can do in C:<br /><br />#<br /># optional return-value parameters<br />#<br />int foo_c (int var, int *ret)<br />{<br />&nbsp; &nbsp; var *= 2;<br />&nbsp; &nbsp; if (ret) *ret = var;<br />&nbsp; &nbsp; return var;<br />}<br />foo_c(2, NULL);<br /><br />Of course, since variables are "free" anyway, we can always get away with it by using dummy variables...<br /><br />zlel</span>
</code></div>
  </div>
 </div>
  <div class="note" id="104404">  <div class="votes">
    <div id="Vu104404">
    <a href="/manual/vote-note.php?id=104404&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd104404">
    <a href="/manual/vote-note.php?id=104404&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V104404" title="32% like this...">
    -9
    </div>
  </div>
  <a href="#104404" class="name">
  <strong class="user"><em>jacob at jacobweber dot com</em></strong></a><a class="genanchor" href="#104404"> &para;</a><div class="date" title="2011-06-13 02:05"><strong>6 years ago</strong></div>
  <div class="text" id="Hcom104404">
<div class="phpcode"><code><span class="html">
This page states:<br /><br />"Note that when using default arguments, any defaults should be on the right side of any non-default arguments; otherwise, things will not work as expected."<br /><br />There seems to be one exception to this. Say you're using type-hinting for an argument, but you want to allow it to be NULL, and you want additional required arguments to the right of it. PHP allows this, as long as you give it the type-hinted argument a default value of NULL. For example:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">function </span><span class="default">sample</span><span class="keyword">(</span><span class="default">ClassA $a </span><span class="keyword">= </span><span class="default">NULL</span><span class="keyword">, </span><span class="default">$b</span><span class="keyword">) {<br />}<br /></span><span class="default">sample</span><span class="keyword">(new </span><span class="default">ClassA</span><span class="keyword">(), </span><span class="string">''</span><span class="keyword">); </span><span class="comment">// success<br /></span><span class="default">sample</span><span class="keyword">(new </span><span class="default">ClassB</span><span class="keyword">(), </span><span class="string">''</span><span class="keyword">); </span><span class="comment">// failure; wrong type<br /></span><span class="default">sample</span><span class="keyword">(</span><span class="default">NULL</span><span class="keyword">, </span><span class="string">''</span><span class="keyword">); </span><span class="comment">// success<br /></span><span class="default">sample</span><span class="keyword">(new </span><span class="default">ClassA</span><span class="keyword">()); </span><span class="comment">// failure; missing second argument<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="54315">  <div class="votes">
    <div id="Vu54315">
    <a href="/manual/vote-note.php?id=54315&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd54315">
    <a href="/manual/vote-note.php?id=54315&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V54315" title="29% like this...">
    -7
    </div>
  </div>
  <a href="#54315" class="name">
  <strong class="user"><em>balint , at ./ atres &amp;*( ath !# cx</em></strong></a><a class="genanchor" href="#54315"> &para;</a><div class="date" title="2005-06-30 02:59"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom54315">
<div class="phpcode"><code><span class="html">
(in reply to benk at NOSPAM dot icarz dot com / 24-Jun-2005 04:21)<br />I could make use of this assignment, as below, to have a permanently existing, but changing data block (because it is used by many other classes), where the order or the refreshed contents are needed for the others: (DB init done by one, an other changed the DB, and thereafter all others need to use the other DB without creating new instances, or creating a log array in one, and we would like to append the new debug strings to the array, atmany places.)<br /><br />class xyz {<br />&nbsp; &nbsp; var argN = array();<br />&nbsp; &nbsp; function xyz($argN) {<br />&nbsp; &nbsp; &nbsp; &nbsp; $this-&gt;argN = &amp;$argN;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; function etc($text) {<br />&nbsp; &nbsp; &nbsp; &nbsp; array_push($this-&gt;argN, $text);<br />&nbsp; &nbsp; }<br />}<br />class abc {<br />&nbsp; &nbsp; var argM = array();<br />&nbsp; &nbsp; function abc($argM) {<br />&nbsp; &nbsp; &nbsp; &nbsp; $this-&gt;argM = &amp;$argM;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; function etc($text) {<br />&nbsp; &nbsp; &nbsp; &nbsp; array_push($this-&gt;argM, $text);<br />&nbsp; &nbsp; }<br />}<br /><br />$messages=array("one", "two");<br />$x = new xyz(&amp;$messages);<br />$x-&gt;etc("test");<br /><br />$a = new abc(&amp;$messages);<br />$a-&gt;etc("tset");<br /><br />...</span>
</code></div>
  </div>
 </div>
  <div class="note" id="40967">  <div class="votes">
    <div id="Vu40967">
    <a href="/manual/vote-note.php?id=40967&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd40967">
    <a href="/manual/vote-note.php?id=40967&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V40967" title="30% like this...">
    -9
    </div>
  </div>
  <a href="#40967" class="name">
  <strong class="user"><em>heck AT fas DOT harvard DOT edu</em></strong></a><a class="genanchor" href="#40967"> &para;</a><div class="date" title="2004-03-24 05:49"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom40967">
<div class="phpcode"><code><span class="html">
I have some functions that I'd like to be able to pass arguments two ways: Either as an argument list of variable length (e.g. func(1, 2, 3, 4)) or as an array (e.g., func(array(1,2,3,4)). Only the latter can be constructed on the fly (e.g., func($ar)), but the syntax of the former can be neater. <br /><br />The way to do it is to begin the function as follows:<br />&nbsp; $args = func_get_args();<br />&nbsp; if (is_array ($args[0]))<br />&nbsp; &nbsp; $args = $args[0];<br />Then one can just use $args as the list of arguments.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="49389">  <div class="votes">
    <div id="Vu49389">
    <a href="/manual/vote-note.php?id=49389&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd49389">
    <a href="/manual/vote-note.php?id=49389&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V49389" title="26% like this...">
    -9
    </div>
  </div>
  <a href="#49389" class="name">
  <strong class="user"><em>csaba at alum dot mit dot edu</em></strong></a><a class="genanchor" href="#49389"> &para;</a><div class="date" title="2005-01-26 04:58"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom49389">
<div class="phpcode"><code><span class="html">
Argument evaluation left to right means that you can save yourself a temporary variable in the example below whereas $current = $prior + ($prior=$current) is just the same as $current *= 2;<br /><br />function Sum() { return array_sum(func_get_args()); }<br />function Fib($n,$current=1,$prior=0) {<br />&nbsp; &nbsp; for (;--$n;) $current = Sum($prior,$prior=$current);<br />&nbsp; &nbsp; return $current;<br />}<br /><br />Csaba Gabor<br />PS.&nbsp; You could, of course, just use array_sum(array(...)) in place of Sum(...)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119240">  <div class="votes">
    <div id="Vu119240">
    <a href="/manual/vote-note.php?id=119240&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119240">
    <a href="/manual/vote-note.php?id=119240&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119240" title="10% like this...">
    -8
    </div>
  </div>
  <a href="#119240" class="name">
  <strong class="user"><em>maduro_0 at hotmail dot com</em></strong></a><a class="genanchor" href="#119240"> &para;</a><div class="date" title="2016-04-25 03:56"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119240">
<div class="phpcode"><code><span class="html">
This will work<br /><br />function test($a,$b){<br />&nbsp; &nbsp; echo 'yes it works';<br />&nbsp; &nbsp; echo $a;<br />&nbsp; &nbsp; echo $b;<br />}<br /><br />echo test('1','2','3','2');<br /><br />This wouldn't work<br /><br />function test($a,$b){<br />&nbsp; &nbsp; echo 'yes it works';<br />&nbsp; &nbsp; echo $a;<br />&nbsp; &nbsp; echo $b;<br />}<br /><br />echo test('1');</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117243">  <div class="votes">
    <div id="Vu117243">
    <a href="/manual/vote-note.php?id=117243&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117243">
    <a href="/manual/vote-note.php?id=117243&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117243" title="10% like this...">
    -15
    </div>
  </div>
  <a href="#117243" class="name">
  <strong class="user"><em>rich at richware dot net</em></strong></a><a class="genanchor" href="#117243"> &para;</a><div class="date" title="2015-05-08 05:27"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117243">
<div class="phpcode"><code><span class="html">
How to pass a class as an argument? This is simple:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">TMath </span><span class="keyword">{<br />&nbsp; &nbsp; private </span><span class="default">$_Total</span><span class="keyword">;<br />&nbsp; &nbsp; function </span><span class="default">Sum</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">_Total </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach (</span><span class="default">func_get_args</span><span class="keyword">() as </span><span class="default">$n</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">_Total </span><span class="keyword">+= </span><span class="default">$n</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; function </span><span class="default">Total</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">_Total</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br />&nbsp; &nbsp; </span><span class="default">$myMath </span><span class="keyword">= new </span><span class="default">TMath</span><span class="keyword">();<br />&nbsp; &nbsp; </span><span class="default">$myMath</span><span class="keyword">-&gt;</span><span class="default">Sum</span><span class="keyword">(</span><span class="default">1</span><span class="keyword">,</span><span class="default">2</span><span class="keyword">,</span><span class="default">3</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">ShowTotal</span><span class="keyword">(</span><span class="default">$myMath</span><span class="keyword">);<br /><br />&nbsp; &nbsp; function </span><span class="default">ShowTotal</span><span class="keyword">(</span><span class="default">$aMath</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">$aMath</span><span class="keyword">-&gt;</span><span class="default">Total</span><span class="keyword">().</span><span class="string">'&lt;br/&gt;'</span><span class="keyword">;<br />&nbsp; &nbsp; }</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="112743">  <div class="votes">
    <div id="Vu112743">
    <a href="/manual/vote-note.php?id=112743&amp;page=functions.arguments&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd112743">
    <a href="/manual/vote-note.php?id=112743&amp;page=functions.arguments&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V112743" title="9% like this...">
    -18
    </div>
  </div>
  <a href="#112743" class="name">
  <strong class="user"><em>post at auge8472 dot de</em></strong></a><a class="genanchor" href="#112743"> &para;</a><div class="date" title="2013-07-18 08:48"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom112743">
<div class="phpcode"><code><span class="html">
I needed a way to decide between two possible values for one function parameter. I didn't want to decide it before calling the function but wanted to do the constraint inside the function call.<br /><br />$foo = 1;<br />$bar = 2;<br /><br />function foobar($val) {<br />&nbsp; &nbsp; echo $val;<br />&nbsp; &nbsp; }<br /><br />foobar(isset($foo) ? $foo : $bar);<br /><br />// output: 1<br /><br />$bar = 2;<br /><br />function foobar($val) {<br />&nbsp; &nbsp; echo $val;<br />&nbsp; &nbsp; }<br /><br />foobar(isset($foo) ? $foo : $bar);<br /><br />// output: 2</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=functions.arguments&amp;redirect=http://php.net/manual/en/functions.arguments.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.functions.php">Functions</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="functions.user-defined.php" title="User-&#8203;defined functions">User-&#8203;defined functions</a>
                        </li>
                          
                        <li class="current">
                            <a href="functions.arguments.php" title="Function arguments">Function arguments</a>
                        </li>
                          
                        <li class="">
                            <a href="functions.returning-values.php" title="Returning values">Returning values</a>
                        </li>
                          
                        <li class="">
                            <a href="functions.variable-functions.php" title="Variable functions">Variable functions</a>
                        </li>
                          
                        <li class="">
                            <a href="functions.internal.php" title="Internal (built-&#8203;in) functions">Internal (built-&#8203;in) functions</a>
                        </li>
                          
                        <li class="">
                            <a href="functions.anonymous.php" title="Anonymous functions">Anonymous functions</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

