<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: SSL context options - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/context.ssl.php">
 <link rel="shorturl" href="http://php.net/manual/en/context.ssl.php">
 <link rel="alternate" href="http://php.net/manual/en/context.ssl.php" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/context.php">
 <link rel="prev" href="http://php.net/manual/en/context.ftp.php">
 <link rel="next" href="http://php.net/manual/en/context.curl.php">

 <link rel="alternate" href="http://php.net/manual/en/context.ssl.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/context.ssl.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/context.ssl.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/context.ssl.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/context.ssl.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/context.ssl.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/context.ssl.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/context.ssl.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/context.ssl.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/context.ssl.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/context.ssl.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="context.curl.php">
          CURL context options &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="context.ftp.php">
          &laquo; FTP context options        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='context.php'>Context options and parameters</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/context.ssl.php' selected="selected">English</option>
            <option value='pt_BR/context.ssl.php'>Brazilian Portuguese</option>
            <option value='zh/context.ssl.php'>Chinese (Simplified)</option>
            <option value='fr/context.ssl.php'>French</option>
            <option value='de/context.ssl.php'>German</option>
            <option value='ja/context.ssl.php'>Japanese</option>
            <option value='ro/context.ssl.php'>Romanian</option>
            <option value='ru/context.ssl.php'>Russian</option>
            <option value='es/context.ssl.php'>Spanish</option>
            <option value='tr/context.ssl.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/context.ssl.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=context.ssl">Report a Bug</a>
    </div>
  </div><div id="context.ssl" class="refentry">
 <div class="refnamediv">
  <h1 class="refname">SSL context options</h1>
  <p class="refpurpose"><span class="refname">SSL context options</span> &mdash; <span class="dc-title">SSL context option listing</span></p>

 </div>
 
 <div class="refsect1 description" id="refsect1-context.ssl-description">
  <h3 class="title">Description</h3>
  <p class="para">
   Context options for <em>ssl://</em> and <em>tls://</em>
   transports.
  </p>
 </div>


 <div class="refsect1 options" id="refsect1-context.ssl-options">
  <h3 class="title">Options</h3>
  <p class="para">
   <dl>

    
     <dt id="context.ssl.peer-name">
      <code class="parameter">peer_name</code>
      <span class="type"><a href="language.types.string.php" class="type string">string</a></span>
     </dt>

     <dd>

      <p class="para">
       Peer name to be used. If this value is not set, then the name is guessed
       based on the hostname used when opening the stream.
      </p>
     </dd>

    
    
     <dt id="context.ssl.verify-peer">
      <code class="parameter">verify_peer</code>
      <span class="type"><a href="language.types.boolean.php" class="type boolean">boolean</a></span>
     </dt>

     <dd>

      <p class="para">
       Require verification of SSL certificate used.
      </p>
      <p class="para">
       Defaults to <strong><code>TRUE</code></strong>.
      </p>
     </dd>

    
    
     <dt id="context.ssl.verify-peer-name">
      <code class="parameter">verify_peer_name</code>
      <span class="type"><a href="language.types.boolean.php" class="type boolean">boolean</a></span>
     </dt>

     <dd>

      <p class="para">
       Require verification of peer name.
      </p>
      <p class="para">
       Defaults to <strong><code>TRUE</code></strong>.
      </p>
     </dd>

    
    
     <dt id="context.ssl.allow-self-signed">
      <code class="parameter">allow_self_signed</code>
      <span class="type"><a href="language.types.boolean.php" class="type boolean">boolean</a></span>
     </dt>

     <dd>

      <p class="para">
       Allow self-signed certificates. Requires
       <a href="context.ssl.php#context.ssl.verify-peer" class="link"><code class="parameter">verify_peer</code></a>.
      </p>
      <p class="para">
       Defaults to <strong><code>FALSE</code></strong>
      </p>
     </dd>

    
    
     <dt id="context.ssl.cafile">
      <code class="parameter">cafile</code>
      <span class="type"><a href="language.types.string.php" class="type string">string</a></span>
     </dt>

     <dd>

      <p class="para">
       Location of Certificate Authority file on local filesystem
       which should be used with the <em>verify_peer</em>
       context option to authenticate the identity of the remote peer.
      </p>
     </dd>

    
    
     <dt id="context.ssl.capath">
      <code class="parameter">capath</code>
      <span class="type"><a href="language.types.string.php" class="type string">string</a></span>
     </dt>

     <dd>

      <p class="para">
       If <em>cafile</em> is not specified or if the certificate
       is not found there, the directory pointed to by <em>capath</em> 
       is searched for a suitable certificate.  <em>capath</em>
       must be a correctly hashed certificate directory.
      </p>
     </dd>

    
    
     <dt id="context.ssl.local-cert">
      <code class="parameter">local_cert</code>
      <span class="type"><a href="language.types.string.php" class="type string">string</a></span>
     </dt>

     <dd>

      <p class="para">
       Path to local certificate file on filesystem.  It must be a PEM
       encoded file which contains your certificate and private key.
       It can optionally contain the certificate chain of issuers.
       The private key also may be contained in a separate file specified
       by <em>local_pk</em>.
      </p>
     </dd>

    
    
     <dt id="context.ssl.local-pk">
      <code class="parameter">local_pk</code>
      <span class="type"><a href="language.types.string.php" class="type string">string</a></span>
     </dt>

     <dd>

      <p class="para">
       Path to local private key file on filesystem in case of separate
       files for certificate (<em>local_cert</em>) and private key.
      </p>
     </dd>

    
    
     <dt id="context.ssl.passphrase">
      <code class="parameter">passphrase</code>
      <span class="type"><a href="language.types.string.php" class="type string">string</a></span>
     </dt>

     <dd>

      <p class="para">
       Passphrase with which your <em>local_cert</em> file
       was encoded.
      </p>
     </dd>

    
    
     <dt id="context.ssl.cn-match">
      <code class="parameter">CN_match</code>
      <span class="type"><a href="language.types.string.php" class="type string">string</a></span>
     </dt>

     <dd>

      <p class="para">
       Common Name we are expecting.  PHP will perform limited wildcard
       matching.  If the Common Name does not match this, the connection
       attempt will fail.
      </p>
      <blockquote class="note"><p><strong class="note">Note</strong>: 
        <span class="simpara">
          This option is deprecated, in favour of <code class="parameter">peer_name</code>,
          as of PHP 5.6.0.
        </span>
      </p></blockquote>
     </dd>

    
    
     <dt id="context.ssl.verify-depth">
      <code class="parameter">verify_depth</code>
      <span class="type"><a href="language.types.integer.php" class="type integer">integer</a></span>
     </dt>

     <dd>

      <p class="para">
       Abort if the certificate chain is too deep.
      </p>
      <p class="para">
       Defaults to no verification.
      </p>
     </dd>

    
    
     <dt id="context.ssl.ciphers">
      <code class="parameter">ciphers</code>
      <span class="type"><a href="language.types.string.php" class="type string">string</a></span>
     </dt>

     <dd>

      <p class="para">
       Sets the list of available ciphers. The format of the string is described
       in <a href="https://www.openssl.org/docs/manmaster/man1/ciphers.html#CIPHER-LIST-FORMAT" class="link external">&raquo;&nbsp;ciphers(1)</a>.
      </p>
      <p class="para">
       Defaults to <em>DEFAULT</em>.
      </p>
     </dd>

    
    
     <dt id="context.ssl.capture-peer-cert">
      <code class="parameter">capture_peer_cert</code>
      <span class="type"><a href="language.types.boolean.php" class="type boolean">boolean</a></span>
     </dt>

     <dd>

      <p class="para">
       If set to <strong><code>TRUE</code></strong> a <em>peer_certificate</em> context option
       will be created containing the peer certificate.
      </p>
     </dd>

    
    
     <dt id="context.ssl.capture-peer-cert-chain">
      <code class="parameter">capture_peer_cert_chain</code>
      <span class="type"><a href="language.types.boolean.php" class="type boolean">boolean</a></span>
     </dt>

     <dd>

      <p class="para">
       If set to <strong><code>TRUE</code></strong> a <em>peer_certificate_chain</em> context
       option will be created containing the certificate chain.
      </p>
     </dd>

    
    
     <dt id="context.ssl.sni-enabled">
      <code class="parameter">SNI_enabled</code>
      <span class="type"><a href="language.types.boolean.php" class="type boolean">boolean</a></span>
     </dt>

     <dd>

      <p class="para">
       If set to <strong><code>TRUE</code></strong> server name indication will be enabled. Enabling SNI 
       allows multiple certificates on the same IP address.
      </p>
     </dd>

    
    
     <dt id="context.ssl.sni-server-name">
      <code class="parameter">SNI_server_name</code>
      <span class="type"><a href="language.types.string.php" class="type string">string</a></span>
     </dt>

     <dd>

      <p class="para">
       If set, then this value will be used as server name for server name 
       indication. If this value is not set, then the server name is guessed 
       based on the hostname used when opening the stream.
      </p>
      <blockquote class="note"><p><strong class="note">Note</strong>: 
        <span class="simpara">
          This option is deprecated, in favour of <code class="parameter">peer_name</code>,
          as of PHP 5.6.0.
        </span>
      </p></blockquote>
     </dd>

    
    
     <dt id="context.ssl.disable-compression">
      <code class="parameter">disable_compression</code>
      <span class="type"><a href="language.types.boolean.php" class="type boolean">boolean</a></span>
     </dt>

     <dd>

      <p class="para">
       If set, disable TLS compression. This can help mitigate the CRIME attack
       vector. 
      </p>
     </dd>

    
    
     <dt id="context.ssl.peer-fingerprint">
      <code class="parameter">peer_fingerprint</code>
      <span class="type"><a href="language.types.string.php" class="type string">string</a></span> | <span class="type"><a href="language.types.array.php" class="type array">array</a></span>
     </dt>

     <dd>

      <p class="para">
       Aborts when the remote certificate digest doesn&#039;t match the specified
       hash.
      </p>
      <p class="para">
       When a <span class="type"><a href="language.types.string.php" class="type string">string</a></span> is used, the length will determine which hashing algorithm
       is applied, either &quot;md5&quot; (32) or &quot;sha1&quot; (40).
      </p>
      <p class="para">
       When an <span class="type"><a href="language.types.array.php" class="type array">array</a></span> is used, the keys indicate the hashing algorithm name
       and each corresponding value is the expected digest.
      </p>
     </dd>

    
   </dl>

  </p>
 </div>

 
 <div class="refsect1 changelog" id="refsect1-context.ssl-changelog">
  <h3 class="title">Changelog</h3>
  <p class="para">
   <table class="doctable informaltable">
    
     <thead>
      <tr>
       <th>Version</th>
       <th>Description</th>
      </tr>

     </thead>

     <tbody class="tbody">
      <tr>
       <td>5.6.0</td>
       <td>
        Added <code class="parameter">peer_fingerprint</code> and <code class="parameter">verify_peer_name</code>.
        <code class="parameter">verify_peer</code> default changed to <strong><code>TRUE</code></strong>.
       </td>
      </tr>

      <tr>
       <td>5.4.13</td>
       <td>
        Added <code class="parameter">disable_compression</code>. Requires OpenSSL &gt;= 1.0.0.
       </td>
      </tr>

      <tr>
       <td>5.3.2</td>
       <td>
        Added <code class="parameter">SNI_enabled</code> and
        <code class="parameter">SNI_server_name</code>.
       </td>
      </tr>

     </tbody>
    
   </table>

  </p>
 </div>


 <div class="refsect1 notes" id="refsect1-context.ssl-notes">
  <h3 class="title">Notes</h3>
  <blockquote class="note"><p><strong class="note">Note</strong>: 
   <span class="simpara">
    Because <em>ssl://</em> is the underlying transport for the
    <a href="wrappers.http.php" class="link"><em>https://</em></a> and
    <a href="wrappers.ftp.php" class="link"><em>ftps://</em></a> wrappers, 
    any context options which apply to <em>ssl://</em> also apply to
    <em>https://</em> and <em>ftps://</em>.
   </span>
  </p></blockquote>
  <blockquote class="note"><p><strong class="note">Note</strong>: 
   <span class="simpara">
    For SNI (Server Name Indication) to be available, then PHP must be compiled 
    with OpenSSL 0.9.8j or greater. Use the 
    <strong><code>OPENSSL_TLSEXT_SERVER_NAME</code></strong> to determine whether SNI is 
    supported.
   </span>
  </p></blockquote>
 </div>


 <div class="refsect1 seealso" id="refsect1-context.ssl-seealso">
  <h3 class="title">See Also</h3>
  <p class="para">
   <ul class="simplelist">
    <li class="member"><a href="context.socket.php" class="xref">Socket context options</a></li>
   </ul>
  </p>
 </div>


</div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=context.ssl&amp;redirect=http://php.net/manual/en/context.ssl.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">5 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="119844">  <div class="votes">
    <div id="Vu119844">
    <a href="/manual/vote-note.php?id=119844&amp;page=context.ssl&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119844">
    <a href="/manual/vote-note.php?id=119844&amp;page=context.ssl&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119844" title="80% like this...">
    3
    </div>
  </div>
  <a href="#119844" class="name">
  <strong class="user"><em>website at meezaan dot net</em></strong></a><a class="genanchor" href="#119844"> &para;</a><div class="date" title="2016-09-05 01:48"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119844">
<div class="phpcode"><code><span class="html">
There is also a crypto_type context. In older versions this was crypto_method. This is referenced on <a href="http://php.net/manual/en/function.stream-socket-enable-crypto.php." rel="nofollow" target="_blank">http://php.net/manual/en/function.stream-socket-enable-crypto.php.</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="96328">  <div class="votes">
    <div id="Vu96328">
    <a href="/manual/vote-note.php?id=96328&amp;page=context.ssl&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd96328">
    <a href="/manual/vote-note.php?id=96328&amp;page=context.ssl&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V96328" title="62% like this...">
    4
    </div>
  </div>
  <a href="#96328" class="name">
  <strong class="user"><em>Botjan kufca</em></strong></a><a class="genanchor" href="#96328"> &para;</a><div class="date" title="2010-02-20 11:11"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom96328">
<div class="phpcode"><code><span class="html">
CN_match works contrary to intuitive thinking. I came across this when I was developing SSL server implemented in PHP. I stated (in code): <br /><br />- do not allow self signed certs (works)<br />- verify peer certs against CA cert (works)<br />- verify the client's CN against CN_match (does not work), like this:<br /><br />stream_context_set_option($context, 'ssl', 'CN_match', '*.example.org');<br /><br />I presumed this would match any client with CN below .example.org domain.<br />Unfortunately this is NOT the case. The option above does not do that.<br /><br />What it really does is this:<br />- it takes client's CN and compares it to CN_match<br />- IF CLIENT's CN CONTAINS AN ASTERISK like *.example.org, then it is matched against CN_match in wildcard matching fashion<br /><br />Examples to illustrate behaviour:<br />(CNM = server's CN_match)<br />(CCN = client's CN)<br /><br />- CNM=host.example.org, CCN=host.example.org ---&gt; OK<br />- CNM=host.example.org, CCN=*.example.org ---&gt; OK<br />- CNM=.example.org, CCN=*.example.org ---&gt; OK<br />- CNM=example.org, CCN=*.example.org ---&gt; ERROR<br /><br />- CNM=*.example.org, CCN=host.example.org ---&gt; ERROR<br />- CNM=*.example.org, CCN=*.example.org ---&gt; OK<br /><br />According to PHP sources I believe that the same applies if you are trying to act as Client and the server contains a wildcard certificate. If you set CN_match to myserver.example.org and server presents itself with *.example.org, the connection is allowed.<br /><br />Everything above applies to PHP version 5.2.12.<br />I will supply a patch to support CN_match starting with asterisk.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120278">  <div class="votes">
    <div id="Vu120278">
    <a href="/manual/vote-note.php?id=120278&amp;page=context.ssl&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120278">
    <a href="/manual/vote-note.php?id=120278&amp;page=context.ssl&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120278" title="50% like this...">
    0
    </div>
  </div>
  <a href="#120278" class="name">
  <strong class="user"><em>Charlie</em></strong></a><a class="genanchor" href="#120278"> &para;</a><div class="date" title="2016-12-05 07:53"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom120278">
<div class="phpcode"><code><span class="html">
I am unable to load a PEM that was generated with the stunnel tools. However, I am able to use PHP calls to generate a working PEM that is recognized both by stunnel and php, as outlined here:<br /><br /><a href="http://www.devdungeon.com/content/how-use-ssl-sockets-php" rel="nofollow" target="_blank">http://www.devdungeon.com/content/how-use-ssl-sockets-php</a><br /><br />This code fragment is now working for me, and with stunnel verify=4, both sides confirm the fingerprint. Oddly, if "tls://" is set below, then TLSv1 is forced, but using "ssl://" allows TLSv1.2:<br /><br />$stream_context = stream_context_create([ 'ssl' =&gt; [<br />'local_cert'&nbsp; &nbsp; &nbsp; &nbsp; =&gt; '/path/to/key.pem',<br />'peer_fingerprint'&nbsp; =&gt; openssl_x509_fingerprint(file_get_contents('/path/to/key.crt')),<br />'verify_peer'&nbsp; &nbsp; &nbsp;&nbsp; =&gt; false,<br />'verify_peer_name'&nbsp; =&gt; false,<br />'allow_self_signed' =&gt; true,<br />'verify_depth'&nbsp; &nbsp; &nbsp; =&gt; 0 ]]);<br /><br />$fp = stream_socket_client('ssl://ssl.server.com:12345',<br />&nbsp;&nbsp; $errno, $errstr, 30, STREAM_CLIENT_CONNECT, $stream_context);<br />fwrite($fp, "foo bar\n");<br />while($line = fgets($fp, 8192)) echo $line;</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120265">  <div class="votes">
    <div id="Vu120265">
    <a href="/manual/vote-note.php?id=120265&amp;page=context.ssl&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120265">
    <a href="/manual/vote-note.php?id=120265&amp;page=context.ssl&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120265" title="50% like this...">
    0
    </div>
  </div>
  <a href="#120265" class="name">
  <strong class="user"><em>Charlie</em></strong></a><a class="genanchor" href="#120265"> &para;</a><div class="date" title="2016-12-02 07:28"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom120265">
<div class="phpcode"><code><span class="html">
It appears that "allow_self_signed" does not and cannot apply to the local_cert option.<br /><br />The stunnel verify=4 option, which verifies but ignores a CA, has no analog in these settings, which is unfortunate.<br /><br />Even more perplexingly, while the "openssl verify -CAfile" is successful, PHP appears unable to use the new ca/crt pair in any configuration.<br /><br />I did actually link my PHP against a copy of LibreSSL 2.3.8, but PHP oddly is unable to use TLS1.1 or 1.2. It does, however, enable EC secp521r1 (of which my native OpenSSL 0.9.8e is incapable).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114269">  <div class="votes">
    <div id="Vu114269">
    <a href="/manual/vote-note.php?id=114269&amp;page=context.ssl&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114269">
    <a href="/manual/vote-note.php?id=114269&amp;page=context.ssl&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114269" title="50% like this...">
    0
    </div>
  </div>
  <a href="#114269" class="name">
  <strong class="user"><em>borbas dot geri at gmail dot com</em></strong></a><a class="genanchor" href="#114269"> &para;</a><div class="date" title="2014-01-31 12:06"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114269">
<div class="phpcode"><code><span class="html">
I used this for Apple Push Notification Service.<br />Passed in a local certificate filename `cert.pem` trough local_cert option. <br />Worked fine, when invoked the script directly.<br /><br />But when I included/required the script from a different location, it stopped working, without any explicit error message.<br /><br />Resolved by passed in the full path for the file `&lt;FullPathTo&gt;cert.pem`.</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=context.ssl&amp;redirect=http://php.net/manual/en/context.ssl.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="context.php">Context options and parameters</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="context.socket.php" title="Socket context options">Socket context options</a>
                        </li>
                          
                        <li class="">
                            <a href="context.http.php" title="HTTP context options">HTTP context options</a>
                        </li>
                          
                        <li class="">
                            <a href="context.ftp.php" title="FTP context options">FTP context options</a>
                        </li>
                          
                        <li class="current">
                            <a href="context.ssl.php" title="SSL context options">SSL context options</a>
                        </li>
                          
                        <li class="">
                            <a href="context.curl.php" title="CURL context options">CURL context options</a>
                        </li>
                          
                        <li class="">
                            <a href="context.phar.php" title="Phar context options">Phar context options</a>
                        </li>
                          
                        <li class="">
                            <a href="context.mongodb.php" title="MongoDB context options">MongoDB context options</a>
                        </li>
                          
                        <li class="">
                            <a href="context.params.php" title="Context parameters">Context parameters</a>
                        </li>
                          
                        <li class="">
                            <a href="context.zip.php" title="Zip context options">Zip context options</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

