<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Handling file uploads - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/features.file-upload.php">
 <link rel="shorturl" href="http://php.net/file-upload">
 <link rel="alternate" href="http://php.net/file-upload" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/features.php">
 <link rel="prev" href="http://php.net/manual/en/features.xforms.php">
 <link rel="next" href="http://php.net/manual/en/features.file-upload.post-method.php">

 <link rel="alternate" href="http://php.net/manual/en/features.file-upload.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/features.file-upload.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/features.file-upload.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/features.file-upload.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/features.file-upload.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/features.file-upload.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/features.file-upload.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/features.file-upload.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/features.file-upload.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/features.file-upload.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/features.file-upload.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="features.file-upload.post-method.php">
          POST method uploads &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="features.xforms.php">
          &laquo; Dealing with XForms        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='features.php'>Features</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/features.file-upload.php' selected="selected">English</option>
            <option value='pt_BR/features.file-upload.php'>Brazilian Portuguese</option>
            <option value='zh/features.file-upload.php'>Chinese (Simplified)</option>
            <option value='fr/features.file-upload.php'>French</option>
            <option value='de/features.file-upload.php'>German</option>
            <option value='ja/features.file-upload.php'>Japanese</option>
            <option value='ro/features.file-upload.php'>Romanian</option>
            <option value='ru/features.file-upload.php'>Russian</option>
            <option value='es/features.file-upload.php'>Spanish</option>
            <option value='tr/features.file-upload.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/features.file-upload.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=features.file-upload">Report a Bug</a>
    </div>
  </div><div id="features.file-upload" class="chapter">
  <h1>Handling file uploads</h1>
<h2>Table of Contents</h2><ul class="chunklist chunklist_chapter"><li><a href="features.file-upload.post-method.php">POST method uploads</a></li><li><a href="features.file-upload.errors.php">Error Messages Explained</a></li><li><a href="features.file-upload.common-pitfalls.php">Common Pitfalls</a></li><li><a href="features.file-upload.multiple.php">Uploading multiple files</a></li><li><a href="features.file-upload.put-method.php">PUT method support</a></li><li><a href="features.file-upload.errors.seealso.php">See Also</a></li></ul>


  

  

  
  
  

  

  

 </div>

<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=features.file-upload&amp;redirect=http://php.net/manual/en/features.file-upload.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">32 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="114004">  <div class="votes">
    <div id="Vu114004">
    <a href="/manual/vote-note.php?id=114004&amp;page=features.file-upload&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114004">
    <a href="/manual/vote-note.php?id=114004&amp;page=features.file-upload&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114004" title="63% like this...">
    276
    </div>
  </div>
  <a href="#114004" class="name">
  <strong class="user"><em>CertaiN</em></strong></a><a class="genanchor" href="#114004"> &para;</a><div class="date" title="2013-12-29 11:09"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114004">
<div class="phpcode"><code><span class="html">
You'd better check $_FILES structure and values throughly.<br />The following code cannot cause any errors absolutely.<br /><br />Example:<br /><span class="default">&lt;?php<br /><br />header</span><span class="keyword">(</span><span class="string">'Content-Type: text/plain; charset=utf-8'</span><span class="keyword">);<br /><br />try {<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; </span><span class="comment">// Undefined | Multiple Files | $_FILES Corruption Attack<br />&nbsp; &nbsp; // If this request falls under any of them, treat it invalid.<br />&nbsp; &nbsp; </span><span class="keyword">if (<br />&nbsp; &nbsp; &nbsp; &nbsp; !isset(</span><span class="default">$_FILES</span><span class="keyword">[</span><span class="string">'upfile'</span><span class="keyword">][</span><span class="string">'error'</span><span class="keyword">]) ||<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">is_array</span><span class="keyword">(</span><span class="default">$_FILES</span><span class="keyword">[</span><span class="string">'upfile'</span><span class="keyword">][</span><span class="string">'error'</span><span class="keyword">])<br />&nbsp; &nbsp; ) {<br />&nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">RuntimeException</span><span class="keyword">(</span><span class="string">'Invalid parameters.'</span><span class="keyword">);<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">// Check $_FILES['upfile']['error'] value.<br />&nbsp; &nbsp; </span><span class="keyword">switch (</span><span class="default">$_FILES</span><span class="keyword">[</span><span class="string">'upfile'</span><span class="keyword">][</span><span class="string">'error'</span><span class="keyword">]) {<br />&nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">UPLOAD_ERR_OK</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">UPLOAD_ERR_NO_FILE</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">RuntimeException</span><span class="keyword">(</span><span class="string">'No file sent.'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">UPLOAD_ERR_INI_SIZE</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="default">UPLOAD_ERR_FORM_SIZE</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">RuntimeException</span><span class="keyword">(</span><span class="string">'Exceeded filesize limit.'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; default:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">RuntimeException</span><span class="keyword">(</span><span class="string">'Unknown errors.'</span><span class="keyword">);<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">// You should also check filesize here. <br />&nbsp; &nbsp; </span><span class="keyword">if (</span><span class="default">$_FILES</span><span class="keyword">[</span><span class="string">'upfile'</span><span class="keyword">][</span><span class="string">'size'</span><span class="keyword">] &gt; </span><span class="default">1000000</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">RuntimeException</span><span class="keyword">(</span><span class="string">'Exceeded filesize limit.'</span><span class="keyword">);<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">// DO NOT TRUST $_FILES['upfile']['mime'] VALUE !!<br />&nbsp; &nbsp; // Check MIME Type by yourself.<br />&nbsp; &nbsp; </span><span class="default">$finfo </span><span class="keyword">= new </span><span class="default">finfo</span><span class="keyword">(</span><span class="default">FILEINFO_MIME_TYPE</span><span class="keyword">);<br />&nbsp; &nbsp; if (</span><span class="default">false </span><span class="keyword">=== </span><span class="default">$ext </span><span class="keyword">= </span><span class="default">array_search</span><span class="keyword">(<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$finfo</span><span class="keyword">-&gt;</span><span class="default">file</span><span class="keyword">(</span><span class="default">$_FILES</span><span class="keyword">[</span><span class="string">'upfile'</span><span class="keyword">][</span><span class="string">'tmp_name'</span><span class="keyword">]),<br />&nbsp; &nbsp; &nbsp; &nbsp; array(<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'jpg' </span><span class="keyword">=&gt; </span><span class="string">'image/jpeg'</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'png' </span><span class="keyword">=&gt; </span><span class="string">'image/png'</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">'gif' </span><span class="keyword">=&gt; </span><span class="string">'image/gif'</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; ),<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">true<br />&nbsp; &nbsp; </span><span class="keyword">)) {<br />&nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">RuntimeException</span><span class="keyword">(</span><span class="string">'Invalid file format.'</span><span class="keyword">);<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; </span><span class="comment">// You should name it uniquely.<br />&nbsp; &nbsp; // DO NOT USE $_FILES['upfile']['name'] WITHOUT ANY VALIDATION !!<br />&nbsp; &nbsp; // On this example, obtain safe unique name from its binary data.<br />&nbsp; &nbsp; </span><span class="keyword">if (!</span><span class="default">move_uploaded_file</span><span class="keyword">(<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$_FILES</span><span class="keyword">[</span><span class="string">'upfile'</span><span class="keyword">][</span><span class="string">'tmp_name'</span><span class="keyword">],<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">sprintf</span><span class="keyword">(</span><span class="string">'./uploads/%s.%s'</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">sha1_file</span><span class="keyword">(</span><span class="default">$_FILES</span><span class="keyword">[</span><span class="string">'upfile'</span><span class="keyword">][</span><span class="string">'tmp_name'</span><span class="keyword">]),<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$ext<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">)<br />&nbsp; &nbsp; )) {<br />&nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">RuntimeException</span><span class="keyword">(</span><span class="string">'Failed to move uploaded file.'</span><span class="keyword">);<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; echo </span><span class="string">'File is uploaded successfully.'</span><span class="keyword">;<br /><br />} catch (</span><span class="default">RuntimeException $e</span><span class="keyword">) {<br /><br />&nbsp; &nbsp; echo </span><span class="default">$e</span><span class="keyword">-&gt;</span><span class="default">getMessage</span><span class="keyword">();<br /><br />}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="107406">  <div class="votes">
    <div id="Vu107406">
    <a href="/manual/vote-note.php?id=107406&amp;page=features.file-upload&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd107406">
    <a href="/manual/vote-note.php?id=107406&amp;page=features.file-upload&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V107406" title="58% like this...">
    19
    </div>
  </div>
  <a href="#107406" class="name">
  <strong class="user"><em>xmontero at dsitelecom dot com</em></strong></a><a class="genanchor" href="#107406"> &para;</a><div class="date" title="2012-02-06 10:23"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom107406">
<div class="phpcode"><code><span class="html">
If "large files" (ie: 50 or 100 MB) fail, check this:<br /><br />It may happen that your outgoing connection to the server is slow, and it may timeout not the "execution time" but the "input time", which for example in our system defaulted to 60s. In our case a large upload could take 1 or 2 hours.<br /><br />Additionally we had "session settings" that should be preserved after upload.<br /><br />1) You might want review those ini entries:<br /><br />* session.gc_maxlifetime<br />* max_input_time<br />* max_execution_time<br />* upload_max_filesize<br />* post_max_size<br /><br />2) Still fails? Caution, not all are changeable from the script itself. ini_set() might fail to override.<br /><br />More info here:<br /><a href="http://www.php.net/manual/es/ini.list.php" rel="nofollow" target="_blank">http://www.php.net/manual/es/ini.list.php</a><br /><br />You can see that the "upload_max_filesize", among others, is PHP_INI_PERDIR and not PHP_INI_ALL. This invalidates to use ini_set():<br /><a href="http://www.php.net/manual/en/configuration.changes.modes.php" rel="nofollow" target="_blank">http://www.php.net/manual/en/configuration.changes.modes.php</a><br /><br />Use .htaccess instead.<br /><br />3) Still fails?. Just make sure you enabled ".htaccess" to overwrite your php settings. This is made in the apache file. You need at least AllowOverride Options.<br /><br />See this here:<br /><a href="http://www.php.net/manual/en/configuration.changes.php" rel="nofollow" target="_blank">http://www.php.net/manual/en/configuration.changes.php</a><br /><br />You will necessarily allow this manually in the case your master files come with AllowOverride None.<br /><br />Conclussion:<br /><br />Depending on the system, to allow "large file uploads" you must go up and up and up and touch your config necessarily up to the apache config.<br /><br />Sample files:<br /><br />These work for me, for 100MB uploads, lasting 2 hours:<br /><br />In apache-virtual-host:<br />-----------------------------------------------------------<br />&lt;Directory /var/www/MyProgram&gt;<br />&nbsp; &nbsp; AllowOverride Options<br />&lt;/Directory&gt;<br />-----------------------------------------------------------<br /><br />In .htaccess:<br />-----------------------------------------------------------<br />php_value session.gc_maxlifetime 10800<br />php_value max_input_time&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; 10800<br />php_value max_execution_time&nbsp; &nbsp;&nbsp; 10800<br />php_value upload_max_filesize&nbsp; &nbsp; 110M<br />php_value post_max_size&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 120M<br />-----------------------------------------------------------<br /><br />In the example,<br />- As I last 1 to 2 hours, I allow 3 hours (3600x3)<br />- As I need 100MB, I allow air above for the file (110M) and a bit more for the whole post (120M).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="111489">  <div class="votes">
    <div id="Vu111489">
    <a href="/manual/vote-note.php?id=111489&amp;page=features.file-upload&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd111489">
    <a href="/manual/vote-note.php?id=111489&amp;page=features.file-upload&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V111489" title="57% like this...">
    14
    </div>
  </div>
  <a href="#111489" class="name">
  <strong class="user"><em>jan at lanteraudio dot nl</em></strong></a><a class="genanchor" href="#111489"> &para;</a><div class="date" title="2013-02-25 01:31"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom111489">
<div class="phpcode"><code><span class="html">
Also stumbled on the max_file_size problem, in particular getting no response, no error whatsoever when uploading a file bigger than the set upload_max_filesize.<br /><br />I found that it's not the upload_max_filesize setting, but instead the post_max_size setting causing this no response issue. So if you set post_max_size way larger than upload_max_filesize, at least you are likely to get an error response when filesize exceeds upload_max_filesize but is still within the limits of post_max_size.<br /><br />Hope this helps anyone.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="52989">  <div class="votes">
    <div id="Vu52989">
    <a href="/manual/vote-note.php?id=52989&amp;page=features.file-upload&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd52989">
    <a href="/manual/vote-note.php?id=52989&amp;page=features.file-upload&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V52989" title="59% like this...">
    11
    </div>
  </div>
  <a href="#52989" class="name">
  <strong class="user"><em>ceo at l-i-e dot com</em></strong></a><a class="genanchor" href="#52989"> &para;</a><div class="date" title="2005-05-19 08:25"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom52989">
<div class="phpcode"><code><span class="html">
Using /var/www/uploads in the example code is just criminal, imnsho.<br /><br />One should *NOT* upload untrusted files into your web tree, on any server.<br /><br />Nor should any directory within your web tree have permissions sufficient for an upload to succeed, on a shared server. Any other user on that shared server could write a PHP script to dump anything they want in there!<br /><br />The $_FILES['userfile']['type'] is essentially USELESS.<br />A. Browsers aren't consistent in their mime-types, so you'll never catch all the possible combinations of types for any given file format.<br />B. It can be forged, so it's crappy security anyway.<br /><br />One's code should INSPECT the actual file to see if it looks kosher.<br /><br />For example, images can quickly and easily be run through imagegetsize and you at least know the first N bytes LOOK like an image.&nbsp; That doesn't guarantee it's a valid image, but it makes it much less likely to be a workable security breaching file.<br /><br />For Un*x based servers, one could use exec and 'file' command to see if the Operating System thinks the internal contents seem consistent with the data type you expect.<br /><br />I've had trouble in the past with reading the '/tmp' file in a file upload.&nbsp; It would be nice if PHP let me read that file BEFORE I tried to move_uploaded_file on it, but PHP won't, presumably under the assumption that I'd be doing something dangerous to read an untrusted file.&nbsp; Fine.&nbsp;&nbsp; One should move the uploaded file to some staging directory.&nbsp; Then you check out its contents as thoroughly as you can.&nbsp; THEN, if it seems kosher, move it into a directory outside your web tree.&nbsp; Any access to that file should be through a PHP script which reads the file.&nbsp; Putting it into your web tree, even with all the checks you can think of, is just too dangerous, imnsho.<br /><br />There are more than a few User Contributed notes here with naive (bad) advice.&nbsp; Be wary.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="70471">  <div class="votes">
    <div id="Vu70471">
    <a href="/manual/vote-note.php?id=70471&amp;page=features.file-upload&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd70471">
    <a href="/manual/vote-note.php?id=70471&amp;page=features.file-upload&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V70471" title="58% like this...">
    9
    </div>
  </div>
  <a href="#70471" class="name">
  <strong class="user"><em>jedi_aka at yahoo dot com</em></strong></a><a class="genanchor" href="#70471"> &para;</a><div class="date" title="2006-10-18 12:12"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom70471">
<div class="phpcode"><code><span class="html">
For those of you trying to make the upload work with IIS on windows XP/2000/XP Media and alike here is a quick todo.<br /><br />1) Once you have created subdirectories "uploads/"&nbsp; in the same directory wher you code is running use the code from oportocala above and to make absolutely sure sure that the file you are trying to right is written under that folder. ( I recomend printing it using echo $uploadfile; )<br /><br />2) In windows explorer browse to the upload directory created above and share it. To do that execute the following substeps.<br />&nbsp; &nbsp;&nbsp; a) Right click the folder click "sharing and security..."<br />&nbsp; &nbsp;&nbsp; b) Check 'Share this folder on the network'<br />&nbsp; &nbsp;&nbsp; c) Check 'Allow network users to change my files' ( THIS STEP IS VERY IMPORTANT )<br />&nbsp; &nbsp;&nbsp; d) click 'ok' or 'apply' <br /><br />3) you can then go in the IIS to set read and write permissions for it. To do that execute the followin substeps.<br />&nbsp; &nbsp;&nbsp; a) Open IIS (Start/Controp Panel (classic View)/ Admistrative tools/Internet Information Service<br />&nbsp; &nbsp;&nbsp; b) Browse to your folder (the one we created above)<br />&nbsp; &nbsp;&nbsp; c) right click and select properties.<br />&nbsp; &nbsp;&nbsp; d) in the Directory tab, make sure, READ, WRITE, AND DIRECTORY BROWSING are checked.<br />&nbsp; &nbsp;&nbsp; e) For the security freaks out there, You should also make sure that 'execute permissions:' are set to Script only or lower (DO NOT SET IT TO 'script and executable)'( that is because someone could upload a script to your directory and run it. And, boy, you do not want that to happen).<br /><br />there U go.<br /><br />Send me feed back it if worked for you or not so that I can update the todo.<br /><br />jedi_aka@yahoo.com<br /><br />PS: BIG thanks to oportocala</span>
</code></div>
  </div>
 </div>
  <div class="note" id="55886">  <div class="votes">
    <div id="Vu55886">
    <a href="/manual/vote-note.php?id=55886&amp;page=features.file-upload&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd55886">
    <a href="/manual/vote-note.php?id=55886&amp;page=features.file-upload&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V55886" title="59% like this...">
    5
    </div>
  </div>
  <a href="#55886" class="name">
  <strong class="user"><em>myko AT blue needle DOT com</em></strong></a><a class="genanchor" href="#55886"> &para;</a><div class="date" title="2005-08-16 09:13"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom55886">
<div class="phpcode"><code><span class="html">
Just a quick note that there's an issue with Apache, the MAX_FILE_SIZE hidden form field, and zlib.output_compression = On.&nbsp; Seems that the browser continues to post up the entire file, even though PHP throws the MAX_FILE_SIZE error properly.&nbsp; Turning zlib compression to OFF seems to solve the issue.&nbsp; Don't have time to dig in and see who's at fault, but wanted to save others the hassle of banging their head on this one.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="74692">  <div class="votes">
    <div id="Vu74692">
    <a href="/manual/vote-note.php?id=74692&amp;page=features.file-upload&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd74692">
    <a href="/manual/vote-note.php?id=74692&amp;page=features.file-upload&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V74692" title="57% like this...">
    11
    </div>
  </div>
  <a href="#74692" class="name">
  <strong class="user"><em>svenr at selfhtml dot org</em></strong></a><a class="genanchor" href="#74692"> &para;</a><div class="date" title="2007-04-23 03:13"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom74692">
<div class="phpcode"><code><span class="html">
Clarification on the MAX_FILE_SIZE hidden form field:<br /><br />PHP has the somewhat strange feature of checking multiple "maximum file sizes". <br /><br />The two widely known limits are the php.ini settings "post_max_size" and "upload_max_size", which in combination impose a hard limit on the maximum amount of data that can be received.<br /><br />In addition to this PHP somehow got implemented a soft limit feature. It checks the existance of a form field names "max_file_size" (upper case is also OK), which should contain an integer with the maximum number of bytes allowed. If the uploaded file is bigger than the integer in this field, PHP disallows this upload and presents an error code in the $_FILES-Array.<br /><br />The PHP documentation also makes (or made - see bug #40387 - <a href="http://bugs.php.net/bug.php?id=40387" rel="nofollow" target="_blank">http://bugs.php.net/bug.php?id=40387</a>) vague references to "allows browsers to check the file size before uploading". This, however, is not true and has never been. Up til today there has never been a RFC proposing the usage of such named form field, nor has there been a browser actually checking its existance or content, or preventing anything. The PHP documentation implies that a browser may alert the user that his upload is too big - this is simply wrong.<br /><br />Please note that using this PHP feature is not a good idea. A form field can easily be changed by the client. If you have to check the size of a file, do it conventionally within your script, using a script-defined integer, not an arbitrary number you got from the HTTP client (which always must be mistrusted from a security standpoint).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="39796">  <div class="votes">
    <div id="Vu39796">
    <a href="/manual/vote-note.php?id=39796&amp;page=features.file-upload&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd39796">
    <a href="/manual/vote-note.php?id=39796&amp;page=features.file-upload&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V39796" title="58% like this...">
    7
    </div>
  </div>
  <a href="#39796" class="name">
  <strong class="user"><em>~caetin~ ( at ) ~hotpop~ ( dot ) ~com~</em></strong></a><a class="genanchor" href="#39796"> &para;</a><div class="date" title="2004-02-10 08:37"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom39796">
<div class="phpcode"><code><span class="html">
From the manual: <br /><br />&nbsp; &nbsp;&nbsp; If no file is selected for upload in your form, PHP will return $_FILES['userfile']['size'] as 0, and $_FILES['userfile']['tmp_name'] as none. <br /><br />As of PHP 4.2.0, the "none" is no longer a reliable determinant of no file uploaded. It's documented if you click on the "error codes" link, but you need to look at the $_FILES['your_file']['error']. If it's 4, then no file was selected.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="82762">  <div class="votes">
    <div id="Vu82762">
    <a href="/manual/vote-note.php?id=82762&amp;page=features.file-upload&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd82762">
    <a href="/manual/vote-note.php?id=82762&amp;page=features.file-upload&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V82762" title="56% like this...">
    5
    </div>
  </div>
  <a href="#82762" class="name">
  <strong class="user"><em>Rob</em></strong></a><a class="genanchor" href="#82762"> &para;</a><div class="date" title="2008-04-24 01:07"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom82762">
<div class="phpcode"><code><span class="html">
You should not have any directories within your website root that has the permissions required for file upload.&nbsp; If you are going to do a file upload, I recommend you use the PHP FTP Functions in conjunction with your file field, that way the files are transferred to a remote FTP location separate from your server.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="53133">  <div class="votes">
    <div id="Vu53133">
    <a href="/manual/vote-note.php?id=53133&amp;page=features.file-upload&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd53133">
    <a href="/manual/vote-note.php?id=53133&amp;page=features.file-upload&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V53133" title="55% like this...">
    13
    </div>
  </div>
  <a href="#53133" class="name">
  <strong class="user"><em>keith at phpdiary dot org</em></strong></a><a class="genanchor" href="#53133"> &para;</a><div class="date" title="2005-05-24 04:14"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom53133">
<div class="phpcode"><code><span class="html">
Caution: *DO NOT* trust $_FILES['userfile']['type'] to verify the uploaded filetype; if you do so your server could be compromised.&nbsp; I'll show you why below:<br /><br />The manual (if you scroll above) states: $_FILES['userfile']['type'] -&nbsp; The mime type of the file, if the browser provided this information. An example would be "image/gif".<br /><br />Be reminded that this mime type can easily be faked as PHP doesn't go very far in verifying whether it really is what the end user reported!<br /><br />So, someone could upload a nasty .php script as an "image/gif" and execute the url to the "image".<br /><br />My best bet would be for you to check the extension of the file and using exif_imagetype() to check for valid images.&nbsp; Many people have suggested the use of getimagesize() which returns an array if the file is indeed an image and false otherwise, but exif_imagetype() is much faster. (the manual says it so)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="87989">  <div class="votes">
    <div id="Vu87989">
    <a href="/manual/vote-note.php?id=87989&amp;page=features.file-upload&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd87989">
    <a href="/manual/vote-note.php?id=87989&amp;page=features.file-upload&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V87989" title="55% like this...">
    4
    </div>
  </div>
  <a href="#87989" class="name">
  <strong class="user"><em>damien from valex</em></strong></a><a class="genanchor" href="#87989"> &para;</a><div class="date" title="2009-01-04 05:53"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom87989">
<div class="phpcode"><code><span class="html">
This is simpler method of checking for too much POST data (alternative to that by v3 from sonic-world.ru).<br /><br /><span class="default">&lt;?php<br />&nbsp; &nbsp; </span><span class="keyword">if (</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'REQUEST_METHOD'</span><span class="keyword">] == </span><span class="string">'POST' </span><span class="keyword">&amp;&amp; empty(</span><span class="default">$_POST</span><span class="keyword">) &amp;&amp; </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'CONTENT_LENGTH'</span><span class="keyword">] &gt; </span><span class="default">0</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; throw new </span><span class="default">Exception</span><span class="keyword">(</span><span class="default">sprintf</span><span class="keyword">(</span><span class="string">'The server was unable to handle that much POST data (%s bytes) due to its current configuration'</span><span class="keyword">, </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'CONTENT_LENGTH'</span><span class="keyword">]));<br />&nbsp; &nbsp; }<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="19926">  <div class="votes">
    <div id="Vu19926">
    <a href="/manual/vote-note.php?id=19926&amp;page=features.file-upload&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd19926">
    <a href="/manual/vote-note.php?id=19926&amp;page=features.file-upload&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V19926" title="56% like this...">
    3
    </div>
  </div>
  <a href="#19926" class="name">
  <strong class="user"><em>am at netactor dot NO_SPAN dot com</em></strong></a><a class="genanchor" href="#19926"> &para;</a><div class="date" title="2002-03-14 10:20"><strong>15 years ago</strong></div>
  <div class="text" id="Hcom19926">
<div class="phpcode"><code><span class="html">
Your binary files may be uploaded incorrectly if you use modules what recode characters. For example, for Russian Apache, you should use <br />&lt;Files ScriptThatReceivesUploads.php&gt;<br />CharsetDisable On<br />&lt;/Files&gt;</span>
</code></div>
  </div>
 </div>
  <div class="note" id="88591">  <div class="votes">
    <div id="Vu88591">
    <a href="/manual/vote-note.php?id=88591&amp;page=features.file-upload&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd88591">
    <a href="/manual/vote-note.php?id=88591&amp;page=features.file-upload&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V88591" title="53% like this...">
    7
    </div>
  </div>
  <a href="#88591" class="name">
  <strong class="user"><em>info at levaravel dot com</em></strong></a><a class="genanchor" href="#88591"> &para;</a><div class="date" title="2009-01-30 07:39"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom88591">
<div class="phpcode"><code><span class="html">
A little codesnippet which returns a filesize in a more legible format.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">display_filesize</span><span class="keyword">(</span><span class="default">$filesize</span><span class="keyword">){<br />&nbsp; &nbsp; <br />&nbsp; &nbsp; if(</span><span class="default">is_numeric</span><span class="keyword">(</span><span class="default">$filesize</span><span class="keyword">)){<br />&nbsp; &nbsp; </span><span class="default">$decr </span><span class="keyword">= </span><span class="default">1024</span><span class="keyword">; </span><span class="default">$step </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />&nbsp; &nbsp; </span><span class="default">$prefix </span><span class="keyword">= array(</span><span class="string">'Byte'</span><span class="keyword">,</span><span class="string">'KB'</span><span class="keyword">,</span><span class="string">'MB'</span><span class="keyword">,</span><span class="string">'GB'</span><span class="keyword">,</span><span class="string">'TB'</span><span class="keyword">,</span><span class="string">'PB'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; while((</span><span class="default">$filesize </span><span class="keyword">/ </span><span class="default">$decr</span><span class="keyword">) &gt; </span><span class="default">0.9</span><span class="keyword">){<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$filesize </span><span class="keyword">= </span><span class="default">$filesize </span><span class="keyword">/ </span><span class="default">$decr</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$step</span><span class="keyword">++;<br />&nbsp; &nbsp; } <br />&nbsp; &nbsp; return </span><span class="default">round</span><span class="keyword">(</span><span class="default">$filesize</span><span class="keyword">,</span><span class="default">2</span><span class="keyword">).</span><span class="string">' '</span><span class="keyword">.</span><span class="default">$prefix</span><span class="keyword">[</span><span class="default">$step</span><span class="keyword">];<br />&nbsp; &nbsp; } else {<br /><br />&nbsp; &nbsp; return </span><span class="string">'NaN'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; &nbsp; <br />}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="48809">  <div class="votes">
    <div id="Vu48809">
    <a href="/manual/vote-note.php?id=48809&amp;page=features.file-upload&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd48809">
    <a href="/manual/vote-note.php?id=48809&amp;page=features.file-upload&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V48809" title="54% like this...">
    3
    </div>
  </div>
  <a href="#48809" class="name">
  <strong class="user"><em>Tyfud</em></strong></a><a class="genanchor" href="#48809"> &para;</a><div class="date" title="2005-01-07 08:44"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom48809">
<div class="phpcode"><code><span class="html">
It's important to note that when using the move_uploaded_file() command, that some configurations (Especially IIS) will fail if you prefix the destination path with a leading "/". Try the following:<br /><br /><span class="default">&lt;?php move_uploaded_file</span><span class="keyword">(</span><span class="default">$tmpFileName</span><span class="keyword">,</span><span class="string">'uploads/'</span><span class="keyword">.</span><span class="default">$fileName</span><span class="keyword">); </span><span class="default">?&gt;<br /></span><br />Setting up permissions is also a must. Make sure all accounts have write access to your upload directory, and read access if you wish to view these files later. You might have to chmod() the directory or file afterwards as well if you're still getting access errors.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="55958">  <div class="votes">
    <div id="Vu55958">
    <a href="/manual/vote-note.php?id=55958&amp;page=features.file-upload&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd55958">
    <a href="/manual/vote-note.php?id=55958&amp;page=features.file-upload&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V55958" title="53% like this...">
    3
    </div>
  </div>
  <a href="#55958" class="name">
  <strong class="user"><em>warwickbarnes at yahoo dot co dot uk</em></strong></a><a class="genanchor" href="#55958"> &para;</a><div class="date" title="2005-08-18 04:58"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom55958">
<div class="phpcode"><code><span class="html">
You may come across the following problem using PHP on Microsoft IIS: getting permission denied errors from the move_uploaded_file function even when all the folder permissions seem correct. I had to set the following to get it to work:<br /><br />1. Write permissions on the the folder through the IIS management console.<br />2. Write permissions to IUSR_'server' in the folder's security settings.<br />3. Write permissions to "Domain Users" in the folder's security settings.<br /><br />The third setting was required because my application itself lives in a secure folder - using authentication (either Basic or Windows Integrated) to identify the users. When the uploads happen IIS seems to be checking that these users have write access to the folder, not just whether the web server (IUSR_'server') has access.<br /><br />Also, remember to set "Execute Permissions" to "None" in the IIS management console, so that people can't upload a script file and then run it. (Other checks of the uploaded file are recommended as well but 'Execute None' is a good start.)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="109495">  <div class="votes">
    <div id="Vu109495">
    <a href="/manual/vote-note.php?id=109495&amp;page=features.file-upload&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd109495">
    <a href="/manual/vote-note.php?id=109495&amp;page=features.file-upload&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V109495" title="50% like this...">
    1
    </div>
  </div>
  <a href="#109495" class="name">
  <strong class="user"><em>Thomas</em></strong></a><a class="genanchor" href="#109495"> &para;</a><div class="date" title="2012-07-22 06:08"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom109495">
<div class="phpcode"><code><span class="html">
MIME type can be faked.<br /><br />VVV<br /><br />$_FILES['userfile']['type']<br /><br />The mime type of the file, if the browser provided this information. An example would be "image/gif". This mime type is however not checked on the PHP side and therefore don't take its value for granted.<br /><br /><a href="http://www.php.net/manual/en/features.file-upload.post-method.php" rel="nofollow" target="_blank">http://www.php.net/manual/en/features.file-upload.post-method.php</a><br /><br />[Editor's note: removed a reference to a deleted note, and edited the note to make sense by itself.]</span>
</code></div>
  </div>
 </div>
  <div class="note" id="39654">  <div class="votes">
    <div id="Vu39654">
    <a href="/manual/vote-note.php?id=39654&amp;page=features.file-upload&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd39654">
    <a href="/manual/vote-note.php?id=39654&amp;page=features.file-upload&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V39654" title="52% like this...">
    1
    </div>
  </div>
  <a href="#39654" class="name">
  <strong class="user"><em>maya_gomez ~ at ~ mail ~ dot ~ ru</em></strong></a><a class="genanchor" href="#39654"> &para;</a><div class="date" title="2004-02-06 05:20"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom39654">
<div class="phpcode"><code><span class="html">
when you upload the file, $_FILES['file']['name'] contains its original name converted into server's default charset.<br />if a name contain characters that aren't present in default charset, the conversion fails and the $_FILES['file']['name'] remains in original charset.<br /><br />i've got this behavior when uploading from a windows-1251 environment into koi8-r. if a filename has the number sign "�" (0xb9), it DOES NOT GET CONVERTED as soon as there is no such character in koi8-r.<br /><br />Workaround i use:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">if (</span><span class="default">strstr </span><span class="keyword">(</span><span class="default">$_FILES</span><span class="keyword">[</span><span class="string">'file'</span><span class="keyword">][</span><span class="string">'name'</span><span class="keyword">], </span><span class="default">chr</span><span class="keyword">(</span><span class="default">0xb9</span><span class="keyword">)) != </span><span class="string">""</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; </span><span class="default">$_FILES</span><span class="keyword">[</span><span class="string">'file'</span><span class="keyword">][</span><span class="string">'name'</span><span class="keyword">] = </span><span class="default">iconv </span><span class="keyword">(<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">"windows-1251"</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="string">"koi8-r"</span><span class="keyword">,<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">str_replace </span><span class="keyword">(</span><span class="default">chr</span><span class="keyword">(</span><span class="default">0xb9</span><span class="keyword">), </span><span class="string">"N."</span><span class="keyword">, </span><span class="default">$_FILES</span><span class="keyword">[</span><span class="string">'file'</span><span class="keyword">][</span><span class="string">'name'</span><span class="keyword">]));<br />};<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="41615">  <div class="votes">
    <div id="Vu41615">
    <a href="/manual/vote-note.php?id=41615&amp;page=features.file-upload&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd41615">
    <a href="/manual/vote-note.php?id=41615&amp;page=features.file-upload&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V41615" title="52% like this...">
    1
    </div>
  </div>
  <a href="#41615" class="name">
  <strong class="user"><em>steve dot criddle at crd-sector dot com</em></strong></a><a class="genanchor" href="#41615"> &para;</a><div class="date" title="2004-04-16 11:43"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom41615">
<div class="phpcode"><code><span class="html">
IE on the Mac is a bit troublesome.&nbsp; If you are uploading a file with an unknown file suffix, IE uploads the file with a mime type of "application/x-macbinary".&nbsp; The resulting file includes the resource fork wrapped around the file.&nbsp; Not terribly useful.<br /><br />The following code assumes that the mime type is in $type, and that you have loaded the file's contents into $content.&nbsp; If the file is in MacBinary format, it delves into the resource fork header, gets the length of the data fork (bytes 83-86) and uses that to get rid of the resource fork.<br /><br />(There is probably a better way to do it, but this solved my problem):<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">if (</span><span class="default">$type </span><span class="keyword">== </span><span class="string">'application/x-macbinary'</span><span class="keyword">) {<br />&nbsp; &nbsp; if (</span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$content</span><span class="keyword">) &lt; </span><span class="default">128</span><span class="keyword">) die(</span><span class="string">'File too small'</span><span class="keyword">);<br />&nbsp; &nbsp; </span><span class="default">$length </span><span class="keyword">= </span><span class="default">0</span><span class="keyword">;<br />&nbsp; &nbsp; for (</span><span class="default">$i</span><span class="keyword">=</span><span class="default">83</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">&lt;=</span><span class="default">86</span><span class="keyword">; </span><span class="default">$i</span><span class="keyword">++) {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$length </span><span class="keyword">= (</span><span class="default">$length </span><span class="keyword">* </span><span class="default">256</span><span class="keyword">) + </span><span class="default">ord</span><span class="keyword">(</span><span class="default">substr</span><span class="keyword">(</span><span class="default">$content</span><span class="keyword">,</span><span class="default">$i</span><span class="keyword">,</span><span class="default">1</span><span class="keyword">));<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; </span><span class="default">$content </span><span class="keyword">= </span><span class="default">substr</span><span class="keyword">(</span><span class="default">$content</span><span class="keyword">,</span><span class="default">128</span><span class="keyword">,</span><span class="default">$length</span><span class="keyword">);<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="60024">  <div class="votes">
    <div id="Vu60024">
    <a href="/manual/vote-note.php?id=60024&amp;page=features.file-upload&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd60024">
    <a href="/manual/vote-note.php?id=60024&amp;page=features.file-upload&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V60024" title="51% like this...">
    1
    </div>
  </div>
  <a href="#60024" class="name">
  <strong class="user"><em>geert dot php at myrosoft dot com</em></strong></a><a class="genanchor" href="#60024"> &para;</a><div class="date" title="2005-12-23 12:16"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom60024">
<div class="phpcode"><code><span class="html">
When file names do contain single quote parts of the filename are being lost.<br />eg.: uploading a filename <br />&nbsp; &nbsp; &nbsp; startName 'middlepart' endName.txt<br />will be uploaded (and hence stored in the _Files ['userfile'] variable as <br />&nbsp; &nbsp; &nbsp; endName.txt <br />skipping everything before the second single quote.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="51541">  <div class="votes">
    <div id="Vu51541">
    <a href="/manual/vote-note.php?id=51541&amp;page=features.file-upload&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd51541">
    <a href="/manual/vote-note.php?id=51541&amp;page=features.file-upload&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V51541" title="51% like this...">
    1
    </div>
  </div>
  <a href="#51541" class="name">
  <strong class="user"><em>robpet at tds dot net</em></strong></a><a class="genanchor" href="#51541"> &para;</a><div class="date" title="2005-04-02 10:35"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom51541">
<div class="phpcode"><code><span class="html">
People have remarked that incorrect permissions on the upload directory may prevent photos or other files from uploading.&nbsp; Setting the Apache owner of the directory incorrectly will also prevent files from uploading -- I use a PHP script that creates a directory (if it doesn't exist already) before placing an uploaded file into it.&nbsp; When the script creates the directory and then copies the uploaded file into the directory there is no problem because the owner of the file is whatever Apache is running as, typically "nobody". However, lets say that I've moved the site to a new server and have copied over existing file directories using FTP.&nbsp; In this case the owner will have a different name from the Apache owner and files will not upload. The solution is to TelNet into the site and reset the owner to "nobody" or whatever Apache is running as using the CHOWN command.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="87216">  <div class="votes">
    <div id="Vu87216">
    <a href="/manual/vote-note.php?id=87216&amp;page=features.file-upload&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd87216">
    <a href="/manual/vote-note.php?id=87216&amp;page=features.file-upload&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V87216" title="50% like this...">
    0
    </div>
  </div>
  <a href="#87216" class="name">
  <strong class="user"><em>rnagavel at yahoo dot com dot au</em></strong></a><a class="genanchor" href="#87216"> &para;</a><div class="date" title="2008-11-25 01:10"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom87216">
<div class="phpcode"><code><span class="html">
If $_FILES is always empty, check the method of your form.<br />It should be POST. Default method of a form is GET.<br /><br />&lt;form action="myaction.php"&gt;<br /> &lt;input type="file" name"userfile"&gt;<br />&lt;/form&gt;<br />File will not be uploaded as default method of the form is GET.<br /><br />&lt;form action="myaction.php" method="POST"&gt;<br /> &lt;input type="file" name"userfile"&gt;<br />&lt;/form&gt;<br />Files will be uploaded and $_FILES will be populated.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="66025">  <div class="votes">
    <div id="Vu66025">
    <a href="/manual/vote-note.php?id=66025&amp;page=features.file-upload&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd66025">
    <a href="/manual/vote-note.php?id=66025&amp;page=features.file-upload&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V66025" title="50% like this...">
    0
    </div>
  </div>
  <a href="#66025" class="name">
  <strong class="user"><em>david at cygnet dot be</em></strong></a><a class="genanchor" href="#66025"> &para;</a><div class="date" title="2006-05-12 05:14"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom66025">
<div class="phpcode"><code><span class="html">
If you are experiencing problems posting files from Internet Explorer to a PHP script over an SSL connection, for instance "Page can not be displayed" or empty $_FILES and $_POST arrays (described by jason 10-Jan-2006 02:08), then check out this microsoft knowledgebase article:<br /><br /><a href="http://support.microsoft.com/?kbid=889334" rel="nofollow" target="_blank">http://support.microsoft.com/?kbid=889334</a><br /><br />This knowledgebase article explains how since service pack 2 there may be problems posting from IE over SSL. It is worth checking whether your problem is IE specific since this is definitely not a PHP problem!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="56138">  <div class="votes">
    <div id="Vu56138">
    <a href="/manual/vote-note.php?id=56138&amp;page=features.file-upload&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd56138">
    <a href="/manual/vote-note.php?id=56138&amp;page=features.file-upload&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V56138" title="50% like this...">
    0
    </div>
  </div>
  <a href="#56138" class="name">
  <strong class="user"><em>mariodivece at bytedive dot com</em></strong></a><a class="genanchor" href="#56138"> &para;</a><div class="date" title="2005-08-24 11:33"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom56138">
<div class="phpcode"><code><span class="html">
Just wanted to point out a detail that might be of interest to some:<br /><br />when using base64_encode to store binary data in a database, you are increasing the size of the data by 1.33 times. There is a nicer way of storing the data directly. Try the following: <br /><br /><span class="default">&lt;?php $data </span><span class="keyword">= </span><span class="default">mysql_real_escape_string</span><span class="keyword">(</span><span class="default">$data</span><span class="keyword">); </span><span class="default">?&gt;<br /></span><br />This will leave the data untouched and formatted in the correct way and ready to be inserted right into a MySQL statement without wasting space.<br /><br />By the way, I'd like to thank therebechips for his excellent advice on data chunks.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="49807">  <div class="votes">
    <div id="Vu49807">
    <a href="/manual/vote-note.php?id=49807&amp;page=features.file-upload&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd49807">
    <a href="/manual/vote-note.php?id=49807&amp;page=features.file-upload&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V49807" title="50% like this...">
    0
    </div>
  </div>
  <a href="#49807" class="name">
  <strong class="user"><em>Leevi at izilla dot com dot au</em></strong></a><a class="genanchor" href="#49807"> &para;</a><div class="date" title="2005-02-08 10:52"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom49807">
<div class="phpcode"><code><span class="html">
This may help a newbie to file uploads.. it took advice from a friend to fix it..<br /><br />If you are using<br />-windows xp<br />-iis 5<br />-php 5<br /><br />If you keep getting permission errors on file uploads... and you have sworn you set the permissions to write to the directory in iis... <br /><br />double check that<br />a) in windows explorer under tools &gt; folder options<br />click the view tab<br />scroll down all the way to "use simple file sharing (recommended)"<br />uncheck this box<br /><br />b) find the folder you wish to upload to on your server<br />c) click properties and then the security tab<br />d) make sure the appropriate write settings are checked.<br /><br />you may want to test by setting "everyone" to have full permission....<br /><br />BEWARE doing this will open up big security holes on your server....<br /><br />hope this helps<br /><br />Leevi Graham</span>
</code></div>
  </div>
 </div>
  <div class="note" id="45168">  <div class="votes">
    <div id="Vu45168">
    <a href="/manual/vote-note.php?id=45168&amp;page=features.file-upload&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd45168">
    <a href="/manual/vote-note.php?id=45168&amp;page=features.file-upload&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V45168" title="50% like this...">
    0
    </div>
  </div>
  <a href="#45168" class="name">
  <strong class="user"><em>therhinoman at hotmail dot com</em></strong></a><a class="genanchor" href="#45168"> &para;</a><div class="date" title="2004-08-27 01:20"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom45168">
<div class="phpcode"><code><span class="html">
If your upload script is meant only for uploading images, you can use the image function getimagesize() (does not require the GD image library) to make sure you're really getting an image and also filter image types.<br /><br /><span class="default">&lt;?php getimagesize</span><span class="keyword">(</span><span class="default">$file</span><span class="keyword">); </span><span class="default">?&gt;<br /></span><br />...will return false if the file is not an image or is not accessable, otherwise it will return an array...<br /><br /><span class="default">&lt;?php<br />$file </span><span class="keyword">= </span><span class="string">'somefile.jpg'</span><span class="keyword">;<br /><br /></span><span class="comment"># assuming you've already taken some other<br /># preventive measures such as checking file<br /># extensions...<br /><br /></span><span class="default">$result_array </span><span class="keyword">= </span><span class="default">getimagesize</span><span class="keyword">(</span><span class="default">$file</span><span class="keyword">);<br /><br />if (</span><span class="default">$result_array </span><span class="keyword">!== </span><span class="default">false</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="default">$mime_type </span><span class="keyword">= </span><span class="default">$result_array</span><span class="keyword">[</span><span class="string">'mime'</span><span class="keyword">];<br />&nbsp; &nbsp; switch(</span><span class="default">$mime_type</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">"image/jpeg"</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"file is jpeg type"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; case </span><span class="string">"image/gif"</span><span class="keyword">:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"file is gif type"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; break;<br />&nbsp; &nbsp; &nbsp; &nbsp; default:<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="string">"file is an image, but not of gif or jpeg type"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />} else {<br />&nbsp; &nbsp; echo </span><span class="string">"file is not a valid image file"</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />using this function along with others mentioned on this page, image ploading can be made pretty much fool-proof.<br /><br />See <a href="http://php.net/manual/en/function.getimagesize.php" rel="nofollow" target="_blank">http://php.net/manual/en/function.getimagesize.php</a> for supported image types and more info.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="43372">  <div class="votes">
    <div id="Vu43372">
    <a href="/manual/vote-note.php?id=43372&amp;page=features.file-upload&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd43372">
    <a href="/manual/vote-note.php?id=43372&amp;page=features.file-upload&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V43372" title="50% like this...">
    0
    </div>
  </div>
  <a href="#43372" class="name">
  <strong class="user"><em>olijon, iceland</em></strong></a><a class="genanchor" href="#43372"> &para;</a><div class="date" title="2004-06-18 08:24"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom43372">
<div class="phpcode"><code><span class="html">
When uploading large images, I got a "Document contains no data" error when using Netscape and an error page when using Explorer. My server setup is RH Linux 9, Apache 2 and PHP 4.3.<br /><br />I found out that the following entry in the httpd.conf file was missing:<br /><br />&lt;Files *.php&gt;<br />&nbsp; SetOutputFilter PHP<br />&nbsp; SetInputFilter PHP<br />&nbsp; LimitRequestBody 524288 (max size in bytes)<br />&lt;/Files&gt;<br /><br />When this had been added, everything worked smoothly.<br /><br />- Oli Jon, Iceland</span>
</code></div>
  </div>
 </div>
  <div class="note" id="59156">  <div class="votes">
    <div id="Vu59156">
    <a href="/manual/vote-note.php?id=59156&amp;page=features.file-upload&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd59156">
    <a href="/manual/vote-note.php?id=59156&amp;page=features.file-upload&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V59156" title="47% like this...">
    -1
    </div>
  </div>
  <a href="#59156" class="name">
  <strong class="user"><em>djot at hotmail dot com</em></strong></a><a class="genanchor" href="#59156"> &para;</a><div class="date" title="2005-11-27 02:02"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom59156">
<div class="phpcode"><code><span class="html">
-<br />Be carefull with setting max_file_size via<br /><span class="default">&lt;?php ini_get</span><span class="keyword">(</span><span class="string">'upload_max_filesize'</span><span class="keyword">); </span><span class="default">?&gt;<br /></span><br />ini_get might return values like "2M" which will result in non working uploads.<br /><br />This was the "no no" in my case:<br /><br /><span class="default">&lt;?php<br />$form </span><span class="keyword">= </span><span class="string">'&lt;input type="hidden" name="MAX_FILE_SIZE" value=".ini_get('</span><span class="default">upload_max_filesize</span><span class="string">')." /&gt;'</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />Files were uploaded to the server, but than there was not any upload information, not even an error message. $_FILES was completly empty.<br /><br />djot<br />-</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116293">  <div class="votes">
    <div id="Vu116293">
    <a href="/manual/vote-note.php?id=116293&amp;page=features.file-upload&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116293">
    <a href="/manual/vote-note.php?id=116293&amp;page=features.file-upload&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116293" title="43% like this...">
    -5
    </div>
  </div>
  <a href="#116293" class="name">
  <strong class="user"><em>shubhamtakode at gmail dot com</em></strong></a><a class="genanchor" href="#116293"> &para;</a><div class="date" title="2014-12-07 05:04"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom116293">
<div class="phpcode"><code><span class="html">
// code for handling simple http uploads<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">//properties of the uploaded file<br /></span><span class="default">$name</span><span class="keyword">= </span><span class="default">$_FILES</span><span class="keyword">[</span><span class="string">"myfile"</span><span class="keyword">][</span><span class="string">"name"</span><span class="keyword">];<br /></span><span class="default">$type</span><span class="keyword">= </span><span class="default">$_FILES</span><span class="keyword">[</span><span class="string">"myfile"</span><span class="keyword">][</span><span class="string">"type"</span><span class="keyword">];<br /></span><span class="default">$size</span><span class="keyword">= </span><span class="default">$_FILES</span><span class="keyword">[</span><span class="string">"myfile"</span><span class="keyword">][</span><span class="string">"size"</span><span class="keyword">];<br /></span><span class="default">$temp</span><span class="keyword">= </span><span class="default">$_FILES</span><span class="keyword">[</span><span class="string">"myfile"</span><span class="keyword">][</span><span class="string">"temp_name"</span><span class="keyword">];<br /></span><span class="default">$error</span><span class="keyword">= </span><span class="default">$_FILES</span><span class="keyword">[</span><span class="string">"myfile"</span><span class="keyword">][</span><span class="string">"error"</span><span class="keyword">];<br /><br />if (</span><span class="default">$error </span><span class="keyword">&gt; </span><span class="default">0</span><span class="keyword">)<br /></span><span class="default">    </span><span class="keyword">die(</span><span class="string">"Error uploading file! code </span><span class="default">$error</span><span class="string">."</span><span class="keyword">);<br />else<br /></span><span class="default">   </span><span class="keyword">{<br /></span><span class="default">    </span><span class="keyword">if(</span><span class="default">$type</span><span class="keyword">==</span><span class="string">"image/png" </span><span class="keyword">|| </span><span class="default">$size </span><span class="keyword">&gt; </span><span class="default">2000000</span><span class="keyword">)</span><span class="comment">//condition for the file<br /></span><span class="default">    </span><span class="keyword">{<br /></span><span class="default">    </span><span class="keyword">die(</span><span class="string">"Format  not allowed or file size too big!"</span><span class="keyword">);<br /></span><span class="default">    </span><span class="keyword">}<br /></span><span class="default">    </span><span class="keyword">else<br /></span><span class="default">    </span><span class="keyword">{<br /></span><span class="default">     move_uploaded_file</span><span class="keyword">(</span><span class="default">$temp</span><span class="keyword">, </span><span class="string">"uploaded/" </span><span class="keyword">.</span><span class="default">$name</span><span class="keyword">);<br /></span><span class="default">     echo </span><span class="string">"Upload complete!"</span><span class="keyword">; <br /></span><span class="default">     </span><span class="keyword">}<br />}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="78017">  <div class="votes">
    <div id="Vu78017">
    <a href="/manual/vote-note.php?id=78017&amp;page=features.file-upload&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd78017">
    <a href="/manual/vote-note.php?id=78017&amp;page=features.file-upload&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V78017" title="42% like this...">
    -4
    </div>
  </div>
  <a href="#78017" class="name">
  <strong class="user"><em>ragtime at alice-dsl dot com</em></strong></a><a class="genanchor" href="#78017"> &para;</a><div class="date" title="2007-09-24 08:55"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom78017">
<div class="phpcode"><code><span class="html">
I don't believe the myth that 'memory_size' should be the size of the uploaded file. The files are definitely not kept in memory... instead uploaded chunks of 1MB each are stored under /var/tmp and later on rebuild under /tmp before moving to the web/user space.<br /><br />I'm running a linux-box with only 64MB RAM, setting the memory_limit to 16MB and uploading files of sizes about 100MB is no problem at all! Nevertheless, some users reported a problem at a few 100MB, but that's not confirmed... ;-)<br /><br />The other sizes in php.ini are set to 1GB and the times to 300... maybe the execution_time limits before, since the CPU is just a 233MHz one... :-)<br /><br />====<br /><br />OK,... I got it... finally!<br /><br />If some of you have also problems uploading large files but the usual sizes/times in php.ini are ok, please check <br /><br />&nbsp; &nbsp; session.gc_maxlifetime<br /><br />when you are using session management with your upload script!<br /><br />The default value is 1440 which is just 24min... so with only 600kbit/s upload rate the session will be closed automatically after uploading<br />about 100MB. Actually you are able to upload more, but the file won't be copied from the temporary to the destination folder... ;-)<br /><br />You can set the value also directly inside the php-script via <br /><span class="default">&lt;?php ini_set</span><span class="keyword">(</span><span class="string">"session.gc_maxlifetime"</span><span class="keyword">,</span><span class="string">"10800"</span><span class="keyword">); </span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="93602">  <div class="votes">
    <div id="Vu93602">
    <a href="/manual/vote-note.php?id=93602&amp;page=features.file-upload&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd93602">
    <a href="/manual/vote-note.php?id=93602&amp;page=features.file-upload&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V93602" title="40% like this...">
    -6
    </div>
  </div>
  <a href="#93602" class="name">
  <strong class="user"><em>Phil Ciebiera</em></strong></a><a class="genanchor" href="#93602"> &para;</a><div class="date" title="2009-09-17 01:54"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom93602">
<div class="phpcode"><code><span class="html">
On a Microsoft platform utilizing IIS, you may run into a situation where, upon moving the uploaded file, anonymous web users can't access the content without being prompted to authenticate first...<br /><br />The reason for this is, the uploaded file will inherit the permissions of the directory specified in the directive upload_tmp_dir of php.ini.&nbsp; If this directive isn't set, the default of C:\Windows\Temp is used.<br /><br />You can work around this by granting the IUSR_[server name] user read access to your temporary upload directory, so that after you move_uploaded_file the permissions will already be set properly.<br /><br />It's also a good idea to set the Execute Permissions of the upload directory to NOT include Executables, for security reasons.&nbsp; <br />To accomplish this:<br />-Open the IIS Manager<br />-Browse to the relevant sites directory where the uploads will be placed<br />-Right Click the folder and select Properties<br />-In the Directory tab of the resulting dialog, set the Execute permissions to be None<br /><br />This took me a while to figure out, so I hope this helps save some other peoples time.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="82869">  <div class="votes">
    <div id="Vu82869">
    <a href="/manual/vote-note.php?id=82869&amp;page=features.file-upload&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd82869">
    <a href="/manual/vote-note.php?id=82869&amp;page=features.file-upload&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V82869" title="40% like this...">
    -5
    </div>
  </div>
  <a href="#82869" class="name">
  <strong class="user"><em>jahajee</em></strong></a><a class="genanchor" href="#82869"> &para;</a><div class="date" title="2008-04-29 04:27"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom82869">
<div class="phpcode"><code><span class="html">
hi , i was having difficulty with the upload_max_filesize , if u set the max file size lesser than the php setting then ur script to report error will only work till this difference between ur max set file size and the php set max size .Hence if the uploaded file exceeds the php max file size then php end abruptly without a trace of error that is it behaves like no file is uploaded and hence no error reported .Sure if uploading a file is optional for a form then a user who uploads larger file will get no error and still the form will be processed only without the file.<br />The method of using GET can't be used for optional uploads. Can't find help even in the bugs .Be careful with optional uploads.<br />jahajee</span>
</code></div>
  </div>
 </div>
  <div class="note" id="30377">  <div class="votes">
    <div id="Vu30377">
    <a href="/manual/vote-note.php?id=30377&amp;page=features.file-upload&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd30377">
    <a href="/manual/vote-note.php?id=30377&amp;page=features.file-upload&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V30377" title="39% like this...">
    -5
    </div>
  </div>
  <a href="#30377" class="name">
  <strong class="user"><em>garyds at miraclemedia dot ca</em></strong></a><a class="genanchor" href="#30377"> &para;</a><div class="date" title="2003-03-15 06:12"><strong>14 years ago</strong></div>
  <div class="text" id="Hcom30377">
<div class="phpcode"><code><span class="html">
As it has been mentioned, Windows-based servers have trouble with the path to move the uploaded file to when using move_uploaded_file()... this may also be the reason copy() works and not move_uploaded_file(), but of course move_uploaded_file() is a much better method to use. The solution in the aforementioned note said you must use "\\" in the path, but I found "/" works as well. So to get a working path, I used something to the effect of:<br /><br />"g:/rootdir/default/www/".$_FILES['userfile']['name']<br /><br />...which worked like a charm.<br /><br />I am using PHP 4.3.0 on a win2k server.<br /><br />Hope this helps!</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=features.file-upload&amp;redirect=http://php.net/manual/en/features.file-upload.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="features.php">Features</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="features.http-auth.php" title="HTTP authentication with PHP">HTTP authentication with PHP</a>
                        </li>
                          
                        <li class="">
                            <a href="features.cookies.php" title="Cookies">Cookies</a>
                        </li>
                          
                        <li class="">
                            <a href="features.sessions.php" title="Sessions">Sessions</a>
                        </li>
                          
                        <li class="">
                            <a href="features.xforms.php" title="Dealing with XForms">Dealing with XForms</a>
                        </li>
                          
                        <li class="current">
                            <a href="features.file-upload.php" title="Handling file uploads">Handling file uploads</a>
                        </li>
                          
                        <li class="">
                            <a href="features.remote-files.php" title="Using remote files">Using remote files</a>
                        </li>
                          
                        <li class="">
                            <a href="features.connection-handling.php" title="Connection handling">Connection handling</a>
                        </li>
                          
                        <li class="">
                            <a href="features.persistent-connections.php" title="Persistent Database Connections">Persistent Database Connections</a>
                        </li>
                          
                        <li class="">
                            <a href="features.safe-mode.php" title="Safe Mode">Safe Mode</a>
                        </li>
                          
                        <li class="">
                            <a href="features.commandline.php" title="Command line usage">Command line usage</a>
                        </li>
                          
                        <li class="">
                            <a href="features.gc.php" title="Garbage Collection">Garbage Collection</a>
                        </li>
                          
                        <li class="">
                            <a href="features.dtrace.php" title="DTrace Dynamic Tracing">DTrace Dynamic Tracing</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

