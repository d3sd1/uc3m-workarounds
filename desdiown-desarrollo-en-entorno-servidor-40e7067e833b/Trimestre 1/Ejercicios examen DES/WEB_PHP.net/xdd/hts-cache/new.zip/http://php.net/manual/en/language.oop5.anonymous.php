<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: Anonymous classes - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.oop5.anonymous.php">
 <link rel="shorturl" href="http://php.net/oop5.anonymous">
 <link rel="alternate" href="http://php.net/oop5.anonymous" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.oop5.php">
 <link rel="prev" href="http://php.net/manual/en/language.oop5.traits.php">
 <link rel="next" href="http://php.net/manual/en/language.oop5.overloading.php">

 <link rel="alternate" href="http://php.net/manual/en/language.oop5.anonymous.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.oop5.anonymous.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.oop5.anonymous.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.oop5.anonymous.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.oop5.anonymous.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.oop5.anonymous.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.oop5.anonymous.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.oop5.anonymous.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.oop5.anonymous.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.oop5.anonymous.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.oop5.anonymous.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.oop5.overloading.php">
          Overloading &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.oop5.traits.php">
          &laquo; Traits        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.oop5.php'>Classes and Objects</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.oop5.anonymous.php' selected="selected">English</option>
            <option value='pt_BR/language.oop5.anonymous.php'>Brazilian Portuguese</option>
            <option value='zh/language.oop5.anonymous.php'>Chinese (Simplified)</option>
            <option value='fr/language.oop5.anonymous.php'>French</option>
            <option value='de/language.oop5.anonymous.php'>German</option>
            <option value='ja/language.oop5.anonymous.php'>Japanese</option>
            <option value='ro/language.oop5.anonymous.php'>Romanian</option>
            <option value='ru/language.oop5.anonymous.php'>Russian</option>
            <option value='es/language.oop5.anonymous.php'>Spanish</option>
            <option value='tr/language.oop5.anonymous.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.oop5.anonymous.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.oop5.anonymous">Report a Bug</a>
    </div>
  </div><div id="language.oop5.anonymous" class="sect1">
 <h2 class="title">Anonymous classes</h2>

 <p class="para">
  Support for anonymous classes was added in PHP 7. Anonymous classes are
  useful when simple, one-off objects need to be created.
 </p>

 <div class="informalexample">
  <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /><br /></span><span style="color: #FF8000">//&nbsp;Pre&nbsp;PHP&nbsp;7&nbsp;code<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">Logger<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">log</span><span style="color: #007700">(</span><span style="color: #0000BB">$msg</span><span style="color: #007700">)<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #0000BB">$msg</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br /></span><span style="color: #0000BB">$util</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">setLogger</span><span style="color: #007700">(new&nbsp;</span><span style="color: #0000BB">Logger</span><span style="color: #007700">());<br /><br /></span><span style="color: #FF8000">//&nbsp;PHP&nbsp;7+&nbsp;code<br /></span><span style="color: #0000BB">$util</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">setLogger</span><span style="color: #007700">(new&nbsp;class&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">log</span><span style="color: #007700">(</span><span style="color: #0000BB">$msg</span><span style="color: #007700">)<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #0000BB">$msg</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />});</span>
</span>
</code></div>
  </div>

 </div>

 <p class="para">
  They can pass arguments through to their constructors, extend other classes,
  implement interfaces, and use traits just like a normal class can:
 </p>

 <div class="informalexample">
  <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /><br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">SomeClass&nbsp;</span><span style="color: #007700">{}<br />interface&nbsp;</span><span style="color: #0000BB">SomeInterface&nbsp;</span><span style="color: #007700">{}<br />trait&nbsp;</span><span style="color: #0000BB">SomeTrait&nbsp;</span><span style="color: #007700">{}<br /><br /></span><span style="color: #0000BB">var_dump</span><span style="color: #007700">(new&nbsp;class(</span><span style="color: #0000BB">10</span><span style="color: #007700">)&nbsp;extends&nbsp;</span><span style="color: #0000BB">SomeClass&nbsp;</span><span style="color: #007700">implements&nbsp;</span><span style="color: #0000BB">SomeInterface&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;private&nbsp;</span><span style="color: #0000BB">$num</span><span style="color: #007700">;<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">__construct</span><span style="color: #007700">(</span><span style="color: #0000BB">$num</span><span style="color: #007700">)<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">num&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$num</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;use&nbsp;</span><span style="color: #0000BB">SomeTrait</span><span style="color: #007700">;<br />});</span>
</span>
</code></div>
  </div>

  <p class="para">The above example will output:</p>
  <div class="example-contents screen">
<div class="cdata"><pre>
object(class@anonymous)#1 (1) {
  [&quot;Command line code0x104c5b612&quot;:&quot;class@anonymous&quot;:private]=&gt;
  int(10)
}
</pre></div>
  </div>
 </div>

 <p class="para">
  Nesting an anonymous class within another class does not give it access to
  any private or protected methods or properties of that outer class. In order
  to use the outer class&#039; protected properties or methods, the anonymous class
  can extend the outer class. To use the private properties of
  the outer class in the anonymous class, they must be passed through its
  constructor:
 </p>

 <div class="informalexample">
  <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /><br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">Outer<br /></span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;private&nbsp;</span><span style="color: #0000BB">$prop&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;protected&nbsp;</span><span style="color: #0000BB">$prop2&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">2</span><span style="color: #007700">;<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;protected&nbsp;function&nbsp;</span><span style="color: #0000BB">func1</span><span style="color: #007700">()<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">3</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">func2</span><span style="color: #007700">()<br />&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;new&nbsp;class(</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">prop</span><span style="color: #007700">)&nbsp;extends&nbsp;</span><span style="color: #0000BB">Outer&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;private&nbsp;</span><span style="color: #0000BB">$prop3</span><span style="color: #007700">;<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">__construct</span><span style="color: #007700">(</span><span style="color: #0000BB">$prop</span><span style="color: #007700">)<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">prop3&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">$prop</span><span style="color: #007700">;<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}<br /><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;public&nbsp;function&nbsp;</span><span style="color: #0000BB">func3</span><span style="color: #007700">()<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">prop2&nbsp;</span><span style="color: #007700">+&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">prop3&nbsp;</span><span style="color: #007700">+&nbsp;</span><span style="color: #0000BB">$this</span><span style="color: #007700">-&gt;</span><span style="color: #0000BB">func1</span><span style="color: #007700">();<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;};<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /><br />echo&nbsp;(new&nbsp;</span><span style="color: #0000BB">Outer</span><span style="color: #007700">)-&gt;</span><span style="color: #0000BB">func2</span><span style="color: #007700">()-&gt;</span><span style="color: #0000BB">func3</span><span style="color: #007700">();</span>
</span>
</code></div>
  </div>

  <p class="para">The above example will output:</p>
  <div class="example-contents screen">
<div class="cdata"><pre>
6
</pre></div>
  </div>
 </div>

 <p class="para">
  All objects created by the same anonymous class declaration are instances of
  that very class.
 </p>

 <div class="informalexample">
  <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">anonymous_class</span><span style="color: #007700">()<br />{<br />&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;new&nbsp;class&nbsp;{};<br />}<br /><br />if&nbsp;(</span><span style="color: #0000BB">get_class</span><span style="color: #007700">(</span><span style="color: #0000BB">anonymous_class</span><span style="color: #007700">())&nbsp;===&nbsp;</span><span style="color: #0000BB">get_class</span><span style="color: #007700">(</span><span style="color: #0000BB">anonymous_class</span><span style="color: #007700">()))&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">'same&nbsp;class'</span><span style="color: #007700">;<br />}&nbsp;else&nbsp;{<br />&nbsp;&nbsp;&nbsp;&nbsp;echo&nbsp;</span><span style="color: #DD0000">'different&nbsp;class'</span><span style="color: #007700">;<br />}</span>
</span>
</code></div>
 </div>

 <p class="para">The above example will output:</p>
 <div class="example-contents screen">
<div class="cdata"><pre>
same class
</pre></div>
  </div>
 </div>

 <blockquote class="note"><p><strong class="note">Note</strong>: 
  <p class="para">
   Note that anonymous classes are assigned a name by the engine, as
   demonstrated in the following example. This name has to be regarded an
   implementation detail, which should not be relied upon.
  </p>
  <div class="informalexample">
   <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">echo&nbsp;</span><span style="color: #0000BB">get_class</span><span style="color: #007700">(new&nbsp;class&nbsp;{});</span>
</span>
</code></div>
  </div>

  <p class="para">The above example will output
something similar to:</p>
  <div class="example-contents screen">
<div class="cdata"><pre>
class@anonymous/in/oNi1A0x7f8636ad2021
</pre></div>
   </div>
  </div>
 </p></blockquote>
</div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.oop5.anonymous&amp;redirect=http://php.net/manual/en/language.oop5.anonymous.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">6 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="121055">  <div class="votes">
    <div id="Vu121055">
    <a href="/manual/vote-note.php?id=121055&amp;page=language.oop5.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121055">
    <a href="/manual/vote-note.php?id=121055&amp;page=language.oop5.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121055" title="100% like this...">
    3
    </div>
  </div>
  <a href="#121055" class="name">
  <strong class="user"><em>ytubeshareit at gmail dot com</em></strong></a><a class="genanchor" href="#121055"> &para;</a><div class="date" title="2017-05-06 01:59"><strong>7 months ago</strong></div>
  <div class="text" id="Hcom121055">
<div class="phpcode"><code><span class="html">
Anonymous classes are syntax sugar that may appear deceiving to some.<br />The 'anonymous' class is still parsed into the global scope, where it is auto assigned a name, and every time the class is needed, that global class definition is used.&nbsp; Example to illustrate....<br /><br />The anonymous class version...<br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">return_anon</span><span class="keyword">(){<br />&nbsp; &nbsp; return new class{<br />&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; public static </span><span class="default">$str</span><span class="keyword">=</span><span class="string">"foo"</span><span class="keyword">;&nbsp; <br />&nbsp; &nbsp; };<br />}<br /></span><span class="default">$test</span><span class="keyword">=</span><span class="default">return_anon</span><span class="keyword">();<br />echo </span><span class="default">$test</span><span class="keyword">::</span><span class="default">$str</span><span class="keyword">; </span><span class="comment">//ouputs foo<br /><br />//we can still access the 'anon' class directly in the global scope! <br /></span><span class="default">$another</span><span class="keyword">=</span><span class="default">get_class</span><span class="keyword">(</span><span class="default">$test</span><span class="keyword">); </span><span class="comment">//get the auto assigned name<br /></span><span class="keyword">echo </span><span class="default">$another</span><span class="keyword">::</span><span class="default">$str</span><span class="keyword">;&nbsp; &nbsp; </span><span class="comment">//outputs foo<br /></span><span class="default">?&gt;<br /></span><br />The above is functionally the same as doing this....<br /><span class="default">&lt;?php<br /></span><span class="keyword">class </span><span class="default">I_named_this_one</span><span class="keyword">{<br />&nbsp; &nbsp; public static </span><span class="default">$str</span><span class="keyword">=</span><span class="string">"foo"</span><span class="keyword">;<br />}<br />function </span><span class="default">return_not_anon</span><span class="keyword">(){<br />&nbsp; &nbsp; return </span><span class="string">'I_named_this_one'</span><span class="keyword">;<br />}<br /></span><span class="default">$clzz</span><span class="keyword">=</span><span class="default">return_not_anon</span><span class="keyword">();</span><span class="comment">//get class name<br /></span><span class="keyword">echo </span><span class="default">$clzz</span><span class="keyword">::</span><span class="default">$str</span><span class="keyword">;<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119055">  <div class="votes">
    <div id="Vu119055">
    <a href="/manual/vote-note.php?id=119055&amp;page=language.oop5.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119055">
    <a href="/manual/vote-note.php?id=119055&amp;page=language.oop5.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119055" title="67% like this...">
    19
    </div>
  </div>
  <a href="#119055" class="name">
  <strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#119055"> &para;</a><div class="date" title="2016-03-25 06:52"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119055">
<div class="phpcode"><code><span class="html">
Below three examples describe anonymous class with very simple and basic but quite understandable example<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">// First way - anonymous class assigned directly to variable<br /></span><span class="default">$ano_class_obj </span><span class="keyword">= new class{<br />&nbsp; &nbsp; public </span><span class="default">$prop1 </span><span class="keyword">= </span><span class="string">'hello'</span><span class="keyword">;<br />&nbsp; &nbsp; public </span><span class="default">$prop2 </span><span class="keyword">= </span><span class="default">754</span><span class="keyword">;<br />&nbsp; &nbsp; const </span><span class="default">SETT </span><span class="keyword">= </span><span class="string">'some config'</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public function </span><span class="default">getValue</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// do some operation<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">return </span><span class="string">'some returned value'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">getValueWithArgu</span><span class="keyword">(</span><span class="default">$str</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// do some operation<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">return </span><span class="string">'returned value is '</span><span class="keyword">.</span><span class="default">$str</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />};<br /><br />echo </span><span class="string">"\n"</span><span class="keyword">;<br /><br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$ano_class_obj</span><span class="keyword">);<br />echo </span><span class="string">"\n"</span><span class="keyword">;<br /><br />echo </span><span class="default">$ano_class_obj</span><span class="keyword">-&gt;</span><span class="default">prop1</span><span class="keyword">;<br />echo </span><span class="string">"\n"</span><span class="keyword">;<br /><br />echo </span><span class="default">$ano_class_obj</span><span class="keyword">-&gt;</span><span class="default">prop2</span><span class="keyword">;<br />echo </span><span class="string">"\n"</span><span class="keyword">;<br /><br />echo </span><span class="default">$ano_class_obj</span><span class="keyword">::</span><span class="default">SETT</span><span class="keyword">;<br />echo </span><span class="string">"\n"</span><span class="keyword">;<br /><br />echo </span><span class="default">$ano_class_obj</span><span class="keyword">-&gt;</span><span class="default">getValue</span><span class="keyword">();<br />echo </span><span class="string">"\n"</span><span class="keyword">;<br /><br />echo </span><span class="default">$ano_class_obj</span><span class="keyword">-&gt;</span><span class="default">getValueWithArgu</span><span class="keyword">(</span><span class="string">'OOP'</span><span class="keyword">);<br />echo </span><span class="string">"\n"</span><span class="keyword">;<br /><br />echo </span><span class="string">"\n"</span><span class="keyword">;<br /><br /></span><span class="comment">// Second way - anonymous class assigned to variable via defined function<br /></span><span class="default">$ano_class_obj_with_func </span><span class="keyword">= </span><span class="default">ano_func</span><span class="keyword">();<br /><br />function </span><span class="default">ano_func</span><span class="keyword">()<br />{<br />&nbsp; &nbsp; return new class {<br />&nbsp; &nbsp; &nbsp; &nbsp; public </span><span class="default">$prop1 </span><span class="keyword">= </span><span class="string">'hello'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; public </span><span class="default">$prop2 </span><span class="keyword">= </span><span class="default">754</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; const </span><span class="default">SETT </span><span class="keyword">= </span><span class="string">'some config'</span><span class="keyword">;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; public function </span><span class="default">getValue</span><span class="keyword">()<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// do some operation<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">return </span><span class="string">'some returned value'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; public function </span><span class="default">getValueWithArgu</span><span class="keyword">(</span><span class="default">$str</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// do some operation<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">return </span><span class="string">'returned value is '</span><span class="keyword">.</span><span class="default">$str</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; };<br />}<br /><br />echo </span><span class="string">"\n"</span><span class="keyword">;<br /><br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$ano_class_obj_with_func</span><span class="keyword">);<br />echo </span><span class="string">"\n"</span><span class="keyword">;<br /><br />echo </span><span class="default">$ano_class_obj_with_func</span><span class="keyword">-&gt;</span><span class="default">prop1</span><span class="keyword">;<br />echo </span><span class="string">"\n"</span><span class="keyword">;<br /><br />echo </span><span class="default">$ano_class_obj_with_func</span><span class="keyword">-&gt;</span><span class="default">prop2</span><span class="keyword">;<br />echo </span><span class="string">"\n"</span><span class="keyword">;<br /><br />echo </span><span class="default">$ano_class_obj_with_func</span><span class="keyword">::</span><span class="default">SETT</span><span class="keyword">;<br />echo </span><span class="string">"\n"</span><span class="keyword">;<br /><br />echo </span><span class="default">$ano_class_obj_with_func</span><span class="keyword">-&gt;</span><span class="default">getValue</span><span class="keyword">();<br />echo </span><span class="string">"\n"</span><span class="keyword">;<br /><br />echo </span><span class="default">$ano_class_obj_with_func</span><span class="keyword">-&gt;</span><span class="default">getValueWithArgu</span><span class="keyword">(</span><span class="string">'OOP'</span><span class="keyword">);<br />echo </span><span class="string">"\n"</span><span class="keyword">;<br /><br />echo </span><span class="string">"\n"</span><span class="keyword">;<br /><br /></span><span class="comment">// Third way - passing argument to anonymous class via constructors<br /></span><span class="default">$arg </span><span class="keyword">= </span><span class="default">1</span><span class="keyword">; </span><span class="comment">// we got it by some operation<br /></span><span class="default">$config </span><span class="keyword">= [</span><span class="default">2</span><span class="keyword">, </span><span class="default">false</span><span class="keyword">]; </span><span class="comment">// we got it by some operation<br /></span><span class="default">$ano_class_obj_with_arg </span><span class="keyword">= </span><span class="default">ano_func_with_arg</span><span class="keyword">(</span><span class="default">$arg</span><span class="keyword">, </span><span class="default">$config</span><span class="keyword">);<br /><br />function </span><span class="default">ano_func_with_arg</span><span class="keyword">(</span><span class="default">$arg</span><span class="keyword">, </span><span class="default">$config</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; return new class(</span><span class="default">$arg</span><span class="keyword">, </span><span class="default">$config</span><span class="keyword">) {<br />&nbsp; &nbsp; &nbsp; &nbsp; public </span><span class="default">$prop1 </span><span class="keyword">= </span><span class="string">'hello'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; public </span><span class="default">$prop2 </span><span class="keyword">= </span><span class="default">754</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; public </span><span class="default">$prop3</span><span class="keyword">, </span><span class="default">$config</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; const </span><span class="default">SETT </span><span class="keyword">= </span><span class="string">'some config'</span><span class="keyword">;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$arg</span><span class="keyword">, </span><span class="default">$config</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">prop3 </span><span class="keyword">= </span><span class="default">$arg</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">config </span><span class="keyword">=</span><span class="default">$config</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; public function </span><span class="default">getValue</span><span class="keyword">()<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// do some operation<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">return </span><span class="string">'some returned value'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; public function </span><span class="default">getValueWithArgu</span><span class="keyword">(</span><span class="default">$str</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="comment">// do some operation<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">return </span><span class="string">'returned value is '</span><span class="keyword">.</span><span class="default">$str</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; };<br />}<br /><br />echo </span><span class="string">"\n"</span><span class="keyword">;<br /><br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$ano_class_obj_with_arg</span><span class="keyword">);<br />echo </span><span class="string">"\n"</span><span class="keyword">;<br /><br />echo </span><span class="default">$ano_class_obj_with_arg</span><span class="keyword">-&gt;</span><span class="default">prop1</span><span class="keyword">;<br />echo </span><span class="string">"\n"</span><span class="keyword">;<br /><br />echo </span><span class="default">$ano_class_obj_with_arg</span><span class="keyword">-&gt;</span><span class="default">prop2</span><span class="keyword">;<br />echo </span><span class="string">"\n"</span><span class="keyword">;<br /><br />echo </span><span class="default">$ano_class_obj_with_arg</span><span class="keyword">::</span><span class="default">SETT</span><span class="keyword">;<br />echo </span><span class="string">"\n"</span><span class="keyword">;<br /><br />echo </span><span class="default">$ano_class_obj_with_arg</span><span class="keyword">-&gt;</span><span class="default">getValue</span><span class="keyword">();<br />echo </span><span class="string">"\n"</span><span class="keyword">;<br /><br />echo </span><span class="default">$ano_class_obj_with_arg</span><span class="keyword">-&gt;</span><span class="default">getValueWithArgu</span><span class="keyword">(</span><span class="string">'OOP'</span><span class="keyword">);<br />echo </span><span class="string">"\n"</span><span class="keyword">;<br /><br />echo </span><span class="string">"\n"</span><span class="keyword">;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121724">  <div class="votes">
    <div id="Vu121724">
    <a href="/manual/vote-note.php?id=121724&amp;page=language.oop5.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121724">
    <a href="/manual/vote-note.php?id=121724&amp;page=language.oop5.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121724" title="100% like this...">
    1
    </div>
  </div>
  <a href="#121724" class="name">
  <strong class="user"><em>j.m \ jamesweb \ ca</em></strong></a><a class="genanchor" href="#121724"> &para;</a><div class="date" title="2017-10-04 12:21"><strong>2 months ago</strong></div>
  <div class="text" id="Hcom121724">
<div class="phpcode"><code><span class="html">
/* I like the idea of OneShot classes.<br />Thanks to that Anonymous bro\sist for precising&nbsp;&nbsp; <br />new class( $a, $b )<br />¯¯¯¯¯¯¯¯¯<br /><br />If you are looking for "Delayed OneShot Anonymous Classes" for any reason (like the reason: loading files in a readable manner while not using autoload), it would probably look something like this; */<br /><br />$u = function()use(&amp;$u){<br />&nbsp; &nbsp; $u = new class{private $name = 'Utils';};<br />};<br /><br />$w = function(&amp;$rewrite)use(&amp;$w){<br />&nbsp; &nbsp; $w = null;<br />&nbsp; &nbsp; $rewrite = new class{private $name = 'DataUtils';};<br />};<br /><br />// Usage;<br />var_dump(<br />&nbsp; &nbsp; array(<br />&nbsp; &nbsp; &nbsp; &nbsp; 'Delayed',<br />&nbsp; &nbsp; &nbsp; &nbsp; '( Self Destructive )',<br />&nbsp; &nbsp; &nbsp; &nbsp; 'Anonymous Class Creation',<br />&nbsp; &nbsp; &nbsp; &nbsp; array(<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 'Before ( $u )' =&gt; $u,<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 'Running ( $u() )' =&gt; $u(),<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 'After ( $u )' =&gt; $u,<br />&nbsp; &nbsp; &nbsp; &nbsp; ),<br />&nbsp; &nbsp; &nbsp; &nbsp; 0,0,<br />&nbsp; &nbsp; &nbsp; &nbsp; 0,0,<br />&nbsp; &nbsp; &nbsp; &nbsp; 0,0,<br />&nbsp; &nbsp; &nbsp; &nbsp; 'Delayed',<br />&nbsp; &nbsp; &nbsp; &nbsp; '( Overwriting &amp;&amp; Self Destructive )',<br />&nbsp; &nbsp; &nbsp; &nbsp; 'Anonymous Class Creation',<br />&nbsp; &nbsp; &nbsp; &nbsp; array(<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 'Before ( $w )' =&gt; $w,<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 'Running ( $w($u) )' =&gt; $w($u),<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 'After ( $w )' =&gt; $w,<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 'After ( $u )' =&gt; $u<br />&nbsp; &nbsp; &nbsp; &nbsp; )<br />&nbsp; &nbsp; )<br />);<br /><br />// btw : oh shoot I failed a spam challenge</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121021">  <div class="votes">
    <div id="Vu121021">
    <a href="/manual/vote-note.php?id=121021&amp;page=language.oop5.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121021">
    <a href="/manual/vote-note.php?id=121021&amp;page=language.oop5.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121021" title="50% like this...">
    0
    </div>
  </div>
  <a href="#121021" class="name">
  <strong class="user"><em>piotr at maslosoft dot com</em></strong></a><a class="genanchor" href="#121021"> &para;</a><div class="date" title="2017-04-26 05:47"><strong>7 months ago</strong></div>
  <div class="text" id="Hcom121021">
<div class="phpcode"><code><span class="html">
Please note that class name returned by `get_class` might contain null bytes, as is the case in my version of PHP (7.1.4). <br /><br />Name will change when class starting line or it's body is changed.<br /><br />Yes, name is implementation detail that should not be relied upon, but in some rare use cases it is required (annotating anonymous class).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="121839">  <div class="votes">
    <div id="Vu121839">
    <a href="/manual/vote-note.php?id=121839&amp;page=language.oop5.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd121839">
    <a href="/manual/vote-note.php?id=121839&amp;page=language.oop5.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V121839" title="33% like this...">
    -1
    </div>
  </div>
  <a href="#121839" class="name">
  <strong class="user"><em>solobot</em></strong></a><a class="genanchor" href="#121839"> &para;</a><div class="date" title="2017-11-07 01:33"><strong>1 month ago</strong></div>
  <div class="text" id="Hcom121839">
<div class="phpcode"><code><span class="html">
eval() is workaround for generating multiple anonymous classes with static properties in loop<br /><span class="default">&lt;?php<br /></span><span class="keyword">public function </span><span class="default">generateClassMap</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; foreach (</span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">classMap </span><span class="keyword">as </span><span class="default">$tableName </span><span class="keyword">=&gt; </span><span class="default">$class</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$c </span><span class="keyword">= </span><span class="default">null</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; eval(</span><span class="string">'$c = new class extends \common\MyStaticClass {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; public static $tableName;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; public static function tableName()<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return static::$tableName;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; };'</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$c</span><span class="keyword">::</span><span class="default">$tableName </span><span class="keyword">= </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">replicationPrefix</span><span class="keyword">.</span><span class="default">$tableName</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">classMap</span><span class="keyword">[</span><span class="default">$tableName</span><span class="keyword">] = </span><span class="default">$c</span><span class="keyword">;<br /><br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }<br /></span><span class="default">?&gt;<br /></span>thus every class will have its own $tableName instead of common ancestor.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119953">  <div class="votes">
    <div id="Vu119953">
    <a href="/manual/vote-note.php?id=119953&amp;page=language.oop5.anonymous&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119953">
    <a href="/manual/vote-note.php?id=119953&amp;page=language.oop5.anonymous&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119953" title="18% like this...">
    -10
    </div>
  </div>
  <a href="#119953" class="name">
  <strong class="user"><em>primipilus13 at gmail dot com</em></strong></a><a class="genanchor" href="#119953"> &para;</a><div class="date" title="2016-09-26 07:02"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119953">
<div class="phpcode"><code><span class="html">
<span class="default">&lt;?php<br /><br /></span><span class="comment">// using constructor and extends in anonymous class&nbsp; <br /><br /></span><span class="keyword">class </span><span class="default">A<br /></span><span class="keyword">{<br />&nbsp; &nbsp; private </span><span class="default">$name</span><span class="keyword">;&nbsp; &nbsp; <br /><br />&nbsp; &nbsp; public function </span><span class="default">__construct</span><span class="keyword">(</span><span class="default">$name</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">name </span><span class="keyword">= </span><span class="default">$name</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /><br />&nbsp; &nbsp; public function </span><span class="default">getName</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">name</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">$b </span><span class="keyword">= new class(</span><span class="string">'anonymous'</span><span class="keyword">) extends </span><span class="default">A<br /></span><span class="keyword">{<br />&nbsp; &nbsp; public function </span><span class="default">getName</span><span class="keyword">()<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">parent</span><span class="keyword">::</span><span class="default">getName</span><span class="keyword">() . </span><span class="string">' class'</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />};<br /><br />echo </span><span class="default">$b</span><span class="keyword">-&gt;</span><span class="default">getName</span><span class="keyword">(), </span><span class="default">PHP_EOL</span><span class="keyword">;<br /><br /></span><span class="comment">// result: anonimous class</span>
</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.oop5.anonymous&amp;redirect=http://php.net/manual/en/language.oop5.anonymous.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.oop5.php">Classes and Objects</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="oop5.intro.php" title="Introduction">Introduction</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.basic.php" title="The Basics">The Basics</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.properties.php" title="Properties">Properties</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.constants.php" title="Class Constants">Class Constants</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.autoload.php" title="Autoloading Classes">Autoloading Classes</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.decon.php" title="Constructors and Destructors">Constructors and Destructors</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.visibility.php" title="Visibility">Visibility</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.inheritance.php" title="Object Inheritance">Object Inheritance</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.paamayim-nekudotayim.php" title="Scope Resolution Operator (::)">Scope Resolution Operator (::)</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.static.php" title="Static Keyword">Static Keyword</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.abstract.php" title="Class Abstraction">Class Abstraction</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.interfaces.php" title="Object Interfaces">Object Interfaces</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.traits.php" title="Traits">Traits</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.oop5.anonymous.php" title="Anonymous classes">Anonymous classes</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.overloading.php" title="Overloading">Overloading</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.iterations.php" title="Object Iteration">Object Iteration</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.magic.php" title="Magic Methods">Magic Methods</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.final.php" title="Final Keyword">Final Keyword</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.cloning.php" title="Object Cloning">Object Cloning</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.object-comparison.php" title="Comparing Objects">Comparing Objects</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.typehinting.php" title="Type Hinting">Type Hinting</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.late-static-bindings.php" title="Late Static Bindings">Late Static Bindings</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.references.php" title="Objects and references">Objects and references</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.serialization.php" title="Object Serialization">Object Serialization</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.changelog.php" title="OOP Changelog">OOP Changelog</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

