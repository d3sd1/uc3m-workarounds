<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: OOP Changelog - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.oop5.changelog.php">
 <link rel="shorturl" href="http://php.net/oop5.changelog">
 <link rel="alternate" href="http://php.net/oop5.changelog" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.oop5.php">
 <link rel="prev" href="http://php.net/manual/en/language.oop5.serialization.php">
 <link rel="next" href="http://php.net/manual/en/language.namespaces.php">

 <link rel="alternate" href="http://php.net/manual/en/language.oop5.changelog.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.oop5.changelog.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.oop5.changelog.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.oop5.changelog.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.oop5.changelog.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.oop5.changelog.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.oop5.changelog.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.oop5.changelog.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.oop5.changelog.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.oop5.changelog.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.oop5.changelog.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.namespaces.php">
          Namespaces &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.oop5.serialization.php">
          &laquo; Object Serialization        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.oop5.php'>Classes and Objects</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.oop5.changelog.php' selected="selected">English</option>
            <option value='pt_BR/language.oop5.changelog.php'>Brazilian Portuguese</option>
            <option value='zh/language.oop5.changelog.php'>Chinese (Simplified)</option>
            <option value='fr/language.oop5.changelog.php'>French</option>
            <option value='de/language.oop5.changelog.php'>German</option>
            <option value='ja/language.oop5.changelog.php'>Japanese</option>
            <option value='ro/language.oop5.changelog.php'>Romanian</option>
            <option value='ru/language.oop5.changelog.php'>Russian</option>
            <option value='es/language.oop5.changelog.php'>Spanish</option>
            <option value='tr/language.oop5.changelog.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.oop5.changelog.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.oop5.changelog">Report a Bug</a>
    </div>
  </div><div id="language.oop5.changelog" class="sect1">
 <h2 class="title">OOP Changelog</h2>
 <p class="para">
  Changes to the PHP 5 OOP model are logged here. Descriptions and other notes regarding
  these features are documented within the OOP 5 documentation.
 </p>
 <p class="para">
  <table class="doctable informaltable">
   
    <thead>
     <tr>
      <th>Version</th>
      <th>Description</th>
     </tr>

    </thead>

    <tbody class="tbody">
     <tr>
      <td>7.0.0</td>
      <td>
       Defining (compatible) properties in two used traits no longer triggers an error.
      </td>
     </tr>

     <tr>
      <td>5.6.0</td>
      <td>
       Added: The <a href="language.oop5.magic.php#object.debuginfo" class="link">__debugInfo()</a> method.
      </td>
     </tr>

     <tr>
      <td>5.5.0</td>
      <td>
       Added: The <a href="language.oop5.basic.php#language.oop5.basic.class.class" class="link">::class</a> magic constant.
      </td>
     </tr>

     <tr>
      <td>5.5.0</td>
      <td>
       Added: <a href="language.exceptions.php" class="link">finally</a> to handle exceptions.
      </td>
     </tr>

     <tr>
      <td>5.4.0</td>
      <td>
       Added: <a href="language.oop5.traits.php" class="link">traits</a>.
      </td>
     </tr>

     <tr>
      <td>5.4.0</td>
      <td>
       Changed: If an <a href="language.oop5.abstract.php" class="link">abstract</a> class
       defines a signature for the constructor it will now be enforced.
      </td>
     </tr>

     <tr>
      <td>5.3.3</td>
      <td>
       Changed: Methods with the same name as the last element of
       a <a href="language.namespaces.php" class="link">namespaced</a>
       class name will no longer be treated as <a href="language.oop5.decon.php" class="link">constructor</a>. This change doesn&#039;t
       affect non-namespaced classes.
      </td>
     </tr>

     <tr>
      <td>5.3.0</td>
      <td>
       Changed: Classes that implement interfaces with methods that have default 
       values in the prototype are no longer required to match the interface&#039;s default 
       value.
      </td>
     </tr>

     <tr>
      <td>5.3.0</td>
      <td>
       Changed: It&#039;s now possible to reference the class using a variable (e.g.,
       <em>echo $classname::constant;</em>).
       The variable&#039;s value can not be a keyword (e.g., <em>self</em>,
       <em>parent</em> or <em>static</em>).
      </td>
     </tr>

     <tr>
      <td>5.3.0</td>
      <td>
       Changed: An <strong><code>E_WARNING</code></strong> level error is issued if
       the magic <a href="language.oop5.overloading.php" class="link">overloading</a>
       methods are declared <a href="language.oop5.static.php" class="link">static</a>.
       It also enforces the public visibility requirement.
      </td>
     </tr>

     <tr>
      <td>5.3.0</td>
      <td>
       Changed: Prior to 5.3.0, exceptions thrown in the
       <span class="function"><a href="function.autoload.php" class="function">__autoload()</a></span> function could not be
       caught in the <a href="language.exceptions.php" class="link">catch</a> block, and
       would result in a fatal error. Exceptions now thrown in the __autoload function
       can be caught in the <a href="language.exceptions.php" class="link">catch</a> block, with
       one provison. If throwing a custom exception, then the custom exception class must
       be available. The __autoload function may be used recursively to autoload the
       custom exception class.
      </td>
     </tr>

     <tr>
      <td>5.3.0</td>
      <td>
       Added: The <a href="language.oop5.overloading.php" class="link">__callStatic</a> method.
      </td>
     </tr>

     <tr>
      <td>5.3.0</td>
      <td>
       Added: <a href="language.types.string.php#language.types.string.syntax.heredoc" class="link">heredoc</a>
       and <a href="language.types.string.php#language.types.string.syntax.heredoc" class="link">nowdoc</a>
       support for class <em class="emphasis">const</em> and property definitions.
       Note: heredoc values must follow the same rules as double-quoted strings,
       (e.g., no variables within).
      </td>
     </tr>

     <tr>
      <td>5.3.0</td>
      <td>
       Added: <a href="language.oop5.late-static-bindings.php" class="link">Late Static Bindings</a>.
      </td>
     </tr>

     <tr>
      <td>5.3.0</td>
      <td>
       Added: The <a href="language.oop5.magic.php#object.invoke" class="link">__invoke()</a> method.
      </td>
     </tr>

     <tr>
      <td>5.2.0</td>
      <td>
       Changed: The <a href="language.oop5.magic.php#object.tostring" class="link">__toString()</a>
       method was only called when it was directly combined with
       <span class="function"><a href="function.echo.php" class="function">echo</a></span> or <span class="function"><a href="function.print.php" class="function">print</a></span>.
       But now, it is called in any string context (e.g. in
       <span class="function"><a href="function.printf.php" class="function">printf()</a></span> with <em>%s</em> modifier) but not
       in other types contexts (e.g. with <em>%d</em> modifier).
       Since PHP 5.2.0, converting objects without a <em>__toString</em>
       method to string emits a <strong><code>E_RECOVERABLE_ERROR</code></strong> level error.
      </td>
     </tr>

     <tr>
      <td>5.1.3</td>
      <td>
       Changed: In previous versions of PHP 5, the use of <em>var</em>
       was considered deprecated and would issue an <strong><code>E_STRICT</code></strong>
       level error. It&#039;s no longer deprecated, therefore does not emit the error.
      </td>
     </tr>

     <tr>
      <td>5.1.0</td>
      <td>
       Changed: The <a href="language.oop5.magic.php#object.set-state" class="link">__set_state()</a> static
       method is now called for classes exported by <span class="function"><a href="function.var-export.php" class="function">var_export()</a></span>.
      </td>
     </tr>

     <tr>
      <td>5.1.0</td>
      <td>
       Added: The <a href="language.oop5.overloading.php#object.isset" class="link">__isset()</a>
       and <a href="language.oop5.overloading.php#object.unset" class="link">__unset()</a> methods.
      </td>
     </tr>

    </tbody>
   
  </table>

 </p>
</div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.oop5.changelog&amp;redirect=http://php.net/manual/en/language.oop5.changelog.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes </h3>
 </div>
 <div class="note">There are no user contributed notes for this page.</div></section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.oop5.php">Classes and Objects</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="oop5.intro.php" title="Introduction">Introduction</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.basic.php" title="The Basics">The Basics</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.properties.php" title="Properties">Properties</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.constants.php" title="Class Constants">Class Constants</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.autoload.php" title="Autoloading Classes">Autoloading Classes</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.decon.php" title="Constructors and Destructors">Constructors and Destructors</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.visibility.php" title="Visibility">Visibility</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.inheritance.php" title="Object Inheritance">Object Inheritance</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.paamayim-nekudotayim.php" title="Scope Resolution Operator (::)">Scope Resolution Operator (::)</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.static.php" title="Static Keyword">Static Keyword</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.abstract.php" title="Class Abstraction">Class Abstraction</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.interfaces.php" title="Object Interfaces">Object Interfaces</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.traits.php" title="Traits">Traits</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.anonymous.php" title="Anonymous classes">Anonymous classes</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.overloading.php" title="Overloading">Overloading</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.iterations.php" title="Object Iteration">Object Iteration</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.magic.php" title="Magic Methods">Magic Methods</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.final.php" title="Final Keyword">Final Keyword</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.cloning.php" title="Object Cloning">Object Cloning</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.object-comparison.php" title="Comparing Objects">Comparing Objects</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.typehinting.php" title="Type Hinting">Type Hinting</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.late-static-bindings.php" title="Late Static Bindings">Late Static Bindings</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.references.php" title="Objects and references">Objects and references</a>
                        </li>
                          
                        <li class="">
                            <a href="language.oop5.serialization.php" title="Object Serialization">Object Serialization</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.oop5.changelog.php" title="OOP Changelog">OOP Changelog</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

