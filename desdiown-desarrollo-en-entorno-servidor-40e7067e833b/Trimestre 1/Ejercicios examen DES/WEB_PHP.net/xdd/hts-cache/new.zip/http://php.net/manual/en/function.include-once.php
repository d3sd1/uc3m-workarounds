<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: include_once - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/function.include-once.php">
 <link rel="shorturl" href="http://php.net/include-once">
 <link rel="alternate" href="http://php.net/include-once" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.control-structures.php">
 <link rel="prev" href="http://php.net/manual/en/function.require-once.php">
 <link rel="next" href="http://php.net/manual/en/control-structures.goto.php">

 <link rel="alternate" href="http://php.net/manual/en/function.include-once.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/function.include-once.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/function.include-once.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/function.include-once.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/function.include-once.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/function.include-once.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/function.include-once.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/function.include-once.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/function.include-once.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/function.include-once.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/function.include-once.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="control-structures.goto.php">
          goto &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="function.require-once.php">
          &laquo; require_once        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.control-structures.php'>Control Structures</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/function.include-once.php' selected="selected">English</option>
            <option value='pt_BR/function.include-once.php'>Brazilian Portuguese</option>
            <option value='zh/function.include-once.php'>Chinese (Simplified)</option>
            <option value='fr/function.include-once.php'>French</option>
            <option value='de/function.include-once.php'>German</option>
            <option value='ja/function.include-once.php'>Japanese</option>
            <option value='ro/function.include-once.php'>Romanian</option>
            <option value='ru/function.include-once.php'>Russian</option>
            <option value='es/function.include-once.php'>Spanish</option>
            <option value='tr/function.include-once.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/function.include-once.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=function.include-once">Report a Bug</a>
    </div>
  </div><div id="function.include-once" class="sect1">
 <h2 class="title">include_once</h2>
 <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p>
 <p class="para">
  The <em>include_once</em> statement includes and evaluates
  the specified file during the execution of the script.
  This is a behavior similar to the <span class="function"><a href="function.include.php" class="function">include</a></span> statement,
  with the only difference being that if the code from a file has already
  been included, it will not be included again, and include_once returns <strong><code>TRUE</code></strong>.  As the name suggests,
  the file will be included just once.
 </p>
 <p class="para">
  <em>include_once</em> may be used in cases where
  the same file might be included and evaluated more than once during a
  particular execution of a script, so in this case it may help avoid
  problems such as function redefinitions, variable value reassignments, etc.
 </p>
 <p class="para">
  See the <span class="function"><a href="function.include.php" class="function">include</a></span> documentation for information about
  how this function works.
 </p>
 <p class="para">
  <blockquote class="note"><p><strong class="note">Note</strong>: 
  <p class="para">
   With PHP 4, <em>_once</em> functionality differs with case-insensitive
   operating systems (like Windows) so for example:
   <div class="example" id="example-128">
    <p><strong>Example #1 <em>include_once</em> with a case insensitive OS in PHP 4</strong></p>
    <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">include_once&nbsp;</span><span style="color: #DD0000">"a.php"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;this&nbsp;will&nbsp;include&nbsp;a.php<br /></span><span style="color: #007700">include_once&nbsp;</span><span style="color: #DD0000">"A.php"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;this&nbsp;will&nbsp;include&nbsp;a.php&nbsp;again!&nbsp;(PHP&nbsp;4&nbsp;only)<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>
   <p class="para">
    This behaviour changed in PHP 5, so for example with Windows the path is normalized first so that
    <var class="filename">C:\PROGRA~1\A.php</var> is realized the same as
    <var class="filename">C:\Program Files\a.php</var> and the file is included just once.
   </p>
  </p></blockquote>
 </p>
</div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=function.include-once&amp;redirect=http://php.net/manual/en/function.include-once.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">8 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="120520">  <div class="votes">
    <div id="Vu120520">
    <a href="/manual/vote-note.php?id=120520&amp;page=function.include-once&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120520">
    <a href="/manual/vote-note.php?id=120520&amp;page=function.include-once&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120520" title="90% like this...">
    84
    </div>
  </div>
  <a href="#120520" class="name">
  <strong class="user"><em>Greg McCarthy</em></strong></a><a class="genanchor" href="#120520"> &para;</a><div class="date" title="2017-01-24 08:16"><strong>10 months ago</strong></div>
  <div class="text" id="Hcom120520">
<div class="phpcode"><code><span class="html">
In response to what a user wrote 8 years ago regarding include_once being ran two times in a row on a non-existent file:<br /><br />Perhaps 8 years ago that was the case, however I have tested in PHP 5.6, and I get this:<br /><br />$result = include_once 'fakefile.php';&nbsp; // $result = false<br />$result = include_once 'fakefile.php'&nbsp;&nbsp; // $result is still false</span>
</code></div>
  </div>
 </div>
  <div class="note" id="84108">  <div class="votes">
    <div id="Vu84108">
    <a href="/manual/vote-note.php?id=84108&amp;page=function.include-once&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd84108">
    <a href="/manual/vote-note.php?id=84108&amp;page=function.include-once&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V84108" title="69% like this...">
    182
    </div>
  </div>
  <a href="#84108" class="name">
  <strong class="user"><em>roach dot scott+spam at googlemail dot com</em></strong></a><a class="genanchor" href="#84108"> &para;</a><div class="date" title="2008-06-27 05:22"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom84108">
<div class="phpcode"><code><span class="html">
If you include a file that does not exist with include_once, the return result will be false. <br /><br />If you try to include that same file again with include_once the return value will be true.<br /><br />Example:<br /><span class="default">&lt;?php<br />var_dump</span><span class="keyword">(include_once </span><span class="string">'fakefile.ext'</span><span class="keyword">); </span><span class="comment">// bool(false)<br /></span><span class="default">var_dump</span><span class="keyword">(include_once </span><span class="string">'fakefile.ext'</span><span class="keyword">); </span><span class="comment">// bool(true)<br /></span><span class="default">?&gt;<br /></span><br />This is because according to php the file was already included once (even though it does not exist).</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116897">  <div class="votes">
    <div id="Vu116897">
    <a href="/manual/vote-note.php?id=116897&amp;page=function.include-once&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116897">
    <a href="/manual/vote-note.php?id=116897&amp;page=function.include-once&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116897" title="44% like this...">
    -13
    </div>
  </div>
  <a href="#116897" class="name">
  <strong class="user"><em>xcl_rockman at qq dot com</em></strong></a><a class="genanchor" href="#116897"> &para;</a><div class="date" title="2015-03-17 07:56"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom116897">
<div class="phpcode"><code><span class="html">
config.php<br /><span class="default">&lt;?php<br /></span><span class="keyword">return array(</span><span class="string">"test"</span><span class="keyword">&gt;</span><span class="default">1</span><span class="keyword">);<br /><br />-------------<br /></span><span class="comment">//first<br /></span><span class="default">$config </span><span class="keyword">= include_once(</span><span class="string">"config.php"</span><span class="keyword">);<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$config</span><span class="keyword">);<br /><br /></span><span class="default">$config </span><span class="keyword">= include_once(</span><span class="string">"config.php"</span><span class="keyword">);<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">$config</span><span class="keyword">);<br /><br />-------------------<br /></span><span class="default">output will be<br /></span><span class="keyword">array(<br />&nbsp; &nbsp; </span><span class="string">"test"</span><span class="keyword">=&gt;</span><span class="default">1</span><span class="keyword">,<br />)<br /><br /></span><span class="default">nothing</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="68776">  <div class="votes">
    <div id="Vu68776">
    <a href="/manual/vote-note.php?id=68776&amp;page=function.include-once&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd68776">
    <a href="/manual/vote-note.php?id=68776&amp;page=function.include-once&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V68776" title="36% like this...">
    -42
    </div>
  </div>
  <a href="#68776" class="name">
  <strong class="user"><em>webmaster AT domaene - kempten DOT de</em></strong></a><a class="genanchor" href="#68776"> &para;</a><div class="date" title="2006-08-10 05:11"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom68776">
<div class="phpcode"><code><span class="html">
Since I like to reuse a lot of code it came handy to me to begin some sort of library that I stored in a subdir<br />e.g. "lib"<br /><br />The only thing that bothered me for some time was that although everything worked all IDEs reported during editing<br />these useless warnings "file not found" when library files included other library files, since my path were given all relative to the corresponding document-root.<br /><br />Here is a short workaround that makes that gone:<br /><br /><span class="default">&lt;?php<br /></span><span class="comment">// Change to your path<br /><br /></span><span class="keyword">if(</span><span class="default">strpos</span><span class="keyword">(</span><span class="default">__FILE__</span><span class="keyword">,</span><span class="string">'/lib/'</span><span class="keyword">) != </span><span class="default">FALSE</span><span class="keyword">){<br />&nbsp; &nbsp; </span><span class="default">chdir</span><span class="keyword">(</span><span class="string">".."</span><span class="keyword">);<br />}<br />include_once (</span><span class="string">'./lib/other_lib.inc'</span><span class="keyword">);<br /></span><span class="comment">// ... or any other include[_once] / require[_once]<br /></span><span class="default">?&gt;<br /></span><br />just adjust the path and it will be fine - also for your IDE.<br /><br />greetings</span>
</code></div>
  </div>
 </div>
  <div class="note" id="120846">  <div class="votes">
    <div id="Vu120846">
    <a href="/manual/vote-note.php?id=120846&amp;page=function.include-once&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd120846">
    <a href="/manual/vote-note.php?id=120846&amp;page=function.include-once&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V120846" title="25% like this...">
    -8
    </div>
  </div>
  <a href="#120846" class="name">
  <strong class="user"><em>sascha dot diebel at gmail dot com</em></strong></a><a class="genanchor" href="#120846"> &para;</a><div class="date" title="2017-03-21 01:39"><strong>8 months ago</strong></div>
  <div class="text" id="Hcom120846">
<div class="phpcode"><code><span class="html">
i tried<br /><br />-------------------------------- index.php: <br />$out='todo 1';<br />include 'file1.php';<br />$out='todo 2';<br />include 'file1.php';<br />echo 'end';<br />-------------------------------- file1.php:<br />include_once 'file2.php';<br />if(isset($out)){<br /> echo $out;<br />}<br />-------------------------------- file2.php:<br />$out='first todo once';<br />include 'file.php';<br /><br />the output is:<br />first todo once<br />first todo once<br />todo 2<br /><br />what should i do?<br /><br />if i would replace in file2.php include with include_once, then i have following output:<br />first todo once<br />todo 2<br /><br />i could write<br />$out='first todo once';<br />include 'file1.php'<br />$out='todo 1';<br />include 'file1.php';<br />$out='todo 2';<br />include 'file1.php';<br /><br />but i don't want :-)<br />please help</span>
</code></div>
  </div>
 </div>
  <div class="note" id="53239">  <div class="votes">
    <div id="Vu53239">
    <a href="/manual/vote-note.php?id=53239&amp;page=function.include-once&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd53239">
    <a href="/manual/vote-note.php?id=53239&amp;page=function.include-once&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V53239" title="34% like this...">
    -47
    </div>
  </div>
  <a href="#53239" class="name">
  <strong class="user"><em>flobee at gmail dot com</em></strong></a><a class="genanchor" href="#53239"> &para;</a><div class="date" title="2005-05-26 07:55"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom53239">
<div class="phpcode"><code><span class="html">
i already had a discussion with several people about "not shown errors"<br />error reporting and all others in php.ini set to: "show errors" to find problems: <br />the answer i finally found:<br />if you have an "@include..." instead of "include..." or "require..('somthing') in any place in your code <br />all following errors are not shown too!!!<br /><br />so, this is actually a bad idea when developing because paser errors will be droped too:<br /><span class="default">&lt;?php<br /></span><span class="keyword">if(!@include_once(</span><span class="string">'./somthing'</span><span class="keyword">) ) {<br />&nbsp; &nbsp; echo </span><span class="string">'can not include'</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />solution:<br /><span class="default">&lt;?php<br /></span><span class="keyword">if(!@</span><span class="default">file_exists</span><span class="keyword">(</span><span class="string">'./somthing'</span><span class="keyword">) ) {<br />&nbsp; &nbsp; echo </span><span class="string">'can not include'</span><span class="keyword">;<br />} else {<br />&nbsp;&nbsp; include(</span><span class="string">'./something'</span><span class="keyword">);<br />}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="83280">  <div class="votes">
    <div id="Vu83280">
    <a href="/manual/vote-note.php?id=83280&amp;page=function.include-once&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd83280">
    <a href="/manual/vote-note.php?id=83280&amp;page=function.include-once&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V83280" title="32% like this...">
    -61
    </div>
  </div>
  <a href="#83280" class="name">
  <strong class="user"><em>emanuele at rogledi dot com</em></strong></a><a class="genanchor" href="#83280"> &para;</a><div class="date" title="2008-05-18 05:40"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom83280">
<div class="phpcode"><code><span class="html">
For include_once a file in every paths of application we can do simply this<br /><br />include_once($_SERVER["DOCUMENT_ROOT"] . "mypath/my2ndpath/myfile.php");</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117818">  <div class="votes">
    <div id="Vu117818">
    <a href="/manual/vote-note.php?id=117818&amp;page=function.include-once&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117818">
    <a href="/manual/vote-note.php?id=117818&amp;page=function.include-once&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117818" title="24% like this...">
    -33
    </div>
  </div>
  <a href="#117818" class="name">
  <strong class="user"><em>1083706899 at qq dot com</em></strong></a><a class="genanchor" href="#117818"> &para;</a><div class="date" title="2015-08-14 03:57"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117818">
<div class="phpcode"><code><span class="html">
require_once() can check the file if once include ,or the file is wrong will tell a error and quit the script.</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=function.include-once&amp;redirect=http://php.net/manual/en/function.include-once.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.control-structures.php">Control Structures</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="control-structures.intro.php" title="Introduction">Introduction</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.if.php" title="if">if</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.else.php" title="else">else</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.elseif.php" title="elseif/else if">elseif/else if</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.alternative-syntax.php" title="Alternative syntax for control structures">Alternative syntax for control structures</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.while.php" title="while">while</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.do.while.php" title="do-&#8203;while">do-&#8203;while</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.for.php" title="for">for</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.foreach.php" title="foreach">foreach</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.break.php" title="break">break</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.continue.php" title="continue">continue</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.switch.php" title="switch">switch</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.declare.php" title="declare">declare</a>
                        </li>
                          
                        <li class="">
                            <a href="function.return.php" title="return">return</a>
                        </li>
                          
                        <li class="">
                            <a href="function.require.php" title="require">require</a>
                        </li>
                          
                        <li class="">
                            <a href="function.include.php" title="include">include</a>
                        </li>
                          
                        <li class="">
                            <a href="function.require-once.php" title="require_&#8203;once">require_&#8203;once</a>
                        </li>
                          
                        <li class="current">
                            <a href="function.include-once.php" title="include_&#8203;once">include_&#8203;once</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.goto.php" title="goto">goto</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

