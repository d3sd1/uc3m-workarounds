<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: FAQ: things you need to know about namespaces - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/language.namespaces.faq.php">
 <link rel="shorturl" href="http://php.net/namespaces.faq">
 <link rel="alternate" href="http://php.net/namespaces.faq" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.namespaces.php">
 <link rel="prev" href="http://php.net/manual/en/language.namespaces.rules.php">
 <link rel="next" href="http://php.net/manual/en/language.errors.php">

 <link rel="alternate" href="http://php.net/manual/en/language.namespaces.faq.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/language.namespaces.faq.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/language.namespaces.faq.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/language.namespaces.faq.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/language.namespaces.faq.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/language.namespaces.faq.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/language.namespaces.faq.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/language.namespaces.faq.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/language.namespaces.faq.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/language.namespaces.faq.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/language.namespaces.faq.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="language.errors.php">
          Errors &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="language.namespaces.rules.php">
          &laquo; Name resolution rules        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.namespaces.php'>Namespaces</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/language.namespaces.faq.php' selected="selected">English</option>
            <option value='pt_BR/language.namespaces.faq.php'>Brazilian Portuguese</option>
            <option value='zh/language.namespaces.faq.php'>Chinese (Simplified)</option>
            <option value='fr/language.namespaces.faq.php'>French</option>
            <option value='de/language.namespaces.faq.php'>German</option>
            <option value='ja/language.namespaces.faq.php'>Japanese</option>
            <option value='ro/language.namespaces.faq.php'>Romanian</option>
            <option value='ru/language.namespaces.faq.php'>Russian</option>
            <option value='es/language.namespaces.faq.php'>Spanish</option>
            <option value='tr/language.namespaces.faq.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/language.namespaces.faq.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=language.namespaces.faq">Report a Bug</a>
    </div>
  </div><div id="language.namespaces.faq" class="sect1">
  <h2 class="title">FAQ: things you need to know about namespaces</h2>
  <p class="verinfo">(PHP 5 &gt;= 5.3.0, PHP 7)</p>
  <p class="para">
   This FAQ is split into two sections: common questions, and some specifics of
   implementation that are helpful to understand fully.
  </p>
  <p class="para">
   First, the common questions.
   <ol type="1">
    <li class="listitem">
     <span class="simpara">
      <a href="language.namespaces.faq.php#language.namespaces.faq.shouldicare" class="link">If I don&#039;t use namespaces, should
      I care about any of this?</a>
     </span>
    </li>
    <li class="listitem">
     <span class="simpara">
      <a href="language.namespaces.faq.php#language.namespaces.faq.globalclass" class="link">How do I use internal or global
      classes in a namespace?</a>
     </span>
    </li>
    <li class="listitem">
     <span class="simpara">
      <a href="language.namespaces.faq.php#language.namespaces.faq.innamespace" class="link">How do I use namespaces classes
      functions, or constants in their own namespace?</a>
     </span>
    </li>
    <li class="listitem">
     <span class="simpara">
      <a href="language.namespaces.faq.php#language.namespaces.faq.full" class="link">
       How does a name like <em>\my\name</em> or <em>\name</em>
       resolve?
      </a>
     </span>
    </li>
    <li class="listitem">
     <span class="simpara">
      <a href="language.namespaces.faq.php#language.namespaces.faq.qualified" class="link">How does a name like
      <em>my\name</em> resolve?</a>
     </span>
    </li>
    <li class="listitem">
     <span class="simpara">
      <a href="language.namespaces.faq.php#language.namespaces.faq.shortname1" class="link">How does an unqualified class name
      like <em>name</em> resolve?</a>
     </span>
    </li>
    <li class="listitem">
     <span class="simpara">
      <a href="language.namespaces.faq.php#language.namespaces.faq.shortname2" class="link">How does an unqualified function
      name or unqualified constant name
      like <em>name</em> resolve?</a>
     </span>
    </li>
   </ol>
  </p>
  <p class="para">
   There are a few implementation details of the namespace implementations
   that are helpful to understand.
   <ol type="1">
    <li class="listitem">
     <span class="simpara">
      <a href="language.namespaces.faq.php#language.namespaces.faq.conflict" class="link">Import names cannot conflict with
      classes defined in the same file.</a>
     </span>
    </li>
    <li class="listitem">
     <span class="simpara">
      <a href="language.namespaces.faq.php#language.namespaces.faq.nested" class="link">Nested namespaces are not allowed.
      </a>
     </span>
    </li>
    <li class="listitem">
     <span class="simpara">
      <a href="language.namespaces.faq.php#language.namespaces.faq.nofuncconstantuse" class="link">Before PHP 5.6 neither functions nor
      constants can be imported via the <em>use</em>
      statement.</a>
     </span>
    </li>
    <li class="listitem">
     <span class="simpara">
      <a href="language.namespaces.faq.php#language.namespaces.faq.quote" class="link">Dynamic namespace names (quoted
      identifiers) should escape backslash.</a>
     </span>
    </li>
    <li class="listitem">
     <span class="simpara">
      <a href="language.namespaces.faq.php#language.namespaces.faq.constants" class="link">Undefined Constants referenced
      using any backslash die with fatal error</a>
     </span>
    </li>
    <li class="listitem">
     <span class="simpara">
      <a href="language.namespaces.faq.php#language.namespaces.faq.builtinconst" class="link">Cannot override special
      constants NULL, TRUE, FALSE, ZEND_THREAD_SAFE or ZEND_DEBUG_BUILD</a>
     </span>
    </li>
   </ol>
  </p>
  <div class="sect2" id="language.namespaces.faq.shouldicare">
   <h3 class="title">If I don&#039;t use namespaces, should I care about any of this?</h3>
   <p class="para">
    No.  Namespaces do not affect any existing code in any way, or any
    as-yet-to-be-written code that does not contain namespaces.  You can
    write this code if you wish:
   </p>
   <p class="para">
    <div class="example" id="example-267">
     <p><strong>Example #1 Accessing global classes outside a namespace</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$a&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;\</span><span style="color: #0000BB">stdClass</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>
   <p class="para">
    This is functionally equivalent to:
   </p>
   <p class="para">
    <div class="example" id="example-268">
     <p><strong>Example #2 Accessing global classes outside a namespace</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$a&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">stdClass</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>
  </div>
  <div class="sect2" id="language.namespaces.faq.globalclass">
   <h3 class="title">How do I use internal or global classes in a namespace?</h3>
   <p class="para">
    <div class="example" id="example-269">
     <p><strong>Example #3 Accessing internal classes in namespaces</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">namespace&nbsp;</span><span style="color: #0000BB">foo</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;\</span><span style="color: #0000BB">stdClass</span><span style="color: #007700">;<br /><br />function&nbsp;</span><span style="color: #0000BB">test</span><span style="color: #007700">(\</span><span style="color: #0000BB">ArrayObject&nbsp;$typehintexample&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">null</span><span style="color: #007700">)&nbsp;{}<br /><br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;\</span><span style="color: #0000BB">DirectoryIterator</span><span style="color: #007700">::</span><span style="color: #0000BB">CURRENT_AS_FILEINFO</span><span style="color: #007700">;<br /><br /></span><span style="color: #FF8000">//&nbsp;extending&nbsp;an&nbsp;internal&nbsp;or&nbsp;global&nbsp;class<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">MyException&nbsp;</span><span style="color: #007700">extends&nbsp;\</span><span style="color: #0000BB">Exception&nbsp;</span><span style="color: #007700">{}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>
  </div>
  <div class="sect2" id="language.namespaces.faq.innamespace">
   <h3 class="title">
    How do I use namespaces classes, functions, or constants in their own
    namespace?
   </h3>
   <p class="para">
    <div class="example" id="example-270">
     <p><strong>Example #4 Accessing internal classes, functions or constants in namespaces</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">namespace&nbsp;</span><span style="color: #0000BB">foo</span><span style="color: #007700">;<br /><br />class&nbsp;</span><span style="color: #0000BB">MyClass&nbsp;</span><span style="color: #007700">{}<br /><br /></span><span style="color: #FF8000">//&nbsp;using&nbsp;a&nbsp;class&nbsp;from&nbsp;the&nbsp;current&nbsp;namespace&nbsp;as&nbsp;a&nbsp;type&nbsp;hint<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">test</span><span style="color: #007700">(</span><span style="color: #0000BB">MyClass&nbsp;$typehintexample&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">null</span><span style="color: #007700">)&nbsp;{}<br /></span><span style="color: #FF8000">//&nbsp;another&nbsp;way&nbsp;to&nbsp;use&nbsp;a&nbsp;class&nbsp;from&nbsp;the&nbsp;current&nbsp;namespace&nbsp;as&nbsp;a&nbsp;type&nbsp;hint<br /></span><span style="color: #007700">function&nbsp;</span><span style="color: #0000BB">test</span><span style="color: #007700">(\</span><span style="color: #0000BB">foo</span><span style="color: #007700">\</span><span style="color: #0000BB">MyClass&nbsp;$typehintexample&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">null</span><span style="color: #007700">)&nbsp;{}<br /><br /></span><span style="color: #FF8000">//&nbsp;extending&nbsp;a&nbsp;class&nbsp;from&nbsp;the&nbsp;current&nbsp;namespace<br /></span><span style="color: #007700">class&nbsp;</span><span style="color: #0000BB">Extended&nbsp;</span><span style="color: #007700">extends&nbsp;</span><span style="color: #0000BB">MyClass&nbsp;</span><span style="color: #007700">{}<br /><br /></span><span style="color: #FF8000">//&nbsp;accessing&nbsp;a&nbsp;global&nbsp;function<br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;\</span><span style="color: #0000BB">globalfunc</span><span style="color: #007700">();<br /><br /></span><span style="color: #FF8000">//&nbsp;accessing&nbsp;a&nbsp;global&nbsp;constant<br /></span><span style="color: #0000BB">$b&nbsp;</span><span style="color: #007700">=&nbsp;\</span><span style="color: #0000BB">INI_ALL</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>
  </div>
  <div class="sect2" id="language.namespaces.faq.full">
   <h3 class="title">
     How does a name like <em>\my\name</em> or <em>\name</em>
     resolve?
   </h3>
   <p class="para">
    Names that begin with a <em>\</em> always resolve to what they
    look like, so <em>\my\name</em> is in fact <em>my\name</em>,
    and <em>\Exception</em> is <em>Exception</em>.
    <div class="example" id="example-271">
     <p><strong>Example #5 Fully Qualified names</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">namespace&nbsp;</span><span style="color: #0000BB">foo</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;\</span><span style="color: #0000BB">my</span><span style="color: #007700">\</span><span style="color: #0000BB">name</span><span style="color: #007700">();&nbsp;</span><span style="color: #FF8000">//&nbsp;instantiates&nbsp;"my\name"&nbsp;class<br /></span><span style="color: #007700">echo&nbsp;\</span><span style="color: #0000BB">strlen</span><span style="color: #007700">(</span><span style="color: #DD0000">'hi'</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;calls&nbsp;function&nbsp;"strlen"<br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;\</span><span style="color: #0000BB">INI_ALL</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;$a&nbsp;is&nbsp;set&nbsp;to&nbsp;the&nbsp;value&nbsp;of&nbsp;constant&nbsp;"INI_ALL"<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>
  </div>
  <div class="sect2" id="language.namespaces.faq.qualified">
   <h3 class="title">How does a name like <em>my\name</em> resolve?</h3>
   <p class="para">
    Names that contain a backslash but do not begin with a backslash like
    <em>my\name</em> can be resolved in 2 different ways.
   </p>
   <p class="para">
    If there is
    an import statement that aliases another name to <em>my</em>, then
    the import alias is applied to the <em>my</em> in <em>my\name</em>.
   </p>
   <p class="para">
    Otherwise, the current namespace name is prepended to <em>my\name</em>.
   </p>
   <p class="para">
    <div class="example" id="example-272">
     <p><strong>Example #6 Qualified names</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">namespace&nbsp;</span><span style="color: #0000BB">foo</span><span style="color: #007700">;<br />use&nbsp;</span><span style="color: #0000BB">blah</span><span style="color: #007700">\</span><span style="color: #0000BB">blah&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">foo</span><span style="color: #007700">;<br /><br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">my</span><span style="color: #007700">\</span><span style="color: #0000BB">name</span><span style="color: #007700">();&nbsp;</span><span style="color: #FF8000">//&nbsp;instantiates&nbsp;"foo\my\name"&nbsp;class<br /></span><span style="color: #0000BB">foo</span><span style="color: #007700">\</span><span style="color: #0000BB">bar</span><span style="color: #007700">::</span><span style="color: #0000BB">name</span><span style="color: #007700">();&nbsp;</span><span style="color: #FF8000">//&nbsp;calls&nbsp;static&nbsp;method&nbsp;"name"&nbsp;in&nbsp;class&nbsp;"blah\blah\bar"<br /></span><span style="color: #0000BB">my</span><span style="color: #007700">\</span><span style="color: #0000BB">bar</span><span style="color: #007700">();&nbsp;</span><span style="color: #FF8000">//&nbsp;calls&nbsp;function&nbsp;"foo\my\bar"<br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">my</span><span style="color: #007700">\</span><span style="color: #0000BB">BAR</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;sets&nbsp;$a&nbsp;to&nbsp;the&nbsp;value&nbsp;of&nbsp;constant&nbsp;"foo\my\BAR"<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>
  </div>
  <div class="sect2" id="language.namespaces.faq.shortname1">
   <h3 class="title">How does an unqualified class name like <em>name</em> resolve?</h3>
   <p class="para">
    Class names that do not contain a backslash like
    <em>name</em> can be resolved in 2 different ways.
   </p>
   <p class="para">
    If there is
    an import statement that aliases another name to <em>name</em>, then
    the import alias is applied.
   </p>
   <p class="para">
    Otherwise, the current namespace name is prepended to <em>name</em>.
   </p>
   <p class="para">
    <div class="example" id="example-273">
     <p><strong>Example #7 Unqualified class names</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">namespace&nbsp;</span><span style="color: #0000BB">foo</span><span style="color: #007700">;<br />use&nbsp;</span><span style="color: #0000BB">blah</span><span style="color: #007700">\</span><span style="color: #0000BB">blah&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">foo</span><span style="color: #007700">;<br /><br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">name</span><span style="color: #007700">();&nbsp;</span><span style="color: #FF8000">//&nbsp;instantiates&nbsp;"foo\name"&nbsp;class<br /></span><span style="color: #0000BB">foo</span><span style="color: #007700">::</span><span style="color: #0000BB">name</span><span style="color: #007700">();&nbsp;</span><span style="color: #FF8000">//&nbsp;calls&nbsp;static&nbsp;method&nbsp;"name"&nbsp;in&nbsp;class&nbsp;"blah\blah"<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>
  </div>
  <div class="sect2" id="language.namespaces.faq.shortname2">
   <h3 class="title">
    How does an unqualified function name or unqualified constant name
    like <em>name</em> resolve?
   </h3>
   <p class="para">
    Function or constant names that do not contain a backslash like
    <em>name</em> can be resolved in 2 different ways.
   </p>
   <p class="para">
    First, the current namespace name is prepended to <em>name</em>.
   </p>
   <p class="para">
    Finally, if the constant or function <em>name</em> does not exist
    in the current namespace, a global constant or function <em>name</em>
    is used if it exists.
   </p>
   <p class="para">
    <div class="example" id="example-274">
     <p><strong>Example #8 Unqualified function or constant names</strong></p>
     <div class="example-contents">
<div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">namespace&nbsp;</span><span style="color: #0000BB">foo</span><span style="color: #007700">;<br />use&nbsp;</span><span style="color: #0000BB">blah</span><span style="color: #007700">\</span><span style="color: #0000BB">blah&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">foo</span><span style="color: #007700">;<br /><br />const&nbsp;</span><span style="color: #0000BB">FOO&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">1</span><span style="color: #007700">;<br /><br />function&nbsp;</span><span style="color: #0000BB">my</span><span style="color: #007700">()&nbsp;{}<br />function&nbsp;</span><span style="color: #0000BB">foo</span><span style="color: #007700">()&nbsp;{}<br />function&nbsp;</span><span style="color: #0000BB">sort</span><span style="color: #007700">(&amp;</span><span style="color: #0000BB">$a</span><span style="color: #007700">)<br />{<br />&nbsp;&nbsp;&nbsp;&nbsp;\</span><span style="color: #0000BB">sort</span><span style="color: #007700">(</span><span style="color: #0000BB">$a</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;calls&nbsp;the&nbsp;global&nbsp;function&nbsp;"sort"<br />&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">array_flip</span><span style="color: #007700">(</span><span style="color: #0000BB">$a</span><span style="color: #007700">);<br />&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;</span><span style="color: #0000BB">$a</span><span style="color: #007700">;<br />}<br /><br /></span><span style="color: #0000BB">my</span><span style="color: #007700">();&nbsp;</span><span style="color: #FF8000">//&nbsp;calls&nbsp;"foo\my"<br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">strlen</span><span style="color: #007700">(</span><span style="color: #DD0000">'hi'</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;calls&nbsp;global&nbsp;function&nbsp;"strlen"&nbsp;because&nbsp;"foo\strlen"&nbsp;does&nbsp;not&nbsp;exist<br /></span><span style="color: #0000BB">$arr&nbsp;</span><span style="color: #007700">=&nbsp;array(</span><span style="color: #0000BB">1</span><span style="color: #007700">,</span><span style="color: #0000BB">3</span><span style="color: #007700">,</span><span style="color: #0000BB">2</span><span style="color: #007700">);<br /></span><span style="color: #0000BB">$b&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">sort</span><span style="color: #007700">(</span><span style="color: #0000BB">$arr</span><span style="color: #007700">);&nbsp;</span><span style="color: #FF8000">//&nbsp;calls&nbsp;function&nbsp;"foo\sort"<br /></span><span style="color: #0000BB">$c&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">foo</span><span style="color: #007700">();&nbsp;</span><span style="color: #FF8000">//&nbsp;calls&nbsp;function&nbsp;"foo\foo"&nbsp;-&nbsp;import&nbsp;is&nbsp;not&nbsp;applied<br /><br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">FOO</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;sets&nbsp;$a&nbsp;to&nbsp;value&nbsp;of&nbsp;constant&nbsp;"foo\FOO"&nbsp;-&nbsp;import&nbsp;is&nbsp;not&nbsp;applied<br /></span><span style="color: #0000BB">$b&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">INI_ALL</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;sets&nbsp;$b&nbsp;to&nbsp;value&nbsp;of&nbsp;global&nbsp;constant&nbsp;"INI_ALL"<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>
  </div>
  <div class="sect2" id="language.namespaces.faq.conflict">
   <h3 class="title">Import names cannot conflict with classes defined in the same file.</h3>
   <p class="para">
    The following script combinations are legal:
    <div class="informalexample">
     <p class="simpara">file1.php</p>
     <div class="example-contents">
     <div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">namespace&nbsp;</span><span style="color: #0000BB">my</span><span style="color: #007700">\</span><span style="color: #0000BB">stuff</span><span style="color: #007700">;<br />class&nbsp;</span><span style="color: #0000BB">MyClass&nbsp;</span><span style="color: #007700">{}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

     <p class="simpara">another.php</p>
     <div class="example-contents">
     <div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">namespace&nbsp;</span><span style="color: #0000BB">another</span><span style="color: #007700">;<br />class&nbsp;</span><span style="color: #0000BB">thing&nbsp;</span><span style="color: #007700">{}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

     <p class="simpara">file2.php</p>
     <div class="example-contents">
     <div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">namespace&nbsp;</span><span style="color: #0000BB">my</span><span style="color: #007700">\</span><span style="color: #0000BB">stuff</span><span style="color: #007700">;<br />include&nbsp;</span><span style="color: #DD0000">'file1.php'</span><span style="color: #007700">;<br />include&nbsp;</span><span style="color: #DD0000">'another.php'</span><span style="color: #007700">;<br /><br />use&nbsp;</span><span style="color: #0000BB">another</span><span style="color: #007700">\</span><span style="color: #0000BB">thing&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">MyClass</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">MyClass</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;instantiates&nbsp;class&nbsp;"thing"&nbsp;from&nbsp;namespace&nbsp;another<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>
   <p class="para">
    There is no name conflict, even though the class <em>MyClass</em> exists
    within the <em>my\stuff</em> namespace, because the MyClass definition is
    in a separate file.  However, the next example causes a fatal error on name conflict
    because MyClass is defined in the same file as the use statement.
    <div class="informalexample">
     <div class="example-contents">
     <div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">namespace&nbsp;</span><span style="color: #0000BB">my</span><span style="color: #007700">\</span><span style="color: #0000BB">stuff</span><span style="color: #007700">;<br />use&nbsp;</span><span style="color: #0000BB">another</span><span style="color: #007700">\</span><span style="color: #0000BB">thing&nbsp;</span><span style="color: #007700">as&nbsp;</span><span style="color: #0000BB">MyClass</span><span style="color: #007700">;<br />class&nbsp;</span><span style="color: #0000BB">MyClass&nbsp;</span><span style="color: #007700">{}&nbsp;</span><span style="color: #FF8000">//&nbsp;fatal&nbsp;error:&nbsp;MyClass&nbsp;conflicts&nbsp;with&nbsp;import&nbsp;statement<br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">MyClass</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>
  </div>
  <div class="sect2" id="language.namespaces.faq.nested">
   <h3 class="title">Nested namespaces are not allowed.</h3>
   <p class="para">
    PHP does not allow nesting namespaces
    <div class="informalexample">
     <div class="example-contents">
     <div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">namespace&nbsp;</span><span style="color: #0000BB">my</span><span style="color: #007700">\</span><span style="color: #0000BB">stuff&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;namespace&nbsp;</span><span style="color: #0000BB">nested&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;class&nbsp;</span><span style="color: #0000BB">foo&nbsp;</span><span style="color: #007700">{}<br />&nbsp;&nbsp;&nbsp;&nbsp;}<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
    However, it is easy to simulate nested namespaces like so:
    <div class="informalexample">
     <div class="example-contents">
     <div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">namespace&nbsp;</span><span style="color: #0000BB">my</span><span style="color: #007700">\</span><span style="color: #0000BB">stuff</span><span style="color: #007700">\</span><span style="color: #0000BB">nested&nbsp;</span><span style="color: #007700">{<br />&nbsp;&nbsp;&nbsp;&nbsp;class&nbsp;</span><span style="color: #0000BB">foo&nbsp;</span><span style="color: #007700">{}<br />}<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>
  </div>
  <div class="sect2" id="language.namespaces.faq.nofuncconstantuse">
   <h3 class="title">Before PHP 5.6 neither functions nor constants can be imported via the <em>use</em>
      statement.</h3>
   <p class="para">
    Before PHP 5.6 the only elements that are affected by <em>use</em> statements are namespaces
    and class names.  In order to shorten a long constant or function, import its containing
    namespace.
    <div class="informalexample">
     <div class="example-contents">
     <div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">namespace&nbsp;</span><span style="color: #0000BB">mine</span><span style="color: #007700">;<br />use&nbsp;</span><span style="color: #0000BB">ultra</span><span style="color: #007700">\</span><span style="color: #0000BB">long</span><span style="color: #007700">\</span><span style="color: #0000BB">ns</span><span style="color: #007700">\</span><span style="color: #0000BB">name</span><span style="color: #007700">;<br /><br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">name</span><span style="color: #007700">\</span><span style="color: #0000BB">CONSTANT</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">name</span><span style="color: #007700">\</span><span style="color: #0000BB">func</span><span style="color: #007700">();<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
    As of PHP 5.6 aliasing or importing function and constant names is allowed.
   </p>
  </div>
  <div class="sect2" id="language.namespaces.faq.quote">
   <h3 class="title">Dynamic namespace names (quoted identifiers) should escape backslash</h3>
   <p class="para">
    It is very important to realize that because the backslash is used as an escape character
    within strings, it should always be doubled when used inside a string.  Otherwise
    there is a risk of unintended consequences:
    <div class="example" id="example-275">
     <p><strong>Example #9 Dangers of using namespaced names inside a double-quoted string</strong></p>
     <div class="example-contents">
      <div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br />$a&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">"dangerous\name"</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;\n&nbsp;is&nbsp;a&nbsp;newline&nbsp;inside&nbsp;double&nbsp;quoted&nbsp;strings!<br /></span><span style="color: #0000BB">$obj&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">$a</span><span style="color: #007700">;<br /><br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'not\at\all\dangerous'</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;no&nbsp;problems&nbsp;here.<br /></span><span style="color: #0000BB">$obj&nbsp;</span><span style="color: #007700">=&nbsp;new&nbsp;</span><span style="color: #0000BB">$a</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
    Inside a single-quoted string, the backslash escape sequence is much safer to use, but it
    is still recommended practice to escape backslashes in all strings as a best practice.
   </p>
  </div>
  <div class="sect2" id="language.namespaces.faq.constants">
   <h3 class="title">Undefined Constants referenced using any backslash die with fatal error</h3>
   <p class="para">
    Any undefined constant that is unqualified like <em>FOO</em> will
    produce a notice explaining that PHP assumed <em>FOO</em> was the value
    of the constant.  Any constant, qualified or fully qualified, that contains a
    backslash will produce a fatal error if not found.
    <div class="example" id="example-276">
     <p><strong>Example #10 Undefined constants</strong></p>
     <div class="example-contents">
      <div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">namespace&nbsp;</span><span style="color: #0000BB">bar</span><span style="color: #007700">;<br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">FOO</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;produces&nbsp;notice&nbsp;-&nbsp;undefined&nbsp;constants&nbsp;"FOO"&nbsp;assumed&nbsp;"FOO";<br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;\</span><span style="color: #0000BB">FOO</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;fatal&nbsp;error,&nbsp;undefined&nbsp;namespace&nbsp;constant&nbsp;FOO<br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">Bar</span><span style="color: #007700">\</span><span style="color: #0000BB">FOO</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;fatal&nbsp;error,&nbsp;undefined&nbsp;namespace&nbsp;constant&nbsp;bar\Bar\FOO<br /></span><span style="color: #0000BB">$a&nbsp;</span><span style="color: #007700">=&nbsp;\</span><span style="color: #0000BB">Bar</span><span style="color: #007700">\</span><span style="color: #0000BB">FOO</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;fatal&nbsp;error,&nbsp;undefined&nbsp;namespace&nbsp;constant&nbsp;Bar\FOO<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>
  </div>
  <div class="sect2" id="language.namespaces.faq.builtinconst">
   <h3 class="title">Cannot override special constants NULL, TRUE, FALSE, ZEND_THREAD_SAFE or ZEND_DEBUG_BUILD</h3>
   <p class="para">
    Any attempt to define a namespaced constant that is a special, built-in constant
    results in a fatal error
    <div class="example" id="example-277">
     <p><strong>Example #11 Undefined constants</strong></p>
     <div class="example-contents">
      <div class="phpcode"><code><span style="color: #000000">
<span style="color: #0000BB">&lt;?php<br /></span><span style="color: #007700">namespace&nbsp;</span><span style="color: #0000BB">bar</span><span style="color: #007700">;<br />const&nbsp;</span><span style="color: #0000BB">NULL&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #0000BB">0</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;fatal&nbsp;error;<br /></span><span style="color: #007700">const&nbsp;</span><span style="color: #0000BB">true&nbsp;</span><span style="color: #007700">=&nbsp;</span><span style="color: #DD0000">'stupid'</span><span style="color: #007700">;&nbsp;</span><span style="color: #FF8000">//&nbsp;also&nbsp;fatal&nbsp;error;<br />//&nbsp;etc.<br /></span><span style="color: #0000BB">?&gt;</span>
</span>
</code></div>
     </div>

    </div>
   </p>
  </div>
 </div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=language.namespaces.faq&amp;redirect=http://php.net/manual/en/language.namespaces.faq.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">5 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="108236">  <div class="votes">
    <div id="Vu108236">
    <a href="/manual/vote-note.php?id=108236&amp;page=language.namespaces.faq&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd108236">
    <a href="/manual/vote-note.php?id=108236&amp;page=language.namespaces.faq&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V108236" title="71% like this...">
    17
    </div>
  </div>
  <a href="#108236" class="name">
  <strong class="user"><em>manolachef at gmail dot com</em></strong></a><a class="genanchor" href="#108236"> &para;</a><div class="date" title="2012-04-10 02:32"><strong>5 years ago</strong></div>
  <div class="text" id="Hcom108236">
<div class="phpcode"><code><span class="html">
There is a way to define a namespaced constant that is a special, built-in constant, using define function and setting the third parameter case_insensitive to false:<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">namespace </span><span class="default">foo</span><span class="keyword">;<br /></span><span class="default">define</span><span class="keyword">(</span><span class="default">__NAMESPACE__ </span><span class="keyword">. </span><span class="string">'\NULL'</span><span class="keyword">, </span><span class="default">10</span><span class="keyword">); </span><span class="comment">// defines the constant NULL in the current namespace<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">NULL</span><span class="keyword">); </span><span class="comment">// will show 10<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">null</span><span class="keyword">); </span><span class="comment">// will show NULL<br /></span><span class="default">?&gt;<br /></span><br />&nbsp; No need to specify the namespace in your call to define(), like it happens usually<br /><span class="default">&lt;?php<br /></span><span class="keyword">namespace </span><span class="default">foo</span><span class="keyword">;<br /></span><span class="default">define</span><span class="keyword">(</span><span class="default">INI_ALL</span><span class="keyword">, </span><span class="string">'bar'</span><span class="keyword">); </span><span class="comment">// produces notice - Constant INI_ALL already defined. But:<br /><br /></span><span class="default">define</span><span class="keyword">(</span><span class="default">__NAMESPACE__ </span><span class="keyword">. </span><span class="string">'\INI_ALL'</span><span class="keyword">, </span><span class="string">'bar'</span><span class="keyword">); </span><span class="comment">// defines the constant INI_ALL in the current namespace<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">INI_ALL</span><span class="keyword">); </span><span class="comment">// will show string(3)"bar". Nothing unespected so far. But:<br /><br /></span><span class="default">define</span><span class="keyword">(</span><span class="string">'NULL'</span><span class="keyword">, </span><span class="default">10</span><span class="keyword">); </span><span class="comment">// defines the constant NULL in the current namespace...<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">NULL</span><span class="keyword">); </span><span class="comment">// will show 10<br /></span><span class="default">var_dump</span><span class="keyword">(</span><span class="default">null</span><span class="keyword">); </span><span class="comment">// will show NULL<br /></span><span class="default">?&gt;<br /></span><br />&nbsp; If the parameter case_insensitive is set to true<br /><span class="default">&lt;?php<br /></span><span class="keyword">namespace </span><span class="default">foo</span><span class="keyword">;<br /></span><span class="default">define </span><span class="keyword">(</span><span class="default">__NAMESPACE__ </span><span class="keyword">. </span><span class="string">'\NULL'</span><span class="keyword">, </span><span class="default">10</span><span class="keyword">, </span><span class="default">true</span><span class="keyword">); </span><span class="comment">// produces notice - Constant null already defined<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119983">  <div class="votes">
    <div id="Vu119983">
    <a href="/manual/vote-note.php?id=119983&amp;page=language.namespaces.faq&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119983">
    <a href="/manual/vote-note.php?id=119983&amp;page=language.namespaces.faq&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119983" title="75% like this...">
    2
    </div>
  </div>
  <a href="#119983" class="name">
  <strong class="user"><em>shaun at slickdesign dot com dot au</em></strong></a><a class="genanchor" href="#119983"> &para;</a><div class="date" title="2016-10-04 07:20"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119983">
<div class="phpcode"><code><span class="html">
When creating classes or calling static methods from within namespaces using variables, you need to keep in mind that they require the full namespace in order for the appropriate class to be used; you CANNOT use an alias or short name, even if it is called within the same namespace. Neglecting to take this into account can cause your code to use the wrong class, throw a fatal missing class exception, or throw errors or warnings.<br /><br />In these cases, you can use the magic constant __NAMESPACE__, or specify the full namespace and class name directly. The function class_exists also requires the full namespace and class name, and can be used to ensure that a fatal error won't be thrown due to missing classes.<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">namespace </span><span class="default">Foo</span><span class="keyword">;<br />class </span><span class="default">Bar </span><span class="keyword">{<br />&nbsp; &nbsp; public static function </span><span class="default">test</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; return </span><span class="default">get_called_class</span><span class="keyword">();<br />&nbsp; &nbsp; }<br />}<br /><br />namespace </span><span class="default">Foo</span><span class="keyword">\</span><span class="default">Foo</span><span class="keyword">;<br />class </span><span class="default">Bar </span><span class="keyword">extends \</span><span class="default">Foo</span><span class="keyword">\</span><span class="default">Bar </span><span class="keyword">{<br />}<br /><br /></span><span class="default">var_dump</span><span class="keyword">( </span><span class="default">Bar</span><span class="keyword">::</span><span class="default">test</span><span class="keyword">() ); </span><span class="comment">// string(11) "Foo\Foo\Bar"<br /><br /></span><span class="default">$bar </span><span class="keyword">= </span><span class="string">'Foo\Bar'</span><span class="keyword">;<br /></span><span class="default">var_dump</span><span class="keyword">( </span><span class="default">$bar</span><span class="keyword">::</span><span class="default">test</span><span class="keyword">() ); </span><span class="comment">// string(7) "Foo\Bar"<br /><br /></span><span class="default">$bar </span><span class="keyword">= </span><span class="default">__NAMESPACE__ </span><span class="keyword">. </span><span class="string">'\Bar'</span><span class="keyword">;<br /></span><span class="default">var_dump</span><span class="keyword">( </span><span class="default">$bar</span><span class="keyword">::</span><span class="default">test</span><span class="keyword">() ); </span><span class="comment">// string(11) "Foo\Foo\Bar"<br /><br /></span><span class="default">$bar </span><span class="keyword">= </span><span class="string">'Bar'</span><span class="keyword">;<br /></span><span class="default">var_dump</span><span class="keyword">( </span><span class="default">$bar</span><span class="keyword">::</span><span class="default">test</span><span class="keyword">() ); </span><span class="comment">// FATAL ERROR: Class 'Bar' not found or Incorrect class \Bar used</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="116945">  <div class="votes">
    <div id="Vu116945">
    <a href="/manual/vote-note.php?id=116945&amp;page=language.namespaces.faq&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd116945">
    <a href="/manual/vote-note.php?id=116945&amp;page=language.namespaces.faq&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V116945" title="52% like this...">
    1
    </div>
  </div>
  <a href="#116945" class="name">
  <strong class="user"><em>phpcoder</em></strong></a><a class="genanchor" href="#116945"> &para;</a><div class="date" title="2015-03-25 01:01"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom116945">
<div class="phpcode"><code><span class="html">
Regarding "Neither functions nor constants can be imported via the use statement." Actually you can do it in PHP 5.6+:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="comment">// importing a function (PHP 5.6+)<br /></span><span class="keyword">use function </span><span class="default">My</span><span class="keyword">\</span><span class="default">Full</span><span class="keyword">\</span><span class="default">functionName</span><span class="keyword">;<br /><br /></span><span class="comment">// aliasing a function (PHP 5.6+)<br /></span><span class="keyword">use function </span><span class="default">My</span><span class="keyword">\</span><span class="default">Full</span><span class="keyword">\</span><span class="default">functionName </span><span class="keyword">as </span><span class="default">func</span><span class="keyword">;<br /><br /></span><span class="comment">// importing a constant (PHP 5.6+)<br /></span><span class="keyword">use const </span><span class="default">My</span><span class="keyword">\</span><span class="default">Full</span><span class="keyword">\</span><span class="default">CONSTANT</span><span class="keyword">;<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119234">  <div class="votes">
    <div id="Vu119234">
    <a href="/manual/vote-note.php?id=119234&amp;page=language.namespaces.faq&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119234">
    <a href="/manual/vote-note.php?id=119234&amp;page=language.namespaces.faq&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119234" title="50% like this...">
    0
    </div>
  </div>
  <a href="#119234" class="name">
  <strong class="user"><em>teohad at NOSPAM dot gmail dot com</em></strong></a><a class="genanchor" href="#119234"> &para;</a><div class="date" title="2016-04-24 09:02"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119234">
<div class="phpcode"><code><span class="html">
[Editor's note: that behavior is caused by a bug in PHP 7.0, which has been fixed as of PHP 7.0.7.]<br /><br />Regarding the entry "Import names cannot conflict with classes defined in the same file".<br />- I found that since PHP 7.0 this is no longer the case.<br />In PHP 7.0 you can have a class with a name that matches an imported class (or namespace or both at the same time).<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">namespace </span><span class="default">ns1 </span><span class="keyword">{<br />&nbsp; class </span><span class="default">ns1 </span><span class="keyword">{<br />&nbsp; &nbsp; public static function </span><span class="default">write</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; echo </span><span class="string">"ns1\\ns1::write()\n"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; }<br />}<br /><br />namespace </span><span class="default">ns1</span><span class="keyword">\</span><span class="default">ns1 </span><span class="keyword">{<br />&nbsp; class </span><span class="default">ns1c </span><span class="keyword">{<br />&nbsp; &nbsp; public static function </span><span class="default">write</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; echo </span><span class="string">"ns1\\ns1\\ns1c::write()\n"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; }<br />}<br /><br />namespace </span><span class="default">ns2 </span><span class="keyword">{<br />&nbsp; use </span><span class="default">ns1</span><span class="keyword">\</span><span class="default">ns1 </span><span class="keyword">as </span><span class="default">ns1</span><span class="keyword">; </span><span class="comment">// both a class in ns1, and a namespace ns1\ns1<br />&nbsp; &nbsp; <br />&nbsp; // the next class causes fatal error in php 5.6, not in 7.0<br />&nbsp; </span><span class="keyword">class </span><span class="default">ns1 </span><span class="keyword">{<br />&nbsp; &nbsp; public static function </span><span class="default">write</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; echo </span><span class="string">"ns2\\ns1::write()\n"</span><span class="keyword">;<br />&nbsp; &nbsp; }<br />&nbsp; }<br />&nbsp; &nbsp; <br />&nbsp; </span><span class="default">ns1</span><span class="keyword">::</span><span class="default">write</span><span class="keyword">(); </span><span class="comment">// calls imported ns1\ns1::write()<br />&nbsp; </span><span class="default">ns1</span><span class="keyword">\</span><span class="default">ns1c</span><span class="keyword">::</span><span class="default">write</span><span class="keyword">(); </span><span class="comment">// calls imported ns1\ns1\ns1c::write()<br />&nbsp; </span><span class="keyword">namespace\</span><span class="default">ns1</span><span class="keyword">::</span><span class="default">write</span><span class="keyword">(); </span><span class="comment">// calls ns2\ns1::write()<br /></span><span class="keyword">}<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="112807">  <div class="votes">
    <div id="Vu112807">
    <a href="/manual/vote-note.php?id=112807&amp;page=language.namespaces.faq&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd112807">
    <a href="/manual/vote-note.php?id=112807&amp;page=language.namespaces.faq&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V112807" title="44% like this...">
    -1
    </div>
  </div>
  <a href="#112807" class="name">
  <strong class="user"><em>okaresz</em></strong></a><a class="genanchor" href="#112807"> &para;</a><div class="date" title="2013-07-25 08:31"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom112807">
<div class="phpcode"><code><span class="html">
To correct manolachef's answer: define() ALWAYS defines constants in the GLOBAL namespace.<br /><br />As nl-x at bita dot nl states in the note at <a href="http://www.php.net/manual/en/function.define.php," rel="nofollow" target="_blank">http://www.php.net/manual/en/function.define.php,</a> the constant "NULL" can be defined with define() case-sensitively, but can only be retrieved with constant(), leaving the meaning of NULL uppercase keyword as the only value of the type null.</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=language.namespaces.faq&amp;redirect=http://php.net/manual/en/language.namespaces.faq.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.namespaces.php">Namespaces</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="language.namespaces.rationale.php" title="Namespaces overview">Namespaces overview</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.definition.php" title="Defining namespaces">Defining namespaces</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.nested.php" title="Declaring sub-&#8203;namespaces">Declaring sub-&#8203;namespaces</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.definitionmultiple.php" title="Defining multiple namespaces in the same file">Defining multiple namespaces in the same file</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.basics.php" title="Using namespaces: Basics">Using namespaces: Basics</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.dynamic.php" title="Namespaces and dynamic language features">Namespaces and dynamic language features</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.nsconstants.php" title="namespace keyword and _&#8203;_&#8203;NAMESPACE_&#8203;_&#8203; constant">namespace keyword and _&#8203;_&#8203;NAMESPACE_&#8203;_&#8203; constant</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.importing.php" title="Using namespaces: Aliasing/Importing">Using namespaces: Aliasing/Importing</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.global.php" title="Global space">Global space</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.fallback.php" title="Using namespaces: fallback to global function/constant">Using namespaces: fallback to global function/constant</a>
                        </li>
                          
                        <li class="">
                            <a href="language.namespaces.rules.php" title="Name resolution rules">Name resolution rules</a>
                        </li>
                          
                        <li class="current">
                            <a href="language.namespaces.faq.php" title="FAQ: things you need to know about namespaces">FAQ: things you need to know about namespaces</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

