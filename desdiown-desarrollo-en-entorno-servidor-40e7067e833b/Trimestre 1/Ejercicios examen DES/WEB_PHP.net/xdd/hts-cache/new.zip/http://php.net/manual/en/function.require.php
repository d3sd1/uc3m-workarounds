<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 

  <title>PHP: require - Manual </title>

 <link rel="shortcut icon" href="http://php.net/favicon.ico">
 <link rel="search" type="application/opensearchdescription+xml" href="http://php.net/phpnetimprovedsearch.src" title="Add PHP.net search">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/releases/feed.php" title="PHP Release feed">
 <link rel="alternate" type="application/atom+xml" href="http://php.net/feed.atom" title="PHP: Hypertext Preprocessor">

 <link rel="canonical" href="http://php.net/manual/en/function.require.php">
 <link rel="shorturl" href="http://php.net/require">
 <link rel="alternate" href="http://php.net/require" hreflang="x-default">

 <link rel="contents" href="http://php.net/manual/en/index.php">
 <link rel="index" href="http://php.net/manual/en/language.control-structures.php">
 <link rel="prev" href="http://php.net/manual/en/function.return.php">
 <link rel="next" href="http://php.net/manual/en/function.include.php">

 <link rel="alternate" href="http://php.net/manual/en/function.require.php" hreflang="en">
 <link rel="alternate" href="http://php.net/manual/pt_BR/function.require.php" hreflang="pt_BR">
 <link rel="alternate" href="http://php.net/manual/zh/function.require.php" hreflang="zh">
 <link rel="alternate" href="http://php.net/manual/fr/function.require.php" hreflang="fr">
 <link rel="alternate" href="http://php.net/manual/de/function.require.php" hreflang="de">
 <link rel="alternate" href="http://php.net/manual/ja/function.require.php" hreflang="ja">
 <link rel="alternate" href="http://php.net/manual/ro/function.require.php" hreflang="ro">
 <link rel="alternate" href="http://php.net/manual/ru/function.require.php" hreflang="ru">
 <link rel="alternate" href="http://php.net/manual/es/function.require.php" hreflang="es">
 <link rel="alternate" href="http://php.net/manual/tr/function.require.php" hreflang="tr">

<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Fira/fira.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1421837618&amp;f=/fonts/Font-Awesome/css/fontello.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1478800802&amp;f=/styles/theme-base.css" media="screen">
<link rel="stylesheet" type="text/css" href="http://php.net/cached.php?t=1449787206&amp;f=/styles/theme-medium.css" media="screen">

 <!--[if lte IE 7]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie7.css" media="screen">
 <![endif]-->

 <!--[if lte IE 8]>
 <script type="text/javascript">
  window.brokenIE = true;
 </script>
 <![endif]-->

 <!--[if lte IE 9]>
 <link rel="stylesheet" type="text/css" href="http://php.net/styles/workarounds.ie9.css" media="screen">
 <![endif]-->

 <!--[if IE]>
 <script type="text/javascript" src="http://php.net/js/ext/html5.js"></script>
 <![endif]-->

 <base href="http://php.net/manual/en/function.require.php">

</head>
<body class="docs ">

<nav id="head-nav" class="navbar navbar-fixed-top">
  <div class="navbar-inner clearfix">
    <a href="/" class="brand"><img src="/images/logos/php-logo.svg" width="48" height="24" alt="php"></a>
    <div id="mainmenu-toggle-overlay"></div>
    <input type="checkbox" id="mainmenu-toggle">
    <ul class="nav">
      <li class=""><a href="/downloads">Downloads</a></li>
      <li class="active"><a href="/docs.php">Documentation</a></li>
      <li class=""><a href="/get-involved" >Get Involved</a></li>
      <li class=""><a href="/support">Help</a></li>
    </ul>
    <form class="navbar-search" id="topsearch" action="/search.php">
      <input type="hidden" name="show" value="quickref">
      <input type="search" name="pattern" class="search-query" placeholder="Search" accesskey="s">
    </form>
  </div>
  <div id="flash-message"></div>
</nav>
<nav id="trick"><div><dl>
<dt><a href='/manual/en/getting-started.php'>Getting Started</a></dt>
	<dd><a href='/manual/en/introduction.php'>Introduction</a></dd>
	<dd><a href='/manual/en/tutorial.php'>A simple tutorial</a></dd>
<dt><a href='/manual/en/langref.php'>Language Reference</a></dt>
	<dd><a href='/manual/en/language.basic-syntax.php'>Basic syntax</a></dd>
	<dd><a href='/manual/en/language.types.php'>Types</a></dd>
	<dd><a href='/manual/en/language.variables.php'>Variables</a></dd>
	<dd><a href='/manual/en/language.constants.php'>Constants</a></dd>
	<dd><a href='/manual/en/language.expressions.php'>Expressions</a></dd>
	<dd><a href='/manual/en/language.operators.php'>Operators</a></dd>
	<dd><a href='/manual/en/language.control-structures.php'>Control Structures</a></dd>
	<dd><a href='/manual/en/language.functions.php'>Functions</a></dd>
	<dd><a href='/manual/en/language.oop5.php'>Classes and Objects</a></dd>
	<dd><a href='/manual/en/language.namespaces.php'>Namespaces</a></dd>
	<dd><a href='/manual/en/language.errors.php'>Errors</a></dd>
	<dd><a href='/manual/en/language.exceptions.php'>Exceptions</a></dd>
	<dd><a href='/manual/en/language.generators.php'>Generators</a></dd>
	<dd><a href='/manual/en/language.references.php'>References Explained</a></dd>
	<dd><a href='/manual/en/reserved.variables.php'>Predefined Variables</a></dd>
	<dd><a href='/manual/en/reserved.exceptions.php'>Predefined Exceptions</a></dd>
	<dd><a href='/manual/en/reserved.interfaces.php'>Predefined Interfaces and Classes</a></dd>
	<dd><a href='/manual/en/context.php'>Context options and parameters</a></dd>
	<dd><a href='/manual/en/wrappers.php'>Supported Protocols and Wrappers</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/security.php'>Security</a></dt>
	<dd><a href='/manual/en/security.intro.php'>Introduction</a></dd>
	<dd><a href='/manual/en/security.general.php'>General considerations</a></dd>
	<dd><a href='/manual/en/security.cgi-bin.php'>Installed as CGI binary</a></dd>
	<dd><a href='/manual/en/security.apache.php'>Installed as an Apache module</a></dd>
	<dd><a href='/manual/en/security.sessions.php'>Session Security</a></dd>
	<dd><a href='/manual/en/security.filesystem.php'>Filesystem Security</a></dd>
	<dd><a href='/manual/en/security.database.php'>Database Security</a></dd>
	<dd><a href='/manual/en/security.errors.php'>Error Reporting</a></dd>
	<dd><a href='/manual/en/security.globals.php'>Using Register Globals</a></dd>
	<dd><a href='/manual/en/security.variables.php'>User Submitted Data</a></dd>
	<dd><a href='/manual/en/security.magicquotes.php'>Magic Quotes</a></dd>
	<dd><a href='/manual/en/security.hiding.php'>Hiding PHP</a></dd>
	<dd><a href='/manual/en/security.current.php'>Keeping Current</a></dd>
<dt><a href='/manual/en/features.php'>Features</a></dt>
	<dd><a href='/manual/en/features.http-auth.php'>HTTP authentication with PHP</a></dd>
	<dd><a href='/manual/en/features.cookies.php'>Cookies</a></dd>
	<dd><a href='/manual/en/features.sessions.php'>Sessions</a></dd>
	<dd><a href='/manual/en/features.xforms.php'>Dealing with XForms</a></dd>
	<dd><a href='/manual/en/features.file-upload.php'>Handling file uploads</a></dd>
	<dd><a href='/manual/en/features.remote-files.php'>Using remote files</a></dd>
	<dd><a href='/manual/en/features.connection-handling.php'>Connection handling</a></dd>
	<dd><a href='/manual/en/features.persistent-connections.php'>Persistent Database Connections</a></dd>
	<dd><a href='/manual/en/features.safe-mode.php'>Safe Mode</a></dd>
	<dd><a href='/manual/en/features.commandline.php'>Command line usage</a></dd>
	<dd><a href='/manual/en/features.gc.php'>Garbage Collection</a></dd>
	<dd><a href='/manual/en/features.dtrace.php'>DTrace Dynamic Tracing</a></dd>
</dl>
<dl>
<dt><a href='/manual/en/funcref.php'>Function Reference</a></dt>
	<dd><a href='/manual/en/refs.basic.php.php'>Affecting PHP's Behaviour</a></dd>
	<dd><a href='/manual/en/refs.utilspec.audio.php'>Audio Formats Manipulation</a></dd>
	<dd><a href='/manual/en/refs.remote.auth.php'>Authentication Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.cmdline.php'>Command Line Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.compression.php'>Compression and Archive Extensions</a></dd>
	<dd><a href='/manual/en/refs.creditcard.php'>Credit Card Processing</a></dd>
	<dd><a href='/manual/en/refs.crypto.php'>Cryptography Extensions</a></dd>
	<dd><a href='/manual/en/refs.database.php'>Database Extensions</a></dd>
	<dd><a href='/manual/en/refs.calendar.php'>Date and Time Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.file.php'>File System Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.international.php'>Human Language and Character Encoding Support</a></dd>
	<dd><a href='/manual/en/refs.utilspec.image.php'>Image Processing and Generation</a></dd>
	<dd><a href='/manual/en/refs.remote.mail.php'>Mail Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.math.php'>Mathematical Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.nontext.php'>Non-Text MIME Output</a></dd>
	<dd><a href='/manual/en/refs.fileprocess.process.php'>Process Control Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.other.php'>Other Basic Extensions</a></dd>
	<dd><a href='/manual/en/refs.remote.other.php'>Other Services</a></dd>
	<dd><a href='/manual/en/refs.search.php'>Search Engine Extensions</a></dd>
	<dd><a href='/manual/en/refs.utilspec.server.php'>Server Specific Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.session.php'>Session Extensions</a></dd>
	<dd><a href='/manual/en/refs.basic.text.php'>Text Processing</a></dd>
	<dd><a href='/manual/en/refs.basic.vartype.php'>Variable and Type Related Extensions</a></dd>
	<dd><a href='/manual/en/refs.webservice.php'>Web Services</a></dd>
	<dd><a href='/manual/en/refs.utilspec.windows.php'>Windows Only Extensions</a></dd>
	<dd><a href='/manual/en/refs.xml.php'>XML Manipulation</a></dd>
	<dd><a href='/manual/en/refs.ui.php'>GUI Extensions</a></dd>
</dl>
<dl>
<dt>Keyboard Shortcuts</dt><dt>?</dt>
<dd>This help</dd>
<dt>j</dt>
<dd>Next menu item</dd>
<dt>k</dt>
<dd>Previous menu item</dd>
<dt>g p</dt>
<dd>Previous man page</dd>
<dt>g n</dt>
<dd>Next man page</dd>
<dt>G</dt>
<dd>Scroll to bottom</dd>
<dt>g g</dt>
<dd>Scroll to top</dd>
<dt>g h</dt>
<dd>Goto homepage</dd>
<dt>g s</dt>
<dd>Goto search<br>(current page)</dd>
<dt>/</dt>
<dd>Focus search box</dd>
</dl></div></nav>
<div id="goto">
    <div class="search">
         <div class="text"></div>
         <div class="results"><ul></ul></div>
   </div>
</div>

  <div id="breadcrumbs" class="clearfix">
    <div id="breadcrumbs-inner">
          <div class="next">
        <a href="function.include.php">
          include &raquo;
        </a>
      </div>
              <div class="prev">
        <a href="function.return.php">
          &laquo; return        </a>
      </div>
          <ul>
            <li><a href='index.php'>PHP Manual</a></li>      <li><a href='langref.php'>Language Reference</a></li>      <li><a href='language.control-structures.php'>Control Structures</a></li>      </ul>
    </div>
  </div>




<div id="layout" class="clearfix">
  <section id="layout-content">
  <div class="page-tools">
    <div class="change-language">
      <form action="/manual/change.php" method="get" id="changelang" name="changelang">
        <fieldset>
          <label for="changelang-langs">Change language:</label>
          <select onchange="document.changelang.submit()" name="page" id="changelang-langs">
            <option value='en/function.require.php' selected="selected">English</option>
            <option value='pt_BR/function.require.php'>Brazilian Portuguese</option>
            <option value='zh/function.require.php'>Chinese (Simplified)</option>
            <option value='fr/function.require.php'>French</option>
            <option value='de/function.require.php'>German</option>
            <option value='ja/function.require.php'>Japanese</option>
            <option value='ro/function.require.php'>Romanian</option>
            <option value='ru/function.require.php'>Russian</option>
            <option value='es/function.require.php'>Spanish</option>
            <option value='tr/function.require.php'>Turkish</option>
            <option value="help-translate.php">Other</option>
          </select>
        </fieldset>
      </form>
    </div>
    <div class="edit-bug">
      <a href="https://edit.php.net/?project=PHP&amp;perm=en/function.require.php">Edit</a>
      <a href="https://bugs.php.net/report.php?bug_type=Documentation+problem&amp;manpage=function.require">Report a Bug</a>
    </div>
  </div><div id="function.require" class="sect1">
 <h2 class="title">require</h2>
 <p class="verinfo">(PHP 4, PHP 5, PHP 7)</p>
 
 <p class="para">
  <em>require</em> is identical to <span class="function"><a href="function.include.php" class="function">include</a></span>
  except upon failure it will also produce a fatal <strong><code>E_COMPILE_ERROR</code></strong>
  level error. In other words, it will halt the script whereas
  <span class="function"><a href="function.include.php" class="function">include</a></span> only emits a warning 
  (<strong><code>E_WARNING</code></strong>) which allows the script to continue.
 </p>
 <p class="para">
  See the <span class="function"><a href="function.include.php" class="function">include</a></span> documentation for how this works.
 </p>
 
</div>
<section id="usernotes">
 <div class="head">
  <span class="action"><a href="/manual/add-note.php?sect=function.require&amp;redirect=http://php.net/manual/en/function.require.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></span>
  <h3 class="title">User Contributed Notes <span class="count">25 notes</span></h3>
 </div><div id="allnotes">
  <div class="note" id="75875">  <div class="votes">
    <div id="Vu75875">
    <a href="/manual/vote-note.php?id=75875&amp;page=function.require&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd75875">
    <a href="/manual/vote-note.php?id=75875&amp;page=function.require&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V75875" title="57% like this...">
    90
    </div>
  </div>
  <a href="#75875" class="name">
  <strong class="user"><em>chris at chrisstockton dot org</em></strong></a><a class="genanchor" href="#75875"> &para;</a><div class="date" title="2007-06-19 05:06"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom75875">
<div class="phpcode"><code><span class="html">
Remember, when using require that it is a statement, not a function. It's not necessary to write:<br /><span class="default">&lt;?php<br /> </span><span class="keyword">require(</span><span class="string">'somefile.php'</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />The following:<br /><span class="default">&lt;?php<br /></span><span class="keyword">require </span><span class="string">'somefile.php'</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />Is preferred, it will prevent your peers from giving you a hard time and a trivial conversation about what require really is.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="72742">  <div class="votes">
    <div id="Vu72742">
    <a href="/manual/vote-note.php?id=72742&amp;page=function.require&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd72742">
    <a href="/manual/vote-note.php?id=72742&amp;page=function.require&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V72742" title="53% like this...">
    8
    </div>
  </div>
  <a href="#72742" class="name"><strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#72742"> &para;</a><div class="date" title="2007-01-31 03:38"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom72742">
<div class="phpcode"><code><span class="html">
A note that drove me nuts for 2 days!<br /><br />Be carfull if you have a newline or blank space befor your php tags in the included/required file it will read as html and outputed.<br /><br />If your running your output through javascript string evaluations which would be sensitive to newlines/white spaces be carfull that the first chars in the file are the php tages eg &lt;?php</span>
</code></div>
  </div>
 </div>
  <div class="note" id="60987">  <div class="votes">
    <div id="Vu60987">
    <a href="/manual/vote-note.php?id=60987&amp;page=function.require&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd60987">
    <a href="/manual/vote-note.php?id=60987&amp;page=function.require&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V60987" title="52% like this...">
    3
    </div>
  </div>
  <a href="#60987" class="name">
  <strong class="user"><em>dave at davidhbrown dot us</em></strong></a><a class="genanchor" href="#60987"> &para;</a><div class="date" title="2006-01-22 12:08"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom60987">
<div class="phpcode"><code><span class="html">
re: danielm at unb dot br...<br /><br />$_SERVER['DOCUMENT_ROOT'] is very useful, but it is not available with all web servers. Apache has it; IIS doesn't. <br /><br />I use the following to make my PHP applications work in more situations:<br /><span class="default">&lt;?php<br /></span><span class="keyword">if (!</span><span class="default">defined</span><span class="keyword">(</span><span class="string">"BASE_PATH"</span><span class="keyword">)) </span><span class="default">define</span><span class="keyword">(</span><span class="string">'BASE_PATH'</span><span class="keyword">, isset(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'DOCUMENT_ROOT'</span><span class="keyword">]) ? </span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'DOCUMENT_ROOT'</span><span class="keyword">] : </span><span class="default">substr</span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'PATH_TRANSLATED'</span><span class="keyword">],</span><span class="default">0</span><span class="keyword">, -</span><span class="default">1</span><span class="keyword">*</span><span class="default">strlen</span><span class="keyword">(</span><span class="default">$_SERVER</span><span class="keyword">[</span><span class="string">'SCRIPT_NAME'</span><span class="keyword">])));<br /></span><span class="default">?&gt;<br /></span><br />...but even that gets tripped up by symlinks to different mount points, etc. You could substitute realpath($_SERVER['PATH_TRANSLATED']), but that function has been reported not to work on some (Windows) servers. One could use the PATH_TRANSLATED for both servers, but I figure if Apache is going to tell me exactly what I want to know, I should listen.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="68126">  <div class="votes">
    <div id="Vu68126">
    <a href="/manual/vote-note.php?id=68126&amp;page=function.require&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd68126">
    <a href="/manual/vote-note.php?id=68126&amp;page=function.require&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V68126" title="49% like this...">
    -1
    </div>
  </div>
  <a href="#68126" class="name">
  <strong class="user"><em>gabe at websaviour dot com</em></strong></a><a class="genanchor" href="#68126"> &para;</a><div class="date" title="2006-07-13 05:42"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom68126">
<div class="phpcode"><code><span class="html">
If you are experiencing a bug related to using relative paths with include or require, it may be related to a grandparent directory that is executable but not readable.&nbsp; It will cause __FILE__ to return a relative path instead of the full path which it is supposed to show.&nbsp; This manifests itself in interesting ways that can be seemingly unrelated.&nbsp; For instance, I discovered it using the Smarty {debug} command which failed to find its template due to this issue.&nbsp; Please see the following for more details:<br /><br /><a href="http://bugs.php.net/bug.php?id=34552" rel="nofollow" target="_blank">http://bugs.php.net/bug.php?id=34552</a><br /><a href="http://shiftmanager.net/~kurt/test/" rel="nofollow" target="_blank">http://shiftmanager.net/~kurt/test/</a></span>
</code></div>
  </div>
 </div>
  <div class="note" id="65990">  <div class="votes">
    <div id="Vu65990">
    <a href="/manual/vote-note.php?id=65990&amp;page=function.require&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd65990">
    <a href="/manual/vote-note.php?id=65990&amp;page=function.require&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V65990" title="47% like this...">
    -4
    </div>
  </div>
  <a href="#65990" class="name">
  <strong class="user"><em>tjeerd</em></strong></a><a class="genanchor" href="#65990"> &para;</a><div class="date" title="2006-05-11 06:41"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom65990">
<div class="phpcode"><code><span class="html">
When using symbolic links with PHP, specify a dotslash './page.php' path to ensure that PHP is looking in the right directory with nested requires:<br /><br />E.g. when the required actual page1.php contains other require statements to, say page2.php, PHP will search the path that the symbolic link points to, instead of the path where the symbolic link lives. To let PHP find the other page2.php in the path of the symbolic link, a require('./page2.php'); statement will solve the puzzle.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="87191">  <div class="votes">
    <div id="Vu87191">
    <a href="/manual/vote-note.php?id=87191&amp;page=function.require&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd87191">
    <a href="/manual/vote-note.php?id=87191&amp;page=function.require&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V87191" title="42% like this...">
    -9
    </div>
  </div>
  <a href="#87191" class="name">
  <strong class="user"><em>duccio at getlocal dot it</em></strong></a><a class="genanchor" href="#87191"> &para;</a><div class="date" title="2008-11-23 01:37"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom87191">
<div class="phpcode"><code><span class="html">
In response to some dot user at notarealdomain dot com:<br /><br />This is because require executes the code "as if" it was code written inside of the function, inheriting everything including the scope. But here there is something even more interesting:<br /><br />&lt;requiredfile.php&gt;:<br /><span class="default">&lt;?php<br /><br />$this</span><span class="keyword">-&gt;</span><span class="default">a</span><span class="keyword">.=</span><span class="string">" is visible also under a require\n"</span><span class="keyword">;<br /></span><span class="default">$b</span><span class="keyword">=</span><span class="string">"While the variable b is a local variable of the function\n"</span><span class="keyword">;<br />function </span><span class="default">FunctionUnderRequire</span><span class="keyword">() {<br />&nbsp; &nbsp; echo </span><span class="string">"But the functions declared inside of a require called from a class function, just as when defined from inside any other function, are always global\n"</span><span class="keyword">;<br />}<br /></span><span class="default">?&gt;<br /></span><br />&lt;mainfile.php&gt;:<br /><span class="default">&lt;?php<br /><br />error_reporting</span><span class="keyword">(</span><span class="default">E_ALL</span><span class="keyword">|</span><span class="default">E_STRICT</span><span class="keyword">);<br /><br />class </span><span class="default">UserClass </span><span class="keyword">{<br /><br />&nbsp; &nbsp; protected </span><span class="default">$a</span><span class="keyword">;<br /><br />&nbsp; &nbsp; public function </span><span class="default">UserFunction</span><span class="keyword">() {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">a</span><span class="keyword">=</span><span class="string">'The class variable a'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; require </span><span class="string">'requiredfile.php'</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; echo </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">a</span><span class="keyword">; </span><span class="comment">// "The class variable a&nbsp; is visible also under a require\n"<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">echo </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">b</span><span class="keyword">; </span><span class="comment">// Notice: Undefined property: UserClass::$b<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="keyword">echo </span><span class="default">$b</span><span class="keyword">; </span><span class="comment">// "While the variable b is a local variable of the function\n"<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$this</span><span class="keyword">-&gt;</span><span class="default">FunctionUnderRequire</span><span class="keyword">(); </span><span class="comment">//Fatal error!<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">FunctionUnderRequire</span><span class="keyword">(); </span><span class="comment">// "But the functions..."<br />&nbsp; &nbsp; </span><span class="keyword">}<br />}<br /><br /></span><span class="default">$UserClass</span><span class="keyword">=new </span><span class="default">UserClass</span><span class="keyword">;<br /></span><span class="default">$UserClass</span><span class="keyword">-&gt;</span><span class="default">UserFunction</span><span class="keyword">();<br /></span><span class="default">?&gt;<br /></span><br />I'm wondering if there is a method for declaring class public/private/protected functions from inside a require/include...</span>
</code></div>
  </div>
 </div>
  <div class="note" id="114328">  <div class="votes">
    <div id="Vu114328">
    <a href="/manual/vote-note.php?id=114328&amp;page=function.require&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd114328">
    <a href="/manual/vote-note.php?id=114328&amp;page=function.require&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V114328" title="38% like this...">
    -8
    </div>
  </div>
  <a href="#114328" class="name">
  <strong class="user"><em>moreau dot marc dot web at gmail dot com</em></strong></a><a class="genanchor" href="#114328"> &para;</a><div class="date" title="2014-02-07 10:10"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom114328">
<div class="phpcode"><code><span class="html">
Petit script pour résoudre le problème de l'inclusion dans l'inclusion.<br /><br />A requiert B qui requiert C -&gt; l'on doit normalement faire correspondre le requiere de B en fonction de l'endroit ou se trouve A dans l'arborescence du site. Pas de souci, sauf si l'on est amené à requérir B depuis une autre page, impossible alors de faire appel au C -&gt; cela retourne une erreur "fichier non trouvé".<br /><br />Voici une solution qui marche sur tout type de configuration:<br /><br />Dans B:<br /><br /><span class="default">&lt;?php<br /><br />chdir</span><span class="keyword">(</span><span class="default">__DIR__</span><span class="keyword">); </span><span class="comment">//Sert à indiquer à PHP le dossier de référence de travail<br /><br /></span><span class="default">$file_to_require</span><span class="keyword">=</span><span class="default">realpath</span><span class="keyword">(</span><span class="string">'./../../adresse_de_C_relative_par_raport_a_B.php'</span><span class="keyword">); </span><span class="comment">//Crée l'adresse absolue de C<br /><br /></span><span class="keyword">require(</span><span class="default">$file_to_require</span><span class="keyword">); unset(</span><span class="default">$file_to_require</span><span class="keyword">);<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="76348">  <div class="votes">
    <div id="Vu76348">
    <a href="/manual/vote-note.php?id=76348&amp;page=function.require&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd76348">
    <a href="/manual/vote-note.php?id=76348&amp;page=function.require&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V76348" title="41% like this...">
    -12
    </div>
  </div>
  <a href="#76348" class="name">
  <strong class="user"><em>some dot user at notarealdomain dot com</em></strong></a><a class="genanchor" href="#76348"> &para;</a><div class="date" title="2007-07-11 07:58"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom76348">
<div class="phpcode"><code><span class="html">
Discovered a bit of weird behavior yesterday involving require() (using PHP 5.2.3).&nbsp; If you use require() inside a function, the "globals" in the file will be local to the function.&nbsp; An example of this:<br /><br />test.php:<br /><span class="default">&lt;?php<br />&nbsp; </span><span class="keyword">function </span><span class="default">TestFunc</span><span class="keyword">()<br />&nbsp; {<br />&nbsp; &nbsp; require(</span><span class="string">'test2.php'</span><span class="keyword">);<br />&nbsp; &nbsp; echo </span><span class="string">"&lt;pre&gt;" </span><span class="keyword">. </span><span class="default">print_r</span><span class="keyword">(</span><span class="default">$GLOBALS</span><span class="keyword">, </span><span class="default">true</span><span class="keyword">) . </span><span class="string">"&lt;/pre&gt;"</span><span class="keyword">;<br />&nbsp; }<br /></span><span class="default">?&gt;<br /></span><br />test2.php:<br /><span class="default">&lt;?php<br />&nbsp; $MyTestGlobal </span><span class="keyword">= Array();<br /></span><span class="default">?&gt;<br /></span><br />This happens because require is a statement that _inlines_ the target code - not a function that gets called.<br /><br />To fix this, use the $GLOBALS superglobal:<br /><br />test2.php:<br /><span class="default">&lt;?php<br />&nbsp; $GLOBALS</span><span class="keyword">[</span><span class="string">"MyTestGlobal"</span><span class="keyword">] = Array();<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="78517">  <div class="votes">
    <div id="Vu78517">
    <a href="/manual/vote-note.php?id=78517&amp;page=function.require&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd78517">
    <a href="/manual/vote-note.php?id=78517&amp;page=function.require&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V78517" title="39% like this...">
    -10
    </div>
  </div>
  <a href="#78517" class="name">
  <strong class="user"><em>Peter McDonald</em></strong></a><a class="genanchor" href="#78517"> &para;</a><div class="date" title="2007-10-15 09:21"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom78517">
<div class="phpcode"><code><span class="html">
re the comment by moazzamk at gmail dot com<br /><br />As the manual states require and require_once as of PHP 4.02 no longer call the file if the line of code it is on should not be executed.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="87675">  <div class="votes">
    <div id="Vu87675">
    <a href="/manual/vote-note.php?id=87675&amp;page=function.require&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd87675">
    <a href="/manual/vote-note.php?id=87675&amp;page=function.require&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V87675" title="39% like this...">
    -11
    </div>
  </div>
  <a href="#87675" class="name">
  <strong class="user"><em>pedro dot evangelista at gmail dot com</em></strong></a><a class="genanchor" href="#87675"> &para;</a><div class="date" title="2008-12-16 06:23"><strong>8 years ago</strong></div>
  <div class="text" id="Hcom87675">
<div class="phpcode"><code><span class="html">
Be careful when using symbolic links, because require will search the real path of the file and not the path relative to the symbolic link.<br /><br />Imagine your script A.php resides on directory /a and you create a symbolic link for it on directory /b/c.<br />So for the code<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">echo </span><span class="default">realpath</span><span class="keyword">(</span><span class="string">"../"</span><span class="keyword">);<br /></span><span class="default">?&gt;<br /></span><br />you might expect the directory /b, but actually you get the root directory /.<br /><br />If you need to include the file /b/B.php inside your A.php, you can't use the following<br /><br /><span class="default">&lt;?php<br /></span><span class="keyword">require </span><span class="string">"../B.php"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />because it will search the root directory, not the /b directory.<br /><br />Regards.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="52596">  <div class="votes">
    <div id="Vu52596">
    <a href="/manual/vote-note.php?id=52596&amp;page=function.require&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd52596">
    <a href="/manual/vote-note.php?id=52596&amp;page=function.require&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V52596" title="38% like this...">
    -12
    </div>
  </div>
  <a href="#52596" class="name">
  <strong class="user"><em>Marc</em></strong></a><a class="genanchor" href="#52596"> &para;</a><div class="date" title="2005-05-06 10:42"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom52596">
<div class="phpcode"><code><span class="html">
This will sound elementary, but for C++ native programmers, be sure NOT to put a '#' in front of your include statements! The parser will not give you an error, but also will not include the file, making for a tedious debugging process.<br /><br />In short, USE:<br /><span class="default">&lt;?php<br />&nbsp; &nbsp;&nbsp; </span><span class="keyword">include </span><span class="string">"yourfile.php"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span><br />and DON'T use:<br /><span class="default">&lt;?php<br />&nbsp; &nbsp;&nbsp; </span><span class="comment">#include "yourfile.php";<br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="83187">  <div class="votes">
    <div id="Vu83187">
    <a href="/manual/vote-note.php?id=83187&amp;page=function.require&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd83187">
    <a href="/manual/vote-note.php?id=83187&amp;page=function.require&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V83187" title="39% like this...">
    -18
    </div>
  </div>
  <a href="#83187" class="name">
  <strong class="user"><em>ricardo dot ferro at gmail dot com</em></strong></a><a class="genanchor" href="#83187"> &para;</a><div class="date" title="2008-05-14 11:15"><strong>9 years ago</strong></div>
  <div class="text" id="Hcom83187">
<div class="phpcode"><code><span class="html">
Two functions to help:<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">function </span><span class="default">add_include_path </span><span class="keyword">(</span><span class="default">$path</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; foreach (</span><span class="default">func_get_args</span><span class="keyword">() AS </span><span class="default">$path</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; if (!</span><span class="default">file_exists</span><span class="keyword">(</span><span class="default">$path</span><span class="keyword">) OR (</span><span class="default">file_exists</span><span class="keyword">(</span><span class="default">$path</span><span class="keyword">) &amp;&amp; </span><span class="default">filetype</span><span class="keyword">(</span><span class="default">$path</span><span class="keyword">) !== </span><span class="string">'dir'</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">trigger_error</span><span class="keyword">(</span><span class="string">"Include path '</span><span class="keyword">{</span><span class="default">$path</span><span class="keyword">}</span><span class="string">' not exists"</span><span class="keyword">, </span><span class="default">E_USER_WARNING</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; continue;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$paths </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">(</span><span class="default">PATH_SEPARATOR</span><span class="keyword">, </span><span class="default">get_include_path</span><span class="keyword">());<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; if (</span><span class="default">array_search</span><span class="keyword">(</span><span class="default">$path</span><span class="keyword">, </span><span class="default">$paths</span><span class="keyword">) === </span><span class="default">false</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">array_push</span><span class="keyword">(</span><span class="default">$paths</span><span class="keyword">, </span><span class="default">$path</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">set_include_path</span><span class="keyword">(</span><span class="default">implode</span><span class="keyword">(</span><span class="default">PATH_SEPARATOR</span><span class="keyword">, </span><span class="default">$paths</span><span class="keyword">));<br />&nbsp; &nbsp; }<br />}<br /><br />function </span><span class="default">remove_include_path </span><span class="keyword">(</span><span class="default">$path</span><span class="keyword">)<br />{<br />&nbsp; &nbsp; foreach (</span><span class="default">func_get_args</span><span class="keyword">() AS </span><span class="default">$path</span><span class="keyword">)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$paths </span><span class="keyword">= </span><span class="default">explode</span><span class="keyword">(</span><span class="default">PATH_SEPARATOR</span><span class="keyword">, </span><span class="default">get_include_path</span><span class="keyword">());<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; if ((</span><span class="default">$k </span><span class="keyword">= </span><span class="default">array_search</span><span class="keyword">(</span><span class="default">$path</span><span class="keyword">, </span><span class="default">$paths</span><span class="keyword">)) !== </span><span class="default">false</span><span class="keyword">)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; unset(</span><span class="default">$paths</span><span class="keyword">[</span><span class="default">$k</span><span class="keyword">]);<br />&nbsp; &nbsp; &nbsp; &nbsp; else<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; continue;<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; if (!</span><span class="default">count</span><span class="keyword">(</span><span class="default">$paths</span><span class="keyword">))<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">trigger_error</span><span class="keyword">(</span><span class="string">"Include path '</span><span class="keyword">{</span><span class="default">$path</span><span class="keyword">}</span><span class="string">' can not be removed because it is the only"</span><span class="keyword">, </span><span class="default">E_USER_NOTICE</span><span class="keyword">);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; continue;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">set_include_path</span><span class="keyword">(</span><span class="default">implode</span><span class="keyword">(</span><span class="default">PATH_SEPARATOR</span><span class="keyword">, </span><span class="default">$paths</span><span class="keyword">));<br />&nbsp; &nbsp; }<br />}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="70463">  <div class="votes">
    <div id="Vu70463">
    <a href="/manual/vote-note.php?id=70463&amp;page=function.require&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd70463">
    <a href="/manual/vote-note.php?id=70463&amp;page=function.require&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V70463" title="35% like this...">
    -9
    </div>
  </div>
  <a href="#70463" class="name">
  <strong class="user"><em>bmessenger at 3servicesolution dot com</em></strong></a><a class="genanchor" href="#70463"> &para;</a><div class="date" title="2006-10-17 01:06"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom70463">
<div class="phpcode"><code><span class="html">
// Looks like I might have a fix for some on the<br />// relative path issue.<br /><br />if (!function_exists('bugFixRequirePath'))<br />{<br />&nbsp; &nbsp; function bugFixRequirePath($newPath)<br />&nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; $stringPath = dirname(__FILE__);<br />&nbsp; &nbsp; &nbsp; &nbsp; if (strstr($stringPath,":")) $stringExplode = "\\";<br />&nbsp; &nbsp; &nbsp; &nbsp; else $stringExplode = "/";<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; $paths = explode($stringExplode,$stringPath);<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; $newPaths = explode("/",$newPath);<br />&nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; if (count($newPaths) &gt; 0)<br />&nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; for($i=0;$i&lt;count($newPaths);$i++)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if ($newPaths[$i] == "..") array_pop($paths);&nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; for($i=0;$i&lt;count($newPaths);$i++)<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; if ($newPaths[$i] == "..") unset($newPaths[$i]);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; reset($newPaths);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $stringNewPath = implode($stringExplode,$paths).<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; $stringExplode.implode($stringExplode,$newPaths);<br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <br />&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; return $stringNewPath;<br />&nbsp; &nbsp; &nbsp; &nbsp; }<br />&nbsp; &nbsp; }&nbsp; &nbsp; <br />}<br /><br />require_once(bugFixRequirePath("../config.php"));</span>
</code></div>
  </div>
 </div>
  <div class="note" id="97819">  <div class="votes">
    <div id="Vu97819">
    <a href="/manual/vote-note.php?id=97819&amp;page=function.require&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd97819">
    <a href="/manual/vote-note.php?id=97819&amp;page=function.require&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V97819" title="33% like this...">
    -7
    </div>
  </div>
  <a href="#97819" class="name">
  <strong class="user"><em>Wing</em></strong></a><a class="genanchor" href="#97819"> &para;</a><div class="date" title="2010-05-10 05:04"><strong>7 years ago</strong></div>
  <div class="text" id="Hcom97819">
<div class="phpcode"><code><span class="html">
if you want always include, require, open files using some 'root' folder based path you may may put file '.htroot' in 'root' folder and&nbsp; use this.<br /><br />while(!file_exists(getcwd()."/.htroot")){chdir('..');}<br /><br />This code change current dir to dir where '.htroot' file located and everywhere you can use relative to 'root' paths.<br /><br />Please avoid absent of '.htroot' file.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="77656">  <div class="votes">
    <div id="Vu77656">
    <a href="/manual/vote-note.php?id=77656&amp;page=function.require&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd77656">
    <a href="/manual/vote-note.php?id=77656&amp;page=function.require&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V77656" title="36% like this...">
    -14
    </div>
  </div>
  <a href="#77656" class="name">
  <strong class="user"><em>daniel at nohair dot com</em></strong></a><a class="genanchor" href="#77656"> &para;</a><div class="date" title="2007-09-06 07:24"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom77656">
<div class="phpcode"><code><span class="html">
I love php.&nbsp; But when file can't be included, 'require' or 'require_once' throw fatal error and halt the script, which is almost never desirable on a mission-critical production server.&nbsp; I think it may be better to use something like the following.&nbsp; <br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">if (@include </span><span class="string">'plan_A.php'</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="comment">// Plan A;<br /></span><span class="keyword">} elseif (@include </span><span class="string">'plan_B.php'</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="comment">// Plan B;<br /></span><span class="keyword">} else {<br />&nbsp; &nbsp; </span><span class="comment">// Hope never happens.&nbsp; If does, then Email the webmaster;<br />&nbsp; &nbsp; // Call 911, Medic, Fire, Police, the president;<br />&nbsp; &nbsp; // Change hard drive, server, hosting service;<br /></span><span class="keyword">}<br /><br /></span><span class="default">?&gt;<br /></span><br />Or handle trouble first is you wish<br /><br /><span class="default">&lt;?php<br /><br /></span><span class="keyword">if (!@include </span><span class="string">'plan_A.php'</span><span class="keyword">) {<br />&nbsp; &nbsp; </span><span class="comment">// Someone has kidnapped/corrupted Plan_A.php;<br />&nbsp; &nbsp; // Email the webmaster;<br />&nbsp; &nbsp; // Change hard drive, server, hosting service;<br /></span><span class="keyword">} else {<br />&nbsp; &nbsp; </span><span class="comment">// Plan A;<br /></span><span class="keyword">}<br /><br /></span><span class="default">?&gt;</span>
</span>
</code></div>
  </div>
 </div>
  <div class="note" id="66892">  <div class="votes">
    <div id="Vu66892">
    <a href="/manual/vote-note.php?id=66892&amp;page=function.require&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd66892">
    <a href="/manual/vote-note.php?id=66892&amp;page=function.require&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V66892" title="33% like this...">
    -8
    </div>
  </div>
  <a href="#66892" class="name">
  <strong class="user"><em>Inc</em></strong></a><a class="genanchor" href="#66892"> &para;</a><div class="date" title="2006-05-31 08:35"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom66892">
<div class="phpcode"><code><span class="html">
I have found a problem when I try to access a php file via require($class_directory)<br /><br />// # $class_directory contain a long full path and dot into the last folder.<br />// # $class_directory = "/var/.../app/system/plugintoto_1.0/class_plugintoto_1.0.php";<br /><br />// dot ('.') and minus ('-') are not accepted in require !</span>
</code></div>
  </div>
 </div>
  <div class="note" id="49864">  <div class="votes">
    <div id="Vu49864">
    <a href="/manual/vote-note.php?id=49864&amp;page=function.require&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd49864">
    <a href="/manual/vote-note.php?id=49864&amp;page=function.require&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V49864" title="33% like this...">
    -8
    </div>
  </div>
  <a href="#49864" class="name"><strong class="user"><em>Anonymous</em></strong></a><a class="genanchor" href="#49864"> &para;</a><div class="date" title="2005-02-10 10:29"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom49864">
<div class="phpcode"><code><span class="html">
Note when calling any require or include function, that the call will block if the script given as the parameter is excecuting.<br />Because of this one should be careful when using blocking functions like sleep() in a script which is included by another.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="62327">  <div class="votes">
    <div id="Vu62327">
    <a href="/manual/vote-note.php?id=62327&amp;page=function.require&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd62327">
    <a href="/manual/vote-note.php?id=62327&amp;page=function.require&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V62327" title="34% like this...">
    -13
    </div>
  </div>
  <a href="#62327" class="name">
  <strong class="user"><em>webmaster at netgeekz dot net</em></strong></a><a class="genanchor" href="#62327"> &para;</a><div class="date" title="2006-02-24 09:34"><strong>11 years ago</strong></div>
  <div class="text" id="Hcom62327">
<div class="phpcode"><code><span class="html">
I have learnt to manipulate this code into an effecitve and easy to use form. I use it with require_once, but it could be used for require.<br /><br />require_once($_SERVER['DOCUMENT_ROOT'].'/includes/top.php');<br /><br />This mainly jumps back to the servers document root and then begins to enter the directories defined until it finds the file. In this case it would go back to the root of the server, or whatever your document root is, and then enter includes. there it would search for the top.php file. Simple to use, yet effective...espcially for people like me who re-use code or move files to different directories. I don't have to fix the includes, because they all work the same way.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="113116">  <div class="votes">
    <div id="Vu113116">
    <a href="/manual/vote-note.php?id=113116&amp;page=function.require&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd113116">
    <a href="/manual/vote-note.php?id=113116&amp;page=function.require&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V113116" title="30% like this...">
    -9
    </div>
  </div>
  <a href="#113116" class="name">
  <strong class="user"><em>hans at ratzinger dot com</em></strong></a><a class="genanchor" href="#113116"> &para;</a><div class="date" title="2013-09-01 05:25"><strong>4 years ago</strong></div>
  <div class="text" id="Hcom113116">
<div class="phpcode"><code><span class="html">
Thanks a lot for this information Brian! This drove me nuts for many hours! This is the first information I found in the web that a white page can be caused by a require -&gt; your script will die if the file is not found!!!</span>
</code></div>
  </div>
 </div>
  <div class="note" id="117670">  <div class="votes">
    <div id="Vu117670">
    <a href="/manual/vote-note.php?id=117670&amp;page=function.require&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd117670">
    <a href="/manual/vote-note.php?id=117670&amp;page=function.require&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V117670" title="28% like this...">
    -6
    </div>
  </div>
  <a href="#117670" class="name">
  <strong class="user"><em>dank at kegel dot com</em></strong></a><a class="genanchor" href="#117670"> &para;</a><div class="date" title="2015-07-19 05:46"><strong>2 years ago</strong></div>
  <div class="text" id="Hcom117670">
<div class="phpcode"><code><span class="html">
PHP's require and include seem to differ from C's include in another way: they can't be used in the middle of an expression.&nbsp; e.g.<br /><br />$ more foo1.php foo2.php<br />::::::::::::::<br />foo1.php<br />::::::::::::::<br /><span class="default">&lt;?php<br /></span><span class="keyword">print </span><span class="string">"hello" <br /></span><span class="keyword">.<br /></span><span class="comment">#"there"<br /></span><span class="keyword">require </span><span class="string">'foo2.php'</span><span class="keyword">;<br />. </span><span class="string">"\n"</span><span class="keyword">;<br /></span><span class="default">?&gt;<br /></span>::::::::::::::<br />foo2.php<br />::::::::::::::<br />"there"<br />$ php foo1.php<br />PHP Parse error:&nbsp; syntax error, unexpected '.' in foo1.php on line 6<br /><br />So php's include operates only on complete statements, whereas c's include operates on bytes of source code.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="47589">  <div class="votes">
    <div id="Vu47589">
    <a href="/manual/vote-note.php?id=47589&amp;page=function.require&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd47589">
    <a href="/manual/vote-note.php?id=47589&amp;page=function.require&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V47589" title="32% like this...">
    -10
    </div>
  </div>
  <a href="#47589" class="name">
  <strong class="user"><em>danielm at unb dot br</em></strong></a><a class="genanchor" href="#47589"> &para;</a><div class="date" title="2004-11-21 11:50"><strong>13 years ago</strong></div>
  <div class="text" id="Hcom47589">
<div class="phpcode"><code><span class="html">
if you want to include files with an absolut path reference, you can use:<br /><br />require ($_SERVER["DOCUMENT_ROOT"]."/path/to/file.php");<br /><br />this way you can organize your files in subdirectories trees.</span>
</code></div>
  </div>
 </div>
  <div class="note" id="77929">  <div class="votes">
    <div id="Vu77929">
    <a href="/manual/vote-note.php?id=77929&amp;page=function.require&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd77929">
    <a href="/manual/vote-note.php?id=77929&amp;page=function.require&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V77929" title="32% like this...">
    -13
    </div>
  </div>
  <a href="#77929" class="name">
  <strong class="user"><em>scott</em></strong></a><a class="genanchor" href="#77929"> &para;</a><div class="date" title="2007-09-20 01:27"><strong>10 years ago</strong></div>
  <div class="text" id="Hcom77929">
<div class="phpcode"><code><span class="html">
If you want to verify that a file can be included or required, the simplest solution I've found is just to check that the file exists.<br /><br /><span class="default">&lt;?php<br /><br />&nbsp; &nbsp; </span><span class="keyword">if(</span><span class="default">file_exists</span><span class="keyword">(</span><span class="default">$pageContentInc</span><span class="keyword">)){<br />&nbsp; &nbsp; &nbsp; &nbsp; require_once </span><span class="default">$pageContentInc</span><span class="keyword">;<br />&nbsp; &nbsp; }else{<br />&nbsp; &nbsp; &nbsp; &nbsp; </span><span class="default">$pageContentInc </span><span class="keyword">= </span><span class="string">"common/content_404.inc"</span><span class="keyword">;<br />&nbsp; &nbsp; &nbsp; &nbsp; require_once </span><span class="default">$pageContentInc</span><span class="keyword">;<br />&nbsp; &nbsp; }<br /></span><span class="default">?&gt;<br /></span><br />Does it really need to be any harder than that?</span>
</code></div>
  </div>
 </div>
  <div class="note" id="51699">  <div class="votes">
    <div id="Vu51699">
    <a href="/manual/vote-note.php?id=51699&amp;page=function.require&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd51699">
    <a href="/manual/vote-note.php?id=51699&amp;page=function.require&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V51699" title="30% like this...">
    -9
    </div>
  </div>
  <a href="#51699" class="name">
  <strong class="user"><em>richardbrenner(-at- )gmx(-)at</em></strong></a><a class="genanchor" href="#51699"> &para;</a><div class="date" title="2005-04-07 01:58"><strong>12 years ago</strong></div>
  <div class="text" id="Hcom51699">
<div class="phpcode"><code><span class="html">
If you use relativ paths in a php script (file A) that can be required by another php script (file B), be aware that the relativ paths in file A will be relativ to the directory, where file B is stored. <br />You can use the following syntax in file A, to be sure that the paths are relativ to the directory of file A:<br /><br />&lt;?<br />require(dirname(__FILE__)."/path/relative/file_to_include.php");<br />?&gt;<br /><br />Greetings,<br />Richard</span>
</code></div>
  </div>
 </div>
  <div class="note" id="115700">  <div class="votes">
    <div id="Vu115700">
    <a href="/manual/vote-note.php?id=115700&amp;page=function.require&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd115700">
    <a href="/manual/vote-note.php?id=115700&amp;page=function.require&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V115700" title="23% like this...">
    -9
    </div>
  </div>
  <a href="#115700" class="name">
  <strong class="user"><em>theunis dot botha1 at gmail dot com</em></strong></a><a class="genanchor" href="#115700"> &para;</a><div class="date" title="2014-09-11 11:33"><strong>3 years ago</strong></div>
  <div class="text" id="Hcom115700">
<div class="phpcode"><code><span class="html">
Just for those who may wonder about receiving E_WARNING (in custom error handlers) - PHP generates an E_WARNING when require or require_once fails - and before control returns to your script, it generates an E_COMPILE_ERROR.<br /><br />So when require() or require_once() fails - don't be surprised to see two messages in your logs (if you have your logging setup this way) - once for the E_WARNING caught by your custom error handler, and once for getting the error from error_get_last() in your shutdown function (which is the actual E_COMPILE_ERROR you were expecting)</span>
</code></div>
  </div>
 </div>
  <div class="note" id="119947">  <div class="votes">
    <div id="Vu119947">
    <a href="/manual/vote-note.php?id=119947&amp;page=function.require&amp;vote=up" title="Vote up!" class="usernotes-voteu">up</a>
    </div>
    <div id="Vd119947">
    <a href="/manual/vote-note.php?id=119947&amp;page=function.require&amp;vote=down" title="Vote down!" class="usernotes-voted">down</a>
    </div>
    <div class="tally" id="V119947" title="20% like this...">
    -3
    </div>
  </div>
  <a href="#119947" class="name">
  <strong class="user"><em>phpDev a t eSurfers_dot_ com</em></strong></a><a class="genanchor" href="#119947"> &para;</a><div class="date" title="2016-09-25 03:19"><strong>1 year ago</strong></div>
  <div class="text" id="Hcom119947">
<div class="phpcode"><code><span class="html">
I didn't find mention that calling return from inside an required file is different than calling return from inside an included file.<br /><br />return "aaa"; if called in the global scope of an included file will terminate the inclusion and return control to the main file givin "aaa" as a result of the include statement itself.<br /><br />As far as I have tested (PHP 5.6.10) this does not apply to require</span>
</code></div>
  </div>
 </div></div>

 <div class="foot"><a href="/manual/add-note.php?sect=function.require&amp;redirect=http://php.net/manual/en/function.require.php"><img src='/images/notes-add@2x.png' alt='add a note' width='12' height='12'> <small>add a note</small></a></div>
</section>    </section><!-- layout-content -->
        <aside class='layout-menu'>
    
        <ul class='parent-menu-list'>
                                    <li>
                <a href="language.control-structures.php">Control Structures</a>
    
                                    <ul class='child-menu-list'>
    
                          
                        <li class="">
                            <a href="control-structures.intro.php" title="Introduction">Introduction</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.if.php" title="if">if</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.else.php" title="else">else</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.elseif.php" title="elseif/else if">elseif/else if</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.alternative-syntax.php" title="Alternative syntax for control structures">Alternative syntax for control structures</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.while.php" title="while">while</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.do.while.php" title="do-&#8203;while">do-&#8203;while</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.for.php" title="for">for</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.foreach.php" title="foreach">foreach</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.break.php" title="break">break</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.continue.php" title="continue">continue</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.switch.php" title="switch">switch</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.declare.php" title="declare">declare</a>
                        </li>
                          
                        <li class="">
                            <a href="function.return.php" title="return">return</a>
                        </li>
                          
                        <li class="current">
                            <a href="function.require.php" title="require">require</a>
                        </li>
                          
                        <li class="">
                            <a href="function.include.php" title="include">include</a>
                        </li>
                          
                        <li class="">
                            <a href="function.require-once.php" title="require_&#8203;once">require_&#8203;once</a>
                        </li>
                          
                        <li class="">
                            <a href="function.include-once.php" title="include_&#8203;once">include_&#8203;once</a>
                        </li>
                          
                        <li class="">
                            <a href="control-structures.goto.php" title="goto">goto</a>
                        </li>
                            
                    </ul>
                    
            </li>
                        
                    </ul>
    </aside>


  </div><!-- layout -->
         
  <footer>
    <div class="container footer-content">
      <div class="row-fluid">
      <ul class="footmenu">
        <li><a href="/copyright.php">Copyright &copy; 2001-2017 The PHP Group</a></li>
        <li><a href="/my.php">My PHP.net</a></li>
        <li><a href="/contact.php">Contact</a></li>
        <li><a href="/sites.php">Other PHP.net sites</a></li>
        <li><a href="/mirrors.php">Mirror sites</a></li>
        <li><a href="/privacy.php">Privacy policy</a></li>
      </ul>
      </div>
    </div>
  </footer>

    
 <!-- External and third party libraries. -->
 <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/modernizr.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/hogan-2.0.0.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/typeahead.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/ext/mousetrap.min.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1421837618&amp;f=/js/search.js"></script>
<script type="text/javascript" src="http://php.net/cached.php?t=1500560403&amp;f=/js/common.js"></script>

<a id="toTop" href="javascript:;"><span id="toTopHover"></span><img width="40" height="40" alt="To Top" src="/images/to-top@2x.png"></a>

</body>
</html>

