package Semana12.Ejercicio1;

public interface Estrategia {
    final String[] ENABLED_ESTRATEGIES = new String[] {"AZAR","CICLICA","COPIA"};
    final String[] DISABLED_ESTRATEGIES = new String[] {};
}
